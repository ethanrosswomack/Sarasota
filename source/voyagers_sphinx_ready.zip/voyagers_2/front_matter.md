This PDF sold to Ethan Womack - dudeinwrens@gmail.com  Transaction: 7960

                
         
              Voyagers
   Secrets of Amenti
     Volume II                                    
    Expanded Second Edition                      
                                                            By Ashayana Deane                                     
                                           (Anna Hayes)
         Information transcribed from the Guardian Alliance
        regarding the 2000 to 2017 Time Continuum Shift,
     Humanity’s True Origins and Hidden Evolutionary Destiny, the Arc of
      the Covenant, the Halls of Amenti, Keylontic Science, and the Process
      of Entering the Higher Evolution
  ARhAyas Productions LLC
              Sarasota, Fl
                                                                                                                                                                                                                                                          
                                                                                                      
                                      
                                                                                                                                                                        This PDF sold to Ethan Womack - dudeinwrens@gmail.com  Transaction: 7960

                                                       
                                                        
                                                      Copyright ©2002 by Ashayana Deane
All rights reserved.
                      No part of this book may be reproduced in any form or by any electronic or mechanical means,         
                including information and retrieval systems, without prior permission from the publisher in writing.                                                   
.
Library of Congress Cataloging-in-Publication Data
Deane, Ashayana 1964
V oyagers: the secrets of amenti / by Ashayana Deane
p. cm. 
                                                  ISBN-978-0-692-84552-3 
            1. Human-alien encounters.                                                                                                                   
2. Spirit writings
l. Title
BF2050.H38 1999
                                                                                   001.942—dc21                                                                                                                   
99-23148
CIP
The V oyagers Series
V olume II, Second Edition 
Reprised March, 2017 
Cover artwork and internal illustrations: Ashayana Deane                                                                                                                                            
           Final cover work: Suzanne Maksel and Pam Meyer                                                                      
Manuscript editors: Brian Crissey, Pam Meyer, Julie Sherar and Susan Westhoff
Indexer: Brian Crissey, Ph.D.
Address all inquiries to:
                                                                                           
ARhAyas Productions LLC
5020 Clark Rd #307
Sarasota, FL 34233
Email: office@arhayas.com
Phone: 941-924-8109
www.arhayas.com
                                                 
                                        
                          This PDF sold to Ethan Womack - dudeinwrens@gmail.com  Transaction: 7960

                                                  Dedicated to                                                The Guardians 
                                        of all Races and Realities
                                                      And to
                                        The Guardian Alliance
                                  for their patience and wisdom 
                                 and for the creation of this book.
                                                                                                                    
                                                  In Memory of                                                      Richard G. Herhenreader, 
                                         Beloved Voyager                                      
                                                  
This PDF sold to Ethan Womack - dudeinwrens@gmail.com  Transaction: 7960

                   
                           Table of Contents
                  
                                                                                         
Preface to Volume ll ......................................................................................... ix                                                                                          
       Required Reading  ........................................................................................... xi
   ORIGINAL MATERIAL                                                                                                                                                       1 The Secrets of Am enti.................................................................................. 1                                       
                     Amenti Transmission l998 ............................................................................... .1                                                     
                     Origins and the Fall. .................................................................................................... .2                                      
                     Amenti Rescue Mission. ............................................................................................ .6
                     The Halls of Amenti... ....................................................................................... 9                                                                                                Root Races - Cloistered Races .......................................................................15                                                                              
            The Electric Wars... ....................................................................................... ..18                                                                           
                2 The Second Seeding ................................................................................... 27                                                
                     Sirius B ............................................................................................................ .27                                                            
                         Melchizedek Races  .............................................................................. .29                                                               
                  Science of Ascensio n...................................................................................... .38                                                          
                  The Thousand—Years’ War. ......................................................................... .43                                                                 
             3 The Third Seeding ...................................................................................... 50                                            
                    The Arc of the Covenant .. ........................................................................... ..50                                                             
                          Lemuria Destroyed  ........................................................................................ ..58                                                                                                    
                         Giza to Atlantis . ........................................................................................................... 59                                                       
                   2017 AD Appointment .................................................................................. .65                                                            
              4 A Journey Toward Awakening .................................................................... 7l                                                 
                   Sinking Atlantis and Earth Quarantine  ....................................................... .71                                            
                   Dreaming, Ego, and Higher Self ................................................................. .77                                                               
                   Alcyone and the Templar Seal  ..................................................................... .82                                                                         
              5 Return to Amenti ......................................................................................... 87                                               
                 Pharaoh Akhenaton ........................................................................................ .87                                                           
                  The Three Christs ........................................................................................... .96                                                            
             6 Ascension Mechanics .................................................................................106                                      
                Humanity’s Evolution ................................................................................. .106                                                           
               Earth Time Cycles ....... .................................................................................110                                                               
                 The Holographic Beam ................................................................................114                            
                DNA and the Halls of Amenti ......................................................................117                                                                  
           7 Countdown to Amenti .................................................................................122                                                        
                     Recent History ............................................................................................ ...122                                              
                Merkaba Fields  ............................................................................................. .126                                                                                        
           The Philadelphia Experiment and Solar Crisis .................................... 130                                                          
               Solar Crisis and 11:11/12:12 ...................................................................... .133                                                             
                        The Montauk Project ................................................................................... .136                                       
         8 Current Events ............................................................................................142                                                                                                       ..                                                       
        The Bridge Zone Project. ..............................................................................142                                                            
                             Bridge Zone Mechanics .............................................................................. .145                                                       
                                 Time-Cycle Mechanics and Evolution. ......................................................146                                                                      
                                 DNA ................................................................................................................156
     iv
                                                                                                                      
                                                                                                   
            
This PDF sold to Ethan Womack - dudeinwrens@gmail.com  Transaction: 7960

                                                                                                                Table of Contents                                                                 
  9   Time Shift.. ...............................................................................................160
                Ascending and Descending Planets.................................................................. .160
                   Three Tracks of Time........................................................................................169
 10 Opening the Halls of Amenti ………………………………………........185                                                                                           Context .............................................................................................................185                                                                                                                                     
               10/1986 through 6/1998 ............................................................................. ..187                       
                    The Arc of the Covenant Opens ................................................................ .193                                                                             
                    Palaidorian Birthing Contracts.. ..................................................................194
 11  Things to Come ........................................................................................199                                                               Ascension Schedule ..................................................................................... .199             
               The Amenti Ascension Program Schedule ................................................201                                                                                               
                Final 1998 Comments from the Guardian Alliance  ................................230
 12 Author’ s Closing Statement,  1998 ......................................................234                                                                                   The I Am Prayer ............................................................................................239
 2001 UPDATE SECTION                                                                                             
 13 Emergency Release GA ............................................................................241                                                         
              A New Level of (Continuous) Revelation . . . . . . . . . …………........…. .241                                                                   
                Anunnaki, 1992 Pleiadian-Sirian Agreements & Fallen ET races....... 242                                                   
                Solar Star Gate-4 & Anunnaki defection from                                                                                               
               the 1992 Pleiadian-Sirian Agreements  .............................................245                                                                               
        The July 5, 2000, Treaty of Altair & Anunnaki Sabotage                                                                                  
                       of the 9/2000 UK Expedition . .............................................................247                                                                        
                The September 2000 UIR and the Edict of War ......................................250                                                                                  
                The D-l2 Planetary Security Seal, Planetary Shields Clinics,                                                                                           
                      and Crisis Intervention . ........................................................................255                                                            
                Invasion Agenda, HAARP, Merkaba-Reversal,                                                                                                 
                      and the Rude Awakening ......................................................................257                                                           
                Merkaba Mayhem, Real Ratios, and                                                        .                                                            
                       the Nibiruian Checkerboard Mutation .............................................. .259.
 14 Angelic Human Heritage & Rainbow Roundtables ..................................261                                                           
               Genetic Ascendancy of Angelic Human Lineage .................................... .262                                                                                                  
                 12-Tribes Seeding-3 Genetic Ascendancy ................................................263                                                                      
                 The Azurites, IAFW, Oraphim-Angelic Human, MC Priests of UR,                                                                                                               
                    and lndigo Child Eieyani Grail Line. ....................................................264                                                                        
               Creation of the Oraphim-Turaneusiam Angelic Human                                                                                                         
                       Christiac-Rishic Grail Line ............................................................. ...266                                                                       
               Seeding the 12 Urtite-Cloister Palaidia Empires .....................................269                                                                    
                Urtite-Tri-Cloister Maji Holy Grail Line Flame Keepers . ......................270                                                                  
                Shambali, Bhrama, and Annu-Melchizedek Races of Inner Earth ....... 271                                                                                
               The Three Primary Urtite-Tri-Cloister Maji Flame Keeper                                                                                            
                 Holy Grail Line Seed Races of the Palaidia Empires .....................272                                                                     
                The Two Secondary Urtite-Bi-Cloister Maji Flame Keeper                                                                     
                       Holy Grail Line Seed Races of the Palaidia Empires .....................276                                                                      
                The Riddle of the “Roundtable”— Location of Race Seedings                                                                             
                    and Rites of the Rounds ..........................................................................278               
                Four Evolutionary Rounds, Co-Resonant Continuum Alignment,                                                                                                                                       
                Trans-Time Connection, & Christos Realignment Mission . …..............284                                                                          
                The Cycle of the Rounds Seeding-3 ......................................................... .290                                                             
      The "Cycle of the Round" .......................................................................... ..291                                                            
      Evolutionary Rounds . ...................................................................................291                                      
 Fire Letter Sequences ....................................................................................291        
                v                                                                                                                                                                                                                                                                 
                                                                                                                                                                            
This PDF sold to Ethan Womack - dudeinwrens@gmail.com  Transaction: 7960

      . 
 
Table of Contents
           Angelic Humanity’s Original Sacred Mission . ....................................... .292                                                                                   
    The Planetary Shields & 12 Signet Star Gates                                                                                                                                            
                  of the Universal Templar Complex . ...................................................294                                                                                          
           The 12 Tribes and the Roundtables ........................................................... .295                                                                        
           12-Cycles, Simultaneous Incarnation, and DNA ....................................296                                                                     
           The Reality of Spiritual Integration .......................................................... .298                                                         
                 Activating the Tribal Shield . ......................................................................299                                                                       
                  The Silicate Matrix 12-Strand DNA Template with Hova Body,                                                     
     Scalar Shield, and Identity Level Correspondences.. ...................... .300                                                                                                      
     The fastest means of naturally activating                                                                                                                                                      
           the Personal 12-Strand DNA Template ..............................................301      
         Christos Identity Integration  ........................................................................301           
                  Reality of the Roundtables ......................................................................... ....302                                                      
                  12 Tribe Names and Sacred Psonns ............................................................303                                                                             
                  The Three Key Elements of the Cycle of the rounds.. ................................ .303                                                                                                      
                   Tribal Shield Dynamics ................................................................................ .307         
  15  The Atlantian Conspiracy and Roundtables ............................................310                      
              Long-Term Problems and Immediate Solutions ...................................... 310                                                                                            
                 The Atlantian Conspiracy .............................................................................311                                                       
                 King Arthur and the Knights of the Roundtable ..................................... .315
    Progression of Major Events in the Atlantian Conspiracy ..................... .319
     Core Template Gridwork is Required . ..................................................... .328
    Creation of the Leviathan Force & Related History  ...............................328
      Angelic Human Seeding-3—Contemporary Lineage Begins  ............... .328 
    Summary of the Atlantian Conspiracy ..................................................... .330
    The REAL Atlantian-Lemurian Maps ........................................................331
    Note On 12-Strand DNA Template Activation: Be Aware  ................... ..333
  16 The 9/11/2001 Attack & the Illuminati OWO ..........................................335 
           “ UFO I nvestigation” and “Trigger Events”. ............................................336
           One World Order (OWO) Master Plans, GA State of War Alert
                  and Imminent Crisis Order ................................................................. .337
           Star Gate-6 and the Selenite Crystal Temple Network .......................... .339
           Trion-Meajhé Fields and Expedited Amenti Opening . ..........................342
           The October 1999 Classified Document, Psychotronics,
                   Montauk and OWO  .............................................................................344
           Sleepers, Terrorists, Remote Viewing, RITs and the NET... .................. .347
  17 The Phi-Ex Wormhole &  Illuminati OWO  ..............................................354              
       The Bermuda Triangle, Phi-Ex Wormhole, Falcon Matrix and WW II ......354
        The Phi-Ex Wormhole, and the Phantom Matrix “Pit”—1943 ............. .359
          Necromiton-Andromies and the “Unholy Alliance” .............................. .359
        “Big Brother Drac,” the Andromies, Hiroshima and Hitler ..................361
    18 The Hidden Game-board Final Conﬂict Drama .....................................366
             APIN Systems; The Falcon, the Andromies and the Dove 1943-1951 .......366
               The Lion, the “Lamb,” the Sphinx and the Eagle ...................................367
        The White Eagle and the Melchizedek Deception .................................. .370
         The Sacred Cow, Faces of Man, Easter Island Heads & Trion Field... .371
         The Falcon, Phoenix Project and
                the Andromie-Rigelian Coalition 1951-1983 .................................. .374
         Andromie-Rigelian Coalition, Dragon, bin Laden,
                and the “War on Terrorism” 1980-2001 ........................................... .376
        Montauk Project, “War in the Heavens,” Sonic Pulse
                and “Un-Natural Disasters” 1983 ............................. ......................... .378   
  vi                                                                                                                                                  
                                                                             
                     
          
                                                                                         
This PDF sold to Ethan Womack - dudeinwrens@gmail.com  Transaction: 7960

                                                                                         
                                                                                         
                                                                                                                               
                                                                                                  Table of Contents
            Guardian Intervention and the Bridge Zone Project 1983-1992 ........... .379
            The Pleiadian-Sirian Agreements and Hurricane Andrew 1992 ........... .380
            Temporary Cap on the Montauk Phi-Ex Wormhole 1994-1998 ............382
            Anunnaki Defection, Falcon Un-Capped, Indigo Hunting          
               and Edict of War 1998-2001 ....................................................................... .384
.
     19 Wall in Time, Atlantian Secrets of Phoenix & Falcon .............................386  
          Dimensional Ble nd Experiment, the Wall in Time,
                Illuminati Master Plan 2003 . ............................................................... .386
          The WTC/Pentagon Disaster and
                  the “Secrets of the Phoenix and the Falcon” .................................... ..389
          The Real Founding of America—“Spiking Out the Territory” ..............393
      Our Hidden History of Sorrow, 9558 BC-present ...................................398
          Spiritual Manipulation ..................................................................................399
          Breeding a Final Conﬂict Army & Planetary Shields Reversal. ............401  
 20 HAARPs, Trumpets, Horsemen, and Heaven ...........................................403  
                    What Really Ha ppened on 9/ 11/2001 ..............................................................403
                     The  Trumpets, Towers and Terrorists-
                                   The Hidden Realities of the WTC/Pentagon Disaster. ...................... .407 
        UIR OWO Master Plan Agenda. .................................................................410                       
      Decoding “Revelations”—the OWO Schedule ........................................ ..414
             Revelations and “Saint John the Divine” ...................................................416
              The  “Seven Churches,” “Seven Angels” and “the Dove” .....................417
            The Seven Seals and the Four Horsemen of the Apocalypse .................419
          Return to Innocence ......................................................................................422
21 Conclusion— Earth Changes Potential. ..................................................426
         Planetary Shields Crisis, Seals and Earth Changes . ................................426
         Climatic Disturbances and the Labor Day 2001.
                  Sonic Pulse Interference ...................................................................... .429
            Epilog ............................................................................................................. .433
 .
 APPENDICES
 Appendix I  Data Summaries & At—A-Glance Blow-Up Charts ................ 434
       At-A-Glance Blow-Up Charts ....................................................................434
      Original  Amenti Ascension Program .........................................................438
                 The Six Silent Ascension Avatars  .............................................................. .446
               The Three Tracks of Time  ........................................................................... .447
          Choosing Your Future ..................................................................................450
   Appendix II Introduction to Keylonta .........…..............................................451
            The Science of Light, Sound, the Sub-Conscious Symbol Codes,
                  and the Base Codes of Matter ..............................................................451
          Six Primary Elements of Keylontic Science ............................................ .434
          Welcome to the Fifth World  .........................................................................461
  Appendix III Ascension Cycle Dynamics …………….........................463
           Stellar Activations .........................................................................................464
             Stellar Wave Infusions  ..................................................................................466
    The Stellar Bridge  ......................................................................................... .470
     Morphogenetic Crystal Seals  .......................................................................473
      The Silicate Matrix ........................................................................................ .477
      DNA 101 ..........................................................................................................478
      Ascension Cycle Dynamics At-A-Glance Blow-Up Charts ....................484
      Crystal Seals and Chakras Correspondence Chart  .................................. .485                 
      Stellar Activations, Spiral Alignments & 
            the Star Crystal Seal Activations Chart ...............................................486                           
   
   vii                                                                                                   
    
  
This PDF sold to Ethan Womack - dudeinwrens@gmail.com  Transaction: 7960

      
 
         Table of Contents   
               
                 Crystal Seals, Dimensional Placement and
                               DNA Correspondence Chart .........................................................487
                   15-Chakras & 15-Star Crystal Seals Anatomical Placement Chart ...... .488
                   Six Personal Stellar Activations and Wave Infusions Chart  .................489
                   Planetary Stellar Activations and Wave Infusions Chart  ...................... .490
                   Stellar Activations and Wave Infusions Schedule  .................................. .491
                   Stellar Spiral Alignments Schedule ..........................................................492
    Appendix IV Field Techniques . ....................................................................493
                Field Technique 1: Exercise to Release Crystallized Thought
                          Patterns from the DNA and Cellular Memory Imprint .................. ..493
                   Field Technique 2: The Maharic Seal ...................................................... .496
                   The Personal and Planetary Maharic Shields Chart  ...............................497
                   Temporary Maharic Seal Technique Steps .............................................. .502
                   Field Technique 3: The Maharic Quick Seal ...........................................502
                   Field Technique 4: The Maharata ..............................................................503
    Appendix V 2001 Update Summary Charts .................................................505
                   Star Gate Master Grid Lines Map .............................................................505
                   Star Gates and the Halls of Amenti Charts ..............................................506
                   The Halls of Amenti Star Gate System ....................................................507
                 Universal, Galactic, Planetary and Inner Earth Star Gates ...................508
                   Planetary Star Gates Location coordinate Chart ..................................... .509
                   Expedited Amenti Opening and
                           Christos Realignment Mission Charts .............................................510
                   Earth’s D-12 Pre-matter Christos Divine Blueprint ...............................513
                   Planetary and DNA Seals Release Schedules .........................................514
                   12-Strand DNA Template, Vector Codes and Seals ...............................515
                   The Real Christ Crucifixion, Checkerboard Mutation .......................... .516                                             
                   Christos-Trion-Meajhé Fields, Veca Codes                                                                                                                                                           
                           and Universal Life Force Currents .................................................. .517
                      Progression of Intruder APIN Templar Conquest: Atlantis to 2001 ......518
                   Sonic Pulse “Un-Natural Disasters” 1935-1992 Summary Chart ........ .522
                   9/11/2001 Intrasound Sub-Space Sonic Pulse Projection Map  .............. 523
                   24 Nibiruian Crystal Temple Bases .......................................................... .524
                   24 United Intruder Resistance Nibiruian Crystal Temple Bases .. …... .525
                        The Four Faces of Man/Guardians of the 12 Pillars LPIN System ..... .526
                   The Great White Lion Guardian APIN System  ...................................... .527
                   Golden Eagle APIN System  .......................................................................528
                   The Falcon and Dragon Intruder APINs ..................................................529
                Anunnaki and Anunnaki-Andromie-Nephite Intruder APINs ............. .530
                   Angelic Human 12-Tribes & Indigo Maji Grail Lines Summary  ..….. .531
                   Intruder ET & Illuminati Races, 2001 UIR OWO Team Summaries ...532      
    Appendix VI Crisis Intervention Expedited Amenti Opening Schedule .........5 38      
                Events Leading to GA Crisis Intervention and 
                            Expedited Amenti Opening ...............................................................538
                   Expedited Amenti Opening Crisis Intervention Program Begins ......... .540
                   2011 Meajhe Field Weakness, UIR Jehovian Seals
                            and Trumpet Pulse .............................................................................. .552       
                   UIR, “ Wingmakers” the Labyrinth Weapon and 2011. ......................... .553
    Index, V olume II ............................................................................................ 558    
     viii      
This PDF sold to Ethan Womack - dudeinwrens@gmail.com  Transaction: 7960

                       
                                                               
                                              
                                                                                                                                                                                                             
                                                                       
       Preface to V olume II   
           For there is nothing hidden except to be revealed, nor is anything kept
          secret except in order that it may be made known. If any man has ears
                       to hear, let him be listening and let him perceive and comprehend.
                                                                                 —Mark 4: 22-23
             
                 Voyagers: Secrets of Amenti  is a remarkable achievement. The magnitude
          of the implications fostered by its very existence is, in a word, stupendous. In
            the inspired writings of India, Voyagers  would be regarded as Shruti,  which
             functions as its own authority , since it is the product of immediate insight
          into the nature of ultimate reality . Ashayana’ s experience with the Guardian
           Alliance represents, in my opinion, a true Gnosis —a direct experience with
         higher intelligence—the direct experience of knowledge, with no loss of res-     
                                olution.  
            Ashayana, by her own admission, functions here solely as scribe. Voyagers
       is the product of nearly 30 years of direct, physical, consensual, and—most
        importantly—on-going contact with pro-human higher intelligence, be they
       Extra-, Meta- or Ultra-terrestrial; hence a Gnosis in the truest sense. This
            Gnosis is passed on to the reader, engaging a higher level of cognition or             
          precognition, if one is already one step ahead of the game.
        Voyagers is a precious jewel in “Indra’s Web,” spoken of in the Buddha’ s
      Flower Garland Sutra , itself a testament in previous times to a profound
       knowledge and understanding of advanced Keylontic Morphogenetic Sci-                       
     ence. In the following pages, you will be reawakened to a model of interdi-
  m e n s i o n a l  p h y s i c s ,  t i m e  m e c h a n i c s ,  D N A  c o n s t r u c t i o n  a n d  m u l t i -
   dimensional identity structure that will revolutionize your comprehension of
     our world, our universe and yourselves.  
                          These teachings are being returned to us at a most critical juncture in our
                 tenure as embodied souls, “in order that you may , as free and proud shaper of
                your own being, fashion yourself in the form you may prefer .” ¹ These teach-
                   ings are submitted, as Rod Serling ( The Twilight Zone ) would say, not “for your                                                                                                                     
                         
                               
                                 ix
                      
  
   
This PDF sold to Ethan Womack - dudeinwrens@gmail.com  Transaction: 7960

  
   
       Preface to Volume II
         approval,” but rather for your consideration. Do consider them carefully. For
      “If most of us remain ignorant of ourselves, it is because self-knowledge is
        painful and we prefer the pleasures of  illusion.'' ² 
                As so aptly put, in The Adornment of The Spiritual Marriage ,ᵌ “Knowledge
       of ourselves teaches us whence we come, where we are and whither we are
     going. We come from God and we are in exile.” You, the reader, are about to
    cross the event horizon of a ground-breaking work of singular s ignificance for      
     Earth and its inhabitants.  V oyagers  is, quite literally , a road map to the
      stars...and beyond. Inside these pages is truth , not re-veiled...but unveiled-
     stripped of the distortion, dogma and elitism still so pervasive within tradi-
    tional and contemporary works of higher calling. Voyagers  establishes a cos-
     mographic paradigm through which all others can be organized and uni fied,
    providing a most compelling and impressive body of information regarding
     the true origins of the human lineage, as well as our hidden (until now!) evo-
     lutionary destiny.  
            We stand on the threshold of the fulfillment of a covenant made a long
      time ago in “a special pre-existent place”—a place known to the Acoma as
       Ha Ku, to the Mayan as Hunab Ku—the Egyptian Ku, to the Lakotas’
          Peschla.
         To the Dorothy in each of us, the Emerald City of OZ, the heavenly
       Tula...Tara...Home. Prepare for a new level of revelation.
                                                  
      _____Philip L.Gruber
                Founder/Director,
                Quantum Access Group
      ________________________________
        1.  Giovanni Pico della Mirandola, Oration on the Dignity of  Man, trans. A. Robert Caponigri.
              Chicago: Gateway Editions, 1956.
         2.  Aldous Huxley, The Perennial Philosophy , 1944-1945 Harper and Row Perennial Library.
         3.  Jan Van Ruysbroeck, London 1916
       x

                    
      
                  Required Reading
                  
    The second edition of V olume ll of the  Voyagers  series has been vastly
enlarged so as to include much important, current information about what is
happening on Planet Earth, up to and including the tragic national events of
September ll, 2001, when hijacked airliners were intentionally crashed into
the World Trade Center and the Pentagon.  
                          
    To ensure that you have an appropriate understanding of this informa-
tion, it will be necessary for you to obtain and read, if you have not done so
already, the second edition of       Voyagers, Vo l u m e  I .  S e e  “ O r d e r i n g    i n f o r m a -
tion” on page 580. Specifically, the following bolded  sections of  V oyagers  I ,
second edition, are essential  to understand before proceeding : 
 *Introduction................................................................................................................... ........................ .ix 
 *The Azurite Temple of the Melchizedek Cloister, Inc (updated)...........................................xxxv
 *About the Author ...........................................................................................................................xxxvi
 *CDT-Plates, Emerald Covenant and the Mass Drama ...........................................................xliii
 *Administrative Levels of the Emerald Order Melchizedek Cloister........................................xlix
               The Yunasai..............................................................................................................................xlix
                Yanas.........................................................................................................................................xlix
               Breneau Order Founders Races ................................................................................... .............l
               Density-5 MC Eieyani Master Council ............................................................................ .... lii
               IAWF —Interdimensional Association of Free Worlds................................li
               Azurite Universal Templar Security Team............................................................................liii
               GA—Guardian Alliance .................................................................................................................... .liv 
l UFOs, Visitors, and the Interior Government.....................................................................................1  
2 Keylonta Science and Abduction...................................................................................................... .21 
3 Human Origins and Hybridization.............................................................................................. ......37
4 Hidden Motives and Mechanics................................................................................................. ......50 
     5 Awareness, Emotion, an Intuition.....................................................................................................74
6 Special Projects.. ............................................................................................................................... ................ 105
7 Levels of Identity and Components of Mind ...............................................................................134
*History, Motivation, Meaning and Message ………………………............158
             Guardians and Founders Races.................................................................................................158
                  The IAFW,  Azurite Security Team and the MC Eieyani Master Council…................162
                  The GA and the Angelic Human Lineage .............................................................................165
                  The 12 GA Signet Councils, Star Gate Security & Royal House Deception................ .167
             The 3 GA Signet Councils Of Etheric Matter Density-3(D7-8-9) ............... ..170
             GA Signet Council-6, Sirius B, Indigo Children & Christiac Grail Lines….............171
                 The Maharaji, Angelic Humans, Priests of Ur & Melchizedek Priesthoods.............175
                  The Final Conflict, Star Gate-6, Maji Priests of Azurline & Christ Drama................182
                                                                                                                                
           xi  

                                                                                                                 
                                                                                                                                                                                                                                                             1
                                   
                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                          
                 The Secrets of Amenti
                                                
              
                                                     AMENTI  TRANSMISSION 1998
                 Throughout Voyagers: The Sleeping Abductees  various speakers of the                                        
  Guardian Alliance have provided you with information pertinent to your times                        
and to the success of your species evolution. We have provided glimpses of your 
future, your distant past and what is taking place behind the scenes of your mul-                            
tidimensional present. All of this data is relevant to various peoples of your times, 
but there is information not yet addressed that is perhaps the most signif-           
icant of all, for it will provide you with the missing links of knowledge through 
which your past, present, and future can be united.  
    We of the Guardian Alliance have an announcement to make: lt is a mes-          
sage your species has waited over 800,000 years to hear. Our announcement  
will be made in later chapters of this book, for without the information con-            
tained here within, this announcement would have little meaning for you. In         
order for you to understand the importance of this message we must first pro-      
vide you with a sequential summary of the true history of your evolutionary     
journey. Within these missing passages of time lives the purpose and process of
your evolution as a people.  
    In previous chapters we have explored the beginnings of your species lin-        
eage beginning with the inception of your race as the Turaneusiams upon     
planet Tara in the Second Harmonic Universe, 560 million years ago. This is   
where your Earth drama began and the place to which you will eventually 
be led through the course of your evolutionary progression. To explore your                           
entire history from 560 million years ago to the present would require many    
books. Here we will simply provide you with the data most important to your 
understanding of the purposes for your present evolution.  
1
   


  
                                                                                                                                                                                                                                                                          
 
The Secrets of Amenti                    
                                                                                                                                                                                                                                                                                                                                             ORIGINS AND THE FALL                                                                                                           
                                                                 Origins—the First World —Tara                                                                                                                                               
              560,000,000 - 550,750,000 YA                                                              
            Approximately 560 million years ago (YA), upon the planet  Tara within  
       the Second Harmonic Universe), (your Earth is presently in the First Har-                                         
      monic Universe), many ET and metaterrestrial races combined their genetic          
             and energetic make-up to create a master race of beings that would serve as  
          Guardians of the planet T ara. The Sirian Council from Harmonic Universe       
    2, along with several other groups were appointed as directors and overseers 
       of the project, the Turaneusiam-1 (T -1) experiment. Metaterrestrials from         
     the Fourth and Fifth Harmonic Universes were the founders of this project,    
                working through a seed race called the Lyrans from the Third Harmonic
Universe. The Lyrans created a race of beings in Harmonic Universe 3 called   
the Elohim , who would become overseers for the Sirian races in Harmonic                  
universe 2.The Elohim became one of the numerous supervisory groups within 
the Turaneusiam-1 experiment, due to the Sirian race contribution of genetic 
      identity to the experiment.    
       The Turaneusiam race evolved for about eight million years on Tara, with      
    12 primary sub-racial divisions among them. Each of the 12 Turaneusiam sub-      
    races carried a genetic slant derived from the 12 primary contributors to the T-1   
    experiment, but all of them carried the unique l2-strand DNA  package the        
     T -1’ s were designed to embody . The 12 Turaneusiam sub-races were the Bra-   
  ha-man, Dhr-ah-men, Atoni, Trin-i-ten, Azurtan, Celtos, Addami, Yut-     
  arans, Luri, Cerrasz, Nezack-tai, and the  Melchizedakz . After evolving suc-   
   cesfully for many years the Turaneusiam race began to digress, their genetic    
   code breaking down and their cultures falling into disharmony. Manipulation    
   by and inter-breeding with various unrelated ET strains was the primary cause  
   of this digression. About eight million years into their evolution (552,000,000 
   YA) the Turaneusiam race divided into two primary racial strains, the Alanians  
  (sometimes referred to as the Beli-Kudyem ) and the Lumians  (frequently      
   called the Adami-Kudmon ). The two strains of Turaneusiam evolved together 
  on one large land-mass called E-Den, creating two cultures known as Alania   
 and Lumia.  Both cultures evolved on T ara for about one million years   
   (551,000,000 YA). Both races carried the original 12-strand DNA genetic code     
  of their Turaneusiam lineage, and both carried mutations and digressions of       
   that code from inter-stellar breeding. Cultural disturbances escalated along 
   with the continued digression of the Alanian and Lumian strains, and hostility
  arose as the Alanians sought dominion over the more passive Lumian culture.
     2 
  
          
     
            
   
                         

      
                                                                                                                 
                                                                                                                Origins and the Fall                                                            
                                        
                                             Mu, the Lumians, Ceres and the Priesthood of Mu                                                                                                  
550,750,000 - 550,700,000 YA
    Keeping a close eye on their Alanian antagonists, about 550,750,000 years
ago (YA) certain members of the Lumian race foresaw a cataclysm in their    
future, brought on by the increasingly dangerous Alanian experimentation   
with power generation through Tara’s planetary core. The Lumians petitioned    
assistance from the Harmonic Universe 2 (HU-2) Sirian Council and the HU-     
3 Elohim. Under direction of the Sirian Council, the Lumians set up amongst     
their members an organization called The Council of Mu.  Through the Coun-    
cil of Mu the Lumians moved large numbers of their race across the oceans, to a    
small continent on Tara that was primarily uninhabited by organized culture.     
They named this continent Mu, and for 50,000 years (550,750,000 YA to     
550,700,000 YA) the Lumians of Mu worked with the Sirian Council to redi-    
rect the genetic digression of their race. During this period the Elohim of HU-3    
interbred with Lumians who carried the Cerrasz Turaneusiam sub-race strain in
their gene codes, creating a race called the Ceres , which puri fied the genetic  
strain of the Lumians of  Tara. (Descendants of the Ceres later became known   
as the Seres , who interacted with HU-1 Earth humans at various periods.) The
Lumians and Ceres co-existed peacefully on Mu attending to the inter-galactic  
and spiritual business of the Council of Mu. The Ceres created the Priesthood     
of Mu , an egalitarian spiritual collective with a strong matriarchal slant whose 
practices centered around the teachings of the sacred Law of One, or Unity
Consciousness. The Mu priesthood exists to this day and is a primary motivat-  
ing force within certain Taran communities. The community of Mu continued 
its evolution through the re-aligned 12-strand DNA gene code until about 550   
   million years ago.                                                                                                             
                                      Alania, Templar Solar Initiates & the Sirian Rebellion
                                                                 550,750,000 - 550,000,000 YA
    Throughout the evolution of Mu digression continued within the Ala-    
nian race and anti-Lumian sentiment ran high within the power hungry Ala-   
nian elite. The Alanians employed subterranean grid technologies in hopes       
of bringing the now bountiful continent of Mu under Alanian domain. The    
Lumians and the Ceres foresaw the cataclysm of Tara that would result from    
          these technologies about 900 years prior to the events. The Ceres tried to     
warn the Alanians to no avail. Petitions to the Sirian Council to redirect the     
Alanians had failed, giving rise to the Alanian rebellion and Lumian-Sirian    
resistance. The Alanians were controlled by an elite group called the Tem-     
plar Solar Initiates, who had been entrusted with rulership and guardianship       
over the Alanian continent by the Sirian Council. The Templar Solar Ini-      
3 
                                                                                                                      

                      
                                                                                                                        
                                                                                                                                                                                                                                                          
                        
                      
                    
                The Secrets of Amenti       
     tiates became sympathetic with the Sirian root race Anunnaki in their Sirian 
     rebellion against the Sirian Council and refused to follow dictates of the Sir-    
     ian Council and advisory Elohim (who based their decisions on the teachings     
     of the Sacred Law of One). Through the Templar Solar Initiates the power 
     struggle between Sirian Anunnaki and Elohim/Sirian Council-loyal Sirian    
     “blues” (another Sirian root race) was brought to Tara. This period in Ala-     
      nian history is known as the Sirian Rebellion, and through this power strug-   
        gle planet Tara was almost destroyed.  
                                                        Ur-Tarranates, Mu and the Priesthood of Ur
                                                                          550,750,000 - 550,000,000 YA
     Certain groups of Alanians became aware that the T emplar Solar Ini-                  
tiates were misusing power in a way that would result in the implosion of     
Tara’s planetary grid. This group of Alanians approached the Lumians and     
Ceres of Mu, asking for assistance and many of them defected to the territo-      
ries of Mu. The Ceres interbred with these Alanians, (primarily those carry-       
ing the Yutaran Turaneusiam sub-race genetic line) re-aligning their       
digressing genetic code, and these Alanians further interbred with the Lumi-      
ans. The original Turaneusiam 12-strand DNA gene code was rebuilt and   
purified through this Ceres-Lumian-Alanian blend. This re-vitalized Turane-    
usiam race became known as the Ur-Tarranates . The Ur-Tarranates created 
the Temple and Priesthood of Ur  upon the continent of Mu. The Priesthood   
of Ur shared most practices of the Priests of Mu, but developed interest in
more scientific applications of Spiritual Law (such as portal mechanics). Like
the Priesthood of Mu, the Priests of Ur exist on Tara to this day, and they  
serve as Guardians and gatekeepers of the time portal structures that link 
Earth to present day Tara.  
               During the Sirian Rebellion on T ara the Priesthood of Ur stood against
          the Templar Solar Initiates of Alania, eventually retreating underground 
             with the people of Mu, unable to stop the Templars from misusing the power  
           of the planetary core. Small wars within the local galactic sectors were fought
           during these times, which became known as the Taran Wars. Under direction     
              of the Sirian Council and Elohim, the Priests of Ur began to prepare for the   
           pending grid implosion. Many people were evacuated to other sympathetic   
               star systems, where they evolved, safely intermingling with other races.  
             
               
               4

                                                                                                                                                                                                   
                                                                                                              Origins and the Fall             
                                                            
                                                                  Cataclysm of Tara
                                                                           550,000,000 YA
                         Approximately 550 million years ago the Power-generator Crystals deep
        underground in Alania exploded, due to the Templar Solar Initiates’ misuse of 
           power from Tara’s planetary core. This created a chain reaction of implosions 
          within Tara’s planetary grid. Portions of Tara’s grid were blown apart and frag-
      mented, becoming detached from the Morphogenetic Field  of the planet. Por-
       tions of Alania were immediately destroyed and the entire planet suffered the 
       effects of rapid pole reversal. For a period of two days Tara ceased to rotate on
      its axis. It took 10,000 years to re-stabilize T ara’ s environment, during which
       time the few surviving Taran races still on-planet retreated permanently under-
       ground. Descendants of those civilizations who survived this disaster still ﬂour- 
         ish within elaborate underground communities. Surface life also returned to
             T ara following this 10,000 year period of healing. Because portions of the
       planet’s energy structures had been ripped from the main planetary grid, planet 
       T ara could not continue its evolution of dimensional ascension into the Third
        Harmonic Universe. T ara could not re-emerge with the energy grid of its
              dimension-7 counterpart Gaia, until its own grid system was repaired. T ara 
                          became trapped in the tracks of time within the Second Harmonic Universe .                           
                      
                                        The Fall to  Harmonic Universe-1 and the 12 Planets
                                                                        550,000,000 YA
                  The fragments of the Taran planetary grid that became dismembered from 
    T ara’ s core energy supply rapidly fell in vibration until they could no longer
      resist the natural magnetic pull of the descending lnterdimensional energy cur-
      rents. The planet fragments were pulled into a sun within T ara’ s universe,
      vaporized, and the morphogenetic field carried in those fragments was pulled 
     into a black hole at the center of this sun¹ and re-emerged into a galaxy within
     the lower-dimensional fields of Harmonic Universe 1. Entering this system as 
     gaseous substance, this morphogenetic field broke down into 12 pieces, which 
      set up a “mini-solar system” around a star within an already existing HU-1 solar 
        system. One of the 12 pieces of Tara’s fragmented morphogenetic field fused 
         with this sun, while the 11 other pieces began to build up matter density and 
     re-manifest their forms through their portion of the morphogenetic field. These 
     planets did not birth into existence in the usual accretion fashion, for they car-
     ried with them the organizational imprint of part of T ara’ s planetary grid mor-
           phogentic field. These planets did not birth into Harmonic Universe 1, they 
     fell into it, literally. Their original morphogenetic field fell in vibration, reorga-
                         _____________________
                                 1.  All suns have sets of black and white holes at their core; they operate as portals through                                                                         
            which energy can pass through dimensional fields.                                                                                  
                             5                                                                                                                        
                       

                                                                                                                                                                                                                                                                                                                                The Secrets of Amenti
              
  
   nized through the morphogenetic field of a star, and re-manifested within 
    a slower vibrating dimensional scale. The 12 new planets entering HU-1 55
    million years ago are the planets of your local solar system —Mercury, Venus,                    
 Earth, Mars, Maldak  (imploded to become the asteroid belt), Jupiter, Saturn,
   Uranus, Neptune, Pluto, Nibiru  (very long orbit, not yet discovered by Earth
  scientists), and your Sun (the part of Tara’s morphogenetic field that fused with
  this already existing, non-Taran sun). The fragments of Tara became part of the 
 Unified Field morphogenetic structure of Harmonic Universe 1.                       
                    
                                                   The Fall of Man and the Lost Souls of Alania
                                                                            550,000,000 YA
       The    event    of     Tara’s     cataclysm  became   known   as   the    “  fall     of    man.”   This    his-
tory beca me interwoven with other events on Earth that occurred since that 
time, appearing in various forms throughout human mythology. The Adam and
Eve drama of Biblical stories combined this event as the fall from God’s grace 
and removal from the Garden of Eden, with other earthly events, including the
Drakon in filtration of around one million years ago. The stories became a 
depiction of multilevel events from various time periods, woven together into a
symbolic event portrayed in the stories. This was also done in relation to the
Biblical Flood and Noah. The consciousness of the beings who were blown
apart in Tara’s fall, also fell into HU-1. They became ripped from their race
morphogenetic field at Tara’s core and disengaged from their original soul 
matrices through which they needed to evolve in order to pass out of the Time
Matrix and dimensionalized systems, and return to Source as pure conscious-
ness. The souls of Alania became trapped in time, fragmented as units of con-
sciousness within the Uni fied Field of HU-1, and there they would have 
remained if a rescue mission had not been orchestrated.                                              
                                 
                                                           AMENTI RESCUE MISSION
                                           The Covenant of Palaidor and the Palaidorians of Tara
                                                                            550,000,000 YA
              Just prior to the cataclysm on Tara 550 million years ago the Ceres, Ur-Tar-      
      ranates and Lumians of Mu devised a plan to rescue the Taran souls that would          
be lost in HU-l during the approaching disaster. Being skilled at time portal    
mechanics and lnterdimensional portal travel, the Ceres created a plan that
the Ur-Tarranates would ful fill. With the assistance of the Sirian Council, Elo-                  
him, and HU-2 Pleiadians, the Ur-Tarranates formed an agreement with sev-   
eral other HU-2 races called The Covenant of Palaidor.  Through the    
Covenant of Palaidor a rescue mission for the Taran souls of HU-1 was set in 
motion. Those involved in this agreement (the Sirians, Pleiadians, Ur-Tarran-
ates, Elohim, Lyrans, Ceres, Lumians and Alanians) became known as the 
6           
                    
                    
                                                                                                                                                                                                                                                                                                            
                                                                                     

  
                     
                        Amenti Rescue Mission
Palaidorians.  W orking through the Breneau Rishi (beings of pure conscious-
ness) from HU-5, the Palaidorians petitioned further assistance from an entity 
gestalt within the Metagalactic Core; this entity is known as Ra, or the Ra
Confederacy.  Of the 12 primary identity gestalts within the Ra Confederacy ,
members of its four largest gestalts became involved and allowed for the rescue 
mission to take place. The four primary members of the Ra Confederacy 
involved within the Covenant of Palaidor are the Azurites, Aton-a, Amonites
and the Brigijhidett  (a sub-group of the Brigijhidett are presently incarnating 
in your Earth system as members of the ascended masters family of Viragi . Sev-
eral other groups associated with these three gestalts are also involved with 
Earth at this time, including the consciousness gestalt Azar-Azara  and a HU-2  
ET race known as the Zhar Confederacy ).                                                               
           Time Travel and the Sphere of Amenti
                                                                                  550,000,000 YA    pre-cataclysmic Tara
            Using lnterdimensional portal mechanics, the Ur-Tarranates of the Cov-  
           enant of Palaidor time-traveled into HU-1 to a time/space coordinate posi-    
       tioned just after the cataclysm of Tara and the fall of man. Once on Earth,      
          with the help of the Sirian Council, this group of Ur-T arranates transmuted
    their body forms into pure energy (Keylontic science) and merged into a     
   gestalt energy field of consciousness, which served as a morphogenetic field   
         or the 12-strand DNA Turaneusiam race prototype. Also contained within       
    this morphogenetic field were the Keylontic Time Codes (electrotonal fre- 
           quency patterns) of the pre-cataclysmic time/space coordinates of Tara,       
   which would allow T ara to re-assemble the lost portions of its grid into the   
  fabric of time. With the assistance of the Ra Confederacy this gestalt of con-
   sciousness/genetic and planetary morphogenetic field was entered into the 
       remaining morphogenetic field of Earth through the 11th and 14th dimen-   
      sions. This morphogenetic field of consciousness energetically took on the    
  shape of a sphere, and was called the Sphere of Amenti , named after the por-
  tion of T ara’ s morphogenetic field that contained the imprint for Mu and its
   inhabitants. Amenti was the part of Tara’s planetary core that connected 
                energetically to the portals upon the continent of Mu.   
            By placing the Sphere of Amenti within the Earth core, a “worm hole” or 
  portal link was established between Earth’ s core in dimension two and T ara's 
   core in dimension 5. Though numerous other portals between Earth and T ara 
    existed, these had become unstable and their operations unpredictable fol- 
     lowing the fall. The Sphere of Amenti would create a stable portal structure    
      that, once operational, would stabilize the other portals and allow open tran-              
       sit between Earth and T ara for beings possessing genetic codes that could
          
            
           7                                                                                                                   
                                 

    
                     
                      The Secrets of Amenti
endure portal transit. The Sphere of Amenti would link into the space/time         
of Tara's pre-fall past. With this sphere placed within the Earth as Earth re-    
evolved through dimensional ascension back into the Tara grid following the    
morphogenetic imprint from the sphere, a link between the future Tara and    
its pre-cataclysmic past would be reestablished. Tara's past would be re-        
attached to the Time Matrix grid and Tara's future time cycles. Through the    
Sphere of Amenti a bridge was constructed between Tara's pre-cataclysmic    
past and future tracks/cycles of time.            
       When a planet undergoes such a trauma, having a portion of its grid blown    
apart, not only does it lose the portions of its evolutionary history stored within    
the cellular memory of the parts that blew apart, it also loses a portion of its    
energetic thrust. Without this thrust the planet cannot evolve out of its Har-    
monic Universe and into the next. The planet, and most life forms on it,     
become trapped in the fabric of time. The Sphere of Amenti not only gave    
hope for the continued evolution of human/Turaneusiam lineage, it held the    
hopes of ascension and continued evolution for Earth, Tara and their seventh-   
dimensional counterpart Gaia. lf one was trapped in time, they would all be    
trapped. The only other option available in such cases of planetary morphoge-   
netic field fragmentation is that of a Host Matrix Transplant (as previously dis-    
cussed in relation to people), and this is exceedingly difficult  to achieve on a    
planetary level. Each of the 12 planets in HU-1 that emerged as a result of      
Tara's fragmentation received a similar morphogenetic sphere from the    
Palaidorians to ful fill the same purpose. But here we are only concerned with    
the Sphere of Amenti, as through it Earth became an ascension planet,  able to    
achieve dimensional ascension through re-evolution.                                                                   
                                
                                                The Sphere of Amenti and Soul Ascension
                                                                Rescue Mission from Tara
                                                                550,000,000 —250,000,000 YA
                             Th e Sphere of Amenti was entered into Earth's core within the second-     
                       dimensional frequency bands (often called the “ Cave of Creation ”) about     
                        550 million years ago from a position in HU-2 space/time that existed before
                  the Earth existed within that HU-2 time track. The rescue mission for Tara's          
                     lost souls was begun before those souls became lost, in terms of linear time.    
                             Such things are quite practical within the structure of the Time Matrix.
                        Through the Covenant of Palaidor and the Sphere of Amenti the souls of                                                                                                                        
             Earth could re-evolve back into their original 12-strand DNA body type. 
                        This process can be viewed as the Palaidorians creating new bodies (and mor-
                        phogenetic blueprints) for the now formless consciousness fragments of the                    
              fallen souls. The Sphere of Amenti morphogenetic Field allowed for the Ur-  
                      
                        8
                                 
          

                                                                                                                 The Halls of Amenti                                                                                                                               
                                                           
           Tarranates to enter incarnational cycles on Earth, pick up the fragments of                      
              consciousness from the lost souls by pulling their energetic particles from the 
 HU-1 Uni fied Fields into the DNA, merging the consciousness of the soul 
 fragments with the embodied Ur-Tarranate consciousness, thereby allowing 
 this composite identity to evolve through a sentient life form, back into its 
 original soul matrix (the Turaneusiam 12-strand prototype).                              
     This evolutionary plan was not immediately set in motion. Though the
 Sphere of Amenti was set within Earth’ s morphogenetic field nearly 550 mil-
 lion years ago, the Earth grid had to evolve and pick up grid speed before the 
 Sphere of Amenti could begin birthing its new races. Between 250 and 550
 million years ago various other species seeded by HU-1 ET Visitors evolved  
 on Earth, some of whom became members of your plant, animal and insect 
      kingdoms. Various groups of etheric beings (without matter density) also   
 spent time on your planet. The races of the Sphere of Amenti finally began to 
 appear on Earth about 250 million years ago. Before their appearance more 
 inter-galactic wars were fought by races who did not want the Covenant of 
 Palaidor to be ful filled. These wars were primarily fought on Tara, becoming 
   part of a long history of confrontations that were simply termed the Taran   
  W ars. Once the Earth territory was secured the Ur-T arranates of the Sphere   
 of Amenti began birthing on Earth. This began what came to be known as   
 the Turaneusiam-2  or T-2 experiment. This represented the seeding of the      
 12 Tribes  out of which your present human lineage has emerged.                               
                                                                                                          THE  HALLS OF AMENTI
                                                The Cloistered Races of Parallel Earth—
                                               the Second World—Rescue Mission Stage 1
                                                                2 50,000,000-25,000,000 YA
          From the Sphere of Amenti five smaller spheres were created, which    
    became the morphogenetic patterns for five races known as the Cloistered                
  Races.  Collectively the five Cloistered Races were called the Palaidorians, as   
    they represented the beginning of the ful fillment of the Covenant of        
    Palaidor . They represented the Earthly counterparts to the larger Palaidorian
   group from HU-2. Of the original Turaneusiam-1 12-strand DNA package,  
 each Palaidorian race held the morphogenetic imprint for DNA  strands 7-12
   (which held the electro-tonal frequencies corresponding to dimensions 7-
   12), plus the imprint for strand l, and each of the five groups carried the 
 imprint for one additional DNA strand corresponding to dimensions 2,3,4,5                            
       and  6    . The Cloisters served as “Guardians” for  the  evolution  of  the  additional
    9 
                                                                                                                      

                    
                     The Secrets of Amenti
 DNA  strand to which they were assigned. Each race had eight strands of
 DNA  manifest within the body structure. The five Cloistered races did not
 possess gender, nor did they originally possess the degree of matter density
  with which you are familiar. Density of form developed over time throughout
   the course of their evolution on Earth, between 250 million and 25 million
 years ago. The five Cloistered Races were:  
 1. Ur-Antrians —brown skinned-strand #2  
 2. Breanoua— red skinned-strand #3  
 3. Hibiru —white skinned-strand #4  
 4. Melchizedeks —yellow skinned-strand #5  
 5. Yunaseti —black skinned-strand #6  
           The Cloistered races populated the Earth for many generations, creating
   various racial mixtures through which many of the lost souls of T ara were able
 to ascend. This period of great civilization became known as the Second
    W orld (250-25 million years ago) within your present Native American Cul-
 tures. Many of these souls ascended. Those who digressed returned to the
  Sphere of Amenti to re-birth on Earth in the particle universe as members of
  the Root Races. The First World represented the original Turaneusiam cul-
         tures of T ara (560-550 million Y A). The Palaidorian Cloister races left no
        remnants in your present world, for they evolved within the faster moving
        time bands of Earth, within the anti-particle universe. The morphogenetic
          fields of those races were then drawn into your particle-Earth and out of these
  came the next evolutionary stage.                  
                                    The First and Second Etheric Root Races of Gaia
                                                             Rescue Mission Stage 2
                                                           25,000,000-20,000,000 YA
     Before manifestation into embodiment on your Earth the five Cloistered
          races divided into two groups. One group held the DNA  imprint for 1/2 of
  the first strand of DNA (which corresponded to dimension-one frequencies),
 the other group held the remaining 1/2 of the first strand. This created polar-
 ization and gender within the Cloistered Race morphogenetic field. Both
 groups held the dimensional codes/strands of 7-12. These two groups were
 seeded on Gaia, the seventh-dimensional/HU-3 counterpart to T ara and
    Earth. These two races were the first two Root Races,  the Polarians of Gaia
    and the Hyperborneans  of Gaia’ s antiparticle double. These beings were of a
  much less dense, or “etheric” nature, but through their evolution on Gaia (25
  
  10                 

                                                                                                           
                                                                                                          
                                                                                                            The Halls of Amenti
-20 million YA) the pathways of evolution through dimensional ascension
were reopened for the lost souls of Tara.  
    These races anchored the morphogenetic fields of dimensions 7-12 into
dimension one and Earth. Through their evolution, the one strand of the 12-
strand DNA package was pulled together in Earth particles and connected to
the Turaneusiam morphogenetic field.                                                       
                                                                                  The Halls of Amenti—Rescue Mission Stage 3
                                                                   25,000,000 YA
     The morphogenetic consciousness of the five Cloistered Races held within
the Sphere of Amenti began the third stage of seeding humans on Earth 25
million years ago. They opened the Sphere of Amenti within the Earth Core in
dimension 2, which opened a portal bridge to Tara’s core in dimension 5, a por-
tal that linked the Earth of 25 million years ago with pre-cataclysmic Tara of
550 million years ago. Working with the Priesthoods of Ur and Mu on Tara, the
consciousness of the five Cloistered races created five other portal bridge exten-
sions from the center of the Sphere of Amenti, each of the five opening into
dimensional fields 2 through 6. Dimensional fields represent positions in space/
time within the Time Matrix, stages a planet or being will pass through in its
evolutionary progression of dimensional ascension. The six portals  from the
Sphere of Amenti  (the original one to Tara’s past and five new ones into various
stages of Earth’s future ) linked Tara’ s past, through various time periods on Earth,
into Tara’ s future, creating a new track in time through which Earth could re-evolve
into the ﬁfth-dimensional frequency bands and merge with Tara . Once this merger
was accomplished Earth would become Tara, new lands would open up within
and emerge upon Earth, and Tara would reclaim the energetic thrust lost in the
fall so evolution into the seventh-dimensional Gaia could continue.  
    The six portals in the Sphere of Amenti also allowed the five Cloistered
races to incarnate into dimensional bands/time fields 2 through 6, pulling into
their consciousness and body forms the fragmented consciousness of the lost
souls from each of those dimensional bands. The time codes (frequency pat-
terns) from the first dimensional strand of DNA that had been built up through
Root Races one and two would link into the frequencies of dimensions 2
through 6. The consciousness within the Sphere of Amenti would leave the
morphogenetic field and express into manifestation as Root Races within each
of those dimensional bands, building up into the DNA pattern strands 2
through 6. Through this pattern of building DNA through time, incarnates
within each time period/dimensional band would be able to pull together the
frequencies  of  their  dimensional strand (through a series of  24  incarnations/two
12-cycles), link with the morphogenetic field of their Cloistered Race, pick up
strands 7-12 from the Cloister, pass through the other Cloisters and pick  up  the
11 
                                                                                                                         

                                                                                                                             
          
               
                 The Secrets of Amenti
remai ning Root Race Strands, re-bundling the 12-strand DNA package. As the
 12 DNA strands were assembled, the body form of the incarnate would progres-
               s ively transmute into a less dense state and ascend into HU-2 on Tara. Origi-
   nally only one Ea rth body was needed for this process, as the form would
               assemble the DNA patterns within the two 12-cycles in one very long lifetime
 and then transmute and ascend.  
    The ascension occurred through the portal from the Sphere of Amenti to
which the incarnate’s dimensional band/time period was connected. Once
passing through its dimensional portal into the Sphere of Amenti, the incar-
nate could enter one of the other portal bridges, and appear on Tara in a
future space/time coordinate, becoming free from HU-1. Through this pro-
cess the consciousness of Tara’s fragmented parts would be returned to Tara’s
planetary grid piece by piece, progressively de-densifying the matter particles
of Earth and transmuting them back into Tara’s grid. As the lost souls
returned to Tara, so did the lost portions of Tara’s morphogenetic field.
         Though the dynamics of this process are complicated, the principle is sim-
ple. The portals within  the  Sphere of Amenti served as a time-portal structure through
which the lost substance/energetic thrust of Tara could be returned, and the lost souls
of  Tara could return to their original identity as souls incarnated upon the planet Tara.
In ancient Taran history this planet had once, long ago (eons before the 560
million year ago Turaneusiam seeding) been located within the First Harmonic
Universe, and had successfully evolved into the fifth dimension and Second
Harmonic Universe. The fall represented a portion of Tara being thrown back
into its own past, through which it had to re-evolve in order for the planet to
evolve into its natural future. The portals within the Sphere of Amenti operated as a
warp in time through which re-evolution could take place more quickly . The human
lineage is an intimate part of that re-evolutionary plan, and this plan is the
underlying hidden dynamic and purpose for present human evolution. This
plan is part of a larger Taran/Gaian evolutionary plan which ultimately will
lead to all consciousness involved returning to its Source.  
         The Sphere of Amenti contains the purposes and mechanics of humanity’ s
evolutionary blueprint. The time portal structures within the Sphere of
Amenti regulate the processes of humanity’s dimensional ascension/evolution
or “return to God.” The portals within the morphogenetic field of the Sphere of
Amenti are known as the Halls of Amenti . They are the dimensional passage
ways one must pass through in order to ascend from Earth, out of the Time Matrix
and dimensionalized reality.  The Halls of Amenti have been a closely guarded
secret since the time of your inception on Earth, and the Priests of Ur and Mu,
their earthly descendants and the ET and metaterrestrial ancestors of your
Turaneusiam lineage from Harmonic Universes two through five have been the
Guardians of this secret since the time of its inception 550 million years ago.                       
                                                                                           12
           
                 

                                                                                   
                                                                                                              
                                                                                                              The Halls of Amenti
                                       The Staff of Amenti Blue Flame Morphogenetic Field
                                                                The Ivory Gates of Tara
                                                                          25,000,000 YA  
        
     Once the Halls of Amenti were created 25 million years ago, the priests
   of Ur on T ara drew out from T ara's fifth-dimensional core a pattern of fre-
       quency that represented the morphogenetic field for the entire planetary grid
      structure. They removed from T ara the morphogenetic field through which
    T ara drew its energy imprint for its grid line structure and matter form. By
    removing this form-holding energy field from Tara's core, Tara could no
    longer build a bridge of frequency between its core and Gaia's core at the
   eighth-dimension Metagalactic core. This removal of T ara's interior morpho-
  genetic field was done out of necessity. If the morphogenetic field had
 remained within T ara's core, T ara's progression of dimensional ascension into
   the Third Harmonic Universe would have continued, up to a point. When
  the planetary grid of T ara had pulled in the remaining frequency bands from
  the Uni fied Fields of dimensions 5 and 6, through the morphogenetic field at
 its core, it would next begin to pull in the frequencies of the seventh dimen-
  sion and begin its ascent into the Gaian planetary grid structure. This is the
 natural path of evolution for a planet. However, if the seventh-dimensional
 frequency bands entered and expanded T ara's morphogenetic field, certain
 portions of these frequencies could not plug into the grid lines of the planet
 as they needed to do, because portions of these grid lines had been ripped
  apart during the fall event.  
     The energy carrying the frequencies of D-7 that could not pass into the
 framework of the planet's energetic structure would build up within the mor-
 phogenetic field of Tara's core, eventually causing the entire grid system and
 the planet to explode. The morphogenetic field of Tara had to be temporarily
 removed from the planet's core, which would leave T ara with the ability to
 draw energy through its grid from the Uni fied Fields of Dimensions 4 through
 6, but would not allow any higher frequency energies to enter into its grid sys-
 tem. This meant that T ara would be trapped in the time bands of Harmonic
 Universe 2, unable to evolve out of those frequencies until its morphogenetic
  field had been returned to the planetary core. The planet had to remain con-
  nected to its morphogenetic field in order to retain its form, but the field could
     not be stored within the planet structure.  
     The morphogenetic field of Tara had to be placed within the portions of
   the original morphogenetic field that had been blown apart, broken down
    among the 12 HU-1 planets. Each of the 12 planets would hold a portion of
   T ara's morphogenetic field, and Tara could draw in sustaining energy from
  13  

   
    The Secrets of Amenti  
   each of those areas. Meanwhile, the other planets would process the dimen-
 sional frequency patterns that T ara could not synthesize. Once a HU-1 planet
 pulled in its portion of the higher dimensional frequencies, it would then
 undergo dimensional ascension back into T ara's grid, bringing with it its por-
 tion of the T aran morphogenetic field. Tara could not ascend to HU-3 and
 become Gaia until each of its HU-1 planets completed the manifestation of
 their portion of the morphogenetic field and ascended back into the Taran
 grid. (The time when this will occur is many millions of years in your future).
 But each planet in your solar system has its part to play in this program.
       Each planet received its portion of the T aran morphogenetic field. Earth
 received its portion 25 million years ago when the Halls of Amenti were con-
  structed.² The five Cloistered Races of the Sphere of Amenti retrieved their
  frequency pattern 25 million years ago. This pattern of energy/morphoge-
 netic field had the appearance of a standing wave pattern, composed of
 fourth- and fifth-dimensional frequencies, and thus appearing as blue in color.
 Visually , this standing wave pattern looks like an electric-blue ﬂame with a
 pale shade of green, several inches in height. The blue ﬂame, which consti-
 tutes Earth's portion of T ara's morphogenetic field, was brought into the
 Sphere of Amenti by the five Cloistered Races and the Priesthoods of Ur and
 Mu. The fifth-dimensional frequency patterns held in the blue ﬂame allowed
 for the Halls of Amenti to open so the seeding and evolution of the five
 remaining Root Races could begin on Earth. The ﬂame was stored within the
  Sphere of Amenti and as long as it was there the portals between Earth's
       dimensional time periods and T ara remained opened. The souls of Earth
  could ascend out of HU-1 incarnational cycles and continue their evolution
  through Tara.  
        The Blue Flame became known as the Staff of Amenti  which is the item
   referred to in your Bible as the Staff of God, of the “rod and the staff.” The rod
  represents the standing wave pattern within Earth's core in dimension 2,
  orange-gold in color, and composed of the frequency patterns of dimensions 1,
   2 and 3. The Blue Flame Staff of Amenti was composed of frequency patterns
   of dimensions 4, 5 and 6, and allowed T ara's morphogenetic field to link with
   the double ﬂame at Gaia's core, the violet and pale-gold ﬂames that would
         allow   Gaia   to    link  with   the   white-gold     ﬂame   of      the   Metagalactic   core. When     we
      speak of the colored ﬂames we are referring to multiple bands of frequency of which
                 morphogenetic ﬁelds are composed. Colors represent spectra of light and light repre-
                    
                      _________________________
                        2.    The other planets had undergone a similar Sphere and Halls creation at various other
                                      times, each set being named after the portion of the morphogenetic field it carried.
                          14

                                                                                        
                                                                                  Root Races - Cloistered Races  
  sents the manifestation of patterns of dimensionalized electro-tonal frequency.
Through linking the frequency bands of dimensions 1 through 7 within the
morphogenetic field, a planet or a person can ascend/evolve out of the matter
based systems and into pure sentient consciousness. This is the evolutionary
process. So the Blue Flame Staff of Amenti, stored within the time warp mor-
phogenetic field of the Sphere of Amenti, represents the key to the evolution
of Earth, and the human lineage, and one of the keys to the evolution of the
planets in your solar system, Tara and Gaia.  The Staff of Amenti is the gateway
into Tara's morphogenetic ﬁeld.  Whether the Staff is held within Tara's core or
within the Sphere of Amenti at Earth's core, it represents the gateway to which
the Halls of Amenti lead. One can pass into the Halls of Amenti, but must pass
through the Blue Flame in order to transmute form and appear on Tara. In later
Egyptian mystery schools the Blue Flame gateway became known as the Gates
of lvory, which became translated in Biblical terms as the Pearly Gates of
Heaven.  In each case the writings referred to the Blue Flame Staff of Amenti,
the energetic gateway to Tara. Needless to say, the Sphere of Amenti and the
Staff which allows the Halls of Amenti to open into Tara are quite valuable
commodities. Every human on Earth now is in some way energetically con-
nected to the race morphogenetic field within the Sphere of Amenti, and it is
through the Halls of Amenti (or through the Taran morphogenetic Sphere
within one of the other 11 planets in your solar system) that you must ascend to
fulfill your evolutionary imprint as souls and return to your Creator/Creative
Source.                                                                        ROOT RACES - CLOISTERED RACES                                    F orming of the five physical Root Races and their Cloisters  
                             Blue Print For Evolution Through DNA Assembly  
                                                    Rescue Mission Stage 4  
                                                             25,000,000 YA                       
    After the Staff of Amenti was set within the Sphere of Amenti at Earth's
D-2 core, the forming of the five remaining Root Races began. The five Clois-
tered Races within the morphogenetic field of the Sphere polarized, splitting
their energy fields, each creating two smaller morphogenetic fields within the
Sphere of Amenti. The 10 new spheres collectively held the blueprint for
DNA strands one through 12. Each of the five Cloistered races was responsible
for the evolution of one pair of these new morphogenetic fields. Each sphere
became the morphogenetic field for one Root Race plus its companion Cloister
Race that would simultaneously manifest into physical expression on Earth,
during the time periods that corresponded to the dimensional DNA strand to
which each race was appointed. These five morphogenetic fields became Root
 Races 3—7, through which DNA strands 2—6 would be assembled.  
 15                  

             
             The Secrets of Amenti  
  Each Root Race was responsible for evolving/assembling one strand of
DNA while its companion Cloister Race would hold the imprint of that
strand plus strands 7 —l2. The Cloister Race would appear first and through
this race its Root Race would emerge. The Cloistered Race broke down into
five Cloistered Sub-races, and each sub-race further broke down into five
Cloistered families. The Root Race would then break down into seven sub-
races, and each of the seven sub-races would further break down into seven
families. Soul fragments from the dimension that corresponded to the DNA
strand of the Root Race would be pulled from the Uni fied Field of that
dimension into the body form, progressively pulling the frequency bands of
that dimension into the DNA until all the frequencies of that dimension
were assembled into the morphogenetic field of the body. This process was to
be accomplished within 24 incarnations, i.e., two l2-cycles, that were lived
in one body. With the morphogenetic field in the Sphere of Amenti holding
the pattern for the body form, souls trapped within that dimension could
begin merging their consciousness with the new body form, and through 24
cycles of incarnation pull their consciousness into a pattern that vibrated
high enough to merge with the Sphere of Amenti.  
               Soul fragments would incarnate once then transmute through each of the
seven families of its sub-race, then through each of the five Cloistered fami-
lies of its Cloistered sub-race, building up the lower frequency patterns (base
tones) of that dimension into the DNA through its first 12 transmutations
within the families. Next the now-more-evolved soul would transmute into
each of the seven sub-races of its Root Race, then into each of the five Clois-
tered sub-races of its Cloistered Race, building up the higher frequency pat-
terns (overtones) of that dimension into the DNA. In the final
transmutation, in which all of the frequency patterns for that dimension were
pulled into the DNA and the completed strand assembled, the incarnate
then carried the full base tone pattern of its Root Race and the particle over-
tones of its Cloistered Race within the DNA. In this final phase, the incar-
nate's body, DNA and consciousness would transmute, the base tones and
overtones within the DNA strand merging to create a resonant tone through
which the identity could merge with the Cloister Race morphogenetic field
in the Sphere of Amenti, where it would pick up the remaining “activation”
DNA codes/overtones from the Cloister.  
         The Cloister Race held the higher frequency DNA  codes/overtones for
         that dimension, which match the base tone frequency patterns of the body
 double in the parallel Earth (these are called the Activation Codes, as they
              16 
             
    

                                                                   
                                                        Root Races - Cloistered Races
allow the DNA particles to merge with their anti-particles, creating transmu-
tation of the matter particles and anti-particles, through which DNA strands
7—12 could “plug into” the operating genetic code.)  
   The Root Race held the lower frequency base tone codes of this Earth.
Once both sets of DNA codes were assembled in the DNA through the 24
transmutations, the overtone activation codes from the Cloister would allow
the incarnate to enter its Cloister's morphogenetic field within the Sphere of
Amenti, where DNA strands 7—12 would “plug into” the activation codes. This
would open the morphogenetic field of the Palaidorian collective ( five Clois-
tered Races), where the codes of the other Root Races could be assembled and
the full 12-strand DNA pattern would be restored. As this process of DNA
activation took place, the incarnate was enabled to enter the Blue Flame mor-
phogenetic field of Tara with its consciousness, which began activation of
DNA strands 7-l2 within the body. This process increased the rate of pulsation
of the matter particles of the body into HU-2 patterns, which allowed the
incarnate to turn its body into light, pass through the Halls of Amenti as pure
energy, then re-manifest within a less dense version of that body upon Tara.
The 24 transmutations were lived in one body, which progressively transmuted
as the DNA assembled, until later genetic distortion. Originally the human
body was designed to transmute and ascend, not die and reincarnate. The 24
cycles of transmutation later became 24 cycles of incarnation, or birth and
death, through which the DNA would assemble as the consciousness passed
from one life to another. The original human body was immortal.         
                                 The First Seeding-the Third World                                                                                                                                   25,000,000 to 5,500,000 YA                  
    The pattern for the evolution of the five remaining Root Races was set in
motion 25 million YA. In the first wave of souls moving out of the Palaidorian
morphogenetic field and into physical incarnation The Five Cloistered Races
were entered into Earth in various geographical locations on the Earth.
Through budding/ fission/replication the five Cloistered families each mani-
fested six male and six female beings on Earth, and the same number on the
   parallel, anti-particle Earth. So in the first wave of physical creation on Earth
   60 human beings were manifested, in adult form, out of the Cloistered Races
  morphogenetic field. Each of the five Cloistered Races began with a family of
  12 humans, six male, six female. They entered Earth together, with equal
  standing, seeding the brown- Ur-Antrian, red-Breanoua,  white- Hibiru,  yel-
   low- Melchizedek  and black- Yunaseti races. Earth populations built up through
 this lineage.  
  After about 10 million years of evolution (25-15 million YA) the Third
Root Race was entered through peoples of the Ur-Antrian Cloister. The Third
17 
                                                                                                                                             
                                                                                                                         
                     

              
             The Secrets of Amenti  
 Root Race, and first physical Root Race to appear on Earth were the Lumari-
 ans. They were a brown race that appeared about 15 million years ago, who
  were assigned to assembling the second strand of DNA. Following the Lumari-
 ans and their seven sub-races and 49 families was the Second infusion of the
 Breanoua Cloistered race and their five subraces and 25 families. They entered
 through the peoples of their first incarnational wave about 12 million years ago.
 Entering through the peoples of the Breanoua Cloister came the Fourth Root
 Race, the Alanians  and their sub-races and families. The Alanians appeared
 about nine million years ago, a red skinned race, who were responsible for
 assembling DNA strand #3. The five Cloister Races and the Lumarian and
  Alanian Root Races evolved together on Earth between 25 million to 5.5 mil-
 lion years ago, developing high culture and much diversification. Incarnates
 who kept the integrity of their genetic code transmuted through each of the
 races then ascended within their immortal bodies through the Halls of Amenti.
 This period in time is known as The First Seeding,  and represents  the Third
  World in Native American tradition.  
                                                           THE ELECTRIC WARS                     
                               The Electric Wars & Palaidorian Resistance Entity Wars
                                                                                                                  5,509,000 - 5,508,100 YA
       During the course of the First Seeding all went well as many soul frag-
 ments from HU-1 Earth successfully ascended through the Halls of Amenti
 back into Tara. But many members of the races from the First Seeding had
 also begun to digress through animal interbreeding and contact with HU-1
 ETs, some losing the ability of genetic transmutation and thus their immor-
 tality. About 5,509,000 years ago members of the Sirian-Anunnaki race from
 HU-2, along with several other groups of ETs and metaterrestrials from the
 higher Harmonic Universes wanted to stop the evolution of the earthly races
  and abandon the Turaneusiam-2/12 Tribes experiment, for fear that the
 mutating genetic code of the 12 Tribes would contaminate the races of Tara
 as they ascended through the Halls of Amenti. Many HU-2 species did not
 want the digressive human element to return to Tara, for they were already
 creating damage within the energetic systems of Earth, and those of Tara
needed protection from such activities. Numerous other groups simply
 wanted Earth territories for their own purposes. The Resistance groups began
 a war with the Elohim from HU-3, and those of the Covenant of Palaidor in
 HU-2. Entities of the higher Universes descended upon Earth, and great bat-
  tles of pure energy were fought in Earth's local galaxy and within Earth's
   atmosphere. These events became known as the Electric Wars.  The wars
 lasted around 900 years as Entities of these opposing groups battled for con-
 trol over Earth's natural portal system and the Sphere of  Amenti. The human
  races caught in this battle either ascended to Tara through the Halls of
            18
          
        

   
                                                                           
                                                                   The Electric Wars
Amenti or were relocated to other HU-1 planets with the help of the Elohim
and HU-2 Palaidorians. Those who lost their immortal genetic codes and did
not leave Earth perished, along with many animal life-forms, as Earth's plan-
etary environment was thrown into chaos. Earth would have been destroyed
if the Breneau from HU-5 had not intervened.                      
                                       T he Seal of Amenti and the End of the Electric Wars
                                                                              5,508,100 YA       
     The Breneau entities negotiated a treaty between these opposing fac-
tions. In the agreement the Root Races of Earth would be allowed to evolve,
but the Halls of Amenti —the portals between Earth and Tara —would be
sealed to humans until the mutations within the genetic code of Root Races
3 and 4, which had contaminated the morphogenetic fields, could be
reversed. ln terms of souls evolving out of HU-1, the sealing of the Halls of
Amenti meant that they could evolve into the morphogenetic field of their
Cloister Race and pick up DNA strands 7 —12, but they could not pass
through the Cloister morphogenetic field of their Root Race into the collec-
tive Palaidorian morphogenetic field where DNA strands of the other Root
Races, strands 4 —6 could be assembled. Without the imprint frequency pat-
terns of strands 4 —6, the incarnate soul could not plug strands 7-12 into the
operational genetic code.  The Halls of Amenti were sealed to the human lineage
by removing from the morphogenetic ﬁelds of the Third and Fourth Cloistered
Races, the activation codes/overtonesᵌ that would allow the particles and anti-par-
ticles of the body to merge, transmute and assemble strands 7 —12 into the opera-
tional DNA.  This morphogenetic alteration effectively sealed the particles of
the physical body out of the etheric body (anti-particle body), making the
final transmutation of Cloister overtone codes 7-12 impossible. This mani-
fested as an energetic block between the physical and etheric bodies within the
human bio-energetic auric ﬁeld, and a sealing out of the Primary D-1 overtones
within the base chakra of the human—an auric conﬁguration still carried today
within the contemporary human.  It also created perception of duality between
consciousness and body for those baring this genetic con figuration.
    Normally an incarnate would build up the DNA strand of its Root Race
then build up the activation strands from its Cloister Race, which would
allow it to pull strands 7-12 into manifestation from the Cloister morphoge-
netic field. The seventh strand (a primary base tone strand), which contained
the frequencies of all of the strands below it, would plug in to the single
strand assembled through the Cloister, then assemble all of the other Root
         ______________________________  
             3.   The frequency patterns that corresponded to their form double in the parallel universe.
                                                                                                                                                              
         19
                                                                                                                                             

   
     The Secrets of Amenti  
Race strands as their frequency patterns were contained within the seventh
strand. Once strands 1—7 were assembled an lnterdimensional resonant tone
(three resonant tones) was created. The body could then turn into light, pass
through the Blue Flame in the Sphere of Amenti and re-manifest on Tara,
where assembly of strands 8-12 would continue. By removing one of the acti-
vation code/overtone frequency patterns from the morphogenetic field of the
Cloister,4 the human incarnate could not plug in the seventh DNA strand,
which meant that the incarnate could not assemble the strands of the other
Root Races so it could transmute into light to pass through the Blue Flame.
Humans carrying this code distortion became trapped in their matter bodies
within HU-1, and the supply of transmuting energy available to the matter
body became finite as the DNA strands that would have fed the body with
higher frequency energies were no longer operational. When the body
reached its genetic capacity for assembling frequency, then the physical struc-
ture would begin to deteriorate as the consciousness was transferred back into
the morphogenetic field. 
    Following this morphogenetic distortion, the consciousness would birth
into its Root Race, complete the 12 family and 12 sub-race transmutation
cycles, then run into the genetic frequency block. The body would die and
the incarnate would pass into the morphogenetic field for its Cloister, then
have to rebirth into a body within the next Root Race. After completing the
transmutation cycles of the Fourth Root Race the incarnate would pass into
its Cloister's morphogenetic field, then have to wait until the Fifth Root
Race manifestation cycle had begun, before it could complete its final incar-
nation in the Aeiran Root Race and release the Seal of Amenti. Once assem-
bling the fourth DNA strand through the Fifth Root Race incarnation the
Seal of Amenti would release from DNA strand one and the activation
codes/overtones from the Fifth Cloister would plug in, assemble the fifth,
sixth and seventh strands creating an interdimensional resonant tone. Then
the body could turn into light, pass through the Blue Flame and re-manifest
on Tara to continue evolution. The Seal of Amenti made it necessary to
incarnate three times, once within Root Races 3, 4, and 5, in order to com-
plete the dimensional ascension process into HU-2. After the sealing of the
Halls of Amenti, the Sphere of Amenti at Earth's core became the collector
of souls awaiting rebirth into the Fifth Root Race through which the Seal of
Amenti would be lifted, so they could ascend and be set free.  
     Following the Electric W ars, the Third and Fourth Root Races would
have to be reseeded on Earth, and the new seeding would carry with it the
    ___________________________  
       4.     The six th sub-frequency band overtone of dimension one was removed from strand one.  
  
   20 
 
 

                                                                                                                The Electric Wars
Seal of Amenti. The Halls of Amenti were not in themselves sealed or
closed, they were only sealed to incarnates carrying the altered genetic strain.
Some ET hybrid strains of the humans in exile in other planetary systems,
who did not have the Seal of Amenti genetic distortion, returned to Earth
following the Electric Wars to pass through the Halls of Amenti. It was then
discovered that a much greater problem had occurred as a result of the Elec-
tric Wars.  
The Seal of Palaidor-Pole Tilt, Quick Freeze, Sphere of Amenti placed
  in D-4, lst Major Earth Flood, 5.5 Million Year-Old Wall in Time
                                   5,500,000 YA  
      Summary : As a result of damage from the Electric Wars the Elohim had to
place the Sphere of Amenti in D-4 creating a fourth-dimensional frequency
block within the second and third DNA strands, sealing Root Races 3 and 4
out of their morphogenetic field/soul matrices, creating build-up of soul frag-
ments in D-2, D-3 and D-4 that would have to integrate into Root Race 5 con-
sciousness. This created the subconscious mind D-2 emotional body which
would draw in elemental Lamanian/Lemurian-Root Race 3-soul fragments, a
D-3 egotistical mind that would draw in Alanian/Atlantean—Root Race 4-
soul fragments, and a D-4 astral mind-body that would draw in soul fragments
of Root Race three and four from the astral plane. Manifested as an extra D-4 fre-
quency pattern within the second and third DNA strands, a blockage within the sec-
ond and third chakras through which their energies could only merge through the fourth
chakra, and as an energetic barrier between the frequencies of the second, third and
fourth dimensions within the bio-energetic auric ﬁeld, this created separation between
the emotional, mental and astral identity aspects. Root Race 5 souls became
responsible for integrating the soul fragments of the Lamanians and Atlanians
of the Second Seeding and the Atlanteans and Lemurians of the Third Seed-
ing, which manifest as blockages within the second-emotional body, third-
mental body and fourth-astral body chakras and corresponding levels of the
auric field. Seal released through assembly of the fourth DNA strand and inte-
gration of soul fragments, which must occur before Seal of Amenti can release
from DNA strand one. Human consciousness lost awareness of its relationship
to Earth and the higher dimensions, and its species evolutionary memory, and
souls of Root Races and Cloisters from the Third and Fourth Races could only
evolve through the Fifth Root Race. Auric configuration remains in present
day human descendants of Root Races three and four and within Aryan Root
Race 5. The present Aryan Root Race is now responsible for integrating the
soul fragments of their Lamanian/Lemurian, and Ur-Antrian and Breanoua
Cloister ancestors from the Second and Third Seeding. The Aryan Root Race
is also responsible for integrating the anti-particle overtones omitted by the
21 
 
                                                                                                                               

         
        The Secrets of Amenti  
Seal of Amenti, which appear as a build-up of electrical particles within the
etheric body called  miasms , which distort the natural functioning of the chakra
system and accelerate the manifestation of physical disease. The Seal of Palaidor
must be released before the Seal of Amenti can release, both achieved by assembling
the full fourth DNA strand.  
  For a period of time following the end of the Electric Wars, Earth could
not sustain life. For over 4,000 years Earth was plagued by erratic weather
patterns, tectonic shifting and climatic anomalies. Earth experienced a slow,
partial pole reversal and tilted several degrees on its axis between 5,508,100
and 5,504,000 years ago, as a result of damage done to Earth's energetic grid
and portal systems during the Electric Wars. Numerous ET races visited the
planet during its more stable periods, some serving as Guardians over the
Sphere of Amenti. Various animal forms were again reseeded by visiting
races. Approximately 5,504,000 years ago a sudden, final shift in Earth's grid,
as its poles realigned, caused a “quick freeze” Ice Age  to occur, which wiped
out most life-forms on the planet except for some of those residing in deep
caverns beneath the seas. Following this shift the vibrational rate of Earth's
grid dropped swiftly and it could no longer hold the higher frequencies of the
Sphere of Amenti at its core. If the Sphere of Amenti were not removed, the
Earth would explode.  
  In order to avoid planetary destruction the Elohim of HU-3 and the Ra
Confederacy entity families detached the Sphere of Amenti morphogenetic
field from Earth's core in D-2, 5,500,000 years ago. It was placed in a secure
position in deep space within the fourth-dimensional frequency bands.
Because the Sphere was placed within the D-4 frequency bands, it acquired a
fourth-dimensional frequency seal, which meant that souls who had not yet assem-
bled their fourth strand of DNA could no longer merge with their Root Race mor-
phogenetic ﬁeld/soul matrix or that of their Cloister.  Root races 3 and 4, and their
Cloister Races, who were to be reseeded on Earth with the Seal of Amenti in
their genetic code, could not evolve to assemble the fourth strand, as this
strand was assembled through birthing through the Fifth Root Race. This
fourth-dimensional seal on the Sphere of Amenti became known as the Seal
of Palaidor , as it sealed the races out of their Palaidorian morphogenetic field
once they had entered manifestation. The Root Race 3 Lamanian/Lemurian
and Root Race 4 Atlanian/Atlantean souls of the Second and Third Seeding
could not reincarnate into the Fifth Aeiran/Aryan Root Race and became
trapped in time within the second, third and fourth dimensions. Following
death, these souls would enter D-2 Earth core and their consciousness would
fragment into the Earth's D-2 Uni fied Field. Having lost their form-holding
22 
 

                                                                                                           
                                                                                                           
                            The Electric Wars
 morphogenetic field, they would incarnate into elemental consciousness and
 evolve as second-dimensional life forms. They would be trapped in the ele-
 mental incarnations until the fourth-dimensional Seal of Palaidor was lifted
from the morphogenetic field. 
  The Palaidorian/Amenti morphogenetic field within the Sphere of
 Amenti represented the collective Soul Matrix for the human lineage on
Earth. Because of the Seal of Palaidor the races would emerge into Earth from
the morphogenetic field from D-4 instead of through Earth's D-2 core, they
would experience one incarnation, die and become part of the consciousness
         of Earth, losing their sentient identity. Meanwhile, the portion of their
 essence that had picked up the fourth-dimensional base tone frequencies
while passing through D-4 in birthing, would rise back into the lower fre-
quency bands of  D-4 at death. These fragments of identity became disembod-
ied astral consciousness without a body form or organizational identity
imprint. The Fifth Root Race Aeirans were able to retain form in the astral
identity as the D-4 frequencies were already contained within their fourth
DNA strand. Though the Aeirans could not plug the second, third and
fourth DNA strands into each other until the fourth strand had been fully
assembled, the identity pattern manifested itself within the second, third and
fourth dimensions, creating an emotional/elemental body in D-2, a mental
body in D-3 and an astral body in D-4. As the Aeiran race progressively
assembled its fourth DNA strand, unity between D-2 emotional awareness,
D-3 mental awareness and D-4 astral awareness would result, allowing the
consciousness to separate from the physical body and travel through the D-4
astral planes. Once all of the fourth strand was assembled and the ancestral
soul fragments integrated, the Seal of Palaidor would release in the Aeiran
genetic code, the emotional, mental and astral identities would merge, the
activation code overtones of the Fifth Cloister (the Hibiru) would plug in
and release the Seal of Amenti, allowing ascension through the Blue Flame
in the Sphere of Amenti to occur.  
   The Third and Fourth Root Races did not have an astral body as their
genetic imprint did not include the fourth/D-4 strand of DNA. Only mem-
bers of Races three and four who participated in inter-stellar breeding were
able to create the organizational form of an astral body in D-4 and splice in
the imprint for the fourth DNA strand. Members of these earlier races from
the Second and Third Seedings could not pass into their race's morphoge-
netic field at death, and thus they could not reincarnate into the Fifth Root
Race. At death their soul essence fragmented into the Uni fied Fields of
23 
                                                                                            

         
              The Secrets of Amenti  
 dimensions two, three and four where they would have to merge with Aeiran
consciousness in order to ascend. A great burden was placed upon the Aeiran
Root Race and its Cloister Hibiru, for they became responsible for assimilat-
ing the fragments of consciousness from their race three and four ancestors,
before they could fully ascend. These ancestral soul fragments appeared as
fragments of incarnational memory and chaotic identities, sub-personality
fragments from the elemental, mental and astral planes, which would assem-
ble into the conscious awareness as the astral, mental and emotional bodies
merged through assembly of the fourth DNA strand. Along with this burden
the Aeirans and Hibiru also had to integrate the missing sixth overtone in
DNA strand one through which the Seal of Amenti could release and ascen-
sion take place.  
   Until the Seal of Amenti was released, the anti-particle codes that could
not merge with the physical body built up within the etheric body level of
the auric field—the anti-particle double within the parallel Earth. This elec-
trical build-up in the etheric body caused the physical body particles to
become overly dense and manifested as blockages (called miasms) within the
natural energy channels of the body, accelerating the manifestation of physi-
cal disease and the cellular deterioration process. The Aeiran and Hibiru
races, and their Aryan and Hibiru descendants would inherit this burden of
cellular clearing. Most humans of the present day have the fifth race coding,
and are subconsciously involved with this process of cellular clearing, inte-
gration of the emotional, mental and astral bodies, and assembling the fourth
DNA strand in order to release the Seal of Amenti and ascend. The Seal of
Palaidor would create a build-up of chaotic energies/identity fragments
within the elemental, mental and astral planes, until the Fifth Root Race ful-
filled its genetic imprint and assembled the fourth DNA strand through
which these soul fragments could be released. An alternative to fragmenta-
tion was offered to the races through the later inception of what came to be
called the Third Eye of Horus.  
  Though the burdens of evolution placed upon human consciousness
under the Seals of Amenti and Palaidor would be great, the Elohim and Ra
Confederacy knew this before orchestrating the Second Seeding, and they
allowed it to occur as a way of assisting to purify the digressive genetic codes.
The lower-vibrating genetic imprints would dissolve into the Uni fied Field of
           D-2, while the soul essences could re-evolve through the Fifth Races. They
             knew that one day, when Earth's grid vibrated high enough, the Sphere of
           
             24  
           
           
  

                                                                                                                           
                                                                                                             
                                                                                                                 The Electric Wars
 Amenti could be returned to Earth's core, releasing the fourth-dimensional
 Seal of Palaidor and the souls lost in D-2 and D-4 could ascend.
      Not only did the Seal of Palaidor create problems within the incarnational
     process, it also created problems for the physical incarnates on Earth. The race
  morphogenetic field through which a race incarnates represents the living
    memory bank of that evolving race. If the morphogenetic field of a race is
 removed from a planet and its energies are no longer running through the plan-
 etary grid, the entire race memory is wiped out of the planet’s cellular memory.
 People alive on the planet cannot find the content or sequence of most of the
 race memory. They do not remember their origins, the purposes for which they
 came, or their destination through the course of their evolution. The portions
 of the race morphogenetic field removed from the planet take with them the
 DNA strand imprint through which that memory would be stored within an
  incarnate's bodily cellular memory. Corresponding DNA particles break loose
  from the operating DNA strands, lose their sequence of linear order and cannot
   translate through the neurological structure of the human into conscious per-
  ception. DNA particles breaking loose from the operating strands become what
     Earth scientists call “junk DNA," stored within the cells with seemingly no
       purpose.  
      After the Seal of Palaidor was set, the races of the Second Seeding would
 enter incarnation with no memory of their identity or of the higher dimen-
 sional worlds from which they had come. This knowledge would be stored
 within the fourth dimension and could be accessed only through the astral
    essence. The races would also forget their connection to the Earth and to
 each other, as this memory is stored within the second strand, and is blocked
 from mental view. The human of the Second Seeding would have a new kind
 of consciousness, a perception of exaggerated duality and a sense of separa-
 tion from all things that would bury the memory and the truth of the teach-
 ings of the sacred Law of One . Through the dismantled DNA codes stored in
  the cells, the human would develop a subconscious mind, containing the
 consciousness of its second strand and soul fragments drawn in from the D-2
   elemental Uni fied Field. A time of dream assimilation would have to take
 place in order to begin assembling the astral awareness of the fourth strand
 and the soul fragments drawn in from the D-4 uni fied field. A new kind of
 multi-layer consciousness would develop in the human, quite different from
 the earlier uni fied awareness of its immortal body. Even for Visitors of non-
 human lineage, the memory of the planet's history would not be found unless
 it were accessed through the Sphere of Amenti in the fourth dimension. The
   Seal of Palaidor placed Earth in a frequency quarantine, through which it
     became temporarily disconnected from its inter-galactic community. Humans
          
          25 
                                                                                                                  

 
        The Secrets of Amenti
on Earth would not be able to remember what existed on the Earth, or that
 Earth was a member of vast multidimensional reality fields containing innu-
 merable sentient forms of life. The human developed tunnel vision, a condi-
      tion which remains today within the majority of people on Earth.  
   Great hope was placed upon the success of the Fifth Root Race evolution,
     for the Fifth Root Race was designed to assemble the fourth DNA strand, the
        strand that corresponded to the fourth dimension. If the Fifth Root Race could
    fully evolve its strand, their astral awareness could pass through the Seal of
         Palaidor. While they were still alive in body, they could consciously awaken in
 their astral bodies, discover the secrets of their missing codes and begin to con-
 sciously heal the mutations in their gene codes. The Fifth  races would  become
          the Keepers of Records for Earth  until the Sphere of Amenti was returned to
     Earth's core, as they could pull the lost race memory from the Sphere of
 Amenti in D-4 and bring it alive once again upon the planet.  
       Following the removal of the Sphere of Amenti from the Earth's core
    5,500,000 years ago, the Earth grid rapidly plunged in speed, then began an
     even more rapid acceleration as erratic energies left over from the Sphere fil-
 tered through Earth's bioenergetic system. Climatic changes again occurred,
  land masses slid beneath waters, and great quakes rumbled through the
   planet. Within three years of the removal of the Sphere, a great ﬂood came
  that covered over 85% of Earth's surface. The memory of this ﬂood, along
  with that of two others, was given to you by the Elohim and recorded in your
     Biblical history as one event. The ﬂood of 5,500,000 years ago just described
 is the first major ﬂood on Earth, the second ﬂood occurred about 849,000
  years ago and the third during the Third Seeding of the Root Races. There
  were many other periods of ﬂooding but these three periods were the most
       notable. With the Seal of Palaidor came a wall in time behind which the
     truth of human lineage was hidden. Humans born in the Second and Third
  Seedings would be marked by the Seals of Amenti and Palaidor, baring the
           burden of a past of which they would have no memory. It could take millions
  of years for the Earth grid vibrational rate to rise enough so that life with
    fourth-dimensional coding (the fifth races) could be sustained and the Sphere
   of Amenti returned so the Seal of Palaidor could be lifted. Human evolution
                  was stunted 5.5 million years ago and would have remained so if it were not
          for Sirius B.  
       
        
        
         26  

                                     
                                   
                                         2                        
                                                                                                         
                              The Second Seeding                                                                           
                                                                                                                  
                                                                         
                                                                           SIRIUS B
                                                                                 Sirius B and the Third Eye of Horus                                                                                                                                                  4,000,000 YA         
    In an attempt to revitalize the human evolutionary program, on behalf of
the Ur-Tarranates who had sacrificed their freedom 550 million years ago to
rescue the lost souls of Tara through the Turaneusiam-2 experiment, about
four million years ago the Sirian Council of HU-2, working with the Elohim
and descendants of the Taran Ceres (a HU-2 family known as the Seres) and
several other HU-2 groups created a plan through which human evolution on
Earth could be restarted. Earth's grid still could not sustain a life field with
fourth-dimensional gene coding, so a plan was devised to allow the souls
waiting within the Sphere of Amenti in D-4 to be re-entered into Earth by a
process called  Down-grading. Through this process the vibrational essence of
the race morphogenetic field could be “stepped down” to a slower vibrational
pattern, by passing a portion of the morphogenetic field through the core of
another planet in HU-1. This experiment would require the use of a plane-
tary body within the same time spiral cycles as Earth, which had a core vibra-
tional speed/particle pulsation rate slightly higher than that of Earth. The
planet chosen for this experiment is in your Sirius star system and is known as
Sirius B.  
    An artificial portal bridge was constructed between the core of Sirius B,
the Sphere of Amenti in D-4 and the Earth core at D-2. A small portion of
the Amenti morphogenetic field was placed within the core of Sirius B, the
part that contained the energy essence/souls of the Second Seeding. Some of
these soul essences combined their consciousness with the evolving etheric
consciousness of Sirius B and created a hybrid strain of Sirian-human con-
sciousness which came to be known as the Kantarians.  This name was
derived from the Kuntureaz,  the non-physical Sirian sub-race of conscious-
ness with which the human consciousness had merged. The Kantarians       
        
       
       27  
                                                                                                                                                                                                                                                                       
      
     


                                                                                                              
                             The Second Seeding  
  became semi-dense physical beings upon merging with the morphogenetic
  field of humans from the Second Seeding. Much later the Kantarians founded
  the Kantarian Federation,  gaining approval from the HU-1 Galactic Federa-
  tion to serve as a guardian and educator race for Earth humans of the Second
  and Third Seedings and they became heavily involved with old Sumerian
   and Egyptian cultures, as well as that of Atlania and Atlantis.  
    The portal bridge between Sirius B, the Sphere of Amenti and Earth
   allowed for greater evolutionary options for the fourth and fifth races, those
  who carried the third DNA strand in their race morphogenetic field. This
    option was not available to Lamanian/Lemurian and Ur-Antrian cultures, as
  they did not carry the full third stand imprint in their morphogenetic field. The
  option assisted Atlanian/Atlantean races and their Breanoua Cloister who suc-
  cessfully assembled the third strand, and also the Aeiran/Aryan races and their
  Hibiru Cloister who were not able to fully assemble their fourth DNA strand
   prior to death. For these races, instead of the soul essence fragmenting into D-2,
   D-3 and D-4 following death (as would be the case due to the Seal of Palaidor),
  the soul essence who had assembled most of the third strand could move into
  the race morphogenetic field in Sirius B. Within the morphogenetic field of
    Sirius B the soul could evolve here for a time as disembodied consciousness to
   assemble more frequencies into its code, then pass into the Sphere of Amenti
  through the portal bridge. Souls taking the Sirius B path of evolution could
  release the Seal of Palaidor, but not the Seal of Amenti. They could return to
  the Palaidorian morphogenetic field and wait there for the seeding of the fifth
  race into which they would incarnate to assemble the remainder of the fourth
  strand. This was a much better option than fragmentation, which would create
   loss of the personal identity imprint as the soul fragments merged with the con-
   sciousness of the fifth races. Individual sentient identity could be retained
  through evolving through Sirius B. During the Second Seeding this portal
      bridge became known as the  Hall of Amorea,  in the Third Seeding, during the
  times of Atlantis and Egyptian Pharaonic rule, it became known as the Third
    Eye of Horus,  and represented the culmination of the “Left Eye of Horus” and
   “Right Eye of Horus” mystical teachings. The Third Eye of Horus was a closely
  guarded secret, and passage through this dimensional bridge was reserved for
        the few elite races who carried the needed third strand genetic imprint.  
                             The Second Seeding - the Fourth World                                                                                      3,700,000 - 848,000 YA         
     The morphogenetic field for the Second Seeding Races was entered into
   Sirius B approximately four million years ago. The races began incarnating on
   Earth through a small group of human hybrids who had found exile and
   evolved within the HU-1 Pleiades star system during the Electric Wars.
    Through the Sirian Council of HU-2 and the Galactic Federation of HU-1,
       28 
    
 
                         

                                                                                                                             
                                                                                                                          Melchizedek Races
members of this hybrid race, known as the Europherites (sometimes called the
Euries,) migrated from the HU-1 Pleiadian star system to Sirius B, interbred
with the Kantarian race to strengthen the human and Sirian imprint in their
genetic code, forming a smaller hybrid race called the Dagos.  Through the
Dagos, Kantarian and HU-1 Pleiadian lineage became intertwined with the
original Turaneusiam-2 imprint during the Second Seeding. The Dagos were a
dark brown skinned race whose genetic imprint would be carried as a recessive
gene within the human strain of the Second Seeding. The Dagos were brought
to Earth to set up small colonies in various locations about 3,995,750 years ago.
Reseeding of the Cloistered and Root Races of Amenti began, starting with the
Ur-Antrian Cloister 3,700,000 years ago, followed by Root Race 3, three mil-
lion years ago. Root Race 3, the Lumarians, became the Lamanians,  denoting
their passage through Sirius B. The Fourth Root Race and its Cloister entered
next, the Breanoua Cloister, about three million years ago, followed by the
Alanian Root Race 4 at 2,500,000 years ago. The Alanians became known as
the Atlanians. The Fifth Root Race Aeirans and their Cloister Hibiru then
entered, the Hibiru 1,500,000 and the Ayrians 1,275,000 years ago. The time
period beginning with the Second Seeding 3,700,000 years ago and extending
through the Third Seeding into the present time represents the Fourth World
of Native American legend.                                                                                                                                     MELCHIZEDEK RACES  
      
     DNA Strands and the Races, the Sixth Root Race, the Melchizedeks  
                    and Hibiru Cloister Mix, Agartha and the Essenes,  
                                          Hebrews, and Christians  
    The Fifth Root Race Aeirans, now known as the Ayrians, were responsible
for assembling the fourth DNA strand, which corresponded to the fourth-
dimensional frequencies, and through them the Earth grid would raise in vibra-
tional rate so the Sphere of Amenti could be returned to the Earth core. As
they ful filled the assembly of the fourth strand the Seal of Palaidor would be
lifted allowing the soul fragments from D-2 and D-4 to merge with fifth race
consciousness and evolve, and the soul essences of races 3 and 4, who waited
within the Sphere of Amenti to reincarnate into the fifth race could be set free.
The Ayrians contained within their DNA strands number 1, 2, 3 and the base
codes of 4, their Hibiru Cloister containing these plus the imprint for assembly
of strands 7-12. Both Ayrian and Hibiru races have two strands of DNA (dou-
ble helix) manifest within their bodies on Earth and two strands manifest
within their anti-particle doubles on parallel Earth. The Fourth Root Race
Alanians, now the Atlanians,  had three-strand DNA, strands one and two and
the base codes of 3, their Breanoua Cloister having these plus the imprint for
7-12. Atlanians and Breanoua would each manifest 1.5 strands within their
29 
                                                                                                                   
                                                                                                       
 
                                                                                                                           
                                                       

 
                                                T he Second Seeding
bodies on Earth and within the parallel system. Root Race three Lumarians,
now Lamanians,  had strand one and the base codes of strand 2, their Ur-
Antrian Cloister had these plus the imprint for 7-12.  
    All of the races of the Second Seeding carried trace codes of the Pleia-
dian-Sirian Dagos. Races of the Second and Third Seeding, like their ances-
tors of the First Seeding, also carried grounding codes within their
operational DNA strands, which contained partial frequency patterns for
each of the 12 dimensions within the 12-strand Turaneusiam imprint. The
grounding codes allowed each race to manifest with some degree of three-
dimensional, physical matter density and also allowed for transmutation of
the physical matter particles once the overtone activation codes were opera-
tional. Though all of the races carried the grounding codes, not all could acti-
vate them because of the Seal of Amenti. As long as the Seal of Amenti, the
missing sixth overtone of the first DNA strand, was contained in their mor-
phogenetic pattern, none of the races could activate the grounding codes of
the higher dimensions. As races 3-5 of the Second and Third Seeding would
be born with the Seals of Palaidor and Amenti, only those whose imprint
contained the fourth DNA strand (the Fifth and Sixth Root Races) had the
potential to activate all of the grounding codes to ascend.         
    The Fifth Root Race, which was also born with the Seal of Amenti, held
the hope of activating the grounding codes, if they could fully assemble their
fourth DNA strand. This would give them astral plane/D-4 mobility of con-
sciousness through which they could pass into their Cloister morphogenetic
field on the astral plane, then merge with their double there, through which
the Seal of Amenti would release from strand 1. Then strands 2 and 3 could
plug into their doubles and into strand 4. Once strands 1-4 plugged into each
other, the matter particles would begin to fuse within their anti-particles,
which would activate or fire the fifth, sixth and seventh grounding codes,
allowing the body to fully transmute through the Blue Flame and the Halls of
Amenti to reappear on Tara.  
  The Sixth and Seventh Root Races and their Cloisters carried the
remaining fifth and sixth DNA strands of the 12-strand package. Neither of
these races entered full manifestation during the Second and Third Seedings.
The Sixth Root Race are the Muvarians, their Cloister the Melchizedeks,
they will assemble DNA strand number 5, corresponding to the fifth-dimen-
sional frequencies and represent the transitional race cycle through Earth’s
ascension passage into merger with Tara. The Melchizedeks are a blended
race carrying various racial strains. Though they represent the Cloister that
originally began the yellow-skinned races on Earth, they are not limited to
manifesting through this racial line. Melchizedeks appear within strains of all
the races as they became involved as a Host Matrix/surrogate morphogenetic
field for many of the races toward the end of the Second Seeding. The
Melchizedeks carry DNA strands 1-4 and the base codes of 5, plus the
30 
 
                                                                               

                                                                      
                                                                             Melchizedek Races
imprint for strands 7-12. They are free of the Seals of Palaidor and Amenti,
and can thus undergo full transmutation of bodily form in order to ascend, if
they are able to fully activate the base tones within their fifth strand. Because
of their advanced genetic package the Melchizedeks are able to pass through
the Blue Flame in the Halls of Amenti and experience teleportation through
the portals into the Taran environment.           
    The Melchizedeks assisted in repairing genetic digression toward the end
of the Second Seeding, becoming one of the Host Matrix families, then
began their race birthing cycle during the Third Seeding. The first wave of
Melchizedeks appeared about 35,000 years ago, the second wave 3,500 years
ago, and the third wave began about 250 years ago and continues today. The
family of the Templar-Melchizedeks established the Essene Brotherhood and
Priesthood of Melchizedek,  a priesthood that still exists on Earth today. The
lineage of the Essenes was one of the 25 families within the Melchizedek
Cloister, descendants of the first wave of the Melchizedek cycle. The
Melchizedeks assisted the Hibiru Cloister of Root Race 5 in repairing genetic
damage at the end of the Second Seeding, then during the Third Seeding the
Templar-Melchizedeks once again intervened, creating a mixed-Cloister race
carrying the genetic codes of both lines, which accelerated the evolutionary
potentials of the Hibiru and Ayrian/Aryan races. This mix-cloister breeding
would later become a major problem for the descendants of this lineage, due
to events that transpired 10,000 years ago during the Third Seeding. The
mix-cloister Hibiru/Melchizedek race became known as the Hebrew  race
during the Second and Third Seedings. The Essenes, Templar-Melchizedeks,
Hebrew and Christian lineages of the Third Seeding, including those of
present day Earth, all carry this genetic advancement. And following the
events of 8,000 BC (10,000 YA) those affiliated with the Templar-
Melchizedeks would also carry forth a great genetic burden.  
   The spiritual in ﬂuence of the Templar-Melchizedeks has touched all of
the major Christian and Jewish persuasions, and they played an instrumental
role in the formation of the modern day Mormon-Christian  faith. The
Melchizedeks are a primary force within the present times on Earth, as they
are now within the third wave of their race birthing cycle. The Melchizedeks
hold within their lineage the promise of ascension, even more so than do the
fifth Ayrian/Aryan and Hibiru races. But not all Melchizedeks presently bear
the same genetic coding. Two primary groups of Melchizedeks have evolved
out of the original Melchizedek Cloister morphogenetic field, the Cloistered
Family of Melchizedek and the Templar-Melchizedeks.  The difference
between their spiritual teachings denotes not only a philosophical prefer-
ence, but also a genetic propensity that came into being 10,000 years ago.
Spiritual teachings that have been either directly or indirectly in ﬂuenced by
the Templar-Melchizedeks will have an distinctly patriarchal slant, often pro-
moting gender subservience, elitist philosophy and subjugation of Earth’s ele-
31                                                                                                                                                                                                                                
 

 
         The Second Seeding  
mental kingdoms. These attributes of the Templar-Melchizedeks were not
originally part of the Melchizedek Cloister strain, but rather evolved through
ET distortion. The Cloister Family Melchizedeks are considered to be the
pure strain of this race, the Templar-Melchizedeks and their descendants a
mutation of that strain. In the following pages we will explore how that dis-
tinction came to be, as the duality within the Melchizedek race has created
an intense, hidden undercurrent within the ideologies of present day Earth,
greatly in ﬂuencing the development of many of your world religions. And
this distinction also directly affects the genetic code and ascension process of
descendants of the Melchizedek races.  
   The Melchizedeks of both Templar and Cloister persuasion draw their
name from their original genetic affiliation to the Turaneusiam-1 sub-race Mel-
chazedakz  from Tara, whose name also denoted their genetic affiliation with
the Entity gestalt Melchazedek from the realities beyond the Metagalactic
Core. There are many divergent races baring traces of the Melchizedek line
throughout all of the Harmonic Universes. Members of the Priesthood of
Melchizedek, who specialize in dimensional ascension training are not neces-
sarily direct members of the Melchizedek/Melchazedek race line, but often
work under the teaching programs of that Cloister.  
   During the Third Seeding, about 65,000 years ago, the Melchizedeks
appeared in Atlantean culture, and prior to the sinking of the Atlantean
islands (30,000 - 11,500 YA) retreated to an underground haven deep below
the Earth’s crust within a three-dimensional frequency modulation zone that
exists between Earth and her anti-particle double. This area is known as the
Inner Earth,  and large civilizations exist in these lands since times prior to
Atlantis, when the Melchizedeks and others began to retreat from surface life.
These underground civilizations exist to this day, and occasionally members
interact with surface Earth through the hidden caverns that link Earth’s surface
to the modulation zone of the Inner Earth. Both Cloister Family Melchizedeks
and Templar-Melchizedeks reside within these lands, under the primary guard-
ianship of the Speakers of the Blue Flame and Melchizedek Priesthood, and
Priesthoods of Ur and Mu from Tara. These sub-subterranean lands were origi-
nally called Ar-Ratoth, later Agratath and since about 3,000 years ago have
been referred to as Agartha.  
 The Cloister Family of Melchizedeks, Templar-Melchizedeks, the Staff
 of Amenti, The Speakers of the Blue Flame and  the Templar and Axion
                   Seals, the Eye of Elohim and the “666” Symbolism  
                                            10,000-3,500 YA  
    As we have mentioned, the first full wave of the Melchizedeks birthing
cycle began during the Third Seeding, about 35,000 years ago, the second
wave about 3,500 years ago and the last about  250 years ago and continues on
32 
 
 
    

                                                                                     
                                                                                                                                          Melchizedek Races  
today. During their first appearance they created the Priesthood of
Melchizedek on Earth, a spiritual organization specializing in the process of
ascension, which over time developed a strong elitist, sexist, patriarchal slant
due to Atlantean and Sirian-Anunnaki influence. About 32,000 years ago
some of the Melchizedeks joined forces with the matriarchal Taran Priest-
hood of Mu, creating a more balanced Melchizedek Priesthood which more
closely followed the teachings of equality promoted in the original
Melchizedek Priesthood. The balanced Melchizedek priesthood became
known as the Cloistered Family of Melchizedek , for they carried with them
the original sacred Law of One teachings of the Melchizedek morphogenetic
cloister.  
    The egalitarian Melchizedeks became known as the Speakers of the
Blue Flame  about 10,000 years ago (about 8,000 BC) when the Priesthood of
Ur and the Palaidorian Council of Tara transferred Earth guardianship of the
Staff of Amenti/Blue Flame/Tara's morphogenetic field out of the hands of
the unbalanced, patriarchal Melchizedek Priesthood and into the hands of
the balanced Melchizedek Priesthood. The Taran Priests of Ur disassociated
themselves from the patriarchal Melchizedeks, attributing their elitist, sexist
slant to infiltration of the Sirian-Anunnaki cultures, who brought with them
to Atlania, and later Atlantis, the distorted teachings of the original Templar
Solar Initiates whose elitist, aggressive misuse of power for materialistic gain
had culminated in the cataclysm of Tara 550,000,000 years ago. This transfer
of guardianship of the power of the Blue Flame 10,000 years ago resulted in
the instrumentation of two more genetic frequency seals being placed upon
members of the sixth race Melchizedek Cloisters who were associated with
Templar distortions of the Sacred Law of One and also on any descendants of
the Templar-Melchizedeks or races who interbred with them and picked up
their genetic coding.  
    The Templar Seal,  as the first alteration became known, was imple-
mented 10,000 years ago, and represented a sixth-dimensional seal upon the
Halls/Sphere of Amenti. The second Templar Seal was administrated about
3,500 years ago when descendants of Templar-Sealed Melchizedeks infiltrated
Egyptian culture and violated the Covenant of Palaidor by opening the D-2
Earth portals as a way of orchestrating ascension through the D-1 and D-2
Underworld. Through their misdeeds many chaotic forces were unleashed
upon the Earth, and humans with distorted morphogenetic imprints were
released from the Seals of Palaidor and Amenti and allowed to pass into Tara.
Many tragic events since took place on Tara as a result of this misadventure
3,500 years ago, and a seventh-dimensional Seal  was added to the T emplar-
Melchizedeks who participated in these events. The second Templar Seal is
called the Templar-Axion Seal.  Both T emplar Seals made physical ascension
through the Halls of Amenti impossible for those who carried this genetic
configuration, and only under certain circumstances could the soul essence
33                                                                                                                    
                                                                                                                                                                                                                 
  

       
      The Second Seeding  
 pass through the Blue Flame. Those baring the Templar-Axion Seal could
 eventually pass into Tara and enter incarnations within the sixth races, but
  the Templar-Axion Seal did not allow them to transmute into their immortal
 seventh race bodies. The Templar-Axions were destined to repeat innumera-
  ble incarnational cycles upon Earth in order to clean up the mess they had
 made by releasing the chaotic forces of D-2.  
    Only the Elohim, the Axious Entity Family and Ra Confederacy families
     of the Azurites and Amonites, from the Metagalactic Core, or the Breneau
     Entities from HU-5 had the power to release the Templar-Axion Seal, and
      would do so only for humans who gained their favor through serving the
    truth of the Sacred Law of One.  
     The Templar-Axion Seal became as a curse upon the human lineage, as this
    distortion was passed on genetically;  as the Melchizedeks and their Hebrew
    hybrids interbred with other racial strains, the Templar Seals were passed on,
    in whole or in part, to incarnate souls who did not have this prior affiliation.
         Fragments of the Templar Seals that passed on genetically created a variety of
      incarnational and ascensional problems for anyone involved with them. The
  Seals were to remain intact for those whose prior affiliations with the Tem-
 plar Solar Initiates/Templar-Melchizedeks warranted such security measures,
      but attempts were made to help purge unintended Templar Seal holders of
  their genetic burden. The Elohim, Sirian Council of HU-2 and the Pleiadi-
  ans all assisted in this plan, offering ascension teachings through which the
     burdened races could purge their genetic code of the Templar Seals. Templar
       Seals can only be removed when this is approved by the Ra Confederacy and
   its Axious, Amonite and Azurite gestalt Families, the Entities who orches-
    trated the Templar Sealings in order to protect Earth and Tara.  
    The Templar Seals still affect a majority of the present human population, and
     the Elohim, Pleiadians, Sirian Council and other assistants from the higher Har-
        monic Universes still work to assist unintended Templar Seal bearers.  Through
   spiritual training, humans are led to at least a rudimentary understanding of
    the sacred Law of One, and once this education has taken hold, the Elohim
      or other helpers take the incarnate through the astral planes (if the incar-
      nate's fourth DNA strand is plugged in) into a meeting station within the
    eighth dimension Metagalactic Core. There the incarnate's personal mor-
    phogenetic field is evaluated to determine if Templar Sealing is in order as a
    planetary security measure, and if the Seals are unwarranted the Elohim peti-
    tion the Ra Confederacy to remove any trace of the Templar Seals. If the Ra
   Confederacy agrees, the Seals are removed and the incarnate's consciousness
   is allowed to pass through the eighth dimension where the DNA imprint in
      the morphogenetic field is repaired. The eighth-dimensional meeting place
            and passage way into the Metagalactic Core is often referred to as the Eye of
      Elohi m, or the Galactic Core.  Humans not bearing Templar Seal distortion
      can pass through this dimensional portal once they have fully evolved their
           34
         
       

                                                                                              Melchizedek Races  
seventh DNA strand. Those bearing the Templar Seals must be assisted by
the Elohim, Azurites, Amonites or their many helpers, in order to pass
through the eighth dimension to heal their DNA of Templar distortion. Oth-
ers who rightfully bear the Templar Seals can find freedom through working
with the lessons of love, unity and equality as taught through the sacred Law
of One. When these lessons are learned, the incarnate's consciousness is no
longer a threat to interplanetary security, and assistance in lifting the Tem-
plar Seals will be provided.    
   Though we will not address the mechanics by which the Templar Seals
operate, we will provide a bit of information regarding the DNA strands
affected. The Templar Seal is a sixth-dimensional seal affecting the second,
fourth and fifth DNA strands. The sixth base tone of strand 2, the sixth over-
tone of strand four and the 12th overtone of strand 5 were all removed from
the morphogenetic field of the Templar-Melchizedek Cloister. The portion of
the Melchizedek Cloister morphogenetic field containing the Seal was
removed from the Sphere of Amenti and placed within the planet core Alcy-
one within the Pleiadian star system, which required the Seal bearer to
evolve within the Pleiadian star system for a time as pure consciousness
before being able to ascend through the Sphere of Amenti to rebirth within
the sixth race on Tara. The fourth strand distortion of this seal created a
polarization within the fourth/heart chakra (which corresponds to fourth-
dimensional frequencies), and a barrier within the Nadial Capsule that sepa-
rates the mental and astral awareness and separates the third/mental body
and fourth/astral body levels within the auric field. It limited astral travel to
the lower astral planes. It created a separation within the astral awareness,
creating a lower  and higher  astral identity. The lower astral identity became
known as the “evil twin”  or the “ dweller on the threshold”  within some
religious teachings. The Second strand distortion created a division within
the D-2 elemental/emotional body, which created two levels of the sub-con-
scious mind, a higher level and lower level. The higher level held identity
fragments of sub-personalities, while the lower level created a chaotic emo-
tional force that came to be known as “the shadow self,”  exaggerating the
human’s primitive emotional impulses. The Second strand distortion also
made it impossible for these humans to successfully interbreed with other spe-
cies from Earth or from the stars. It created an ampli fied blockage between
the first, second and third chakras, blocking out clear communication with
the body consciousness and with the Earth's elemental kingdoms. The fifth-
strand distortion made the physical earthly body unable to transmute or
ascend, so the consciousness would have to rebirth into the sixth races on
Tara to continue evolution.  
    The Templar-Axion Seal  did all of this and more. It is a seventh-dimen-
sional seal which meant that once the consciousness had managed to ascend
to Tara it could not evolve into the seventh races, reclaim the immortal body
35 
  

     
     The Second Seeding  
and ascend out of matter form. The Axion Seal required that the soul con-
tinue innumerable cycles of birth and rebirth within the earlier races, until
the time when Tara and Earth would merge. The sixth base tone of the first
strand, sixth base tone of the fifth strand and sixth base tone of the sixth
strand of DNA were all removed from the morphogenetic field. This genetic
conﬁguration of the Templar-Axion Seal was the original meaning behind the sym-
bolism of the “666”, and these numbers also ﬁgured prominently in the earlier
building of the Great Pyramid, for this Seal had originally been applied to the Sirian-
Anunnaki in HU-2, who assisted in the construction of this machine . The “666”
became the trademark of members of the Sirian-Anunnaki who refused to
accept leadership from the HU-2 Sirian Council, and who would not uphold
the Law of One. The “666” became a part of the human genetic code through
the interbreeding of the Melchizedek Cloister with visiting Anunnaki, who
created the hybrid races Nephilim  and Annu,  and then again through the
imposition of the Templar-Axion Seal following the opening of the D-2 por-
tals in Egypt during the Third Seeding. To administer the Templar-Axion
Seal, part of the morphogenetic field was put under the jurisdiction of the
Arcturian races and part within a planet in the Andromeda galaxy, which
meant that the soul essence would have to evolve a disembodied conscious-
ness, first through the Pleiadian system, then Arcturus, and then into
Andromeda, before it could finally rebirth on Tara. Once its Taran cycle was
completed, the soul had to return to Earth. By passing the consciousness
through these other star systems, teachings of the Law of One could slowly
heal the identity, until eventually its tour of duty on Earth would be ful filled.
This tour would last until Earth had successfully re-evolved into Tara and the Cov-
enant of Palaidor was fulﬁlled.                  
    Due to the T emplar and T emplar-Axion Seals the concept of “ soul har-
vesting”  became part of many religious teachings. Soul Harvesting referred to
souls bearing the Templar Seals being brought, by one of the helper organiza-
tions before the Ra Confederacy for review, at which time those souls deemed
safe for transit to Tara or higher systems would be released from the Templar
Seals and allowed to end the perpetual cycles of birth and rebirth on Earth.
Those passing the review would have evolved to comprehension of the
necessity for the Law of One, and would have actively employed these princi-
ples within their present incarnation. Passing the review meant the soul
would be “harvested” or cleared of its distortions and allowed to ascend to
Tara for rebirth within the sixth and seventh races, and following its com-
pleted Taran cycles, the soul could ascend out of matter. In some traditions
this concept became translated as “ judgment day”  or similar ideas of having
to “pass God's tests” and become “worthy.” But in truth, God's universe is
free, and these concepts applied only to beings bearing the Templar Seals,
who wore the armor of their disregard for the Law of One within the con figu-
rations of their genetic codes. Processes of initiation that developed through
36 
                                                                                         

                                                                                                                
                                                                                                              Melchizedek Races
the mystery schools of old and those of the present were all designed to assist
in the ascension passage. Many were designed specifically to release the Tem-
plar Seals, and to protect individuals from inadvertently adopting the Seals
through interbreeding.  
     Many people of present day Earth carry some portion, or all, of the T em-
plar Seals, and they will experience such a review after passing into the astral
plane in death. Others can begin this review before death by working with
spiritual principles and guardians/ascended masters, who will help them learn
the Law of One so the Seals can be removed prior to death, which will allow
some individuals to transmute the body and pass through the Halls of Amenti
to Tara, immortalizing the body as it was originally intended. The enforced
tour of duty of some of the Templar Seal bearers is almost at its end, as the
merger of Earth's grid and Tara will take place within the next three to four
Earth generations, a process that will begin in the year 2012. The Earth will
“ascend in waves,” as portions of its energetic systems merge with their dou-
bles and transmute into Tara's grid. The first wave will begin in 2012 and end
between 2072 and 2084, i.e., five to six 12-year cycles following the opening
of the Halls of Amenti, which is scheduled for 2012 - 2022. Humans who can
assemble their full fourth DNA strand will be able to ride this first wave into
ascension. The Second planetary ascension wave is not scheduled to occur
until about 4230 AD. Templar Seal bearers who have their Seals released can
ascend on this first wave, and be freed of the Earthly incarnational cycles.
     It would be helpful to humans if they could realize the reality of life after
death so when encountering this event some level of preparation can be
applied. Most humans would prepare for a trip across town, yet they make lit-
tle preparation for the greatest journey they will make; the voyage between
dimensions when they leave the con fines of one life time and their conscious-
ness moves into its next experience. All humans will have a personal review
of their life content upon this transition, but not a judgment placed upon
them. The personal soul and its higher levels of consciousness are aware of
the evolutionary process, the purpose of which is ascension. The soul aware-
ness becomes available to a human after the veils created by the con fines of
the physical genetic code are lifted, and the identity as soul then chooses the
next living experience most appropriate to its own evolution, learning,
desires and ascension process.  
    Much help is available in the higher dimensions, and there are many
institutes of higher learning, but one does not have to die in order to receive
this assistance. Education through the astral identity and projection of conscious-
ness is accessible to most humans while they are still alive in body, and through inte-
gration of the astral identity (which comes through building the fourth DNA strand)
the comprehension of the soul becomes available to the human on Earth.  It is
through this level of understanding that an individual can discover if the
Templar Seals are an issue, and if they are, how best to proceed for their
37 
                                                                                                                                                                                                                                          

      
       The Second Seeding  
removal. The issue of the Templar Seals, and of the dimensional frequency
patterns held within the imprint for the DNA, will have to be addressed,
either in life or after the death transition, for it is the frequency patterns held
there within that will determine the dimensional bands within which a con-
sciousness will next manifest. lt is not a “judgment call” by some authority
figure that determines where you will next travel after your present life time,
but rather an energetic compatibility between the frequency bands held
within the pattern of your consciousness and those within the multidimen-
sional universe.  
     DNA is built upon minute electro-tonal patterns of multidimensional fre-
quency, and the energetic imprint of the DNA goes with you in the death transition .
The content of that electro-tonal pattern will determine how high your con-
sciousness will be able to travel once it is released from the body. The DNA
can be directly affected in life by working to bring higher-frequency, higher
dimensional energies into the operating DNA strands through using the
chakra system effectively, and the work that is done to increase the electro-
tonal patterns during life will directly affect the experiences available to you
following physical death. For some of you immortalization of the body and
passage through interdimensional portals will be possible, but only if you can
learn some of the mechanics by which these events take place. It is for this
reason that we have provided you with this information.  Y ou will go on a voy-
age when your soul awareness brings this life time to a close, with or without your
body, whether or not you are prepared; this is the way of life within the universe.  As
with any journey, preparation can make the trip much more enjoyable. Most
of you would not journey to a distant land without a map in hand, and so we
offer you a rudimentary trail guide for the journey of consciousness with
which you are presently involved. There is an order, purpose, plan and mean-
ing for your personal evolution and your existence, and it is intimately inter-
twined with the evolution of your planet and that of your species. Now we
will offer a bit of information as to where your journey will next lead.                                     
                                      SCIENCE OF ASCENSION    
    The Fifth World, the Seventh Race Cycle and Waves of Ascen sion
                                                 Beyond 2000 AD          
    The Seventh Root Race and their Cloister will emerge upon Tara after
the energetic grids of Earth and Tara reemerge. Earth's merger with Tara will
mark the ful fillment of the Covenant of Palaidor, and represents the coming
Fifth World  of Native American Legend; it is often referred to as  Earth
Ascension.  It would do many of you well to realize that the term ascension repre-
sents much more than some lofty spiritual concept invented by the ﬁnite human
  psyche in order to give purpose to its ﬁnite existence. Many in the earthly scien-
 tific communities believe that life is limited to the physical expression and
  38 
       
      
  

                                                                                                           
                                                                                                          
                                                                                                             Science of Ascension
that consciousness is the result of the body's biochemical/neuro-electrical
functions. Following these erroneous beliefs they draw an equally erroneous
conclusion that consciousness ends at the death of the physical body. Yet at
the same time they are unable to identify the creative, intelligent force
through which an ordered system, such as the body, could be created. Current
scientific thought creates a paradox within itself, as an attempt is made to
define the mechanics of infinite reality within the con fines of the finite, 3-
dimensional mind. This paradox can be overcome once it is realized that
consciousness and intelligence predate the manufacture of the body, and
transcend its finite life span. Once this is realized, science will be confronted
with a whole new order of multidimensional reality, and a whole new science
through which that multidimensionality can be understood. The process of
ascension is not some quasi-religious concept based upon the meandering of
the human mind. Ascension is a highly scientific process of multidimensional
energy mechanics that represent the universal order through which con-
sciousness experiences itself as being. There is an order to the universe, and
there are indeed natural laws of energy mechanics that govern and uphold
the functioning of that universal order. Ascension represents the path of order
through  which  consciousness evolves through a structured, multi  dimensional   system.
     In terms of planetary ascension, this process involves the transmutation
of particles and anti-particles into progressively less dense states of matter,
through which a planetary body is able to evolve from the lower dimensional
frequency bands into the higher dimensional reality fields of the 15-dimen-
sional scale. Ascension also involves the understanding of morphogenetic
fields, or the form-holding energy constructions that allow matter and anti-
matter particles to build into individuated form. The process of personal
ascension involves precisely the same process, as the human is part of the
greater morphogenetic field of the planet, and the progression of dimensional
ascension of the human and the planet are intimately intertwined.  
     Without delving into the technical mechanics of the ascension process,
let us just say that planets and people ascend/evolve through the dimensional
scale through the intrinsic universal laws of energy which form and hold
together the structures of consciousness that form identities in time. Spiritual
ascension is not separate from these laws of energy structure, for conscious-
ness is sentient energy, and must therefore abide by the natural energetic laws
which hold universal structure in order. Ascension is a science, with speciﬁc
mechanics that allow for the evolution of consciousness from simple to more com-
  plex forms.  In the highest states of evolution identity evolves into the highest
dimensional fields and then beyond, moving from the simple forms of biolog-
ical expression into the more complex structures of pure conscious identity.
Every being in existence is involved in this evolutionary process, and so the dynam-
ics of the science of ascension apply directly to each and every one of you.  If you
can realize the signi ficance of this science your evolution will occur much
39 
                                                                                                                                                                                                                             

     
      The Second Seeding  
more rapidly and with less effort, for you will learn to work with the natural
laws of energetic structure to which your consciousness is bound, instead of
working against these mechanics because your consciousness has yet to com-
prehend the forces through which it manifests.  
    The evolution of planet Earth is intimately connected to that of the
planet Tara, which is the original planetary mass out of which Earth emerged.
This means that the morphogenetic field of Earth was originally part of the
morphogenetic field of Tara (and both were part of Gaia's morphogenetic
field). In order for an energy structure to fully ascend through the 15-dimen-
sional scale it must assemble all portions of its original morphogenetic
imprint. The morphogenetic fields exist as tapestries of inter-woven energy
particles, composed of literal substance, and so the process of assembling mor-
phogenetic fields into their original pattern is the process of recombining the
portions of this energetic tapestry that have become separated from the origi-
nal, back into the original form of the energetic tapestry. Planetary ascension
is the reuniting of energy units that had been separated into various dimen-
sional frequency bands, pulling those energy particles back together by merg-
ing the frequencies within which the particles reside. There are natural
energy dynamics that govern the merger of multidimensional frequency
bands, part of which involves particles and anti-particles merging.  
    Particles and anti-particles are composed of units of multidimensional
sound, or tones, and within each frequency band there are base tones and
overtones. The process of merging particles and anti-particles in order to cre-
ate the merging of frequency patterns is the process of bringing together base
tones and overtones that emerged out of the same morphogenetic field.
When base tone and overtone merge, a resonant tone is created, through
which particle and antiparticle merge, and transmute into pure energy. They
return to the morphogenetic field carrying with them the new frequency pat-
terns they picked up from the Uni fied Field of the dimension in which they
appeared, which in turn expands and adds energy to the original morphoge-
netic field. When the particles and anti-particles are next expressed into
manifestation, they will appear within the next frequency band up, as their
rate of vibration was increased by adding the frequency patterns from the
dimension they just left.  It is through this process of building dimensional frequen-
cies into the morphogenetic ﬁeld, through the merging of particles and anti-particles,
that matter forms evolve up through the dimensional scale . Tara and Earth will
merge through this process, as Earth moves upward into the dimensional fre-
quency bands in which Tara's matter-body is positioned.  
     When the frequency bands of Earth and T ara merge, changes will take
place within the matter-body of Earth. New land masses will begin to rise in
the oceans, new waters will emerge in places where they were not. But this
process does not take place all at one. Planetary ascension takes millions or
billions of years. Planetary ascension takes place in  waves.  All planets evolve
40 
 
 

                                                                               
                                                                                                             Science of Ascension
within cycles of time designated by the dimensional bands in which they
appear. At certain points in these dimensional time cycles the frequency
bands of one dimension blend into the one above and below, which allows
matter and anti-matter particles to merge, transmute and re-manifest within
the dimensional bands above and below. The particles and anti-particles that
will be able to shift upward, out of their home dimensional band, are those
that have fully assembled the frequency patterns within their home dimen-
sion. During this point in a time cycle the energetic tapestry, or grid, of the
matter-particle planet passes through the grid of its anti-particle double from
the parallel universe, and through this energy fusion certain portions of those
energetic grids transmute, sending a Morphogenetic Wave  into the dimen-
sional band above. The morphogenetic wave then projects its particle and
anti-particle form into manifestation within the new dimension and its
inherent time cycle. The portions of the particles and anti-particles that had
not fully assembled all of the frequency patterns from their home dimension
will not be able to merge, and will thus manifest from the morphogenetic
field back into their home dimension to continue their evolution through
assembling the remaining frequency bands of that dimension.  
      The morphogenetic field of a person exists as part of the larger morpho-
genetic field of the planet, and so when a planet approaches the dimensional
blending point in its time cycle, the people on the planet also reach that
point. People's bodies and consciousness are composed of energy particles, and
when the planet approaches transition and transmutation of some of its particles,
people on the planet will also undergo this particle transmutation . Just as only por-
tions of the planet's particles will be able to transmute and ascend into the
next dimension through the morphogenetic wave, only portions of the
human population will be able to transmute and ride with the planet on that
wave of ascension. People who have fully assembled the third- and fourth-
dimensional frequencies into their DNA (fully assembled the dimensional
frequencies into their third and fourth DNA strand) will be able to ride that
wave of ascension back into Tara's energetic tapestry, which perceptually
constitutes a leap in time. The personal morphogenetic field and conscious-
ness will be carried within the planet's morphogenetic wave, which will
merge with Tara's fourth, fifth and sixth-dimensional particle and anti-parti-
cle structure. The matter particles of the portion of Earth and its people that
were carried in the morphogenetic wave will then re-manifest out of the mor-
phogenetic field into the Second Harmonic Universe frequency bands
(dimensions 4, 5 and 6). These voyagers will find themselves in a new time
cycle, upon a future version of Earth-Tara, whereas the people who did not
catch the morphogenetic wave will continue on in their own First Harmonic
Universe time cycle (dimensions 1, 2 and 3).  
     For many people there will not be enough time between now and the
height of the ascension wave of 2012-2022 AD, to completely assemble the
41 
                                                                                                                            
                                                                                                                                                                                                                    

     
     
        The Second Seeding  
necessary frequency patterns into their DNA, which means they would end up
remaining in the present time cycle, and having to reincarnate into that cycle
to continue evolution. Many of these souls will choose to leave their bodies at
this time so their consciousness can assemble the needed frequencies in time to
catch the ascension wave. The soul, not the personality, will make this deci-
sion. Only natural,  soul-orchestrated  death  transition will allow  for  the   consciousness
to ascend . Suicide will not assist in this process, because, if the soul is ready to
leave its manifest body, the death transition will occur naturally or through soul
arranged events, and not at the hands of an un-awakened personality. We
heartily request, to those who may be thinking along such lines,  do not use sui-
cide as an attempt to release yourselves from the body, for this can actually stop the
ascension process.  If the body cannot transmute, but the soul essence is ready to
ride the ascension wave, the soul awareness will arrange for the appropriate
death scenario. The soul uses the body as a means of assembling frequency pat-
terns into the consciousness, and if the body is released prematurely, the con-
sciousness of the individual may not have reached a high enough level to catch
the ascension wave. The body helps the consciousness evolve to higher fre-
quency, and only the greater soul identity knows when the consciousness has
reached a high enough level to ascend properly. Taking matters into the hands
of the personality, such as is the case in suicide, usually botches the soul's ascen-
sion plan, and during the coming ascension wave it is very important that the
personality allow the soul to direct its ascension process. Under no circum-
stances do we endorse suicide as a way of making this transition. If  you are  still in
a body, then that is where your greater soul identity wants you to be, in order to best
facilitate your evolutionary process.  
    The ascension wave offers the souls of Earth the opportunity to reach
their next level of evolution. This evolutionary ful fillment of Earth was fore-
told in ancient stories as the “Return to the Garden of Eden”  or Man's
Ascension to Heaven.  
    The Seventh Race cycle will occur upon T ara many years in the future.
Presently the Sixth Race cycle is just beginning with the third wave of the
Melchizedek Cloister birthing onto the planet. This cycle represents the transi-
tional race cycle as Earth begins to merge with Tara. This transitional cycle,
and the civilizations that will be built through it, represent the coming Fifth
World prophesied in Native American legend. For over one million years all of
your spiritual traditions have, in some way or another, attempted to prepare you
for this point within Earth's time cycle. In the Fifth World, the sixth races will
evolve, followed by the seventh races, and through this evolution you will tran-
scend the mechanics of death, disease and aging, and rediscover the reality of
the Immortal Body and a fully conscious connection to God. The Seventh
Race cycle will assemble DNA strand 6, and open the potential of ascension to
Gaia (Earth-Tara's HU-3 counterpart) following the Taran cycles. The Cloister
42 
 

                                                                            
                                                                                 The Thousand-Years’ War
of the Seventh Race is the  Y unaseti,  and they carry the full 12-strand DNA
package of the Turaneusiam lineage, in operational form. The Seventh Root
Race is the  Euanjhechi , often called the Paradisians ; they carry DNA strands
l-5, and the base codes for 6-12.                        
    Members of the Seventh Race cycle do not experience death, nor do they
breed through physical means but rather through replication of combined
energy fields. They do not carry exaggerated physical gender distinction, but
are rather primarily androgynous, soul-awakened identities. Their bodies are
composed of less dense matter particles and so they are not as strongly bound by
gravity, which allows for mobility far beyond that of your present bodies. They
can travel through time, and often do, such as when they visit your system.
Many of your ET Visitors are actually your Seventh Race relatives from Tara.  (Not
all Visitors are direct relatives to the human.) They represent the races of
which you will one day evolve to become members, when you walk the beauti-
ful lands of Tara and Gaia. The Seventh Races mark the fulfillment of the
human evolutionary imprint and a return to the glorious beings you all once
were before your fall into HU-l. Evolution beyond this stage will take you into
the realms of pure conscious being and into the “God Worlds” where Entities
play. You are the V oyagers, and have always been. lt is time to awaken to the
reality of your journey. And now we will return you to the times of the Second
Seeding 3,700,000 - 848,000 years ago, when your present Fourth World began
as the reseeding of races 3-5 was orchestrated through the Sirian-Human
hybrid race Dagos. Through understanding this history, you will discover the
truth of The Arc of the Covenant , a well kept secret that will directly impact
the course of your evolution over the next 30 years.  
                                        THE THOUSAND-YEARS’ WAR              The Second Seeding, the Drakon and Dracos, the Anunnaki and the
       Nephilim, the Elohim, Seres, Serres and the Egyptians, Return of the
                              Sphere of Amenti, and the Thousand Years’ War  
                                                      3,700,000 -848,800 YA  
    Great hope lived within the promise of the Fifth Root Race Ayrians and
their Hibiru Cloister of the Second Seeding, for they held within their mor-
phogenetic field and DNA imprint the frequency patterns of the fourth
dimension. The Elohim of HU-3 paid special favor to these races and assisted
a few select families, whose codes were not contaminated by mix-breeding.
The Elohim assisted these families in releasing the Seal of Palaidor within
their genetic codes, by transplanting their energetic bodies into Elohim mor-
phogenetic fields.  
    The Elohim hoped that, by the accelerated evolution of these chosen
groups, the vibration rate of Earth's grid could accelerate more rapidly so the
43 
 
                                                                                                                                                                                                                                                                                                                                                                                          

     
       The Second Seeding  
Sphere of Amenti could be returned to Earth's core and the Seal of Palaidor
lifted from all of the races of the Second Seeding. If 8% of the races could
assemble the fourth DNA strand and increase the vibration rate/particle pulsa-
tion rate of their personal bodies and bio-energetic fields, the particles of
Earth's grid would also accelerate to D-4 frequencies, high enough to hold the
Sphere of Amenti with its fourth-dimensional frequency coding. Once the
Sphere of Amenti was returned to Earth's core the souls of the Second Seeding
races could return to their morphogenetic fields upon death and would no
longer suffer the fragmentation of consciousness into the D-4 astral and D-2
elemental kingdoms. With the return of the Sphere morphogenetic field the
memory of the races would be re-entered into Earth's grid and the strand parti-
cles of DNA that brought that memory imprint into the personal cellular mem-
ory would reassemble within the operational DNA strands of the entire fifth
race, returning to the incarnates the memory of their place and purpose within
the evolutionary drama. Opening the Sphere of Amenti within the Earth's core
would automatically accelerate the process of building DNA strands and incar-
national evolution for all of the races, and for those who completed assembly of
the fourth strand the Seal of Amenti would be released, allowing for ascension
to Tara through the Halls of Amenti.  
      The Lamanians and Ur-Antrians and Breanoua, and the A yrians and
Hibiru of the Second Seeding evolved on Earth together 3.7 to one million
years ago. Approximately one million years ago a race called the  Drakon
from HU-1 Orion star system came to Earth and tampered with the genetic
code of the races. They created hybrids within the Root Races called Dracos,
contaminating the human genetic code and altering the evolutionary imprint
for numbers of the Amenti souls. The Drakon race is a sentient, intelligent
race of up-right standing, dragon/lizard-like beings with a tendency toward
aggression and warlike behavior. They represent a digressive strain of a supe-
rior reptile-like race from HU-3 and frequently had poor relations with the
HU-1 Galactic Council. They were expert geneticists and scientists, but
showed little regard for other life-forms and lacked spiritual development.
The Dracos hybrids were more lizard-like in appearance, with body structure
more closely resembling humans, but facial features and temperaments char-
acteristic to the Drakon. The Drakon also tampered with certain strains of
Earth dinosaurs (who were seeded on Earth about 375,000,000 years ago as an
experiment by other ET races), creating aggressive, carnivorous monitors for
their captive human populations. Many of the cultures of the Second Seed-
ing abandoned their advanced surface cultures and retreated underground to
escape the terror of the Drakon monitors. The Phalzants  (Chupacabras)
were also created at this time, combining certain animal strains from the Dra-
kon planets with various Earth animals. The Phalzants and descendants of the
Dracos are presently assisting Zeta Visitors with earthly agendas detrimental to the
44 
      

                                                                                 The Thousand-Years’ War  
human populace.  These intrusive Visitors of Dracos lineage are in reality a
hybrid mutation of our human ancestors who evolved within the Orion star
system. As they are members of the human lineage they feel entitled to use
the territories of Earth, even though their race was banned from here nearly
850,000 years ago by the Breneau. Like most Sirian-Anunnaki strains, the
Dracos also carry the genetic configuration of the “666” Templar-Axion Seal
(previously discussed). The soul essence of the Dracos is part human and part
Drakon.  
    The Drakon and their creations became a menace to the developing
races, and so plans were orchestrated to dispose of the Drakon problem.
About 956,500 years ago, with the assistance of Anunnaki Visitors from Sir-
ius A, the races jointly employed a plan of using the power within the Earth's
grid to destroy the underground habitats of the Drakon and their monitors.
The plan back fired, creating an explosion within the Earth's crust, which cre-
ated climatic anomalies, ﬂooding, a slight pole tilt, destruction of part of the
land masses and finally a small period of global ice that ended about 950,000
years ago. Most of the Drakon left Earth during this period or were destroyed
by climatic conditions. Most of the human races retreated underground, cre-
ating sophisticated cultures beneath the Earth's crust, some races being per-
mitted to enter the portals of the Inner Earth. Once environmental
conditions stabilized, many races returned to surface life, rebuilding their civ-
ilizations. Though most of the Drakon had vacated or perished, they left a
legacy of genetic distortion behind them, that threatened the continuation of
the human lineage.  
    Earth-animal interbreeding became a problem in the races of the Second
Seeding and Host Matrix Transplants  (see V oyagers I , 2e, p. 76.) were being
used to realign the human genetic codes. The races of Amenti began to digress
further due to Drakon contamination of the genetic lines, and several other ET
races used this opportunity to experiment with the human evolutionary
imprint. Some of the more primitive human-like forms of “early man” arose
from such experiments, as did some of the apelike human varieties. But the
human lineage did not originate from these primitive forms. These forms
emerged from the distorted human imprint. Many such mutations were also
created prior to the Electric Wars. The Lamanian and Atlanian cultures frag-
mented, became factions and began warring. The Atlanians of the Second
Seeding were in ﬂuenced by descendants of the Sirian-Anunnaki race from
HU-2 (which later evolved for a time on HU-1 planet Mars), the same race
that had instigated the Taran Templar Solar Initiates' rebellion against the Sir-
ian Council which culminated in the cataclysm of Tara. The Alanian civiliza-
tion began to systematically disregard the Law of One. The Anunnaki brought
to Earth Atlania the creed of the Templar Solar Initiates from Tara, an elitist,
materialistic distortion of the principals of the Law of One, which had created
45 
                                                                                                                                                                    

                 The Second Seeding
     
the cataclysm of Tara. The Anunnaki added their own sexist slant to these
teachings, so women would be viewed as subservient to men and therefore able
to be used as breeders of hybrid children. This teaching was a tactic used to
socially dis-empower women so they would have little support to reject the sex-
ual advances of the Anunnaki males. The Anunnaki created teachings that
made them appear to be the Gods of the human race, and through these teach-
ings were easily able to manipulate the Atlanian cultures into cooperative sub-
mission.  
     The Anunnaki proceeded to bring forth a race of human-Atlanian-
Anunnaki children who were called the Nephilim,  who entered the Earth
system about 950,000 years ago. Having more developed genetic codes via
their Anunnaki fathers, the Nephilim quickly dominated the less developed
humans, creating a highly advanced materialistic culture built upon exploita-
tion of less evolved life forms. Many genetic experiments were carried out,
creating varieties of animal-humans, terribly distorting the human genetic
imprint. Lamanian culture was not affected as greatly by the Anunnaki infil-
tration, as many members of this race retreated into the underground, becom-
ing involved with the Priests of Mu who guarded the portals of the Inner
Earth. (The Taran Priests of Mu commissioned many of their immortal mem-
bers as guardians of the Inner Earth since the beginning of the Turaneusiam-2
experiment). Around this time, 950,000 years ago, the Elohim and Ra Con-
federacy orchestrated massive Host Matrix Transplants, removing the dis-
torted Nephilim racial strains from their connection to the Amenti
morphogenetic field and “splicing them in” to the morphogenetic fields of
other entities from HU-3, HU-4 and HU-5.  
      The transplants were conducted in order to prevent the human morpho-
genetic field from becoming contaminated by the Anunnaki and Drakon
genetic lines, which would have taken human evolution in a completely dif-
ferent direction. In order to orchestrate the transplants certain frequency pat-
terns within the DNA were dismantled, but left within the cells
(contemporary “junk DNA”) so the souls involved could eventually “plug in”
the frequency codes and re-evolve into the Amenti morphogenetic field,
once their code distortions were corrected. The humans involved in the
transplants, who were already genetically altered by the Seals of Amenti and
Palaidor, now had even more genetic distortion to repair, but without the
transplants they would never have ful filled the human evolutionary imprint
to ascend.  
     During the Second Seeding the Elohim motivated the HU-2 Seres race
(descendants of the HU-2 Ceres) to assist in realigning the genetic imprint of
the earthly race strains, and the Seres energetically interbred with certain
members of the Atlanian and Ayrian races, creating a superior guardian race
called the Serres,  who later became known as the Egyptians.  The Egyptians
 were originally one of the seven sub-races within the Atlanian Root Race.
 46 
 

                                                                             
                                                                                                   
                                                                                                     The Thousand-Years’ War
The original morphogenetic field for this sub-race became distorted through
Anunnaki interbreeding of the Nephilim, at which time the Elohim and oth-
ers removed the distorted portions of the Egyptian morphogenetic field from
the Sphere of Amenti, placing this portion of the race under the care of a
Host Matrix Family from the Ra Confederacy called the Aton-A. The por-
tions of the Egyptian sub-race that remained in the Amenti morphogenetic
field were fused with the morphogenetic field provided by the HU-2 Seres,
which created a hybrid Egyptian race called the Serres, who became the
Pharaonic line within Egyptian culture. The Serres-Egyptians began a new
line of Egyptian bearing an advanced genetic strain.  
    Later, during the Third Seeding, the Egyptians carrying Sirian-Anunnaki-
Nephilim morphogenetic fields were remixed with the Serres-Egyptians so the
morphogenetic field of the Sirian-Egyptians could be integrated into the
Sphere of Amenti. Descendants of the Serres-Egyptians held the line of Egyp-
tian royalty throughout the early dynasties, but eventually the Sirian-Egyptians
were integrated into this line and, for a time, open relationships with the Sir-
ian-Anunnaki and Sirian Blue Races resumed. The Egyptians carried a special-
ized genetic code because of this early morphogenetic manipulation. During
the Third Seeding this imprint became even more specialized as portions of the
Egyptian line were adopted by the Sixth Race Cloister Melchizedeks, who
served as a Host Matrix Family to realign an over-development of Anunnaki
genetic coding. Of all the human races to walk the planet, the Egyptians carry
the most diversi fied genetic code. The Melchizedek Egyptians of the Third
Seeding orchestrated the Atonist movement about 3,000 years ago, in order to
redirect Egyptian culture back toward practice of the Law of One, teachings
that had fallen into digression through Anunnaki involvement with Egyptian
culture. The Serres were created during the Second Seeding about 945,000
years ago, their Atlanian sub-race morphogenetic field being merged with the
Breanoua and Hibiru Cloisters of the fourth and fifth races, which brought the
Ayrian and Hibiru lineage into the Atlanian-Egyptian line. This realigned and
advanced the genetic blueprint for the Egyptian subrace, creating what would
                        become the primary Egyptian lineage throughout the Third Seeding.    
        After a period of development, the human evolutionary imprint began to 
prosper, and about 900,000 years ago the Elohim, and the Sirian Council, Seres
and Palaidorians of HU-2, re-entered the Sphere of Amenti into the Earth
core. At this time Sirian-Anunnaki from HU-1 and HU-2, along with Drakon
and other sympathizers, decided to take human evolution in another direction.
Still angered over Elohim interference with their Nephilim race, the Anunnaki
from Sirius A devised a plan to destroy the Sphere of Amenti and utilize the
Earth humans as a worker race to harvest Earth gold for Anunnaki purposes
(the Anunnaki of Sirius A needed gold to replenish depleting elements within
their planetary atmosphere). Wars broke out between the earthly Nephilim
47 
                                                                                                                    
                                                                                                                                                                                                                 
 

    
      The Second Seeding  
and the Serres which escalated about 850,000 years ago into a great intergalac-
tic war between the Elohim and the Anunnaki, each fighting for control of the
Earth territory and the evolutionary direction of the human lineage. This war
became known as the Thousand Years’ War  as it lasted approximately1,200
years (850,000 - 848,800 years ago). Most of the Earth races sought exile in
other planetary systems, some retreated to the Inner Earth and most of the
Nephilim were relocated to Sirius A and later to the planet Nibiru. The few
races remaining on the surface were destroyed by the ravages of high-tech war.
Again the Breneau of HU-5 had to intervene, and about 848,800 years ago
they assisted the Elohim and Sirian-Anunnaki to negotiate a treaty through
which both the Anunnaki and Elohim would assist in the Third Seeding of the
human lineage.         
The Treaty of El-Annu, th e Annu-Melchizedeks, and the A nunnaki
                            Resistance and Templar-Axion Seal  
                                                  848,800 YA   
      The agreement the Breneau negotiated between the Elohim and the
Anunnaki 848,800 years ago was called the Treaty of El-Annu,  through
which it was agreed that the Nephilim would not return to Earth but were
allowed to evolve in other systems, and that attempts would be made to cre-
ate another Anunnaki-human hybrid, but only if the Anunnaki agreed to
uphold the Law of One. The new hybrid race would be entered into the
human morphogenetic field through the Sixth Race Melchizedek Cloister,
and through this cloister the remaining Atlanian-Egyptian-Nephilim-Aton
A souls from the previous Host Matrix Transplants could be re-integrated
into the Sphere of Amenti. The new hybrid Melchizedek/Anunnaki race
would be called the Annu, and would be entered into Earth through combin-
ing the fifth race Melchizedek Cloister with the fourth race Atlantean-Egyp-
tian sub-race, during the Third Seeding. The Melchizedek Cloister would
serve as a Host Matrix Family for the Annu and later the remaining portions
of the Egyptian-Nephilim morphogenetic field, which had been place with
the Aton-A Host Matrix Family, would be integrated into the Melchizedek
line. The treaty was created in order to end the war through agreements that
were fair to everyone, allowing the Anunnaki to advance the spiritual aspects
of their evolution through working with the Law of One, while allowing
human evolution to remain on course.  
    The Treaty of El-Annu created a division within the ranks of the Anun-
naki races, and between the Anunnaki and their sister race the Sirian Blues
from Sirius A, who like the Kantarians of Sirius B, served the Law of One and
accepted the authority of the HU-2 Sirian Council. Not all of the Anunnaki
agreed to this treaty, and those who continued to pose a threat to Earth secu-
rity were banned from Earth visitation, and became known as the Anunnaki
Resistance.  The few remaining Dracos hybrids that had previously found
48 
 
 

                                                                            
                                                                                                    The Thousand-Years’ War
exile on Sirius A with the Anunnaki joined in the Anunnaki Resistance, and
motivated their Drakon forefathers to join forces with the Anunnaki Resis-
tance, with the intent of destroying the Sphere of Amenti. In an attempt to
promote inter-galactic peace and safety for those to evolve on Earth, the Sir-
ian Council of HU-2 petitioned the Ra Confederacy and Axious Family Enti-
ties from the Metagalactic Core to intervene on behalf of the Treaty of El-
Annu. These Entity Families agreed, and the first administration of the Tem-
plar-Axion Seal  (the “666” genetic con figuration) was applied to the mor-
phogenetic field of those of the Anunnaki Resistance. The Seal was also
applied to the morphogenetic field of the Dracos hybrids. Neither strain
could now inter-breed with other species who did not carry the imprint of
their gene code. For those of the Anunnaki Resistance, the children of Annu
offered the only hope of their hybridization or reintegration on Earth, so even
before they were conceived in ﬂesh the children of Annu became a target for
infiltration by the Anunnaki Resistance. With the Treaty of El-Annu the
Thousand Years’ War was brought to a close, and the division between those
who served the Law of One and those who did not became more clearly
defined. Great protection was needed for the races of the Third Seeding, for
the Dracos, Drakon and the Anunnaki Resistance desired to see their
destruction. The Thousand Years’ War between the Elohim and the Anun-
naki brought an end to the Second Seeding of the human lineage on Earth.
  
       49    
                                                                                                                                                                                                                 

                                                     
                                                    3                            
                                    
                                                               
                             
                                                          
                               
                                     The Third Seeding                                  
                                    
                                                          THE ARC OF THE COVENANT    
                           Creation of the Arc of the Covenant, Removing the Sph ere of Amenti,      
the Flood, the Andromeda Galaxy, the Sirian-Arcturian Coalition for
     Interplanetary Defense and the lnterdimensional Association of Free  
             Worlds, the Urtites, Serres-Egyptians and the Priesthood of UR.  
                                                   849,000 - 800,000 YA  
      The Sphere of Amenti had been returned to Earth's core by the Elohim,
and the Sirian Council, Seres and Palaidorians of HU-2 about 900,000 years
ago, accelerating assembly of the DNA strands and releasing the Seal of
Palaidor for some strains of the races from the Second Seeding. Some groups
were able to evolve enough to release the Seal of Amenti from their DNA,
which allowed them to ascend through the Halls of Amenti back to Tara. All
was going according to plan until the outbreak of the Thousand Years’ War
850,000 years ago. Following the outbreak and escalation of the war and the
Anunnaki's intentions of destroying the Sphere of Amenti in order to use
humans as a worker race, it was no longer safe to keep the Sphere of  Amenti
within the Earth's core, as Anunnaki operatives could easily discover access to
its D-2 resting place. Under the command of the Breneau and the Ra Confed-
eracy, the Sirian Council of HU-2 assisted the Seres of HU-2 and the Elohim
in once again removing the Sphere of Amenti from the Earth. The Sphere of 
Amenti was removed from the Earth and placed within a secured location about 
849,000 years ago. The Sphere was placed within a planetary core in the
Andromeda galaxy, under high security and held there in exclusion until the
close of the Thousand Years’ War —848,800 years ago.  
       With the implementation of the Treaty of El-Annu, and the threat of the
Anunnaki Resistance, a multidimensional, intergalactic effort was made to
ensure protection for the Sphere of Amenti. The Sirian Council of HU-2
petitioned assistance from numerous star systems in HU-1 and HU-2 to pro-
50 


                                                                                  
                                                                                 The Arc of the Covenant
vide security. Races from the Arcturus and some from the Pleiadian systems
offered assistance, as many humans had, during the course of their troubled
evolution, found exile within the Pleiadian and Arcturian cultures; coopera-
tion was given from both HU-1 and HU-2 members of these races. The Sir-
ian Council of HU-2 formed an organization with pro-human members of the
HU-1 Sirians and several cultures from Arcturus, called the Sirian-Arcturian
Coalition for Interplanetary Defense,  through which the hidden Sphere of
Amenti, Earth and its allies would be protected if need arose. This organiza-
tion was later invited to join a much larger interdimensional guardian group
known as the Interdimensional Association of Free Worlds , whose member-
ship extended well into the highest Harmonic Universes. Though many races
in the Andromeda galaxy were already members of this collective, the Asso-
ciation of Planets in Andromeda  would not agree to military involvement,
as they were not entirely supportive of the conditions of the Treaty of El-
Annu. They did, however, allow the Sphere of Amenti to remain hidden
within a secret location in their star system.  
    Following the removal of the Sphere of Amenti 849,000 years ago, the
Earth once again endured a series of climatic and geographical changes as
Earth's energetic grid re-balanced following the removal of the Sphere.
Again ﬂood waters rose, covering portions of Earth's surface. In historical
record, this time period became interwoven with the early ﬂooding associated
with the Electric Wars, and a later time period of ﬂooding, all consolidated
into the story of your Biblical Flood. The Guardian organizations knew that
the Third Seeding of the human lineage would have to be orchestrated once
the planetary environment re-balanced. But the Third Seeding could not
take place directly through Earth's core as the Sphere of Amenti morphoge-
netic field was now in the Andromeda galaxy. The Third Eye of Horus portal
through which the Second Seeding took place would no longer be useful as
its connection to the Sphere of Amenti had been severed, so a new portal
bridge needed to be created between the Andromeda galaxy and Earth in
order for the Third Seeding to take place. The Third Eye of Horus portal
bridge remained open as a passage between Earth and Sirius B (frequently
used by the Kantarians of Sirius B for visitation during the Third Seeding),
but it no longer connected to the Sphere of Amenti and so could not be used
for ascension to Tara.  
                                             The Arc of the Covenant  
                                                          840,000 YA        
       A  portal bridge between the Sphere of Amenti in the Andromeda galaxy
and the Earth's D-2 core was constructed by the Guardian organizations
about 840,000 years ago. This inter-galactic bridge was called the  Arch of the
   Covenant of Palaidor , and later became known as the Arc of the Covenant.
Through the Arc of the Covenant the race souls of the Sphere of Amenti
51 
                                                                                                                                    
                                                                                                                                                                                                                              

    
         The Third Seeding        
could once again be reseeded on Earth. Souls from the Sphere of Amenti
would pass through the Arc/bridge as pure consciousness, merge with the
Earth's morphogenetic field in D-2, then birth into physical manifestation. A
fifth-dimensional security seal was placed upon the Arc of the Covenant,
which meant that this portal operated as a “one-way door”; souls of the races
could descend through the passageway but could not return to the Amenti
morphogenetic field for ascension unless they had fifth-dimensional coding in
their gene structure. This genetic ticket to freedom became known as the
Shield of the Arc,  and the incarnates who bore this fifth-dimensional Shield
within their genetic code could pass through the Seal on the Arc of the Cov-
enant and return, through Amenti, to Tara. As races 3, 4 and 5 did not have
the fifth DNA strand within their genetic imprint, they could not return
through the Arc, even as consciousness, unless the Seals of Palaidor and
Amenti were released.  
    Release of the Seal of Amenti would allow these races to merge with
their anti-particles and pick up the fifth strand, but first the fourth-dimen-
sional Seal of Palaidor had to be released. Evolution would take time for races
3-5 of the Third Seeding. Those who could not reenter the Amenti morpho-
genetic field would evolve within the fourth-dimensional astral planes
between incarnations, along with those identity fragments created through
the Seal of Palaidor, until the time when the Arc of the Covenant was
opened and the fifth-dimensional Seal on the Arc released. The sixth race
Muvarians and their Melchizedek Cloister then held the key to ascension, as
the fifth DNA strand was included in their genetic imprint. The sixth races
would be born with the Shield of the Arc in their genetic code, and as the
Anunnaki-human hybrids Annu were to be seeded through the Melchizedek
Cloister —the Annu would also bear the Shield of the Arc. Those bearing the
Shield of the Arc would become the Earth guardians of the Arc of the Cove-
nant and the Sphere of Amenti.  
     The Arc of the Covenant was designed in such a way that the Sphere of Amenti
could eventually be re-entered into the Earth core through the portal bridge of the Arc.
In this way the Arc became self-regulating. The return of the Sphere of Amenti
would depend upon conditions in the Earth's planetary grid, and the Guardians
would not have to reenter the Sphere. The fifth-dimensional Seal on the Arc
of the Covenant was designed to be released once a certain percentage of the
Earth's population had assembled the fifth DNA strand, which meant that a
certain number of the Melchizedek Cloister would have to be born upon the
planet. If   8% of the living population could assemble the fifth DNA strand, the
Earth's grid vibration would rise, affecting the vibrational speed of the energy
particles within D-2 Earth core. As the D-2 particles began to vibrate faster a
blue-white spark of fifth-dimensional high-frequency energy would be sent up
from the Earth core, through the portal bridge of the Arc of the Covenant.
This spark would penetrate the fifth-dimensional Seal on the Arc and enter the
52 
  
                                                                                      

                                                                                       
                                                                                       The Arc of the Covenant  
Blue Flame within the Sphere of Amenti. The Blue Flame would then send a
corresponding    spark       of      fifth-dimensional frequency      back     into      the       Earth's  core,
which would open the Earth's morphogenetic field to accept the Sphere of
Amenti, while raising the Earth's grid speed high enough to hold the D-5 Blue
Flame morphogenetic field of Tara.  
    Upon the second spark, the Sphere of Amenti would begin its descent
through the Arc of the Covenant, while the Blue Flame remained within the
Andromeda planet. Originally, the descent of the Sphere of Amenti was to
take about 2,000 years, its energies becoming progressively more available to
the peoples of Earth, stimulating the assembly of the fifth DNA strand and
the raising of consciousness. During its 2,000-year descent, the Earth grid
speed would rise in increments, allowing the Earth's energy system to adjust
to the increasing infusion of high-frequency energy. Once the Sphere was re-
positioned within the Earth core, there would be a period of several years for
the Earth grid to assimilate the new frequency, and the race memory would
progressively infuse the Earth grid. As the race memory from the Amenti
morphogenetic field filtered through the Earth grid, this energy would stimu-
late the DNA of everyone on the planet, and the lost memory would reenter
the cellular memory of individuals as their DNA strands began to assemble
through the new fifth-dimensional frequency now available to them through
the Earth core. Over the course of those several years the races would evolve
rapidly and a mass awakening to the lost memory of multidimensional reality
would occur within large numbers of the population. Through these ener-
getic processes the Earth and her people would be prepared to receive the
Blue Flame of Amenti.  
        The Blue Flame would begin a rapid descent to Earth core following the open-
ing of the Arc of the Covenant.  It would take approximately 12 years for the
Blue Flame to descend to Earth through the Arc of the Covenant. Return of
the Blue Flame was a very precise process, and had to be orchestrated in syn-
chronization with the natural time cycles of which Earth was a part —enter-
ing Earth during the period of natural dimensional blending that occurs at
various times within Earth's time cycle. Timing was very important in the
return of the Blue Flame, as certain conditions had to be planned in advance
of its return. During the dimensional blend the Blue Flame could not directly
enter the Sphere of Amenti as the Sphere would be connected to the Earth's
morphogenetic field at D-2. The Inner Earth portals to D-2 open during the
dimensional blending period, and if the fifth-dimensional frequencies of the
Blue Flame merged directly with the second-dimensional frequencies of
Earth's core, Earth's planetary grid would explode. The fifth-dimensional fre-
quencies had to be dispersed through the Earth grid, via the energetic fields of
certain people alive on the planet. The bio-energetic fields of those individu-
als would serve as frequency modulators for the fifth-dimensional energy.
These individuals would hold the D-5 frequency of the Blue Flame within     
53                                                                                                             
                                                                                                                     

  
   The Third Seeding  
their own energy system through the height of the dimensional blending,
then when the natural cycle of dimensional blend reached its close, the Blue
Flame would be returned to the Sphere of Amenti at Earth's core and the
Halls of Amenti —the ascension portals to Tara —would open to those on the
planet who had assembled the fifth DNA strand and could pass through the
Blue Flame. For people who had not yet assembled the fifth strand, much
information on how to go about accelerating this process would be made
available, as the memory banks of the race would be restored. As long as the
Blue Flame remained within the Sphere of Amenti at Earth's core, the ascen-
sion portals to Tara would remain open to the races, allowing them to evolve
rapidly and complete their tour of incarnational duty on Earth. The souls
trapped within the D-4 astral and D-2 elemental kingdoms could also com-
   plete their evolution and ascend.  
       The individuals who would be responsible for holding the fifth-dimen-
sional frequency within their bio-energetic field during the time of transition
are called Keepers of the Flame,  and they would, over a period of years, dis-
pense the fifth-dimensional frequencies throughout large numbers of the pop-
ulation, assisting the populace to assemble the fifth DNA strand, expand
their consciousness and transmute their bodies, so portions of the population
could “catch the morphogenetic wave” (discussed later) and pass through the
Halls of Amenti on the wave, while the dimensional blend was still in effect.
Once the cycle of dimensional blending was through, the Flame would be
placed back in the Sphere and the remaining populations would continue to
evolve on Earth until the next morphogenetic wave. The people who were
able to catch the first wave would find themselves teleported into the future,
where they would appear on the Taran land mass that was once called the
continent of Mu. This Taran location represents the primary reality of Earth
as it exists about 2,500 years in the future —the version of Earth whose grid
has completed its merger with Tara. This path of accelerated evolution con-
stitutes leaping past 2,500 years of evolution within Earth's present time con-
tinuum, and represents literal, biological time travel into the future. With the
opening or “sparking” of the Arc of the Covenant, this path of accelerated
   evolution would become available to some humans on Earth.  
       The Keepers of the Flame would be responsible for assisting people who
were ready to take this morphogenetic wave voyage in preparing their bodies
and consciousness for this transition. The Keepers of the Flame would receive
their infusion of D-5 frequency from one primary individual who had the
genetic code that would allow the Flame to be fully embodied as it passed
through the Arc of the Covenant. That person is called the Flame Bearer or
the Staff Holder.  The Flame Bearer would have to activate the 12-strand
DNA package within the body before being able to embody the Flame. This
person would incarnate with a support team of six fully activated 12-strand
avatars (souls from the fourth Harmonic Universe), who would raise the
54 
 
 

                                                                             
                                                                                 The Arc of the Covenant
planetary frequency high enough to allow the Flame Bearer to fully activate
the codes. Due to the bio-energetic mechanics of the human body, the Flame
Bearer would have to be female in gender, the avatars all male, in order to
keep the energetic balances of the planetary grid intact.  
     During the opening of the Arc of the Covenant there would also be a fam-
ily of individuals appointed to embody the Rod, the orange-gold Flame mor-
phogenetic field of Earth, during the time of transition. The Rod Holder would
be male. Members of these specialized incarnational groups would have to
incarnate in the proper sequence, within the right time periods in conjunction
with the Earth's time cycles, and within the appropriate genetic lineages that
would provide them with the needed genetic imprint. The process of opening
the Arc of the Covenant and allowing the Sphere of Amenti to return to Earth
required a tremendous amount of multidimensional organization. The ful fill-
ment of the promise of the Arc of the Covenant would take over 800,000 years
to ful fill, and meanwhile the races of the Third Seeding would begin their evo-
lutionary journey toward that destination.       
   The Third Seeding through the Arc of the Covenant, the Hebrew,  
           Serres-Egyptians, Urites and the Priesthood of Ur, Races 3-6  
                                     and the Annu-Melchizedeks  
                                             800,000 - 55,000 YA   
      For a period of time following the creation of the Arc of the Covenant
840,000 years ago the Earth went through a period of re-balancing its ener-
getic grid, and during this time the races did not evolve on the planet's sur-
face. Some descendants of the Second Seeding prospered within the lnner
Earth communities, and a few scattered groups had managed to survive
within the underground tunnel systems created by those of the Second Seed-
ing. Most of the human population had ﬂed, finding exile within other plane-
tary systems. The Nephilim had been evacuated to Sirius A, joining
remnants of the Dracos race who had found exile with those who became the
Anunnaki Resistance. About 800,000 years ago several groups of the now
extraterrestrial humans returned to Earth to begin preparation for the Third
Seeding, which would be orchestrated through the Arc of the Covenant por-
tal bridge. Two primary groups of returning humans, descendants of the
Serres-Egyptians  and the Hebrew (Melchizedek-Hibiru hybrids) from the
Second Seeding, were commissioned by the Palaidorians of HU-2, the Elo-
him and the Ra Confederacy to orchestrate the Third Seeding.  
    Upon returning to Earth, these groups discovered that there was a small
group of survivors remaining from the Second Seeding, descendants of the
Third race Lamanians  and their Ur-Antrian  Cloister . The Serres-Egyptians
(who had been exiled on Sirius B and in the Pleiadian star systems, and thus
now carried a stronger ET imprint within their genetic codes) interbred with
55 
                                                                                                                
                                                                                                                      

The Third Seeding  
the Lamanians and Ur-Antrians, forming a new guardian race through incar-
nating souls via the Melchizedek Cloister morphogenetic field via the Arc of
the Covenant. The new race was called the Urtites ; they appeared on Earth
about 800,000 years ago and, working with races of the Inner Earth and the
HU-2 Palaidorians, the Urtites established the Priesthood of Ur  on Earth.
The Urtites lived primarily underground and within the Inner Earth civiliza-
tions, serving as guardians of the Arc of the Covenant. When conditions on
    Earth were conducive to supporting mass surface life, the Urtites were given
authority by the HU-2 Sirian Council, Ra Confederacy and Priests of Ur on
Tara, to begin the Third Seeding of the human lineage. Many sub-races and
families emerged through the Urtite genetic strain, as each of the five Clois-
ter races birthed their race line through the Urtite Host Race. The races were
located throughout various regions of the globe, each developing surface cul-
tures from about 750,000 to 75,000 years ago. The Urtite lineage developed
divergent cultures extending from what is now known as Africa, through
regions of East Asia, North and South America, central Europe, Egypt and
into what is now called Iran. Through development of these diversi fied cul-
tures, the Host Race Urtites created a new cradle of civilization through
which the Root Races and their Cloisters could be reseeded on Earth.  
     The Third Seeding of races three, four and five began again via the Arc of
the Covenant, under the direction and through the lineage of the Urtites. The
third race Ur-Antrian Cloister began birthing about 75,000 years ago, their
Lamanian Root Race 73,000 years ago. The Lamanians of the Third Seeding
were called the Lemurians,  and they were seeded on a land mass that existed in
the area now occupied by parts of the Pacific Ocean and also within the region
of the Andes Mountains. The Breanoua Cloister of the fourth race entered
about 72,000 years ago in lands that existed in the area now occupied by parts
of the Atlantic Ocean, and into the territories that became known as Egypt,
followed by their Root Race Atlanians 70,000 years ago. The Atlanians of the
Third Seeding became the Atlanteans.  The fifth race Hibiru Cloister entered
through the Host Matrix of the sixth race Melchizedek Cloister into various
positions throughout the globe, about 68,000 years ago, followed by their Root
Race Ayrians 65,000 years ago. The fifth Root Race Ayrians of the Third Seed-
ing were called the Aryans, concentrations of this race were seeded into
regions near what is now called the Black Sea and in the area of what became
the Carpathian Mountains.  
    The Annu-Melchizedeks were seeded into the Atlantean Root Race-
Egyptian sub-race through the Melchizedek Cloister Host Matrix morphoge-
netic field about 68,000 years ago. The Annu prospered in Atlantis, many
migrating to various parts of the globe and interbreeding with other races.
    The primary concentration of Annu remained in Atlantis, where open lines
 of commerce with their Sirian-Anunnaki forefathers became a standard way
 56 
 
 

                                                                                   
                                                                              The Arc of the Covenant
of life. The Anunnaki who had joined the Sirian Council through the Treaty
of El-Annu, and the Sirian-Kantarians and Sirian-Blue races of Sirius B,
became a primary motivating force within Atlantean culture, and the Pleia-
dian races of HU-1 assisted in the development of Ur-Antrian and Lemurian
culture. These cultures thrived under the influence of the advanced stellar
races. The Annu-Melchizedeks organized their cultures around the spiritual
and scientific teachings of the Law of One. Members of the Hibiru Cloister
and the hybrid Hebrew peoples migrated from other regions to both Atlantis
and Lemuria, each bringing with them the teachings of the Law of One char-
acteristic of the Melchizedek Host Matrix.  
    As civilization on Earth prospered, the Sirian Council allowed the
Atlantean and Lemurian cultures to receive gifts from the advanced stellar
races, which rapidly developed the technological aspects of society to heights
far exceeding present earthly cultures. The Sirian-Blues of Sirius B brought
large crystalline power generators to Earth as a gift to the Atlantean and
Lemurian cultures. They taught the Ur-Antrians, Lemurians, Annu and
Atlanteans how to draw energy directly from the D-2 Earth core, and store
this energy within the crystal generators. Permission was granted by the Elo-
him and Ra Confederacy to allow power to be drawn from the Blue Flame of
Amenti through the passageway of the Arc of the Covenant. The power of the
Blue Flame allowed Atlantean civilization to access multidimensional frequency,
through which the morphogenetic ﬁelds of Earth's matter particles could be directly
affected . Earth's gravitational pull could be neutralized, objects could be man-
ifested and de-manifested, objects could be teleported to desired locations,
bio-energetic healing became a way of life and genetic evolution was acceler-
ated. Using the power of ET technology the Atlantean and Lemurian cul-
tures thrived.  
    The Annu and Hebrew peoples of the Melchizedek Cloister Host Matrix
became the primary Earth guardians of the Arc of the Covenant. The original por-
tal passage to the Arc of the Covenant was located within the land mass of
the Atlantean continent, and through this interstellar passageway power was
fed through the Earth's grid to the Lemurian continent and various other
developing civilizations. Earth civilizations thrived following the Law of One
until about 55,000 years ago, when members of the Anunnaki Resistance
began to in filtrate Atlantean culture, creating genetic and social digression
that nearly brought Atlantis to an end.  
57 
 

 The Third Seeding                                                                                                                                                               
                                             LEMURIA DESTROYED  
        Anunnaki Resistance,  Annu and the Dracos, Destruction of Lem urian
                     Muarivhi, & Relocating the Arc of the Covenant  
                                               55,000 - 51,750 YA  
     
   As Atlantean and Lemurian cultures thrived, other stellar cultures
watched and waited. Members of the Anunnaki Resistance and their Drakon
and Dracos allies had long planned to overtake Earth territories, waiting until
the growing civilizations had reached a height of maturity. Motivated by their
own desires to utilize Earth as an evolutionary option, the Anunnaki Resis-
tance quietly infiltrated Atlantean culture about 55,000 years ago, covertly
moving within the ranks of Anunnaki of the Sirian Council. Once re-estab-
lished on Earth, the Anunnaki Resistance inter-bred with the Annu, and
over a period of generations distorted the Annu genetic lines with the Tem-
plar Seal (which had been placed on the Anunnaki Resistance following
their refusal to accept the Treaty of El-Annu). The teachings of the Law of
One were slowly distorted as the creed of the Templar Solar Initiates of Tara
(which the HU-2 Anunnaki Rebellion had helped devise), came to replace
the sacred teachings, creating division and social unrest within Atlantean
civilization. The Anunnaki-Annu began to spread their influence into other
cultures, gaining covert control over Egyptian lands and several other smaller
cultural centers.  
    About 52,000 years ago the T emplar-Annu allowed the Resistance allies,
the Dracos, to secretly return to Earth, promising them an earthly home if
they would assist in infiltration of the Earth cultures. The Dracos in filtrated
the Lemurian continent of Muarivhi, creating an extensive network of
underground lairs within the tunnel systems that ran between Lemuria and
Atlantis. Systematically the aggressive Dracos began terrorizing the Lemurian
culture, extending the reign of terror into Atlantis and various other places.
Meetings were held by representatives of all the races through which a plan
was devised to end the Dracos problem. The humans hoped to use the gener-
ator crystals to create small, pin-point explosions within the underground
caverns in order to seal the Dracos within their lairs until the Sirian Council
could come and evacuate the Dracos. But the plan back- fired, as the Earth
grid became energetically overloaded by energy from the generator crystals
and a massive explosion occurred within the lands beneath Muarivhi. The
explosion destroyed the land mass of Lemurian civilization and remnants of the
Lemurians integrated into Atlantean territories.  
      The explosion caused massive volcanic activity , earthquakes and ﬂoods,
and though the Atlantean continent did not suffer massive destruction, it took
generations for them to rebuild, and for the Earth to rebalance her grid. A small
period of ice followed these events, during which most of the races retreated
underground, some permanently entering the Inner Earth. After the surface
58 
 
                                                                                                                                                                       

                                                                                          
                                                                                              
                                                                       Giza to Atlantis
environment stabilized most of the remaining races returned to the surface to
rebuild. Atlantis again became a cultural center, but never again reached its
previous height of development. Most of the Dracos were evacuated from Earth
by their Anunnaki-Resistance accomplices, and the Templar-Annu continued
to hold their ground within Atlantean and Egyptian cultures.  
    Following the cataclysm of 52,000 years ago the Anunnaki of the Sirian
Council and several other stellar neighbors returned to Earth, assisting the
humans to rebuild. During the explosions beneath the ground the portal pas-
sage to the Arc of the Covenant had been damaged, and the energetic grid
beneath the Atlantean continent was unstable. The Elohim, Ra Confederacy
and other guardian groups from HU-2 restructured the Arc of the Covenant,
moving the portal that connected it to Earth out of Atlantis and into the
regions of Egypt, where the Earth grid structure was more stable. The Serres-
Egyptian races would now share guardianship and control of the Arc of the
Covenant with the Annu-Melchizedeks and Hebrew peoples who migrated
there following the explosions. The cultural hub of Earth was relocated from
Atlantis to Egypt about 51,750 years ago, and Egypt began to thrive.  
                                      
                                        GIZA TO ATLANTIS       
      Anunnaki of the Sirian Council and Earth Protection, the First  
       Building of the Great Pyramid of Giza and the Sphinx, Ankhs,  
           Outpost on Mars, First Birth Wave of Melchizedek Cloister  
                         and Re-establishment of the Law of One.  
                                          48,500 - 35,000 YA           
    Following the relocation of the Arc of the Covenant 51,750 years ago,
Egyptian culture prospered, and Egypt became a center for the Annu-
Melchizedek, Hebrew and Serres-Egyptian guardians of the Arc of the Cove-
nant. Atlantean culture also prospered as the generator crystals were once
again restored to operation after being put out of service during the Lemurian
cataclysm 52,000 years ago. The generator crystals were once again charged
with multidimensional frequency using the Arc of the Covenant in Egypt.
Through this period of rebuilding and expansion the influence of the Tem-
Plar-Annu (Annu whose genetic line had been contaminated by the Templar
Seal through interbreeding with members of the Anunnaki Resistance) con-
tinued to spread, creating a growing chasm between races serving the Law of
One and those falling under the in ﬂuence of the Anunnaki Resistance Tem-
plar Solar Initiates' Creed. In Egypt the Templar-Annu were at first met with
resistance to this influence, and many of them relocated to Atlantis where
the Templar-Annu had a stronger hold over the cultural environment. The
Templar-Annu of Atlantis began using their influence to corrupt the
Atlantean priest cast and eventually the social and moral climate in Atlantis
59 
                                                                                                                                                                                                
   

The Third Seeding  
declined under their influence. Motivated by the Anunnaki Resistance, the
Templar-Annu began to dominate the races of Atlantean culture, and made
plans to conquer the lands of the Inner Earth. They planned to use the gener-
ator crystals to break through the electromagnetic barrier which protected
the portals of the Inner Earth.  
    Concerned for the welfare of the Inner Earth civilizations, and the high
concentration of Annu-Melchizedeks residing there, the Anunnaki of the
Sirian Council petitioned the Interdimensional Association of Free Worlds
for permission to make a show of strength on Earth, offering the races protec-
tion against increasing Anunnaki Resistance infiltration. Permission was
granted and the Sirian-Arcturian Coalition for Interplanetary Defense was
called in to assist in this protective mission. The primary target for Anunnaki
Resistance manipulation was the area in which the  Arc of the Covenant  was
located, so Egypt became the focus of Sirian Council activity. Anunnaki of the
Sirian Council were first sent to the planet Mars to recreate an observational
outpost that had been constructed there during the Thousand Years’ War,
which they hoped would intimidate the Anunnaki Resistance from further
interference with Earth. Undaunted by the presence of the Sirian Council,
the Anunnaki Resistance escalated their involvement with Atlantis and
began a resurgence of their in ﬂuence in Egypt, posing a greater threat to the
security of the Arc of the Covenant.  
    About 48,500 years ago the Sirian Council instructed their Anunnaki
members to make a direct show of power in Egypt and Atlantis. Anunnaki of
the Sirian Council visited these civilizations en masse , reasserting the inﬂu-
ence of the Law of One and driving many Templar-Annu out of Egypt and
back to Atlantis, where they would pose less threat to the Arc of the Cove-
nant. In Egypt, and in several other locations on the globe, the portals of the
Inner Earth were fortified as the Sirian Council Anunnaki built bases of oper-
ation on the Earth's surface, directly over the portal regions. The pyramid
structure was a trademark of Anunnaki architecture and scientific achieve-
ment, and several small pyramid structures were constructed above portal
passage areas throughout Egypt. The greatest of these operations bases was
constructed over the main Egyptian portal opening to the Inner Earth,
through which the Arc of the Covenant portal could be accessed. At the
same time another massive structure was constructed over the nearby portal
of the Arc of the Covenant.  
          The ﬁrst monument to be created was the original Sphinx. This building cov-
ered the portal to the Inner Earth and linked directly into the portal passage
that led to the Arc of the Covenant. The Sphinx was designed following
Anunnaki heritage, having the head of an Anunnaki warrior placed upon the
body of a lion-like sculpture. The lion's body of the Sphinx was a symbolic
tribute to a race of beings from HU-2 known as the Leonines, who were
instrumental in laying the early foundations of Anunnaki culture. The Leo-
60 
  
      

                                                                                             
                                                                                                                       
                                                                                                                              
                                Giza to Atlantis
nine beings of HU-2, who were large, upright, fur-covered felines of advanced
intelligence, were revered as Godlike by the early Anunnaki civilizations,
and the Anunnaki of the Sirian Council paid tribute to this heritage. The
Anunnaki of the Sirian Council drew strength and comfort from their affilia-
tion with the Leonine people, and, by constructing this monument, intended
to show the power of the Anunnaki united and built upon their Leonine
ancestral allies. The symbolic design of the Sphinx was intended to show the
Anunnaki Resistance that they were alone in their conquest and that the
true Anunnaki heritage stood behind the Anunnaki of the Sirian Council. In
practical terms, the Sphinx was constructed to serve as a fortification for the
Inner Earth portal and also as a safe house and library for the storage of sacred
records and texts. It also served the purpose of housing the great energy-
transmitting machines that were charged with UHF fifth-dimensional energy
from the Arc of the Covenant, and the smaller Ankhs which were infused
with energy in a similar fashion.  
     Historically , the larger machines became known as Arcs of the Covenant,
and the true identity of the Arc of the Covenant as being a portal bridge was
lost. But during the time of the original building of the Sphinx the truth of the
Arc of the Covenant was well known, and the objects were understood as tools
which could draw, hold and transmit energy that was drawn, through the Arc
of the Covenant, from the Blue Flame of Amenti that was stored in the
Andromeda galaxy. Both the large and small tools were designed in the shape
of the Ankh, which allowed high frequency energy to be synthesized in specific
ways following the natural laws of interdimensional energy mechanics. The
Ankhs were used to create the Spinx, various pyramids, and other structures as they 
provided the power to reverse gravitional pull and directly affect the particle make-up
and    morphogentic    ﬁelds of   Earth  matter  substance.  They served  as major construc -    
tion tools, weather modulators, healing tools and as interdimensional transit
devices. The original Sphinx served as a protective fortress in which these
devices could be stored and kept out of the hands of the Templar-Annu.  
    The second major construction of the Sirian Council Anunnaki was a
massive pyramid centered directly over the portal opening to the Arc of the
Covenant. This pyramid was originally constructed during the same time
period as the Sphinx, about 48,459 years ago (about 46,459 BC). The recon-
struction of this pyramid, which occurred about 12,550 years ago (10,500 BC)
then again about 11,000 years ago (9,000 BC) is what has come to be known in
modern times as the Great Pyramid of Giza, the Cheops pyramid. This struc-
ture was reconstructed and repaired on numerous occasions. It was designed
and erected by the Anunnaki of the Sirian Council, the Annu-Melchizedeks,
Hebrew, and Serres-Egyptian peoples from that time period. The pyramid was
not constructed to serve as a burial tomb, though much later it was used as
61 
                                                                                                                         
                                                                                                                              

The Third Seeding
such.  The  primary purpose of the Great Pyramid of Giza was to fortify the portal of
the Arc of the Covenant and to serve as an interdimensional teleportation center.  
    The original pyramid was designed as a Harmonic Resonance Chamber,
through which multidimensional frequency bands could be pulled in from deep
space and from the planetary core of Sirius B, using a great ankh positioned
directly below a crystalline cap stone. Through the power of the ankh a tre-
mendous amount of UHF energy was pulled into focus within the cap stone of
the pyramid, then projected downward through the structure into the second-
dimensional frequency bands. The pyramid and Arc of the Covenant were situated
upon Earth's geographical center point, within the energy vortex that represented the
“Heart Chakra" within Earth's planetary bio-energetic system . This vortex allowed
energy exchange to take place between Earth and the fourth-dimensional fre-
quency bands. By creating a Harmonic Resonance Chamber within such an
interdimensional vortex, the D-2 overtones of HU-1 could be combined with
the base tones of D-4/HU-2, forming an interdimensional resonant tone
through which visiting craft traveling from Sirius B and other star systems
could enter and leap through time, making transit to Earth almost instanta-
neous. The Great Pyramid was created to allow immediate intervention of the
Sirian Council and Galactic Federation ﬂeets should the Arc of the Covenant
come under Anunnaki Resistance attack. While the pyramid was in operation
as an interstellar teleport station, it served as the greatest deterrent to an
Anunnaki Resistance invasion. The Great Pyramid was used as an active inter-
stellar teleport station from the time of its construction 48,459 years ago to
about 30,000 years ago (about 28,000 BC) when an explosion in Atlantis
caused Earth to tilt slightly on its axis, knocking the pyramid's D-4 vortex
(Earth's heart chakra) out of its previous alignment with the vortex systems of
Sirius B and several other planetary systems to which it had been originally
aligned. ET visitation was commonplace in Egypt prior to this mis-alignment of
the Earth's grid, but following this event, transit from other star systems
required more time and resources, so visitation became much less frequent.  
    Throughout the height of its operation (46,459 BC-28,000 BC) the
Great Pyramid of Giza was also used as an ascension chamber for the select
few who possessed the required DNA assembly and favor of the Elohim. Such
individuals were allowed passage through the Arc of the Covenant if the Elo-
him approved and opened the passageway, and some were able to ascend to
Tara. The pyramid was used as a training school for initiates to the
Melchizedek/Elohim ascension program, and also for healing, accelerating
genetic assembly and for passage into the Inner Earth portals beneath the
Sphinx. The pyramid was always kept under tight security by the resident
Anunnaki of the Sirian Council, and the Templar-Annu were banned from
entering the premises. This created much hostility between the Templar-
Annu and the Egyptian cultures operating under the protection of the Sirian
62 
                                                                   

                                                                                              
                                                                                              
                                                         Giza to Atlantis
Council Anunnaki. The Anunnaki of the Sirian Council developed a strong
hold in Egypt for a time, creating a system of pyramids and other structures
that housed a network of power points through which energy was drawn from
the great crystals of Atlantis, through the Earth's grid lines and into desired
locations. About 35,000 years ago the pure Melchizedek Cloister race began
their first full birthing wave into human civilization, reinforcing the teach-
ings of the Law of One and bringing their fifth DNA strand potentials into
the human genetic pool. Guardianship of the Arc of the Covenant was
slowly turned over from the Sirian Council Anunnaki to the Annu-
Melchizedeks, Cloister Melchizedeks, Hebrew (hybrids of fifth race Cloister
Hibiru and the sixth race Cloister Melchizedeks created through the Host
Matrix Transplants of the Second Seeding), and the Serres-Egyptians, all of
whom became members of the early Egyptian priestcraft.  Since the times of
their creation, the Sphere of Amenti (550 million years ago) and the Arc of the
Covenant (840,000 years ago) were the primary foci of human evolution as the
purpose and process of the human evolutionary imprint was held within the secrets
of Amenti.  
                Guardian Alliance & Galactic Federation Intervention  
                                            28,000 BC-10,000 BC          
    The Templar-Annu grew progressively more hostile within the territories
under Sirian Council protection, and many relocated to Atlantis, which was
becoming the Templar-Annu strong hold. Angered that they were not per-
mitted to enter the Inner Earth or use the Arc of the Covenant, the Templar-
Annu devised a plan to conquer the Inner Earth territories by using the
Atlantean crystal generators to tear down the electromagnetic barriers that
secured the Inner Earth portals. The Templar-Annu began their conquest
from the continent of Atlantis, but quickly discovered the Inner Earth portal
shields could not be easily destroyed. As they forced excessive power through one
of their main generator crystals, the crystal unit exploded, with more than 10 times
the force of an atomic bomb.  Several other smaller generators also exploded,
ripping apart the continent of Atlantis and sending the majority of its land
mass under the sea. Following the explosions of 30,000 years ago (28,000 BC),
the Atlantean land mass was reduced to three islands and most of its popula-
tions were destroyed. Just prior to the explosion, the Sirian Council removed
various groups from Atlantis, distributing them throughout various locations
on the globe, many being taken to Egypt for re-settling. The Egyptians were
forewarned of the coming event, and most of the culture retreated under-
ground into Inner Earth communities, finding shelter from the Earth changes
that would result from the explosions.  
    During the explosions in Atlantis, the Earth was tilted slightly on its axis,
throwing the Earth's grid out of balance, breaking the energetic link between
the pyramid of Giza and Sirius B.  The Great Pyramid could no longer function as
63 
                                                                                                               
                                                                                                                                                                                                                              
      

       The Third Seeding  
an interstellar teleport station. The Arc of the Covenant remained stable but
surface conditions were thrown into chaos once again. The pole tilt created
massive ﬂooding in many places throughout the globe, and the rearrange-
ment of some land masses. Once surface conditions stabilized, the races
returned to the surface to rebuild, while the Anunnaki Resistance collected
the Templar-Annu they had rescued and placed them back upon the Islands
of Atlantis, helping them to reconstruct their civilization. Anunnaki of the
Sirian Council remained in Egypt, then extended their influence into
Atlantean Island territory, returning the Atlantean and Annu-Melchizedek
survivors they had exiled in the Inner Earth to the Atlantean Islands, while
slowly swaying a good percentage of the Atlantean Templar-Annu to give up
their Anunnaki Resistance affiliation.  
    Though the Law of One was beginning a resurgence in the Atlantean
island cultures between 30,000-12,500 years ago (28,000 BC-10,500 BC), the
Anunnaki of the Sirian Council, and the Arc of the Covenant which they
continued to protect, remained more vulnerable to Anunnaki Resistance
infiltration, because the Galactic Federation and Sirian Council ﬂeets could
no longer instantaneously come to Earth's defense due to the disruption of
the Giza pyramid teleport station. Around 12,500 years ago (10,500 BC) the
Anunnaki Resistance, angered by the loss of their stronghold in Atlantis,
launched an aggressive air strike against the Sirian Council Anunnaki out-
post on Mars and then in Egypt, in an attempt to destroy the Arc of the Cov-
enant, and claim dominion over the Earth civilization. The Martian outpost
was destroyed. The Sirian Council and various interstellar allies squelched
the takeover attempt and drove the Anunnaki Resistance ﬂeet out of Earth's
vicinity to the distant planet of Nibiru, but they did not arrive in time to pre-
vent the destruction of the Great Pyramid, the Sphinx and various other cul-
tural centers in Egypt. The portal bridge of the Arc of the Covenant survived
the attack, as did the Inner Earth territories, but following this brief
onslaught of 10,500 BC, the pyramids, Sphinx and other Egyptian structures
had to be rebuilt. The Atlantean Islands were not directly involved in these
attacks, though Resistance-Loyal Templar-Annu created minor uprisings
against their Sirian Council Loyalist relatives, until word of the Resistance
defeat drove them into temporary underground seclusion. The Atlantean
Islands continued on with mounting tensions between the two groups, and by
9,500 BC the Resistance-Loyal Templar-Annu had once again regained their
stronghold in Atlantis.  
    In Egypt, following the Resistance attack, the Sirian Council Anunnaki,
Annu-Melchizedeks, Cloister Melchizedeks and Serres-Egyptians rebuilt the
primary structures of their civilization. The ankhs, which had been hidden in
the Inner Earth during the raid, were again brought to the surface, and the
Great Pyramid of Giza, the Sphinx, and several new structures were rebuilt.
The Sphinx and Great Pyramid were placed in their previous locations mark-
64 
                                                                                                            
   

                                                                              
                                                                                                        2017 AD Appointment
ing the fortification of the Arc of the Covenant and Inner Earth portals. The
Great Pyramid was slightly realigned in order to create a Harmonic Reso-
nance link with the Pleiadian star system through the planet Alcyone, which
would allow the structure to be used once again as an interstellar teleport sta-
tion. Because of the disturbances of the Earth grid that occurred during the
Atlantean explosions 30,000 years ago (28,000 BC) the original alignment
with the Sirius B system could not be reestablished. The Third Eye of Horus
portal bridge to Sirius B did remain operational for smaller-scale visitations.
The Earth was now more closely in alignment with the interstellar energy
spirals that ran through the Pleiadian system, and so the new pyramid was
oriented to an energetic alignment with Alcyone.  
 
                                2017 AD APPOINTMENT     
 Earth enters a new 26,556-Year Time Cycle, Ascension Cycles  
                              and the 2017 AD Appointment  
                                22,326 BC - 2017 AD - 4230 AD  
       
    The civilizations of Earth continued to prosper and once again enjoyed
interstellar visitation from their Sirian and Pleiadian allies. Atlantis contin-
ued to digress under the in ﬂuence of a resurgence of the Templar-Annu. The
crystal generators were adapted into devices of torture for those not in com-
pliance with the Templars, and a period of genetic experimentation and ram-
pant power abuses ensued within Atlantean culture. The Arc of the
Covenant and the Inner Earth remained safe under the protection of the Sir-
ian Council as Earth began her next natural 26,556-year cycle of evolution
through the interdimensional time spirals. Earth entered her new 26,556-year
cycle 24,324 years ago in 22,326 BC, with the challenge of rebalancing her
energetic grid following the Atlantean explosions of 28,000 BC. With the
close of the old cycle came a natural period of dimensional blending through
which the Sphere of Amenti could have been re-entered into the Earth core,
but due to the continuing setbacks and necessity for planetary rebalancing,
the Earth grid did not vibrate high enough for the Sphere of Amenti to be
returned. At the onset of the new cycle in 22,326 BC, the Halls of Amenti
would have to remain closed to the masses, as human evolution continued
slowly along its course.  
    The first 4,426 years within the new cycle represented a time of great
promise, for this cycle period constituted the natural point at which Earth
would release two morphogenetic waves, through which masses of people
could ascend to Tara if the Halls of Amenti were opened. The first morphoge-
netic wave was released from Earth in 20,113 BC, the second wave in 17,900
BC, but the populations were unable to ascend as the Halls of Amenti were
not yet opened. Within the 26,556-year natural time cycle of Earth, morpho-
genetic waves are released only during four periods, the first two waves within
65 
                                                                                                         

                       
                       The Third Seeding
the first 4,426 years of the cycle, and the last two waves during the final 4,426
years of the cycle. These two 4,426-year periods, which occur at the opening
and closing of a 26,566 year cycle, are referred to as Ascension Cycles.  Since
the Halls of Amenti were not opened during the first Ascension Cycle of the
new time cycle, the souls trapped in the D-2 elemental and D-4 astral king-
doms, as well as the humans on Earth, would have to wait until the final
Ascension Cycle of their 26,556-year time cycle, in order to ascend.  
     From 22,326 BC forward the Guardian races of HU-2, the Ra Confederacy
and the earthly guardians of the Arc of the Covenant planned, prepared and
waited for the next Ascension Cycle. This time the Halls of Amenti must be
opened —this time the Earth grid must be able to hold the Sphere of Amenti —
this time the many souls trapped within HU-1 must be allowed to ascend. The
final Ascension Cycle within this 26,556-year time cycle would begin in the
year 196 BC. The first morphogenetic wave of this Ascension Cycle was due to
be released in the year 2017 AD. The last morphogenetic wave of this Ascen-
sion Cycle would take place in 4230 AD.  If the Halls of Amenti wer e not opened
during this ﬁnal Ascension cycle, the souls of the masses would be unable to ascend to
Tara for another 26,556 years. If the Halls of Amenti could be opened by 2012
AD, or by 4230 AD at the latest, the races of Earth could finally reclaim the
divinity and dignity of their heritage and return to HU-2, to the reality of the
Immortal body and the original 12-strand DNA construction. Their conscious-
ness would no longer be trapped within HU-1 or in the D-4 astral planes. The
living and the dead (those souls trapped in the astral planes) would rise up and
ascend out of their earthly prisons and into the “heavenly” lands of Tara in
HU-2. These stories of ascension, which appeared within your traditional reli-
gious texts were originally given to you by the Elohim and others, in order to
explain the highly scientific process of dimensional ascension that your races
would be faced with when the Halls of Amenti were opened.  
The Teachings of the Divine S cience, the Original Templar, Anunnaki  
       Resistance and Templar-Annu Distortions of the Templar Teachings  
               and the Guardians’ Awakening Agenda  
                                                   28,000 BC-present  
    Originally the teachings of ascension were quite scientific in nature, deal-
ing with the reality of multidimensional physics. The original information
brought to the races of the Third Seeding represented the teachings of the  Sci-
ence of Keylonta,  the underlying energetic mechanisms through which reality
is created and the processes through which consciousness evolves. The early
Atlantean cultures had full access  to this information, and until the T emplar-
Annu distorted the teachings in order to control the populations, the science
of ascension and multidimensional mechanics was publicly taught as a primary
belief model around which societies were structured. The teachings were given
66                    
                       
                   

                                                                                 
                                                                                                       2017 AD Appointment
to all of the races throughout the globe, not just those of Egypt and Atlantis.
Over time, and through the oppression of the Templar-Annu and later control-
oriented political groups, the true teachings were distorted or destroyed as they
gave the common person power over their personal destiny. People who are
empowered cannot be controlled or manipulated by outside authorities, and so
the tool of empowerment, knowledge,  was taken away from the masses so the
few elite could hold them under their power.              
         What remains today of the ascension teachings is hardly an introduction to
the true science as it was once applied on Earth. Portions of the teachings survived
through the mystical schools of  the ages, kept under strict secrecy, as the politically
controlling factions of various time periods persecuted those who attempted to
bring the truth to the populations. Even today this persecution exists (though usu-
ally in more covert form), much of it within the traditional religious organizations
whose teachings have been highly distorted in order to keep people powerless and
subservient to religious authority figures.  The science of  ascension was withheld from
the masses, but the promise of ascension was used to manipulate people into supporting
and obeying the authorities who claimed that ascension could be accomplished only
through blind belief and adherence to their politically motivated creeds . The original
teachings were intended for everyone, not just to serve the objectives of a power
elite. Though certain groups were appointed with guardianship of the Sphere of
Amenti and the Arc of the Covenant, they were not intended to horde this
power and knowledge for themselves, but this is precisely what occurred through-
out various periods of Earth's history. The guardian races of 22,326 BC knew it
would be a challenge to prepare the masses for the Ascension Cycle of 196 BC-
4230 AD, but they had not originally planned for the disruptions caused by the
Templar-Annu and their Anunnaki Resistance allies.  
    Through the manipulation of the Anunnaki Resistance and the T emplar-
Annu, following the Atlantean explosions of 28,000 BC, preparing the races
for the morphogenetic wave of 2017 AD became a very difficult task, as the
teachings that would allow this preparation to go smoothly were lost, manip-
ulated, distorted or destroyed, and as time went on, the majority of humans
did not have access to this information. Throughout the development of
human culture since 28,000 BC the covert in ﬂuence of the Anunnaki Resis-
tance and that of the Templar-Annu proceeded to contaminate human con-
sciousness with the elitist, controlling creed initially developed by the
Templar Solar Initiates of Tara. The original Templar of Tara was a sacred
organization devoted to upholding the Law of One. The Taran Turaneusiam
races were gifted, by the Sirian Council, with the power and knowledge of
the Templar in order to serve as guardians of the Taran planetary grid. They
had the awesome responsibility of ensuring that Tara's energetic systems
remained balanced, and that Tara, and the Turaneusiam races, stayed upon
their course of evolution into the HU-3 planetary grid of Gaia. Due to the
67 
                                                                                                                   

The Third Seeding  
corruption of the Taran Templar Solar Initiates, orchestrated by the Anun-
naki factions of the HU-2 Sirius star system who were rebelling against the
Sirian Council, the truth and sacred science of the Templar was, for a time,
lost on Tara. And because of this distortion and intentional Anunnaki Resis-
tance manipulation on Earth, the Templar teachings provided to the Earth
races became tainted with lies and distortions, progressively leading human
culture into an elitist, materialistic, dualistic perception of reality. That per-
ception has formed the underlying belief-base upon which culture was organized,
and is still apparent within most of the cultures of present day Earth.  
    The original T emplar creed taught Unity Consciousness and love, coop-
eration and respect toward all other life forms. It did not appoint some groups
as being godly and others as evil; it taught of the necessity for equality
between peoples and genders and the need to heal and integrate all aspects of
society. The original Templar teachings promoted kindness, gentleness, toler-
ance and power through comprehension of sacred energy mechanics and con-
sciousness embodiment of the God-force. They did not  teach that God was a
male authority ﬁgure who passed judgment upon sinful, inferior humans. They  did
not teach that the male gender was formed in the image of God and the
female was a lesser part extracted through the godly male to hold a position of
subservience to men. The original Templar creed did not  endorse the exploi-
tation of the plant, animal and mineral kingdoms for the purpose of personal
sustenance and materialistic gain, it taught respect and reverence for all life.
The original Templar did not  teach of “good and evil”; it taught that evil
deeds were the result of ignorance to the true structure of the universe, and
that evil was cured by education through the Law of One. It taught that peo-
ples were created to be free, and in that freedom should be taught how to
become co-creators with the God-force.  It taught that every being in the universe
was an individual face and expression of God, and that brotherhood was simply the
rational result of this comprehension.  
      Literally all of the elitist, sexist, materialistic distortions to the true Laws of
the Templar were perpetrated through the in ﬂuence of the Anunnaki Resistance,
some of their ET co-conspirators and the Templar-Annu Resistance loyalists lin-
eage who became their earthly operatives. The distorted Templar creeds moti-
vated everything from the Holy Wars throughout history to the structures upon
which economic, political and social organization has been built.  
       The creed of the Templar-Annu spread far and wide, and has colored the
mores of literally every human culture on Earth since the time of the Third
Seeding. The Templar distortions have evolved into a massive program,
which has repressed the majority for the benefit of the few, and has caused
humanity to lose comprehension of its divine source and the true potentials
of its evolutionary heritage. This creed has been a poison  to human society ,
and the pain, disease, war, competition, hatred and violence that have col-
ored the human condition throughout history and into the present, are clear 
68  
 
                                                                                                                           

                                                                                                            
                                                                                                          
                                                                                                          2017 AD Appointment
illustrations of just how powerfully these distortions of truth have affected
you. It would help all of you to realize that these creeds were given to you and
promoted by ET forces who set themselves up as surrogate gods, so human
evolution would remain under their control for the purpose of exploitation.
True spirituality lives within, and it is through that inner truth that you will
be able to separate the chaff from the grain in regard to your spiritual and
physical evolution. In contemporary society there are groups of souls now
being born who have been commissioned by the Palaidorians, Elohim, Ra
Confederacy and lnterdimensional Association of Free Worlds, to bring the
original teachings of the Templar back into your civilizations. They will bring
back to the Earth the truth of the Law of One and the knowledge of sacred
science through which that Law can be actively applied.  
     Many traditional persuasions will attempt to promote the new teachings as
evil or to otherwise discredit them, precisely because restoration of the truth of
multidimensional reality, which these organizations have for long attempted to
hide, will be the downfall of these institutions. Once humanity becomes aware
of the Law of One and the Unity Consciousness created through its practice,
control organizations will no longer be able to blindly lead the people, for the
people will choose freedom and knowledge over ideological imprisonment.
And they will choose love, equality and a personal relationship with the cre-
ative force over judgment, devaluation, hatred, fear, subservience and blind
worship of self-promoting outside authority figures. This evolution of self-con-
cept and re-definition of reality will take time, but through this process human-
ity will progressively grow to become free, and through its freedom will come to
understand its co-creative relationship with the divine.  
    When the guardian races of 22,326 BC planned the preparation of the
races for their 2017 AD awakening, they had not realized the extent to which
these manipulations would distort the evolution of human culture, nor the
degree to which the races would digress under this influence. Despite the
often disheartening setbacks, the guardian races of the higher Harmonic Uni-
verses remained loyal to their cause of seeing the Covenant of Palaidor, and
the evolution of the races, reach ful fillment. They have assisted, and still do,
along every step of the way, helping humanity to awaken to its relationship with the
divine creative Source.  After defeating the Anunnaki Resistance attack of
10,500 BC, and assisting the races of Egypt to rebuild their cultures, the Sir-
ian Council and guardian allies of humanity continued to visit and assist the
evolving cultures, serving as a counterbalance to the Anunnaki Resistance
and Templar-Annu forces that continued to assert their in ﬂuence on Earth.  
                          The new teleport station of the rebuilt pyramid of Giza, now aligned with
the energetic systems of Alcyone and the Pleiades, offered swift guardian inter-
vention and protection of Earth and easy access to Earth visitation. Until about
11,500 years ago (9,500 BC), humanity enjoyed the benefits of open relation-
ship with advanced ET cultures. This open relationship ended in 9,500 BC, 
69 
                                                                                                                 
                                                                                            

   The Third Seeding  
through an event created at the hands of the Atlantean Templar-Annu. Follow-
ing this event, human culture would enter a long period of digression, as the
planet was placed under intergalactic quarantine, and the previous powers of
advanced civilization were lost. This event of 9,500 BC was the first of several
major setbacks the guardians encountered as they attempted to prepare the races
for the opening of the Halls of Amenti and the mass ascension cycle of 196 BC-
4230 AD. Preparing the races would be no easy task while the Templar-Annu
and their Resistance allies exerted forceful in ﬂuence over the developing human
cultures. Many struggles and hardships would be encountered as the power
struggle between the HU-2 races who upheld the Law of One and those who
placed self-promotion above universal balance, was played out through the evo-
lution of humanity on Earth. Through the evolution of freedom, co-creative
endeavor and unity consciousness that power struggle will one day come to an
end, and peace will be restored to the races of the Third Seeding.  
                  
                        
                       
                                                      70                                                                                    
 
             
                    

                                            
                                                                               4
                                                           
                                                               
                                                                    
                                    
                         A Journey Toward Awakening
                 
                                          SINKING ATLANTIS AND EARTH QUARANTINE
         
                           The Sinking of Atlantis, the Ending of Open ET Relations and the
                       Withdrawal of ET Technologies, Premature Opening of the Arc of the
                                          Covenant and Descent of the Sphere of Amenti,
                                                    Earth's Quarantine, DNA Mutation
                                          and the Creation of the Ego and the Higher Self.
                                                                     9,558 BC-8000 BC       
   Following the 28,000 BC explosion in Atlantis, which reduced the conti-
nent of Atlantis to a small land mass of three islands (in the area of what is
now called the Bermuda Islands), the guardian races continued open visita-
tion with the cultures of Earth, using the Alcyone interdimensional spiral
and the Great Pyramid teleport station for easy access to Earth. The ET Visi-
tors, and occasionally inter-time travelers from future Tara, and past and
future Earth, shared open commerce with human cultures, showing their
inﬂuence in various locations around the globe. As the primary teleport sta-
tion was located in Egypt, Egyptian culture was strongly affected and inﬂu-
enced by ET visitation. Many of their later depiction of Gods originated from
these early days of direct relationship with a wide variety of extraterrestrial
beings. The Sirian Council of HU-2, and the Galactic Federation and Sirian-
Arcturian Coalition for Inter-planetary Defense of HU-1, along with several
other guardian allies, held the Alcyone spiral and Egyptian teleport station
under high security.  
     The Anunnaki Resistance, the Drakon, their allies or any other groups
not authorized by the Sirian Council, were not permitted to access the Alcy-
one spiral for Earth visitation. Unauthorized groups could, however, “take the
long way in,” using other inter-galactic portals which connected to Earth's
portal system. Though these alternative routes of visitation demanded much
more time and resources, they were still frequently used by other stellar cul-
71 
                                                                                                                                     
          


                  A Journey Toward Awakening
tures, who also influenced the development of the races. The Anunnaki
Resistance still occasionally infiltrated the Sirian Council security systems,
and secretly worked with members of the Templar-Annu, primarily those in
the Atlantean Islands. The Atlantean culture digressed into a torturous, elit-
ist society run by the Templar-Annu operatives of the Anunnaki Resistance,
and due to their actions 11,558 years ago, Earth civilizations would be
changed forever. The first major stumbling block to the guardian races awak-
ening plan took place in 9,558 BC.    
         The Te mplar-Annu, motivated by the Anunnaki Resistance, devised a
plan to take control of the Great Pyramid teleport station so the Resistance
could have free access to the Alcyone spiral. Their plan also included the
destruction of the Sphere of Amenti, for without the race morphogenetic
field, the souls of the races would be trapped in HU-1, their evolutionary
imprint erased. The Resistance desired to use humanity as an experiment,
creating a worker race that could supply them with Earth resources, primarily
gold and several other mineral compounds. Using Ankh tools pirated from
the Annu-Melchizedeks of the Inner Earth, the Templar-Annu attempted to
direct UHF fifth-dimensional energy from the Ankhs, through the Great
Crystal Generators which still remained operational in the Atlantean
Islands, through the Earth's energetic grid and into the Arc of the Covenant
portal bridge. They intended to send this high-powered electromagnetic
pulse (EMP) through the Arc of the Covenant and into the Sphere of
Amenti that was held within a planetary core in the Andromeda Galaxy.
Their erroneous calculations indicated that if they sent precise EM pulse pat-
terns into the Arc of the Covenant, the Sphere of Amenti could be isolated
as a target for destruction, and the Blue Flame (morphogenetic field for Tara)
could be released and returned through the Arc of the Covenant, to be used
as an inexhaustible source of power. With the Blue Flame Staff of Amenti
under their control, the Anunnaki Resistance could easily orchestrate a mas-
sive Earth takeover. But the Templar-Annu failed to access the frequenc y 
      codes used by the guardians to protectively seal the Sphere of Amenti against  
       such attack, and that miscalculation became the downfall of Atlantis.  
    When the T emplar-Annu sent their destroyer beam EM pulse through
the Arc of the Covenant, the EM pulse intercepted the Sphere of Amenti
with its security seal. The security seal would not allow the EM pulse to travel
into the Amenti Sphere, but instead created a double overtone frequency
pattern that sent the EM pulse into a state of fission. The exploding energies
focused in the Andromeda Galaxy quickly refracted off of the security seal on
the Sphere, replicated and intensi fied, then projected back down through the
Arc of the Covenant, disseminated through the Earth grid, then refocused on
their point of origin, the Main Crystal Generator beneath the largest Island
of Atlantis. This process occurred almost instantaneously, causing a chain
reaction explosion within most of the operational Crystal Generators. The
72 
                                                                                                                  
  

                                                       
                                                                                
                                                                              Sinking Atlantis and Earth Quarantine
Sirian Council discovered the plan too late, and were unable to prevent the
catastrophe. But they were able to rescue several groups of Sirian Council
loyalists from the Atlantean Islands, transporting them via interdimensional
craft to Egypt. Fleets rapidly scoured the Earth in the few hours prior to the
explosions, warning the cultures to retreat underground and into the Inner
Earth civilizations, where they would find shelter and refuge from the deluge
that would soon follow. Many people from many lands poured into the Inner
Earth portals, some were not able to enter before the portals had to be closed,
and so they perished. The portals and the underground passageways leading
to them were sealed, closed from the inside using the Ankh tools, as Earth
awaited the inevitable explosions.  
    The first series of explosions blew apart the land mass of the largest
Atlantean Island, which triggered tectonic shifting beneath the ocean ﬂoor.
This set off a series of explosions within the other Crystal Generators, deci-
mating the land mass of the two remaining islands, sending them deep into
the caverns beneath the ocean ﬂoor. Atlantis was removed from the face of
the Earth, into a watery grave within the caverns beneath the ocean floor.
The explosions occurred in 9558 BC, and resulted in yet another tilt of the
Earth's axis, shifting of some global land masses, a series of earthquakes and
massive ﬂooding in some locations (the ﬂooding was not global as it had been
during previous ﬂoods). The Giza teleport station was again thrown out of
alignment, as the Earth's vortex beneath it (Earth's “heart chakra”) no longer
energetically lined up properly with the Alcyone spiral. Though portions of
the Great Pyramid, the Sphinx and several other structures did survive these
Earth changes, it would be many years before they were returned to their
grandeur. The guardian races had more pressing problems with which to con-
tend.  
     After the explosions beneath Atlantis ceased, the Sirian Council ordered
the Sirian Blue Race to remove the crystal generators which had not
exploded. The massive crystals were dredged from the ocean floor and
returned to Sirius B. With the removal of the crystals, humanity's technologi-
cal abilities were thrown into the dark ages, and the once glorious civiliza-
tions of Earth were reduced to primitive organizations based upon survival
concerns and built through manual labor. Though the memory of advanced
societal structure remained, its applications became impossible without the
powers supplied through advanced extraterrestrial technologies. The crystals
were removed as a safety precaution, so more explosions did not ensue, but
later it was decided that these technologies would not be returned to Earth
until the races had evolved to a more mature comprehension of the proper
use of power. But this was only the beginning of the problems humanity
would face as a result of the sinking of Atlantis.  
       Following the deluge, the Sirian Council placed further security seals on
the Arc of the Covenant, which no longer permitted energy to be drawn
73 
                                                                                   

                  A Journey Toward Awakening
from the Blue Flame in order to charge objects with UHF fifth-dimensional
energy. Two objects were charged prior to this sealing, so the Egyptian cul-
tures would have a tool through which the Inner Earth portals could be
opened. One object was a small, cylindrical object, ﬂat on one side and made
of gold, which housed a small portion of the Earth's D-2 morphogenetic field,
a small part of the Orange-gold Flame of Earth's core. This object became
known as the  Rod . The other object, also made of gold, was a staff about 3'
long, containing several crystalline stones, which housed a minute portion of
the Blue Flame morphogenetic field. This object was called the Staff.
Though these objects did not have the power of the Ankhs, they enabled
humans to enter the Inner Earth portals and could be used to facilitate heal-
ing, to in ﬂuence weather patterns and to access the portals of parallel Earth.
The objects were stored within a lead-lined chest that was energetically
charged with a frequency barrier so the energies of the Rod and Staff could
not escape while the objects were in storage. The Rod and Staff, and the
Ankhs were placed in the custody of the Annu-Melchizedeks from the Inner
Earth, and the Ankhs were banned from being used by surface cultures. For a
time, the Rod and Staff were used by the Egyptians who rebuilt the surface
cultures, but later they were also banned from surface use and de-activated.
Through time the chest in which the Rod and Staff were stored became
known as the Arc of the Covenant, and the true meaning of the Arc of the
Covenant and of the morphogenetic ﬂames of the D-2 Rod and the D-5 Staff
became lost to all but a select few who remembered the true significance of
these terms.  
    The most treacherous problem created by this Atlantean misadventure
was that the original seal on the Arc of the Covenant, which kept the Sphere
of Amenti in place within the Andromeda planetary core, was sparked open
by the EM-pulse transmission from the Great Crystal. The Sphere of Amenti
began its descent to Earth. The Sphere of Amenti could only be entered into
the Earth core if the Earth grid vibrated high enough to hold the frequencies
within it, and only during the dimensional blending periods inherent to the
Earth's natural time cycles. The descent of the Sphere from the Andromeda
Galaxy would take 2,000 years. Not only was the Earth grid unprepared to
house its energies, but the timing of entry would be completely out of syn-
chronization with Earth's natural cycles. Having been released into the Arc
of the Covenant portal bridge in 9558 BC, the Sphere of Amenti would
intercept Earth sometime in 7558 BC. It would not arrive in time for the
dimensional blend period of 9048 BC, and would arrive before the next
dimensional blend period in 6835 BC. If the Sphere of Amenti attempted to
enter Earth's three-dimensional body during a time period when Earth's
fourth-dimensional vortices were not opened, the Sphere would explode
upon impact with the natural frequency barrier that separates the third and
fourth dimensions. This astral explosion would cause the Earth's fourth vor-
74 
 
 

                                                             
                                                                             Sinking Atlantis and Earth Quarantine
tex/chakra to collapse, which would systematically create a build up of energy
throughout the remaining vortices and the Earth grid would explode. If the
Sphere passed through the astral plane into the frequency bands of the third
dimension in 7558 BC, the Earth would be reduced to space dust.  
    In order to avert this pending Earth cataclysm the Ra Confederacy ,
Palaidorian and Sirian Councils, Elohim and several other Earth guardian
groups devised a plan through which the Earth could be spared this prema-
ture demise. This plan was put into effect in 9540 BC. The Elohim were com-
missioned to alter the Earth's D-2 morphogenetic field in a way that would
create a natural Frequency Fence, or energetic barrier, surrounding the Earth
through which the Sphere of Amenti would be unable to pass. Certain free
quency patterns were removed from the Earth's morphogenetic field, so the
fourth-dimensional frequencies could no longer “plug into” Earth's three-
dimensional body. The seventh through the twelfth base tones and seventh
through the ninth overtones of the third-dimensional frequency bands were
taken out of Earth's morphogenetic pattern. Without these frequencies, the
fourth-dimensional frequency bands could not connect to the Earth's 3-
dimensional body, so the Sphere of Amenti would be halted within the low-
est frequency bands of the fourth dimension, as the path of frequency through
which it would descend into the third dimension was severed. It would
remain in the astral plane until the 3-dimensional frequencies were re-
entered into the Earth's morphogenetic field. Without those frequencies the
Earth would not be able to pull those speci fic tones into its planetary grid, so
Earth would be halted in its tracks of time within the middle frequency bands
of the third dimension. Though this protective measure was necessary at the
time, it also stunted the planet's ability to evolve naturally out of HU-1. The
guardians intended to release the Frequency Fence during an appropriate
time cycle period, once the Earth grid had rebalanced and its vibrational rate
had increased enough to accept a rapid return of the Sphere of Amenti.  
    There were certain advantages and several drawbacks to this Frequency
Fence plan. The 10th-12th overtones of the third dimension were left within
the Earth's morphogenetic field, which meant that a portion of Earth's parti-
cles would manifest within the 10th-12th frequency bands of the third
dimension. A higher-vibrational “Earth phantom” was created, into which
the Sphere of Amenti could be released during an appropriate time cycle.
Once the Sphere was returned to the Earth Phantom energy imprint, the
higher 3-dimensional aspects of the race awareness would be released from
the D-4 Seal of Palaidor, and would be able to enter their race Cloister after
death, so part of the soul essence could return to Sphere of Amenti to await
the release of the fifth-dimensional Seal of Amenti. This meant that in the
dimensional blending period of 6835 BC the Sphere of Amenti could be
entered into the 10th-12th overtone frequency bands of D-3, and from that
point on soul fragments would no longer become trapped in the D-4 astral     
75                                                                                                                
                                                                                                                    

  A Journey Toward Awakening  
plane upon death. This was a definite advantage in terms of the evolution of
consciousness. However, there were also some disadvantages created by the
mechanics of the Frequency Fence.  
    The first disadvantage of the Frequency Fence was that the natural portal
structures which allowed for interstellar transit into Earth would be cut off
from the interdimensional grid. Interstellar Visitors could enter their craft
into the Earth Phantom frequency bands, but could not easily enter onto the
Earth's surface in the frequency bands below the Frequency Fence. Smaller,
more adaptable vessels were needed to orchestrate visitation, and each time a
vessel entered, it did so with the risk of disrupting the Frequency Fence,
which could release the Sphere of Amenti from its storage place. The Elohim
were put in charge of monitoring and protecting the Frequency Fence, and
the guardian organizations agreed that interstellar visitation to Earth would
be strictly limited to emergency intervention. The guardians adopted a policy
of non-interference with earthly affairs, but continued to hold the Frequency
Fence in place to preserve the integrity of the planet. lt was decided that
humans would be allowed to orchestrate their own affairs on Earth, with the
guardians attending to issues of evolutionary ascension from behind the
scenes. Because the Sphere of Amenti was now in a location more vulnerable
to Resistance attack, extremely high security measures were taken to ensure
that no one disrupted the Sphere or breached the Frequency Fence without
guardian approval. In the beginning, this fortification of the Fence was
intended for security purposes, but later it was used as a opportunity for the
Elohim to extend favoritism to those humans carrying genetic strains more
closely connected to their own morphogenetic imprint. This gave an unfair
evolutionary advantage to some humans, such as the Serres-Egyptians and
those of the Hibiru Cloister, who had stronger genetic ties to the Elohim
than many of the other races. The overall effect of the Frequency Fence and the
security tactics used to enforce it, was that the physical Earth and its peoples were
put under galactic Quarantine, losing all direct assistance from and relationship to
the multidimensional, inter-galactic communities.  Because of this quarantine,
information that traveled through the frequency bands of the higher dimen-
sions would no longer transmit into the Earth's grid and cellular memory. Not
only would the race memory from the Sphere of Amenti be unavailable to
humans upon the planet, but interdimensional communications from higher
dimensional fields would also be curtailed, as higher frequency transmissions
could not pass through the Frequency Fence. As generations of the races
evolved beneath the Frequency Fence, previous memory of humanity's
involvement with and genetic relationship to extraterrestrial civilizations
faded, and the advantages of technological advancement those relationships
allowed were lost.  
    Due to implementation of the Frequency Fence in 9540 BC, Earth
evolved under quarantine, and humanity was cut off from its interstellar heri-
76 
 
                                                                                           

                                                                   
                                                                                       Dreaming, Ego, and Higher Self
tage, but this was not the only disadvantage that the Frequency Fence cre-
ated for the human populations. The process of a soul essence birthing out of
the morphogenetic field of the Sphere of Amenti involves the essence pass-
ing out of its morphogenetic field and into the morphogenetic field of the
planet onto which it will birth. Once a soul essence has entered its planetary
morphogenetic field, it will then pass into the fetal pattern that was created
for its entry, and fetal integration of the soul consciousness occurs. As the
individualized morphogenetic field of the soul essence passes through the
planetary morphogenetic field, it picks up the frequency patterns characteris-
tic to the planetary core, which allows the essence to “ground” its identity
within the collective energy imprint of the planet.  
    After the Frequency Fence was applied and some of the third-dimen-
sional tones were removed from the planetary morphogenetic field, soul
essences passing through the Earth core for birthing could not ground the full
imprint for the third DNA strand, as the missing third-dimensional tones
would not allow the companion codes from the soul morphogenetic field to
plug into the Earth's morphogenetic field. The DNA is created in physical
terms as its already existing morphogenetic imprint passes through the Earth
core morphogenetic field where the energy imprint for the DNA then picks
up the particle patterns from the Earth that will “ ﬂesh out” the DNA imprint
in terms of dense-matter particles. If certain frequencies /tones are missing
from the Earth core, those frequencies carried in the DNA imprint cannot
flesh out into matter particles, and the DNA will manifest without those
tones in its operational strands. The Frequency Fence caused the third DNA
strand to manifest without the seventh through the twelfth base tones and
the seventh through the ninth overtones, which resulted in a genetic muta-
tion for the human lineage.                                 
                      
                        DREAMING, EGO, AND  HIGHER SELF  
                                                    Dreaming  
    The third DNA  strand corresponds to the third-Solar Plexus chakra, and
the third level of the bio-energetic field, the mental body. The DNA muta-
tion caused a division, or missing frequency link, in the third DNA strand
which manifested as a gap or void within areas of the bio-energetic system
that corresponded to that strand. The seventh through the twelfth base
tones/sub-frequency bands and seventh through the ninth overtones/sub-fre-
quency bands of the third dimension were blocked out of the third chakra,
and the nadial capsule, which naturally separates the third-dimensional/men-
tal body, and fourth-dimensional/astral body levels of the bio-energetic field,
developed a second barrier, creating an even larger gap between the con-
scious mental awareness and the astral level of awareness. ln sleep the con-
sciousness could travel into the astral identity, but now there would be a gap
77 
                                                                                                                 
                                                                                                                                                                                                                           
 

A Journey Toward Awakening  
between the waking identity and its astral experience. This gap, created by
the missing 7-12 base tones and 7-9 overtones, created a distortion in dream
recall, in which the consciousness would encounter the missing tones and be
unable to translate sensory information from frequency bands corresponding
to those tones into the genetic code. Prior to the Frequency Fence, memory
of other dimensional experience during the dream state was far more lucid, as
experiences the consciousness had while disassociated from its focus in the
body during sleep would be stored in the form of electrical impulse within the
consciousness, and when the consciousness returned to the body these elec-
trical impulses would be translated through the body into coherent, sequen-
tial memory patterns.  (Note: conscious recall of higher dimensional experience requires the
fourth DNA strand, as this strand allows the higher-dimensional experience
to be transferred into the lower DNA strands and then into cellular memory
and conscious recognition. The Third Lamanian/Lemurian Root Race and
their Ur-Antrian Cloister, and the fourth Atlanian/Atlantean Root Race and
their Breanoua Cloister did not dream multidimensionally as the later races
would, because they did not have the fourth DNA strand manifest within
their genetic code. Their dream experience was limited to activity taking
place within the second- and third-dimensional fields. The Fifth Root Race
Ayrians/Aryans and their Hibiru Cloister brought multidimensional dream-
ing and astral projection of consciousness into the human gene pool, as they
held the fourth strand DNA imprint within their genetic code. In the races of
the First Seeding, before the Seal of Amenti was manifest in the gene code,
dreaming took place on a fully conscious level and a sleep state of disassocia-
tion from the body was not required, as perception of various dimensional
fields took place on a fully conscious level. One would consciously perceive
and interact with the dimensional fields corresponding to the number of
DNA strands in the gene code, and the physical body was continually replen-
ished on a conscious level by drawing energy from the morphogenetic field of
Amenti through breathing. Only after the Seal of Amenti was applied did
humans have to disassociate from the body in sleep to revitalize the physical
structure and participate in other dimensional experience.)  
    After the Frequency Fence of 9540 BC was in place higher-dimensional
experience was unable to translate directly into the human cellular memory.
The electrical impulses within the consciousness, within which the imprint of
higher dimensional experiences were stored, could not pass through the gap
within the third DNA strand, so this experiential memory could not be trans-
lated into conscious, sequential dream recall. In contemporary times, now that
the Frequency Fence is beginning to lift and the third DNA strand is being
repaired, sequential dream recall and memory of higher dimensional experience is
once again developing in the races, and experiences associated with development
of the higher DNA strands, such as lucid dreaming, simultaneous dreaming, con -
78 
 

                                                                                         
                                                                                      Dreaming, Ego, and Higher Self
scious astral projection and mental bilocation are also now emerging . For the ear-
lier races, this loss of cognizant dream recall created an extreme sense of
isolation and an over developed focus of consciousness within the external
world. Dream recall was not the only area of human consciousness to be
affected by the Frequency Fence.  
                                         
                                The Ego and the Higher Self         
     Through the mutation in the third DNA strand, which manifested as a
division within the third chakra and mental body level of the bio-energetic
field, a new kind of consciousness developed within the races. As the first
through sixth base tones and 10th-12th overtones were left operational
within the third DNA strand, two aspects of personal mental identity were
brought into manifestation. The conscious mind, or conscious focus of atten-
tion, was divided into two areas that did not consciously associate with each
other. The portions of consciousness that manifested through the first
through sixth base tones of the third DNA strand were focused and could
perceive within the lower vibrating energy fields of the first through sixth
sub-frequency bands of the third dimension. The portions of consciousness
that manifested through the 10th-12th overtones of the third DNA strand
were focused and could perceive within the higher vibrating energy fields of
the l0th-l2th sub frequency bands of the third dimension. The portions of
personal identity manifesting through the lower base tones of the third DNA
strands became the lower self, or what has come to be known as the Ego, and
its perceptions are limited to activity taking place within the lower portions
of the third dimension. The portions of identity manifesting through the
higher overtones of the third DNA strand became the  Higher Self.  The
Higher Self mind could perceive activity taking place within the highest sub-
frequency bands of the third dimension.             
    The lower mind Ego developed an exaggerated sense of dualistic percep-
tion, as it became locked into five-sensory perception. Using only five sensory
perception, extreme distinctions between the inner world of personal iden-
tity and the outer world of manifest reality were perceived, as the cognition
of “where the inside and outside of things meet” was blocked from conscious
perception. The inner and outer realities meet within the morphogenetic
field of the race identity and that of the Earth’s core, where the energetic
inter-relationship between the planet and its people is understood. Through
the race morphogenetic field in the Sphere of Amenti the individual's con-
nection to its race and the purposes for its existence within the greater plan
of evolution can be understood, as the evolutionary plan exists within the
morphogenetic field as an energetic blue print through which identities and
events manifest. The race morphogenetic field also holds the individuated
morphogenetic field for a person, and contains the higher dimensional soul
aspects of consciousness through which the contours of the individual incar-
79                                                                                                                
                                                                                                               
                                                                                                       
   

A Journey Toward Awakening  
nation are designed. Through the Frequency Fence the Ego became cut off
from conscious relationship with its personal morphogenetic field and from
the morphogenetic fields of its race and the planet. The Ego awareness felt
itself to be isolated and separate from the world around it, and could not per-
ceive the creative principle or purposes through which it came to be. Human
consciousness became “locked within the illusion of matter” as a result of the Fre-
quency Fence, unable to perceive or comprehend the reality of non-manifest sub-
stance through which all manifest things are created. Human consciousness lost
touch with the common Source within and behind all things, and so lost its ability to
identify with and comprehend the beings and things that appeared to exist outside of
itself.  Humanity's connection to the Universe remained a reality, but the Ego
awareness lost the ability to consciously perceive that reality. The Egotistical
mind perceived itself as limited and finite, and so developed an overly aggres-
sive need to dominate and control its external environment as a means of
attempting to insure its survival. As humans evolved to view themselves as
finite creatures at the mercy of a seemingly hostile external environment, the
lower Egotistical mind became isolated, lonely and very frightened. Healing
of the Egotistical mind would require its integration with the Higher Self
mind, through which its power and place within the universe could be under-
stood.  
      The Higher Self mind could not only perceive in the highest frequency
bands of the third dimension, it could also “plug into” the D-4 astral identity
and the soul matrix identity that is contained within the fourth-, fifth- and
sixth-dimensional frequency patterns of the Amenti morphogenetic field.
The Higher Self allowed the fourth and fifth DNA strands to begin manifest-
ing, if those strand imprints were contained within the race DNA imprint.
As long as the Frequency Fence was operational the Ego could not translate
higher dimensional data into conscious awareness, nor could it translate the
comprehension of the Higher Self mind. But the elemental aspects of the
human body, the portions of consciousness manifesting through the second
DNA strand that are focused within the second-dimensional frequency fields,
could translate portions of the Higher Self cognition, as the 10th-12th over-
tones of DNA strand two could translate some of the electrical impulses from
the 10th-l2th overtones of DNA strand 3. Strand two had already been
altered through the Seal of Palaidor, creating the division between the D-2
emotional identity and the D-3 mental awareness which created the sub-con-
scious mind, so the portions of the Higher Self perceptions that could trans-
late through the D-2 strand appeared within the body through the sub-
conscious mind, appearing as felt emotional response. The Higher Self com-
municated data to the conscious awareness via sub-consciously sensed feel-
ing, that became known as the Intuitive Sense. Intuition represents information
from the Higher Self sent to the conscious awareness via the body and sub-conscious
mind.  
80  
 

                                                                
                                                                                       
                                                                                         Dreaming, Ego, and Higher Self
    In the present day human, as the third DNA strand begins its reverse-
mutation through the lifting of the Frequency Fence, the perceptions and
cognition of the Higher Self become consciously available to the lower mind
of the Ego, and through this conscious connection the Ego rediscovers its
multidimensional aspects of awareness. When the third DNA strand is com-
pletely assembled, the Higher Self aspect of identity will merge with the Ego
and the mental awareness will comprehend itself as being a multidimensional
identity. The Higher Self serves as a bridge between the identity focused in
HU-1 reality and the soul imprint of that identity which is focused in HU -2.
The first step in integrating the Ego into its multidimensional identity is to
open the lines of conscious communication between Ego and Higher Self. In
contemporary terms this is often called “ channeling your Higher Self, " but the
reality of that process is assembling the third DNA strand through which the
two levels of mind can merge.  
     If the Ego makes a conscious effort to allow its Higher Self to speak, the
third DNA strand assembly process is accelerated, and information received
from the Higher Self will evolve from vaguely sensed intuitive impressions, to
direct inner verbal and visual communication, then eventually the Ego will
understand the Higher Self to be part of its own identity, a focus of conscious-
ness into which it can direct its awareness to receive a greater spectrum of
information. Once a person becomes the Higher Self, there is no longer an
egotistical focus, as the lower and higher minds have become integrated into
a “Superconscious Mind,” which can develop multidimensional perception
and abilities. Through the super conscious mind the D-2 sub-conscious mind
and D-l physical body consciousness can also be integrated into the con-
scious awareness. Working with, through, and becoming the Higher Self is
the next step in human evolution, and through this endeavor the healing and
assembly of the DNA can occur, under the direction of the super-conscious
self. The Higher Self and the Ego came into being within the human lineage in 9540
BC, manifesting as a result of the Frequency Fence that was created to stop the
Sphere of Amenti from destroying the Earth by entering the Earth's core prema-
turely.  
            
            
                                             
   
81 
                                                                                                            

A Journey Toward Awakening  
                          ALCYONE AND THE TEMPLAR SEAL  
  The Templar Seal and the Annu-Melchizedek and Hebrew Races,  
 Realignment of the Melchizedek Cloister Morphogenetic Field, the       
      Annu-Melchizedek and Hebrew Races Removed and Serres-Egyptians  
        and Cloister Melchizedeks Appointed as Guardians of the Arc of the               
               Covenant, Resurrecting the Great Pyramid and the Sphinx . 
                                       8000 BC-5466 BC        
    The races who returned from the Inner Earth to re-establish surface civi-
lization, after the 9558 BC sinking of the Atlantean Islands, were faced with
many new hardships as rebuilding of their cultures was orchestrated through
manual labor, without the use of the Great Crystal Generators and high pow-
ered Ankhs to which they had become accustomed. Following the employ-
ment of Earth's quarantine in 9540 BC, and its resulting genetic mutation,
evolution became an even slower, more arduous task. The Egyptian-Serres,
Annu-Melchizedeks and Hebrew peoples were guardians of the Arc of the
Covenant and were permitted to have custody of the Rod and the Staff so
their connection to the Inner Earth civilizations could remain open. The
Great Pyramid and the Sphinx suffered damage during the ﬂooding that fol-
lowed the downfall of Atlantis, but portions of these and other structures
remained intact, and these were once again used as a central hub around
which the cultures would rebuild. The Serres-Egyptians remained as the royal
line in Egyptian culture, while remnants of the Lemurian and Atlantean cul-
tures and the Breanoua and Ur-Antrian Cloisters, the Annu-Melchizedeks of
the Inner Earth, the Hibiru, Aryans, Cloister Melchizedeks and the Hebrew
races populated Egypt and various other locations of the globe. The first num-
ber of generations were preoccupied with survival issues and the development
of small cultural clans, which eventually led to the development of larger
social orders. The Egyptian culture received much assistance from the Inner
Earth races as the Arc of the Covenant was located within the Egyptian lands
and surface guardianship of this and other portal passages was placed in the
hands of the developing races in this area.  
    During the retreat to the Inner Earth at the time of the sinking of Atlan-
tis, numbers of Templar-Annu had also entered the inner territories. (The
Templar-Annu were those born into the Atlantian-sub-race-Egyptian race
through the Melchizedek Host Matrix, who later interbred with members of
the Anunnaki Resistance, inheriting all or part of the genetic distortion
Templar Seal from this extraterrestrial race). The Templar-Annu interbred
with many different races in generations following Atlantis, especially with
those of the Annu-Melchizedek and Hebrew (Hibiru/Melchizedek) lines,
passing on concentrations of the Templar Seal distortion throughout the
Melchizedek races. The distortions of the Templar creed had also made their
82 
 
 

                                                                     
                                                                         
                                                                              Alcyone and the Templar Seal
way into the Inner Earth societies and their patriarchal, elitist, sexist, materi-
alistic slant began to color the original teachings of the Templar within cer-
tain groups. These creed distortions became apparent in the evolution of the
surface cultures, as did the progression of the Templar Seal genetic distortion,
as well as various other genetic anomalies that were created through inter-
breeding with a variety of Interstellar Visitors during the times of Atlantis .¹
     The genetic distortions were of great concern to the Palaidorians and
guardian races, as if the deviations in the DNA imprint became too numer-
ous, the original imprint for the races would be lost. If enough soul essences
from lineage with deviating genetic imprints passed back into their race mor-
phogenetic field at death, those deviations would eventually override the
original patterns in the morphogenetic field. If the Amenti race morphoge-
netic field became misaligned with the 12-strand pattern, evolution of the
12-strand DNA package could not take place.  
      In order to preserve the integrity of the Turaneusiam-2/human genetic line ,
the Sirian Council and Elohim were authorized by the Ra Confederacy to
remove certain portions of the race morphogenetic field from the Sphere of
Amenti, so the Amenti race morphogenetic field would not become misaligned
by deviations in the genetic imprint. The races removed from Amenti would
pass through the planetary morphogenetic field of Alcyone, and after death the
soul essence would evolve as consciousness for a time within the frequency
fields of Alcyone, through which genetic deviations of the human line could be
processed out before the consciousness returned to the Sphere of Amenti. This
separation of the morphogenetic fields became known as the Templar Seal . It
involved removing the sixth base tone of the second DNA strand, the sixth
overtone of the fourth DNA strand and the 12th overtone of the fifth DNA
strand. The races bearing this genetic imprint con figuration were sealed out of
the Sphere of Amenti morphogenetic field and redirected into evolution
through Alcyone, with the intention of one day releasing the Templar Seal and
reentering their morphogenetic field back into the Sphere of Amenti for ascen-
sion.  
     The races bearing the most genetic deviation were those of the T emplar-
Annu, who had been seeded through the Melchizedek Host Matrix, and
through them larger portions of the Melchizedek Cloister had become mis-
aligned with the 12-strand DNA imprint. Through the Melchizedek morpho-
genetic field, the Hebrew-Melchizedeks and Annu-Melchizedeks also carried
                         ________________________                    
                 1.   The Zephelium, the original race line of the modern day Zeta Reticuli and their Greys,
                           were one of the visiting groups to Atlantis who became genetically mixed with some of
      the T emplar-Annu race families. The reason contemporary Zeta sought genetic material
      from our race was that they hoped to find traces of their own original genetic imprint in
      our DNA, so they could reverse the mutations that had occurred in their own genetic
           lines and create hybrid versions of themselves more suited to Earth's environment  
83 
                                                                                                                         
                                                                                                                                                                                                           
        

                  A Journey Toward Awakening
excessive genetic deviation, so the morphogenetic fields of these three groups
were chosen for re-alignment through Alcyone.  
    It is important to note that the genetic deviations carried by these groups
were not inferior or “bad;” the deviations simply would have taken those
aspects of humanity on a different evolutionary course. This would have
eventually redirected the entire course of human evolution, and the original
Turaneusiam 12-strand DNA package would no longer be available to the
human lineage of Earth. The 12-strand package is one of the highest genetic
imprints within HU-1 and HU-2 for it allows full transmutation out of matter
and can embody the consciousness of a 12-dimensional oversoul when the 12
strands are fully activated. Very few biological forms possess this potential.
Humans carrying the lineage of the deviated genetic codes are in no way infe-
rior to other human strains, and as long as excessive deviations are not
allowed to alter the original Amenti morphogenetic field, those races do not
pose a threat to the human lineage. As you will see, through the course of this
chapter, the guardian races have insured the integrity of the human genetic
imprint, and have also made it possible for the races deviating from that
imprint to return and ascend through the Sphere of Amenti. The Hebrew
morphogenetic field was realigned and entered into the Sphere of Amenti
about 2000 years ago with the birth of the man who has come to be known as
Jesus Christ, and the Annu-Melchizedeks and Templar-Annu were reentered
into Amenti about 3,300 years ago with the birth of the Pharaoh Akhenaton/
Amenophis IV .  
    At your present point in history all of your races are part of the Amenti
morphogenetic field, and all of you are in the process of healing and assem-
bling various DNA configurations.  We do not want the more immature among
you to misuse this information on genetic lineage as grounds for unfair and discrim-
inatory attitudes toward other members of   your  race, for such discrimination has no
intelligent basis and is groundless.  We would also like to mention here that of
the Third through Seventh Root Races and their Cloisters, each of the seven
sub-races within each race carries one of the race strains from each of the
seven Root Races. For example, those of the Aryan Root Race affiliated with
the Hibiru Cloister, who carry the gene code imprint for the white skinned
races, have within their seven sub-races a white skinned sub-race with a dom-
inant Aryan or Hibiru Cloister gene, a black skinned sub-race with a domi-
nant Euanjhechi or Yunaseti Cloister gene, a yellow skinned sub-race with a
dominant Muvarian or Melchizedek Cloister gene, a brown skinned sub-race
with a dominant Lemurian or Ur-Antrian gene, and a red skinned sub-race
with a dominant Atlantean or Breanoua Cloister gene. There will also be two
additional sub-races which bear the primary skin color of their Root Race and
Cloister, who carry a dominant gene from the First Polarian and Second
Hyperbornean Root Races of Gaia. Each of the primary Root Races and their
Cloisters have this inter-mixed sub-racial division. The seven sub-families
84 
 

                                                                            
                                                                                       
                                                                                        Alcyone and the Templar Seal
within each of the seven sub-races are even further intermixed. We tell you
this so you may come to realize that  all of your races, though diversi fied in
genetic content are equal in value and all of them, by the design of their mor-
phogenetic pattern, are intertwined.  
    Discrimination of race, genetic lineage, or skin color is as ridiculous and
unfounded a notion as gender discrimination. Both of these ideas were given to you
at   various periods by different groups of non-terrestrial Visitors, in order to manipu-
late the evolution of the races for their own purposes. These notions have kept
your races and genders at odds, competing for who is better or best, when
instead the true power and beauty of the human races lies within its unity
which allows for diversification. You are all of equal value and importance,
and each of you brings unique characteristics and gifts into the human gene
pool. It would do your species well to realize this fact, so you can learn to
work together, through which all of you may heal and prosper. Now we will
conclude our discussion on the realignment of the Melchizedek morphoge-
netic field. 
    Following the implementation of the T emplar Seal upon the Annu and
Hebrew morphogenetic fields, these groups were provided with teachings from
the Priesthood of Ur in the lnner Earth, through which they were counseled
not to interbreed with members of the other races, so as not to pass on the
Templar Seal gene con figuration. Unfortunately, these teachings eventually
became distorted, the original meaning for the ban on interracial mixing
became lost, and the teachings evolved into an elitist creed of genetic superior-
ity among these groups. This attitude was perpetuated within the Annu and
Hebrew races and later developed into unnecessary cultural discord between
those of Annu and Hebrew lineage, and the Serres-Egyptian ruling class, and
the Hibiru, Aryan and Cloister Melchizedek families who made up the majority
of the Egyptian nations populations. This interracial discord exaggerated
already existing conditions of competition and conquest among the races.
When the Halls of Amenti were opened in 1374 BC, this interracial discord
proved to be a second primary setback to preparation for the 2017 AD mass
ascension wave. Due to interracial difficulties between the Annu-Melchizedek
and the Serres-Egyptian majorities, the Halls of Amenti were once again closed
and mass preparation for ascension was curtailed.      
    When the T emplar Seals were applied in 8,000 BC, guardianship of the
Arc of the Covenant was transferred out of the hands of the Annu-
Melchizedeks and Hebrew races into the protection of the Serres-Egyptians
and Cloister Family Melchizedeks (those born through the Sphere of Amenti
Melchizedek Cloister after the Annu and Hebrew morphogenetic fields had
been removed). Previously the four races shared responsibility and accessibil-
ity to the Arc of the Covenant, but following the Templar Seal only Cloister
Melchizedeks and Serres-Egyptians were permitted direct involvement with
85 
                                                                                                                                                                                                                                    
 

A Journey Toward Awakening  
the Inner Earth Priesthood of Ur, whose training kept knowledge of the Arc
of the Covenant alive within the surface cultures. From 8,000 BC forward the
cultures developed with greater racial divisions, some groups leaving the
areas which came to be known as Giza, integrating into other cultural bases
along the Nile river, such as Thebes and into Nubia, others journeying into
the territories of what came to be known as Jerusalem, and Sumeria and Ur
along the Euphrates River, intermixing with the descendants of the other
Root Races and their Cloisters. The Serres-Egyptians and Cloister
Melchizedeks remained concentrated in the area of Giza where the Arc of
the Covenant entered the Earth, and continued to build up their civiliza-
tions, with periods of achievement tempered by periods of digression.  
    During the height of pre-dynastic Egypt, following an inﬂux of cultures
from various other regions, the Serres-Egyptians and Cloister Melchizedeks,
under the direction of the Priesthood of Ur, made an attempt to reconstruct
the remains of the Great Pyramid of Giza and the Sphinx, which had been
damaged in the deluge following the sinking of Atlantis in 9,958 BC. Using
manual labor, the Great Pyramid was restored around 5,546 BC, as a religious
center through which the Arc of the Covenant was fortified and secured, but
the structure no longer served as an interstellar teleport due to the pole tilt
resulting from the Atlantean cataclysm and the Frequency Fence of 9,540
BC. The Sphinx was reconstructed around 5,466 BC, the contours of the
structure's facial features were altered to more closely resemble the appear-
ance of the Serres-Egyptian line, and the stronger, more exaggerated facial
features characteristic to the Anunnaki lineage (who originally designed the
structure in 46,459 BC) were omitted from the reconstruction. The form of
the Leonine body remained as a tribute to remembered gods of Egyptian
mythology, who represented symbolic trace memories of ancient Anunnaki
affiliations with the HU-2 Leonine races. The early dynastic periods of Egypt
emerged around 3,500 BC, bearing increasing influence of cultural inﬂux
from various other regions. The Arc of the Covenant, Sphere of Amenti and
the tools of the Rod and the Staff became closely guarded secrets, held within the
conﬁnes of select Serres-Egyptian and Melchizedek Cloister families  with  whom the
Priests of Ur continued covert contact.  
                         
                         
                             86
                    
                                             

                                                
                                                        5
                                                                                                                                                                                              
                                                                    
            
Return to Amenti                                                      
                                                 
                                                 PHARAOH AKHENATON               
                   Return of the Sphere of Amenti, Birth of Pharaoh Akhen aton/  
                      Amenophis IV, Templar Seal Released From the Annu Races,  
                                           Opening the Halls of Amenti and Ascension  
                                                              2409 BC-l362 BC  
    The Sphere of Amenti could only be reentered into Earth’ s core during
the periods of dimensional blending within Earth’s natural time cycles. The
Elohim and guardians from HU-2 and HU-3 had orchestrated the Frequency
Fence and Earth's quarantine in 9540 BC in order to prevent the Sphere from
destroying Earth after it had prematurely descended through the Arc of the
Covenant as a result of the Atlantean cataclysm, and since 9540 BC the
Sphere of Amenti had been in storage, under high security, within the fre-
quency bands of the fourth dimension astral planes. The Earth’s grid had sta-
bilized and risen in vibrational speed since the times of Atlantis, and the
guardian races made plans to reenter the Sphere of Amenti into Earth’s core
through the barrier between the third and fourth dimensions during the next
natural opening in the time cycle, in preparation for opening the Halls of
Amenti. The next natural dimensional blending period would occur in 2409
BC, which marked the half cycle point within the 4426-year cycle that began
in 4622 BC. If the Sphere of Amenti could be entered into the third dimen-
sion in 2409 BC, it could then be returned to the Earth’s D-2 core whenever
the Earth grid speed rose high enough to hold the frequencies of the Blue
Flame morphogenetic field of Tara, which needed to be embodied on the
planet for the Halls of Amenti to open. As the Melchizedek Cloister race
held the imprint for the fifth DNA strand, which would pull fifth-dimen-
sional frequencies into the Earth grid, the opening of the Halls of Amenti
was dependent upon enough of the Melchizedeks and fifth strand hybrid races
being present on Earth to raise the grid speed high enough to hold the Blue
87 


                  Return to Amenti
Flame . In order to raise the grid speed, 8% of the total global population had to have
the ﬁfth strand activated, which meant that the Sphere of Amenti could not descend
into Earth’ s core until a concentration of Cloister Melchizedeks had been born . The
second mass birthing wave of Melchizedek Cloister souls was scheduled to
occur around 1500 BC, so the tentative date for the opening of the Halls of
Amenti was set for a period following the 1500 BC Melchizedek Cloister
birthing wave.  
      The Sphere of Amenti was released from D-4 by the Elohim in 2409 BC.
The seventh through 12th base tones of the third dimension, which had been
removed from Earth’s morphogenetic field to create the Frequency Fence,
were readjusted. The eighth through 12th base tones of D-3 were re-entered
into the Earth’s morphogenetic field, reconstructing the Frequency Fence
between the sixth and eighth base tones of the third dimension. This allowed
the Sphere to enter into the UHF bands of D-3 until it was time to open the
Halls of Amenti. Releasing the Sphere from the UHF bands of D-3 did not
require synchronization with a natural dimensional blend period as would
have been necessary if the Sphere remained in D-4.  
     Following the Melchizedek birthing wave of 1500 BC, plans were made
for the opening of the Halls of Amenti. This opportunity would also be used
to begin the reintegrating of the Annu-Melchizedek morphogenetic field,
which was stored in Alcyone under the Templar Seal. It was decided that in
the year 1398 BC an avatar from HU-2 would birth on to Earth through the
Annu-Melchizedek morphogenetic field, then through the Sphere of Amenti
and into the Earth. By passing an avatar soul essence, who carried at least 9-
dimensional frequencies within its personal morphogenetic field, the genetic
imprint deviations in the Annu-Melchizedek morphogenetic field could be
realigned with the HU-2 frequency patterns. This process would serve to
clear the Annu morphogenetic field of its distortions and reintegrate the
Annu back into the Cloister Melchizedek morphogenetic field in the Sphere
of Amenti. Following the birth of this avatar, the Annu peoples would be
released from the Templar Seal and would be able to ascend to Tara with the
unsealed races when the Halls of Amenti opened. The birth of the avatar
would “spark,” or quickly raise the frequency of the Earth grid, which would
in tum cause the Earth core vibrational rate to increase, so a spark would be
released from the Earth core into the Arc of the Covenant, thereby releasing
the Sphere of Amenti into the Earth core.  
    The avatar chosen for this project was a pure Anunnaki soul essence
appointed by the Sirian Council from HU-2 It was necessary for an Anun-
naki to serve this role in order to realign the Annu genetic imprint to its orig-
inal order. The avatar was born in 1398 BC, in the city of Thebes, Egypt, as
the son of a Serres-Egyptian father and Annu-Melchizedek mother. This
child became known as Amenophis IV , son of Pharaoh Amenophis III and
Queen Tiy. When the child was grown he changed his name to Akhenaton
88 

                                                                                                              Pharaoh Akhenaton
(1366 BC), and began the Atonist movement within the Egyptian New
Kingdom dynastic line. At the birth of Akhenaton in 1398 BC, the Arc of
the Covenant was opened and the Sphere of Amenti descended into Earth
core from the UHF bands of D-3. Twelve years later, in 1386 BC the Blue
Flame of Amenti descended and was embodied by the Melchizedek Cloister
Flame Holder, who became the High Priest of Akhenaton’s Atonist move~
ment. (Amenophis III died in 1385 BC when Akhenaton was 13 years old,
and Akhenaton served as regent with his mother Queen Tiy until 1370 BC,
when at age 28 he began his 17-year Pharaonic rule). The Melchizedek
Cloister soul group who were to serve as Keepers of the Flame were birthed
into this time period in synchronization with Akhenaton’s birth, so they
would be in the appropriate places to ful fill their role within the opening of
the Halls of Amenti. The Halls of Amenti opened 12 years later in 1374 BC,
after the frequencies of the embodied ﬂame had stabilized within the Earth
grid. 
     At the age of 24 Akhenaton was taken to the Inner Earth by the Priests
of Ur, and trained in the processes of ascension, which he would conduct
after his training was complete. In 1367 BC, at the age of 31, Akhenaton was
instructed to relocate his seat of power from Thebes to a location in middle
Egypt called Tel el-Amarna, where he constructed the city of Akhetaton in
honor of the Aton god and the Law of One. He was led to this location by
the Priests of Ur, as there, beneath the ground, were portals connecting to
the Inner Earth, through which he could pass into the portals beneath the
Great Pyramid of Giza, where the Arc of the Covenant and the Halls of
Amenti were found. The Giza pyramid was still under the control and protec-
tion of the Amonist priests of Serres-Egyptian lineage, among whom much
anti-Atonist sentiment stirred. The Priests of Ur did not want knowledge of
the opening of the Halls of Amenti known among the general Amonist
priest-cast, as certain abuses of power and distortion of the original Templar
creed had become prevalent in this group, and only Cloister Melchizedeks
born into the Serres-Egyptian elite were permitted knowledge of the opening
of Amenti.  
    The new city at T el el-Amarna allowed Akhenaton and his followers to
go about the business of ascension without drawing the attention of the
Serres priesthood, and also permitted easy access through the Inner Earth to
Giza, Thebes, Jerusalem and the city of Ur along the Euphrates River. Using
surface travel, these locations were hundreds of miles apart, but through the
portals of Inner Earth these locations could be accessed within minutes.
Akhenaton’s purpose in coming to Earth was to ensure the opening the Halls
of Amenti, to realign the morphogenetic field of the Annu races so they
could be re-entered into the Sphere of Amenti, and to orchestrate ascension
for the Templar-Annu, Annu-Melchizedeks and selected others of various
races, whose genetic codes were evolved enough to undergo this process. The
89 
                                                                                                                                                                                                                       
 

 Return to Amenti  
Annu lived in concentration in the Inner Earth, and were also disbursed
throughout the lands of Egypt and beyond. Through the inner passageways,
Annu from various locations were brought to Akhetaton at Tel el-Amarna
for ascension initiation and training, and then taken secretly into the lower
chambers of the Great Pyramid of Giza where they could pass through the
Halls of Amenti and return to Tara.   
         Though the Halls of Amenti had been opened in 1374 BC, Akhenaton
did not begin ascension practices until 1367 BC, when his sanctuary at
Akhetaton had been prepared and his training with the Priests of Ur had
been completed. For five years, between 1367 BC and 1362 BC Akhenaton
successfully trained and ascended several thousand people through the Halls
of Amenti, secretly and without incident. Though his spiritual commitments
left him little time or concern for the more mundane earthly affairs of poli-
tics, which made him highly unpopular among the general Egyptian popu-
lace, he was quite successful in fulfilling his purposes for incarnating on Earth,
and was held in high esteem by the peoples of Inner Earth and the surface
dwellers who understood the significance of his work. His success was, how-
ever, short lived, as his less-desirable character leanings of arrogance, intoler-
ance for the beliefs of others and favoritism toward the Annu peoples brought
an early end to his achievements, and ultimately created a major setback in
the greater plan of preparing the races for mass ascension. Akhenaton is still
primarily viewed as a master and revered avatar among descendants of the
Melchizedek people, who understand the purposes for his work on Earth. He
deserves much credit for his achievements in realigning the genetic imprint
of the Annu races and reintegrating their morphogenetic field into the
Sphere of Amenti. Though his general Earth mission was successful, it is still
worth mentioning the less-than-desirable events that colored his reign as
Pharaoh. Because of these events, the Halls of Amenti were once again
closed, and the quarantine under which the races had evolved since 9540 BC
remained in effect long after it was originally intended.             
            Conﬂict Between Ser res-Egyptian-Melchizedeks and Annu-  
         Melchizedeks and Akhenaton, Opening the Portals of the Underworld,
   Closing the Halls of Amenti, Guardianship of the Arc of the Covenant  
       transferred to Hibiru Cloister, Deactivation of the Rod and the Staff  
       and the Templar-Axion Seal, Tutankhamon and Haremhab.  
                                         1362 BC -1309 BC  
        
     Akhenaton successfully practiced the rites of ascension among the Annu
populations from 1367 BC to 1362 BC, following directives from the Priests
of Ur in the Inner Earth. Tensions began to mount between Akhenaton and
the Ur Priesthood when he was instructed to begin ascending other individu-
als not of Annu lineage. In his original soul agreement, Akhenaton was to re-
90 
 
                                                                                 

                                                                                 
                                                                                                               
                                                                                                               
                                                                                                              Pharaoh Akhenaton
enter the Annu-Melchizedek morphogenetic field back into the Sphere of
Amenti, see that the Halls of Amenti were opened, then oversee the training
and ascension of all individuals whose genetic codes would allow them to
pass through the fifth-dimensional frequencies into Tara. Serres-Egyptians,
and all of the other races were to be considered equally for this process, but
Akhenaton, from the beginning, showed extreme favoritism toward people of
Annu descent and an unwarranted prejudice toward those of Serres-Egyptian
lineage. To appease the Priests of Ur, Akhenaton would allow select Serres to
enter into the initiation programs at Akhetaton, but then systematically omit
them from the final stages of training, so the opportunity of program comple-
tion and ascension was denied. The Priests of Ur and the Elohim created an
alternative plan by which the Melchizedek Cloister Keepers of the Blue
Flame, who held strategic  positions  within  Akhenaton’s inner council, would
be permitted to conduct ascension rites under the direction of the Priests of
Ur, without Akhenaton’s knowledge of their activities.  
     The Keepers of the Blue Flame were headed by the primary Flame
Holder, a women named Phaelopea, who for long held the rank of High
Priestess of the Atonist temples at Akhetaton. The inner circle of the Flame
Keepers was composed of General Haremhab, head of Akhenaton’s strategic
armies of the north, the head physician of Akhenaton’s court and his illegiti-
mate, elder half brother Sabatoth, and his fourth wife Ankhi (historically
known as Kiya). There were approximately 200 other members of the Blue
Flame Melchizedeks among Akhenaton’s ranks, who had originally been sent
to support him in his efforts. As his personal prejudice and intolerance of the
Serres-Egyptians had colored his ability to ful fill his ascension duties appro-
priately, the Blue Flame Melchizedeks were assisted by the Elohim to carry
out ascension by night, using an alternative portal passage to the Great Pyra-
mid of Giza. Through the alternate route, the Keepers of the Blue Flame
would not have to pass through the portions of Inner Earth through which
Akhenaton conducted his ascensions, so both groups could ful fill the ascen-
sion contract, while circumnavigating Akhenaton’s personal character lean-
ings. From 1363 BC to 1362 BC the Keepers of the Blue Flame lead qualified
Serres-Egyptians and others to the Arc of the Covenant at Giza, successfully
ascending several hundred individuals not of Annu descent through the
Halls of Amenti.  
      In 1362 BC the inevitable occurred, and Akhenaton discovered the activi-
ties of the Keepers of the Blue Flame, and charged identi fied members with
treason, and sentenced them to death. Among those sentenced to die were his
fourth wife Ankhi and his half brother Sabatoth. With the assistance of the
Elohim, these individuals were exiled to Giza and placed under the protection
of a select group of Serres-Egyptian priests who had been permitted to know of
the secrets of Amenti. Akhenaton’s fourth wife Ankhi had produced a son for
91 
                                                                                                                                                                                                                        
                       

Return to Amenti  
Akhenaton in 1363 BC, and the child was later secretly taken to Giza by his
mother and several other Keepers of the Blue Flame. General Haremhab’s affil-
iation with the Keepers of the Blue Flame had not yet been discovered, and he
remained an operative within Akhenaton’s ranks, attempting to soften
Akhenaton’s wrath toward those whom he perceived as traitors. In 1362 BC,
shortly after the child was taken from Akhetaton to Giza, a final confrontation
took place between Akhenaton and the Keepers of the Blue Flame. The con-
frontation took place within the hidden passages beneath Giza, when
Akhenaton and his men followed Haremhab through the alternative portal
route and caught the Keepers of the Blue Flame in their ascension practices.
Using the Staff, Akhenaton attempted to close the Halls of Amenti. The
Flame Holder transmitted the D-5 frequencies held within her body into
Ankhi, who was to be the next Flame Holder. Ankhi transmitted the D-5 fre-
quencies of the ﬂame into the Sphere of Amenti to counter the transmissions
of the Staff, forcing the Halls to remain open. Akhenaton and Ankhi were
held within a duel of energy, with the Sphere of Amenti between them. Saba-
toth, Akhenaton’s unrecognized half brother, retrieved the Rod instrument
from Akhenaton’s guard and activated the second-dimensional frequencies of
the Rod in hope of knocking the Staff from Akhenaton’s grasp, fearing that the
power duel taking place would destroy the Sphere of Amenti. In a brief
moment the course of intended history was changed, as the second-dimen-
sional energy transmissions of the Rod interacted with the fifth-dimensional
energy transmissions of the Staff to create a double overtone frequency field.
When the double overtone was struck, the energetic barrier around the Sphere
of Amenti collapsed, opening the D-2 Earth morphogenetic field into the
Sphere of Amenti. This released the chaotic energies of the soul fragments
caught in D-1 and D-2 (known as the Underworld) into the morphogenetic
field of the Sphere of Amenti.  
    The Elohim immediately intervened, descending through the Arc of the
Covenant, resealing the Sphere of Amenti. Portions of the Amenti morpho-
genetic field had been contaminated by the chaotic forces of D-2, and the
Elohim had to separate the Sphere of Amenti, leaving the contaminated por-
tions within the D-2 Earth core morphogenetic field. The portions of the
Sphere that had not been compromised were placed back into the Arc of the
Covenant in the UHF bands of D-3, where the Sphere of Amenti was once
again sealed. Because of these events, the Halls of Amenti were once again
closed. The portions of Amenti that remained in Earth’s core stayed opened,
but the frequency bands of the Amenti Sphere that allowed passage into Tara
were sealed away in the UHF bands of D-3 within the Arc of the Covenant.
On the evening when this confrontation occurred, all members of the con-
flicting parties were energetically altered and returned to their home in
Akhetaton, having their memory of the night's proceedings erased.
92 
 
                                                                                                                

                                                                                                             
                                                                                                           Pharaoh Akhenaton
          
    Prior to this event, the Elohim and Priests of Ur had intended to orches-
trate the ascension of Akhenaton, his first wife Nefertiti and their daughters.
This was scheduled to occur after the seat of power had been transferred from
Akhenaton to his fourth wife Ankhi and their son, through whom the half
brother Sabatoth would acquire the throne until the avatar child came of
age. The Elohim intentions were to blend the Atonist and Amonist perspectives
together around the original Templar teachings of the Law of One, through which 
Egypt could be uniﬁed and serve as a model for preparing the races for ascension.
Following the closing of the Halls of Amenti, this plan was no longer feasible,
as the royals could not ascend to Tara while the Sphere of Amenti remained
split in two, so alternative measures had to be taken. The Sirian Council had
arranged for the royal family to be taken by starship to Sirius B after the trans-
fer of earthly power, but Akhenaton did not live long enough to ful fill this
vision.  
    The Elohim and Priests of Ur attempted to council Akhenaton following
the closing of the Halls of Amenti, but he misunderstood their attempts at
astral communication to represent attempted manipulation by evil forces.
Having no memory of the Giza events, Akhenaton was swayed by the Priests
of Ur, during physical contact, to allow the Flame Keepers to go free. He was
further advised to continue with the plan to allow Ankhi to be appointed as
wife number one so the child would be given legitimacy as the next heir to
the Pharaonic line. Events became a jumble of confusion as Akhenaton,
fearing treason at every turn, chose to disregard the requests of the Priests of
Ur that ascension practices be stopped. This request was given in good mea-
sure, as anyone attempting to ascend through Amenti while the Sphere was
broken into two pieces, would find their soul essence fragmented into D-2
and the upper portions of D-3. Thinking that he was sparing the Annu from
manipulation attempts by the Priests of Ur, Akhenaton used the Staff to
access the alternative portal route to Giza, and continued to ascend groups of
Annu through the portals, not realizing he was sentencing them to soul frag-
mentation. Sabatoth discovered Akhenaton was using the Halls of Amenti
and so he, going against the advice of the other Flame Keepers, also contin-
ued ascension attempts for the Serres-Egyptian peoples. Sabatoth discovered
that by using the D-2 portals to access parallel Earth, through which people
could merge consciousness with their anti-particle double and transmute
their DNA, that passage into the Halls of Amenti could be made without the
use of the Staff or Blue Flame. Neither man realized they were sending people
into fragmentation and both believed they were assisting their own people
who were being unfairly denied by the other side.  
    The Elohim again intervened to stop these activities. The personal mor-
phogenetic fields of individuals involved with ascension after the Halls of
Amenti were closed were removed from the Sphere of Amenti morphoge-
netic field and placed within the Third Eye of Horus portal passage in the
93 
                                                                                                               
                                                                                                                                                                                                                                 
 

Return to Amenti  
core of Sirius B, under the Templar-Axion Seal. This group included over
1,000 people, who would be allowed to ascend to Tara as soul essences once
the Halls of Amenti were reopened, but once there, they had to repeatedly
incarnate on Earth until they had fully assembled the fragmented portions of
their soul essence from the D-2 elemental kingdom. Akhenaton and his half
brother Sabatoth, and various others of Cloister Melchizedek and Serres-
Egyptian lineage were among those placed under the Templar-Axion Seal.
This Sealing was again employed as a protective measure, to insure that the
remaining portions of the Amenti Sphere were not compromised by the mis-
aligned energies of D-2. But unfortunately, through generations following
this lineage, portions of the Templar-Axion Seal were passed down indiscrim-
inately throughout various racial families, and the Templar-Axion Seal
became like a curse to the races, causing misalignment in various portions of
the Amenti Sphere, which were further passed on through various genetic
lines. These distortions in the Sphere of Amenti would have to be realigned
with the 12-strand DNA imprint before anyone could again ascend through
the Halls of Amenti.  
    Suffering from confusion caused by the cumulative effects of these events,
Akhenaton grew progressively more disinterested in the common affairs of
Egypt and devoted his attention to ensuring the position of his son as the next
heir to the throne. At this point, conspiratorial plans to remove Akhenaton
from power brewed heavily within his own legions, promoted primarily by his
uncle (the younger brother of Amenophis Ill). His first wife Nefertiti found
sympathy with the conspirators, as she did not take well to the intended trans-
fer of her position and power, pending the validation of the son as heir. The
Flame Keepers and Ankhi (wife number 4, whom Nefertiti blamed for destroy-
ing her family) appealed to Nefertiti for compliance, at the insistence of the
Priests of Ur. Unfortunately for all, Nefertiti could not muster the required
humility, and in 1361 BC she assisted the uncle in sabotaging Akhenaton’s
plans. The uncle orchestrated the assassination of Ankhi and Akhenaton’s
two-year-old son, thereby leaving the issue of heir to the Pharaonic throne
open to the highest bidder.  
    Distraught over the loss of his son and what he perceived as the failure of
his earthly mission, Akhenaton withdrew from social interaction, as General
Haremhab, Sabatoth and others devised a plan to remove Akhenaton from
power to protect Egypt from Akhenaton’s declining rule. In 1353 BC, with a
heavy heart, General Haremhab turned a blind eye as Akhenaton’s aged uncle
led the final conspiracy, assassinating Akhenaton and arranging the temporary
succession of Smenkhkaré (husband of one of Akhenaton’s daughters, who
secretly held a pro-Amonist outlook) to the throne. Haremhab, Sabatoth and
the Keepers of the Blue Flame hoped to see Smenkhkaré replaced by Sabatoth,
but after the fall of Akhenaton’s reign in 1353 BC, Sabatoth was imprisoned as 
94 
      

                                                                                      
                                                                                                             Pharaoh Akhenaton
a traitor in 1348 BC by the corrupt Serres-Egyptian Priesthood at Thebes (with
whom he had been raised in childhood), tortured for his knowledge of the
secrets of the Arc of the Covenant, then executed in 1344 BC.  
    Sabatoth left behind him a legacy within which lived the hope of the
Keepers of the Blue Flame. A child was born to Ihopetohetep, the wife of
Sabatoth, several months after he was incarcerated in Thebes in 1348 BC.
The child was named Tutankhaton. Haremhab and the Keepers of the Blue
Flame kept the child’s true lineage hidden and orchestrated a marriage
between this child and Akhenaton’s third daughter Ankhesenpaaton. In
1340 BC Smenkhkaré was assassinated by Haremhab’s secret guard, and 8-
year old Tutankhaton was proclaimed Pharaoh. In order to avert the suspi-
cions of the Serres priesthood, Haremhab arranged for the royal couple’s ini-
tiation through the Serres priesthood at Thebes, where their names were
changed to Tutankhamon and Ankhesenamon. Tutankhamon acted as a
puppet Pharaoh under the direction of Haremhab and an elder councilor-
priest named Aya, and the capitol was again moved from Akhetaton at Tel el-
Amarna to Memphis, so activities at Giza could be more closely monitored.
Originally Haremhab intended to uphold his commitments as a Keeper of the
Blue Flame. This required a slow but steady integration of the belief systems
of the Amonist and Atonist peoples. Under mounting pressure from the
Serres-Egyptian priesthood at Thebes, Haremhab succumbed to taking
actions which appeared to be more politically correct, and the teachings of
the Law of One became lost as he influenced Tutankhamon to abandon all
Atonist sympathy and revert to old Amonist perspectives. Having loyalties
to the Keepers of the Blue Flame, Tutankhamon attempted to resist Harem-
hab’s campaign.  
    In 1331 BC, when the 17-year old Pharaoh Tutankhamon was suffering
from an illness, several of Haremhab’s advisors took matters into their own
hands and poisoned him, removing the primary obstacle to Haremhab’s new
direction and ending the nine-year reign of Tutankhamon, the child king
(1340 BC-1331 BC). Haremhab quickly appointed the aging Aya, a long-
time friend and Serres-Egyptian sympathizer, to the Pharaonic throne. Fall-
ing hopelessly under the manipulation of the Serres-Egyptian old order,
Haremhab appointed himself Pharaoh following the death of Aya in 1324
BC. In order to preserve his political standing, Haremhab methodically set
about destroying any evidence of his prior affiliation with the Atonist move-
ment and involvement with the Cloister Melchizedek Keepers of the Blue
Flame. Haremhab reigned as Pharaoh from 1324 BC until his death in 1309
BC, appointing Rameses I as his successor. Following the death of Aya in
1324 BC, the Melchizedek Cloister Keepers of the Blue Flame became scat-
tered throughout Egypt, being considered criminals of the state for their prior
affiliation with Akhenaton. Some found refuge within the secret ranks of the
Serres priests at Giza, who still worked under the directive of the Priests of
95 
                                                                                                                            
                                                                                                                                     
                                                                                                                  
         
            

Return to Amenti  
Ur. By 1309 BC the Elohim plans for opening the Halls of Amenti and pre-
paring the races for the mass ascension wave of 2017 AD were lost beneath
the chaos left in the wake of Akhenaton’s clandestine rule.  
    Although Akhenaton was ultimately successful in re-entering the Annu
people into the Sphere of Amenti and successfully orchestrating the ascension
of many individuals during his brief reign, he left an equally detracting legacy of
chaos behind him. The Halls of Amenti were closed, the Sphere of Amenti
was broken in two, with part of the race morphogenetic field in chaotic sham-
bles within the D-2 Earth core and the other part again quarantined in the
UHF bands of the third dimension. The Arc of the Covenant was once again
sealed, and the Frequency Fence, which kept the Sphere of Amenti from
descending through the Arc, was once again put in place. Following the death
of Tutankhamon in 1331 BC, the Elohim and the Priests of Ur, disheartened by
the error of the human element, transferred surface guardianship of the Arc of
the Covenant out of Egyptian hands. The Arc of the Covenant was placed
under the protection of the Hibiru Cloister races, under the supervision of the
Blue Flame Melchizedeks. The Rod and Staff were de-activated, and thus
entry into the portals of the Inner Earth was stripped away from all races within
the surface cultures .¹ 
                                      
                                       THE THREE CHRISTS     Elohim and Sirian Council Favoritism toward Sirian Genetic Strains
  and Promotion of Patriarchal T emplar Creed Distortion. Pleiadian,
 Arcturian, and Andromeda Resistance and Azurites Appointed by Ra
Confederacy as Co-guardians of Palaidorian Covenant. Division within
                the Cloister Melchizedeks and Essene Brotherhood.  
                                               1240 BC -12 BC        
    The chaos which resulted from the misfortunes of Akhenaton’s reign also
created a major division within the ranks of the Elohim of HU-3, the Sirian
Council of HU-2 and the Ra Confederacy from the Meta-galactic Core. Dis-
pute arose as to what should be done with the program of human evolution.
The majority of Elohim had abandoned their loyalty to the human races in
general, and saved their attentions for Annu-Melchizedeks and Hebrew peo-
ples to whom they had closer genetic ties. In the years following Akhenaton’s
demise, the Elohim and Sirian Council began showing their favoritism of
these groups by purposely influencing the developing cultures to adopt the        ________________________  
1.   Some historical reference sources suggest that Akhenaton reigned from 1353-1335 BC
    and place Tutankhamon’ s reign from 1333-1323 BC. Speakers from the Sirian Council
                                provided the dates 1370—1353 BC for Akhenaton’s reign and 1340-1331 BC for Tut-
                            ankhamon; they request that I leave the dates as they have given. I cannot personally                                                                      
                                        attest to the accuracy of either set of dates .
               96 

                                                                                         
                                                                                      
                                              The Three Christs
distorted Templar Creed. They believed that by promoting male dominance
within the races (which was already a rampant distortion promoted by the
corrupted Serres-Egyptian line), the course of interbreeding could be con-
trolled . By controlling the women breeders and in ﬂuencing a male elite to practice
interracial discrimination, the Elohim's preferred lineage of humans could be kept
genetically pure. These selected “chosen ones” would be given special privilege
of ascension if they followed the teachings of the Elohim’ s altered Templar
Creed. The Elohim had basically given up on the rest of the human population,
and made no attempt to assist the general populace in realigning the damage done to
their genetic codes through the propagation of the Templar-Axion Seal.  
    Other members of the Elohim, Pleiadian Star League Council, Androm-
eda and Arcturian Federations felt this preferential treatment was unfair, and
appealed to the Ra Confederacy for intervention. The Ra Confederacy
agreed that this treatment was discriminatory and detrimental to the human
evolutionary plan. In 700 BC the Azurite Family of the Ra Confederacy was
called into operation as primary protectors of the Covenant of Palaidor, and
though willing to work with the biased Elohim, the Azurites were given an
equal hand in the orchestration of human evolution. Their primary concern
was to realign the morphogenetic field of the Sphere of Amenti, reintegrate
all of the races who had been removed and prepare the races for another
opening of the Halls of Amenti, to be scheduled in coincidence with the
mass ascension wave of 2017 AD. The Azurites and Elohim worked together
through the Melchizedek Cloister, establishing the Essene brotherhood about
1240 BC, which was originally designed to bring the undistorted Templar
teachings of the Law of One back into manifestation on Earth. (The Essenes
were originally one of the 25 families within the Melchizedek Cloister race.
Members of this family were interbred with the Hibiru Cloister races to cre-
ate a hybrid Hebrew strain. The Essenes thus had two primary racial divi-
sions, those of the Melchizedek Cloister and those of Hebrew mixed-Cloister
lineage.) Within several generations the biased Elohim took the project in
their own direction, interbreeding some of the Cloister Melchizedek families
with the Hebrew-Melchizedeks and promoting the patriarchal Templar
Creed, which became the primary focus of the Essene Brotherhood teachings.
By 1150 BC the Priests of Ur disassociated themselves from the primary fam-
ilies of the Essene brotherhood, and began working with a few select families
within the Essenes, and the Hibiru and Melchizedek Cloisters. These families
were chosen to reintegrate the undistorted pure Templar teachings and to
work directly with the Priests of Ur to ensure the race preparation for the
ascension wave of 2017 AD. In 700 BC the Ra Confederacy gave the Azur-
ites equal directive control over human evolution and appointed them pri-
mary guardians of the Covenant of Palaidor. The Azurites began their work
on Earth through the Essenes of the Priests of Ur. In 196 BC the Azurites and
the Sirian Council attempted to mend the growing rift within the
97 
                                                                                                                             
                                                                                                                                                                                                                          
 

Return to Amenti  
Melchizedek families by combining the previous teachings of the
Melchizedek Priesthood with the evolving doctrines of the patriarchal and
purist Melchizedeks.  
    The original Melchizedek Priesthood, as it exists today , was founded on
surface-Earth in 1982 BC, prior to Akhenaton’s reign, within the Hibiru Clois-
ter race in the area of Salem, which became Jerusalem. An ET Nephilim (an
immortal Sirian-human hybrid from the Second Seeding period) was brought
to Earth from Nibiru in 1979 BC, carrying a patriarchal version of the Templar
Creed, which allowed knowledge of ascension and genetic protection to reach
the Hibiru and Aryan races. This individual became known as Melchizedek,
King of  Salem . The foundations for the modern day Jewish religion were laid at
this time with the establishment of the Priesthood of Melchizedek among the
Hebrew, Hibiru and Aryan races, through which the mystical studies of the
original Kabbalah were organized. In 196 BC some success was achieved in
consolidating the Templar teachings by combining the old Templar-
Melchizedek doctrine with those of the Blue Flame Melchizedek Essenes and
the Templar-Melchizedek Essenes. Despite this achievement, two primary,
covert divisions within the Essene brotherhood remained. The Melchizedeks
and Hebrew Essenes who were under the in ﬂuence of the patriarchal Elohim
were known as the Templar-Melchizedeks.  They were primarily descendants
of the Hebrew-Melchizedeks who had received the Templar Seal in 8,000 BC,
and whose morphogenetic field still remained in Alcyone, not yet reintegrated
into the Sphere of Amenti. This group emphasized the patriarchal slant of the
Templar creed within the Jewish faith and heavily in ﬂuenced the evolution of
the Christian faiths. The Templar-Melchizedek Essenes were taught by the
Elohim to believe that they were God’s chosen people and that they held the
key to ascension. The covert group of Cloister Melchizedeks within the Essene
brotherhood, who worked secretly with the Priests of Ur under the Azurite
Council, were primarily descendants of the Blue Flame Pure-Cloister Family
Melchizedeks. The Blue Flame Melchizedeks had not received the Templar
Seal in 8,000 BC, and their morphogenetic field remained in the Sphere of
Amenti. Protection of the Arc of the Covenant and the secrets of Amenti had
been placed with the Blue Flame Melchizedek Essenes by the Azurite Council.
The Blue Flame Melchizedeks taught the original, non-patriarchal, egalitarian
creed of the undistorted Templar Creed, including the sacred teachings of the
science of ascension, the reality of reincarnation and ET ancestry and the pre-
cepts of unity consciousness and the Sacred Law of One. The two groups co-
existed with each other within the Essene brotherhood until 12 BC, when the
Azurite Council orchestrated the next major event in preparing the races for
ascension.  
98  
    
  

                                                                                           
                                                                                              The Three Christs
    
                      Reintegration of the Races into and Restoration of  
                              the Sphere of Amenti, the Three Christs,  
                           The Zionites and Preparation for 2017 AD.                        
                                                     12 BC-22 AD        
     The Azurite Council knew that in order for the races to be prepared for the
mass ascension wave of 2017 AD, the integrity of the Sphere of Amenti must be
restored by realigning the portions of the Sphere trapped within the D-2 Earth
morphogenetic field. The Alcyone morphogenetic fields of Templar
Melchizedeks and those that received the Templar-Axion Seal during
Akhenaton’s reign and were stored in Sirius B, also needed to be reintegrated
into the Sphere of Amenti. Despite the failures of Akhenaton’s campaign, he
had successfully reintegrated the Annu peoples into the Sphere of Amenti
morphogenetic field, so a similar arrangement was made in reference to the
Templar and Templar-Axion Sealed race families. This time, not only would
the races be restored to their place within Amenti, the entire Sphere of
Amenti would be realigned with the original 12-strand DNA pattern. Realign-
ment of the Sphere of Amenti would allow all of the races to heal their genetic
distortions in preparation for the opening of the Halls of Amenti, and would
restore the integrity of the Sphere of Amenti so the Halls of Amenti could he
opened. This realignment project would require the services of a 12th-level
avatar, whose energetic imprint contained the alignment of 12-dimensional
frequencies. This 12th-level avatar was to realign the Sphere of Amenti and
the Alcyone morphogenetic field of the Templar Sealed Hebrew and Annu
Melchizedeks, and he was intended to bring together the factions within the
Essenes that had developed within the Melchizedek and Hebrew Cloisters. He
would also re-enter the original egalitarian Templar creed back into the teach-
ings of the Essenes.  
    Under the direction of Azurites of the Ra Confederacy , in 12 BC, the
12th-level avatar, a pure Taran Turaneusiam-1 soul essence was born outside of
Bethlehem in a private residence, to a Blue Flame Melchizedek-Hebrew Essene
mother and a Blue Flame Melchizedek-Hibiru Cloister Essene father. It was not
an Immaculate Conception, but rather orchestrated via traditional means
through a couple chosen and prepared by the Priests of  Ur. His mother’s name
was Jeudi, his father Joehius; both were leaders within the Blue Flame
Melchizedek Essene sect. The child’s soul essence was born of the HU-4 avatar
Sananda,  and the child was named Jesheua-Melchizedek (herein Jesheua-12),
who later became known as Jesus, son of Mary and Joseph. The personages of
Mary and Joseph were not the parents of this avatar child, they were the par-
ents of a ninth-level avatar soon to follow. Jesheua-12 was born to descendants
of the house of Solomon, and taken in infancy into the custody of the Priests of
Ur.  
99                                                                                                                      
                                                                                                                                      
                                                                                                                   

   Return to Amenti  
      
  In 7 BC the Elohim orchestrated the birth of a ninth-level avatar, who
would serve to re-integrate the Templar-Axion Sealed souls of Sirius B, back
into the Sphere of Amenti and restructure the patriarchal Templar creed to
be more re ﬂective of the Law of One. This child was named Jeshewua (herein
Jeshewua-9), and the stories of his birth to the Hebrew-Melchizedek Essenes
Mary and Joseph are recorded as the birth of Jesus in contemporary Christian
doctrine. Jeshewua was not born of an Immaculate Conception either, but
rather through the visitation of an ET Nephilim, who, like King Melchizedek
had been, was part of the entity named Jehovah. The entity Jehovah, who
was one of the original contributors to the creation of the Sirian-Anunnaki
races of HU-2, had worked with the Elohim since the time of the Treaty of
El-Annu 848,000 years ago. Jeshewua’s mother Mary was also born of ET
Nephilim conception. Following the events of Akhenaton’s reign, the Elo-
him did not want knowledge of ET ancestry available to the general human
populations, so the truth of Jeshewua’s birth was hidden within the story of
the Immaculate Conception.  Through the centuries that followed the births of the
two avatars, the life stories of Jesheua-12 and ]eshewua-9, plus another man who
was not an avatar, became consolidated into one personage called Jesus Christ.
    With the birth of Jesheua-12, the 12th-level avatar, the Hebrew and
Melchizedek morphogenetic field in Alcyone was reintegrated into the Sphere
of Amenti. Through Jesheua-12 the integrity of the Hebrew Melchizedek
genetic imprint was restored, and he became known by some as the “savior” of
the Jewish peoples for this reason. The portions of the Amenti Sphere that had
been trapped within Earth’s D-2 morphogenetic field, as a result of
Akhenaton’s reign, were realigned and the integrity of the Sphere of Amenti
was once again restored. In a greater sense, Jesheua-12 became the savior for
the races, for through his birth the Halls of Amenti could once again be opened.
The realigned Sphere of Amenti was kept in storage within the UHF bands of
D-3, now under protection of the Azurites of the Ra Confederacy. At age 20 (8
AD), following his study in Persia and India, Jesheua-12 was taken to Egypt by
the Priests of Ur. At the Great Pyramid of Giza, while Jesheua-12 was between
20 and 33 years of age (8 AD through 21 AD), he and the Blue Flame
Melchizedek Essenes secretly orchestrated ascension for various groups, directly 
through the portal passage of the Arc of the Covenant. (Ascensions conducted 
while the Halls of Amenti were closed could only be done through the energy field 
of a 12th-level avatar, whose bio-energetic field could carry the energy fields of 
others through the seals on the Sphere of Amenti. Through the energy fields of the 
avatar, people could pass through the Arc of the Covenant, into the Blue Flame 
of Tara’s morphogenetic field and into Tara.)  
    Through Jesheua-l2, the Hebrew Essene races that followed the Blue
Flame Cloister Melchizedek Essenes were appointed by the Azurites of Ra, to
share guardianship of the Arc of the Covenant with the Melchizedek and
100 
 
 

                                                                                                                 The Three Christs
 
Hibiru Cloisters. The descendants of these groups presently carry the full 12-
strand DNA package within their gene codes, as this group was one of those
chosen in 1972 AD to receive full-genetic realignment through interaction
with the time traveling, hybrid Zionite  race (see Vo y a g e r s  I , p.38). The Zion-
ites were created during the present-day Zeta infiltration and were sent back in
time to realign certain ancestral groups with the 12-strand DNA imprint, in
order to accelerate the evolution of present-day humans. The followers and
descendants of the Jesheua-12 Essenes were one of the groups chosen for this
realignment. Groups involved with Zionite genetic restructuring are consid-
ered to be of Celestial Human lineage as they carry the full 12-strand DNA
Silicate Matrix within their operational genetic codes, regardless of their pri-
mary racial line. (The Silicate Matrix appears within family lines as a recessive
gene composite, which remains dormant until it is called into activation via
opening of chakra centers 8-15.) Various groups within Root Races 3-5 and
Cloister races 3-6, along with several other hybrid race strains, were chosen for
this genetic realignment, so the Silicate Matrix is distributed at random
throughout present-day human genetic lines. The greatest concentrations can
be found within the Hebrew, Melchizedek, Aryan, East Indian and Tibetan
racial lines.  
     During the period that Jesheua-12 practiced in Egypt (8 AD - 21 AD),
the second Christ, Jeshewua-9, grew in popularity among the families of the
Templar Melchizedeks and Hebrew Melchizedeks who were not aware of, or
interested in, the birth of Jesheua-12. Jeshewua-9 was also taken to Egypt for
initiation, ascension training and ordination as a Melchizedek priest, and
portions of these rites were conducted by Jesheua-12. Prior to his ordination
in Egypt, Jeshewua-9 had traveled throughout Nepal, Greece, Syria, Persia
and Tibet, training in various inter-faith doctrines. Jesheua-12 studied prima-
rily in India and Persia before coming to Egypt at age 20 and his Templar
teachings showed a stronger eastern orientation than those of Jeshewua-9.
The training and ascension activities of Jesheua-12 and the Blue Flame
Melchizedek Essenes remained primarily hidden and practiced as a secret
“mystery school” within Egypt at Giza and in various other locations. The
teachings of Jeshewua-9 became more well-known, which caused him pro-
gressively more persecution from Roman inﬂuence and also within some fac-
tions of the Hebrew and Templar-Melchizedek race lines who did not accept
deviations from the original patriarchal Templar creed as set within the Jew-
 ish religion by King Melchizedek.   
         When Jeshewua-9 was 32 years old (25 AD), with the assistance of sup-
portive Templar Melchizedek Essenes, the Elohim exiled Jeshewua-9, his wife
(the woman who came to be known as Mary Magdalene  in Biblical reference),
and their three children to the territories of France, to avoid political persecu-
tion. Another man, by the name of Arihabi,  who was a Jerusalem-born
101 
                                                                                                                       
                                                                                                                    
                                                                                                                 

Return to Amenti  
Hebrew-Annu-Melchizedek, was led by the Elohim, through a series of visions,
to believe that he was the true Jeshewua-9, and this is the man who was cruci-
fied. Neither of the avatar Christs were cruciﬁed, and both of them left genetic
family lines within the Hebrew-Melchizedek  races . The sacri fice of Arihabi was
orchestrated to divert attention away from Jeshewua-9, his family and his lin-
eage. The resurrection of the “body of Christ"/Arihabi, was orchestrated by the
Elohim through the use of holographic inserts, but Arihabi was indeed resur-
rected following the holographic display. In return for his assistance in divert-
ing attention from Jeshewua-9, the body of Arihabi was restored to life by the
Elohim, even though he was not an avatar. He was then taken to India, where
he lived for another 30 years. Upon his natural death, Arihabi’s soul essence
was ascended to Sirius B through the Third Eye of Horus portal bridge. After
his ascension to Sirius B, the Elohim granted him special favor and adjusted his
energy field so he could ascend to the Sirius star system in HU-2 via the plane-
tary core of Sirius A in HU-1. The story of Jesus Christ, as it is known in con-
temporary times, evolved through the mythology the Elohim used to conceal the
identity of their avatar, Jeshewua-9, and to perpetuate their patriarchal slant on
the Templar Creed. The distortions of the true facts of history were used to pro-
tect the lineage of Jeshewua-9 from political persecution, making it appear as if
the Christ had no descendants, thereby allowing those descendants to remain
obscured from the public view . The teachings of Jeshewua-9 and the Templar
Melchizedeks became the primary foundations for both the contemporary Jew-
ish and Christian faiths, but the Jewish religion did not acknowledge Jeshewua-
9 as their savior. In truth, Jesheua-12 was the true savior of the Hebrew peo-
ples, for he re-entered their race morphogenetic field into the Sphere of
Amenti. Few people knew of Jesheua-12 and his Blue Flame Melchizedek Ess-
ene ascension school, so the majority of the Hebrew people did not realize that
their foretold Messiah had, indeed, arrived. Even though Jesheua-12’s accom-
plishments went unnoticed by the majority of the Hebrew people, his affect on
the restoration of their genetic development was valid —an unseen gift to the
Hebrew peoples for which Jesheua-12 did not receive credit.  
    Between 8 AD and 21 AD, while Jesheua-12 practiced ascension rites at
Giza, several expeditions were made by Jesheua-12 and the Blue Flame
Melchizedek Essenes. They traveled throughout Egypt and Nubia and into
Jerusalem, promoting the original Templar teachings of ascension and gather-
ing together groups of people to take to Giza for ascension. Plans were made to
perpetuate the Jesheua-12 lineage, which carried the full 12-strand DNA
imprint, and six women of various Melchizedek Cloister sub-races were chosen
to bring forth the children of Jesheua-12, the First Christ. Couples were cho-
sen to serve as guardians of these children. Each of the six females to receive
the seed of Jesheua-12 was matched to a male Blue Flame Melchizedek who
102 
 

                                                                                        The Three Christs
would serve as adoptive father to the child of Jesheua-12. Jesheua-12 did not
interact directly with the raising of these children, nor did he serve as husband
to any of the six women chosen to carry his seed. The children were created
through sacred procreative rites for the sole purpose of perpetuating the 12-
strand DNA pattern within the human races. Descendants of these children
became spread throughout various regions, some appearing within the French
Aristocracies, others within the Celtic, Egyptian and African genetic lines.
One line of the descendants of Jesheua-12 now resides within the continental
United States. Of the six families of Jesheua-12 that were seeded between 18
AD and 23 AD, five of the children survived to bring the 12-strand DNA lin-
eage into the contemporary human gene pool. The lineage of Jeshewua-9’s
three children also prospered and spread throughout various nations to the
present day. In his later years, Jeshewua-9 traveled to Tibet, where, with the
help of the Elohim, he ascended out of matter in 47 AD to HU-3, through the
portion of Tara’s morphogenetic field stored within the planetary core of  Venus.
(This ascension passage requires a tenth-strand DNA imprint, and is thus not
available to most humans, without direct assistance and DNA reconstruction
by the Elohim, Azurites or other HU-2 guardian groups.)  
    The teachings of Jesheua-12 were highly censored by T emplar
Melchizedeks who later came into political prominence, and were kept alive
through the secret mystery schools that evolved throughout Europe, Egypt, the
Middle East and in certain parts of China and Indonesia. The teachings of
Jesheua-l2 were originally included in the manuscripts that became the Chris-
tian Bible, but were distorted or edited entirely at various times, to suit the
needs of the power elite within the evolving political-religious machine. Even-
tually the teachings were banned by the early Christian churches, for they dis-
closed the identity and tactics of the Elohim and other ET groups, and told of
the divisions within the Melchizedek Templar Creed. Very few of the original
Jesheua-12 teachings have survived into the present time, though there are
remnants of these teachings secretly preserved in France, that will one day be
discovered. The original teachings of ]eshewua-9 were also distorted and mis-
represented through political and religious structures of various times. The
teachings of contemporary Christianity, though they provide a basic structure
upon which social organization and spiritual initiation can be built, reﬂect little of
the depth, content or meaning of the original teachings of the avatar Christs.  
  Following the establishment of Jesheua-12’s lineage (18 AD-23 AD) the
avatar had completed his work on Earth. The Blue Flame Melchizedeks carried
on his teaching legacy and became the primary keepers of the secrets of the Arc
of the Covenant and the Sphere of Amenti. Various groups were assigned vari-
ous portions of the whole story, with no one group having the entire chronol-
ogy of the teachings of Jesheua- 12. Jesheua-12 left Earth through the Arc of the
103 
                                                                                                                                                                                                                               
 

Return to Amenti  
Covenant at 39 years of age in 27 AD. He did not die, but rather bodily
ascended to Tara, and has since evolved far beyond the con fines of physical
matter. The Arc of the Covenant was resealed within the UHF bands of D-3
following his ascension, awaiting the time when Earth’s grid rose high enough
in vibration to allow for the return of the Sphere of Amenti, which was sched-
uled to occur before the mass ascension wave of 2017 AD. The Azurite Coun-
cil, Interdimensional Association of Free Worlds and their many supporters
maintained a stance of non-interference following the success of ]esheua-12’s
mission. They allowed the Elohim and various other Host Matrix Families to
direct the course of earthly events as they desired, knowing that the truth of the
Templar and the Law of One, as upheld by the Blue Flame Melchizedeks and
Priests of Ur, would eventually come to light within the evolving human con-
sciousness. The Azurites planned to wait until the return of the Sphere of
Amenti to Earth's core before bringing this knowledge back into the public
domain, and in the meantime hoped to unite the Melchizedeks within the
teachings of the sacred Law of One.  
    Though Jesheua-12 had successfully aligned the race morphogenetic
field at Amenti with the original 12-strand DNA imprint, most of the races
still carried traces of genetic distortions from the Templar and Templar-
Axion Seals, which would need to be cleared prior to the opening of the
Halls of Amenti. The Elohim, Templar Melchizedeks, Blue Flame
Melchizedeks and many other unrelated Host Matrix groups have assisted,
and continue to assist, many individuals in clearing their genetic codes in
preparation for ascension. All present-day ideologies that teach conscious evolu-
tion, and DNA activation and transmutation, are geared toward this purpose,
including the new information currently being provided by various guardian ET and
metaterrestrial forces.  Jesheua-12, the 12th-level Turaneusiam avatar from
Tara, ful filled his purposes on Earth. Through him the Sphere of Amenti was
made ready for re-entry into Earth’s core, following which the Halls of
Amenti would eventually be opened. The race morphogenetic field had been
reunited, so following the opening of the Halls of Amenti, all souls could
again ascend through Amenti, once their genetic imprint had evolved to
assemble the fourth and fifth DNA strand. The plan for preparing the races
for the 2017 AD ascension wave was put back on schedule. Since 27 AD,
when the avatar Jesheua-12 ascended, the races of Earth evolved under the
primary influence of the Elohim and various other Host Matrix groups not
associated with the Christian and Jewish perspectives.   
    Through the achievements of Jesheua-12 and Jeshewua-9, the primary
morphogenetic imprint for all of the races was returned to the Sphere of
Amenti, and the Sphere of Amenti was once again made whole. These accom-
plishments set the stage for mass ascension, but the races still had a long way to
go in healing and evolving their consciousness and genetic codes. The Fre-
104 

                                                                                      
                                                                                                                The Three Christs
quency Fence quarantine (UHF D-3 seal) still blocked Earth from open rela-
tions with the inter-stellar communities. The Arc of the Covenant D-5
security seal kept all but the Melchizedek race strains from bodily ascension.
The races still carried portions of the Amenti Seal (DNA strands one, two and
three mutation, anti-particle “death” seal), the Palaidorian Seal (DNA strands
two and three mutation, D-4 seal), the Templar Seal (DNA strands two, four
and five mutation, D-6 seal) and the Templar-Axion Seal (DNA strands 1, 5
and 6 mutation, D-7 seal; the “666” seal) within their genetic codes and the
memory of the human lineage still remained locked away within the Sphere of
Amenti in the UHF bands of the third dimension. These conditions would
have to evolve and heal before humanity would be prepared to face the ascen-
sion wave of 2017 AD.  
    Throughout the evolution of the races, guardian races attempted to
awaken humanity to the reality of its evolutionary destiny. All of the major
Earth religions were seeded at one time or another by guardian groups, to help
the races prepare for their eventual ascension out of HU-1. Though the teach-
ings are often quite different or seemingly contradictory and all religions have
suffered manipulation and distortion at the hands of man and covert intruder
ET forces, they are united through their original purpose of achieving ascension
and freedom from the illusions of matter.  
     The secrets of Amenti were ultimately kept under the protection of the Blue
Flame Cloister Melchizedeks and the Hebrew Essenes who followed them, but
the reality of Amenti belongs to all of the races and world religions. The Sphere
of Amenti, Arc of the Covenant and Halls of Amenti represent the manifesta-
tion of the Covenant of Palaidor, which holds the evolutionary promise and pro-
gression for all races of the human lineage. It is the promise of humanity
returning to the integrity of the Immortal God-being that is the original morpho-
genetic imprint of the human race.          
      The promise of ascension is the hidden heritage and legacy of the human
condition, the ful fillment of humanity’s evolutionary blueprint.  
105  

                                                                          6                                                                                                                         
                                                                             
                                                                 
                         
                                                                                                           Ascension Mechanics                                                                
                                                   
                                                HUMANITY’S EVOLUTION             
                 The Science of Ascension, Time Cycles, Morphogenetic Waves                                                                                     and the Sphere of Amenti 
      As we have mentioned before, ascension is not some lofty spiritual con-
cept designed by the minds of man, it is the literal, tangible scienti fic process
of the evolution of consciousness and biology within the laws of energy
mechanics that apply to a multidimensional reality system. You can go about
your human lives, with your consciousness con fined to the limitations pres-
ently imposed by your physical body, or you can learn the mechanics by
which those limitations can be released, and begin to experience the reality
of freedom that is the comprehension of yourself-as-soul.  Whether or not you
view ascension and multidimensional evolution as a reality while you are alive on
Earth, you will be directly faced with that reality once your consciousness has
passed out of physical life and into the multidimensional framework. At the death
of the physical body you will discover that your consciousness lives on and
your evolution continues. How well you prepare for that discovery now will
determine the ease with which you are able to take your next evolutionary
step once you “wake up on the other side.” All souls will eventually evolve
and ascend through the 15-dimensional scale, to re-emerge as sentient iden-
tity within realms of pure consciousness beyond the dimensional systems. But
this process is not something that takes places automatically for humankind.
Humanity was created as a creator species, which means that thoughts and
actions entertained by the human will be met in manifest experience, both
on Earth and in the life experiences that take place beyond the earthly
planes. The choices one makes in thought and deed will determine the qual-
ity of experience, or lack thereof, that will be personally encountered in feel-
ing and event.  
    In preceding chapters  we have detailed for you the great challenges and
  struggles your species endured as it has blindly followed the hidden evolu-
   106  


                                                                                
                                                                                    Humanity’ s Evolution
tionary blueprint that calls it forth to evolve through time. That blueprint is
the Covenant of Palaidor and the morphogenetic field of the Sphere of
Amenti, within which the organizational plan and purpose for human evolu-
tion is stored. For 550,000,000 years this blueprint has called your races for-
ward toward an unseen destiny, which is the return of immortality and the
reunion of the consciousness of man with its creative Source.  In terms of the
soul’s perspective, the challenges and hardships faced along the way are
understood to be lessons in growth, as human consciousness evolves to
remember the truth of its eternal existence and embrace the beauty of its
multidimensional identity. From the perspective of a human consciousness
focused within a physical body on Earth, those challenges can seem, at times,
overwhelming. Without conscious recognition of the purposes, processes and
objectives of the evolutionary plan, the hardships can appear to be unbear-
able and without meaning. Through the portions of human evolutionary his-
tory we have detailed in these writings, you may be able to glimpse the
greater challenges and obstacles involved in the process of evolution, and to
realize that these obstacles do not end with the completion of your physical
lifetime.  
    Y our races have evolved on Earth for 550 million years, and many of
the souls involved in that evolution have had to return time and again,
trapped within cycles of birth, death and rebirth. Immortality, freedom from
death, disease and pain are the natural birthrights of your species. You will not be
able to reclaim these rights until you come to comprehend the greater reality
structures within which your evolution takes place, for through this compre-
hension you will learn to make choices that bring you joy and harmony,
health and freedom. If you are unaware of these greater reality structures you
will be unable to use them wisely, and it will seem as if the greater reality is,
instead, using you. You will feel powerless, and while you feel powerless and
             victimized by circumstance you cannot know freedom.   
             In view of the history we have provided, you may be able to see that
the Sphere of Amenti holds great importance to the evolution of your race,
for it holds the morphogenetic (form-holding) blueprint through which your
race consciousness manifests. You have learned that earthly consciousness is
directly affected by the condition and structure of the physical body and bio-
energetic systems, and that the DNA imprint which sets the biological struc-
ture for the body, is directly manifested through a morphogenetic field. The
personal morphogenetic field directs the design of the DNA, and thus the
body and the quality of consciousness that will be expressed through that
body. The personal morphogenetic field exists within the larger morphoge-
netic fields of the race and the species. The species morphogenetic field is the
Sphere of Amenti. The Sphere of Amenti connects the human species to
the greater morphogenetic field of the Earth, which, in turn, is connected to
the morphogenetic field of planet Tara in HU-2. In order for Earth, and
107 
                                                                                                                                
                                                                                           
                                                                                                                     
 

    
    
    Ascension Mechanics  
humanity, to evolve out of HU-1 and into the higher dimensional fields of
HU-2, the frequency patterns of dimensions four, five and six from HU-2
must be brought into manifest expression within the energetic grid of Earth.
These frequencies, or  sound tones , must also become operational within the
active DNA strands of Earth’s people. The energetic imprint of the DNA is
carried within the personal morphogenetic field and consciousness after phys-
ical death of the body. Whatever frequencies are contained within that
imprint will determine the dimensional placement of the consciousness after
death.  
    If freedom from the con fines and struggles of HU-1 is what one desires,
then it is wise to pay attention to the amount of frequencies contained within
the physical DNA, while one is still alive in body. Humanity has the power to
evolve consciously and thus more rapidly, by learning how to use the bio-ener-
getic system to build the needed frequencies into the DNA. This is a personal
responsibility , and although guardians from HU-2 can assist in this process, the
ultimate success of DNA building lies in the hands of the embodied conscious-
ness who directs this process by the way in which personal energy is used and
applied. The greater the amount of the 12-strand DNA imprint that can be
activated within the body’s DNA, the greater the amount of conscious aware-
ness and multidimensional knowledge that will be available to the conscious-
ness while it is physically embodied and after death.  
    Through this knowledge, greater joy can be created while living on Earth,
and following the death transition, the consciousness will be able to focus in
higher dimensions of reality. In order to end the cycle of rebirth in HU-1, an
identity must possess a fifth-dimensional level of consciousness, the particle
substance of the consciousness must pulsate at the speed of fifth-dimensional
frequency. The fifth strand of DNA must be fully assembled, and the lower-
dimensional DNA strands must be fully activated and aligned. An identity that
undergoes the death transition without assembly of the fifth DNA strand
imprint will continue evolution in the fourth-dimensional astral planes. If that
identity does not have the lower-dimensional strands fully assembled, it will
have to experience rebirth in HU-1, in order to fully assemble the lower strand
imprints. An identity that can fully assemble strands 1-5 while still within the
body will be able to merge its molecular particles with those of its anti-particle
double, and transmute the body itself into the higher-dimensional fields of HU-
2, literally transcending the experience of physical death. The human body was
originally designed to be immortal.  
    The process of DNA  transmutation does not only involve the personal
identity. As we have illustrated throughout our historical account, the ability
to ascend is also directly in ﬂuenced by the conditions of the race morphoge-
netic field, and by the Root or Cloister Race into which one is born. The
Sixth Cloister Melchizedek race holds the full imprint for the fifth DNA
108 
                                                                 

                                                                                   Humanity ’ s Evolution
strand, and several hybrid race strains contain the full l2-strand DNA pack-
age in dormant form. Individuals possessing these genetic codes have a per-
sonal advantage in terms of ascension, if their codes are fully activated. ln
order to be born into bodies with the advanced genetic lines these souls,
(unless they are over-souls or avatars birthing directly from HU-3 and
above), had to evolve through incarnations carrying the smaller gene-code
imprint, in order to attain the frequencies within their consciousness that
would allow them energetic compatibility with the larger gene-code body. In
other words, humans with larger gene-code imprints have earned this privi-
lege through their evolutionary progression, just as present-day souls within
smaller gene-code bodies are in the process of evolving into larger gene-code
bodies. All human souls are involved with the exact same process of evolving the
genetic package and consciousness to higher-dimensional levels; some souls are just
further along in this journey.  
    Humans carrying the larger gene-code packages are a gift to other
evolving souls, because, as they assemble their fifth and higher DNA strands,
they pull higher-dimensional frequency into the Earth’s grid. Once this
higher-dimensional frequency reaches a certain peak concentration within
the Earth’s grid, the race morphogenetic field/Sphere of Amenti opens into
the Earth’s core morphogenetic field, and the individual race morphogenetic
fields open into the Sphere of Amenti collective. At this point within the
energy mechanics, the Earth’s grid begins transmitting fifth-dimensional fre-
quency directly into the bio-energetic fields of everyone on the planet. This
infusion of fifth-dimensional frequency then sets the energetic imprint for the
fifth DNA strand within all of the races, even those whose personal, organic
morphogenetic imprint did not originally contain the fifth DNA strand.
Because of the races with the larger gene-code packages, the entire species
has the opportunity to rapidly evolve this larger DNA imprint and to trans-
mute the limitations of the genetic codes with which they were born.  
    The ability to fully transmute the personal genetic imprint is not always
available on Earth. It is dependent upon whether or not enough of the larger
gene-code races are present on the Earth, which is dependent upon whether
or not the Earth’s energetic grid vibrates high enough to sustain a concentra-
tion of beings with higher frequency genetic codes. If the Earth vibration is
too low, due to imbalances in its bio-energetic systems, souls carrying higher
frequency energies cannot birth onto the planet, for the frequencies con-
tained within their bio-energetic fields would literally overload the Earth’s
grid and cause it to collapse. The evolution of DNA within the races is dependent
upon the vibrational evolution of the Earth.  If the condition of the Earth’s bio-
energetic field is poor, due to pollution and abuse of its natural environment
and digression of the consciousness upon the planet, Earth cannot sustain a
concentration of high-frequency soul essence. This also means that Earth
cannot hold the UHF of the Sphere of Amenti at its core. If the Sphere of
109 
                                                                                                                 
                                                                                                            

Ascension Mechanics  
Amenti is not within the Earth’s core, its frequencies cannot be opened into
the Earth’s grid, and thus the bio-energetic fields of the races will not receive
an infusion of fifth-dimensional frequency. It is the infusion of fifth-dimen-
sional frequency that allows the imprint for the fifth DNA strand to manifest
within all races. Thus in order for the races to have the opportunity for accel-
eration of evolution, Earth must be able to sustain a concentration of souls
with higher frequency gene codes and be able to hold the Sphere of Amenti
at its core. The Earth grid must be in balance for this evolutionary accelera-
tion of the races to occur.  
                                      
                                       EARTH TIME CYCLES                                         
                                            Morphogenetic Waves  
    There are only certain points within each 26,556-year cycle of time
that the Earth grid reaches a vibration rate high enough to accommodate an
infusion of fifth-dimensional energy. It is during these times that Earth can
sustain larger concentrations of higher-frequency souls, and thus it is only
during these periods that the Sphere of Amenti can be fully opened within
the Earth core, to allow assembly of the fifth DNA strand for all of the races.
There are other periods, such as during the time of Pharaoh Akhenaton,
when the Sphere can be returned to Earth core and the Halls of Amenti
opened. But the full frequency patterns of the Sphere of Amenti can be trans-
mitted through Earth’s grid only during the periods of dimensional blending
that occur four times in each 26,556-year cycle. Akhenaton was able to open
the Halls of Amenti and orchestrate ascension only for those individuals who
had the fifth DNA strand imprint, but he could not release the Sphere of
Amenti directly into the D-2 Earth core morphogenetic field to create mass
DNA assembly and ascension. During the four periods in a 26,556-year cycle
when dimensional blending occurs, certain energetic conditions take place
within the morphogenetic fields of the planet that do not occur at any other
time. During these periods, the energetic grid of Earth fuses with the ener-
getic grid of its double within the parallel universe, or with its counterpart’s
parallel double from the next Harmonic Universe up. In the first 4,426-year
cycle of the 26,556-year cycle, Earth fuses twice with its own double in HU-
1, once at the half-point in the 4,426-year period and once at the end of that
period. These two time periods are called Primary Conjunction Points.  In
the last 4,426-year cycle of the 26,556-year cycle Earth fuses twice with its
HU-2 counterpart double, once at the half-point and once at the end of that
4,426-year period. The two time periods when Earth fuses with its counter-
part double are called Primary Coordinate Points.  T ara is Earth’s HU-2
counterpart, so, during the Primary Coordinate Points, Earth’s grid fuses with
the energetic grid of parallel Tara. The two 4,426-year cycles at the begin-
ning and end of a 26,556-year cycle, in which Primary Conjunction Points
110 

                                                                                   
                                                                                                                Earth Time Cycles
and Primary Coordinate Points occur, are collectively referred to as  Ascen-
sion Cycles.  Ascension cycles occur only twice within a 26,556-year Har-
monic Time Cycle. Earth fuses with its double twice within the first 4,426
years after entering a 26,556-year Harmonic Time Cycle. Earth fuses twice
with its counterpart double parallel Tara, once after being in the 26,556-year
cycle for 24,343 years (half-cycle Coordinate Point in the second ascension
cycle) and once after completing the full 26,556 years of the Harmonic Time
Cycle, at the end of the second ascension cycle.  
    When Earth encounters its first Coordinate Point within the second
Ascension Cycle, all of its particles that are composed of the overtone fre-
quencies of dimensions one, two and three merge and fuse with the anti-par-
ticles of parallel Tara that are composed of the base-tone frequencies of
dimensions four, five and six within the parallel dimensional scale of HU-2.
As Earth’s particles fuse with Tara’s anti-particles, both particles and anti-par-
ticles enter hyper-space ; they momentarily return to their higher-dimem
sional morphogenetic fields. Earth’s D-1 overtone particles return to their D-
15 morphogenetic field, the D-2 particles return to D-14 and D-3 particles
return to D-13. Tara’s D-4 anti-particles return to their morphogenetic fields
in D-12, the D-5 anti-particles return to D-11 and the D-6 anti-particles
return to D-10.  
    When the particles and anti-particles again leave the morphogenetic
field, they reverse their spin and polarity, shift their angle of rotation by 45°,
and then return to the frequency bands of one Harmonic up. D-1 particles re-
appear as anti-particles within the fourth-dimensional frequency bands, D-2
particles re-appear as anti-particles within the fifth-dimensional frequency
bands and D-3 particles re-appear as anti-particles within the D-6 frequency
bands. Earth’s particles shift from HU-1 into Tara in HU-2. Tara’s anti-parti-
cles also reverse spin and polarity, and re-appear one Harmonic Universe up.
Tara’s D-4 anti-particles reappear as particles in D-7, D-5 anti-particles
become non-matter-based particles in D-8 and D-6 anti-particles reappear as
non-matter-based particles in D-9. Tara’s anti-particles shift from HU-2 into
Gaia’s etheric matter body in HU-3 This transformation of particles consti-
tutes a full shift of Earth’s overtone particles from the time cycles of the parti-
cle universe in Harmonic Universe 1, into the time cycles in the parallel/
anti-particle universe in Harmonic Universe 2.  
    T ara’ s base-tone anti-particles simultaneously shift from the time cycles
of the anti-particle universe in HU-2, into the time cycles of the etheric par-
ticle universe in HU-3. This is the process by which planetary bodies (and
the life-forms residing upon them) evolve their matter particles and anti-par-
ticles upward through the l5-dimensional scale, from dense matter solidity to
pure, non-matter-based conscious energy substance. Ascension through the
time cycles represents the progressive acceleration of particle and anti-parti-
cle pulsation speeds, created through the systematic merging of particles and
111 
                                                                                                                   
                                                                                                              

 Ascension Mechanics  
anti-particles, from the lowest dimensions to the highest, within the 15-
dimensional scale.  
    The progressive release of particles and anti-particles into the morpho-
genetic field at the Primary Coordinate Points in the second ascension cycle
constitutes the release of a particle/anti-particle wave of energy. This parti-
cle/anti-particle energy wave is called a morphogenetic wave.  The morpho-
genetic wave represents the energy released as particles and anti-particles
fuse, exploded into the morphogenetic field/hyper-space and undergo fission
and replication, through which they re-appear in expanded form within the
dimensional frequency fields of the next highest Harmonic Universe.
    At the beginning of a 4,426-year second ascension cycle, the Earth draws
patterns of frequency into its morphogenetic field at Earth’s D-2 core from the
dimensional Uni fied Field of energy. When Earth approaches the half-point in
the cycle, the core morphogenetic field has expanded to its full capacity of
energy holding. About 15 to 20 years before the half-cycle point the Earth’s
energetic grid begins to interact with that of Tara, just as the Earth’s core mor-
phogenetic field reaches full energy-holding capacity and explodes, releasing a
rush of energy through the Earth’s grid. As this energy is released, the particles
carrying overtone frequencies begin merging with Tara’s anti-particles carrying
base-tone frequencies. As Earth’s particles and Tara’s anti-particles progres-
sively merge, they enter hyper-space and transmute into their respective
dimensional morphogenetic fields. 
    This particle/anti-particle transmutation progressively accelerates, as the
energetic grids of Earth and Tara come into alignment, transmuting more and
more overtone particles and base-tone anti-particles into the morphogenetic
fields. The progressive transmutation of particles and anti-particles creates a
building wave of energy moving from Earth and Tara, into the higher-dimen-
sional morphogenetic fields. And like the undertow of a tide, this energy wave
creates a back ﬂow energy wave, from the morphogenetic fields, through which
Earth’s overtone particles re-manifest as Tara’s base-tone anti-particles and
Tara’s base-tone anti-particles re-manifest as Gaia’s particles.  
      The height of the process occurs when the grids of Earth and T ara come
into full alignment at the half-point in the cycle, at which time the morpho-
genetic wave fully crests, and the grids of Earth and Tara begin pulling away
from each other. The crest of the morphogenetic wave begins about five years
before, and extends up to the half-cycle point. During the five-year crest of
the morphogenetic wave, all of Earth’s overtone particles, and Tara’s base-
tone anti-particles, fully transmute into the morphogenetic fields. As Earth’s
overtone particles become progressively suspended in hyper-space and the
dimensional base-tone frequencies left within the Earth’s grid begin to blend
with the overtone anti-particles in Tara's grid, an Harmonic Resonant Tone
is formed. Through the Harmonic Resonant Tone the spin and polarity of
112 
                                                                          

                                                                                     
                                                                                         Earth Time Cycles
Earth’s base-tone particles and Tara’s overtone anti-particles temporarily
reverse, and their angle of rotation shifts 45°. When the polarity of Earth’s
particle base is reversed, Earth’s magnetic poles spin, reverse and shift 45° in
their angle of rotation, and the Earth enters the faster moving parallel time
cycle in the HU-1 anti-particle universe. As this occurs during the five-year
cresting of the morphogenetic wave, Tara’s anti-particles are also going
through a pole reversal and time cycle shift. The electrical fields in Tara’s
grid spin, reverse and shift 45°, and anti-particle Tara shifts into the parallel
time cycle in the HU-2 particle universe.   
        The particle pulsation rate of Earth’ s parallel, anti-particle time cycle in
HU-1 is twice the speed of the same cycle in the HU-1 particle universe. The
particle pulsation rate of Tara’s HU-2 particle time cycle is also twice the
speed of Earth’s particle time cycle. When anti-particle Tara enters its paral-
lel particle time cycle in HU-2, and particle Earth enters its parallel anti-par-
ticle time cycle in HU-1, the two planetary grids are entering the same
particle pulsation rate and thus the same time cycle. Base-tone particle Earth
and overtone anti-particle Tara temporarily merge in the dimensional fre-
quency bands of D-4. As long as the electromagnetic fields of both planets
are in balance, this simultaneous 45° shift in angular rotation and reversal of
polarity in particles and anti-particles will not cause a shift of the physical
Earth on its axis. The electromagnetic fields of each planet keep the fields of
the other in balance. Some ﬂuctuation in Earth’s magnetism may be detected,
and some tectonic movement may occur in areas that are not fully energetic-
cally balanced, but the basic structure of the Earth’s body will remain intact.
If the grids are not balanced, however, a full 45° tilt of Earth’s rotation upon
its axis could result, which would create massive Earth changes.  It is very
important that the Earth’ s bio-energetic structure and electromagnetic grid are bal-
anced during this ﬁve-year period.  
    In this five-year transition during the crest of the morphogenetic wave,
the magnetic grid of particle Earth becomes electrical, and the electrical grid
of anti-particle Tara becomes magnetic. The two planetary grids merge and
some of the land mass contours of Tara emerge on Earth as etheric overtone
structures . When particle Earth returns to its particle time cycle in HU-1,
these land masses will manifest first on the anti-particle Earth, and by the
close of the full ascension cycle 2,213 years later, these new land configure-
tions will manifest physically on the particle Earth. (This is what is meant by
the New Age concept of literal “Atlantis Rising”. These lands of Tara will
indeed rise up on Earth, but normally they will do so progressively over a
period of 2,213 years, not all at once.)  
    At the height of the morphogenetic wave crest, during the half-point
in the cycle, there is an approximately three-day period when Earth’s mag-
netic fields temporarily collapse as the spin of particles and anti-particles
slows, polarity again reverses, and the angle of particle rotation shifts back
113 
                                                                                                           
                                                                                                                                                                                                       

Ascension Mechanics  
45° to its original position. Within that three-day period, particle Earth
returns to its HU-1 time cycle in the particle universe, and anti-particle Tara
returns to its HU-2 time cycle in the HU-2 anti-particle universe. There will
be difficulty with the functioning of earthly electrical and magnetic devices
during this period, and the human mind and body will experience an exces-
sive feeling of tension, pressure and fatigue. Strange atmospheric anomalies
may occur, including a prolonged period of darkness and daylight, and the
possible appearance of a double moon, depending upon the balance of the
Earth’s grid. These symptoms will release as soon as the transfer of time cycles
is completed, but during the three-day period tremendous stress will be
placed upon the human’s body, mind and emotions.  
    Prior to this three-day shifting period, during the five-year crest of the
morphogenetic wave, electrical energy is magnetically pulled from particle
Earth’s core into anti-particle Tara’s core and the fifth-dimensional frequen-
cies of Tara’s core blend into Earth’s D-2 core morphogenetic field. At this
time, the fastest-vibrating base-tone particles of Earth —those that vibrate to
the particle pulsation rate of the fifth-dimensional frequencies—are trans-
ferred from particle Earth’s D-2 core morphogenetic field into anti-particle
Tara’s D-5 morphogenetic field. These mechanics of energy create a ﬂuctua-
tion within the electromagnetic fields of both Tara and Earth, which operate
as a warp in space-time. This naturally occurring time warp serves as a portal
passage between Earth and Tara, which opens at the beginning of the five-
year period, reaches its height of activity during the half-point of the ascen-
sion cycle five years later, then progressively closes from the half-point to its
full closing five years following the half-point.  
                                     
                                 THE HOLOGRAPHIC BEAM                                                                                                                                          
                 The Holographic Beam, the Photon Belt and the Pleiades  
       
    During the course of this 10-year period, five years prior to and after the
half-point, fifth through ninth-dimensional frequencies are progressively
infused into Earth’s grid, then into the bio-energetic fields of all life-forms on
Earth. The infusion of frequency from the higher-dimensional fields and
Tara’s core in D-5 into Earth's core in D-2 follows a natural path of interdi-
mensional energy circulation, through which HU-1 through HU-5 are con-
nected. Each Harmonic Universe has a Harmonic Time Cycle, such as that
of HU-1, which is 26,556 years long. All of the Harmonic Time Cycles are
synchronized through the particle pulsation rates within each of the 15
dimensions. When Earth enters the half-point in its second ascension cycle,
its grid fuses with the grid of anti-particle Tara precisely because these Har-
monic Time Cycles are synchronized. When Earth reaches its half-point, not
only does a warp in space-time occur within HU-1, it occurs all the way up
through the five Harmonic Universes. A time-warp portal opens all the way
114 

                                                                                                    
                                                                                   The Holographic Beam
up through the 15-dimensional scale. This opening of interdimensional por-
tals, which creates the morphogenetic wave, allows a beam of UHF energy to
pass from the Meta-galactic Core in D-8, through all of the Harmonic Uni-
verses. We refer to this as the Holographic Beam, for it is the primary spiral
of transmitting energy that feeds and sustains all of the dimensional systems
and the holograms of matter which take place in those systems. The path of
the Holographic Beam follows a particular route into the time cycles of HU-
1. lt spirals down through various planetary cores from HU-2 and HU-3,
through the planetary core of Alcyone in the Pleiades, through various other
planets and then enters your solar system through the core of the sun. From
there the Holographic Beam moves outward and through the cores of the
planets in your solar system. As the planets move within the cycles of their
orbits, at certain points they align with the sun in a particular way, and pass
through the projection of this Holographic Beam.  
    The Holographic Beam is released when the portals open during the
half-point of the ascension cycle and again at the close of the ascension cycle
2213 years later. The Holographic Beam that was released during the ascen~
sion cycle at the end of the previous 26,556-year period leaves its trace
within the HU-1 galaxy. The beam from the past cycle will appear as an area
of concentrated photon activity surrounding the planet Alcyone, through
which the beam entered HU-1. The Holographic Beam follows a path
through the Pleiades to Earth because Earth’s sun is actually the eighth star in
the Pleiadian system. As discussed in earlier chapters, during the cataclysm
550 million years ago, fragments of Tara's morphogenetic field were pulled
through the center of this Pleiadian star. The planets of Earth's solar system,
which are fragments of Tara, then re-formed around this star in HU-1.
(Recent speculation in the private scientific communities suggests that our
solar system is a binary solar system having two suns. Alcyone, the central sun
of the Pleiadian star system is actually the primary sun of our solar system. Our
sun is a star within the Pleiadian solar system.)  The area of photon energy
around the Pleiades has been referred to as the Photon Belt, which was dis-
covered by Earth scientists in 1961 through mechanical observation of that
star system. (Photons are created through the fusion of multidimensional par-
ticles and anti-particles, so the Photon Belt is the residual energy left over
from the last morphogenetic wave. That energy is replenished every 26,556
years as the Holographic Beam projects through Alcyone twice during each
second ascension cycle.)  
     As Earth moves through its next 26,566-year cycle following the release
of the last Holographic Beam, completing a full round of its Harmonic Time
cycle, it will appear as though the Photon Belt is moving closer to Earth and
its solar system. They are actually moving toward each other, as the Pleiades
and the Earth’s solar system travel in their orbits within the HU-1 and HU-2
Harmonic Time cycles. When Earth completes its half-point in the second
115 
                                                                                                                          
                                  

Ascension Mechanics  
ascension cycle, its overtone particles will pass into the Photon Belt, just as a
new release of the Holographic Beam takes place. The new release of the
Holographic Beam creates the morphogenetic wave that allows portions of
Earth and Tara to temporarily merge within the fourth dimension. The infu-
sion of Earth’s grid with D-5 through D-9 frequency occurs through the Holo-
graphic Beam. When that energy infusion begins, five years prior to the half-
point, Earth begins passing into the Holographic Beam as it merges with Tara
and enters the D-4 time cycle. As this occurs, Earth’s overtone particles move
into the Photon Belt. While particles and anti-particles reverse polarity and
spin, and the angular rotation of particles shifts 45°, the morphogenetic fields
of D-2 Earth’s core and D-5 Tara’s core come into direct alignment with the
Holographic Beam. The beam allows the D-2 and D-5 planetary core mor-
phogenetic fields to open into each other, which creates an infusion of D-5
frequency into Earth’s grid.  
    At the height of the morphogenetic wave crest, at the half-point in the
cycle, the Holographic Beam is aligned directly through the planetary cores
of Earth, Tara and Gaia for about three days, and the grids of Earth and Tara
are in complete alignment. The Holographic Beam runs from the D-8 Meta-
Galactic Core, upward into the D-9 Galactic Core, then downward, directly
through the cores of Gaia in HU-3, Tara in HU-2 and Earth in HU-1. This
creates an infusion of D-8 and D-9 frequency through the three planetary
grids, and allows an ascension passage from Earth, through Tara and into
Gaia and beyond, to open during the three-day period. The morphogenetic
fields of each planet absorb as much UHF energy from the beam as they can
hold, at which point the morphogenetic wave reaches its full crest and parti-
cle/anti-particle spin begins to slow in preparation for Earth’s return to its
HU-1 time cycle. Particles and anti-particles reverse spin and polarity, and
their angular rotation shifts 45° back to its original position, as Earth begins
to shift out of direct alignment with the Holographic Beam and Tara’s grid.
After a three-day period Earth returns to its HU-1 time cycle and the time
warp portal between D-2 and D-5 begins its five-year closing period, and the
portals between D-9, D-8 and D-7 close. The grids of Earth and Tara begin
their five-year period of moving out of alignment with each other, and Earth’s
overtone particles remain within the Photon Belt. Normally Earth’s overtone
particles would remain within the Photon Belt for 2213 years, until the next
morphogenetic wave, when the base-tone particles would also enter the Pho-
ton Belt and Earth would shift fully into the HU-2, D-4 time cycle to begin
another 26,556-year Harmonic Time cycle.  
116 

 
                                                                                 
                                                   DNA and the Halls of Amenti
                           
                           DNA AND THE HALLS OF AMENTI                     
                 DNA, the Morphogenetic Wave, the Halls of Amenti,  
                                            and the Doreadeshi  
    During the period of five years prior to and five years after the half-
cycle point, the imprint of the fifth DNA strand is made available to all of
the races, and the opportunity for ascension to Tara is made available to all
who can fully activate that strand before the close of the dimensional time
warp portal five years following the half-point. Ideally, the Sphere of Amenti
race morphogenetic field and the Blue Flame Staff of Amenti, Earth’s portion
of Tara’s morphogenetic field, will be placed within this time-warp portal in
Earth’s D-2 core during the half-point in the second ascension cycle. During
this 10-year period, the Halls of Amenti portal passages to Tara, and to other
time fields of Earth in HU-1, become open to the masses. In order for the
morphogenetic wave, mass ascension and evolutionary leap in time to occur,
the Sphere of Amenti must be held and opened within the D-2 Earth core
morphogenetic field, and the Blue Flame must be embodied within 8% of
Earth’s populations.  
    Individuals whose body , bio-energetic field and consciousness pulsate
at the rate of fifth-dimensional frequency will experientially perceive either
direct, bodily transmutation through a time portal passage from Earth to Tara,
or a time travel transport to Tara via interdimensional spacecraft (arranged
by guardian groups to assist those who cannot quite make it through the
dimensional transmutation of the portals). They will end up on Tara in a
space-time coordinate about 5,532.5 years in the future from Earth’s original
space-time position. At the end of the five-year period following the crest of
the morphogenetic wave, people who have not fully assembled the fifth DNA
strand will find that the assembled portions of that strand begin to disassem-
ble. 
    When Earth returns to its time cycle in the particle universe, the ener-
getic imprint of the fifth DNA strand will remain in their bio-energetic field,
and will manifest within their anti-particle double on parallel Earth, but the
fifth strand will no longer manifest into the person’s operational gene code.
The Halls of Amenti will no longer be passable for such individuals until the
fifth strand slowly assembles over the course of the next several incarnational
cycles within HU-1. These individuals will be stuck in the HU-1 incarna-
tional cycles until they can build the fifth strand or until the next morphoge-
netic wave period 2213 years later, whichever comes first. The Halls of
Amenti will remain passable only to those who organically possessed the fifth
DNA strand imprint. The 10-year period, starting five years before and end-
ing five years after the half-cycle point, allows the races the opportunity for
an evolutionary leap in time. This opportunity occurs only twice in a 26,556-
year cycle, during the second ascension cycle. During this period many
117 
                                                                                                              
                                                                                                                    
                                                                                                       

      Ascension Mechanics  
human souls, who cannot fully assemble the fifth strand while embodied, but
have assembled the fourth strand, choose to drop their physical bodies, so
they may rapidly assemble D-5 frequency into their morphogenetic field from
D-4. Such individuals will ascend to Tara as soul essence from D-4, so they do
not have to continue incarnational cycles in HU-l. There are frequently
localized disaster events during these periods through which masses of people
die and leave their bodies at one time. The events may appear tragic from an
earthly perspective, but from the soul perspective participation in these events is
planned in order to catch the morphogenetic wave and ascend.  
    During the five-year period prior to the half-point in the cycle, when
Earth and Tara shift into the fourth-dimensional frequency bands, the part of
Earth’s particles that vibrate/pulsate at D-5 speed, begin to fully transmute
and appear on Tara, within the time cycles of HU-2. The highest vibrating
particles enter hyper-space and re-appear in the future. The portions of
Earth’s particles that pulsate the slowest fall further in vibration at the release
of the higher pulsating particles and drop into the Uni fied Field of the base-
tone frequency patterns of D-1. The slowest vibrating particles break apart
their form construction and re-appear as part of the Earth’s particle-base in
the past, at a time period in the beginning of the present 26,556-year cycle.
The particles pulsating at a middle range rate of speed enter the faster time
cycle of D-4 for five years, then return to their original time cycle in HU-1 to
complete the remaining 2213 years of the ascension cycle. The mid-range
vibration particles appear within the present time continuum in the parallel
anti-particle universe (which is the same time continuum as the D-4 cycle in
the particle universe), then after five years return to their original present D-
3 HU-1 time continuum.  
    What this process constitutes in terms of the human perspective, is the
opening up of three tracks of time,  or three time continua, during the 10-year
period surrounding the half-point within the second ascension cycle. Human
beings and their consciousness are made up of energy particles. As Earth under-
goes this particle separation, transmutation and dimensional transfer, the ener-
getic structures of human biology and consciousness also undergo this
transformation via the makeup of their particle content. Humans possessing
the slowest vibration rates would find their consciousness fragmenting into the
distant past and their body form returning to the uni fied field of the first dimen-
sion. Not to worry, however, as the collective race consciousness now vibrates
high enough, thanks to the efforts of visiting guardian races, so humans would
not experience this evolutionary digression into D-1 in the event of a morpho-
genetic wave.  
      Humans possessing mid-range vibration rates, which is presently the
majority of the population, would normally find themselves within the present
time continuum, where things look the same, but this continuum, in actuality,
118 
 
                                                             

                                                                            
                                                                            DNA and the Halls of Amenti
would be taking place within the D-3 time cycle of the parallel universe. The
D-3 time cycle of parallel anti-particle Earth is, in reality, the same time cycle
as the fourth dimension cycle in the particle universe. Thus humans possessing
mid-range vibrational rates would find themselves on Earth entering the time
cycle of the fourth dimension for a period of five years. Humans who have the
highest vibration rates will enter hyper-space then re-appear on Earth within
the next Harmonic Universe up, HU-2, which constitutes a position in time
5532.5 years in the future. Humans with the highest vibration rates will find
themselves traveling through time, experientially either by portal passage or via
spacecraft, to the future parallel Earth of HU-2. The future Earth and its paral-
lel in HU-2 represent the planet Tara and its double, at a point in time 225 mil-
lion years in the future from the time of Tara’s cataclysm.¹  
    Normally , within five years following the half-point morphogenetic
wave crest, the overtone particles of Earth will have entered the HU-2 time
cycles. During the morphogenetic wave 2213 years in the future, at the natu-
ral close of the ascension cycle, the remaining base-tone particles of Earth
would transmute in the same manner. Earth would shift completely out of
HU-1 and fully enter the D-4 time cycle, the first 4,426-year cycle of the
26,556-year cycle in HU-2. This natural close of an ascension cycle is called
the Doreadeshi.  Earth’ s natural shift from the HU-1 to the HU-2 time cycles
would normally occur in two stages. The overtone particles of Earth shift in
the morphogenetic wave at the half-cycle point, and the base-tone particles
of Earth shift 2213 years later, in the second morphogenetic wave at the close
of the cycle. At that point the full particle base of Earth would be stationed
in HU-2, having evolved through dimensional ascension, out of HU-1. The
particles composed of overtone frequencies undergo this transformation half-
way through the ascension cycle, and the particles composed of base-tone fre-
quencies follow suit, 2213 years later, at the end of the ascension cycle.                          
                          The Sphere of Amenti, Halls of Amenti,  
                             the Blue Flame and Human Evolution  
    The complex processes of particle mechanics, morphogenetic waves
and time cycles that we have just outlined, represent the natural hidden
dynamics of planetary dimensional ascension and the evolution of conscious-
ness through time. An essential part of this process is the relationship
between these multidimensional energy mechanics and the operation of the
Sphere of Amenti. For the Halls of Amenti to open to the races during the_________________________  
1.   Cataclysm occurred 550 million years ago from the perspective of  HU-1 Earth time. HU-
2 time cycles are the same amount of time in terms of evolutionary distance covered, but
they move twice as fast. D-4 time cycles cover the same block of time in half the number
of years it would take to complete that block of time in the D-3 cycle. Thus 550 million
years on Earth in the D-3 time cycle represents 225 million years on Tara in the D-4 time
       cycle.  
119                                                                                                                      
          

Ascension Mechanics  
10-year time warp/dimensional blend period surrounding the half-cycle
point, the Earth grid vibration must raise high enough to spark/open the Arc
of the Covenant. The Sphere of Amenti must descend through the Arc into
Earth’s D-2 core, and the Sphere must have its 12-year period of disbursing its
frequencies through the Earth grid, before the grids of Earth and Tara begin
to intersect five years prior to the half-point. The Blue Flame Staff of
Amenti, Earth’s portion of Tara’s D-5 morphogenetic field, allows Earth’s grid
to merge with Tara’s in D-4. If the Blue Flame is not embodied on Earth when the
grids begin to intersect, the infusion of D-5 energy from Tara’ s grid and the Holo-
graphic Beam cannot run through Earth’ s grid during the crest of the morphogenetic
wave.  In such a case the Earth’ s grid cannot link with T ara’ s to receive the
energy infusion, so Tara’s grid will link with whatever planetary core the Blue
Flame is stored within. The fifth-dimensional energy infusion would then
pass down from that planet, through the energy spiral of the Holographic
Beam and remain within the overtone particles of Earth, unable to pass into
Earth’s base-tone particles and grid. In this case Earth and the races would be
trapped for another 26,556 years within HU-1, the mass assembly of the fifth
DNA strand would not occur, and the majority of Earth’s people would have
to reincarnate into HU-1 until the next morphogenetic wave. This is only
the beginning of the problems that would occur if the Blue Flame were not
embodied on Earth during the time of grid intersection.  
    If the Earth grid could not link with T ara’ s, the Earth grid speed would
slow in vibration due to the excessive particle content that it could not
release through the first morphogenetic wave. After 2,213 years had passed
and the final morphogenetic wave of the cycle was due, the Earth grid vibra-
tion would be too low to hold the Sphere of Amenti and the Blue Flame, so
the grids of Earth and Tara again would be unable to merge. At the close of
the ascension cycle Earth’s excessive particle content and density would
make its grid speed and particle pulsation rate slow to the speed of the D-l
frequency bands. Earth would plunge from the sixth, and final, D-3 time con-
tinuum cycle in HU-1, back into the First D-1 time continuum cycle, of HU-
1. From this D-1 position, Earth would have to evolve through another
26,556-year Harmonic Time cycle in HU-1, before having another opportu-
nity to ascend to HU-2.  
    As you can perhaps now see, it is very important that the Sphere of
Amenti is appropriately placed in Earth’s core, and the Blue Flame success-
fully embodies, during the half-point in the second ascension cycle. If this
process does not occur, the Earth becomes trapped in HU-1 time. This digres-
sion and repetition of HU-1 time cycles has occurred seven times in the past
of Earth’s evolution. Earth is presently within its eighth repetition of the
26,556-year Harmonic Time cycle in HU-1. Earth’ s evolution has been stunted
within the  HU-1 time cycle for  nearly 212,448 years.  Though some progress was
made in dimensional ascension at several different points in time, Earth and
120 
 
 

                                                                           
                                                                                DNA and the Halls of Amenti
the human races repeatedly ended up returning to the start of the 26,556-year
HU-l cycle.  
    Since 840,000 years ago, when the guardian races from HU-2 and above
created the Arc of the Covenant, they have watched, waited, nurtured,
guided, assisted and prayed (yes, prayed!) for the time to come when the lost
souls of Tara could return home from their long and troubled evolutionary
journey on Earth. They did this because your race was loved.  They have waited
patiently for the distant time when Earth, and the 11 other missing fragments
of Tara, could be returned into Tara’s energetic body, so Tara herself could
ascend. Great wars have been fought and great catastrophes endured to
secure your species’ right to evolve, and to uphold and protect the Covenant
of Palaidor, through which the integrity of your species’ evolutionary blue-
print is ensured.  
    Can you understand how important the next morphogenetic wave will
be in relation to the evolution of Earth and the souls who continue to repeat-
edly incarnate there? The next morphogenetic wave in your present 26,556-
year cycle is your potential ticket to freedom, after being imprisoned within
the illusion of HU-1 matter for over 200,000 years. If you are unable to utilize
that potential, you will sentence yourselves to yet another 26,556 years in the
prison of your Earth school, if your planet could survive long enough to com-
plete its next cycle.  
We    are    taking    great    pains    to    explain    the   dynamics  of    morphogenetic  waves 
to you because you are presently within the second ascension cycle of your
                                 26,566-year Harmonic Time Cycle.  
                 The ascension cycle began 2194 years ago in 196 BC.  
                 The half-point in your current time cycle is 2017 AD.  
                                           You have 19 years before  
             the first morphogenetic wave of this cycle completes its crest.  
                                   Do you think you will be ready?  
                             If the Guardian races had not intervened,  
                         your planet would not have made it this far.
121
 
                                                                                                                         

                                      
                                      7
                                                                                                                                                      
                              
                                                                                        
                                                         
                   Countdown to Amenti   
     Several events have occurred during the last 98 years of your evolution
that could have drastically altered the course of your history. One such event
took place in the early 1900, which was repeated again in 1982. During
both of these periods large asteroid masses came into alignment with Earth’s
orbit, and if they had not been destroyed or diverted in deep space by interdi-
mensional Guardian ﬂeets, before they entered your solar system, conditions
supportive of life on Earth would have been destroyed. Because you were so
close to the coming 2017 AD morphogenetic wave, and the potentials of
ascension it holds, numerous Guardian races petitioned the Azurite Council,
Elohim and Ra Confederacy on your behalf, to allow non-direct intervention
in Earth’s affairs. Permission was granted. On the first occasion in 1906, the
asteroid was destroyed, and only portions of its debris bombarded Earth’s sur-
face. On the second occasion, in 1982, the asteroid was broken into two
pieces and its path was diverted using electromagnetic, Keylontic technolo-
gies. The asteroids are the least of the problems you have encountered within
your current century.  
                                              RECENT HISTORY  
                           The Original Zeta Agenda and the Zeta Seal  
                                                  1926 AD -6643 AD     
     In 1926 time traveling members of the Zeta/Zephelium races, originally
from the planet Apaxein-Lau began interacting with private factions within
several Earth governments. The Zeta agenda is discussed in earlier chapters.
In recent years the Zetas conducted several projects that had a highly detri-
mental effect upon the vibration rate of Earth’s grid and which damaged
Earth’s bio-energetic fields. If  the Sirian Council had not intervened, Earth’ s pop-
ulations would have been decimated between 1972 and 1974, and Earth would
have experienced a pole shift during the mid-1980s.  The Zetas and their Dracos
(Drakon-human hybrid) and Rutilia (Zeta-Dracos hybrid) accomplices desire
122 
 


                                                                                        
                                                                                                               Recent History
to take over Earth’s territory. The Dracos, being created as a hybrid race of
Drakonian and human genetic structure about one million years ago on
Earth, feel dominion of Earth is their birthright, as Earth is their planet of ori-
gin. The Dracos are Earthlings who were banned from their home planet
Earth, and exiled to the Orion star system one million years ago. The Zeta/
Zephelium races were involved with Atlantean and Atlanian Earth cultures,
and for a time colonized Mars. Both groups share a common interest in pos-
sessing Earth to facilitate the continuation of their races’ evolution.  
    The Zetas’  original plan was born out of their need to retain control of
a future human society. In the future of Earth, between 4230 AD and 6443
AD, the Zeta/Dracos alliance has successfully overtaken the human world
culture in that time period. This time period takes place within the First
ascension cycle time continuum of  Tara’s 26,556-year Harmonic Time cycle,
the natural path of evolution into which Earth would next evolve to become
Tara, following completion of its present cycle in 4230 AD. The Sixth Root
Race Muvarians and descendants of the present human races live there now
in a Zeta-ruled society, controlled by Frequency Fence and Holographic
Insert technology. These events are taking place now, in that future time-space
coordinate. In order for the Zetas to retain control over that society, they have trav-
eled backward through time to Earth’ s present.  Humanity’s upcoming opportu-
nity for accelerated evolution between 2012-2017 AD poses a direct threat
to the Zetas’ ability to retain control of that society. If 8% of present day
humans are able to successfully take this evolutionary leap, the humans of
4230 AD-6443 AD will be set free from the Zeta Collective Mind Frequency
Fence through which they are presently controlled in their space-time coor-
dinate. The Zetas do not want this to occur.  
    The Zetas’  original Earth agenda involved first creating Zeta-human
hybrid strains that could comfortably thrive on Earth. In the second phase of
their plan, they intended to make sure that the grids of Earth and Tara did
not merge during the 2012-2017 half-cycle point. By stopping this event,
Earth would remain trapped in HU-1 for another 26,556-year cycle, and the
human populations could not accelerate their evolution and activate their
fifth DNA strand. If the Zetas could keep Earth in the HU-1 time band and
gain control of the planet here, they would insure the continuation of their
future stronghold on D-4 Tara-Earth. If Earth successfully merged with Tara
between 2012-2017, and the morphogenetic wave allowed fifth-dimensional
frequency to move through Earth’s grid, the Frequency Fence through which
the D-4 Zeta controlled their human populations would be released. If ascen-
sion of Earth humans could be stopped by 2012, the Zetas could retain con-
trol of their D-4 holding. If humans began ascension to the D-4 time cycles
of Tara, their assembled fifth-strand DNA imprint would correct the D-4
DNA mutation the Zetas used to keep their humans under the Frequency
Fence. Humans in the D-4 time cycle would be set free if 8% of the D-3
123 
                                                                                                             
                                                                                    
                                                                                                                     

        Countdown to Amenti  
humans of Earth activated their fifth DNA strand. These present-day humans
would correct, within the race morphogenetic field of the Sphere of Amenti,
the Zeta-created D-4/fourth-DNA strand distortion that keeps the future
humans controlled. By ascending through Amenti, humans with activated
fifth DNA strands would realign the morphogenetic field of the future races,
reversing the genetic mutation the Zetas use to control the future humans.  
    In this future period, Muvarians and descendants of present human
races are kept from ascension and evolution to higher consciousness and
immortality by a seal the Zetas placed within their fourth DNA strand. The
Zeta Seal  stopped the fifth DNA strand from plugging into the lower strands,
so these future soul essences are trapped within Tara’s First time cycle in the
D-4 astral planes. As long as the future races carry this fourth strand DNA
distortion, humans on Earth will also carry this distortion of the fourth DNA
strand, and they will be unable to evolve past that D-4 time cycle. The Zetas
infiltrated the D-4 future time continuum about 400 years ago in Earth time,
and successfully implemented the Zeta Seal Frequency Fence there about 250
years ago. The Zeta Seal and Frequency Fence have thus manifested within
the present-day human genetic pool and within Earth’s morphogenetic field,
for the past 250 years, since about 1748 AD. All human souls incarnating on
Earth since 1748 AD have the Zeta-Seal distortion within their fourth DNA
strand. As your life span is presently only about 75-100 years long, this
implies that all people on your planet at this time carry the Zeta Seal genetic muta-
tion.       
    The second base tone and second and third overtones of the fourth DNA
strand were unable to manifest in the operational DNA, because these fre-
quency patterns were taken out of the morphogenetic field of Tara-Earth in
that future time period, in order to create the Frequency Fence. This block-
age within the future Earth’s morphogenetic field also caused blockage of
these frequencies in your Earth morphogenetic field in 1748, a distortion
which then manifested within the human gene code as souls from Amenti
passed through the Earth’s morphogenetic field to birth on Earth. This mor-
phogenetic distortion of Earth, created by Zeta manipulation in the future,
has created a hidden Zeta Frequency Fence  on Earth since 1748.  
      The fourth DNA  strand mutation has created an unnatural blockage
between the higher self aspect of identity (the portion of personal identity
focused in the UHF bands of D-3) and the D-4 astral awareness. This block-
age manifests as greater fragmentation within the dream state, difficulty in
orchestrating and remembering astral/“out-of-body” travel, an unnatural
blockage within the fourth chakra, repression of the natural intuitive senses
and an inability to fully assemble the fourth DNA strand. The Zeta Fre-
quency Fence on Earth made it easy for the Zetas to directly in ﬂuence human
behavior, as it connected the human DNA directly into the Zeta Collective
Mind complex that controlled the populations in the future. Since 1748,
124 

                                                                                                                     
                                                                                                                       Recent History
                         
                   human behavior has been directly inﬂuenced on subconscious and subliminal
 levels, by the Brainwashing Program that is broadcast by the Zeta Collective
 Mind Complex, from this future time period. This influence has played a
 major role in the development of human cultures since that time.  
       If these circumstances had been left to evolve unabated, the entire
human race would now be under the mental control of the Zeta Collective
Mind, and Earth’s vibration would have dropped too low to hold the Sphere
of Amenti for the 2017 half-point. The Zetas would not have had to do any-
thing to stop the grids of Tara and Earth from merging, as this would have
been a natural consequence of the effects of their Frequency Fence in the
future. In 1902 Guardian groups intervened and began “poking holes” in
Earth’s Zeta Frequency Fence by orchestrating astral-body realignments from
D-4, on various portions of the human population. The astral-body realign-
ments repaired the fourth DNA strand and added the fifth strand imprint to
these groups of humans, progressively bringing the corrected fourth strand
imprint back into the Earth’s morphogenetic field. When at least 8% of
Earth’s populations carried the corrected imprint, the Earth’s morphogenetic
field would realign and the morphogenetic field of Tara-Earth in the future
would follow suit and begin realigning. Through this astral involvement
with humans, the Guardians were able to begin dismantling the Frequency
Fence on Earth and on Tara-Earth. In 1986, Earth populations carrying the
re-aligned fourth DNA imprint peaked at 8%, and the Zetas’ Frequency
Fence on Earth deteriorated. The Tara-Earth Frequency Fence of the future
also began to unravel, and the Zetas began losing control over their future
human populations.        
    The Zetas began interacting directly with Earth’ s present cultures in
1926, in order to survey the effects of Guardian intervention on their Fre-
quency Fence, and to monitor the progression of the fourth-strand mutation
within the human DNA. They were aware of the upcoming half-point
ascension cycle and that their Frequency Fence would be collapsing at some
point before 20l2. The Zetas knew that they would have to reconstruct the
Frequency Fence and take action to prevent Earth’s grid from receiving its
scheduled infusion of D-5 through D-9 frequency. They decided they would
create Zeta-human hybrids, which possessed mutated fourth-strand genetic
codes, to repopulate the Earth following 2017. After the hybrids were cre-
ated, and their Frequency Fence on Earth was reconstructed, they planned to
eradicate all races carrying the realigned fourth and fifth DNA strand
imprint, by using Holographic Insert technology to vaporize the unwanted
specimens by passing them through UHF portals. In order to maintain con-
trol of their stronghold in the future, the Zetas returned to the past (Earth’s
recent past and present) to create the structures that would hold their control
of future populations in place. They began physical in filtration of Earth
between World Wars l and ll. Working with the Allied Governments in
125 
                                                                                                                                                                                                                           
   

    Countdown to Amenti  
World War ll, they formed covert agreements that would allow them to con-
duct experimentation on the human populations in order to begin the cre-
ation of hybrids to replenish their declining race and through which they
could take over Earth after 2017. The covert human Majestic 12 (MJ-12)
group was formed within the Allied human governments at this time, to
secretly oversee treaties they formalized with the Zetas. The Zetas then
began the next phase of their plan, a scheme of which MJ-12 knew nothing.
    During the late 1930s and early 1940s, the Zetas began their hybridiza-
tion program, then turned their attention toward reconstruction of the Fre-
quency Fence and stopping the grid merge of Earth and Tara scheduled for
2012-2017. The Zetas possess the knowledge and technology that would
allow them to misalign the electromagnetic fields of Earth and Tara, so the
planetary grids could not begin to merge in 2012. They understand the elec-
tromagnetic relationships between Earth’s planetary energetic fields and
those of the Sun. With this understanding, they devised a plan to shift the
electromagnetic fields of Earth and Tara by altering the electromagnetic fields
of Earth’s Sun. Before exploring the Zetas’ manipulation of the Sun, let us
review a brief lesson in the mechanics of multidimensional, electromagnetic
fields. 
                                                                                 MERKABA FIELDS                                                                                  Merkaba Field Mechanics  
    All planetary spheres possess sets of counter-rotating electromagnetic
fields, within and surrounding the planetary body. In the first-dimensional
frequency bands, Earth has a magnetic spiral of energy composed of the 12
base tone frequency patterns of D-1. This counter-clockwise rotating mag-
netic spiral pulls energy transmitted by the Sun into the D-1 portion of
Earth’s morphogenetic field, Earth’s D-1 Iron Core Crystal. Earth also has a
clockwise-rotating, electrical, D-l energy spiral composed of the 12 overtone
frequency patterns of D-1. The electrical spiral transmits energy from the D-1
portion of Earth’s morphogenetic field downward, where the energy is then
picked up by the D-1 magnetic spiral of the Sun. A planetary sphere has such
a set of counter-rotating electromagnetic spirals within each dimensional fre-
quency band. The two spirals form two pyramidal shaped energy constructs,
and the magnetic spiral is inverted within the upright electrical spiral. The
collective construction of the two energy fields is that of a Star tetrahedron ,
and this structure is referred to as a Merkaba Field.  Every planet, object and
person has such a Merkaba Field within each of the 15-dimensional bands. It
is the energy construct through which energetic substance emerges from and
returns to the morphogenetic field, the structure through which energy and
consciousness enter and leave manifestation.  
126 

                                                                                          
                                                 Merkaba Fields
    Earth’s D-1 Merkaba Field is located deep within the Earth's core. It
exists as a minute crystal encased in elemental iron and serves to ground
Earth’s morphogenetic field into HU-1. Surrounding this iron core crystal of
D-1 is the D-2 Merkaba Field, which is located within the Earth’s core at the
D-2 frequency level and serves to hold the morphogenetic imprint and parti-
cle base of Earth in place. Earth’s D-3 Merkaba Field extends about 444,000
miles out into space and serves to hold Earth’s atmosphere in place. (The
hole in Earth’s ozone layer represents a disruption within Earth's D-3 Merk-
aba Field).  
     The D-4 Merkaba Field of Earth exists as a minute crystal encased in ele-
mental gold, which is presently located within a black hole at the center of
Earth’s Sun at the D-4 frequency level. It serves to ground Tara’s morphoge-
netic field (portions of which are presently scattered within the planetary
cores of your solar system) into HU-2, and also connects the planets of your
solar system in HU-l to Tara’s D-5 core in HU-2.  
    T ara-Earth’ s D-5 Merkaba Field surrounds the D-4 gold crystal at the
Sun’s core at the level of fifth-dimensional frequency, and thus your Sun and
solar system are encased within this fifth-dimensional Merkaba Field. The D-
5 Merkaba Field serves to hold Tara-Earth’s morphogenetic field and particle
base in place.  
     Tara-Earth’s D-6 Merkaba field extends thousands of miles out from Tara-
Earth into outer space in HU-2, at the sixth-dimensional frequency level. It
serves to keep Tara’s atmosphere in place and encompasses within its energy
field HU-2 planet Tara, the planets of Tara’s solar system, the planets orbiting
around Alcyone in the Pleiades in HU-1 and all of the planets orbiting
around Earth’s Sun in HU-1. The multidimensional structures of planetary
Merkaba Fields are referred to as Stellar Spirals.  They represent vast con-
structs of electromagnetic energy through which all planetary systems in the
15-dimensional galaxy are energetically connected.  
    The Merkaba Fields of the higher dimensions encompass the Merkaba
Fields of the lower dimensions and all matter forms contained within them.
The frequencies of the 15 smaller-dimensional Merkaba Fields combine to
form larger Harmonic Universe Merkaba Fields. Harmonic Universe Merk-
aba Fields combine to form the largest Merkaba Field, the  Meta-galactic
Merkaba Field.  The Meta-galactic Merkaba Field is composed of a 15-
dimensional, inverted, counterclockwise spiraling magnetic field and an
upright, 15-dimensional clockwise spiraling electrical field. The magnetic
spiral extends from D-1 upward through the Meta-galactic Core at D-8 and
into the 15th dimension. This spiral of magnetic energy serves to draw elec-
trical energy from the anti-particle universe through the dimensional mor-
phogenetic fields in D-9 through D-15, into dimensions 1 through 7 of the
particle universe, then back into the Meta-galactic Core. The electrical spiral
extends from D-15, downward through the Meta-galactic Core and into D-1.
127 
                                                                                                                                                                                                                 

 
   Countdown to Amenti  
The  electrical spiral serves to transmit electrical energy from the Meta-galac-
tic Core, into the anti-particle universe, through the morphogenetic fields,
then into dimensions 1-7 of the particle universe. These are the energy
mechanics through which the universe is perpetually sustained . The Zetas are
aware of these energy mechanics, which gives them a tremendous technolog-
ical advantage over present-day human technological capability. The energy
mechanics of the Merkaba Fields holographically creates the perceptual/experiential
illusions of matter, space and time through the refraction of energy particles. The
reality behind this illusion is an eternal Uniﬁed Field of energy within which every-
thing resides, and out of which all things are composed. The following example
will give you some idea of how that holographic projection tricks human per-
ceptions into the experience of space, time and matter.                                                  
Agartha   
    The civilizations of  Agartha,  the Inner Earth, which exist in a frequency
modulation zone between Earth and its parallel-universe double, between D-3
and D-4 time bands, actually exist at the core of Earth’s Sun, within the 3.5-
dimensional frequency level. Particles in the D-3.5 vibration spin at a 22.5°
reverse angular rotation to the particles in D-3 (Earth’s atmosphere) and at a
22.5° angular rotation to the particles in D-4. (D-4 particles spin at a 45°
reverse angular rotation to D-3 particles). The gold core crystal of Tara-Earth’s
D-4 Merkaba Field  appears as a Sun to those of the Inner Earth. This D-3.5
area is called the Inner Earth because one must travel through the Earth’s
external portals, downward through the Earth into the D-2 Earth morphoge-
netic field, then into the D-1 iron core crystal in the center of Earth (which in
reality exists inside of the sphere of the Sun) in order to re-emerge within the
D-3.5 frequency level of the Sun where Agartha exists. Just as the gold core
crystal of Tara-Earth’s D-4 Merkaba Field appears as a Sun when viewed from
Agartha at the 3.5-frequency level, the iron core crystal of Earth’s D-1 Merkaba
Field appears as Earth’s Sun when viewed from the D-3 frequency level.¹ What
you perceive as the Sun actually represents the iron core crystal D-1 Merkaba
Fields of the 11 planets plus the Sun in your local solar system. Though the
planets and Sun appear to be externalized from the Earth, in reality, the sub-
stance of the Earth and the local planets exists within the energetic substance
of what you perceive as the Sun. (As your Sun is actually the eighth star within
the Pleiadian system, your Sun and its contents are likewise contained within
the energetic substance of Alcyone, the central sun of the Pleiades.) Your D-2
telluric/elemental and D-3 atmospheric Earth, and those levels of the planets in
your local solar system, are in reality orbiting around the iron core crystals of
   ______________________  
1.   Note: your present perceptual field is that of the D-3 frequency bands. You are able to per-
     ceive the D-3 frequency bands as manifest reality because your consciousness is presently
       stationed in D-4.  
128 
    

                                                                                             
                                                                                                   Merkaba Fields
their D-1 Merkaba Fields, which exist within the core of each planet and col-
lectively manifest as your Sun. When viewed from the vibration level of the
third dimension, which is where your consciousness and instruments are pres-
ently focused, the D-1 Merkaba Fields, which exist within the core of Earth and
the local planets, and which are within the core of the Sun, appear to be
located outside of the planets, many miles away in outer space. You are dealing
with multi-layered reality fields that take place in the same space, but appear to
be separated due to the relationship between particle pulsation rhythm and
angular rotation of particle spin.  
    The perceivable experience of movement, passing time, matter, space,
distance between objects and separation of forms is an illusion created by the
multidimensional, holographic refraction of particles and anti-particles,
which pulsate and spin at varying speeds and angular rotations in relation to
each other. The movement of particles itself is a holographic illusion; movement
only appears to be such when consciousness views itself through the layered prisms
of multidimensional order.  It will be centuries before your scientists begin to
comprehend these facts of reality construction. However, while your con-
sciousness is focused within the multiple layers of dimensional reality, the
concepts of space, time, matter and movement will indeed appear to apply, so
we will continue our discussion following that paradigm of perception.
     Y ou can begin to stretch your perceptual and conceptual fields by simply
pondering the following concepts and allowing your intuitive senses to bring to
you a sensed cognition of these realities of which we speak. When you look at
your Sun from the third dimension, you are seeing the D-1 Merkaba Field of
Earth and her sister planets. From the D-3 frequency level, when you view the
D-2 Merkaba Field surrounding Earth’s iron core crystal, which holds Earth’s
morphogenetic field, it appears to be the solid matter makeup of your Earth’s
body and elemental/telluric kingdom. From the D-3 view, the D-3 Merkaba
Field is the Earth’s atmosphere within which your present reality takes place.
The distance of outer space that you perceive between Earth, the Sun and the
planets represents the magnetic repulsion zone that separates the D-1, D-2 and
D-3 frequency bands of HU-1 from the counter-rotating D-4, D-5 and D-6 fre-
quency bands of HU-2.  
     All dimensions exist in the same space, but seem to operate separately due
to the particle pulsation rates of which they are composed. Particle pulsation
rates are created by the degrees of angular rotation at which particles and anti-
particles spin in relation to each other. In one universe there are 15 primary
dimensional bands. Dimensional frequency bands group in sets of 3, and each
set of three dimensions represents a Harmonic Universe. Thus there are five
Harmonic Universes within one 15-dimensional Universe. The degree of angu-
lar rotation of particle spin shifts 90° from one dimension to the next within
one Harmonic Universe. In each Harmonic Universe containing three dimen-
129 
                                                                                                                                                                                                                              
                                                                                                                       

     
     Countdown to Amenti  
sions, there are two 90° shifts of the angular rotation of spin between the parti-
cles. Between one Harmonic Universe and the next there is a 45° reverse
angular rotation of particle spin. This 45° reverse angular rotation of particle
spin creates a Magnetic Repulsion Zone, or “void” between Harmonic Uni-
verses, which keeps the reality fields contained there within separated from
each other. These Magnetic Repulsion Zones are what you perceive as the
seemingly endless vestiges of outer space. Through this structure of relative
angular rotations of particle spin, the holographic illusions of multidimensional
reality, matter, time, space, movement and individuation of form are perpetu-
ally created and sustained. This will conclude our brief introductory lesson in
multidimensional physics; we hope we have provided some interesting ideas for
your more courageous scientists to explore.  
                 THE PHILADELPHIA EXPERIMENT AND SOLAR CRISIS                                     
                                 The Philadelphia Experiment 1943  
     We will now resume our discussion of the Zetas plan to stop the merger of
Earth and Tara’s grid and what they did to the Sun in 1943 that almost caused
the extinction of the human population on Earth in the 1970s.  
    The Zetas determined that in order to retain control of the human soci-
ety within the future space-time coordinates where they had successfully
achieved dominion over Tara-Earth’s territories in the D-4 time cycle, they
had to stop the fifth DNA strand from manifesting within the human popula-
tions of present-day Earth. Re-alignment of the fourth DNA strand by
Guardian groups had broken down their D-4 Frequency Fence and they were
losing control of their human subjects in the future. If the fifth DNA strand
activated within 8% of Earth’s present human populations, the race Morpho-
genetic Field in the Sphere of Amenti would realign the Frequency Fence
distortions in the grids of Earth and Tara, and the Zetas’ Frequency Fence and
Zeta Collective Mind Complex in D-4 would be destroyed. The upcoming
morphogenetic wave period of 2012-2017 in Earth's present time cycle would
allow all Earth humans to begin assembly of their fifth DNA strand and the
D-4/strand-four Zeta Seal would be released in all humans. After 2017 the
Zetas would totally lose control of the future human populations, if they did
not stop the fifth DNA strand from activating within Earth humans and stop
the present Earth grid from receiving its scheduled infusion of fifth to ninth-
dimensional frequencies.  
    From the beginning of their involvement with the covert human gov-
ernments, the Zetas held this secret agenda of Earth in filtration. When they
offered the Allied Governments technological information that helped them
win World War II, the Zetas had ulterior motives. In 1943 the Zetas offered
the U.S. Navy a rudimentary technology that would allow them to make
objects appear invisible. On August 12th, 1943 the experiment was con-
130 
 

                                                     
                                                   
                                      The Philadelphia Experiment and Solar Crisis
 
ducted in Philadelphia, PA, using a battle ship, the U.S.S. Eldridge. The
event became known as the Philadelphia Experiment.  W e will not detail the
experiment here, as there are several published accounts of this event, but we
would like you to understand the Zetas’ motivation for instigating this
project. The Zetas knew that in creating such an experiment, which utilized
the creation of an external, manufactured Merkaba Field, that the functions
of Earth’s natural Merkaba Fields would be disrupted. They failed to share
this knowledge with the US. government. The experiment created a “rip in
space-time,” or a tear in the natural Merkaba Fields, which served as a dimen-
sional warp through which the Zetas could secretly pass their ships to Earth
from their D-4 future location. Using this rip in space-time, the Zetas were
able to transport large numbers of their spacecraft, undetected by human
observation, into Earth’s D-2 Merkaba Field, and, from there, the ships could
be used to broadcast speci fic electromagnetic pulses directly into Earth’s D-1
Merkaba Field at the center of the Sun.  
    Because the Earth is directly connected to Sun through the Stellar
Spirals of the multidimensional Merkaba Fields, the Zetas knew they could
misalign the grids of Earth and Tara by manipulating the Merkaba Fields of
the Sun. They desired to create a Frequency Fence on Earth that would cause
the grids of Earth and Tara to repel each other in 2012. Earth would be
unable to receive its infusion of D-5 frequency, which would stop the fifth
DNA strand imprint from manifesting in the races and keep Earth trapped
within HU-1 for another 26,556-year cycle. They also knew that such a Fre-
quency Fence, applied during the half-point in the second ascension cycle,
would cause a pole shift on Earth, creating cataclysmic changes on Earth,
wiping out the majority of the populations, once the environment had re-sta-
bilized, the Zetas and Dracos planned to claim Earth’s territories as their own.
      The covert human government had no idea of the Zetas’ real plan when they
entered treaties with them during WW2, and they still do not know the extent to
which they have been manipulated by the Zetas.  The Interior Government was
not aware of the dire consequences that could have resulted from these
actions. Violation of human rights through covert forced abductions of citi-
zens for hybridization experimentation was the least of the troubles created 
by the Zetas’ involvement. In 1943 the Zetas used the opportunity presented
by the Philadelphia Experiment to begin their plan of shifting the Earth’s grid
out of alignment with Tara via manipulating the energy fields of the Sun. To
the present day, the Interior Government does not realize that it was this
event which triggered abnormal activity on the Sun between 1949 and 1972,
activity which had some of Earth’s scientific community very concerned
about the probability of a major pole shift occurring sometime during the
1970s or 1980s. The Merkaba Fields of the Earth, the Sun and Tara are inti-
mately intertwined with each other and with the Pleiadian star system and
131 
                                                                                                      
                                                            

      Countdown to Amenti  
others, so following 1943 the Zetas plan brought many different Guardian
groups into Earth's drama.  
    After the rip in space-time was made on August 12th, 1943, the Zetas
secretly positioned their spacecraft beneath Earth’s surface in the D-2 fre-
quency bands and began beaming electromagnetic pulses into the Sun.
Using these EM pulses, the following effects were created:  
    The spin of the base tone particles/magnetic field of the Sun’s D-1 Merk-
aba Field was reversed, which made the Sun’s D-1 magnetic spiral become
electrical. This change in the Sun created a reciprocal shift of polarity within
the D-1 Merkaba Field of Earth. Earth’s D-1 base tone particles/magnetic spi-
ral became electrical. This, in turn, caused Earth’s D-1 electrical/overtone
particle spiral to reverse and become magnetic. Through spacecraft posi-
tioned within the D-4 frequency bands, the Zeta next reversed the spin on
the Sun’s D-4 Merkaba Field, which set the pattern for Tara's grid through
the gold core crystal at the center of the Sun. The D-4 Merkaba Fields of par-
ticle and anti-particle Tara were reversed. These actions constituted a full
reversal of Earth’s D-1 electromagnetic Merkaba Fields, and a partial reversal
of Tara’s D-4 electromagnetic Merkaba Fields, putting both out of alignment
with the Merkaba Fields of D-2, D-3, D-5 and D-6.  
    Normally , when the grids of T ara and Earth begin to enter alignment
with each other about five years before the half-cycle point, the D-1 and D-4
Merkaba Fields line up as follows:  
    Earth’ s electrical overtone spiral in D-1 aligns with T ara’ s base tone mag-
netic spiral in D-4, and Earth’s magnetic base tone spiral in D-1 aligns with
Tara’s electrical overtone spiral in D-4.  
    This alignment of D-1 electrical to D-4 magnetic and D-1 magnetic to
D-4 electrical creates an interdimensional Resonant Tone through which the
planetary grids can fuse. Following the reversal of Tara’s D-4 and Earth’s D-1
Merkaba Fields, the new alignment between Earth’s and Tara’s Merkaba
Fields became D-1 electrical to D-4 electrical and D-1 magnetic to D-4 mag-
netic. The particles, which compose the planetary grids, would magnetically
repel each other and the grids of Earth and Tara could not fuse. But this plan
also causes major imbalance within the D-2, D-3, D-5 and D-6 Merkaba
Fields. If the Sirian Council and other Guardian groups had not intervened, the
human populations of Earth would have been vaporized between 1972-1974.  
    By 1950 Earth scientists began to notice odd phenomena occurring on
the Sun, as the Sun appeared to release periodic spirals of energy toward the
Earth. This phenomenon was heavily observed between 1952 and 1968, and
there was great concern that this solar anomaly would alter the wobble of
Earth upon its axis, creating a pole shift of the planet. Although most of this
information was blacked out of the media and kept from the public, some of
these studies were published in scienti fic journals and news papers, especially
after 1968, when the scientists calculated that if events continued as they
132 
 

                                                                         
                                                                            Solar Crisis and 11:11/12:12
    were, by 1972 there would be a huge explosion on the Sun that would cause
pole reversal and wipe out humanity by about 1984. On August 7, 1972 the
solar explosions began to occur. Earth scientists observed a rapid increase in
solar flares for several days, which peaked on August 7th, with the most
intense ﬂare ever recorded. Solar winds accelerated at an alarming rate in the
most intense solar storm ever witnessed by Earth scientists. Published
accounts of these observations can be found in scienti fic literature from this
time period. The solar winds increased rapidly between August 7th and
August 10th I972, then strangely the winds began a rapid decrease in speed
and the solar storms appeared to die down in the month that followed. This
was a perplexing observation to Earth scientists; they had no idea that the Sirian
Council had intervened.  
                                
                                 SOLAR CRISIS AND 11:11/12:12                                         
                                             Wave-of-Flame and Red Pulse         
      In January of 1972 members of the Sirian Council, Sirian-Arcturian
Coalition for Interplanetary Defense, the Pleiadian Star League and several
other Guardian groups entered the UHF bands of Earth’s atmosphere, aware
of the solar events that were to occur. If they had not intervened, Earth’s
populations would have been wiped out by 1974. When the electromagnetic
Merkaba Fields of the Sun are artificially manipulated, such as they were by
the Zetas following the Philadelphia Experiment, erratic electrical energies
build up within the Sun’s energetic grid, throwing all of the Sun’s Merkaba
Fields out of balance. As the misalignment of the Sun’s EM fields progresses,
it manifests as an acceleration of solar- ﬂare activity, which eventually culmi-
nates in surface explosions and temporary expansion of the Sun’s Merkaba
Fields, lasting about 950-970 years.  
      In 1972, the first explosions began to occur . The explosions would have
continued until about September of 1973, when the Sun’s D-1 Merkaba Field
would have burst open and expanded. The expansion of the Sun’s D-1 Merke
aba Field would have sent an intense wave of ULF energy out through all of
the planets in the local solar system. This wave of energy would cause a
chain reaction within all of the planetary Merkaba Fields, through which
pole reversal and vaporization of surface life would result. This wave of
expanding D-I energy is called a Red Pulse (red denoting its D-I frequency),
and it constitutes a wave of solar ﬂame within the D-1 frequency bands. Life-
forms on planets in the First Harmonic Universe cannot survive such an infu-
sion of ULF D-1 energy, because it would implode the molecular structure
before the genetic code could expand enough to process those frequencies.
    In order to avert the pending termination of Earth life, the Guardian
races, under the direction of the Sirian Council, altered several layers of the
morphogenetic fields of Earth and the local planets. As the Red Pulse Wave
133 
                                                                                                                                                              
                                                                                              
  

      Countdown to Amenti  
of Flame would be coming in on the electrical overtone D-1 frequency bands,
all of the D-1 overtones were temporarily removed from the planetary mor-
phogenetic fields. This served to create a D-1 seal around Earth’s core, so the
ULF of the Red Pulse could not enter Earth’s grid, or the grids of the neigh-
boring planets. Next, a frequency seal was placed within the D-4 frequency
bands, in order to block D-4 frequencies from entering into Earth’s morpho-
genetic field. Once the overtones of D-1 were removed, Earth’s core could
not synthesize incoming D-4 frequency, and the core would explode, so D-4
frequencies had to be temporarily blocked from Earth. To create the D-4 seal,
the first 11 (out of 12) base tones and overtones of D-4 were removed from
Earth’s morphogenetic field, which meant that Earth’s lower three Merkaba
Fields connected with the D-4 Merkaba Field only at the level of the 12th
base tone and 12th overtone. These morphogenetic manipulations created
another Frequency Fence, which served as a protective barrier around Earth
and the neighboring planets. In energetic terms the  1 1:1 1/12:12 Frequency
Fence  took the form of a spherical band of energy surrounding Earth, within
the D-1 and D-4 frequency bands —a protective “bubble” of multidimen-
sional energy.  
    Following the implementation of the Guardians’  Frequency Fence,
humanity was under three layers of frequency modulation, the original Fre-
quency Fence Quarantine from 9540 BC, the Zeta Seal Frequency Fence
from 1748 AD and the 11:11/12:12 Frequency Fence of 1972. All three of
these Frequency Fences would need to be lifted in order for the Blue Flame of
Amenti to become embodied on Earth between 2012 and 2017. As Fre-
quency Fences are morphogenetic manipulations, they also manifest within
the DNA imprint of the races. The DNA of 8% of the human populations
would have to be realigned and purged of the three Frequency Fence Seals
and the remaining mutations from the earlier Amenti, Palaidorian, Templar
and Templar-Axion Seals by January 1, 2012. Guardian races began conduct-
ing mass-level, consensual, soul-agreement abductions of humans since 1972,
in order to help humans begin repairing these genetic mutations, and also to
begin education on preparation for 2012. Memory repression tactics were
used to spare humanity the terror of facing events that it was not yet prepared
to understand. The Zetas had been conducting frequent forced abductions
since the late l940s as part of their hybridization program. They also used
memory repression tactics. Guardians did not participate in these forced
abductions, nor did they participate in intrusive experimentation.  
    When the 11:11/12:12 Frequency Fence was established in 1972, the
Guardians knew it was a temporary measure to buy the time they needed to
rebalance the Merkaba Fields of Earth and the Sun.  Balancing the Merkaba
Fields was the most important project in the Guardian agenda.  Since 9558 BC,
when the islands of Atlantis sank and the Earth tilted on her axis, the Guard-
ians knew they would have to assist in realigning the Merkaba Fields of Earth
134 

                                                                              Solar Crisis and 11:11/12:12
before the 2012-2017 ascension cycle. Following the events of 1943-1972,
this re-balancing effort would be much more dif ficult to achieve. Originally
the Guardians planned to slowly accelerate the vibration rate of Earth’s grid
through occasional infusions of D-4 energy that would slowly bring the grid
into alignment and correct the pole tilt over the course of about 2,000 years.
These occasional energy transmissions began in 196 BC, when Earth entered
its present 4,426-year cycle. In their original plan the Guardians intended to
raise Earth’s grid vibration into the UHF bands of the third dimension begin-
ning in the 1950s, so the first seal on the Arc of the Covenant could be
released no later than October of 1986. Following the release of the first seal
on the Arc, the Sphere of Amenti would begin its 12-14 month descent into
Earth’s core.  
    The Sphere of Amenti had to be in place no later than 1/1/1988 so the
Sphere would be able to ful fill the first 12-year phase of its activation cycle no
later than 2,000 AD. Once the Sphere was fully activated to the 3-dimen-
sional level in Earth’s D-2 core, it would cause Earth’s grid to send a spark of
D-5 frequency into the Arc of the Covenant, releasing the second seal on the
Arc. This would begin the 12-year descent of the Blue Flame of Amenti and
the shift of Earth from the D-3 to the D-4 time cycle. The second seal on the
Arc of the Covenant had to spark open no later than 6/1998 so the shift into
the D-4 time cycle would begin by 1/1/2000, in order for the Earth’s grid to be
prepared for proper fusion with Tara’s grid between 2012-2017. The D-5 fre-
quencies of the Blue Flame had to be embodied within the populations of
Earth, no later than 5/5/2012, or else Earth changes would result when the
grids began to merge.  
    When the Zetas’  Frequency Fence and genetic mutation from the
future began affecting Earth in 1748, creating blockages of the D-4 frequen-
cies in Earth’s morphogenetic field and fourth-strand DNA mutations in the
races, the Guardians began construction of an arti ficial D-4 grid imprint
within the Earth’s morphogenetic field. They re-entered the aligned D-4 fre-
quency patterns into the gold core crystal D-4 Merkaba Field at the center of
the Sun, which began to restore the D-4 imprint in the Earth’s morphoge-
netic field and within the Sphere of Amenti. This allowed the Guardians to
continue infusing Earth with D-4 frequency to slowly reverse Earth’s unnatu-
ral tilt on its axis. This arti ficial D-4 imprint also began the deterioration of
the Zetas’ Frequency Fence and a reverse mutation of the fourth DNA strand.
The new D-4 imprint manifested as a band of UHF energy surrounding the
outer portions of the Earth’s atmosphere, about 444,000 miles out in space,
just beyond the 12th overtone of the third dimension. It allowed human
consciousness to continue its expansion into D-4 perception and allowed the
Earth’s infusion of D-4 energy accelerations to continue. This arti ficial D-4
grid which the Guardians began constructing in 1748, has frequently been
referred to in New Age terminology as the “ artificial Christ Consciousness      
135                                                                                                                
                                                                                                                   
                                                                     

        Countdown to Amenti  
Grid ”. This term was chosen because the upper frequency bands of D-4 rep-
resent the beginning levels of the Turaneusiam 12-strand DNA conscious-
ness, which was exempli fied on Earth by Jesheua-12 in 12 BC-27 AD. When
the problems arose with the Zetas’ manipulation of the Sun between 1943-
1972, the arti ficial D-4 grid became blocked by the 11:11/12:12 Frequency
Fence.  
    In 1972, the Guardians had to accelerate their whole energy infusion
program in order to reverse the damage the Zetas had caused, which meant
that humanity would be put on a course of very rapid evolution between 1972
and 2012. For the arti ficial D-4 grid to become operational again, the 11:11/
12:12 Frequency Fence had to be removed, which meant that the D-4 and D-
1 Merkaba Fields of the Sun had to be returned to their original polarity. This
would correct the D-1 Merkaba Field of Earth and the D-4 Merkaba Field of
Tara-Earth so the grids could fuse in 2012, if the Earth grid vibration was
raised high enough in time to hold the Sphere of Amenti.  
    The Earth’ s grid had to reach the speed of the UHF bands of D-3 for the
first seal on the Arc of the Covenant to spark and release the Sphere of
Amenti by 10/1986. It would be difficult, if not impossible, for the Guardians
to raise Earth's grid speed that high without the infusions of D-4 energy that
were now blocked by the 11:11/12:12 Frequency Fence, so correction of the
Sun’s Merkaba Fields became a race for time within the Guardian legions.
Even though the Frequency Fence did not lift until 1992, the Guardians were
successful in raising the grid speed enough for the Arc of the Covenant to
open by the 10/1986 deadline. The accelerated energy infusions used to re-
balance the Merkaba Fields of the Sun, began in 1973 and were projected
into the solar fields via beam ships stationed in the future D-4 time cycle.
These infusions would cause rapid shifts of the energy fields on Earth, which
would have created havoc within the consciousness of the human popula-
tions and instability of Earth’s natural EM fields. However, the 11:11/12:12
Frequency Fence allowed the Guardians to employ Holographic Insert tech-
nology on Earth, through which the illusion of grid stability could be created,
so the Guardian re-balancing efforts would remain undetected and excessive
instability within the human populations could be avoided.  Earth existed
under these Guardian-created Holographic Inserts from 1973 to 1/11/1992, when
the 11:11/12:12 Frequency Fence began lifting.  
                                      
                                      THE MONTAUK PROJECT            
          Zetas and Rigelians, the Montauk Project 1983 and 2976 AD 
    Between 1973 and 1980 Earth remained under the Guardians’  Holo-
graphic Inserts and the illusion of electromagnetic stability they created,
while the Guardians worked to complete realignment of the Sun’s Merkaba
Fields. By 1982 the Zetas became tremendously frustrated as they observed
136 
                        
          

                                                                            
                                                                                 The Montauk Project
the continuing breakdown of their Collective Mind Complex in the D-4
time cycle, and began to realize that the Guardians would correct the mis-
alignment of the Sun in time for the ascension period to proceed as sched-
uled. Between 1982 and 1984, most members of the Zeta Legion entered into
treaties with the Guardian races, and agreed to stop their plan of Earth in fil-
tration. These agreements also included the Zetas from the D-4 time cycle,
who had fallen under domination of the Dracos in that future time period.
The Guardians agreed to relocate the Zeta races and their hybrids to another
planetary system in D-4, where they could evolve peacefully, as long as the
Zetas agreed to follow the dictates of the Sirian Council and Galactic Federa-
tion, and to operate upon principles of the Law of One from that time for-
ward. The Zetas were also required to fully dismantle their Collective Mind
Complex in D-4, to release the Zeta Seal Frequency Fence and to assist the
Guardians in preparing Earth and humanity for 2012. Though most of the
Zetas agreed, and began working with the Guardians in 1983, several Zeta
and most Dracos groups refused to release their desire for possession of Earth.
These groups became known as the Dracos-Zeta Resistance,  which included
rebellious Zeta races, Dracos and their hybrids.  
     The primary Zeta groups that refused Guardian treaties are the Zeta
Greys from a solar system that orbits the star Rigel, in the Orion star system.
These are frequently called the  Rigelians ; we know them as the Futczhi  (pro-
nounced FOO’-SHE). It is this Zeta group that formed treaties with the Inte-
rior Government on Earth and orchestrated the Zeta Seal and manipulations
of the Sun. They are the most aggressive and militant of the Zeta Grey races
and are extremely dangerous to humans, because they often attempt to
present themselves as Guardians in order to seduce humans into being their
earthly operatives. The Rigelians/Futczhi dominated the other Zeta races in
the D-4 time cycle until the majority of these non-Rigelian Zetas rebelled
and sought Guardian protection when this option was offered between 1982-
1984. Following the Guardian treaties of 1982-1984, the Zeta-Dracos hybrids
known as the Rutilia,  who had always been the primary go-betweens in Zeta-
Futczhi/human relations, served as infiltrates within the Interior Govern-
ment, and continued to secretly motivate humans to continue helping them
fulfill their old agenda. (Note: the Rutilia are those beings referred to by the
government as “EBE’s” - Extraterrestrial Biological Entities. They closely
resemble the Greys, but usually have a lighter gray to gray-white complexion,
and more pronounced ridging at the rear of the skull.) The Dracos-Zeta
Resistance had to find a way to reconstruct the Zeta Seal, Frequency Fence
and Zeta Collective Mind Complex before 2012, in order to regain control of
the human populations in D-4.  
     The Dracos-Zeta Resistance set their new plan in motion in 1983, when
they covertly motivated humans to create another experiment, similar to the 
Philadelphia Experiment of 1943. They desired to create another rip in space-
137 
                                                                                                                                                                                                                                    

Countdown to Amenti  
time, through which large numbers of their ships could be secretly sent from
the future to Earth, into three different time-space coordinates. From these
positions in time, the ships could enter the D-2 frequency bands of Earth and
begin transmitting EM pulses through the Earth’s grid, which would serve to
reconstruct their Frequency Fence and cause mutation in the fourth DNA
strand.  
     Even if the grids of Earth and Tara were able to merge between 2012-2017,
the human gene code would not have time to fully assemble the fifth DNA
strand in the majority of the populations. This would stop the scheduled ascen-
sions through the Halls of Amenti and keep the Zeta Seal operational within
the Sphere of Amenti, so their human captives in D-4 would once again be
subject to Zeta-Dracos control. For their new plan to work, the Zetas had to
begin broadcasting their EM pulse Frequency Fence as close to 2012 as possible,
while still allowing enough time for the fence to take effect within the human
gene code. It would take a minimum of six years for the new frequency fence to
cause the fourth DNA strand mutation in the majority of the human popula-
tions, so the Dracos-Zeta Resistance would have to begin broadcasting their
EM pulses no later than 2006. If they began broadcasting too soon, the Guard-
ians’ infusions of  D-4 frequency would counteract their EM transmissions, and
the genetic mutation would not “hold” within the DNA. The Dracos-Zeta
Resistance decided upon the year 2004 as their target date. In order to ful fill
their plan of covert mass infiltration, they would have to enter their ﬂeets into
Earth’s D-2 frequency bands during the peak of Earth’s D-1/D-4 Merkaba Field
cycle, which takes place every 20 years on August 12th.  
    Dimensional Merkaba Fields go through cycles of movement in which
the two spiraling energy fields vertically condense and draw toward each
other, then progressively expand on the vertical axis, drawing away from each
other. When the Merkaba Fields draw away from each other, the upright
electrical spiral moves into the magnetic Merkaba spiral of the dimension
above, which causes a temporary blending of frequencies between the mag-
netic spiral of one dimension and that of the dimension above. These points
of interdimensional magnetic spiral blending are called Dimensional Mag-
netic Peaks.  During Magnetic Peaks, natural interdimensional portal win-
dows briefly open, allowing unencumbered transit between dimensional
bands. Magnetic Peaks also occur between the Merkaba Spirals of Harmonic
Universes, through which the Merkaba Fields of a dimension in one Har-
monic Universe blend with the Merkaba Fields of the corresponding dimen-
sion one Harmonic Universe up; these blending periods are called Harmonic
Magnetic Peaks.  Each Harmonic Universe has three dimensions, each of the
three dimensions representing a base tone, overtone or resonant tone, within
the 15-dimensional scale. D-1, D-4, D-7, D-10, and D-13 are base tone
dimensions. D-2, D-5, D-8, D-11 and D-13 are overtone dimensions. D-3, D-
138 

  
                                                                                    The Montauk Project
6, D-9, D-12 and D-15 are resonant tone dimensions. Harmonic Magnetic
Peaks occur when base tone —base tone, overtone —overtone, or resonant
tone—resonant tone Merkaba Field alignments take place. The D-1 base tone
Merkaba Field of Earth and the D-4 base tone Merkaba Field of Tara reach
their Magnetic Peak cycle once every 20 years between August 12th-15th,
at which time a dimensional window opens between Earth’s HU-1, and Tara’s
HU-2, time continuum cycles.  
    The first Harmonic Magnetic Peak of the 20th century occurred on
August 12th, 1903, and the last on August 12th, 1983. These periods mark a
time of peak magnetic pull within Earth’s subtle energy bodies and height-
ened dimensional blending, through which large numbers of Dracos-Zeta
ships could be cloaked and brought to Earth from D-4. August 12th, 2003 is
the closest peak date to the Dracos-Zeta Resistance target date of 2004. The
plan called for a simultaneous entry of beam ships during three time periods,
and once the Zetas had successfully orchestrated in filtration, they would
broadcast their Frequency Fence through Earth’s grid and begin the genetic
mutation. If they attempted this mutation from only one time period, there
would not be enough time for it to take hold within the majority of the popu-
lations. By entering the EM transmissions at the three different, but closely
related time periods of 1943, 1983, and 2003, a great number of people would
be affected.  
    For the Dracos-Zeta Resistance plan to be effective, they would have to
create three rips in space-time on Earth, through which their ships could be
entered. One such rip already existed from the Philadelphia Experiment of
1943 and one would have to be created in 2003. The Resistance scheduled
the third rip in space-time for the next Harmonic Magnetic Peak cycle of
August 12th 1983, the only opportunity they would have before 2003.
Working with the Interior Government, the Dracos-Zeta Resistance orches-
trated another experiment, which came to be known as the Montauk
Project.  Again, accounts of this experiment are available in other publica-
tions, so we will not detail here.  
    The Montauk project served to widen the rip in 1983 space-time that
had begun as the result of the Philadelphia Experiment. By August 14th
1983 the time periods of 1943 and 1983 were successfully linked to the Dra-
cos-Zeta Resistance D-4 time period, which they used as a base of operations.
From 1983 to the present, the Dracos-Zeta Resistance resumed their
hybridization program through abducting humans, creating several strains
of hybrids and human clones. They also created in filtrates via genetic engi-
neering, through which they could interface with Earth’s cultures under
the guise of human form. In filtrates are children conceived of natural
human conception, whose mothers were abducted during pregnancy so Zeta-
Dracos genetic materials could be infused into the fetus. These children are
born (usually within the seventh month of gestation) and raised by their
139 
                                                                                                                                                                   

Countdown to Amenti  
human parents, and appear to be fully human. They are consciously unaware
of their ET affiliation, but can be subliminally directed by the Dracos-Zeta
Resistance via the DNA and neurological structure. When Guardian groups
locate such in filtrate individuals, they orchestrate abductions, and dismantle
the Zeta-Dracos gene codes, thereby freeing these mostly human subjects
from their covert controllers.                              
                         2976 AD and the Dracos-Zeta Resistance  
    The Guardians became aware of the Dracos-Zeta Resistance problem in
1984, and were able to trace probable events in the future that would result
from this present activity. What they discovered was alarming, as the conse-
quences of this in filtration were more far-reaching than they had speculated.
They discovered a future event that would occur in the year 2976 AD, that was
the result of the Zetas’ interference after the year 2000. In this probable future,
the Guardians had been successful in realigning the Merkaba Fields of Earth
and the Sun, but in 2003 AD the Dracos-Zeta Resistance is also successful with
their in filtration plan. The Guardians saw that the Zetas’ new Frequency Fence
partially misaligns Earth’s grid in 2012, and when Earth and Tara begin to inter-
sect, major Earth changes result. Though Earth still fuses with Tara and
releases a morphogenetic wave as intended, just as that wave begins to crest
(2012), the Earth changes begin. When the morphogenetic wave begins to
crest, the Halls of Amenti portals open, but the Earth grid must be stable in
order for the Halls to remain open through their 10-year cycle (2012-2022).
The Earth changes cause a premature closing of the Halls of Amenti, which
creates a rapid drop in Earth’s grid speed. The Sphere of Amenti cannot be left
in Earth's core during this drop in vibration or the Earth grid will explode. In
this future probability, Guardians remove the Sphere of Amenti from Earth and
human populations come under direct covert control of the Dracos-Zeta Resis-
tance. The Zeta Seal genetic mutation is returned to the human race. Once
Earth is under Dracos-Zeta rule, the Zetas are attacked and dominated by the
Dracos group with whom they had been working. The Dracos take command
of Earth in both the D-3 and D-4 time cycles and begin to use the D-3 Earth
as a storehouse for unwanted photo-nuclear waste materials from the D-4
Tara-Earth time cycle.  (Photo-nuclear waste is produced through certain pro-
cesses involving the manufacture of photonic energy through manipulation of
multidimensional nuclear materials). This process causes a massive nuclear
explosion on D-3 Earth in 2976 AD, through which Earth is destroyed.  All
souls involved in the cataclysm fragment and are lost within HU-1. Their con-
nections to the Sphere of Amenti race morphogenetic field and their personal
soul matrices are severed.  
    If this future event occurred in present-Earth's line of development, not
only would the Earth and the major part of the human race be lost, but the evo-
140 

                                                                                
                                                                                     The Montauk Project
lution of Tara in HU-2 would be set back by eons, as Tara would remain
trapped in her HU-2 time cycles until Earth’s imprint could be reconstructed
and re-evolve in HU-1.  
    Upon discovering these probable future events, Guardian groups made
an appeal to the Resistance Zetas, telling them of the Dracos’ betrayal and
offering to assist them in relocation, if they would give up their in filtration
plan. The Zetas refused to alter their plans.  
    Though the Guardians could easily subdue the Dracos-Zeta legions in a
forced confrontation, such a confrontation would cause major damage to
the Earth’s Merkaba Fields, which would ensure the destruction of the
human populations.  The Guardians had to find a better way to avert the
new Dracos-Zeta agenda. Not only did the Guardians bear the responsibility
for preparing Earth and humanity for 2012, they now had the additional bur-
den of protecting their preparation plan from Dracos-Zeta Resistance sabo-
tage. In December of 1984, the Sirian Council, Pleiadian Star League,
Sirian-Arcturian Coalition for Inter —planetary Defense, the Andromeda Fed-
eration of Planets, the Palaidorians of HU-2 and several other Guardian
groups from HU-l, HU-2 and HU-3, co-created the Bridge Zone Project,  in
order to protect Earth and the human populations from Dracos-Zeta Resis-
tance in filtration, and the destruction of Earth in 2976 AD that would result
from this interference.  
    The Dracos-Zeta Resistance is presently quite aware of the Guardian’ s
Bridge Zone plan, but they are con fident that humanity will be unable to rise
to the occasion and feel sure their in filtration plan will be successful. The
Guardians believe humanity can indeed pull together and make the Bridge
Zone project a success. For this reason we of the Guardian Alliance bring to
you this hidden knowledge, so that you may be prepared to make a stand on
behalf of your own evolution and freedom.  
141 
                                                                                                                                                                                                                               

                                                                                                             
                                    8 
                   
                         
                                                                                                                                                           
                         Current Events  
                      
                                             THE BRIDGE ZONE PROJECT  
                           
                                        The Bridge Zone Time Continuum Shift  
                    12/1984 - present
         
    Before the Dracos-Zeta legions had altered the EM fields of the Sun in
1943 the Guardians’ preparation plans were relatively simple. Using their
artificial “Christ Consciousness” D-4 grid from 1748, they progressively sent
transmissions of UHF D-4 energy into Earth’s grid to raise the vibration of
Earth’s core high enough to send the first spark into the Arc of the Covenant
by October of 1986. The Sphere of Amenti would complete its 14-month
descent through the Arc from the UHF bands of D-3 by 1988. The Sphere of
Amenti would merge its D-1, D-2 and D-3 frequency patterns with, and
expand Earth's morphogenetic field no later than 6/1998, which would spark
the Arc a second time, beginning the 12-year descent of the Blue Flame and
Earth’s temporary 2000 AD shift into the D-4 time cycle. The Guardians
would continue to gradually realign Earth's Merkaba Fields/electromagnetic
fields to correct the tilt caused by Atlantis sinking. This would align Earth’s
fourth vortex/Heart Chakra at Giza with the Alcyone energy spiral by 2004,
in preparation for Earth’s entry into the Photon Belt and Holographic Beam,
and the opening of the Halls of Amenti in 2012.  
    The original Quarantine Frequency Fence from 9540 BC would begin to
lift once the Arc of the Covenant first opened, and all traces of the fourth-
strand DNA Zeta Seal mutation and Zeta Frequency Fence would dissolve
once the Arc was sparked a second time and D-4 frequency from the Sphere
of Amenti would begin transmitting through Earth’s grid . Between 1/1988 and
1/2017, the seven natural seals on Earth’ s seven primary vortex points would pro-
gressively  open  as   the    dimensional  Merkaba  Fields   and   Stellar  Spirals   began   opening
and blending into each other, while the Guardians assisted the Earth grid to remain
balanced through these transitions . The Guardians planned to offer dispensa-
tions of teachings to humans while the veils between the ego, higher self and
142 
              
            


                                                                              
                                                                               The Bridge Zone Project
soul identity began to lift, as the DNA progressively assembled. The Guard-
ians’ primary concern at this time was to realign Earth’s Merkaba Fields and
bring Giza into alignment with Alcyone. They would ensure that the descent
of the Sphere of Amenti and the Blue Flame stayed on schedule. Guardians
were to maintain planetary balance while Earth’s seven vortex seals opened,
and they would begin making subtle contact with humans, to help them pre-
pare for the opening of the Halls of Amenti.  
    Following the 1943 Philadelphia Experiment, the Zetas’  manipulation
of the solar Merkaba Fields and the necessity of the Guardians’ 11:11/12:12
Frequency Fence of 1972, the Guardians’ preparation plan and deadline
schedule became more taxing. Before the original plan could continue, the
11:11/12:12 Frequency Fence, which blocked all of the fourth-dimensional
frequencies except the 12th base tone and overtone out of Earth’s grid, had to
be dismantled. Though the Guardians could alter the Frequency Fence
enough to allow the Sphere of Amenti to enter Earth's core on schedule, the
fence could not remain intact when the Sphere of Amenti began transmit-
ting D-4 frequency into Earth’s grid in 1/2000, when the fourth vortex seal
opened. lt would take about four years for the Earth’s grid to balance once
the 11:11/12:12 Frequency Fence was released, so the fence had to be down
no later than 1/1996.  
     Once the Sphere of Amenti was opened, if the D-4 frequencies could not
enter Earth’s core in 1/2000, the D-4 Merkaba Field of Tara, the gold core
crystal stored at the center of the Sun, would explode. In this event, not only
would Earth explode, but so would the other 10 planets of the local solar sys-
tem and the Sun, all of which are energetically attached to the D-4 Merkaba
Field gold core crystal. This would begin a similar chain reaction within the
Pleiadian star system, to which Earth’s Sun belongs. As you may now under-
stand, balance and timing are extremely important factors when the Halls of
Amenti open. In order to remove the 11:11/12:12 Frequency Fence, the
Merkaba Fields of the Sun would have to be carefully realigned no later than
6/1994, which would allow one and one-half years for the Earth’s grids to
rebalance before the Frequency Fence was lifted. Realigning the solar fields is
a delicate process in and of itself, but this process combined with the general
preparations of opening the Halls of Amenti within the scheduled deadlines
served to make the Guardians’ task even more complex.  
     As if these complications were not enough, the Guardians then discov-
ered the potentially disastrous results of the Dracos-Zeta Resistance infiltra-
tion and their plan to re-institute their Frequency Fence and Zeta Seal in
2003. The events of the 2017 ascension cycle were taking a very serious turn,
and if the circumstances were not handled properly, the human populations
would be decimated by severe Earth changes between 2012-2017. The
option of stopping the Sphere of Amenti from descending through the Arc of
the Covenant, and thus allowing Earth and humanity to remain trapped
143 
                                                                                                                     
                                                                                                                 
                                                                                                              

  
   Current Events  
within HU-1 time cycles for another 26,556 years, was no longer open. The
Earth changes of 2012-2017 could be primarily avoided in this case, but
humanity would fall under dominion of the Dracos-Zeta Resistance and
under that in ﬂuence the Earth would meet with an untimely, cataclysmic end
in 2976 AD. These events could not be allowed to transpire, as they were set
to occur. The explosion of Earth would cause tragic consequences for Earth,
Tara and numerous other star systems. The lost souls of Tara, whom the
Guardians had so painstakingly nurtured and protected for the past 550 mil-
lion years, would once again be fragmented and left with no evolutionary
blue print to follow.  
    The Rigelian/Futczhi Zetas working with the Dracos would not listen
to reason and the Dracos would not release their claims on Earth. Confronta-
tional force between the Guardians and the Dracos-Zeta Resistance, during
Earth’s most vulnerable period, would destroy the planetary balances of
Earth, so t he Guardians had to turn to high-spiritual technology in order to shift the
course of events as they were evolving on Earth.  In 1984 Guardian groups from
HU-1, HU-2 and HU-3 joined together to create the Bridge Zone Project.
The basic idea behind the Bridge Zone project involved shifting Earth com-
pletely out of the HU-1 time cycle, an event that would not occur naturally
until the second morphogenetic wave of the second ascension cycle, during
the natural Doreadeshi in 4230 AD. Since the Guardians could not move the
Dracos-Zeta Resistance out of the way of Earth’ s intended evolution, they would
instead move Earth out of the way of the Dracos-Zeta Resistance. The Guardians
would construct an artiﬁcial time continuum between the third and fourth dimen-
sions, into which Earth could pass in 2017. This constituted orchestrating a forced
Doreadeshi, 2213 years ahead of its natural schedule.  
    In order for the Dracos-Zeta Resistance’ s Frequency Fence to work in
2003-2004 AD, they had to transmit very speci fic EM pulses, at very speci fic
angles through the Earth’s grid. The Zetas had worked since 1943 to deci-
pher the appropriate calculations to use for the projections of their EM
pulses. If the Merkaba Fields of Earth were rapidly accelerated, which would
constitute a planetary leap in time cycles from the HU-1/D-3 cycle to Bridge
Zone D-3.5 cycle of the lnner Earth, between D-3 and D-4, the Zetas-Dracos
calculations would be useless. The Earth’s grid speed would be increased to a
level that the Frequency Fence EM pulses could not reach. The Dracos-Zeta
Resistance would not have enough time to decipher new calculations, and
once Earth was stabilized in the Bridge Zone D-3.5 time continuum, and
under full Guardian protection, the Dracos-Zetas could not successfully
launch an infiltration. Furthermore, if Earth was successfully shifted, and its
frequency  raised suf ficiently, the Dracos-Zetas would lose control of  their  Fre-
quency Fence and their human captives  in the D-4 cycle. For humanity to shift
into the Bridge Zone with Earth, the populations would have to fully assemble
their DNA to the 4.5 -strand level, and a minimum of  8% would have to assemble
144 

                                                                                   
                                                                              
                                                                  The Bridge Zone Mechanics
the ﬁfth DNA strand. Along with this , 144,000 individuals would need to fully
assemble the sixth strand, embody their entire soul matrix and begin to assemble the
seventh-twelfth strands.  This acceleration of the human genetic imprint would
release the D-4 Zeta Seal from all of the human races, present and future, and
would allow Earth’s grid speed to raise high enough to remain in the Bridge
Zone.  
    Following the shift to the Bridge Zone, Earth would leap ahead 2213
years by skipping the second half of its D-3 cycle, then move backward in
time 1106.5 years within the Bridge Zone cycle. After completing 1106.5
years in the Bridge Zone, Earth would leap ahead another 1106.5 years by
skipping the first half of its first D-4 cycle. Earth would then pass into the first
D-4 cycle at the half-cycle point and continue its path of natural evolution
through the D-4 time cycles. This movement of 2213 years ahead, 1106.5
back, and 1106.5 ahead in time represents a cumulative leap of 2213 years in
evolutionary space-time progression. The Dracos-Zeta Frequency Fence
would end up in the dimensional frequency bands below the Bridge Zone fre-
quency bands in which the Earth was positioned, and thus Earth’s grid would
be unaffected. However, once Earth was above the frequency fence, it could
not be re-entered into the dimensional bands below the fence. The Merkaba
Fields of Earth would re-seal in 2017, locking Earth into the Bridge Zone
time continuum. If the Guardians were going to force an early Doreadeshi, by
moving both the overtone/electrical fields and the base tone/magnetic fields
of Earth into the Bridge Zone time continuum cycle during the 2017 half-
cycle point, the move would have to be permanent.  
 
                                    BRIDGE ZONE MECHANICS  
    The idea of shifting a planetary body from one time continuum to
another may seem quite outrageous to a civilization that does not yet have a
working comprehension of multidimensional physics. We assure you that
such a procedure is most definitely real and valid in terms of the structural
energetic dynamics of the Time Matrix. This procedure is not used fre-
quently, for it is a complex and delicate process requiring direct intervention
from the higher Harmonic Universes of HU-3 -HU-5. For the most part,
planets and civilizations are allowed to evolve along the course of their own
development, following their own choices and meeting with the conse-
quences of those choices. But occasionally a planet and its peoples get into
trouble that has far-reaching consequences for numerous planetary systems,
and in these cases intervention in the course of evolution is permitted. Earth
is presently in such a state of potential crisis, unbeknownst to most of its pop-
ulations.  
145 
                                                                                                                     
           
                                                                                                                   

 
            Current Events  
                           TIME-CYCLE MECHANICS AND EVOLUTION  
                                       
                                                    Time-Cycle Mechanics  
    In order to understand the dynamics involved in such a time continuum
shift, it is helpful to realize that the structure and illusion of linear time is cre-
ated through the pulsation rate of particles and their relationship to that of
other particles. Each of the six 4,426 year smaller cycles within one 26,556
year Harmonic Time Cycle represents one time continuum. A 26,556-year
Harmonic Time cycle, through which a planet evolves through the 3-dimen-
sional bands of one Harmonic Universe, is called an Euiago.  A planet passes
through each of the six smaller time continua as it progresses upward through
the 3-dimensional scale within its Harmonic Universe. Each dimensional
band contains two time continua of 4,426 years each, so each dimension rep-
resents a time track of 8,852 years.  
    Of the six time continua in a 26,556-year Euiago cycle, four time con-
tinua represent forward-moving tracks of time called Pardo,  and two repre-
sent counter-rotating tracks of time called Reiago,  in which the planet passes
through the parallel universe.  A Pardo = 17,704 years  (4 continua of 4,426
years each = 4 x 4,426 years = 17,704 years). A Reiago = 8,852 years  (2 con-
tinua of 4,426 years each = 2 x 4,426 = 8,852 years) spent in the parallel uni-
verse.  Each Euiago contains one Pardo and one Reiago.  
    A  planet’ s progression through one time continuum creates a 45° shift in
the angular rotation of particle spin, or 1/8th of a full 360° rotation of parti-
cles, thus one continuum represents one dimensional Octave.  One Octave =
a 4,426-year track of time.  One dimension contains two time continua, or two
Octaves. A planet’s progression through one dimension creates a 90° shift (2
shifts of 45°) in the angular rotation of particle spin, or one-fourth of a full
360° rotation, thus one dimension represents one Harmonic Quadrant.  One
Quadrant = an 8,852-year track of time.  Three dimensions, three Quadrants,
or six Octaves (time continua) represent one Harmonic Universe.  One Har-
monic Universe = a 26,556-year track of time.  
    As a planet progresses through the first two Pardo Octaves, the angular
rotation of particle spin shifts 90° from its original position. Upon entering
the two Reiago Octaves in the parallel universe, the angular rotation of parti-
cle spin undergoes a 90° reverse rotation, bringing the angular rotation of
particle spin back to its original position. As the planet completes the final
two Pardo Octaves, returning from the parallel universe, the angular rotation
of particle spin again shifts 90°. Through the progression of three dimen-
sions, or Quadrants, the angular rotation of particle spin has a cumulative
shift of 90° (+90°, -90°, +90° = +90° shift), so in one Harmonic Universe the
angular rotation of particle spin undergoes one-quarter of a full 360° rotation.
    When passing from one Euiago cycle (Harmonic Universe) to the next,
the angular rotation of particle spin shifts 45°. Between HU-1 and HU-2, the
146 

                                                          
                                                                 Time-Cycle Mechanics and Evolution
45° shift is a 45° reverse angular rotation of particle spin. Earth enters HU-2
with its particles at a 45° angular rotation from their original position upon
entering HU-1 (+90°, -45° = +45° shift). In the progression from one Har-
monic Universe to the next, the angular rotation of particle spin moves for-
ward 1/4th, then backward 1/8th of a full 360° rotation.  
     It  is through the multidimensional relationships between angles of particle and
anti-particle spin that multiple reality ﬁelds can take place in the same space, while
remaining invisible to each other. As a planet evolves through this process, the rate
of particle pulsation, and thus the speed at which time moves, progressively
increases, while the density of matter particles progressively decreases. This is the
process of planetary evolution through the 15-dimensional scale.  
     A  planet moves from one dimensional frequency band to the next, and
from one time continuum to the next, by magnetically drawing into its mor-
phogenetic field, particles from the Uni fied Field of energy for each dimen-
sion. When a planet has pulled in all the frequency patterns of one
dimension into its morphogenetic field, it then moves upward into the next
dimensional field to complete the same process.  
     As a planet pulls in particles and patterns of frequency from the Uni fied
Fields, its morphogenetic field progressively expands to include those fre-
quency patterns and the pulsation rate of its particles progressively increases.
For each dimensional band there is a corresponding speci fic rate of particle
pulsation and also a speci fic angular rotation of particle spin. In one Har-
monic Universe a planet simultaneously has three levels of energetic identity,
one in each of the three-dimensional fields of that Harmonic Universe. The
three levels of a planet’s identity function together to give you the illusion of
Earth’s matter solidity. The particle content of each level of Earth’s body pul-
sates at a rhythm characteristic to the dimension in which each portion of
the body is stationed, and particles spin on an angular rotation that is charac-
teristic to the respective dimension. The planet exists within each of six
time continua simultaneously, as each of the three levels of the planet’s body
pulls in energy from its respective dimensional band, through the synchroni-
zation of particle pulsation speed and angular rotation of spin within each of
the six time continua. A planet evolves out of one Harmonic Universe and
into the next as each level of its three-dimensional body simultaneously com-
pletes pulling the frequency patterns of its respective dimension into the
planet’s morphogenetic field. These processes give the consciousness perceiv-
ing the third dimension the illusion of passage through linear time. In actual-
ity, time is not linear, but simultaneous.  
    Time exists as a Uniﬁed Field of particles pulsating at various rhythms and
spinning on various angles of rotation, through which the illusions of manifest space
and linear time appear to individuated identities, as they bring segments of the Uni-
ﬁed Field of particle substance into view by moving their consciousness through por-
147 
                                                                                                                                
                                                                                                               
                                                                                               

Current Events  
tions of the Uniﬁed Field. Time does not move. Consciousness moves itself through
the Uniﬁed Field of the Time Matrix.                             
                            Incarnational Identities, the Time Cycles,  
                                    DNA and Planetary Evolution  
    The evolution of life-forms upon the planet also takes place simulta-
neously, and, at any given time, activity takes place within each of the six
time continua. As the planet evolves, so does the consciousness stationed upon
that planet. Reincarnational identities represent portions of a person’ s soul aware-
ness that are simultaneously stationed and evolving upon a version of the planet
within each of the six time continuum cycles of an Euiago cycle . Usually, a soul -
HU-2 identity, manifests into 12 simultaneous incarnations, two in each of
the six time cycles in one Harmonic Universe. In each pair of incarnates,
one is male, the other female; this relationship is referred to as “twin ﬂames”,
but does not necessarily imply a romantic “soul mate” involvement.  
    The over soul—the HU-3 identity —creates 12 soul identities in HU-2,
each of which create 12 incarnates within the six time cycles of HU-1. Thus,
each person is part of an incarnational family of 144 incarnates residing
within the six HU-l time cycles. Each of the 144 incarnates carries part of
the 12-strand DNA pattern within the genetic code. As the 144 incarnates
simultaneously evolve with the planet through the six time cycles, the 12-
strand DNA imprint is progressively built up in the genetic code. DNA
evolves and human consciousness expands as identity evolves with the planet
through the Euiago cycles in each Harmonic Universe. The perceptions of
your present races are focused within the middle range of the third dimension
(the sixth and last time continuum of HU-1), and you perceive the reality of
these dimensional bands, from a station of consciousness one dimensional
band above. When you perceive the activity that is simultaneously taking
place in the lower-dimensional time continua, in the lower levels of Earth's
body, that activity appears to you as having taken place in the past. Percep-
tion of the other members of your soul family identity, who are stationed in
time continua below your own, will appear to you as past life incarnational
memory, even though these lifetimes are occurring simultaneously within
their own space-time coordinate. Identities stationed in time continua/
Octaves and dimensions/Quadrants ahead of your own, (which in your case
would be those in the HU-2 time cycles of Tara), will appear as future life
incarnational memory.  
     As you assemble DNA  strands, perception of both past and future incar-
nations becomes progressively more available to your present conscious
awareness. Earth evolves through the HU-1 time cycles, expanding its mor-
phogenetic field and raising the pulsation rhythm of its particle content, until
Earth evolves into the HU-2 time cycles to become Tara. As you move
through HU-l time cycles with Earth, assembling your DNA and expanding
148 
 

                                                        Time-Cycle Mechanics and Evolution
your consciousness, you evolve into the HU-2 time cycles to become your
soul-self identity.  
    T o the soul-self, the 12 immediate HU-1 incarnates that are in its incar-
national family are recognized as living sub-personality fragments of its own
identity, whose reality simultaneously takes place within the dimensional
bands contained within the soul-self’s DNA. The DNA represents electro-
magnetically encoded, digital data imprints of the other living portions of
your identity, which are stationed within other time continua. Through the
DNA, the experiential reality of other-time incarnates is implanted into the
body cells, to create a living Cellular Memory  of your simultaneous partici-
pation within other fields of time. The DNA operates as a window in time
through which your consciousness can perceive and participate in activity
taking place in the other time continua. As you assemble DNA, you expand
the particles of your body and awareness into higher-dimensional time cycles,
and progressively open the windows through time into other space-time coor-
dinates within other time cycles. Through DNA assembly, the Cellular Mem-
ory, which is subconsciously stored within the cellular-body consciousness,
progressively opens into conscious perceptual recognition.     
    In your current time continuum, you technically have one-half cycle
remaining within your third-dimensional time cycle. Earth’s morphogenetic
field has pulled in only half of the frequency patterns of the third dimension.
There is a direct correlation between how many frequency patterns the Earth has
pulled into its morphogenetic ﬁeld and the type of consciousness and biology that will
appear on the Earth at that stage of evolution.  W e call the amount of frequency
Earth has pulled into its morphogenetic field, from the dimensional uni fied
fields, its Accretion Level.  
     Earth is presently at the 2.5-accretion level —Earth has pulled into its mor-
phogenetic field all of the D-1 and D-2 frequency patterns, and half of the fre-
quency patterns of D-3. Earth would normally pass into HU-2 time cycles at
accretion level 3. Normally the three accretion level of Earth would not be
reached until 4230 AD. The life-forms on a planet at the 2.5-accretion level
will have a consciousness that falls near the 3.5 range. Consciousness will per-
ceive as solid matter and external reality the level of Earth’s body that is one
full dimension/Quadrant below the accretion level of the consciousness.
    Present human consciousness has an average accretion level of 3 —3.5,
which means that the energy patterns and activity taking place within the
low to middle frequency bands of D-3, between the 2 to 2.5-accretion level,
within the fifth time continuum, appear as solid matter, and external forms
and events. Present external earthly reality represents the energy patterns of
Earth’s body and the Uni fied Field in the low to middle frequency bands of D-
3, in the fifth time continuum, at accretion levels 2 —2.5. In order to perceive
the 2 —2.5-accretion level of Earth as solid, consciousness must be stationed
149 
                                                                                                                       
                                                                                                                 
                                                                                                              

                   Current Events
within the low to middle D-4 frequency bands at an accretion level of 3- 3.5
(seventh time continuum).  
     When perceiving your own physical body , and the external objects and
activity around it, you are seeing the particle content of your personal mor-
phogenetic field, Earth’s morphogenetic field and the Uni fied Field, as they
exist within the low to middle frequency bands of D-3, in the pulsation
rhythms of the fifth time continuum, at the 2-2.5-accretion level. You per-
ceive these frequency bands as solid while the particle content of your con-
sciousness is stationed within the low to middle frequency bands of D-4, in
the pulsation rhythms of the seventh time cycle, at a 3-3.5-accretion level.
You will perceive the frequency bands of middle to upper D-3, in the pulsa-
tion rhythms of the sixth time cycle, at the 2.5 —3 accretion level, as “inner
space”, the activity taking place “inside your head and body”, and the atmo-
sphere surrounding your body and the Earth, that gives you the perception of
space between objects.  
     The illusion of 3-dimensional perception is created through this triad of
particle pulsation speeds.  The pulsation speed/rhythm of particles is created
as energy substance ﬂows between fields of particles having different angular
rotations of particle spin in relation to each other. The 3-dimensional human
consciousness and the 3-dimensional body of the Earth consciousness are
made of particles that pulsate at three different rhythms, and which exist at
three different positions of angular rotation. These particle fields make up
three levels of Merkaba Fields within and through which physically apparent
manifestation occurs. There is a 90° shift in angular rotation of particle spin
between the three Merkaba Fields, between the three levels of human con-
sciousness, and between the three levels of Earth’s particle body. The three
levels of the personal body and the Earth’s body represent three different time
continua, or Octaves, through which frequency bands from the dimensional
Unified Fields are pulled/accreted into the personal morphogenetic field and
that of the Earth. These three particle pulsation rhythms are synchronized,
and through this dance of particle spin and pulsation, personal consciousness
evolves with the Earth upward through the time cycles of the 15-dimensional
scale, progressively expanding and raising the level of accretion.  
     The level of frequencies accreted into the personal morphogenetic ﬁeld will
determine the level of DNA strand assembly you possess. As you pull in more fre-
quency bands from the dimensional Uniﬁed Fields, your accretion level rises, more
DNA codes assemble and become operational within your DNA strands, and your
consciousness and perceptual ﬁeld expands.  
     A consciousness with a 3 —3.5-accretion level has a DNA code with 3-3.5
strands assembled. The strand assembly and activation level of the DNA cor-
responds directly to the number of dimensional frequencies contained within
the morphogenetic field of the consciousness. The number of dimensional fre-
quencies contained within the personal morphogenetic field corresponds
150 

                                                             
                                                                                  
                                                                                  Time-Cycle Mechanics and Evolution
directly to what dimensional levels of the Earth’s body, and what time con-
tinua, will be perceived as physically manifest reality, to that consciousness. If
your fourth DNA strand is fully assembled, you will have an accretion level of
4, your consciousness will be stationed in lower D-5 and you will perceive
thought-forms and energy patterns existing within the lower D-4 frequency
bands as physically manifest, external events. These thought-forms are the
energy patterns left behind by you and the masses, when your consciousness
was stationed in lower D-4, when you were assembling the fourth DNA strand.
    Presently , most humans do not have more than a 3.5-accretion level, a
low to middle fourth-dimensional focus of consciousness. This level of con-
sciousness corresponds to 3.5 strands of activated DNA, which only allows
the consciousness to perceive thought patterns/energy patterns of objects and
events from the low to middle frequency bands of D-3 as physical reality. The
frequency fields of D-1 are below the range of D-4 perception and appear as
inner darkness. The lower frequency fields of D-2 appear as past memories.
The middle to upper frequency fields of D-3 appear as internal mental/per-
ceptual events and thought-forms, and as Earth’s atmosphere and the space
between objects, from D-4 perception. The reality fields of middle to upper
D-4 and above are above the range of present human D-4 perception and
appear as inner and outer light and future memories. As human DNA builds,
the higher-dimensional reality fields come into manifest view, and the lower-
dimensional reality fields fall out of perceptual range.  
    As a dimensional field begins to come into view , it first appears as inner
thought patterns that become inner mental pictures made of light. The qual-
ity known as imagination is, in reality, the consciousness bringing into its
mental view, higher dimensional thought-forms. The images, perceptions
and pondering of imagination represent higher-dimensional thought-forms
made of energy substance, that are placed in the higher-dimensional fields by
the present moment self. Imaginative perceptions may also be thought pat-
terns of the higher-dimensional, future self aspects of identity, that “just
appear” in inner perception, as the present awareness brings the higher-
dimensional reality fields into its inner view. The quality known as past
memory represents the consciousness bringing into its mental view thought-
forms and experiential imprints from the dimensional bands below its focus of
attention. These represent thought-forms of past identity aspects, presently
focused in the lower time continua or within lower frequencies of the present
time continuum. Dreams represent portions of thoughts and experience that
is taking place in both higher/future and lower/past dimensional fields/time
continua, entering into the present moment station of awareness.  
    The low to middle D-4 frequency bands, in which human consciousness
is presently stationed, represent the now-moment stream of consciousness,
which is always the point of personal creative power. Thoughts held in the
present moment focus of conscious attention will be left as imprints of ener-
151 
                                                                                                                
                                                                                                                   

   Current Events  
getic substance within the frequency bands in which those thoughts were
held. Once the focus of attention has moved beyond those thoughts and on
to the next, the thought imprints left behind become morphogenetic fields,
as the now-moment focus of attention moves forward into the next set of fre-
quency bands.  
    The process of moving forward through time is the process of progressively
accreting sound frequencies into your personal morphogenetic field. As you
pass your consciousness through a now-moment point, it internalizes all con-
tained within that manifest moment as a minute, digital electro-program made
of frequency. The process of internalizing that moment in time expands your
morphogenetic field, which creates a subtle acceleration in the pulsation
rhythm of the particles of which your body and consciousness are composed.
This acceleration of pulsation rhythm perceptually and energetically moves
you-as-consciousness forward into the next set of frequency bands. The fre-
quency bands of the previous moment internalize and fall from your view, as
the set of frequency bands directly above them become your next now-moment
of conscious focus. Movement through time is frequency accretion.  The manifest
illusion you perceive before your eyes is, in reality, a Unified Field of frequency,
composed of energy particle substance in the form of digital, electro-tonal
thought patterns. Every thing and person outside of yourself, including your
body, and the contents of your conscious mind at that moment point, exist as
energy imprints within the Uni fied Field of that now-moment. If you can teach
yourself to perceive each moment of your external reality as a dream-scape that is
manifesting through your consciousness, you will get closer to consciously sensing the
stream of consciousness through which your external reality manifests directly through
you. Just as your internal dreams seem to take place within your consciousness
while you participate within them, your external reality is also a dream-scape,
manufactured by your consciousness, through which energy particles are
shaped into thought-forms that will later become manifest. You are walking
within the con fines of a mass dream, and the sooner you can grasp that con-
cept, the sooner you will be able to assert creative control over the form your
personal part of that mass dream will take.  
    Every time you think a thought, you are leaving a morphogenetic
imprint within the frequency bands in which your consciousness was sta-
tioned. You will run into that thought pattern, in combination with others
from the collective consciousness, as a manifestation in physical reality. Mor-
phogenetic fields are the form-holding patterns through which matter forms
and events manifest. When a morphogenetic field is created, it begins to draw
frequency patterns into itself, expanding, accreting, and “fleshing itself out
into matter”. Have you ever considered where thoughts go once your atten-
tion has left them? Part of what appears to you as manifest reality now, from
your D-4 station of attention, represents your thought-forms, and those of the
collective masses, that were left behind as morphogenetic fields when your
152 
                             
                                           

                                                            
                                        Time-Cycle Mechanics and Evolution
conscious focus of attention was stationed in the dimension below your
present focus. Part of what you see before your eyes represents the living
thought-forms of your past selves (from this incarnation and those previous),
and those of the masses. Your thoughts become morphogenetic fields within
the morphogenetic field of the Earth, planted within the frequency bands in
which your consciousness is presently stationed, left within your present time
cycle, to be rediscovered as manifest objects and events, once your conscious-
ness has evolved beyond them.  
     Another part of what you perceive before your eyes represents the collec-
tive thought-forms of your future selves, whose focus of attention is stationed
in space-time coordinates ahead of those in which your present consciousness
is focused. Thought-forms expand, backward and forward in time, up and
down the dimensional scale, from the position in which the thought-form
was created. Your present manifest illusion is composed of the thought-forms
of your past and future selves, and the thought-forms you presently hold. A
thought-form placed in one dimension will align the energy substance of all
the dimensions below it, into a version of that pattern; the thought sets a
morphogenetic field in each of the dimensions below. The thought will also
group with like thoughts from the future, the higher-dimensional frequency
bands, and set a morphogenetic imprint of itself in all the dimensions above.
Thus the thought expands backward and forward in time.  
    Every thought you think now combines with like thoughts of past and
future selves, to give you the manifest illusion you presently perceive. Like
thought and action attract and re-manifest like thought and action. Your past
thoughts and deeds will show themselves in your present reality, but you have
the absolute power to change them, by using your present focus of attention
to create new thoughts and redesign those that are undesirable, whether they
are coming from the past, present or future. Thought patterns from your past
selves, which are composed of more dense and slower-pulsating particles,
manifest within the cellular structure of your body. This is frequently referred
to as your karmic imprint or karmic debt.  These thought patterns of past
selves will remain in the body, and replicate themselves in the present and
future, until the slower-pulsating particles of those thought patterns are raised
in speed and released from the frequency patterns of which the body is com-
posed. You have the power, in your present moment, to change any thought
pattern from your personal past, present or future, and in doing so you will
change the contours of your present reality.  
    Y ou can become “ karma immune”  once you learn to master this power,
for you will train your consciousness to move backward and forward in time,
to recreate undesired events and redesign more desirable outcomes. The slow
way to release slower-pulsating thought patterns and their manifest discom-
forts from your life is to wait until the events manifest in external reality, or as
conditions of disease within the body. Then you take action in the present to     
153                                                                                                                
                                                                                                                                                                                                                                                                              
                                                                

  Current Events  
 create a present solution, and that solution expands backward and forward in 
time to create some degree of resolution of the pattern in the past and future.
This is the usual path of “walking through your karma,” or walking through
the cumulative thought patterns of your past, present and future selves. The
fast way to change your karmic imprint is to catch those slower-pulsating
thought patterns before they move into manifestation. This is easier said
than done, but it is not exceedingly difficult to do, once you have trained
your consciousness to manipulate energy in certain ways. Thought patterns
from the past and future become part of the particle make-up of your con-
sciousness, bio-energetic field, body, DNA and external reality field. They
become stored in the DNA as minute crystallizations of energy, which inhibit
the natural process of DNA strand assembly.               _____________________________________________________________
       The crystallized thought patterns stored in your DNA and cellular imprint will
continue to manifest within your body and before your eyes, until you learn to ﬁnd
and release them while they are still within the Cellular Memory imprint of your
body. This is easy to do, with practice.            ____________________________________________________________
   To release your crystallized thought patterns from your DNA and cellu-
lar memory imprint, please refer to Field Exercise 1, on page 495, and prac-
tice it now. Through exercises of this nature you are learning to consciously
modulate the pulsation rhythm of the particles of which your consciousness is
composed, training your present moment consciousness to move up and
down the multidimensional scale.  
    Y ou are training your consciousness to time travel, forward and backward
in time, so you may begin to directly affect the collective thought patterns of
portions of your identity stationed in other space-time coordinates. You are
beginning to train yourself to control the manifestation of external events, by
mastering the inner energetic dynamics through which those events manifest.
    W e have given you this exercise because it is one of the fastest and most
effective ways to clear the “karmic imprint” of slower-pulsating crystallized
thought patterns from the body cells and DNA. This is extremely important
to do if you plan to accelerate the assembly and activation of your DNA
strands. As you begin to work with UHF energies from the higher chakra
centers (which we will teach you to do in subsequent books), these energies
will begin to rapidly release slower-pulsating thought-form crystallizations
from the body cells and DNA. As this occurs the “karmic imprint”, or event
manifestation program, contained within the thought-form crystallizations
will begin to manifest itself in personal, external events and within the phys-
ical body form. If the human mind and body is not prepared to synthesize the
frequencies of energy released from the thought-form, one can become
extremely ill in physical terms, or the mental and emotional bodies can
become severely unbalanced. The outer events of one’s life content and rela-
tionships can also turn to chaos during rapid cellular activations, as multiple
154 
  

                                                           
                                                                 Time-Cycle Mechanics and Evolution
karmic dramas begin to manifest themselves at every turn. When you partic-
ipate in accelerated DNA evolution you are rapidly shifting and elevating the
frequency patterns of which your body and consciousness are composed. This
rapid shift in frequency can appear as utter chaos in terms of external condi-
tions and events.  
      Though the ultimate outcome of these cellular activations is a restructuring of
your body, consciousness and life drama into a higher level of peace, harmony, 
health and order, the process of “getting there” rapidly can be very treacherous 
indeed.  When using exercises such as the one provided, you are learning to 
take control of this process so it does not take control of you. The point at 
which you break up the thought-form crystallization and its energy releases, 
is the point that the karmic imprint would normally begin to manifest into the 
body and external events. DNA Activations alone will get you to this point.
However, in the exercise you then take that released energy, transmute it
through D-5 and D-8 frequency patterns, (the “sun” image), and project it
directly into the DNA. Merging the energy of the karmic imprint with the
D-8 frequencies serves to raise its energies to the highest levels of harmony
and order. That ordered energy  is then placed directly into the DNA, where
it can blend in unobtrusively with the imprints of the operational strands. It
will stimulate further assembly and activation of DNA strands, but in an
orderly fashion that does not cause excessive disruption in your bio-energetic
fields, and which will not throw your life into chaos.  
   In cellular activations, the energy will release at the frequency level in
which the thought-form crystallization existed, sending a rush of photonic
energy through the body at that frequency level. The energy will then indis-
criminately alter the existing order of energies in that area, a condition
which will manifest as chaotic energies moving through the bio-energetic
field, body, and consciousness, then into manifestation. This exercise con-
trols the release of energy and directs it into harmonious order.  
     Learning to direct mental energies, and those energies released from 
thought- form crystallizations will become a needed survival  skill in the near future,   
whether or not one is on the path of ascension, or interested in spiritual activities.  
      The Earth is entering an ascension cycle acceleration period, its grid will
  be infused with UHF D-5 through D-9 energies via a process of Stellar Acti-
   vations. The Stellar Activations will occur as Earth's Merkaba Fields align
  directly with the Merkaba Fields of six Stellar Spirals, as parts of Earth's natu-
    ra l procession through its 26,556-year Euiago time cycle . Everyone on the                             
planet will begin to have cellular activations directly through the Earth’ s grid, due 
to the coming Stellar Spiral alignments and the planetary Stellar Activations  these 
alignments will create.         
  The human bio-energetic field is directly connected to that of the Earth,
  and when the energy infusions of the Stellar Activations begin running through
     Earth’s grid, progressively accelerating between   now and  2017, the   human   body       
    155                                                                                                                                
                                                                                                                               

   Current Events  
will also receive these energy infusions. These energy infusions will cause a rapid
release of the crystallized thought patterns stored in the cells and will trigger rapid
DNA activation, assembly and expansion of consciousness.  
   The thought-form crystallizations held within the body , unbeknownst to
the conscious personality, will begin to release their energies as the pulsation
rhythm of the particles of Earth's body progressively increase between now
and 2017. Your DNA and Cellular Memory will activate whether or not you
are ready, and regardless of whether your body and mind have been prepared
to synthesize these new frequencies of energy. The least prepared may find
their entire life drama falling into shambles, the health of their physical and
mental bodies rapidly deteriorating and their emotions exploding into chaos.
We are not joking, nor exaggerating.  
      Be Prepared . Learn to direct these energies now, before they overwhelm you.
Your survival and ability to remain centered and effective in handling external
events will depend upon your development of these subtle energy-directing skills.
The exercise provided is a good place to begin. In 2012, very intense Stellar
Activation energy infusions will begin, so we suggest that you begin preparing
now, as these skills take a bit of time and practice to develop. We recommend
that you clear as many of these hidden karmic imprints as possible before 2012,
when they will begin to rapidly burst into physical manifestation.  
                                                          
                                                      DNA 
                    DNA Initiations, Consummations and Activations  
    Before we resume our discussion on the mechanics of the Bridge Zone,
 we would like to share with you a little secret about human DNA. Presently
  your conscious awareness is stationed within the low- to middle-frequency
  bands of D-4, and the reality fields you perceive as solid matter and external
  events are those of the low to middle frequency bands of D-3. When you
  think a thought from your present station of focus in D-4 (such as “this is so
  and so now”, or “I see such and such now”), that thought, being a quantity of
    particle substance made of units of electromagnetic energy , automatically
  becomes part of the D-4 Uni fied Field of energy. That thought also becomes
 coded as an energy imprint within the fourth DNA  strand. When you are
  assembling DNA  strands, you are pulling frequency patterns from the Uni fied
   Field into your personal morphogenetic field, one set of dimensional sub-fre-
   quency bands at a time. These dimensional frequency patterns that are pulled
     into the morphogenetic field progressively manifest as new electromagnetic
  codes within the DNA  strands, which means the DNA  progressively expands
  or accretes, as the morphogenetic field expands by pulling in more frequency
 patterns from the dimensional Uni fied Field.  
    When you are assembling your fourth DNA strand your consciousness will
  be stationed within the fourth dimension and you will perceive the Uni fied
   156 
  

                                                                                                            
                                                                                                                      
                                                                                                                
                                                                                                                 DNA
Field of the dimension below in terms of matter solidity. It is the present focus
of your consciousness that magnetically draws frequency patterns from the
dimensional Uni fied Field into your personal morphogenetic field. Once your
consciousness has moved into one sub-frequency band, it pulls that frequency
pattern into the morphogenetic field, the morphogenetic field manifests that
frequency pattern into the corresponding DNA strand and shifts the conscious-
ness to the next sub-frequency band up. Whatever thoughts you held at one
station of consciousness become programmed into the DNA strand that corre-
sponds to the dimension in which that thought was held. A thought-form cre-
ated while the consciousness is focused in D-4 becomes a manifest part of the
fourth DNA strand and is entered into the Cellular Memory stored within the
sub-atomic particles of which the body cells are composed.  
    Once the personal morphogenetic field has pulled in all of the 12 sub-
frequency bands in one dimension, the full DNA strand corresponding to
that dimension is fully assembled and the consciousness is transferred into
the first sub-frequency bands of the next dimension up. We call the point of
evolution when the full DNA strand is assembled the Consummation  and
the point when the consciousness transfers into the first sub-frequency band
of the next dimension up the Initiation.  
    With the Consummation of one DNA  strand, and the Initiation of the
next strand, the contents of the consummated strand begin to progressively
appear in physical manifestation for the consciousness, now focused in the
dimension above. We call the point where the contents of a DNA strand
begin to physically appear within the perceptual range of the conscious per-
sonality the Activation of the strand.  
    For example, when the consciousness has moved through the entire 12
sub-frequency bands of D-3 and thus assembled the third DNA strand, the
identity is considered to be at its third Consummation, (the morphogenetic
field and consciousness have “consumed”, or drawn into themselves, the fre-
quency patterns of the third dimension). At the third Consummation, the
fourth Initiation begins, as the station of consciousness transfers to the first
D-4 sub-frequency bands and the D-4 frequencies begin to enter the morpho-
genetic field and the DNA. As the first sub-frequency band of D-4 initiates
into the morphogenetic field, the first sub-frequency band in the D-3 third
DNA strand begins to Activate, or holographically project its contents into
the range of physical perception. Thus the Consummations, Initiations and
Activations of DNA go together, and represent the points at which the focus
of consciousness transfers from one dimension to another, and the collective
thought-forms from the dimension below begin to come into conscious per-
ception as physically manifest form.  
    As we have mentioned, consciousness will perceive as physical reality
the energy patterns of the frequency bands that exist one full dimension
below the station of awareness. The progressive DNA Initiations of one
157 
                                                                                                                                                                                     
                    
                                                                                                                     

      
       Current Events  
dimensional band create the progressive Activations of, or manifestation of
the collective thought patterns contained within, the DNA strand that cor-
responds to the dimension below. This process of progressive frequency infu-
sion into the DNA, and the DNA-strand assembly it creates, gives you the
perceived illusion of passage through linear time.  
   The new frequencies progressively increase the pulsation rhythm of the
particles that compose your body and consciousness, moving your conscious-
ness into the next set of dimensional sub-frequency bands, while propelling
the contents of one sub-frequency band below into manifest perception. The
manifest illusion of moments passing forward in time within a physical reality
represents your consciousness perceiving the progressive Activations of the
last DNA strand you assembled. These progressive Activations of the last
DNA strand occur as your consciousness progressively Initiates new sub-fre-
quency patterns from its present dimensional focus, into the morphogenetic
field. Time does not move forward, in fact, time does not move at all. The
experience of progression through time is created as consciousness progres-
sively draws into itself frequency patterns from the dimensional Unified
Fields, which progressively expands the consciousness, morphogenetic field
and physical body. The particles of which the body and consciousness are
composed pulsate progressively faster as higher frequencies are embodied in
the morphogenetic field, DNA and consciousness, the body matter grows
progressively less dense and the consciousness expands upward through the
multidimensional Unified Field.  
     W e wanted you to know this little secret about the true nature of
human DNA, and how the DNA is the literal vessel through which the illu-
sionary experience of physical, external reality is manufactured. Knowing
this, you may then realize that when you are shifting your consciousness and
using the imagination to program desired thought-forms into the past, present or
future, you are literally reprogramming the frequency patterns of your cellular con-
tent and the operational holographic program that will manifest into physical reality
through the DNA.  
    The holographic, thought-form program through which your external real-
ity will manifest is literally stored, as a multidimensional electromagnetic pro-
gram, within the sub-atomic particle structure of your cells, much as a computer
stores data within its memory. The DNA serves as the literal conduit through
which that holographic program will project data from cellular memory into
physical manifestation, much as a computer’s circuitry allows the electronic data
stored in memory to be projected onto the screen, into forms recognizable to
human perception. Your external reality field is the screen upon which the
thought-forms that are stored within your cellular memory program will be dis-
played, and the DNA operates as the electromagnetic circuitry through which
that memory comes into perceptual manifestation.  
158  

                                                                                                           
                                                                                                              
 DNA
      To gain creative control over your manifest events, you must edit the cellular
memory ﬁles  (clear and transmute the lower pulsating particles from the body
and auric field), upgrade the holographic thought-form program (create new visu-
alizations of desired past, present and future events, living them in imagina-
tion “as if they are happening now” within the desired time period) and
expand the DNA circuitry (consciously use the chakra system to accelerate
DNA strand assembly) in order to allow new, desired reality pictures to project
into your world of manifest events.  In the practice of conscious evolution, cellu-
lar clearing and DNA transmutation, this is precisely what is taking place.
     When you create “future memory” visualizations, you are putting spe-
cific manifestation instructions into the morphogenetic field of the DNA
strands you have not yet assembled. You will encounter those reality pictures
in manifest form once those DNA strands come into activation, through the
initiation of your consciousness into the frequencies of the next dimension
up. When you recreate “past memories” from your present focus, you are lit-
erally putting new reality pictures, in the form of electromagnetic impulses,
into the DNA strands you have already built and activated. You can literally
shift things in your present manifest experience by reprogramming the past
memory impulses stored in your DNA; add new past memories and new
events will manifest in your present. Create future memories now, and you
can direct the path of your evolution from your present moment in time.
    When you release crystallized thought-forms composed of slower-pulsat-
ing particles from your present cellular structure, you are stopping those lower
thought-form patterns from activating into your DNA, through which they
would otherwise project into physical manifestation. Your moment of power
is always in the present, when you realize that your present focus of attention
can alter and direct events in both past and future, and within the present. It
takes practice to develop skill in conscious manifestation and you must
become familiar with the “feel” of your own inner focus of consciousness in
the present, in order to direct your power of manifestation.  
         Prior to learning manifestation skills, you must learn de-manifestation skills.
Learning how to remove undesirable morphogenetic thought-form patterns from
your active holographic program, which is stored within the cells and made oper-
ational through the DNA, is the first step in gaining mastery over the contents of
your external reality field. By removing slower-pulsating particles from your body
systems, you make room for the addition of new morphogenetic thought-form
patterns composed of faster pulsating particles, which contain the electromag-
netic imprint for more harmoniously ordered events.  
     W e are telling you of these things because the Guardian Alliance needs
your help to ensure the success of the Bridge Zone Project. We need you to
take responsibility for consciously building your personal DNA, expanding
your consciousness, clearing your cellular memory and directing your
thought-forms to the Bridge Zone.  
159 
                                                                                                                   
                                                                                                                                                                                                                                    
                                                                                                                       
   

  9
                                            
                                                                                                  Time Shift  
                    
                                ASCENDING AND DESCENDING PLANETS  
      The Bridge Zone, Shift to Agartha, Ascending and Descending Planets
          The speed of evolution of a planet is directly connected to the rate of
evolution of the life-forms upon the planet. In the Bridge Zone Project we
are going to shift Earth entirely out of its present D-3 time cycle, which con-
stitutes accelerating the pulsation rate of particles and shifting the angular
rotation of particle spin by 22.5°. In order to make this shift successfully, 8%
of Earth’s populations have to fully assemble the fifth DNA strand, 144,000
individuals must assemble the sixth DNA strand and the remaining popula-
tions must rapidly reach an accretion level of 4.5, which is the assembly of all
of the fourth DNA strand and half of the fifth strand.  
    Remember that consciousness will perceive as solid the dimensional fre-
quency bands one dimension below its present station of focus. For the con-
sciousness of humanity to experience the physicality of Earth at the 3.5-
accretion level of the Bridge Zone, that consciousness must have a minimum
of 4.5-accretion, which comes with assembly of all of the fourth DNA strand
and half of the fifth strand. The human collective represents part of the
Earth’s matter body, and if the collective accretion level of human beings
remains at its present 3 —3.5 average, the accretion level and vibration rate of
the Earth’s grid will be held down. In the Bridge Zone time continuum, the
Earth’s accretion level will be raised from its current 2.5- to a 3.5-level of
accretion. In order for the Earth's grid to reach this accelerated level of accre-
tion in time to begin entering the Bridge Zone by 2012, most of the human
populations must be able to reach no less than a 4.5-accretion level. If the
majority of the populations cannot reach the 4.5-accretion level, the vibra-
tion rate of Earth will not reach 3.5 and the planet will not shift into the
Bridge Zone Time continuum.  
  In terms of a planet shifting into another time continuum, what is
really taking place is that the pulsation rate of particles, within the three lev-
160 
       
  


                                                              
                                                                                         
                                                                                      Ascending and Descending Planets
                    els of the planet’ s body , is being increased and the angular rotation of particle
spin is being shifted. These adjustments constitute a shift of the planetary
bodies into faster moving time cycles. The consciousness of those upon the
planet must also make such a shift, and the particles of which the body and
consciousness are composed will undergo the same acceleration of pulsation
speed and change in angular rotation of particle spin.  
    Normally , when a planet reached its half-point in its second ascension
cycle, which constitutes the 2.5-accretion level, the electrical overtone parti-
cles of its D-3 Merkaba Fields would merge with their anti-particles, form a
morphogenetic wave and transfer into the next Harmonic Universe into the
sixth-dimensional frequency bands. Also included in this morphogenetic
wave are the electrical overtone particles of the D-1 and D-2 Merkaba Fields.
The D-2 overtone electrical particles transfer to D-5 and the D-1 electrical
overtone particles transfer into D-4. So normally, during the half-point mor-
phogenetic wave the clockwise rotating electrical Merkaba Fields of D-1, D-2
and D-3 open up and merge with the counterclockwise rotating magnetic
Merkaba Fields of D-4, D-5 and D-6. During the 10-year period surrounding
the half-point, all of the electrical overtone particles that Earth had pulled in
from dimensions 1, 2 and 3 and stored in the morphogenetic field, are trans-
muted through their anti-particles and transferred into the morphogenetic
field of Tara in HU-2.  
    At the completion of the ascension cycle, 2213 years later, the same pro-
cess occurs with the magnetic base tone particles within Earth’s morphoge-
netic field. The particles of Earth’s counterclockwise-rotating, magnetic
Merkaba Fields, of D-1, D-2 and D-3, open and merge with the particles of
Tara’s electrical clockwise-rotating Merkaba Fields of D-4, D-5 and D-6.
Earth’s morphogenetic field fully merges with that of Tara and Earth leaves
the time continua of HU-1 and shifts into the time continua of HU-2. Earth
becomes Tara. During this process, the consciousness stationed within the
three levels of Earth’s body, the six time continua of Earth’s HU-1 Euiago
cycle, also transmutes and transfers into the time cycles of HU-2. A planet’s
shift from the time cycles of one Harmonic Universe into the time cycles of
the next Harmonic Universe usually takes place in two phases. The overtone
particle base transfers at the half-ascension cycle point and the magnetic par-
ticle base shifts 2213 years later, at the end of the ascension cycle.  
    The Bridge Zone Project will accelerate this process; the two phases of
Earth’s particle conversion from HU-1 to HU-2 will take place at once,
between 2012 and 2017. The arti ficial time continuum into which Earth will
shift exists between the natural time cycles of the third and fourth dimensions.
In the natural procession of merging the grids of Earth and Tara, the Earth’s grid
progressively raises in speed, beginning 15-20 years before the half-cycle point.
    The pulsation rate of Earth’ s D-1 particles raises to the rhythm of D-4,
Earth's D-2 pulsation rate accelerates to the rhythm of D-5 and Earth’s D-3 par-    
161                                                                                                                             
                                                                                          
                                                                     

Time Shift  
ticles enter the D-6 rhythm. For a period of five years before the half-point,
Earth’s grid begins to intersect with that of Tara, as Earth’s D-1 particles shift
into the pulsation rhythm of the D-4 time continuum. Following the half-
point, scheduled for 2017 AD, Earth would naturally begin returning to the D-
3 - D-1 pulsation rhythms of the HU-1 time cycle. The Dracos-Zeta Resistance
plans to broadcast the EM pulses of their Frequency Fence through the pulsa-
tion rhythms of HU-l dimensional frequency bands.  
    The Bridge Zone Project will allow the primary particle base of Earth to
remain at a higher level of pulsation within the Bridge Zone time continuum,
at the point Earth would normally begin to slow in pulsation rhythm and revert
back into the HU-l time cycles. The Earth must begin its ascent into the HU-
2 particle pulsation rate now, its D-1 particle base accelerating to the D-4
rhythm, in order for the entire grid (both electrical overtone and magnetic base
tone particles) to shift into the D-4 time cycle. Earth’s morphogenetic field will
temporarily reach a stable 4-accretion level, the accretion level of the D-4 time
cycle, by 2012. Acceleration of the particle pulsation rhythm of Earth’s grid
into the D-4 rhythm is a normal part of the ascension cycle process. For the
Bridge Zone project to succeed, this acceleration must be intense enough to
raise both overtone and base tone particles into HU-2 rhythms, and must also
be able to counter balance the ULF EM pulses of the Frequency Fence the Dra-
cos-Zetas plan to use in 2004.  
     If Earth does not make it into the pulsation rhythm of the D-4 time cycles
by 2012, full merger between the grids of Earth and Tara will not take place, the
Halls of Amenti will not open and Earth will not be able to shift into the
Bridge Zone Cycle. In this case the Frequency Fence transmissions of the Dra-
cos-Zeta Resistance (should they be successful in orchestrating their 2003
experiment) will begin chain reaction Earth changes between 2012-2017, as
the natural fusion process of particle and anti-particle within the Earth’s grid
are disrupted.  
    The Frequency Fence would cause the particle pulsation rhythms in cer-
tain portions of Earth grid to drop rapidly in speed, while other portions of the
particle base attempted to rise in speed. The fabric of Earth’s particle base
would begin to tear open and fragment. In areas of Earth’s grid where this frag-
mentation occurred, landmasses would begin to break apart, new fissures within
the Earth’s tectonic plates would emerge and plate shifting would result. This
does not have to occur. The populations are fully capable of accelerating their
genetic evolution by consciously building DNA through working with the
higher chakra centers. If humanity successfully raises the pulsation rhythm of
the particles that compose the physical, emotional and mental bodies, the
Earth’s grid will proceed to accelerate its own pulsation rhythm into the D-4
time cycle. Earth will reach a high enough pulsation rhythm by 2004 to shift
162 
 

                                                                      Ascending and Descending Planets  
out of range of the Frequency Fence transmissions and the Halls of Amenti
plan will proceed on schedule. The Guardians are con fident that humanity
will be able to do its part now,in order to ensure its own survival.   
       Earlier in our discussions we have mentioned the existence of the Inner
Earth, Agartha, which is located in a frequency modulation zone between
Earth and Earth’s double in the parallel universe. Agartha represents part of
Earth, and like Earth, Agartha has three levels of the planetary body. The
Earth’s three primary body levels exist within dimensions 1, 2 and 3. There is
a relationship of particle pulsation speed between Earth and her parallel dou-
ble: 
     The particle pulsation speed of Earth’ s D-2 = anti-particle pulsation
speed of parallel Earth D-1.  
       Earth’s D-3 particle pulsation speed = that of parallel D-2, etc.  
     The speed of particle pulsation within each dimensional band in the
anti-particle universe is faster than that of the corresponding dimension in
the particle universe. The particle pulsation speeds of the dimensional bands
in the particle universe run one dimension behind those of the dimensional
bands in the anti-particle universe. The speed of particle pulsation in the par-
ticle universe D-2 would be the speed at which anti-particles pulsate in D-1
of the parallel universe. Earth’s D-2 particles are stationed within the same
dimensional Uni fied Field as the D-l anti-particles of parallel Earth:
        Particle D-2 = Anti-particle D-1.  
        Particle D-3 = Anti-particle D-2.  
        Particle D-4 = Anti-particle D-3, etc.  
    The frequency bands that make up the D-2 particles of Earth are the
same frequency bands that make up the D-1 anti-particles of Parallel Earth.
    Earth’ s D-3 particles co-exist with parallel Earth’ s D-2 anti-particles.
    Parallel Earth’ s D-2 anti-particles co-exist with Earth’ s D-3 particles, etc.
    When observing Earth’ s D-3 landscape (which are the dimensional fre-
quency bands that appear solid to a consciousness stationed in D-4 of the par-
ticle universe) one perceives the contours of D-3 particle and D-2 anti-
particle Earth.  
      It is important to realize this intimate relationship between the particle
content of Earth and anti-particle Earth, if one is to understand the reality
fields in which Agartha, the Inner Earth, takes place. In view of the above
dimensional particle and anti-particle relationships, the three levels of
Earth’s planetary body and those of the parallel Earth can be understood as
follows:  
    Earth's D-2 elemental body = anti-particle Earth’ s D-1 iron core crystal.
    Earth’ s D-3 mental body/atmosphere = anti-particle Earth’ s D-2 elemen-
tal body.  
163 
                                                                                                                  
                                                                                                                  
                                                                                                             

Time Shift  
    Anti-particle Earth’ s D-3 mental body/atmosphere = Earth’ s D-4 astral
body, which is the D-4 gold core crystal Merkaba Field of Tara, stationed
within the center of Earth’s Sun.  
    Agartha represents an Earth reality field that exists between the Earth
and her parallel double. Earth’s D-1 iron core crystal is stationed within the
first-dimensional frequency bands of the particle universe, at 0-accretion
level. Anti-particle Earth’s D-1 iron core crystal is stationed within the D-2
frequency bands of the particle universe, Earth’s elemental kingdom, at accre-
tion level 1. Agartha’s D-1 iron core crystal can be viewed as being stationed
halfway between Earth’s D-1 core crystal and the core crystal of parallel Earth
at particle universe D-2, which would represent a .5-accretion level in the D-
1 frequency bands. For Earth, parallel Earth and Agartha, the elemental
body is one dimensional band above the placement of the iron core crystal,
and the mental body/atmosphere is one dimensional band above the elemen-
tal body, or two dimensional bands above the iron core crystal:  
•   The particle base of Earth is in D-1 of the particle universe at accretion
       level 0 to 1.  
  •   The particle base of parallel Earth is in D-2 of the particle universe at
      accretion level 1 to 2.  
   •    The particle base of Agartha is half in D-1 and half in D-2 of the particle
       universe, at an accretion level of .5 to 1.5.  
 •    The elemental body of Earth is at particle universe D-2, accretion level 1
      to 2.  
 •    The elemental body of parallel Earth is at particle universe D-3, accretion
      level 2 to 3.  
•    The elemental body of Agartha is at particle universe half D -2—half D-3,
      accretion level 1.5 to 2.5.  
•   The mental body/atmosphere of Earth is at particle universe D-3, accre-
      tion level 2 to 3.  
•   The atmosphere of anti-particle Earth is at particle universe D-4, accre-
      tion level 3 to 4.  
•   The atmosphere of Agartha is at particle universe half D-3 —half D-4,
      accretion level 2.5 to 3.5.  
       From the perspective of the fourth dimension (where human conscious-
ness is presently stationed) the D-1 iron core crystal of anti-particle Earth,
(that is stationed within the overtone D-2 frequency bands of the particle
universe) and the D-1 iron core crystal of particle Earth, (that is stationed
within the D-1 frequency bands of the particle universe), perceptually merge
and appear as the Sun. The Sun appears to be separated by many miles from
Earth. From this perspective, what appears to be the physical body of Earth is
164 
 

                                                             
                                          Ascending and Descending Planets
actually the low to middle D-3 frequency fields, the slower-moving particles
of Earth’s “mental body.”  
      The atmosphere on and surrounding Earth is the middle- to upper-D-3
frequency fields. The “outer space" existing beyond Earth’s atmosphere repre-
sents a Repulsion Zone and the frequency fields of D-4 through 15 that exist
beyond this Repulsion Zone. From the fourth-dimensional perspective, there
appears to be a separation of many miles between Earth and the Sun because
the natural Repulsion Zone between D-3 and D-4 creates the illusion of
absence of light and expansion of space. This Repulsion Zone is created by
the 45° shift of angular rotation of particle spin that occurs between one Har-
monic Universe and the Harmonic Universe above. There are five primary
Repulsion Zones within the 15-dimensional universe, which create the illu-
sion of vast distances between star systems existing within the 15 dimensions.
    Though Earth, the planets and the galaxies appear to be separated in
space by great distances, that distance is only a natural holographic illusion
created by the refraction of energy waves through varying angular relation-
ships between spinning particles. All that you perceive outside of yourselves,
including Earth and what appears to lie beyond, in Earth’s immediate solar
system, actually exists at the center of Earth’s Sun, at varying rates of particle
pulsation and angular relationship of particle spin. Earth’s Sun is likewise
contained within a larger solar structure with other planetary bodies, which
would appear to exist outside of that Sun from various stations of perception.
The reality of the mechanics of energy is that dimensions 1 —3, and all things
contained within them, exist within the D-4 Merkaba Fields of Tara’s gold
core crystal and that core crystal is stationed at the center of the Sun. The
gold core crystal at the center of Earth’s Sun serves as an electromagnetic por-
tal structure between HU-1 and HU-2. Though the Universe appears spread
out over great distances, in reality it all exists within the same space, at vari-
ous dimensional frequency levels and particle spin relationships.  
    W e are telling you of these hidden reality mechanics so you may begin
to comprehend what will be taking place on Earth as your half-cycle period
approaches and the Bridge Zone Project goes into operation. We have said
that Earth’s accretion level will be shifted from its present 2.5 level to that of
3.5 accretion. The present 2.5-accretion level is the measurement of the fre-
quencies contained within Earth’s morphogenetic field. Accretion level 2.5 is
also the measurement of the beginning of Earth’s atmospheric body, the part
which is closest to Earth’s surface.  
    Earth’ s atmospheric body represents the portions of the D-3 Uni fied Field
that have not yet been pulled into Earth’s morphogenetic field, the particle
fields of D-3 that exist outside of Earth’s morphogenetic field and thus outside
of Earth’s physical body structure. Earth’s atmosphere is composed of the
upper frequency bands of D-3, which represent the 2.5 —3-accretion levels.
Earth’s atmosphere is thus said to be at 2.5 accretion.  
165  
                                                                                                                  
                                                                                                                                                                                                                          

      Time Shift  
At present, Earth’s D-2 elemental body is at 1.5 accretion and its D-1
particle base is at .5 accretion. Agartha’s atmosphere is at 3.5 accretion, its
elemental body at 2.5, thus Agartha’s elemental body is located within
Earth’s atmosphere at a different angular rotation of particle spin than that of
Earth’s particles, and so appears invisible. Agartha’s particle base is at 1.5
accretion, thus Agartha’s particle base is located within Earth’s elemental
body.  
    During the Bridge Zone transition, when Earth’ s atmosphere is shifted
from 2.5 accretion to 3.5 accretion, it will be merged with the atmosphere of
Agartha. Earth’s elemental body will shift from 1.5 accretion to 2.5 accre-
tion, Earth’s elemental kingdom will merge with that of Agartha. Earth's par-
ticle base will shift from .5 accretion to 1.5 accretion, Earth’s particle base
will merge with Agartha’s particle base. When Earth merges with Tara’s grid
in the D-4 time cycle between 2012 and 2017, the Earth’s morphogenetic
field temporarily reaches a height of accretion level 4, then returns to its nat-
ural 2.5-accretion level following 2017.  
    In the Bridge Zone Project, Earth’ s morphogenetic content will peak at
accretion level 4 when merging with Tara’s grid between 2012-2017, then
instead of returning to its natural 2.5-accretion level/D-3 time cycle after
2017, Earth will return to the 3.5-accretion level. The 3.5-accretion level
represents the time cycle between D-3 and D-4, in which Agartha’s reality
takes place.  
     In the usual process, Earth’s particles would undergo a 45° shift in angular
rotation of particle spin to enter the D-4 cycle, then shift back 45° to return
to the D-3 time cycle. In the Bridge Zone, Earth will undergo the 45° shift of
angular rotation of particle spin to merge with Tara. Instead of shifting back
45° to return to the D-3 time cycle, Earth’s particles will shift back only 22.5°,
placing Earth within the 3.5-accretion level, the time cycle between D-3 and
D-4, merging Earth and Agartha. Earth will become the Inner Earth, Agar-
tha, through the 2012-2017 transition.  
    Humans who have assembled all of the fourth DNA  strand and half of
the fifth will perceive this transition as the emergence of new lands and struc-
tures on Earth, and the literal disappearance of some of the existing Earth
structures. Humans who do not assemble these strands will perceive a differ-
ent reality entirely. During this transition, the particles of Earth that are
unable to fully shift into the faster pulsation rate, those that cannot reach an
accretion level of 3.5, will not make this shift into the Bridge Zone. The par-
ticles that do not shift will create a Phantom Earth  that will return to the D-
3 time cycle. The Phantom Earth will no longer remain attached to the mor-
phogenetic field of Earth and Tara. This condition is referred to as a planet
being “cut out of the grid.” The planet is no longer attached to the evolution-
ary imprint contained within its morphogenetic field. A phantom planet is
no longer capable of evolving out of the Harmonic Time cycle in which it is
166 

                                                                  Ascending and Descending Planets
placed, it is no longer considered an Ascension Planet, it is called a
Descending Planet.  Such a planet will continue to evolve within its Har-
monic Universe time cycles, slowly expending the energies held within its
core, until its particle pulsation rhythms slow, its temperatures cool and even-
tually it implodes to become a black hole. It can take billions of years for a
Descending Planet to meet this destination, this does not occur quickly, and
life can continue to evolve upon its surface for many years. In the case of
Earth’s coming changes, when the planet is shifted to the Bridge Zone, the
portions of Earth’s particles that do not make the shift will become a Phan-
tom Earth —a Descending Earth.   
      The phantom version of Earth will be cut off from the interdimensional
Time Matrix grid, and the Phantom Earth will return to the D-3 time cycle
following 2017. The entire Bridge Zone Project was designed to keep Earth’s
primary particle base out of that D-3 time cycle, because in that time contin-
uum the Dracos-Zeta Resistance successfully employs the Frequency Fence
and creates Earth’s destruction in 2976 AD. (This probable future for the D-3
time cycle can be averted if the Resistance-inspired 2003 experiment does
not take place.) In the Phantom Earth D-3 time cycle Earth changes occur,
which debilitate a portion of human civilization, and the Zeta-Dracos hybrids
come to “help put things back together”, while placing the remaining popula-
tions under covert mind control through the use of Frequency Fence and
Holographic Insert technology.  
    Humans who do not assemble DNA  strand 4 and half of strand 5 will find
themselves within this probability on the D-3 Phantom Earth. They will not
know they are being controlled, and they will not realize the Dracos-Zeta
Resistance manipulates and covertly directs world culture. They will not
realize they are not free. And the souls of D-3 phantom Earth will con-
sciously have no idea of the ultimate destiny of soul fragmentation toward
which they will be headed. Most souls caught in this D-3 incarnational cycle
in 2017 will have to continue reincarnating within the D-3 continuum, until
they slowly assemble the fourth and half of the fifth DNA strand, which will
be exceedingly difficult to do while under Frequency Fence control. Your
future incarnational selves will be those humans faced with the 2976 cata-
clysm. Through the Bridge Zone Project the severity of this future can be
lessened.          
     If  the Bridge Zone Project is successful, the D-4 time continuum, in which
the Zetas now have their strong hold, will become free from Dracos-Zeta con-
trol, so the 2976 AD explosion of Earth will be avoided for the D-3 Earth. The
Resistance will still attempt to in filtrate and control D-3 Earth, but their
chances of success will be greatly reduced after losing control of the D-4 con-
tinuum.  
    Humans remaining in the D-3 time cycle will not benefit from the genetic
acceleration opportunity that is open to Bridge Zone humans, as they will be
167 
                                                                                                                  
                                                                                                              
                                                                                        

Time Shift  
cut off from the Sphere of Amenti morphogenetic field, which will remain in
Earth’s core in the Bridge Zone. They will follow a different course of evolution
on Descending Earth. It is much more difficult for individual souls to ascend
from such a planet, as their personal connection to the Sphere of Amenti mor-
phogenetic field, which allows them direct access to their higher-dimensional
identity, also becomes severed.  
     The Bridge Zone Project is an absolute necessity to ensure the survival of
Earth, and it also allows humans the opportunity to evolve beyond the reaches
of Dracos-Zeta manipulation. If events unfold perfectly, all humans will shift to
the Bridge Zone in 2017, and thus no one will fall under Dracos-Zeta domin-
ion, but the chances of such high success are slim. It is presently essential that
a critical mass of humans reach a 4.5-accretion level before 2012.  
     If this does not occur, no one will make it to the Bridge Zone continuum,
the Halls of Amenti will not fully open and some degree of Earth changes will
take place between 2012-2017. Humans who are able to assemble the fifth
DNA strand can be rescued by guardian transports, but there will be little time
for such an evacuation, and the majority of the population could not withstand
transport travel to Agartha or Tara. If the Bridge Zone Project is not successful,
most of the human populations will be unable to escape Earth changes, covert
Dracos-Zeta rule and separation from their personal soul matrix. If the Bridge
Zone Project fails, Earth will meet its untimely demise in 2946 AD. Guardian
Host Matrix transplants would have to be used to shift Descending Planet souls
into Agartha before 2976 destruction. This would constitute another massive
Guardian rescue mission in the future, the prospects of which are not promis-
ing, if   humanity were under Resistance  Frequency  Fence control. The need for
this rescue will be removed if  present day humans can accept responsibility for
their personal evolution now, and assist the Guardians in making the Bridge
Zone Project a success.  
     Y our future is in your hands, and your races will live the consequences of
your collective choices. Each individual has the power and the responsibility
for choosing the path of personal destiny that will unfold. In choosing to
ignore the reality of Earth’s present multidimensional affairs, you will be sub-
jugating your personal power to those hidden forces that would be delighted
to control your destiny for you. If you are wise, you will not surrender your
evolutionary survival so easily. You have all the help you need to succeed, but
humanity must also do its part and become responsible for personal evolu-
tion. 
168  

                                                                         
         Three T racks of T ime
                                       THREE TRACKS OF TIME  
Humanity Facing Three Probable Futures and Three Tracks of Time
   The technical information we have provided on the mechanics of the
Bridge Zone Project serves to illustrate some of the operations of multidimen-
sional physics. We are quite aware that it will be centuries before earthly sci-
entific communities can comprehend some of the dynamics of which we
speak. We provided the information so those of scienti fic persuasion might
begin to realize the sophistication of true spiritual science, so they might be
less prone to dismiss the importance of the information we have given. We
suggest that one use the intuitive senses when trying to understand some of
the more complicated concepts we have presented, as the intuitions are bet-
ter equipped to translate this data into cognition, than are the facilities of the
logical-analytical mind alone. To simplify the meaning of the Bridge Zone
Project, it can be viewed as the vessel through which three probable future
paths of development open to the human population. Between the years
2012-20l7, there will be three distinct time continua into which the human
consciousness can pass to continue its evolutionary journey. These time con-
tinua represent three different tracks of time that different portions of
humanity will follow.  
1. Time Track One-—Voyagers Ascension—D-4 Time Cycle 5532.5-year
    Leap into the Future  
   The first track of time opening to the human population in 2012, and
the most desirable for those who can achieve it, constitutes catching the crest
of the morphogenetic wave between 2012-2017 and ascending into the D-5
time cycle of Tara (or into the higher-dimensional fields of Gaia and the
Meta-galactic Core.) We refer to the individuals who will complete bodily
ascension as the V oyagers. To become a V oyager one must fully assemble the
fifth DNA strand no later than 2022.  After 2022,  this first time track is no
longer an option. In this future one would expect to experience subtle com-
munications with a guardian group of either ET or metaterrestrial nature,
prior to the ascension period.  
  Through this communication one will be taught how to prepare for
their personal ascension, and will be given times and locations as to when
and where the physical event will take place. For individuals who are
ascending but cannot fully transmute the body to do so, preparation for
achieving ascension following natural death will be provided through subtle
communications and spiritual work. Most ascending individuals will be
required to engage in conscious cellular transmutation work, and will be
guided through personal spiritual work, to the appropriate methodology for
their personal development.  
       Individuals who will bodily ascend will at some point in their develop-
ment experience direct physical or conscious etheric contact with a Guardian
169 
                                                                                                                                                      
                                                                                                                           
                                                                                                                       
 

  Time Shift  
group. At the designated time, they will be secretly brought to the location
from which they will ascend. Some will be taken, via various portal routes,
into the Halls of Amenti. They will be led into the Halls and assisted in
transmuting their bodies into light (which constitutes raising the pulsation
rhythm of particles in the body and consciousness). As light, they will pass
their consciousness into the Sphere of Amenti and through the portals of the
Halls of Amenti, they will embody the frequencies of the Blue Flame Staff of
Amenti within their consciousness and morphogenetic field, and pass into
Tara. Once transferred to Tara, such individuals will then have the pulsation
rate of their consciousness slowed to D-5 frequency, and they will find them-
selves re-manifest in a less dense, more perfected version of their body. They
will appear in one of several receiving stations on Tara, set up for this pur-
pose, and will be met by greeters appointed by the Priests of Ur and Mu on
Tara. The greeters will escort them to one of several residential learning cen-
ters, appropriate to the personal level of development, and they will be pro-
vided with all necessities.  
    Couples or groups who ascend together will be able to remain together if
they so choose. For a time the V oyagers will be offered classes through which
they can acclimate to their new reality, and will then be offered communal
residence or will be hosted by private Taran families who will provide lodg-
ing, sustenance and love. Memory of multidimensional experience will be
fully returned, and the V oyagers will have the opportunity to commune with
soul friends and family whom they had forgotten in earthly life. V oyagers will
learn to integrate themselves as time travelers, into a culture that exists about
5532.5 years in the future of present day Earth. This culture is built upon the
principles of the Law of One, and love, brotherhood, freedom, health, spiri-
tual at-one-ment and joy are the foundations upon which this society is built.
It is well worth the V oyage for those who can achieve ascension.  
    Some who are on the ascension time track will not have the full fifth
strand of  DNA assembled but will be close to this 5-accretion level. They will
be unable to pass directly through the Halls of Amenti portals, so will instead
be guided to Transport locations on Earth where they will be brought upon
interdimensional transit craft and prepared for a journey into space.  
    Some of those on the transports will have their consciousness transferred
into a clone body of their original body form (these clones were prepared in
advance through guardian abduction/visitation encounters). The Guardians
use cloning only in cases of individuals who possess most of the necessary fifth
strand DNA assembly. Guardian cloning is used for individuals who would
have been able to ascend if they had not encountered genetic damage while on
Earth. Cloning is used for near-ascension—level individuals who experienced
irreparable genetic damage due to intruder ET manipulation, birth defects,
accidents or illness suffered on Earth.  
170 
   

                                                                                                                                       
                              Three Tracks of Time  
    Not all individuals taking the Transport ascension route will have their
consciousness transferred into a clone body. Most will simply have their bio-
energetic fields adjusted to facilitate rapid fifth DNA strand building. (Note:
clones created by the Guardian ET groups are expressly for the purpose of facil-
itating human ascensions. These are not to be confused with cloning tactics
used by intruder Dracos-Zeta forces for in filtration into human culture). V oy-
agers on the Transports will be taken into outer space, then through the D-4
Merkaba Field at the center of the Sun and into the Halls of Amenti at the D-
4 level (this is the same ascension path used by souls who die/drop their bodies
and ascend to Tara as soul essence. However, individuals on the Transports will
not be leaving a body behind). The Transport craft will emerge through the
core of Tara’s Sun in D-5, then proceed to landing facilities on Tara. Interdi-
mensional Transport vessels are designed for such solar passage, as they are able
to modulate frequency bands and alter the composition of their structure. Most
human V oyagers will experience a period of deep sleep then a bit of temporary
time disorientation as the Transports encounter the solar passages. Once they
land on Tara, the Transport V oyagers will experience the same orientation
events as those who ascended directly through the Halls of Amenti. All V oy-
agers will have a companion assigned to them following their arrival on Tara.
The companion will assist them in adjusting to the new reality, and will remain
with them until the V oyager has comfortably integrated into Taran culture.
    Some V oyagers, who have fully assembled the sixth DNA  strand and
have reached an accretion level of 6, will have the opportunity to ascend
beyond Tara in HU-2, to Gaia in HU-3 or into the Meta-galactic Core at D-8
and completely leave matter form, the dimensional system and Time Matrix.
This is the path of full mastery. Normally it is available to only the few who are
born into the highest resonating genetic codes. Due to Earth’s upcoming infu-
sion of fifth-dimensional frequency, in the Bridge Zone time track, the fifth
DNA strand assembly will be made available to everyone who works con-
sciously to assimilate the D-5 frequency into the body. Once the fifth DNA
strand is assembled, assembly of the sixth strand begins, and some individuals
will be able to fully assemble the sixth strand between 2012-2017, while the
Halls of Amenti and portals to Tara and Gaia are opened (Gaia’s portals open
for only three days in 2017). Guardians will be available to assist in all ascen-
sion procedures, those leading to Tara and beyond.  
    The V oyagers’  ascension to T ara will be done solely through private,
personal contact. There will be no mass landings of Guardian ships to pick
up intended V oyagers, there will be no public knowledge of the logistic
orchestration of these events. Individuals who are able to participate in this
activity will be contacted privately and secretly guided to the appropriate
location, just prior to leaving. Publicly conducting such activities would
serve only to cause major chaos within your social orders, not to mention
171 
                                                                                                      
                                                                                
                                                                                                                    
       

       Time Shift  
military interference, so ascensions will remain a closely guarded covert
guardian activity.  
       We present this material now to assist potential V oyagers in remembering
their soul agreements to participate in these activities. Those who are
intended to ascend can find this information through working directly with
their own spiritual identities. Even if you do not consciously remember such
soul agreements, you will feel a certain way about the ascension option when
confronted with this material. If the path of ascension is the right one for
you, you will sense this, and find your soul-self awareness guiding you to the
appropriate preparatory procedures. The ascension path is not something the
Guardians have made happen for you, it is the natural path of your personal
soul evolution. The Guardians do not control the ascension process-—they
simply facilitate humans and the souls and over-souls of humans who are
                  ready for this natural evolutionary step.  
                       2. Time Track Two—Phantom Earth Descending Planet—D-3 Time  
        Cycle Returning to the Present  
         The second track of time opening to the human population in 2017 is
that of the natural procession through the half-point, in which Earth returns
to the D-3 time cycle following 2017. If the Bridge Zone Project is successful,
the Earth that will return to the D-3 time cycle will be the “phantom Earth,”
the remaining particles of Earth’s body that were unable to transmute to
higher accretion levels. This is the least-favorable option available to
humanity, as this is the future in which humanity falls under the covert con-
trol of the Dracos-Zeta Resistance. Humans who will see this future after
2012 will be those who have not assembled their DNA to at least the fourth
strand by 2012.  
     On August 12th, 2003 the Dracos-Zeta Resistance plan to motivate cer-
tain factions of the Interior Government to orchestrate another experiment
similar to those of the Montauk Project of 1983 and the Philadelphia Experi-
ment of 1943. The Interior government will be led to believe this project is
for the bene fit of humankind, that it will stop Earth changes from occurring
in 2012.  
    T o those of the Interior Government who may be reading this material,
please heed this warning:  You are being tricked and used as pawns by the Dracos-
Zeta Resistance. They are planning to use you to orchestrate a covert take-
over, through which you, the populations and the Earth will be placed under
subliminal, bio-neurological Resistance control. If you allow this experiment
to take place, you will ensure that the populations remaining in the D-3 time
track will fall under Dracos-Zeta Resistance Frequency Fence and Holo-
graphic Insert control. You can stop them from putting the Frequency Fence
in place if you refuse to participate in this experiment. Stop “buying into the
lies” and false promises of the Dracos-Zeta Resistance. If not for the sake of
your planet or your people, then at least for the sake of your own personal
172 
  
 

                                                                                  
                                                                                 Three Tracks of Time
safety. Rethink your positions in relation to the Resistance and redirect your
course of action. There is still time left to shift the fate of the D-3 time con-
tinuum. If the Dracos-Zeta plan is not stopped in 2003, they will begin
broadcasting the EM pulses of the Frequency Fence in 2004 and beam in
Holographic Inserts by 2006. People who do not have a minimum of 3.75-
accretion level, (3.75-accretion level constitutes full assembly of the third
DNA strand and 75% of the fourth strand), will fall under the bio-neurologi-
cal block of the Frequency Fence and will become subliminally controlled
and directed by the Dracos-Zeta Resistance. This includes those of you in
the Interior Government who are foolish enough to believe these EBEs are
your allies. No one will know they are being controlled. Those under the
new Frequency Fence will become cut off from their personal intuitive senses
and organic connection to their soul matrix. They will be unable to further
assemble the DNA strands, and thus will not be able to participate in acceler-
ated evolution and the coming ascension opportunity. The EBEs will offer a
new belief system of a religious nature that will teach subservience to a higher
order of spiritual hierarchy, which will become the belief catalyst for the
“New World Order” of covert control and dominion foretold in your Biblical
stories.  
    When the phantom Earth enters the 2012-2017 period, there will be
geographical and climatic changes on Earth, the degree of which we cannot
fully foresee. The severity of such changes will depend completely upon how
the Earth’s grid reacts to the frequency disruptions of the Frequency Fence. It
is the Frequency Fence that will be primarily responsible for causing severe
Earth changes, so if the 2003 infiltration is stopped, the severity of potential
Earth changes between 2012-2017 can be signi ficantly reduced.  
    What do you think might happen to your nuclear weapons and reactors if
such Earth changes take place? It is time your governments began consider-
ing these issues. If these events go unchecked, and the Frequency Fence plan
is not diverted, it is presently estimated that about 40% of Earth’s surface will
be heavily affected by these changes, 15% of this 40% taking place within
the territories belonging to the USA. These estimates may change, depend-
ing up how this Earth drama unfolds between now and 2012. Needless to say,
the cultures of Earth’s D-3 time cycle would be adversely affected. The popu-
lations surviving such events would remain under covert Dracos-Zeta Resis-
tance control, unaware of the truth that had caused them such suffering. We
reiterate: These events can still be changed, before 2003, if the Interior Gov-
ernment changes its agreements with the Resistance forces.  
    There is a tentative plan by the Dracos-Zeta Resistance to stage a public
landing in 2001, after allowing bits of information concerning their presence
to reach the general public. They intend to send their Rutilia operatives
(Zeta-Dracos hybrids that resemble Zeta Greys, called EBEs by the covert
173 
                                                                                                                  
                                                                                                                 
                                                                                                            

Time Shift  
government) to members of the Interior Government, posing as emissaries.
They will offer technology and friendship.  
    Do not trust them . We implore the Interior Government on Earth to
refuse any and all dealings with these beings, for they are not your allies nor
friends. They are attempting to pull a covert “Trojan Horse” stunt on you.
This can succeed only if you “open the gates,” enter agreements with them
and allow them to convince you to orchestrate experiments, the conse-
quences of which you do not understand. The Bridge Zone Project will
remain operable regardless of the choices of the Interior Government.
Humans are advised to begin working with the higher-chakra centers to
accelerate the assembly and alignment of the third and fourth DNA strands
before 2004. If the Resistance is successful in orchestrating the Frequency
Fence in 2004, humans whose DNA has not reached the 3.75-accretion level
will be susceptible to the perceptual distortions caused by the Frequency
Fence. You can all learn to protect yourselves from this manipulation if you
take responsibility for working with your bio-energetic system to accelerate
DNA assembly.  
    Reach for spiritual integration with your soul identity while it is easy to
do so, for if you begin this integration process now (by assembling DNA
strands 3 and 4), it will completely protect you from the Frequency Fence.
   If you fall under Dracos-Zeta control, you will continue to evolve as
souls upon a Descending Planet. You will not consciously realize that you are
being controlled and subliminally manipulated. Experientially those who are
under Frequency Fence control will be unable to perceive the effects of the
multidimensional changes taking place between 2012-2017.  
    If the Earth changes meet or exceed the damage we have estimated,
human culture will be dealt a severe blow and your social, political and eco-
nomic structures will be unable to easily recuperate from these events. If we
are successful in convincing the Interior Government to stop negotiations
with the Dracos-Zeta Resistance and the experiment of 2003 does not take
place, a different reality picture will be perceived by those remaining in the
D-3 time cycle. Localized grid imbalances will most likely still occur, and cli-
matic deviations will continue to accelerate until 2017. Your primary social
structures will remain intact, but national disaster relief funds and insurance
organizations may collapse due to an overabundance of claims and needed
expenditure. If the Resistance is unable to employ the Frequency Fence by
2004, which they cannot do if the 2003 experiment does not take place, they
will have little recourse. As long as the Interior Government refuses dealings
with the Resistance, the Resistance will be unable to orchestrate a full infil-
tration into human society.  
    Once the Earth grid passes through 2017 without the complications of
the Frequency Fence, and the primary vulnerability of the portal structure
ebbs, Guardian Visitors will be able to enforce a ban on Dracos-Zeta presence
174 

                                                                                    Three Tracks of Time
and these intruders will leave. Your government systems will still evolve
under the inﬂuence of the human Interior Government. Guardian Visitors
will again attempt to make contact with this covert organization, in order to
establish public contact procedures through which human social conscience
and order can be redirected toward peaceful evolution. Humans remaining
in the D-3 time track will still find themselves evolving on a Descending
Planet and the opportunity to rapidly evolve the fifth DNA strand will have
passed, as the phantom Earth will not receive the full infusion of D-5 fre-
quency.  
    Y ou will reincarnate on this Descending Planet until you can assemble
the third through fifth DNA strands, which is a slow process that takes
numerous lifetimes, except during the acceleration opportunity presented in
the ascension cycle. If you die after  2022  without the D-4 and D-5 frequency
patterns assembled in your personal morphogenetic field, reincarnation in
HU-1 will be mandatory. This is simply the nature of the energy dynamics
involved in soul evolution. While evolving on a Descending Planet it is very
important for individuals to have conscious knowledge of ascension mechan-
ics, for the opportunity of spontaneous mass ascension is no longer an option.
Guardian Visitors will assist in keeping this knowledge alive and available to
humans remaining on phantom Earth in the D-3 time cycle. We pray that
each individual can be reached with this message, so the opportunity of
ascension and freedom is not lost to your present identity. If the 2003 experi-
ment and the Dracos-Zeta Frequency Fence can be averted, those in the D-3
time cycle will follow a different path of evolution than humans in the Bridge
Zone and ascension time cycles. They will have the opportunity to evolve
more slowly, yet still have the option of free will and more open contact with
guardian races. The severity of Earth changes during the 2012 —2017 transi-
tions will be greatly reduced.  
    If the Dracos-Zeta Resistance is successful in 2003, life in D-3 will con-
tinue under their covert dominion and Earth changes will take place between
2012 —2017. Once D-3 Earth is under Resistance Frequency Fence control,
the Dracos-Zeta Resistance will be motivated to protect their “vested inter-
ests” on Earth from guardian tampering. If the Resistance gains leverage and
confidence through successfully orchestrating the Frequency Fence, it will be
very difficult for the Guardians to enforce a ban on them without direct mili-
tary confrontation. Such a “Star Wars” confrontation between Resistance
and guardian forces would have further catastrophic consequences for D-3
Earth, and it has not been decided by the guardian legions whether such
intervention would be conducted.  
    The Guardians are taking a “let's wait and see what happens” approach to
this subject. The Guardians can only protect humanity from the conse-
quences of its choices for so long, after which point full responsibility for per-
sonal evolution must be returned to the human race. The opportunity to
175 
                                                                                                                           
                                                                                                                      
          

  Time Shift  
create self-protection is now being offered through the Guardians’ attempts
to educate humanity. If this opportunity is ignored, the humans remaining in
the D-3 time cycle will have to accept responsibility for their selected igno-
rance and face the consequences of covert Dracos-Zeta rule. Further guardian
intervention would only be considered if the D-3 populations made a show of
effort to take responsibility and make the needed changes prior to 2017. The
Guardians are willing to help those who are willing to help themselves, but
have little patience left for those who refuse to learn, grow and become
responsible for their choices. If the Bridge Zone Project is not successful,
Earth will remain in HU-1 under Dracos-Zeta rule, and your incarnational
destiny on HU-1 Earth will meet a premature end in 2976 AD. The majority
of the human population can avoid these less favorable futures by seizing the
opportunity of accelerated evolution represented by the Bridge Zone Project.
3. Time T rack Three—the Bridge Zone—D-3.5 Time Cycle 2213-year
     Leap into the Future  
     The third time track available to humanity in 2017 is that leading into
the Bridge Zone. Individuals having a 4.5-accretion level/assembly of the full
fourth DNA strand and half of the fifth will enter the Bridge Zone time contin-
uum. We need a critical mass of people to reach 4.5 accretion before 2012 in
order for the Earth’s grid to raise high enough in speed to enter the Bridge Zone
in 2012. The accretion level of Earth is being continually measured and moni-
tored, and as of this writing (August 1998) things look quite promising. Recent
events involving the Sphere of Amenti have given us much encouragement for
the success of the Bridge Zone Project, and we are still on schedule for the
opening of the Halls of Amenti in 20I2. The transition of Earth moving into
the Bridge Zone began in 1997 as we infused Earth’s grid with UHF energy to
assist in raising the particle pulsation rate of  Earth’s core. The speed of Earth’s
core particles will be progressively raised between now and 2012.  
    As Earth progressively moves closer to 2012, a subtle division will begin
to appear within the populations of Earth. Those with higher accretion rates
will progressively find themselves surrounded by others of similar accretion
levels, and those with low accretion rates will likewise group. You will see a
more apparent division between what you consider the “light and dark
forces” moving within your populations. You may see extremes of this condi-
tion, especially in geological areas in proximity to the seven major Earth vor-
 tices/chakras (we will discuss the V ortices in following pages).    
         Small-scale wars may break out in some areas, motivated covertly by vis-
iting members of the Ancient Anunnaki Resistance, who entered orbit
around Earth in D-4 in 1997, with the intention of amplifying the potentials
of Earth changes to see the downfall of human culture. The Anunnaki Resis-
tance will not directly intervene, nor do they work with the Dracos-Zeta
Resistance, they are simply here to see Earth purged of what they consider
176 
 

                                                                               
                                                                                  Three Tracks of Time
the “cosmic virus” of the human race. They will motivate conﬂict and per-
sonal and collective strife by attempting to manipulate people from the D-4
astral plane. Their purpose is to increase grid instability, as they know this
will amplify any Earth changes that may occur. They are not as highly moti-
vated as the Dracos-Zeta Resistance, and will not attempt direct interference
in Earth affairs, so as to avoid direct con ﬂict with the Sirian Council, their
Council Loyalist Anunnaki Brothers and the other Guardian groups from
HU-2 and HU-3. They are simply game players who will try to tip the bal-
ances of the unfolding Earth drama in the favor of human extinction.  
    The only people who will be susceptible to Anunnaki Resistance
manipulation will be those who have low accretion levels and who have not
learned to put protective energetic barriers around the astral identity. Any-
one working consciously and sincerely to integrate the soul identity will have
protection from Anunnaki Resistance manipulation. Humans with high
accretion levels will be called upon to assist the guardian races in building a
frequency block in D-4 to protect Earth's major portals/vortices from Anun-
naki Resistance energy transmissions. Guardians from the Andromeda galaxy
presently have Earth’s vortices sealed under a protective D-4 frequency seal,
but in the event that the Anunnaki Resistance manage to decode the fre-
quency seal co-ordinates (which they occasionally do, requiring repeated
guardian resealing of the vortices), the Andromies will need human help to
ground a more sophisticated vortex frequency seal. Human Light-workers
involved with the “Portal Project” are presently on stand-by, waiting for the
time when they will be called into service. Human Light-workers will also
assist in keeping the portal regions balanced on Earth between 2012 —2022.                                                    
                                                ET Inﬂuences 
    Presently the human collective moves together toward the three diver-
gent tracks of time. By 2012 the divisions within the populations will be set,
as the three groups, with three different accretion levels, begin to move into
their appropriate track of time. Those on the ascension track will have
already made preparations in their DNA and have a more conscious under-
standing of the process with which they are involved. Those on the
Descending Planet time track will proceed with “business as usual”, unaware
of the changes taking place around them. If the Dracos-Zeta Frequency
Fence is successful, the “peripheral blindness” of those on the Descending
Planet track will be amplified.  
    There may exaggerated movements from within the Interior Govern-
ment to ban, discredit, confuse and black out from public view, information
pertaining to ascension mechanics, advanced multidimensional technologies
and the truth of Visitor agendas. These tactics are already being used to keep
the general populations unaware of what is taking place regarding ET and
metaterrestrial contact. You will see counter-movements emerging through
177 
                                                                                                                  
                                                                                                        
           
                                                                               

  Time Shift  
which genuine information is made available to those who will listen. Many
of the traditional religious organizations will be used as dis-information vehi-
cles, through which the public is taught to view the new information as
“evil.” This tactic is orchestrated through Zeta-human in filtrates presently
working within various organizations. You will see many distraction tactics
emerging, through which public attention is purposely and covertly directed
away from the issues of spiritual development and into fear-base, conflict-
laden agendas. The threats of economic disaster, war and famine, as well as
menial issues will all be used, through covertly manipulated media propa-
ganda, to divert public attention away from the real issues taking place. The
Zetas are expert propagandists, and subliminal manipulators, and are quite
accustomed to subliminally in ﬂuencing the unsuspecting minds of humans in
key positions to carry out their bidding.  
    The propaganda program, which has convinced the majorities that ET
presence is not real, has been in effect since the 1940’s, and you will see a con-
tinuation and acceleration of this propaganda until about 2001, when the
program will be changed to begin preparing the public for intended EBE con-
tact. When information about the possible validity of ET presence begins to
make it into public view, the Dracos-Zeta Resistance will present themselves
as Guardians and attempt to make guardian groups appear as intruders. The
Resistance may orchestrate a mass landing in 2001, but only if they are confi-
dent that they will succeed in motivating human Interior Government to
conduct the 2003 experiment. If by 2001, the Resistance fears their Fre-
quency Fence plan will not succeed, they will not stage a landing. They will
still work to instigate the 2003 experiment, and may increase their abduc-
tions within the general populace, making it appear as though guardian
groups are responsible, in order to trick the Interior Government to continue
with the 2003 experiment. The shift in the perspective of the propaganda
program will take place between 2001-2003, if it takes place at all.  
    If news validating the reality of visiting ET presence reaches public dis-
tribution networks by 2001 you can be sure the Dracos-Zeta Frequency Fence
plan is still in operation and that the Interior Government continues to work
with the Resistance. If a mass level, public landing takes place any time
between 2001 —2003, realize these are not friendly Visitors regardless of what
they may claim.  
    In the event that the Frequency Fence plan remains operational and
the Resistance schedules its mass landing, several guardian ET groups may
create mass sightings, to increase public awareness of the reality of ET pres-
ence. They will not conduct a mass landing or initiate physical contact on a
public or governmental level. If Guardians deem such “ ﬂy-by” tactics neces-
sary, these events may take place anywhere between 2000 —2003. The pur-
pose of such an event will be to warn humans who are aware of these hidden
agendas that the Resistance still plans in filtration. If the guardian “ ﬂy-by’s”
178 
 

                                                                                       
                                                                                    Three Tracks of Time
occur, this is intended as a sign for the populations to begin preparation for
Earth changes, because if the Frequency Fence is employed, some degree of
tectonic shifting will result.  
                                                    Be aware!  
    If you begin to experience mass “ ﬂy-by’s” between 2000 —2003, you need
to make provisions for coming climatic and Earth changes. In this event the
Guardians will provide information on “safe space” locations through their
private human contacts. If the Resistance believes its in filtration plan will not succeed, they will
not land between 2001 —2003, and the Guardians will not conduct mass “ ﬂy
by’s.” The old propaganda program of  blocking public awareness of ET pres-
ence will resume and the Interior Government will continue to distract pub-
lic attention from this issue so as to retain control of the populations. If the
2003 experiment is stopped (the Resistance needs the cooperation of the
Interior Government for this experiment to be successful) there will still be
three tracks of time facing the human populace.  
    In the D-3 time cycle Descending Planet track, the Dracos-Resistance
will leave of their own accord, knowing they cannot claim dominion over
human populations and that after 2017 Guardians can enforce a ban on Dra-
cos-Zeta presence. If the Earth’s grid is balanced in 2012, the Dracos-Zeta
Resistance and the Anunnaki Resistance will leave. Earth’s populations can
then focus upon the primary issues at hand, assisting the Guardians to keep
Earth’s grid balanced and accelerating personal evolution in preparation for
the opening of the Halls of Amenti between 2012 —2022.  
    If  92% of Earth’ s populations could reach a 4.5-accretion level by 2012,
no one would take the second track of time back into the D-3 time cycle of
the Descending Earth. This is not likely, however, so as it stands some of the
Earth’s populations will indeed return to the D-3 continuum. These are the
only individuals susceptible to the Dracos-Zeta Frequency Fence, and we
hope that the Interior Government will stop the 2003 experiment so these
individuals do not have to contend with the Frequency Fence and resulting
changes of the D-3 Earth. If humans begin working now to consciously
assemble DNA and increase accretion level, there is still time to become
immune to that intended Frequency Fence and prepare to leave the D-3 con-
tinuum. If you can achieve a 4.5-accretion level by 2012 you will automati-
cally end up in the Bridge Zone continuum in 2017. As long as 8% of Earth’s
populations reach a 5-accretion level, 144,000 people reach a 6-accretion
level, and about 40% reach a 4.5 level, the Bridge Zone Project will be suc-
cesfully.  
    In approaching the Bridge Zone time track, humans will perceive a
growing gap between the populations following old, fear-based agendas and
those following the path of personal enlightenment between 1998-2012.
Those on the Bridge Zone path will begin to bond together in a global net-
179 
                                                                                                                
                                                                                                         
                                                                                                                    

Time Shift  
work of enlightenment, doing personal and planetary energy healing work
and preparation for Stellar Activations. The schedule of events leading up to
the opening of the Halls of Amenti will continue to unfold up to 2012, when
Earth’s grid begins to merge with Tara’s and the Halls of Amenti begin to
open.  
      As this schedule of events proceeds, the population divisions will begin
to fall out of range of each other’s perceptions. Those headed to the Bridge
Zone will experience progressively more awareness of multidimensional real-
ity, personal purpose and incarnational memory, as the Sphere of Amenti
progressively releases more of the race memory back into the Earth’s grid.
That multidimensional memory will be available to everyone, those who will
access this memory will be people who have the genetic ability to pull higher
frequency into their operational genetic codes. The more DNA you assemble,
the higher your accretion level, the more information and memory you will
be able to draw from the Earth’s grid. The consciousness of the accelerating
individuals will rapidly expand, while the awareness of the people entering
the Descending Planet will remain about the same.  
      Between 1998 and 2012, these two groups of people will progressively
become more “invisible” to each other, as the procession of their lives moves
in opposite directions. There will appear to be natural sequences of events
that occur as individuals of lower accretion begin to move out of the lives of
those of higher accretion levels, to be replaced by new individuals who have
a higher accretion level. Those of lower accretion levels will find themselves
more and more in like company.  
      The progressive separation of populations will take place as the particles
which compose the bodies and consciousness of people with higher accre-
tion/DNA strand assembly levels begin to pulsate at progressively faster
rhythms, moving people of higher and lower accretion levels farther and far-
ther out of each others perceptual range. During the coming transitions, par-
ticle fields are separating. The bodies and consciousness of people are made of
particles, thus humanity will also experience separation of its peoples into
those with faster and slower-particle pulsation rhythms.  
     All humans will experience Earth’s temporary shift into the D-4 time
cycle and the Stellar Activations that create this shift. Humans with lower
accretion levels will have difficulty assimilating the frequencies of the Stellar
Activations. The Stellar Activations will create time acceleration for the
people of Earth. This acceleration can be used to advance the evolutionary
blueprint through consciously assimilating these energies into the body, in
order to create greater health, vitality, harmony and awareness. If the new
frequencies are not assimilated into the body, the time acceleration will apply
to the degeneration of the body and consciousness and the manifestation of
disharmony and disease.  
180 
 

                                                                            
                                                                                  Three Tracks of Time
     The Bridge Zone populations will accelerate their ability to access
guardian information, and some will become involved in subtle communica-
tion with Guardian groups. In 2012, when the more intensive changes begin,
localized climatic deviations and smaller Earth changes may arise, and the
Bridge Zone people will pull together to help each other through these
changes. Between 2009 —20l7 those in the Bridge Zone will begin to see cer-
tain public organizations, businesses and institutions either reach their natu-
ral ends or begin to take their operations in a more enlightened direction.
Those on the Descending Planet will not perceive these changes. Some of
the Bridge Zone people will become aware that the Inner Earth portals have
opened and will have invitation to explore those realms. Some of the struc-
tures of the Inner Earth geography will begin to emerge on the Bridge Zone
Earth, new islands will be discovered on Earth during this transition period,
and new organizations of spiritual and social order will begin to emerge.
Some groups of individuals will have open contact with various guardian ET
and metaterrestrial Visitors. The particle base of both the Descending Earth
and the Bridge Zone Earth will enter the D-4 time cycle between 20l2 —2017.
The infusions of D-5 through D-9 energy will enter the grid of Bridge Zone
Earth, and the spontaneous assembly of the fifth DNA strand imprint will
begin within the populations whose accretion level at 2012 placed them in
the pulsation rhythms of the Bridge Zone time track. The two Earth’s will co-
exist simultaneously within the D-4 time cycle between 2012 and 2017 and
each of the two groups of people will simultaneously perceive two different
sets of events.  
      In order to comprehend the nature of these changes, one must realize
that the energy dynamics taking place involve Earth’s particle base being sepa-
rated into two different rhythms of particle pulsation, and the particle sub-
stance out of which human bodies and consciousness are composed will also
experience such a separation.    
      In 2017 human populations will completely separate into two groups,
each perceiving a different set of events. These events will take place in two
separate fields of particle pulsation rhythm. It will be as if part of the popula-
tion “switched the channel on the television set of manifest events,” one
group remains watching the old channel, and the other group switches the
channel of perception to a new station.   
          The particle pulsation rhythm of the entire Earth will temporarily be
raised to the rhythm of D-4 frequencies between 5/5/2000 and 1/2012. The
Guardians will infuse Earth’s particle base with UHF D-4 energy transmis-
sions until 5/5/2000. The portion of Earth’s particle base that can hold this
frequency pattern will increase to a higher D-4 pulsation rate and begin the
Stellar Activation cycle, while the portions of Earth’s particle base that can-
not hold this frequency will remain at the lower D-4 rate of pulsation.
181 
                                                                                                                                                                                                                  
                                                                                               

Time Shift  
    In the Bridge Zone particle base, the angular rotation of particle spin will
be altered by the Guardians, in order for it to be transferred into the pulsation
rhythms of the Bridge Zone-Agartha time continuum in 2017. The angular
rotation of particle spin of Earth’s higher vibrating particle base will be
shifted 22.5° in reverse from the angle of particle rotation of Earth's lower
vibrating particle base. This separation of particle pulsation rhythms will
reach completion in 2017, just when Earth’s grid is in full alignment with
that of Tara and the Holographic Beam passes through the Photon Belt into
direct alignment with Earth’s seventh vortex/chakra. As the energies of the
Holographic Beam pass into the Earth’s bio-energetic field in 2017, the
higher and lower vibrating particle bases of Earth will completely separate.
The lower vibrating particle base will rapidly drop in vibration and return to
the pulsation rhythm of the D-3 time continuum. The higher vibrating par-
ticle base will complete its 22.5° reverse shift in angular rotation of particle
spin and fix its pulsation rhythm at the 3.5-accretion level of the Bridge
Zone-Agartha time continuum.  
    When this separation transition completes in 2017, the populations will
find themselves permanently divided into two separate groups.  
                                   
                                               Perceptual Stations 
1.  Group One — Descending Planet Perceptual Station  
     Humans with lower accretion levels will perceive none of the multidi-
mensional activity that is taking place. As long as the Frequency Fence is
not operational, they will not experience massive Earth changes, but some
localized shifting may occur. They will experience a three-day period of ten-
sion, fatigue and accelerated atmospheric pressure and a temporary disruption
of the function of electrical apparatus at the height of the separation from
Earth’s higher vibrating grid in  2017. Scientists may detect odd variations in
Earth’s magnetic fields and a sudden, unexplainable increase in gamma ray
activity. Solar storms and ﬂare activity will appear to increase for several
months, then rapidly return to normal appearance. At the height of the sepa-
ration, a phenomenon that resembles a prolonged, spontaneous solar eclipse
may occur, depending upon the stability of Earth’s bio-energetic grid.  
    The most notable occurrence will be that numerous groups of people will
seem to have vanished from the Earth without a trace. There will be no
explanation for these vanishings in conventional terms. For Earth in the D-3
continuum, little will have appeared to change, and populations will move
forth into their D-3 evolution. The Halls of Amenti will be closed to them,
as will the portals to the Inner Earth. They will experience massive Earth
changes only in the event that the Frequency Fence is operational.  
    In either case, Guardians will assist in realigning the planetary grids and
returning Earth to stability. In the event that the Frequency Fence is opera-
tional, the D-3 populations will be totally unaware of the changes taking
182 
  
 

                                                                                 
                                                                                     Three Tracks of Time
place, including the vanishings, as Holographic Inserts will be used to block
perception of these events. Only the Earth changes would be apparent to the
D-3 populations. Descending Planet populations will remain in the D-3 time
continuum and the opportunity for mass ascension will no longer be possible
in the future. Ascension of individuals will have to be orchestrated through
Host Matrix Transplants. If the Frequency Fence becomes operational in
2004, they will see Earth changes and will be under covert Dracos-Zeta Resis-
tance mind control. If not, they will slowly evolve and reincarnate toward
building the fourth and fifth DNA strands through Host Matrix assistance.  
2.  Group Two — Bridge Zone Perceptual Station  
    The populations who shift into the Bridge Zone will experience more
obvious phenomena of change as the two particle bases of Earth complete
their 2017 separation. Many structures of inorganic substance, composed of
lower-vibrating particles, will simply appear to vanish, as well as populations
having lower accretion levels. New island land masses will have appeared to
emerge out of the oceans, seemingly over night. New passageways into the
Earth will be found that lead into the Inner Earth territories. The most amaz-
ing phenomenon to manifest in the Bridge Zone will be the sudden appear-
ance of buildings, roads and other structures of civilization that one did not
remember having existed prior to this shift.  
    Earth’ s Bridge Zone populations will find themselves in old familiar terri-
tories having the new twist of people, organizations, landscapes and social
structures that resemble what was, but which are operating at a higher level
of vibration/pulsation and enlightenment. In 2017, portions of the Inner
Earth, Agartha civilizations will suddenly be visible, and it will seem as if
they had always been there. This may create a bit of temporary time-space
and memory disorientation to the populations of the Bridge Zone. During
the height of the separation in 2017, the Bridge Zone populations will also
experience a three-day period of tension and sensation of atmospheric pres-
sure, and they may perceive the appearance of very bright moon halos or two
moons in the sky during this three-day period. For this reason we refer to the
Bridge Zone time continuum as The Path of the Night of the Two Moons . If
you perceive these lunar effects in 2017, you will know you have entered the
Bridge Zone time continuum.  
    In the Bridge Zone, more open relations with Guardian V isitors will
begin, and humanity will continue to evolve along a more enlightened,
accelerated path. New fuel sources, such as photonic energy containment,
will be discovered as well as many new technologies based upon light, sound
and Keylontic science. As the Bridge Zone Earth will receive the infusion of
D-5 through D-9 energy during the 2012 —20l7 period, the populations will
have the opportunity to assemble the fifth DNA strand to become V oyagers
and enter the path of time travel/ascension to Tara. Some will also have the
opportunity to assemble DNA beyond the fifth strand and enter the acceler-    
183                                                                                                                        
                                                                                                                  
                                                                                                           

Time Shift  
ated path of mastery to ascend to Gaia or the Meta-Galactic Core. Bridge
Zone populations will be completely free from intruding ET Visitor manipu-
lation. Perceptually the sensation of lightness, or less weight, will be felt in
the atmosphere and within the body and a greater feeling of peace, optimism
and personal vibrancy will be experienced. Higher chakra centers in the
human bio-energetic system will come into activation and the conscious
integration of soul awareness will accelerate.  
    W e have undertaken great labors to provide you with this detailed and
often complex information concerning the changes your race will soon
encounter. We wanted you to be prepared. We wanted you to know what is
going on so you can begin to make good, conscious choices now, to ensure
your highest evolutionary potential.  
    Knowledge is power; thus we have given the gift of power to those who
care enough to use this gift wisely.  
    Now that we have provided you with the basic foundations of knowl-
edge concerning the coming changes Earth and the human populations will
face, our primary interest is to prepare you for the opportunity of the opening
of the Halls of Amenti. We will give you an idea of what to expect and
when, and how each of you can best prepare for the future you prefer to expe-
rience. As previously mentioned, there is a schedule of events that the
Guardians have to follow to ensure the opening of the Halls of Amenti. Tim-
ing of these events is crucial to the success of Amenti opening and so far
everything is right on schedule.  
      
  
184 

                                  
                                                        10  
                                                                                  
   
                                                         
               
      Opening the  Halls of Amenti    
                                                         CONTEXT  
      If you will recall from our discussions in earlier chapters, from 1972 for-
ward the Guardians had quite a few things to accomplish before the Halls of
Amenti could open between 2012 —2017. The Earth’s grid speed had to be
raised high enough by 10/1986 to spark open the first seal on the Arc of the
Covenant, so the Sphere of Amenti would descend and be in position within
Earth’s core no later than 1/1/1988. Between 1/1/1988 and 6/30/1998 the
Sphere of Amenti would transmit its D-1, D-2 and D-3 frequencies into
Earth’s grid, so by 6/30/1998 Earth’s grid speed would rise high enough to
spark the second seal on the Arc of the Covenant. Earth could then begin
ascent into the pulsation rhythms of the D-4 time cycle.  
    If all went well, on 1/1/2000 the Sphere of Amenti would begin transmit-
ting D-4 frequency through Earth’s core and the fourth DNA strand imprint
would soon become available to the populations who had a fully assembled
third strand, into which the fourth strand could be plugged. The Blue Flame of
Amenti would begin its 12-year descent to Earth between 1/1/2000 and 5/5/2012.
On 5/5/2012  Earth would begin its intersection with T ara’ s grid, the Blue
Flame would embody within the Keepers of the Blue Flame and the masses
who had assembled the fourth DNA strand would rapidly assemble the fifth
strand for ascension to Tara.  
    The Halls of Amenti ascension portals would open on 5/5/2012 and close
by 1/1/2022. Between 5/5/2017-6/30/2017, the Holographic Beam from D-8
would send a burst of D-7 through D-9 frequency into Earth’s grid. This D-7 -
D-9 frequency infusion would finalize the separation of the Bridge Zone and
Descending Earth time continua, then each version of Earth would move for-
ward in its respective track of time. The Guardians would have 10 years,
between 2012 —2022, to ascend as many people as possible through the Halls of
Amenti to Tara in HU-2 and three days for ascension to Gaia in the HU-3 time
cycles, in 2017.  
185 
                                                                                                                
                                                                                                              


Opening the Halls of Amenti  
     Along with these events, a series of monumental occurrences were also
to take place, as Earth entered the final phases of its ascension cycle. From
1988 through 2017 the natural seals of Earth’s seven primary vortices/chakras
would systematically open, as six Stellar Spirals progressively came into
alignment with Earth’s Merkaba Fields. On 1/1/2000 Earth’s energetic fields
would strike an interdimensional Resonant Tone, beginning the cycle of
Earth's Stellar Activations. The Guardians were to call a global gathering of
Light Workers on this day, for a celebration of the Day Of Transcendence,  to
assist Earth in holding the interdimensional Resonant Tone so planetary
ascension into the D-4 time cycle could begin.  
     Earth would then experience six Stellar Activations and six Stellar W ave
Infusions between 5/5/2000 and 2017, through which the particle conversion
process of the morphogenetic wave would take place. Between 1992-5/5/
2012, six silent avatars would birth on Earth, to purge genetic mutations and
realign the imprints of DNA strands 2-7 with the 12-strand DNA imprint
within the Sphere of Amenti race morphogenetic field. Between 1999 and
2017, 150,000 lndigo Children would birth on Earth through parents with
Palaidorian Birthing Contract soul agreements, to carry the activated sixth
DNA strand imprint. Keepers of the Blue Flame and Keepers of the Violet
Flame would receive their “wake up call” and progressively undergo six Star
Crystal Stellar Activations and Wave Infusions, activating DNA strands 5-9,
between 6/1996 and 2017.  
     Following their six Stellar Activations, the Keepers of T ara's Blue Flame
morphogenetic field would embody the Blue Flame on 5/5/2012, and begin
initiating Stellar Activations in others who hoped to ascend through the
Halls of Amenti to Tara or Gaia. The Keepers of Gaia’s Violet Flame mor-
phogenetic field would embody the Violet Flame on 1/1/2017 and begin
ascending people to Gaia during a 3-day period in 2017. The seven planetary
dimensional Merkaba Fields between Earth in HU-1, Tara in HU-2 and Gaia
in HU-3 would progressively open to each other as Earth, Tara and Gaia
aligned with the Holographic Beam for three days in 2017. This would per-
mit full ascension through the Halls of Amenti and the Blue and Violet
Flames, into the Meta-galactic Core at D-8, for those who had fully assem-
bled the sixth DNA strand.           
     On 9/17/2001, the Hall of Records in Giza, Egypt, would begin opening.
On 5/5/2012, the Flame Holders would activate the Hall of Records, and on
12/21/2012 the Hall of Records would begin transmitting data through
Earth’s grid, making interdimensional memory available to Earth's popula-
tions. Throughout this multi-faceted sequence of events, the grids of Earth,
Tara and Gaia had to be kept in balance and various segments of the popula-
tion had to be guided to their appropriate ascension paths, while Guardians
continued to monitor, side step and undo manipulation tactics of the Dracos-
Zeta Resistance and D-4 Anunnaki instigators.  
186 

                                                                         
                                                                                     
                                  1 0 / 1 9 8 6  t h r o u g h  6 / 1 9 9 8
After 2022, the evolutionary path for Earth’s populations would be set,
the two versions of Earth would progress forward in their respective time
cycles, and the three divisions of Earth’s populations would embark upon
                            their chosen paths of future evolution.    
   Before all of the above events could occur the Guardians had to re-align
the solar Merkaba Fields so the 11:11/12:12 Frequency Fence could come
down. Once this occurred, the arti ficial D-4 “Christ Consciousness” grid
could resume transmitting D-4 frequency into Earth core to progressively
accelerate grid speed and realign the fourth V ortex/Giza pyramid with the
Alcyone spiral, so the Holographic Beam could intersect with Earth at the
proper angle in 2017. At times, we of the Guardian Alliance shake our heads
and chuckle when we hear humans lament that “the Guardians must not be
real, or if they are real, they are uncaring, because they are not doing any-
thing to help us with the Intruder problem.” Perhaps now you can understand
what we have been doing to help you behind the scenes, and that this workload does
not allow an excessive amount of resources to be placed upon concerns of social pro-
tocol.  
    W e will now provide an overview of the status of your ascension schedule.
                                           10/1986 THROUGH 6/1998                      
                          The Opening of Amenti — Schedule of Events  
                            What has transpired between 10/1986 and 6/1998?  
   1.   October 1986: The Arc Of The Covenant First Seal Opened. The
     Sphere Of Amenti Began Descent To Earth. The 9540 BC Quarantine
      Frequency Fence Began T o Lift.  The Earth’s grid speed raised high
       enough to spark open the first seal on the Arc of the Covenant and the
       Sphere of Amenti began its 14-month descent into the Earth's D-2 core.
      With the release of the first Arc of the Covenant Seal, the Quarantine
         Frequency Fence from 9540 BC began to disengage. Some of the third
      DNA strand mutations caused by this Seal began to heal, allowing the veil
     between the ego and the higher self identity aspects to begin dissolving.
  2.    August 16, 1987: The Harmonic Convergence. Permission For Guard-
   ian lntervention On Earth Was Granted. Bridge Zone Project Was Set
     In Motion. Guardians Began Keying Earth’s V ortices.  In 1987, in
     response to the event of the Harmonic Convergence on 8/16/1987, the
     Sirian Council persuaded the Galactic Federation and other HU-2 and
     HU-3 groups to allow the ascension program to be activated for the
   human populations. Permission was given for the Guardians to intervene
    and set the Bridge Zone Project plan from 1984 in motion. Guardian
187 
                                                                                                                                                      
                                                                                                              
    

             Opening the Halls of Amenti  
   groups began keying Earth’s vortices with UHF seals to block Intruder
    forces from using the vortex portals. Guardian and Intruder forces began
     vying for control over Earth’s vortices.  
3.  January 1988: Sphere Of Amenti Returned To Earth’s Core And The
    12-year Amenti Activation Cycle Began. Earth’s First V ortex Seal-Ari-
          zona, USA-opened. Amenti’s D-1 Frequencies Began T ransmitting
      Through Earth’s Grid.  The Sphere of Amenti returned to Earth’s D-2
       core from the UHF bands of D-3, for the first time in about 3,500 years,
       and began transmitting its D-1 frequencies into Earth’ s grid. This began
         the 12-year activation process of the Sphere of Amenti, through which
      the Sphere progressively opens its D-1, D-2 and D-3 frequencies into
     Earth's core D-2 morphogenetic field. This will raise the pulsation rhythm
           of Earth’s particle base and the frequency of Earth's grid, in preparation for
                  Earth’ s first Stellar Activation on 5/5/2000. As the Sphere of Amenti
        began transmitting its D-1 frequencies through Earth’ s grid, the natural
         seal on Earth’ s first primary vortex opened and the vortex began its 4-year
     activation cycle. Earth's first primary vortex/chakra is located in the
         region of the Painted Desert in the state of Arizona, USA. (The Sedona,
       AZ, vortices are connected to this primary vortex and they began multidi-
     mensional activation at this time.)  
 4.  September 1989: Guardians Repair Solar Fields. Guardian Transmis-
   sions of D-4 Frequency to Increase Earth's Grid Speed Begin . The Sir-
     ian Council and other Guardian groups completed the realignment of the
   solar Merkaba Fields, which began the realignment of Earth's D-1 and D-2
   Merkaba Fields, that had been misaligned by the Zetas following the Phil-
   adelphia Experiment of 1943. This allowed D-4 frequency transmissions
  from the Guardian’ s artificial “Christ Consciousness” grid to resume infu-
   sion into Earth’ s core, to raise Earth’ s core frequencies. This also allowed
   for the 11:11/12:12 Frequency Fence to come down, once the Earth’ s grid
      re-balanced.  
 5. January 11, 1992: The 11:11—Promise Of Ascension —Granted as
    Guardians T ransmitted The 1 1 D-4 Magnetic Base Codes That W ould
       Allow 1 1:1 1/12:12 Frequency Fence to Later Release.  On 1/11/1992
   the Guardians began to transmit the 11 D-4 magnetic base tones that had
   been removed from Earth's morphogenetic field in 1972, to create the pro-
   tective 11:11/12:12 Frequency Fence, which stopped the Red Pulse/W ave
   of Solar Flame from moving through Earth and neighboring planets.
   Transmission of these magnetic codes marked the beginning of the 11:11/
   12:12 Frequency Fence disengagement. The Fence had blocked the third
   and fourth DNA  strands from plugging into each other, which caused a
      block between the D-3 personality and higher self and the astral identity .
        The Fence would also block the Sphere of Amenti from transmitting D-4
     188  
 

                                                                           
                                                                              10/1986 through 6/1998
      frequency into Earth’s grid in 2000. The Halls of Amenti could not open
   while the Fence was in place. With the return of the D-4 magnetic base
    tones to the Earth’ s morphogenetic field, the opening of Amenti would
     continue on schedule, the third and fourth DNA  strands began to align
      and astral awareness became more accessible to the 3-dimensionally con-
     sciousness human identity . The date of 1/11/1992 became known as the
  11:11 in New Age circles, representing the celebration of the promise of
   ascension, which was granted on that date, through Earth receiving the 11
   D-4 magnetic base codes that would allow the Frequency Fence to disas-
       semble.  
             6.  June 6, 1992: Earth’s Second Vortex Seal—Jerusalem, Israel —
           opened; Amenti’s D-2 Frequencies Began T ransmitting Through
           Earth’s Grid.  The Sphere of Amenti completed opening its D-1 frequen-
         cies into Earth’ s morphogenetic field, Earth’ s first primary vortex in the
        Arizona Painted Desert completely opened and activated and the seal on
         Earth’s second primary vortex began to open and activate. Earth’s second
         primary vortex/chakra is located in Jerusalem, Israel. The Sphere of
        Amenti began transmitting its D-2 frequencies through Earth's grid.
      7 .  July 26, 1992: Avatar # 1—Seventh-level Avatar —Is Born And Aligns
      DNA  Strand 2 Imprint With 12-strand Pattern; Corrected Strand 2
       Imprint Begins T ransmitting Through Earth’s Grid. The first of six
         Silent Avatars was born. This avatar is a D-7 soul essence from HU-3, a
      seventh-level avatar, with 7-dimensional frequency bands activated in his
      genetic code. This individual was born with DNA strand 7 fully activated.
      As his soul essence passed through the Sphere of Amenti the imprint for
          DNA  strand 2 was realigned with the 12-strand DNA  pattern and the
    imprint for the aligned DNA  strand 2 began transmitting through Earth's
       grid and into the bio-energetic fields of Earth’s population.  
             8.  December 12, 1994: The 12:12- Independence Day- Human Gradua-
    tion. Changing Of The Guard Of Amenti. The 11:11/12: 12 Frequency
     Fence Releases. Earth Guardianship Is Turned Over To Humanity. The
      Ascension Schedule Moves Forth.  The 11 D-4 magnetic base tone codes
      and electrical overtone codes of the 11:11/12:12 Frequency Fence com-
      pleted re-entry into the Earth’ s D-2 morphogenetic field and the 11:11/
     12:12 Frequency Fence was fully dismantled. The 12th base tone and 12th
        overtone frequencies of D-4 were reconnected to the 11 D-4 base tones
              and overtones within Earth’ s morphogenetic field and the Sphere of
         Amenti. Human DNA  could now continue to assemble through the
       fourth and fifth strand. The remaining stages of opening the Halls of
      Amenti were no longer under full Guardian control, the responsibility for
     humanity's evolutionary destiny was now in human hands. The success of
    the opening of  the Halls of Amenti and the Bridge Zone Project, which
      189  
                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                    
                                                                                                                                
    

    Opening the Halls of Amenti  
were previously controlled by the Guardians’ 11:11/12:12 Frequency
  Fence, would now be determined by the rate at which human conscious-
  ness and DNA  evolved to higher accretion levels. The Sphere of Amenti
 race morphogenetic field, which had been created 550,000,000 years ago
  by the Palaidorians of T ara would now be placed under Earth human
 guardianship. The Ur-T arranate Palaidorian souls from HU-2, who had
  merged their consciousness to form the Sphere of Amenti, began to leave
  Earth and the Sphere of Amenti, to return to their HU-2 T aran reality
  fields. For 550,000,000 years, the energetic substance of the Ur-Tarranate
  souls and their consciousness had provided the medium through which
  the lost soul fragments of T ara could evolve from HU-1, by merging their
  consciousness with that of the Ur-T arranates within the Sphere of
         Amenti, through evolution of the DNA. The Ur-T arranates had served as
  a Host Matrix Family for the entire Earthly human lineage. The Sphere of
    Amenti morphogenetic field “rescue mission” for the lost soul fragments of
  T ara represents a Host Matrix Transplant, through which the entire
   Earthly human lineage has evolved. When the fall from T ara occurred, the
       lost souls of T ara were cut off from their soul matrices and the Turaneu-
      siam-1 race morphogenetic field. The Ur-Tarranates of Amenti served as
   an adoptive soul matrix through which the lost souls could re-evolve,
    until they had re-built their connection to their T aran soul matrices
   through assembly of the fourth and fifth DNA strand. Through the accel-
     erated evolution opportunity offered by Earth’ s present ascension cycle,
   fourth and fifth DNA strand assembly would allow many humans the
   chance to re-connect with their personal soul matrices from HU-2. The
    services of the Ur-T arranates would no longer be needed, as the humans
         who made their soul matrix connection would become carriers of the
    human evolutionary blueprint.  
   The return of the race morphogenetic field to the human species could
not occur while the 11:11/12:12 Frequency Fence remained in place and
DNA strands four and five were blocked from assembly. When the Fre-
quency Fence dismantled on 12/12/1994, fourth and fifth strand assembly
once again became available to humanity. The event of Amenti’s transfer
to human guardianship can be viewed as a “Changing of the Guard”.
With the termination of the Frequency Fence, between 1/11/1992 and 12/
12/1994, the Host Matrix Family Ur-Tarranate souls began leaving Earth,
as progressively more humans re-connected to their HU-2 soul matrices.
The Ur-Tarranates involved in the Amenti project had been Earth-bound
for 550,000,000 years and could not ascend from HU-1 until this “Chang-
ing of the Guard” took place. As of 12/12/1994 the ancient Ur-Tarranate
souls from Tara could at last disengage themselves from the Sphere of
Amenti and continue on their own evolutionary journey through the
190 
    

                                                                         
                                                                          10/1986 through 6/1998
            higher Harmonic Universes. This date of 12/12/1994 became known as
         the 12:12 and represents humanity’ s true Independence Day , when the
         fate of human destiny was turned over from the custodial care of the
        ancient Ur-T arranate race and placed into the hands of an evolving
         humanity . The 12:12 stands for humanity's graduation from its adolescent
          evolution into the adult role of becoming a planetary Guardian species.
    9.  1995: Guardians Initiate Portal Project To Secure Earth's Vortices
         From Intruder In filtration By 2012.  The Sirian Council became aware
        of Anunnaki Resistance plans to instigate Earth changes through D-4
         interference. The Pleiadian Star League and members of the Andromeda
          Council agreed to assist the Sirian Council in more aggressive efforts of
         frequency-keying, monitoring and protecting Earth’ s vortex/portal system
        from Anunnaki Resistance and Dracos-Zeta Resistance manipulation.
          They began the collaborative Portal Project. Guardian and Intruder forces
         have been secretly vying for portal control ever since. Presently the
         Andromies have most of Earth’s portals under protection, though Intruder
        forces continue to attempt to overtake the primary second portal vortex
         in Jerusalem and the smaller, secondary portals in Manhattan, Florida,
        Sedona, Arizona, Hawaii, Tibet, China and in other areas of the globe.
        Guardians must secure all seven primary vortex points by 2012 for the
        Bridge Zone Project and the opening of the Halls of Amenti to unfold
          smoothly , without causing grid instability and Earth changes. Humanity
         can help the Guardians in this portal protection endeavor by using
          focused group meditation to project high frequency D-4 - D-8 frequency
          into these locations and into the Earths grid in general, using “sun” visu-
            alizations.  
      10. June 1996: Earth’s Third Vortex—Himalayan Mountains—Opened.
         Amenti Began T ransmitting D-3 Frequencies Through Earth’s Grid.
         Keepers Of The Blue And Violet Flames Begin First Stellar Activation,
        The Solar-Heart Star Activation.  The Sphere of Amenti completed
         opening its D-2 frequencies into Earth’ s morphogenetic field, Earth’ s sec-
        ond primary vortex in Jerusalem, Israel completely opened and activated
        and the seal on the third primary vortex/chakra began to open and acti-
        vate. The third vortex is located in the Himalayan Mountains of South
                            Central Asia. The Sphere of Amenti began transmitting its D-3 frequen-
         cies into Earth’s grid. The Keepers of the Blue and Violet Flames and their
        Flame Holders began the D-4 Solar-Heart Star Activation, initiating the
                            assembly and activation of their fourth DNA strand.  
                 1 1 . June 24, 1996: Avatar 2—Eighth-level Avatar—Was Born And
                    Aligned DNA  Strand 3 Imprint With 12-strand Pattern. Corrected
                       Strand 3 Imprint Begins Transmitting Through Earth’s Grid . The sec-
                       ond of six Silent Avatars was born. This avatar is a D-8 soul essence from
                       191  
                                                                                                                                         

  Opening the Halls of Amenti  
     HU-3, an eighth-level avatar, with 8-dimensional frequency bands acti-
     vated in his genetic code. This individual was born with the eighth DNA
     strand fully activated. As his soul essence passed through the Sphere of
     Amenti, the imprint for DNA  strand 3 was realigned with the 12-strand
     DNA  pattern and the corrected third strand imprint began transmitting
       through Earth’s grid.  
    By 1996 there was great concern among Guardian races, as to whether
Earth’s grid speed would be raised high enough by 6/30/1998 to spark the sec-
ond seal on the Arc of the Covenant. If the second seal did not open by this
date, Earth could not begin its ascent into pulsation rhythms of the D-4 time
cycle for merger with Tara.  
    If Earth’ s grid speed was not high enough to spark open the second Seal
on the Arc of the Covenant by June 30, 1998, the Bridge Zone Project would
not succeed. The Halls of Amenti would not open. The Earth would be
unable to shift into the D-4 time cycle by 1/2012 and the Dracos-Zeta Resis-
tance would have a much better chance of creating the 2003 experiment and
2004 Frequency Fence. If Earth was unable to begin shift into a D-4 particle
pulsation rhythm by 5/5/2000, sporadic Earth changes would erupt between
2012-2017, as the grids of Earth and Tara attempted to merge, and the oppor-
tunity for ascension would be lost.  
    Guardians were permitted by the HU-2 and HU-3 councils to continue
their transmissions of D-4 frequency into Earth’s grid, but they were not per-
mitted to directly intervene in Earth’s affairs by landing and directing the
actions of humans to desired ends. Humans had been given guardianship of
Earth on 12/12/1994. Visiting Guardians were allowed to assist, but not to
alter the choices humanity would make for itself. The Dracos-Zeta Resistance
continued to inﬂuence human decision making through covert infiltrates,
and motivated an acceleration of new technology testing among various
groups of global military organizations. Top Secret military experiments using
scalar wave technology, satellite manipulation of inter-stellar radio waves and
certain types of nuclear testing from 1988 through the present, progressively
created new imbalances in Earth’s bio-fields and grid, which hampered the
Guardians’ efforts to raise grid speed. It was feared that by 6/30/1998 the grid
speed would not be high enough to spark the second seal on the Arc of the
Covenant. Guardian groups from all over the galaxy, and from HU-2 and
HU-3 watched, waited and prayed that humanity would be able to counter-
balance the activities of their governments by raising personal consciousness
and accretion levels enough to allow Earth’s grid speed to sufficiently
increase. In 12/1997 the Anunnaki Resistance began subliminally manipulat-
ing populations through the primary vortex in Jerusalem, the secondary vor-
tex in Manhattan and several other secondary vortices whose security seals
they were able to decode and release. Following this new development, the
192 
  

                                                                       
                                                                       The Arc of the Covenant Opens
odds of the second seal on the Arc of the Covenant sparking open by 6/30/
1998 were about two million to one against the event occurring.  
                 Prospects for the Bridge Zone Project and opening the Halls of Amenti were bleak as 1998
                                                  dawned under the in ﬂuence of covert ET manipulation                                                                             
                         THE ARC OF THE COVENANT OPENS  
          In the beginning of this transmission we mentioned that we had an
          announcement to make, and we will make that announcement now.
              In February 1998 the Elohim from HU-3 knew the second seal of the
Arc of the Covenant would not be sparked open in time for the 6/30/1998
deadline. They broke their own protocol. Having a change of heart toward
helping the entire human species, rather than only their preferred genetic
strains, the Elohim intervened.  
     The original ascension plan called for the birth of six avatar souls from
HU-3 and HU-4, between 1992 and 2012. These individuals were needed to
hold higher-dimensional frequency as Earth progressively integrated the fre-
quencies from the Sphere of Amenti and to correct any misalignments in the
morphogenetic imprints of DNA strands 2-7, within the Sphere of Amenti.
The avatars were to be born about four years apart, in various, undisclosed loca-
tions on the globe, beginning in 1992. Avatar 1 was born on 7/26/1992 and
Avatar 2 on 6/24/1996. Avatar 3 was not due to birth until the year 2000.
  Knowing the ascension plan had reached a standstill early in 1998,  
      the Elohim orchestrated the early birthing of the third avatar,  
                                       the ninth-level avatar.    
       
        With the birth of the third avatar, Earth’ s morphogenetic field would
receive a sudden burst of UHF energy as the avatar soul passed through the
Sphere of Amenti, Earth’s core and into fetal integration, moments before
physical birth. ¹ 
          
         ______________________  
1.   Most avatar souls do not enter the fetal body anywhere near conception, as the vibra-
tional rate of their consciousness would literally blow the physical tissue apart, cause mis-
carriage of the pregnancy and damage to the mother’s bio-energetic system. They usually
hover about and over shadow the pregnancy, then enter the infant’s body just before it
passes through the birth canal. Avatar pregnancies rarely exceed a seven-month gestation
period, as avatar-selected fetal bodies have a larger genetic package, tend to develop more
rapidly and begin to drain the life force energy of the mother-host after the seventh
month of gestation. Most are born as premature infants with soul integration taking place
during or just after the birth process.  
193 
                                                                                                                                                                                                                      
                                                                                                                     

Opening the Halls of Amenti  
              The Guardian Alliance would like to announce the following:  
On June 26, 1998, at 3:46 PM, the third Avatar child was born, and the second
seal on the Arc of the Covenant sparked open, beginning Earth's 2-year preparation
         for passage into the particle pulsation rhythms of the D-4 time cycle.  
   The child was born at home to a couple residing in a village of a Third
World country. He was in actuality a five5-month gestation infant, but is
believed to be only two-months premature. He is faring well and will survive
to ful fill his purpose of holding higher-dimensional frequency as the Sphere
of Amenti continues to open. The name, religious affiliation and location of
this child (and the other five avatars) are unimportant. His identity will not
be publicly disclosed, nor will the identities of the other five ascension ava-
tars reach public notice during the ascension period. Four of the Six Silent
Avatars will disclose their identities sometime after they have turned 33 years
of age and their service missions come into mass awareness.  
    Anyone publicly claiming to be one of the six Silent A vatars before 2025
AD (when avatar one turns 33) is either misguided, being manipulated by
Intruder forces or is purposely trying to distort the truth. There are a number
of other legitimate avatars present on Earth at this time. Some of them are
publicly known, but these are not of the six Silent Ascension Avatars, whose
purpose is to realign the human DNA imprint and ensure Earth’s grid stabil-
ity by holding higher-dimensional frequency in their bio-energetic fields as
the Sphere of Amenti opens into Earths morphogenetic field. 
    Our announcement is thus a birth announcement, but also the con firma-
tion of Earth's passage into the D-4 time cycle in preparation for entering the
Bridge Zone, the opening of the Halls of Amenti and the opportunity for
ascension.  
    The second seal on the Arc of the Covenant has been sparked and Earth
will now begin preparation for the descent of the Blue Flame of Amenti and
the opening of the Halls of Amenti portals, which are scheduled for May 5,
2012.  
       Your preparation for ascension is now back on schedule.  
                       
                           PALAIDORIAN BIRTHING CONTRACTS  
                
                 The Indigo Children, Palaidorian Birthing Contracts,  
                            Contract Bonds, and the Incubation Rite.  
        Along with the birth of the Six Silent Ascension Avatars between 1992-
2012, the Palaidorians and Priests of Ur from HU-2, working with the Elohim
and other Guardian races from HU-3 and HU-4, organized the Palaidorian
Birthing Contract soul agreement program. To ensure the success of the Bridge
Zone project, and thus the ascension program, a minimum of 144,000 individu-
als on Earth would have to completely assemble and activate the sixth DNA
strand and rapidly begin assembly and activation of the seventh and eighth
194 

                                                                     
                                                                                         
                                                                                      Palaidorian Birthing Contracts
DNA strands. The only members of the human population on Earth that
organically possessed the sixth DNA strand imprint are the groups who have
undergone genetic acceleration through earlier Zionite intervention—those
who carry the Celestial 12-strand Silicate Matrix gene code. The Keepers of
the Blue, Violet and Orange-Gold Flames also possess this genetic con figura-
tion. The Sixth Root Race Muvarians and their Melchizedek Cloister race are
born with the fourth DNA strand assembled and the imprint for the fifth strand
dormant. The Muvarians have not yet begun their birthing cycle on Earth. The
Melchizedek Cloister race must fully assemble the fifth DNA strand before it
can activate the imprints for strands 6 and above. Members of all of these races
must fully assemble and activate the lower strands, then assemble and activate
the sixth strand by completing at least three Stellar-Star Crystal Activations,
before Earth can receive the needed concentration of D-6 frequency these acti-
vated sixth strand individuals would provide. There is little time left before the
2012—2017 ascension period begins for a minimum of 144,000 individuals to
awaken to their soul purposes and consciously complete these Stellar activa-
tions to activate their sixth DNA strand.  
    Being aware of the shortage of time available to achieve the needed
sixth strand activations, the Palaidorians created an early birthing program
for members of the seventh Root Race Euanjhechi and their Cloister Race
Yunaseti. The Euanjhechi and Yunaseti, often referred to collectively as the
Paradisians,  possess a fully activated fifth DNA strand at birth and the ability
to rapidly assemble and activate the sixth DNA strand imprint, which they
organically carry. The Paradisians are D-6 soul essences and become fully
embodied souls when their sixth strand completes activation, usually by 12
years of age.  
    Through soul agreements with members of the Sixth Race Melchizedek
Cloister and others carrying the Celestial Silicate Matrix gene code, 150,000
couples were chosen to serve as birthing parents for the incoming Paradisian
race soul essences. These are the only groups of humans possessing a large
enough gene code to create fetal bodies strong enough to hold the Paradisian
soul essence. Through these Palaidorian soul agreements, which are orches-
trated by the Priests of Ur from Agartha and Tara, selected Earth couples are
subconsciously guided together by their personal soul-level identities, to ful-
fill the Palaidorian Birthing Contract.  
   Through astral contact and/or Guardian ET soul-agreement abductions,
the parent couples undergo manipulation of their bio-energetic fields and
DNA, to allow for a strong, energetic soul bond to be created between the
parents. This electromagnetic bond allows the soul matrices of the individu-
als in the couple to merge, forming an UHF bio-energetic field through
which an advanced fetal pattern, with a genetic code larger than that of
either of the parents, can be conceived. Once this bond, referred to as a
195 
                                                                                                              
   
                                                                                                            
  

Opening the Halls of Amenti  
Bonding Contract  or Contract Bond,  takes place, the bio-energetic fields
and life paths of the parents are blended together, following which time the
couples will be led together through various circumstances that occur in their
earthly lives. Some of the parent couples will be consciously aware of these
Contract Bonds and Birthing Contracts, others will be consciously unaware
and “just so happen to fall in love with each other” and bear their Paradisian
child.  
   The Palaidorian Birthing Contracts and Contract Bonds are high-level
soul agreements entered into by the parents’ over-soul level identities, in
cooperation with the over-soul identity of the child they will birth. In fulfill-
ing these contracts the individual parents receive acceleration of their
genetic blueprint, which allows them further advancement in their evolu-
tionary ascension process. The over-soul identity enters the Palaidorian con-
tract in order to allow its incarnate the opportunity for advancement. These
contracts in no way violate the rights of the incarnate and they are intended
by the over-soul to guide the incarnate to its highest life experience.  
    The births of the Six Silent Ascension A vatars and those of the I50,000
Paradisian souls are orchestrated through Palaidorian Birthing Contracts and
Contract Bonds. The Paradisian souls will enter incarnation on Earth from
the D-6 frequency bands of Tara through the D-6 Sirian Stellar Spiral. The
sixth-dimensional frequencies correspond to the Indigo wave pattern of the
interdimensional Light Spectrum, thus the Paradisian children have been
nicknamed the “Indigo Children” or “Sirian Blue Babies”. The coming birth
of the Indigo Children has been foretold within various Earth human groups
that are working with other Guardian ET and metaterrestrial contacts. Some
of this information has been published in channeled writings.  
   The birth schedule of the Indigo Children will proceed as follows: the
first wave of 144,500 Indigo Children will birth between 1999-2004. They
will complete activation of the sixth DNA strand at the age of 12, between
2011-2016. Children of the first birth wave will serve as Place Holders, their
sixth DNA strand activation serving to ensure the balance and grounding of
D-6 frequency on Earth during the 2012-2017 ascension period. The second
birth wave of 5,500 Indigo Children will birth between 2005-2017, to reach
maturity at age 12 between 2017-2029. The children of the second birth
wave will assist Bridge Zone Earth to balance frequency following the 2017
particle conversion process. They will also serve as Place Holders, grounding
D-6 frequency into the Sphere of Amenti race morphogenetic field. 
    The finalization of the Palaidorian Birthing Contracts and Contract
Bonds between the parent couples of the Indigo Children took place on
August 30, 1998. Prior to this date, contracts were transferable between vari-
ous eligible individuals, giving chosen soul identities the opportunity to exit
or renegotiate the terms of their Palaidorian Contracts.  
196  

                                                      Palaidorian Birthing Contracts
    As of 8/30/1998, parent couples were bound to their Palaidorian Birthing
Contracts and Contract Bonds, as the necessary bio-energetic field and DNA
adjustments that would ful fill the Contract Bond were given to the parent
couples through astral body mechanics, referred to as the Incubation Rite.
During the 3-day Incubation Rite, couples agreeing to uphold their contracts
were taken to Agartha-Inner Earth by the Priests of Ur, via their astral bod-
ies. The Priests of Ur then initiated the bio-energetic field mechanics
through which the DNA, bio-energetic fields and soul matrices of the two
individuals in a couple are fused together, by infusions of energy from their
respective over-souls.  
    Through these rites, the Contract Bond and Birthing Contract are pro-
grammed into the individual’s active DNA program, creating a twin DNA
code alignment between the couple. This rite begins the Incubation Period
for each individual, through which the life patterns and soul directive of each
person is aligned with the contract and all events, karmic patterns and cir-
cumstances that are not part of the contract are purged from the life drama
manifestation pattern. From this point forward, the couple’s lives will unfold
according to the soul identity’s intentions, offering the incarnates protection
from various karmic dramas and ego-based choices that normally would have
manifested. The Incubation Rite marks the suspension of the karmic imprint
                            for the individual and the accelerated integration of the soul and ego identity.      
                               The couples of Palaidorian Birthing Contracts will begin rapid DNA
activation acceleration in preparation for their child’s birth, and will receive
“across the board" protection from the Palaidorians and HU-3 Guardians, to
ensure the success of their contracts. Though the families of the Palaidorian
Contracts may appear no different than any other Earthly family, they are
fully guided and protected from the higher Harmonic Universes. Due to their
agreement to participate in this service to human evolution, these couples
are granted direct intervention and support from the D-6 “Angelic King-
doms,” Guardians from HU-2 through HU-5 and the Entity gestalts from
Meta-Galactic Core. This “divine   intervention” will    create an  almost “magi-
cal” ease in Earthly endeavors that are part of the Palaidorian Contract and
the   individuals  will  also   experience  greater   difficulty   in   successfully   orches-
trating Earthly affairs that are not part of the contracts to which their souls
have agreed. All incarnates fulfilling their Palaidorian Birthing Contracts
will  be  freed  from the  HU-1 reincarnational cycles of   birth  and  death, follow-
ing their present incarnation.  
   Through the births of the Six Silent A vatars and the Indigo Children,
Earth’s transition to the Bridge Zone and humanity’s opportunity for ascen-
sion will unfold as planned.  
12. June 26, 1998: Avatar 3—Ninth-level Avatar—Was Born Two Years
    Early . The Second Seal On Arc Of The Covenant Opened. A vatar 3
    Aligned DNA  Strand 4 With 12-strand Pattern. Corrected Strand 4
 197 
                                                                                                                  
                                                                                                                                            
   

Opening the Halls of Amenti  
Imprint Will Allow Reverse-mutations Of Strand 4 Distortions; And
Release Of Palaidor, Amenti, And Zeta Seals From DNA On 5/5/2000.
The third of six Silent Avatars was born two years early via Elohim inter-
vention; originally birth was scheduled for 5/5/2000. This avatar is a D-9
soul essence from HU-3, a ninth-level avatar, with 9-dimensional fre-
quency bands activated in his genetic code. This individual was born with
DNA strand 9 fully activated. As his soul essence passed through the
Sphere of Amenti, the imprint for DNA strand 4 was realigned with the
12-strand pattern. The Seals of Palaidor, Amenti and Zeta all begin to
release with the assembly of the aligned fourth DNA strand. The birth of
Avatar 3 reset the aligned fourth strand pattern into the Sphere of Amenti
morphogenetic field, releasing the imprint of the Palaidorian, Amenti and
Zeta Seals from human DNA. The D-4 frequencies from Amenti will not
begin transmitting through Earth’s grid until 1/2000 and the corrected
pattern for the fourth DNA strand will begin transmitting through Earth’s
grid on 5/5/2000.  
                                      What transpires next?  
        198  
           

                                         11
                                                                                                                                     
                                    Things to Come                                       
                                              
                                                  ASCENSION SCHEDULE  
          As Earth approaches its half-point in the second ascension cycle of its
26,556-year Euiago time cycle, the opportunity for ascension of human popu-
lations through the Halls of Amenti and into HU-2 is presented. Taking
advantage of this time-cycle placement opportunity, with Guardian assis-
tance, Earth can be shifted out of the range of Intruder Visitor manipulation,
through the Bridge Zone time continuum shift. The dynamics by which these
changes will occur are highly scienti fic, and involve complex interdimen-
sional physics mechanics. We have provided extensive information concern-
ing humanity’s need to evolve the DNA in order to accommodate these
changes, attempting to assist you in understanding the concept of the interre-
lationship of biological, spiritual and planetary evolution.  
      The ﬁnal aspect of these interdimensional evolutionary/ascension dynamics
with which you need  to  become acquainted, is the mechanics of  Transmutative
Stellar Activations  and Stellar Wave Infusions , for it is through these mechan-
ics that personal and planetary ascension takes place.  In the Appendix we pro-
vide a brief introduction to Stellar Activations (page 464) and Stellar Wave
Infusion Mechanics (page 466). For now, we would simply like you to under-
stand that Earth and the human populations will be facing a series of six
Transmutative Stellar Activations and Stellar Wave Infusions between 5/5/
2000 and 2017. Through these Stellar Activations and Wave Infusions
Earth’s particle base will be temporarily raised into the pulsation rhythms of
the HU-2 time cycles, so grid merger between Earth and Tara, and the open-
ing of the Amenti ascension passages, can take place.  
     These energy dynamics will affect the planetary grid and the physical and
bio-energetic systems of humans directly, so it is wise that you become aware
of these coming events. For this reason we have included the progression of
Stellar Spiral Alignments, Stellar Activations  and Stellar Wave Infusions
with our running schedule of upcoming Earthly events. The Six Stellar Acti-     
199                         


     Things to Come
  vations, Stellar Wave Infusions and Stellar Spiral alignments Earth will
  encounter between 2000 and 2017 are as follows:                                                                                                                                                                         
1.   D-4 Solar Activation: 5/5/2000-6/2004.
       Blue Wave Infusion 6/2002- 6/2006
       D-4 Solar Spiral aligns with Earth's Merkaba Field s
 2.   D-5 Pleiadian Activation: 6/2004 -6/2008.
       Violet Wave Infusion 6/2006-6/2010
       D-5 Pleiadian Alcyone Spiral aligns with Solar Spiral Merkaba Fields
 3.   D-6 Sirian Activation: 6/2008-1/1/2012.
       Gold Wave Infusion 6/2010- 6/2014
         D-6 Sirian Spiral aligns with Pleiadian-Alcyone Spiral Merkaba Fields
 4.   D-7 Arcturian Activation: 2017— day 1¹
       Silver Wave Infusion day 1-2¹
       D-7 Arcturian Spiral aligns with Sirian Spiral Merkaba Fields
 5.   D-8 Orion Activation: 20l7— day 2¹
      Blue-Black Liquid Light Wave Infusion day 2-3¹
      D-8 Orion - Meta-Galactic Core Spiral aligns with Arcturian Spiral
      Merkaba Fields
 6.   D-9 Andromeda Activation: 2017— day 3¹
       Silver-Black Liquid Light Wave Infusion day 3¹
        D-9 Andromeda- Galactic Core morphogenetic field Spiral aligns with
      Orion Spiral Merkaba Fields.
      The following chronology of events also includes the Activation and
Infusion schedules for the Keepers of the Blue Flame and the Keepers of the
Violet Flame. Many of you reading this book may have hidden soul agree-
ments to serve as a Keeper of the Blue or Violet Flames. The Flame Keepers
are a specialized soul group that carries the Celestial Silicate Matrix gene
code, who incarnate during various time periods to assist the Palaidorians of
HU-2 with the human evolutionary process. Flame Keepers possess special-
ized genetic codes that will allow them to hold UHF within their bodies to
assist Earth with the Stellar Activation process. These writings represent a
“wake-up call” to the Flame Keepers, it is time for them to remember their
higher calling. Those of you who feel drawn to the concept of the Flame
Keepers are likely to be members of the Blue or Violet Flame soul groups. The
Keepers of the Blue Flame (Tara’s HU-2, D-5 morphogenetic field) begin and
complete their Stellar Activations and Infusions just prior to Earth's Activa-
tions and Infusions. The Keepers of the Violet Flame (Gaia’s HU-3, D-7 mor-
________________________________
1.   Three-day particle conversion period between 5/5/2017-6/30/2017
200

                                                      
                                                The Amenti Ascension Program Schedule
phogenetic field) begin and complete three of their Activations and Infusions
just after those of Earth and three just prior. We have included the schedules
for Earth and the two Flame Keepers groups in this chronology to assist the
   Keepers in their awakening process.  
                THE AMENTI ASCENSION PROGRAM SCHEDULE
                                                6/1998 to 2017                                                                                         Transcendence Day
        1.    June 26, 1998: Sphere of Amenti Continues to Transmit D-3 Frequen-
      cies into Earth’s Core. The Morphogenetic Wave Begins to Build. Earth
        Prepares for 1/1/2000 Transcendence Day. Flame Keepers Begin Blue
      Wave Infusions.  
           By 7/1998 the Sphere of Amenti opened into Earth’s morphogenetic field
            six (out of 12) D-3 frequencies and it will proceed to transmit its remain-
        ing six D-3 frequencies into Earth’s core between 7/1998 and 1/ 1/2000.
      On 1/1/2000 Amenti will begin transmitting D-4 frequency through
       Earth’s grid. The morphogenetic wave began to build on 6/26/1998 and
         the D-4 Solar Spiral began to align with Earth, following the birth of Ava-
            tar 3 and the sparking of the second seal on the Arc of the Covenant. Fol-
         lowing the 6/26/1998 opening of the second seal on the Arc of the
       Covenant, Blue Wave Infusions began within the bio-energetic fields of
       the Keepers of the Blue and Violet Flame, as they assembled half of the
       fourth DNA strand, halfway through their Solar Activation that began in
        6/1996. The Flame Keepers will complete their Solar Activation on 1/1/
       2000, in preparation for Earth’s Solar Activation on 5/5/2000. The Blue
        Wave Infusio ns of the Flame Keepers will complete in 1/2002.
    2.   August 30-September 1, 1998: Incubation Rite for Humans with
       Palaidorian Birthing Contracts Took Place in Agartha. Contract Bonds
       Were Activated.
    Humans with Palaidorian Birthing Contract and Contract Bond soul
     agreements were taken in their astral bodies to Agartha, by the Priests of
    Ur . Those accepting their contracts to birth the Indigo children were
    given the Contract Bond Incubation Rite, through which the soul matri-
    ces of each parent couple were energetically merged and the Birthing
   Contract was programmed into their operating genetic code.The
    Palaidorian Birthing Contracts became finalized, non-transferable and
    irreversible following the Contract Bond activation through the Incuba-
      tion Rite.
   3.    January 1, 2000: Celebration of the Day of Transcendence. Earth Pre-
            pares for Its Solar Activation as D-4 Solar Spiral Aligns with Earth’s
       D-2 and D-3 Particle Base.
 201                                                                                                                   
                                                                                                                
                                                                                                                 
   

     Things to Come  
Due to the Guardians’ D-4 energy infusions into Earth’s core (which
began in 196 BC) and the opening of the second seal on the Arc of the
Covenant, with the birth of Avatar 3 on 6/26/1998, the Earth’s core parti-
cle pulsation speed raised high enough to begin preparation for Earth’s
Solar Activation on 5/5/2000. These frequency infusions have suf ficiently
increased the particle pulsation rhythm of Earth's D-2 core and elemental
particle field, and Earth’s D-3 atmospheric particle field. Further D-4 fre-
quencies will be able to run through Earth’s D-2 and D-3 particle bases on
1/1/2000, when the D-4 Solar Spiral begins to align with Earth's core. D-4
is a primary base tone dimension and D-2 is a primary overtone dimension
within the 15-dimensional scale. When the full D-4 frequency spectrum
of the Solar Spiral begins to permeate Earth’s D-2 core and elemental par-
ticle field on 1/1/2000, an interdimensional Resonant Tone  will be struck
as D-2 overtone and D-4 base tone frequencies merge.             
This  interdimensional Resonant Tone allows Earth’s 3-dimensional particle  ﬁeld
to raise in pulsation rhythm, to receive the progressive Transmutative Stellar
Wave Infusions and Stellar Activations that will allow Earth to rise into the
HU-2 time cycles for merger with Tara.  Without this interdimensional Reso-
nant Tone, created through the merger of Earth’s D-2 core frequencies
with the D-4 Solar Spiral frequencies, Earth would not be able to achieve
its temporary shift into the HU-2 time cycle. If Earth is unable to make
this shift, the grids of Earth and Tara will not fully merge and the Bridge
Zone project will fail. The Halls of Amenti will not open, the planetary
ascension process will halt and Earth and its populations will remain
trapped within the HU-1 time cycle to fall under Dracos-Zeta Resistance
control.  
The striking of this lnterdimensional Resonant Tone is a natural part of
Earth’s ascension cycle, and will take place on 1/1/2000, as Earth’s grid has
reached the necessary particle pulsation rhythm as of 6/26/1998. The
event of the interdimensional Resonant Tone Striking will occur on
schedule. The alignment between Earth’s D-2 core and the D-4 Solar
Spiral and the resulting Interdimensional Resonant Tone created through
this alignment, constitutes a Day of Transcendence , for Earth and its
populations. The boundaries of Earth’s 26,556-year HU-1 time cycle, and
humanity’s entrapment within HU-1 physical matter, will be temporarily
Transcended.  This Day of Transcendence marks the ﬁrst day of Earth’s new
 dawn into the age of enlightenment and the opportunity to stop the Intruder Vis-
 itors’ intended destruction of the human race . 
The Interdimensional Resonant Tone of Transcendence Day is scheduled                   
      to occur between 12:00 PM of 1/1/2000 and 12:00  AM 1/2/2000,  
           as Earth completes its first day of the new millennium.  
202 
         
          

                                                                  
                                                                           
                                                                     The Amenti Ascension Program Schedule  
       Light Workers across the globe will be called together in celebration of
        this monumental occasion, and will be directed to begin Solar-Heart Star
         Activations for all who join them in this endeavor . The focused energies
         of the Light W orkers global network will serve to create balance and
      acceleration within Earth’ s grid, to prepare Earth for the initiation of its
       D-4 Solar Activation on 5/5/2000. This gathering of Light W orkers and
        others on 1/1/2000 is needed to counterbalance the fear-based, lower-
       vibrating energies of the fanatical groups who will promoting “millennial
      fever” and doom between 12/ 1999 and 1/2000. These fear-based energies
      have the potential to create temporary grid imbalances that could mani-
      fest as localized Earth changes, as Earth enters the Solar Activation on 5/
        5/2000. C elebration of the Day of Transcendence will serve as an Earth healing
                          measure, as well as a ceremony of human unity. Earth’ s fourth primary vortex-  
                           Giza, Egypt - will begin opening on this clay.                                  4.   1999-2004: First Birth Wave of Indigo Children.  
    The first wave of 144,500 D-6 soul essence —Root Race 7: Paradisian chil-
   dren, who possess the imprint for DNA  strand 6, will birth on Earth. They
     will reach maturity and activation of the sixth DNA  strand at age 12,
     between 2011-2016, to become Place Holders that ground D-6 frequency
         on Earth during the 2012 —2017 ascension period.  
   5.  January 1, 2000: Earth’s Fourth Vortex—Giza, Egypt—Opens. The
    Sphere of Amenti Begins T ransmitting D-4 Frequencies Through
      Earth’s Grid. The Blue Flame Begins Its 12-year Descent to Earth,
       Through the Alcyone and Solar Spirals. The Keepers of the Blue and
      Violet Flames Complete Solar-Heart Star Activation. Keepers of the
      Blue Flame Begin Fifth Strand-D-5 Pleiadian-Soul Seat Activation.
        The 9540 BC Quarantine Frequency Fence Dissolves.  
    As the Sphere of Amenti completes opening its D-3 frequencies into
      Earth’ s morphogenetic field, it begins to transmit D-4 frequencies through
    Earth’ s grid. The natural seal on Earth’ s fourth primary vortex/chakra
    opens; Earth’ s fourth primary vortex is located beneath the Sphinx and
    Great Pyramid of Giza in Egypt. The Keepers of the Blue and V iolet
     Flames will complete their Solar Activation, assembly and activation of
     DNA  strand four and Heart Star Activation. Through completion of the
     Solar Activation, the first level of soul integration takes place, astral inte-
     gration. The Keepers of the Blue Flame will begin their D-5 Pleiadian-
    Soul Seat-Activation and will initiate assembly and activation of their
     fifth DNA  strand, in preparation for grounding and embodying the fre-
      quencies of the Blue Flame of Amenti on 5/5/2012. The Keepers of the
       Blue Flame begin their Pleiadian-Soul Seat -Activation in 1/2000 and will
        complete this second Activation and begin the Third Activation on 1/1/
      2005. The Keepers of the V iolet Flame will begin their Pleiadian-Soul
      Seat-Activation on 1/1/2005. The Blue Flame begins its 12-year descent
     203  
       
                                                                                                                       
  
        

  
     Things to Come  
                 t o Earth through the Alcyone spiral and Solar Spirals. As D-4 frequencies
      from the Sphere of Amenti begin transmitting through Earth’ s core, the
        UHF band D-3 Quarantine Frequency Fence of 9540 BC completely
        releases, which creates a reversal of the third DNA  strand mutation that
        was caused by the Frequency Fence. This mutation manifested as a block-
       age in the third chakra and an arti ficial division within the third mental
         body level of the auric field, creating a division between the Ego/personal-
      ity awareness and the Higher Self awareness. Reversal of this mutation
           will allow humanity the opportunity to merge the Ego, stationed in the
      low to middle frequency bands of D-3, with the Higher Self identity , sta-
        tioned in the UHF bands of D-3. The Higher Self connects the D-3 con-
       scious identity to the astral and soul levels of identity. When the Ego and
         Higher Self merge, awareness of the astral and soul identity becomes more
      available to the Ego, dream reality and astral perception become clearer,
        fourth DNA  strand assembly and Solar Activation become available to
                the identity and consciousness begins to become multidimensional.                                                                                         Earth Solar Activation  
 6.  May 5, 2000: D-4 Solar Spiral Aligns with Earth’s D-1 Iron Core
       Crystal. Earth’s First T ransmutative Stellar Activation—The Solar
           Activation  —begins. Earth’s D-1 Particle Base Enters D-4 Time Cycle.
      The Corrected Fourth DNA  Strand Imprint Begins T ransmitting
      through Earth’s Grid and Seals of Palaidor , Amenti and Zeta Can
       Release from DNA. Solar Activation and Multidimensional Identity
         Become Available to the Masses.  
       Earth’ s D-1 electrical overtone particles in Earth’ s D-1 iron core crystal
        begin to merge with Tara’s D-4 magnetic base tone anti-particles in Tara’s
       D-4 gold core crystal, transmuting both into their higher-dimensional
      morphogenetic fields/hyper-space (D-1 particles to D-15, D-4 anti-parti-
       cles to D-12). This is considered a D-4 Solar Activation  as the Merkaba
       Fields of the D-1 and D-4 core crystals are held within the center of the
       sun and D-4 frequency transmits to Earth via the D-4 Solar Spiral. All of
       Earth’ s D-1 overtone particles and T ara’ s D-4 base tone anti-particles
       enter hyper-space and the overtone D-l and base tone D-4 Merkaba Fields
        will open into each other. E arth’s D-1 overtone particle base will have
       completed its shift into the pulsation rhythms of the D-4 time cycle and
        Earth’s D-1 base tone particles enter D-3 pulsation rhythm. As Earth’s D-l
       Merkaba Field opens into Tara's D-4 Merkaba Field, the particle pulsation
       speed of Earth’s core begins to rise into that of the D-4 frequency bands.
                 By the end of its Solar Activation in 6/2004 ,  Earth will complete 1/3 of its shift
             into the HU-2 time cycles, in preparation for merger with Tara on 5/5/2012.
       During Earth’s second D-5 Pleiadian Activation Earth’s D-2 and D-3 par-
      ticle base will also rise into the pulsation rhythms of HU-2 time cycles,
    204  
                                                                                                                     
     

                                                
                                                
                                                      The Amenti Ascension Program Schedule  
and Earth’s D-2 and D-3 Merkaba Fields will merge with those of Tara,
placing Earth fully within the HU-2 time cycles by 1/2012. Earth’s Solar
Activation is the first of six Transmutative Stellar Activations the planet
will undergo between 2000 and 2017. Earth prepares for its Solar Activa-
tion in 1/2000, when its D-2 and D-3 particle bases align with the Solar
Spiral. The Solar Activation initiates on 5/5/2000, when Earth’s D-1 iron
core crystal aligns with the Solar Spiral. Earth’s Solar Activation begins in
5/5/2000 and will complete in 6/2004, at which time Earth’s second Stel-
lar Activation will begin. The corrected imprint for the fourth DNA
strand will release through the Earth’s grid on 5/5/2000. This will allow
people whom are consciously working to assemble DNA the opportunity
to release the Seal of Palaidor, Seal of Amenti and traces of the Zeta Seal
from their DNA, so fourth strand assembly and the Solar-Heart Star Acti-
vation can begin. Assembly and activation of the fourth DNA strand
allows the consciousness to achieve the first level of soul integration,
Astral integration.  
    The D-4 Seal of Palaidor is a genetic mutation from 5,500,000 years
ago, which caused a blockage between the second and third chakras, a
division between the second, third and fourth levels of the auric field and
separation between emotional, mental and astral identity levels.  This seal is
released by fully assembling the fourth DNA strand.  Release of this seal allows
polarization in the fourth/heart chakra to reverse, and the D-2 emotional,
D-3 mental and D-4 astral levels of awareness to merge. The nadial cap-
sule (barrier between D-3 and D-4 frequency levels in the auric field) dis-
solves and the blockage between the D-3 conscious perceptions and D-2
sub-conscious mind releases. Release of the Seal of Palaidor represents the ﬁrst
stage of soul integration, as the conscious D-3 identity begins to access the D-4
astral planes and skills of D-4 projection of consciousness and multidimensional
communication develop.  
    The Seal of Amenti , the Death Seal , is a genetic mutation from
5,508,100 years ago, a mutation in DNA strand 1, which caused a block-
age between the physical and etheric body. The sixth activation code
(overtone) of the first DNA strand was removed, which caused mutation
in the first, second and third DNA strands, that manifested as a block
between the body’s particles and the anti-particles of the body-double in
the parallel universe. This seal ended humanity’ s ability to possess an Immortal
Body and created the necessity for birth and death through incarnational cycles
in order to evolve. lt stopped the process of bodily transmutation and the ability
to physically pass through the Halls of Amenti, in the masses . Release of the
Seal of Amenti allows the body to merge its particles with those of its
anti-particle double and creates merging of the physical and etheric bod-
ies. This creates transmutation of the body form, the ability to bodily ascend, the
return of the Immortal Body and release from the cycles of reincarnation. Cre-
205 
                                                                                                                  
                                                                                                                                                                                                                                                                                           
 

 
   Things to Come
     ates the merger of consciousness between present identity and identity
   focused in the parallel universe. Release of the Seal of Palaidor and assem-
      bly of the full fourth and fifth DNA strands is necessary to reclaim the
  Immortal Body . Release of the Seal of Amenti allows the process of fifth               
 strand DNA assembly and Pleiadian-Soul Seat -Activation to continue.         
         The Zeta Seal is a genetic mutation created in 1748 AD by the Zetas’
      Frequency Fence in the D-4 time cycle. Zeta Seal was removed by Guard-
     ians through astral realignment, between l902-1986, but traces of this
       fourth DNA  strand mutation still appear in some humans. Zeta Seal
        blocked D-4 frequency , and thus multidimensional perception, from the
      D-3 perceptual awareness, creating an arti ficial barrier between the D-3
      conscious self and the astral identity . The seal operated as an etheric
     implant within the nadial capsule, between the third and fourth layers of
     the auric field. This caused repression of dream recall and memory of mul-
         tidimensional experience, and hampering of multidimensional communi-     
        cation, astral projection and the soul integration processes. It allowed      
      Zetas to electrically impulse human bio-chemical response patterns and
            behavior, through subliminal manipulation of the bio-neurological struc-
               ture. Zeta Seal releases with assembly of realigned fourth DNA strand .                                                                                      The Hall of Records
     7.   September 17, 2001: Guardians Complete Alignment of Giza Pyramid
    with Alcyone Spiral. Hall of Records Begins to Open.  The Guardians
      will complete their Earth grid realignment, bringing the Great Pyramid of
    Giza/vortex 4 into alignment with the Alcyone spiral in preparation for
 the Holographic Beam of 2017. This will begin the opening of the Hall of
  Records  beneath the Sphinx.      
       The Hall of Records  is a fourth-dimensional portal passage storage area that
 connects to the higher-dimensional morphogenetic ﬁelds of Earth, Tara and
  Gaia, where the complete planetary memory banks are stored in the form of
 crystalline energy substance . These crystalline morphogenetic imprints are
 collectively called the Ancient Dora-Teura Matrix , and they contain the
 entire living memory of the five Harmonic Universes in one l5-dimen-
  ional system. The Akashic Record  planetary memory bank of D-8 is part
   of the larger Ancient Dora-T eura Matrix memory complex. The Hall of
   Records represents a D-4 conduit through which data from the Akashic
   Record and Ancient Dora-T eura can be downloaded through the Earth’ s
   seven-primary vortices and into the Sphere of Amenti and Earth’ s mor-
   phogenetic field. The data is transferred electronically through the Hall of
   Records, into Amenti and Earth’ s core, then into Earth's grid. The history
  of the universe then becomes available to anyone on Earth that has a high
         enough accretion level to translate the data through their genetic cod e
  
  206 

                                                     
                                                            The Amenti Ascension Program Schedule
and consciousness. The Hall of Records opens only when the Alcyone spi-
ral is aligned with the primary fourth vortex beneath the Sphinx and
Great Pyramid.  
Within the structure of the Sphinx there are several dormant portal pas-
sages that lead from the Sphinx, to the Great Pyramid then into the D-2
portal passage of Earth’s core, where the Sphere of Amenti is stored. Once
the Alcyone spiral is activated, these portals are accessible, but only to
individuals who carry very precise frequency tone combinations within
their bio-energetic fields. In order for the Hall of Records to release its
data through the portals of the Sphinx and into the Sphere of Amenti, the
three individuals who represent the Flame Holders of the D-2 Orange-
Gold Flame (a male), the D-5 Blue Flame (female) and the D-7 Violet
Flame (female) must enter the Sphinx through the D-4 astral plane, and
find their way to the inner chamber and the portal activation site, which
is a very small crawl space, boxed-in on three sides, just large enough to
hold three bodies (astral) lined up side by side. The activation site is
underground and is presently sealed by several layers of stone, its access
crawl space, through which it was constructed, is packed with earth. There
are several hidden passages within and beneath the Sphinx, that are marked with
a series of instructional symbol codes, the ﬁnal four of which can only be
decoded by the Flame Holders. The symbols are multidimensional Keylontic
Access Codes that, once translated and pulled into the body, serve as the elec-
tronic lock release for the Hall of Records.  
The Flame Holders will be guided to Egypt with a small support team to
help them hold the energy, at the appropriate time. The Flame Holders
must enter the activation site using the astral body. Ideally, they must
project from the physical body stationed within the King’s Chamber of the
Great Pyramid. When the Alcyone spiral is activated, the Flame Holders
within the Kings Chamber will receive a “Blue Flame Infusion” (a bodily
infusion of UHF D-5 energy from the Alcyone spiral), through an energy
rite known only to the Flame Holders and beings with D-15 “clearance”
(beings whom have undergone 15-dimensional initiations and carry the
imprint for D-13 through D-15 within their morphogenetic field). After
the infusions, the Flame Holders will link their bio-energetic fields, and
enter the astral plane and access site together. Once in the activation site
the three will blend the energies of their astral bodies in one unit of ultra-
conscious energy identity. The physical and astral bodies of the Flame
Holders serve as a conduit through which the electronically stored data
from the Hall of Records can download, activate the portals and pass into
the Sphere of Amenti. The Flame Holders allow the Hall of Records to be
put “on line” with the Sphere of Amenti, after which time this data trans-
mits through Earth’s grid and becomes available to anyone on Earth who
can translate the information. The Hall of Records begins opening with
207 
                                                                                                                  
                                                                                                         
                                                                                          

      Things to Come  
      the activation of the Alcyone spiral, but cannot be accessed until the Blue
         Flame of Amenti embodies on Earth, with the birth of the sixth avatar .
       The birth of the sixth avatar creates an energetic connection between 12
          dimensions of the Hall of Records and the Earth’ s core, which allows data
       to ﬂow through the Flame Holders and into the Sphere of Amenti. If the
        Halls of Amenti cannot open, the Hall of Records also remains closed.
      Prior to the opening of the Hall of Records, the chambers leading to the
       dead-end in front of the activation site in the Sphinx will be discovered.
         The Halls of Amenti will begin to open on 5/5/2012. The Hall of Records
         will begin opening on 9/17/2001, but will not activate and begin transmit-
       ting data until after the birth of the sixth avatar, which is scheduled for
        12:01 am on 5/5/2012. At this time the Flame Holders will be called to
         activate the Hall of Records for the races.   
      8.  2001: Dracos-Zeta Resistance Tentative Plan to Stage Public Landing
       and Introduction to Begin Frequency Fence Project. Guardians Plan
              “Fly-by’s” if  Warning of Earth Changes Is Needed.   
             The Dracos-Zeta Resistance tentatively plans to stage a public landing in
       order to deceptively introduce themselves as Guardians and begin covert
                   in filtration of Earth’s electrical power supply and water systems in prepara-
           tion for implementing their Frequency Fence . The Resistance forces will not
           land if they believe their Frequency Fence plan is in jeopardy.  If Earth’s grid
              reaches a 3.75-accretion level by 2001, (which will only occur if 8% of the
           population assembles the fifth DNA strand by 2001; this is not expected
           until just before 2012) the Resistance Frequency Fence will not work on
           the masses. If the Frequency Fence plan can be averted, the Resistance
            will abandon their direct take-over plans, and resort to instigating Earth
         changes.  
           If they cannot gain control over human populations, they still hope to
           stop the Halls of Amenti from opening, so the acceleration of the human
           genetic blueprint does not take place. The Resistance will lose control
           over their future D-4 stronghold if present human populations can assem-
           ble the fourth and fifth DNA strands. For this reason the Resistance has a
           vested interest in keeping the Halls of Amenti closed. Without the Fre-
           quency Fence it will be difficult for them to stop the Bridge Zone project,
           the opening of Amenti and the accelerated genetic evolution it will bring.
           If they cannot stop these events they will attempt to gain dominion over
           the D-3 “phantom Earth”, to begin rebuilding their strong hold from D-3
           after 2017, a plan that is likely to fail if Guardians decide to enforce a ban 
          on Resistance presence.  
             If   the  Frequency  Fence   plan  is  stopped  there    is  a  strong   likelihood  that Resistance
          forces will leave of their own accord.  If the Frequency Fence plan is not
     stopped, humans remaining on D-3 phantom Earth will still remain vul-
  208  
      
     
 
       

                                                           
                                                        The Amenti Ascension Program Schedule    
   nerable to Resistance in filtration. The Frequency Fence plan can still be
    averted if the Interior Government stops all cooperation with the Resis-
  tance EBEs and refuses to allow the 2003 experiment to take place. 
      In the event that the public landing of 2001 does occur, the Resistance
       Frequency Fence plan is still operational, and Earth populations will have
   until 2004 to assemble DNA  to the 3.75 accretion level in order to protect
     themselves from the Frequency Fence. If the Frequency Fence plan is
   operational Guardian V isitors may stage mass sighting “ ﬂy-by’s”, anytime
   between 1998-2004, in order to warn the populations that Earth changes
   will be coming due to the Frequency Fence. In the event that the Fre-
    quency Fence is averted by 2004, and severe Earth changes are not
   expected, Guardians will NOT stage mass “fly-by’ s”. W e are hoping the
   Frequency Fence plan will be abandoned. Humanity can help this effort
   by trying to assemble and activate the fifth DNA strand in 8% of the pop-
    ulations by 2001. Presently an estimated 0.24% of global populations have
     the fifth strand assembled and activated. Reaching 8% by 2001 is not
   likely , but it is not impossible if humanity really tries to reach this goal. If
    this goal can be reached the Dracos-Zeta Resistance takeover plan can be
     stopped before it is put into action.  
  9.  January 2002: Keepers of the Blue and Violet Flames End Blue Wave
   Infusions. Keepers of the Blue Flame Begin Violet W ave Infusions.
    The Keepers of the Blue and V iolet Flames will complete their Blue W ave
   infusions in 1/2002 and the Keepers of the Blue Flame will begin V iolet
      W ave Infusions. The Keepers of the Blue and V iolet Flames complete
   their D-5/D-6 Blue W ave Infusions that began on 6/26/1998. The Keepers
   of the Blue Flame are halfway through their D-5 Pleiadian-Soul Seat Acti-
   vation and their D-6/D-7 V iolet W ave Infusion begins. Through these D-
   6/D-7 W ave Infusions, D-6 base tone and D-7 overtone frequencies, and
   imprints for DNA  strands 6 and 7, enter into the morphogenetic fields of
  the Keepers of the Blue Flame. The Keepers of the Violet Flame will begin
  their D-5 Pleiadian-Soul Seat Activation on 1/1/2005 and their V iolet
   W ave Infusions will begin in 1/2007. Shifting to the Bridge Zone Earth
    requires completion of the Blue W ave Infusion, activation of half of the
   fifth DNA strand, completion of the Solar-Heart Star Activation and half
   of the Pleiadian-Soul Seat Activation. The D-5 Pleiadian Activation
   becomes available to the masses (those who were not born with the fifth
    DNA  strand imprint) on 9/9/2004, with the birth of A vatar 4 and the
  release of the corrected fifth DNA strand imprint through Earth’s grid. At
  this time fifth strand assembly can begin for those who completed fourth
         strand assembly and Heart Star Activation through the Solar Activation.
     The masses will not be able to complete the D-5 Pleiadian Activation
   until the 5/5/2012, following the birth of A vatar 6 and the activation of
       the fifth-strand codes.  
209     
                                                                    
  
                                                                                                                                     
                                                                                                                     
           

          
             Things to Come
    10. June 2002: Earth Begins Fir st Stellar Wave Infusion —The Blue Wave
   Infusion.  
    Earth is halfway through its D-4 Solar Activation, as the frequencies of
    the D-5/D-6 Blue W ave Infusion descend through the Pleiadian-Alcyone
     and Solar Spirals, beginning Earth’ s first Transmutative Stellar Wave lnfu-
    sion, the D-5/D-6 Blue W ave Infusion. Through these D-5/D-6 W ave
  Infusions, D-5 base tone and D-6 overtone frequencies enter into Earth’ s
 core morphogenetic field. Earth’s Blue Wave Infusion will complete in 6/
  2006, when Earth’ s V iolet W ave Infusion begins. In 6/2004 the D-5 Pleia-
  dian-Alcyone Spiral comes into alignment with the D-4 Solar Spiral,
  completing Earth’s D —4 Solar Activation and beginning Earth’s D-5 Pleia-
 dian Activation. Earth will complete six Stellar W ave Infusions between
  6/2002 and 6/2017. Three of these infusions will occur concurrently with
    the final three Stellar Activations within a 3-day period that will fall
  somewhere between 5/5/2017 and 6/30/2017.                                                                                                                                                                           2003 Zeta Experiment 
     11. August 12, 2003: Dracos-Zeta Resistance and Covert Government
   Dimensional Blending Experiment.  
    The Dracos-Zeta Resistance hopes to coerce the Interior Government to
    orchestrate a Dimensional Blending Experiment through top secret mili-
     tary operations. The experiment resembles the Philadelphia Experiment
    of 1943 and the Montauk Project of 1983. The Resistance’ s covert moti-
   vation for the 2003 experiment is to create a rip in space-time that will
    connect with space-time rips that were made during the experiments in
     1943 and 1983, so they may cloak large numbers of spacecraft while bring-
    ing them into underground bases. The presence of these underground
   fleets at three different time intervals, is necessary for the Resistance to
    broadcast the EM pulses of their intended Frequency Fence. If the Interior
     Government and world military organizations can be convinced to stop any
       such dimensional blending experiments, especially during the months of July
   through October of 2003, the Frequency Fence agenda will be abandoned. 
  12. Spring 2004: Dracos-Zeta Resistance to Begin EM Pulses of Frequency
     Fence.  
    If the Dracos-Zeta Resistance is successful in motivating the 2003 experi-
  ment and the Earth’s grid is not yet at 3.75 accretion, they intend to begin
    broadcasting the base EM pulses of the Frequency Fence, from several
    underground base locations. The Resistance will have introduced an
    undetectable organic element to mass water supplies by this time, which is
   needed to repress the human body’ s natural immunological response to
    the foreign EM pulses used in the Frequency Fence. If transmission of the
     Frequency Fence base pulses begins, an undetectable ULF “phantom”
     electrical pulse will begin to be transmitted through Earth’ s grid, into the
   210  
                   
       

                                                   
                                                                        The Amenti Ascension Program Schedule
bio-energetic and electro-chemical systems of humans and into mass elec-
trical power stations. The phantom pulse will follow the natural ﬂow of
electricity from main power generation plants into all electrical systems
drawing power from those plants, and will thus be transmitted through all
commercial and residential electrical devices. The ULF EM phantom
pulse will create a subtle disruption within the bio-energetic fields of
humans, which will manifest in the body as a bio-neurological perceptual
block,  through which the human conscious and sub-consciousness minds
can be blocked from translating perceptual data from all but a few select
dimensional frequency bands.  A “perceptual harness" on human conscious-
ness will result, through which the Resistance can transmit Holographic Inserts
and subliminally impulse human behavioral response patterns directly through
the sub-conscious mind and physical body .    
     The human body has a natural immune response to such electromag-
netic invasion, which the Resistance can repress by introducing a certain
organic elemental compound into the water supply, and by transmitting
speci fic wave spectrums of light directly into the human optical facilities.
Technologies such as broadcast television are intended as vehicles to carry
the subliminal light-spectrum patterns into the human optical facilities.
Common radio waves are also intended as carriers of subsequent EM
pulses, which will serve to reinforce the bio-neurological programming of
the Frequency Fence.    
     The Resistance will attempt to use your own technologies against you.
After approximately six years of such covert electromagnetic manipula-
tion, the contrived electromagnetic imprint will be strong enough to over-
ride the natural DNA imprint within the personal morphogenetic field.
The perceptual harness will manifest as a genetic mutation within the
human DNA, a mutation that will be genetically passed on through
breeding. The Frequency Fence is a powerful, advanced, EM pulse tech-
nology of which the Resistance is in possession and now intends to use on
the human populations. Human technology presently does not have such
command of EM pulse mechanics, and so will be unable to create techno-
logical protection from the Frequency Fence.  
          However, humanity does possess the natural ability to accelerate the genetic
code, through which natural immunity to the Frequency Fence, the water
additive and the subliminal, digital light-spectrum transmissions can be
created.  It is much easier to prevent the Frequency Fence from affecting the bio-
neurological system, by building this natural immunity before the EM pulse
transmissions begin, than it will be to reverse the effects of these transmissions
once the broadcasting is initiated . If the Frequency Fence plan is not averted
by 2004, the Frequency Fence will be operational by 2006, at which time
the Resistance will begin broadcasting mass Holographic Inserts —five-   
      211                                                                                                         
                                                                                                                        
                                                                                                                          

                        Things to Come
             sensory perceptual —illusions-into Earth’s   atmosphere, through which the
        masses can be directed as the Resistance desires. Can you understand why
        we of the Guardian Alliance are trying to educate your race in regard to
       the very real ET technologies the Resistance plans to use against you? We
          are not trying to frighten you. W e are hoping you will be mature enough
          to comprehend the consequences of such technologies before you
          unknowingly fall under this in ﬂuence. You have the power to stop the Fre-
       quency Fence now , by taking command of your personal evolutionary
         imprint. Y ou can protect yourselves if you are willing to learn how to do
            so.  
                                                                                                  Earth's Pleiadian Activation
        1 3. June 2004: D-5 Pleiadian-Alcyone Spiral Aligns with D-4 Solar Spiral.
           Earth’s Fifth Vortex—Machu Picchu, Peru—-Opens. Earth Completes
       Solar Activation and Begins Pleiadian Activation. The Sphere of
                   Amenti Begins Transmitting D-5 Frequency into Earth’s Grid.  
         The Sphere of Amenti completes opening its D-4 frequencies into Earth's
         morphogenetic field, Earth’s fourth primary vortex at Giza is fully opened
        and activated and the natural seal on Earth’ s fifth primary vortex begins to
        open and activate as the D-5 Alcyone spiral aligns with the D-4 Solar Spi-
         ral. Earth’ s fifth primary vortex is located in Machu Picchu, Peru. The
        Sphere of Amenti begins transmitting its D-5 frequencies into Earth’ s grid
        as Earth completes its D-4 Solar Activation and begins its D-5 Pleiadian
         Activation. The morphogenetic wave continues build. The particles of
        Earth’ s D-2 elemental kingdom begin to merge with T ara’ s D5 anti-parti-
          cles, Earth's D-3 atmospheric anti-particles begin to merge with Tara’s D-6
        particles. Earth’ s D-2 and D-3 Merkaba Field begin to merge with T ara’ s
        D-5 and D-6 Merkaba Field, through the pathway of the Alcyone spiral.
        By the end of its Pleiadian Activation in 6/2008, Earth will complete the
        final 2/3 of its shift into the HU-2 time cycles, in preparation for merger
          with Tara on 5/5/2012.  
      14.  September 9, 2004: Tentative Birth of Avatar 4—Tenth-level Avatar.
         Will Align DNA Strand 5 with 12-strand Pattern. Corrected Strand 5
           Imprint Begins Transmitting through Earth’s Grid.  
        The fourth of six Silent A vatars is scheduled to be born; the birth can
       occur before this date, following the birth of A vatar 3 on ]une 26, 1998,
        but must take place by September 9, 2004, to realign the fifth DNA strand
        imprint in the Sphere of Amenti morphogenetic field, before this strand
        imprint begins transmitting through Earth’ s grid on 9/9/2004. The fourth
        avatar is a D-10 soul essence from HU-4, a tenth-level avatar, with 10-
       dimensional frequency bands activated in its genetic code. This individual
        will be born with strand 10 fully activated. As this soul essence passes
       through the Sphere of Amenti, the imprint for DNA  strand 5 will realign
     212  
                    
              

    
                                                The Amenti Ascension Program Schedule  
with the 12-strand DNA pattern, and the fifth strand imprint will begin
transmitting through Earth’s grid. The Palaidor, Amenti and Zeta Seals
will be fully released from the DNA in all whom worked to assemble the
fourth strand. Though the corrected fifth strand begins assembly in 2004,
for most of the populations it will not fully activate, or plug into the lower
strands and become operational, until 5/5/2012, when the Blue Flame is
embodied on Earth. The D-5 Pleiadian Activation pre-activation strand 5
assembly becomes available to the masses on 9/9/2004, but completion of
this activation and activation of the Soul Seat Star Crystal, will not be
available to the masses until the fifth strand activates after 5/5/2012.
Completion of the Pleiadian Activation and assembly and activation of
the fifth DNA strand allows the consciousness to achieve the second level
of soul integration, the Soul Seat Activation, and begins the process of
cellular transmutation through which the body can raise its particle pulsa-
tion rhythm into the HU-2/D-5 time cycle for teleportation through the
Halls of  Amenti.  Ascension to Tara requires completion of the Pleiadian Acti-
vation, full activation of strand 5, completion of  half of the Violet Wave Infusion
and activation of the Soul Seat Star Crystal.  
        15.  2005-2017: Second Birth Wave of Indigo Children.  
          The second wave of 5,500 D-6 soul essence —Root Race 7: Paradisian
           children, who possess the imprint for DNA  strand 6, will birth on Earth.
         They will reach maturity and activation of the sixth DNA  strand at the
         age of 12, between 2017-2029, to become Place Holders that ground D-6
              frequency on Bridge Zone Earth following the 2012-2017 ascension
               period.  
    16.  January 1, 2005: Keepers of the Blue Flame Begin Sixth DNA Strand,
             D-6 Sirian-Earth Star Activation. Keepers of the Violet Flame Begin
               Fifth DNA Strand, D-5 Pleiadian-Soul Seat Activation . 
   The Keepers of the Blue Flame complete their D-5 Pleiadian -Soul Seat
    Activation and begin their D-6 Sirian-Earth Star Activation. Through
    the Sirian Activation they will assemble and activate the sixth DNA
   strand and complete the third level of soul identity integration, in prepa-
    ration for embodying Tara’s Blue Flame morphogenetic field on 5/5/2012.
    The Keepers of the V iolet Flame begin their D-5 Pleiadian-Soul Seat
    Activation and assembly and activation of their fifth DNA strand, begin-
    ning the second level of soul identity integration, in preparation for
         embodying Gaia’ s V iolet Flame morphogenetic field on 1/1/2017.
    17. June 2006: Earth Completes Blue Wave Infusion and Begins Violet
  Wave Infusion.  
Earth will be halfway through its D-5 Pleiadian Activation, the D-5/D-6
Blue Wave Infusion that began in 6/2002 completes and the D-6/D-7 Vio-
let Wave Infusion begins. Through these D-6/D-7 Wave Infusions, D-6
        213  
 
                                                                                                                                                                                                                            
                                                                                                                                                                                                         
                            

                 Things to Come
      base tone and D-7 overtone frequencies are entered into Earth’s core mor-
      phogenetic field. Earth will complete its D-6/D-7 Violet Wave Infusion,
         and begin its D-7/D-8 Gold Wave Infusion in 6/2010.  
         18. 2006: Dracos-Zeta Resistance to Begin Broadcasting Holographic
        Inserts, if Frequency Fence is Established in 2004.  
     Dracos-Zeta Resistance plans to begin broadcasting mass Holographic
      Inserts through their Frequency Fence in order to direct populations away
        from the path of ascension and to establish full covert control over global
      social and economic structures. Once populations are under perceptual
       control Resistance members can walk among humans undetected. They
      plan to create various types of geographical disturbances that interfere
       with the grid merger between Earth and Tara. If it was not for the Bridge
       Zone Project these activities could have stopped the opening of the Halls
      of Amenti. The Frequency Fence and intended grid disruptions can still
       cause Earth changes between 2012-2017, but the Halls of Amenti will
        remain stable as long as Earth's core morphogenetic field reaches the 3.5
       accretion level necessary for Earth to enter the Bridge Zone pulsation
       rhythm in 2012. Only the phantom Earth that returns to the D-3 time
         cycle after 2017 will be susceptible to Resistance control and the massive
       Earth changes that could result from the Frequency Fence and related
        activity. Humans with an accretion level below 4.5 (all of the fourth DNA
        strand assembled and activated plus half of the fifth strand) will end up in
      this future D-3 time continuum after 2017. The Earth changes, Holo-
         graphic Inserts and mental take over can be stopped in this D-3 time cycle
      if humanity can help the Guardians stop the Resistance from activating
        the Frequency Fence in 2004.  
  19. January 2007: Keepers of the Blue Flame Begin Gold Wave Infusions.
           Keepers of the Violet Flame Begin Violet Wave Infusions.   
   The Keepers of the Blue Flame are half way through their D-6 Sirian-
      Earth Star Activation, the D-6/D-7 V iolet W ave Infusion that began in 1/
      2002 completes and the D-7/D-8 Gold W ave Infusion begins. Through
      these D-7/D-8 W ave Infusions, D-7 base tone and D-8 overtone frequen-
         cies, and imprints for DNA  strands 7 and 8, enter into the morphogenetic
       fields of the Keepers of the Blue Flame. The Keepers of the Violet Flame
      are half way through their D-5 Pleiadian-Soul Seat Activation, the D-5/
      D-6 Blue W ave Infusion that began in 2002 completes and the D-6/D-7
      V iolet W ave Infusion begins. Through these D-6/D-7 W ave Infusions, D-
        6 base tone and D-7 overtone frequencies, and imprints for DNA strands 6
     and 7, enter into the morphogenetic fields of the Keepers of the Violet
          Flame.  
    214   
                   
             

                                                            
                                                                           
                                                                          The Amenti Ascension Program Schedule                                                                                                
                                                            Earth’s Sirian Activation                 
                 20.  June 2008: D-6 Sirian Spiral Aligns with D-5 Pleiadian-Alcyone Spi-           
                             ral. Earth’s Sixth Vortex—Caucasus Mountains, Russia —Opens. Earth          
                    Completes D-5 Pleiadian Activation and Begins D-6 Sirian Activation.  
       The Sphere of Amenti Begins T ransmitting D-6 Frequency through 
                    Earth’s Grid. Earth Completes Shift into HU-2 Time Cycles.  
          The Sphere of Amenti will complete its  opening of D-5 frequencies into
        Earth’s morphogenetic field, the fifth primary vortex in Peru will be fully
     opened and activated, and the natural seal on the sixth primary vortex
        will  open. Earth’s  sixth     primary  vortex  is located  in   the  Caucasus Moun-
    tains in Russia. The Sphere of Amenti begins transmitting D-6 frequency  
   through Earth’s grid, as the D-6 Sirian Spiral aligns with the D-5 Alcyone                  
  Spiral. Earth completes its D-5 Pleiadian Activation that began in 6/2004
       and begins its D-6 Sirian Activation.  
            At the end of its Pleiadian Activation on 6/2008, Earth completes its ﬁnal 2/3
             shift into the HU-2 time cycles, in preparation for the merger of the grids of
         Earth and T ara on 5/5/20 1 2 . The morphogenetic wave continues to build
        as T ara ’ s D-4 and D- 5 particles begin to merge with Gaia ’ s D- 7 and D-8
          anti-particles, and Tara’s D-4 and D-5 Merkaba Fields begin to merge with
          Gaia ’ s D- 7 and D-8 Merkaba Fields. T ara ’ s D-4 and D- 5 particle base
                moves  into  the  D-7 and D-8 time  cycles  of  HU-3 while  Earth’s temporary
        shift into the HU-2 time cycles completes.  
             21. July 22, 2008: Tentative Birth of Avatar 5—11th-level Avatar. Will
          Align DNA  Strand 6 Imprint with 12-Strand Pattern. Corrected
          Strand 6 Imprint Begins T ransmitting through Earth’s Grid and the
             Templar Seal Can Release from DNA.  
          The fifth of six Silent A vatars is to be born on this date. The birth can
                 occur    earlier, following birth of Avatar 4 on 9/9/2004, but  it  must occur  by
             7/22/2008, when the sixth DNA  strand imprint begins transmitting
              through   Earth’s   grid. The birth of     Avatar    5   is presently  scheduled for 7/22/
        2008. This avatar is a D-11 soul essence from HU-4, an 11th-level avatar,
        with 11-dimensional frequency bands activated in its genetic code. This
         individual will be born with strand 11 fully activated. As this soul essence
         passes through the Sphere of Amenti the imprint for DNA  strand 6 will
            realign with the 12-strand pattern and the sixth strand imprint will begin
            transmitting through Earth’s grid.  
                 Though the sixth strand will assemble  in  2008, in those  who  have   assembled
                               strands 5 and below, the  sixth strand will not activate for most people until after
                   the Violet Flame embodies on Earth in 2017.  Assembly and activation of the
         sixth DNA  strand allows the consciousness to achieve the third and final
       level of soul integration, the Earth Star Activation,  at which time the
         identity can choose to transmute into etheric form on D-7 Gaia, to begin
       215  
                                                                                                                                       
                                                                                                                                        

                  Things to Come       
    embodiment of the over soul identity. Assembly of the sixth DNA strand
     releases the D-6 Templar Seal , which made bodily ascension impossible
      for those with this genetic con figuration. The Templar Seal was placed on
     certain race strains in 8000 BC, and created genetic distortion in many
           others through interbreeding. Release of the T emplar Seal allows one to
       ful fill activation of the sixth DNA strand for ascension to Gaia and
       beyond.  
  22. January 2009: Keepers of the Blue Flame Begin Seventh DNA Strand,
    D-7 Arcturian-Core Star Activation. Keepers of the Violet Flame Begin
      Sixth DNA Strand, D-6 Sirian-Earth Star Activation.  
    The Keepers of the Blue Flame complete their D-6 Sirian-Earth Star Acti-
    vation and will activate their seventh DNA  strand beginning their D-7
      Arcturian-Core Star Activation, which begins embodiment of the first
          level of the over-soul identity , in preparation for embodying the Blue
     Flame in 2012. The Keepers of the Violet Flame complete their D-5 Pleia-
      dian-Soul Seat Activation and will activate their sixth DNA  strand to
     begin their D-6 Sirian-Earth Star Activation, beginning the third level of
     soul identity integration, in preparation for embodying the V iolet Flame
        in 2017.  
  23. June 2010: Earth Begins Gold Wave Infusions.  
     Earth is half way through its D-6 Sirian Activation, the D/6/D-7 V iolet
       W ave Infusion that began in 6/2006 completes and the D-7/D-8 Gold
      W ave Infusion begins. Through these D-7/D-8 W ave Infusions, D-7 base
    tone and D-8 overtone frequencies are entered into Earth’ s core morpho-
       genetic field. 
  24. June 2011: Keepers of the Blue Flame Begin Silver Wave Infusions.
        Keepers of the Violet Flame Begin Gold Wave Infusions.  
       The Keepers of the Blue Flame are half way through their D-7 Arcturian -
    Core Star Activation, the D-7/D—8 Gold W ave Infusion that began in 1/
      2007 completes and the D-8/D-9 Silver W ave Infusion begins. Through
    these D-8/D-9 W ave Infusions, D-8 base tone and D-9 overtone frequen-
       cies, and imprints for DNA  strands 8 and 9, enter the morphogenetic
          fields of the Blue Flame Holders. The Keepers of the Violet Flame are half
          way through their D-6 Sirian-Earth Star Activation, the D-6/D-7 V iolet
           W ave Infusion that began in 1/2007 completes and the D-7/D-8 Gold
               W ave Infusion begins. Through these D-7/D-8 W ave Infusions, the D-7
           base tone and D-8 overtone frequencies, and imprints for DNA  strands 7
        and 8, enter the morphogenetic fields of the Keepers of the Violet Flame.
   25. January 1, 2012: Earth Completes D-6 Sirian-Earth Star Activation.
     Earth’s Seventh V ortex—Andes Mountains, South America-—Opens.
       Amenti Begins Transmitting D-7 Frequency through Earth’s Grid. Blue
      Flame Begins its Final Approach to Earth through the Alcyone Spiral
 216 
  
  

                                               
                                                                    The Amenti Ascension Program Schedule
Keepers of the Blue Flame Activate Eighth DNA Strand and Begin D-8
Orion-Earth Core Activation. Keepers of the Violet Flame Activate
Seventh DNA Strand, D-7 Arcturian-Core Star Activation.  
Earth completes its D-6 Sirian Activation, that began in 6/2008 and D-6
frequencies from the Earth’s core morphogenetic field begin transmitting
through Earth’s grid. As this occurs, D-7 frequencies from the Sphere of
Amenti begin transmitting through Earth’s grid and the Sphere of Amenti
completes opening its D-6 frequency into Earth’s morphogenetic field.
Earth completes the first 3 Activations of its Transmutative Stellar Acti-
vation cycle, and will not begin its fourth D-7 Arcturian Activation until
the D-7 Arcturian Spiral aligns with the D-6 Sirian spiral on day one of
the Three-day Particle Conversion Period between 5/5/2017 and 6/30/
2017.  
    By 1/2012 the sixth primary vortex in the Caucasus Mountains will be
fully open and activated and the natural seal on the seventh primary vor-
tex will begin to open and activate. Earth’s seventh primary vortex is
located in the Andes Mountains of western South America. The Blue
Flame of Amenti begins its final approach to Earth through the Alcyone
spiral. The Keepers of the Blue Flame complete their D-7 Arcturian -
Core Star Activation, fully activating the seventh DNA strand to become
seventh-level avatars, embodying the first level of the oversoul identity.
The Keepers of the Blue Flame begin activating the eighth DNA strand,
initiating their D-8 Orion-Earth Core Activation, which allows integra-
tion of the second level of the over-soul identity to become an eighth-
level avatar. Completion of the D-7 Arcturian-Core Star Activation
causes the Core Star crystal energy center within the body (above the
navel, below the third Solar Plexus chakra) to transmit D-7 frequency.
The bodies of the Flame Keepers become transmitters of UHF light and
sound, as their bio-energetic fields fill with D-7 frequency. The Flame
Keepers become conduits for D-7 energies, which ﬂow to Earth from the
Arcturian Spiral, through the Sirian, Pleiadian-Alcyone and Solar Spirals.
Through the bodies of the Flame Keepers achieving Arcturian-Core Star
Activation, D-7 frequency runs through Earth’s core, preparing Earth for
its 2017 alignment with the Arcturian Spiral and beginning the separa-
tion of particle fields within the Earth’s matter-body. Following the Core
Star Activation, the Blue Flame Keepers hold the power within their bio-
energetic fields to create seventh strand DNA activations in others, and to
assist others of lesser DNA strand assembly in passing through the Halls of
Amenti, once the Halls have opened. The D-8 Orion and D-9 Androm-
eda Activations allow the Flame Keepers to become transmitters of D-8
and D-9 frequency, capable of initiating Orion and Andromeda Activa-
tions in others and through which the Earth Core prepares to align with
   217  
                                                                                                                 
  

 Things to Come  
        the D-8 Orion and D-9 Andromeda Spirals in 2017. As the Keepers of the  
       Blue Flame begin their D-8 Orion-Earth Core Activation, the Keepers of  
       the Violet Flame begin their D-7 Arcturian-Core Star Activation.  
    26. March 2012: Keepers of the Blue Flame Begin Blue-black Liquid Light  
     Wave Infusion s.  
   The Keepers of the Blue Flame are half way through their D-8 Orion- 
    Earth Core  Activation, the D-8/D-9 Silver Wave Infusion that began in 6/       
     2011 completes and the D-9/D-10 Blue-Black Liquid Light Wave Infusion         
          begins. Through these D-8/D-9 W ave Infusions, the D-9 base tone and D-
          8 overtone frequencies, and imprints for DNA strands 9 and 10, enter into  
        the morphogenetic fields of the Keepers of the Blue Flame.  
   27. May 5, 2012, 12:01 AM: Birth of Avatar 6—12th-level Avatar. Will  
      Align DNA Strand 7 Imprint with 12-strand Pattern. Templar-Axion  
    Seal Releases from Human DNA as Corrected Strand 7 Imprint Begins  
     Transmitting through Earth’s Grid.  
      The sixth of six Silent Avatars will be born precisely at this time, passing  
 through the Sphere of Amenti into fetal integration at 12:01 am, on 5/5/  
      2012. This is a D-l2 soul essence from HU-4, a 12th-level avatar, which is  
    the highest level of identity that can be embodied through the human
       genetic code. Jesheua-12 (12 BC-27 AD), of   the  soul  identity   Sananda, was
     the last level 12 avatar to incarnate on Earth . The sixth avatar will be born  
     with 12-dimensional frequency bands activated in his genetic code, a fully  
      activated DNA  strand 12. As his soul essence passes through the Sphere
  of Amenti, the imprint for DNA strand 7 will realign with the 12-strand
pattern, and the seventh strand imprint will begin transmitting through                     
Earth’s grid. As the seventh DNA strand imprint aligns and activates,  
the  D-7 “666”  Templar-Axion Seal , which imposed repeated reincarnation
  for humans who carried this DNA mutation, is released from Templar-
   Axion sealed humans who begin assembling the seventh DNA strand .                                                Halls of Amenti Open  
              28.  May 5, 2012: The Grids of Earth and Tara Begin to Merge and  the  
           Morphogenetic Wave Prepares to Crest. The Keepers of the Blue Flame                                                                                                                                            
          End D-8 Orion-Earth Core Activation and Begin D-9 Andromeda-                                                                                                                                       
             Galactic Core  Activation. The Blue Flame of Amenti Embodies within
the Keepers  of  the Blue Flame. Spontaneous Mass Awakening Occurs.
The Halls of Amenti Open and Ascensions Begin. The Three Flame
Holders Are Called to Giza to Activate the Hall of Records.
The grids of Earth and Tara begin to merge as the morphogentic wave
prepares to crest. The Keepers of the Blue Flame complete their D-8
Orion-Earth Core Activation, becoming eighth-level avatars and begin
their D-9 Andromeda-Galactic Core Activation. As the ninth DNA
strand begins activation and assembly, the third level of the over-soul
   218  
  
 

                                                    
                                                                      The Amenti Ascension Program Schedule
embodies and the Keepers of the Blue Flame become ninth-level avatars.
The Keepers of the Blue Flame will complete their D-9 Andromeda Acti-
vation, to become ninth-level avatars, on day one of the Three-day Parti-
cle Conversion Period between 5/5/2017 and 6/30/2017. On 5/5/2012 the
Blue Flame of Amenti descends through the Alcyone spiral and into
embodiment within the Keepers of the Blue Flame. Embodiment of the
Blue Flame takes place through the primary Flame Holder, who magneti-
cally draws the Blue Flame from the Alcyone spiral and into her bio-ener-
getic field and body. Flame Holders carry a speci fic magnetic base tone
within their DNA that allows the bio-energetic system to become highly
magnetic, when this recessive gene is activated. Without this extremely
rare recessive gene, the human body would be ripped apart in attempting
to draw energy directly from the Alcyone spiral while the Blue or Violet
Flames are descending. Flame Holders are incarnated on Earth during
appropriate times, after carefully selecting a parental lineage (via
Palaidorian Birthing Contracts) that carries this recessive gene, speci fi-
cally to fill this role. These individuals are predestined via over-soul con-
tracts, to ful fill this role.   
There are three Flame Holder positions to fill, that of the D-2 Orange-
gold Flame (requiring male embodiment) and those of the D-5 Blue and
D-7 Violet Flames (female embodiments). For each position there are only
three individuals born that can fill this role, for a total of nine individuals
on the planet at any one time, who will carry this rare recessive gene. The
primary position is held by a Flame Holder who is appointed by the Galac-
tic Council of HU-4 and the second and third positions serve as “back-
up”, in the event that the primary Flame Holder cannot ful fill the role.
The primary Flame Holder chooses the souls who will serve as back up and
they incarnate during the same time period as per these soul agreements.
The Keepers of the Flames are likewise born into their roles via soul agree-
ments and will begin to awaken to their greater mission once it is time for
their service to begin. The Flame Keepers and Holders have begun to
awaken to their identity over the last 15 years. Once the Blue Flame
Holder has drawn the Blue Flame from the Alcyone spiral, the Flame
Holder then down-grades the frequencies of the Blue Flame through her
bio-energetic field and transfers the frequencies of the Blue Flame into the
Flame Keepers via the fourth/Heart chakra. Once the Blue Flame frequen-
cies stabilize in the morphogenetic fields of the Flame Keepers, an intense
infusion of HU-2 frequencies spreads through the Amenti morphogenetic
field and through the Earth’s grid, which allows rapid acceleration of fifth
and sixth DNA strand assembly to occur throughout the populations who
have begun assembling the fifth and sixth strands. The seventh strand will
begin to assemble in those who have assembled strands 6 and below.
Strand 5 rapidly begins to activate triggering a spontaneous expansion of
   219  
                                                                                                                                           
                                                                                                                    

                     Things to Come
    multidimensional awareness and awakening to multidimensional memory
     and identity within the populations who assembled the fifth strand.
     Strands 6 and 7, which have been assembled, will remain dormant until
    activation during the Three-day particle conversion period between 5/5/
      2017 and 6/30/2017.     
     As the grids of Earth and Tara begin to merge, the Halls of Amenti, within
     the Sphere of Amenti at Earth’ s core, begin to open and people who have
     assembled the fifth strand and above can begin passing through the portals
       that connect to the Halls of Amenti and T ara. At this time, forward
        through 2022, people on the ascension path to T ara will be guided to the
      appropriate portal or interdimensional Transport locations for transfer to
     T ara. Just following the birth of A vatar six on 5/5/2012, the three primary
     Flame Holders and their support team will be called to Egypt to activate
      the Hall of Records portals. Numerous groups will try this feat prior to this
     time, but only the three Flame Holders possess the needed frequency
     codes in their bio-energetic fields to allow them to serve as conduits for
      downloading the electronic transmissions from the Dora-T eura Matrix
      and Akashic Record. Once the portals between the Sphinx, Great Pyra-
          mid and Earth's core open, universal memory comes “on line” within the
          Sphere of Amenti and the Sphere of Amenti prepares to release this con-
          tinual ﬂow of electronically coded data into Earth’s grid, where it can be
          picked up through the human bio-energetic field and translated into con-
            scious information. Reincarnational and race memory will become avail-
       able to people who have assembled the fourth DNA strand and above.  
  29. December 21, 2012: The Morphogenetic Wave Begins Cresting, Earth
       Begins Passing into the Holographic Beam and Photon Belt. Earth’s
       Particle Base Begins to Separate, Magnetic and Electrical Poles of Earth
     and T ara Reverse, Angular Rotation of Particle Spin Shifts 45°. The
     Grids of Earth and Tara Continue to Merge. Earth’s Fastest Pulsating
       Particles Begin Transfer to Hyper-space and the Hall of Records Begins
       Transmitting Data through Earth’s Grid.  
       As the morphogenetic wave begins cresting, Earth’ s particle base begins
      separating in to fields of fast, moderate and slow pulsation. The fastest pul-
      sating particles begin to transfer from Earth, through Earth’ s core and the
       Alcyone spiral, into the higher-dimensional morphogenetic fields/hyper-
      space. Earth begins passing into the Holographic Beam, Earth’ s overtone
       particles pass into the Photon Belt and all of Earth’ s electrical overtone
            particles and T ara’ s base tone anti-particles enter hyper-space. The base
           tone particles left in Earth’ s grid begin to blend with the overtone anti-
          particles left in T ara's grid, the polarity of the particles and anti-particles
          temporarily reverses and the angular rotation of particle spin shifts 45°.
           Earth’ s magnetic poles reverse and shift 45° as T ara’ s electrical poles
             reverse and counter-shift 45°. Between 12/21/2012 and 6/30/2017 the D-1
            220 
   

                                                                                     
                                                                      The Amenti Ascension Program Schedule
        
     base tone particles of Earth progressively merge with the D-4 overtone
      anti-particles of T ara, within the pulsation rhythm of the D-4 time cycle.
       Earth’ s particle base temporarily raises to an accretion level of 4, its ele-
        mental particle base raises to 5-accretion and its atmospheric particle base
        raises to a 6-accretion level. Earth will remain in the D-4 time cycle until
        the morphogenetic wave crest ends at the half cycle point in 2017 and the
       particle fields make their final transition into their respective time cycles.
        The   reversal and shifting of the magnetic and electrical poles of Earth and Tara
           does not create a physical pole reversal or shift, because the action of reversal
      and shift of  Earth  and  Tara are simultaneous and counter-balance each other, as
         long as both grids are properly aligned . In areas where the grids are not bal-
     anced and aligned, tectonic cracking and shifting, and volcanic activity of
     varying degrees may result. The reversal of particle activity will be prima-
     rily undetectable to earthly equipment and human perception, as such
    devices are also composed of particles, which will shift along with Earth’s
    dimensional perception. There will be some subtle observable variance in
         Earth’s magnetic fields, and an increase in gamma wave activity.  
      The Hall of Records  will begin transmitting data through the Sphere of
     Amenti and Earth’ s grid, releasing universal memory into the planetary
    memory banks of Earth’ s morphogenetic field, making personal and race
    incarnational memory available to humans with fourth DNA  stand assem-
    bly and above (humans with lower DNA  strand assembly will not be able
    to translate or synthesize this higher frequency digital data through their
        operational neurological system, into conscious perception).  
  30. January 2013: Keepers of the Violet Flame Begin Silver Wave Infu-
           sions.  
      The Keepers of the V iolet Flame are half way through their D-7 Arc-
      turian- Core Star Activation, the D-7/D-8 Gold W ave Infusion that
      began in 6/2011 completes and the D-8/D-9 Silver W ave Infusion begins.
       Through these D-8/D-9 W ave Infusions, the D-8 base tone and D-9 over-
       tone frequencies, and imprints for DNA  strands 8 and 9, enter into the
         morphog enetic fields of the Violet Flame Keepers.  
  
        31. January 2014: Keepers of the Violet Flame Activate Eighth DNA
       Strand, D-8 Orion-Earth Core Activation. The Keepers of the Blue
          Flame Begin Silver-black Liquid Light Wave Infusions.  
        The Keepers of the Violet Flame will complete their D-7 Arcturian-Earth
       Core Activation, activating the seventh DNA  strand and becoming sev-
       enth-level avatars, that can initiate seventh strand Arcturian Activations
       in others. In 1/2014 the Keepers of the V iolet Flame will activate their
      eighth DNA  strand and begin their D-8 Orion-Earth Core Activation to
       become eighth-level avatars in 1/2017, when their D-8 Orion Activation
    221                                                                                                                                       
 

        
       Things to Come           
    completes; just as the Keepers of the Blue Flame became eighth-level ava-
     tars on 5/5/2012. In 1/2014 the Keepers of the Blue Flame are half way
     through their D-9 Andromeda-Galactic Core Activation, the Blue-Black
     Liquid Light Wave Infusion that began in 3/2012 completes and the D-10/
     D-11 Silver-Black Liquid Light W ave Infusion begins. Through these D-
     10/D-11 W ave Infusions, the D-10 base tone and D-11 overtone frequen-
     cies, and imprints for DNA  strands 10 and 11, enter into the morphoge-
     netic fields of the Blue Flame Keepers. The Blue and Violet Flame Keepers
    will complete their D-9 Andromeda-Galactic Core Activations and D-10/
     D-11 Silver-Black Liquid Light W ave Infusions during the Three-day par-
       ticle conversion period in 20I7.  
   32. June 2014: Earth Completes its Gold Wave Infusion.  
       Earth completes its first cycle of three Transmutative Stellar W ave Infu-
      sions. The D-7/D-8 Gold W ave Infusion that began in 6/2010 completes.
      Through the completion of the W ave Infusion D-7 base tone and D-8
     overtone, frequencies are entered into Earth's core morphogenetic field
     and will begin transmitting through Earth’ s grid on day-1 of the 2017 3-
     day period, when Earth’s D-8/D-9 Silver Wave Infusion begins. Earth will
     not begin its second cycle of three Stellar Wave Infusions until the Three-
     day particle conversion period of 2017, when Earth rapidly ful fills its D-7
      Arcturian, D-8 Orion and D-9 Andromeda Activations and receives the
      Silver W ave and Blue-Black and Silver-Black Liquid Light W ave Infu-
      sions.  
  33. June 2015: Keepers of the Violet Flame Begin Blue-black Liquid Light
       Wave Infusions.  
      The Keepers of the V iolet Flame are half way through their D-8 Orion-
      Earth Core Activation, the D-8/D-9 Silver Wave Infusion that began in 1/
     2013 completes and the D-9/D-10 Blue-Black Liquid Light Wave Infusion
       begins. Through these D-9/D-10 W ave Infusions, D-9 base tone & D-10
       overtone frequencies, and imprints for DNA  strands 9 and 10, enter the
      morphogenetic field of the Violet Flame Keepers.  
  34. January 1, 2017: Violet Flame Embodies on Earth Within the Keepers
      of the Violet Flame. Keepers of the Violet Flame Begin D-9 Androm-
       eda-Galactic Core Activation. The Morphogenetic W ave Begins to
        Slow.  
      The V iolet Flame Keepers complete their D-8 Orion Activation, becom-
      ing eighth-level avatars with the ability to initiate eighth strand Orion
       Activations in others. They rapidly begin their D-9 Andromeda Activa-
       tion, which will complete on day two of the Three-day particle conversion
         period between 5/5/2017-6/30/2017, at which time they will become
        ninth-level avatars, able to initiate ninth strand Andromeda Activations
      in others. On 1/1/2017 the Violet Flame is drawn from the Alcyone spiral  
  222 
 

                                                                        
                                                      The Amenti Ascension Program Schedule
     into embodiment by the Violet Flame Holder, and passed on to the Keep-    
      ers of the V iolet Flame, in the same manner as the Blue Flame had been
       embodied by the Keepers of the Blue Flame on 5/5/2012. The conversion
      speed of particles transferring from Earth and T ara to hyper-space, via the
  morphogenetic wave, begins to slow in preparation for the wave’ s full
    cresting, when the Holographic Beam from Meta-galactic Core aligns
        directly with Earth during the Three-day particle conversion period
          between 5/5/2017 and 6/30/2017.  
   35.  March 2017: Keepers of the Violet Flame Begin Silver-black Liquid 
         Light Wave Infusions.
      The Keepers of the V iolet Flame are half way through their D-9 Androm-
     eda-Galactic Core Activation, the D-9/D-10 Blue-Black Liquid Light
       W ave Infusion that began in 6/2015 completes and the D-10/D-11 Silver-
     Black Liquid Light W ave Infusion begins. Through these D-10/D-ll W ave
     Infusions, D-10 base tone and D-11 overtone frequencies, and imprints for
     DNA  strands 10 and 11, enter into the morphogenetic fields of the Violet
       Flame Keepers.  
                                       Particle Conversion Period
       36. May 5, 20l7-June 30, 2017: The Andromeda, Orion and Arcturian Spi-
     rals Align with the Sirian Spiral. Earth Begins and Completes D-7 Arc-
       turian, D-8 Orion and D-9 Andromeda Activations and the Silver W ave
       and Blue-black and Silver-black Liquid Light W ave Infusions. The Grids
        of Earth And T ara are in Full Alignment and Earth is Centered within
     Holographic Beam and Photon Belt. The Keepers of the Blue and V iolet
     Flames Complete their D-9 Andromeda-Galactic Core Activations and
        Silver-black Liquid Light Wave Infusions.        
      Earth comes into direct alignment with the Holographic Beam, Earth’ s
         overtone particles are fully immersed within the Photon Belt, the grids of
       Earth and T ara are in full alignment, and the planetary cores of Earth,
     T ara and Gaia come into direct alignment with each other and the Meta-
     galactic Core, for a period of three days. As Earth aligns with the Holo-
     graphic Beam, the D-9 Andromeda/Galactic Core morphogenetic field,
        D-8 Orion/Meta-Galactic Core and D-7 Arcturian Spirals align with the
         D-6 Sirian, D-5 Pleiadian-Alcyone, D-4 Solar Spirals and Earth’s Merkaba
       Fields.  
      During this  Three-day particle conversion period Earth begins and com-
     pletes its three remaining Transmutative Stellar W ave Activations and
     Earth’s core receives a rapid sequence of three Stellar Wave Infusions. On
      day one of the 3-day period Earth begins and completes its D-7 Arcturian
     Activation, as the D-7 Arcturian Spiral aligns with the D-6 Sirian Spiral
        and D-7 frequency runs through Earth’ s grid. Halfway through day one
             and halfway into day 2, Earth receives its D-8/D-9 Silver W ave Infusion,
             223 
                                                                                                                                                      
                                                                                     

    
                 Things to Come
       through which D-8 base tone and D-9 overtone frequencies enter the
        morphogenetic fields of Earth, Tara and Gaia. On day two Earth begins
        and completes its D-8 Orion Activation, as the D-8 Orion/Meta-galactic
        Core Spiral aligns with the D-7 Arcturian Spiral and D-8 frequency runs
        through Earth’ s grid. Halfway through day two and halfway into day three
        Earth receives its D-9/D-10 Blue-Black Liquid Light W ave Infusion,
        through which D-9 base tone and D-10 overtone frequencies enter the
       morphogenetic fields of Earth, Tara and Gaia. On day three Earth begins
         and completes its D-9 Andromeda Activation, as the D-9 Andromeda
         Spiral aligns with the D-8 Orion Spiral and D-9 frequency runs through
         Earth’ s grid. Halfway through day three Earth receives its D-10/D-11 Sil-
         ver-Black Liquid Light W ave Infusion, through which D-10 base tone and
        D-11 overtone frequencies enter the morphogenetic fields of Earth, Tara
        and Gaia. This D-10/D-11 Silver-Black Liquid Light W ave Infusion brings
        the Three-day particle conversion period to a close, creating the final sep-
       aration of Earth’ s particle base into the Bridge Zone and D-3 Phantom
     Earth time cycles.  
       On day one of the 3-day period the Keepers of the Blue Flame complete
       their D-9 Andromeda-Galactic Core Activation, activating the ninth
      DNA  strand and becoming ninth-level avatars able to initiate D-9
      Andromeda Activations in others. On day two they complete their D-10/
     D-11 Silver-Black Liquid Light W ave Infusions, through which the fre-
        quencies of D-10 and D-11 are entered into their morphogenetic field. On
     day two the Keepers of the V iolet Flame complete their D-9 Andromeda-
      Galactic Core Activation to become ninth-level avatars. On day three
      they complete their Silver-Black Liquid Light W ave Infusion. Those of
     the Flame Keepers who complete the full six Transmutative Stellar Acti-
     vations and Stellar Wave Infusions will become fully embodied over-souls/
  ninth-level avatars, during the particle conversion period in 2017.     
       37. 2017: Three-day particle conversion period: Earth, Tara, Gaia, Meta-
      galactic Core and Galactic Core in Direct Alignment For Three Days
     and Ascension Passages to Gaia and Higher Dimensions Open for
         Three Days. Morphogenetic Wave Completes Cresting and Particle
         Conversion from Hyper-space T akes Place. Earth’s Magnetic Grids
          Temporarily Collapse. Polarity and Angular Rotation of Particle Spin,
      of Earth and T ara, Reverse Back to Original Positions. Particle Field
       Separation Completes, Earth Shifts to Bridge Zone and Phantom Earth
Returns to D-3 Time Cycle.  
Through the alignment of the six Stellar Spirals the cores of Earth, Tara,
 Gaia, the Meta-Galactic Core and Galactic Core morphogenetic field
     come into direct alignment for three days. Within this period of three days
    the V iolet Flame morphogenetic field of Gaia, Blue Flame of Tara and
 Orange-gold Flame of Earth absorb as much UHF energy as they can hold
  224  
     

                                                     The Amenti Ascension Program Schedule
from the Holographic Beam and the morphogenetic wave completes its
crest. Earth’s base tone magnetic fields temporarily collapse and Earth’s
particles and Tara’s anti-particles slow in pulsation, in preparation for the
return to their original polarity and angular rotation of spin. The Earth's
electrical overtone particles, which were in hyper-space, re-manifest as
magnetic base tone anti-particles in Tara’s grid. Tara’s magnetic base tone
anti-particles return from hyper-space and re-manifest as electrical over-
tone particles in Gaia’s grid. As this occurs, the base tone particles of
Earth and the overtone anti-particles of Tara reverse their polarity, return-
ing to their original orientation. Usually, at this point in the particle con-
version process,  the particles and anti-particles would normally reverse
the 45° shift in angular rotation of spin that began on 12/21/2012. The
particles of Earth and anti-particles of Tara would begin re-orientation
into the pulsation rhythms of their original time cycles.   
     At this phase of the particle conversion process the Bridge Zone comes
into play. The base tone particles of Earth, that would normally slow in
pulsation rhythm and return to the D-3 time cycle, will instead be divided
into two groups. Through beaming a continual stream of D-3.5 energy
through Earth’s core and grid via the Holographic Beam throughout the
three day period, the Guardians will be able to keep the accretion level of
most of Earth’s particle base and its morphogenetic field at 3.5. After the
3-day period ends, Earth’s base tone magnetic fields return and they would
normally seal Earth’s particle pulsation rhythm into the D-3 time cycle. By
shifting the angular rotation of particle spin 22.5° in reverse, instead of
the natural 45 ° rotation, while keeping Earth at a 3.5 accretion level when
the magnetic fields return, most of Earth’s particle base will be shifted into
the Bridge Zone and magnetically sealed at the 3.5 accretion level. The
Bridge Zone represents the natural time cycle of Inner Earth-Agartha. The por-
tions of Earth’ s particle base that cannot hold the infusion of D-3.5 frequency
will drop rapidly into D-3 pulsation rhythm while the magnetic ﬁelds are down,
creating a phantom Earth particle body in the D-3 time cycle.  The primary par-
ticle base and morphogenetic field of Earth, which are holding the 3.5 fre-
quency, will shift into the pulsation rhythm of the Bridge Zone time
continuum, instead of returning to the pulsation rhythm of the D-3 time
cycle. The Bridge  Zone time continuum represents a 2213-year  leap  forward in
space-time.  
                       Time-Leap Mechanics      
    The Bridge Zone Earth jumps from its natural 2.5 accretion level to the
3.5 accretion level, which constitutes a 22l3-year leap forward in the
tracks of time. Normally Earth would reach the three accretion level dur-
ing the second morphogenetic wave 2213 years in the future in 4230 AD,
at which point it would naturally transition into the first D-4 time cycle.
   225  
                                                                                                                                                                                                                                                                                                                                                                            

       Things to Come       
 Earth would then spend another half cycle in D-4 until it reached a 3.5
 accretion level during the first morphogenetic wave of the first D-4 ascen-
  sion cycle. The Bridge Zone continuum omits 2213 years of the last half of the
  D-3 cycle and the ﬁrst half of the D-4 cycle, which represents 1106.5 years.
 The D-4 cycle moves (has a particle pulsation rhythm) twice as fast as the
 D-3 continuum, which means that passage through the D-4 time contin-
 uum takes half as many years as it takes to pass through the D-3 contin-
 uum. In D-3, half of a continuum cycle represents 2213 years, so half of a
 D-4 cycle represents half of 2213 years, or 1106.5 years. Earth leaps ahead
 2213 years by skipping the second half of its D-3 continuum cycle, and
 ahead another 1106.5 years by skipping the first half of its D-4 cycle. This
 creates a cumulative 3319.5-year leap ahead in space-time. This 3319.5-
 year leap does not include the time reversal acquired within the Bridge
 Zone. A  22.5° reverse rotation of particle spin is used to shift Earth into
  the Bridge Zone continuum.   
        One full D-3 cycle of 4426 years represents a cumulative 45° shift in angu-
 lar rotation of particle spin, thus a 22.5° shift in angular rotation of parti-
 cle spin in D-3 represents half D-3 cycle —2213 years. In D-4, where the
 particle pulsation rhythm is twice as fast as that of D-3, 2213 years repre-
 sents one full D-4 time cycle —a 45° shift in angular rotation of particle
 spin = 2213 years in D-4. A 22.5° shift of angular rotation of particle spin
 in D-4 represents 1106.5 years. The D-4 22.5° reverse shift in angular rota-
 tion of particle spin, which is used to create the Bridge Zone shift, trans-
 lates into a minus 1106.5 years. In raising the accretion level of Earth from
 2.5 to 3.5, Earth omits 2213 years from its D-3 time track and 1106.5 years
 from its D-4 time track, for a total forward leap of 3319.5 years. However,
 the angular rotation of Earth’s particle spin will be shifted 22.5° in reverse
within the D-4 cycle, in order to enter the Bridge Zone, creating a minus   
1106.5 years. In entering the Bridge Zone continuum, Earth moves ahead                                                        
3319.5 years, then back 1106.5 years, in terms of time-space placement, for a
  total forward time gain of 2213 years, or half of a D-3 cycle (3319.5-
     1106.5=2213 years).  ² 
              Following  the three-day particle conversion  period, which will occur sometime
    between 5/5/2017 and 6/30/2017, as the Bridge Zone Earth takes its position
   2213 years in the future at accretion level 3.5, the phantom Earth becomes a
  Descending Planet and re-enters the D-3 time continuum, returning to its origi-
   nal 2.5-accretion level.  People who have assembled a minimum of all of the
  fourth DNA  strand and half of the fifth, (giving them an accretion level of
          __________________________      
   2.     Note:We provided this technical data so you might develop some idea of the mathemat-
      ical structure of  multidimensional space-time. It is not necessary for you to understand
      these time mechanics in order to comprehend the signi ficance of what is taking place as
         Earth shifts into the Bridge Zone.  
    226                                                                                                                        
                    

                                                   
                                                      The Amenti Ascension Program Schedule
    4.5, which allows them to perceive the 3.5-dimensional frequencies as
      physical matter) will shift their body and consciousness to the Bridge
   Zone Earth. People with less DNA  strand assembly , and an accretion level
   of less than 4.5 will shift back to the D-3 time continuum when Earth
     leaves the D-4 continuum following the three-day period. In previous sec-
     tions, we have discussed the experiential perceptions one will encounter
     within each of the three tracks of time, and what one might expect to
   experience through this transition period, so we will not restate that infor-
   mation here. During this 3-day period, when the Meta-galactic portals open,
    people who have fully assembled and activated the sixth DNA strand can  ascend
    directly out of matter into etheric matter on Gaia, and those who have activated
    the eighth strand can ascend directly through the Meta-galactic Core into pure
     morphogenetic consciousness in   dimensions  9-12. During the  three-day period of
     full alignment with the Holographic Beam, a burst of accelerating energy runs
    through Earth’ s grid, allowing many others to almost instantaneously assemble
     the ﬁfth or sixth strands, giving them a ﬁnal opportunity to ascend to Tara or
     Gaia. Orion, Arcturian and Andromeda Stellar Activations take place in this 3-
       day period.  
  38. July 2017: Planetary Cores of Earth, Tara, Gaia, Meta-galactic Core
   and Galactic Core Pass out of Alignment, Earth Passes out of Align-
   ment with the Holographic Beam and the Ascension Portals to Gaia
   and Meta-galactic Core Close. The Merkaba Fields of Earth, Phantom
    Earth and Tara Separate and the Collapsed Planetary Magnetic Fields
    Regenerate, Sealing The Planets Into Their Respective Time Contin-
   uum Cycles. The Grids Of Earth And Tara Begin To Separate As Pop-
        ulations Adjust to their New Reality Fields. The Halls of Amenti
     Remain Open to Bridge Zone Populations and Ascensions to Tara Con-
      tinue. The Transmitting Rhythm of the Hall of Records Slows, and the
     Seven Primary Vortices on Earth and Phantom Earth Begin their Clos-
      ing Cycle.  
   After a 3-day period within the Holographic Beam, Earth moves out of
   alignment with the Holographic Beam and the planetary cores of Earth,
   T ara, Gaia, the Meta-galactic Core and Galactic Core pass out of align-
     ment with each other. This causes the portal passages to Gaia and the Meta-
      galactic Core  to  close, ending  the  ascension  cycle  to the   reality   ﬁelds of   Gaia  and
       beyond.  The Merkaba Fields of Earth, Phantom Earth, T ara and Gaia,
      which merged through Earth’s six Stellar Activations, separate and the
      planetary magnetic fields, that had collapsed during the 3-day period,
         regenerate, sealing Earth, Phantom Earth, T ara and Gaia into their respec-
     tive dimensional time continuum cycles. The grids of Earth, Phantom
     Earth and T ara begin to separate, as the particle pulsation rhythms of each
          planet adjust to their respective time cycle rhythms and human popula-
       tions adjust to their new reality fields on T ara, Bridge Zone Earth and
    227  
                                                                                                                
                                                                                                       
        

     Things to Come  
    Phantom Earth. Ascensions to Tara, through the Halls of Amenti, con-
     tinue for populations stationed within the Bridge Zone and the Halls of
    Amenti close to populations stationed on Phantom Earth in the D-3 time
       continuum cycle. The rate of data transmission through the Hall of
     Records slows on Bridge Zone Earth and the Hall of Records closes to
      Phantom Earth. As Earth passes out of alignment with the Holographic
      Beam, the Seven primary vortices on Earth and Phantom Earth enter
        their closing and deactivation cycle.  
  39. January 1, 2022: Earth's Seventh Vortex—Andes Mountains-—Closes.
     Infusions of D-5-D-7 Frequency through Earth’s Grid Cease and
        Accelerated Assembly of DNA  Strands 5 and 6 Ends. The Mass
        Ascension Cycle Comes to a Close as the Halls of Amenti Close to the
            Masses. The Grids of Earth and Tara Completely Separate.  
         The natural seal within Earth’s seventh vortex re-seals, closing and deacti-
        vating the seventh vortex in the Andes Mountains. Following this re-seal-
        ing, the Earth's grid begins to slow in particle pulsation speed to the Bridge
        Zone-Agartha time continuum rhythm and the infusions of D-5-D-7
       energy , that had been running through Earth's grid, cease. In the absence
        of these UHF energy infusions, the acceleration of assembling and activat-
        ing DNA  strands 5-7 ends. Humans who do not organically carry the
       imprint for the fifth and sixth DNA strands will find that the portions of
      these strands that had begun assembly and activation during the infusion
          acceleration, but which had not yet fully assembled, will begin rapid deac-
         tivation and disassembly, once the Earth grid infusions have ceased. Popu-
         lations in the Bridge Zone, who have not assembled and activated the fifth
       DNA  strand, will return to a 4.5-strand assembly level (4.5 accretion),
         and populations on Phantom Earth will return to 3.5-strand DNA  assem-
        bly (3.5 accretion).  The DNA will return to its natural accretion level and
        evolution of DNA will return to its slow and methodical process. On Bridge
       Zone Earth, the Halls of Amenti will close to the masses that did not com-
      plete fifth DNA strand assembly. Passage through the Halls of Amenti
      requires a fifth DNA strand activation level. As long as the Sphere of
        Amenti remains unsealed within Bridge Zone Earth’ s Morphogenetic
        Field, the Halls of Amenti will remain open to anyone in the Bridge Zone
         who can assemble the fifth strand, but fifth strand assembly may now take
      several incarnations. The Hall of Records remains open in the Bridge
        Zone, as long as Earth’ s grid stays aligned with the Alcyone spiral, but it
               will transmit data at a much slower rate.   
       The grids of Earth and T ara complete their separation and the ascension
           cycle comes to a close, as humanity faces its new reality within three dif-
          ferent tracks of time. One part of humanity will experience the future in
          the D-3 Phantom Earth time cycle, another part will move into the age of
       enlightenment within the Bridge Zone-Inner Earth time cycle, 2213 years
    228  
    
   

                                                                                                                        
                                                      The Amenti Ascension Program Schedule
in the future and a relative few will voyage into the lands of Tara, within  
the D-5 time cycles, a position in space-time 5532.5 years in the future of  
present day Earth. The D-3 phantom Earth will take its own course of  
development as Earth, with the Sphere of Amenti in its core morphoge-  
netic field, moves forward in the Bridge Zone continuum. For populations  
remaining in the D-3 time cycle, both the Halls of Amenti and the Hall of  
Records closes completely and permanently. Ascension from the D-3  
cycle will require Guardian assistance because the Sphere of Amenti and  
Earth’s morphogenetic field are no longer at the core of the Phantom  
Earth planet, they are within the planetary core of Bridge Zone Earth.  
Future ascension from the D-3 cycle will require a Host Matrix/Soul  
Matrix transplant, as those remaining in D-3 will be cut off from the plan-  
etary and race morphogenetic fields, and thus also cut off from their per-  
sonal Soul Matrix in HU-2. People of the Phantom Earth will experience  
a genetic mutation through which the third and fourth DNA strands are  
unable to plug into each other. This will create a permanent separation  
between the D-4 astral identity and the D-3 ego identity and a separation  
of the lower three levels of the auric field from the fourth and higher levels  
of the Soul Matrix. This condition can be remedied only through a Host  
Matrix Transplant, such as that employed by the Palaidorians, when they  
created the Sphere of Amenti “rescue mission” for the lost souls of Tara.  
This is one of the problems consciousness faces when evolving on a  
“Phantom” Descending Planet. Can you understand why the Guardian  
races are attempting to inform you of and motivate you to consciously par-  
ticipate in, the accelerated evolution of your DNA? Ascend while ascension  
is relatively easy, during the 2012-2022 ascension cycle,  for if you do not,  
ascension and soul evolution will be much more dif ﬁcult thereafter, for you and  
your future incarnations.  
40. January 1, 2022-June 2047: Closing Cycle of Earth’s Seven-Primary  
       Vortices .
Beginning with the closing of Earth’s seventh vortex in 1/2022, vortices 6  
through 1 begin their respective closing cycles, ending with the sealing of  
the first vortex in 6/2047. We will provide a list of vortex opening and  
closing dates in the final pages of this book.  
229 

  Things to Come  
      FINAL 1998  COMMENTS FROM THE GUARDIAN ALLIANCE
           
    Throughout the course of this book we have led you on an odyssey into
worlds of perception far beyond the focus of your three-dimensional view . We
have recounted pieces of your past as a race, in order to show you the lengthy
path it has taken for you to arrive at your present state of evolution. Perhaps
in reviewing just how far your race has come and what great difficulties you
have encountered, you will be able to appreciate the opportunity that is now
presented to you within the ful fillment of your present ascension cycle. Most
humans on Earth have received little, if any, valid training regarding the
rights and responsibilities of personal and collective evolution. You have
been conditioned for eons to become lost within the perceptual maze of the
three-dimensional illusion, to the extent that most of you have completely
lost touch with the greater reality from which your earthly life springs. You
have been sleeping children, lost within a dreamland of material perception,
and few among you have made a valiant effort to lift your heads above the
clouded seductions of your dreamscape. This will change. lt must, for if you
remain asleep, your dream shall become a nightmare, within which you shall
find yourselves imprisoned. The destiny of your race and your planet is now
in your hands. Though the teachings we bring to you may seem strange, and
indeed alien, you have the capacity to employ this knowledge to your own
bene fit, if you will permit your ego to get out of the way of your intuitive per-
ceptions. The truths of which we speak echo through the cells of your body
and whisper through the winds of your mind, waiting for you to embrace
them as you reclaim your forgotten souls.  
    In future Keylontic transmissions we will bring to you the technical
data of energy mechanics you will need to begin taking responsibility for the
evolution of your DNA and consciousness. As you can see, when viewing the
ascension schedule we have provided, there is little time left for you to debate
the validity of our information. Those of you who will venture to explore our
perspective will have an easier time comprehending the changes you will per-
ceive in the reality around you and you will have the opportunity to develop
survival skills that will allow you to face these changes with dignity and
grace. The Guardian races have been with you long before your arrival on
Earth 550,000,000 years ago. They are no strangers to the human lineage. It
is you who have forgotten. The quality of your future experience will depend
upon your remembering and your awakening to the multidimensional iden-
tity that is your heritage and birthright.  
230 

                                  
                                                        Final 1998 Comments from the Guardian Alliance
    The most important thing you can do after reading this material, is to
   make a firm personal commitment to reclaiming your private spiritual
         nature and to learning the energetic skills that will allow you to
                                    do this as rapidly as possible.  
   If you are wise, you will begin preparing yourselves for the energy infu-
sions that will soon be coursing through your planet’s grid. Learn about the
human chakra system and subtle energy bodies, for without this knowledge you will
be unable to interact directly with your DNA.  There are many fine books avail-
able through which you can learn how to identify, manipulate and balance
your personal bio-energetic fields. These activities are only the beginning
steps in reclaiming power over your personal genetic code and the evolution
of your consciousness and they will provide you with a rudimentary founda-
tion upon which skills of  Keylontic Science  can be developed. Through
applied Keylontic Science you will discover the methods by which DNA can be
altered from within and you will rediscover your personal power to become Guard-
ians and directors of your personal path of evolution . Becoming the director of
your personal energetic power and the path of evolution your consciousness
will follow, is not only a right, it is your responsibility. We have faith in your
intrinsic integrity and offer our support, encouragement and love to all that
muster the courage to face, rather than turn away from that responsibility.
Each of you will reap the harvests of your own personal choices and you will
join together with others making similar choices, to create a collective reality
field through which your consciousness can evolve. May you choose well and
favor enlightenment instead of darkness, comprehension instead of igno-
rance, freedom instead of blind obedience to forces beyond your perceptions.
You have the ability to become free and powerful, loving and wise. Redis-
cover this promise. Reclaim your power as co-creators within the universal
scheme and use it now, while so much hangs in the balance, awaiting the out-
come of your individual and collective choices.  
    As we have mentioned, you may be facing tectonic disturbances and the
Earth changes they will create, between now and 2017, when Earth is in its
most vulnerable position. Pay attention to your skies and if you find waves of
mass UFO “ ﬂy-by” sightings, know these are intended to bring you fair warn-
ing, so you have time to prepare for changes in the Earth. If such sightings do
indeed occur, seek telepathic communication with Guardian Visitors or your
own higher self and soul levels of identity, through which you can be guided
to appropriate action. Your lives and the lives of those you love may very well
depend upon your ability to access this higher level guidance. Learn the skills
of interdimensional communication now and how to protect yourselves from
covert manipulation during this practice, for these skills will become tremen-
dously valuable over the next 20 years. There are many books and teachings
available through which you may develop interdimensional communication
skills. Learn from the Light Workers among you, who have already developed
231   
 
                                                                                                                  
                                                                                                            

  Things to Come  
proficiency in these areas, for they can teach you much. Those of you who mas-
ter the skills of higher-dimensional internal guidance will not become lost within the
maze of external circumstance and you will be able to retain your personal power in
the face of traumatic events.         
      If you do not find starships displaying themselves in your skies, consider
yourselves fortunate, for this indicates that your progression through the
ascension cycle will be far less treacherous than it might otherwise have
been. You still need to prepare. Earth will still undergo infusions of UHF
energy that will directly effect the condition of your personal bio-energetic
system, consciousness and physical body. Earth will still shift into the Bridge
Zone and if you have not assembled 4.5 strands of DNA, you will end up on
the Phantom Earth in the D-3 time cycle. You may face covert and overt
invasion by the Dracos-Zeta Resistance and at best you will find yourselves in
need of Soul Matrix Transplants to free you from cycles of fragmented incar-
nation with the D-3 time cycle. All of this can be avoided now, if you take
responsibility for preparing yourselves for the coming changes. Each of you
can “rise to the occasion” if you choose to do so and we believe that you shall.
We believe in you and would not go to such great lengths to educate you, if
this were not the case. You must now re-learn to believe in yourselves and to
break free from the limiting self-concepts that have been imposed upon you
by outside forces and which you have imposed upon yourselves through
accepting limitations without question. You are not victims unless you
choose to be. Choosing ignorance is choosing victim-hood. Your power lies
in the choices you make each moment, in the thoughts you allow yourselves
to entertain, in the actions and events within which you allow yourselves to
participate. Take responsibility for directing your subtle energies and you will
be on your way to personal empowerment.  
      In closing this book we will provide for you a rudimentary introduction
to the Science of Keylonta, through which you can begin to build a frame-
work of reference for understanding the structures of your subtle energy sys-
tems. In future books we will explore the mechanics of DNA assembly and
activation, offering practical exercises through which you can gain mastery
over this process. The exercises provided within this book are a good place to
begin. Reading alone will not assist you in developing subtle energy skills; it
will only provide the conceptual foundations. The exercises must be used and
practiced to develop pro ficiency. We cannot stress enough the importance of
the times that now approach you, as you move into the 21st century. It is our
hope that you will comprehend the signi ficance of your approaching ascen-
sion opportunity and begin to take action now, to ensure your placement
within your desired future destination. For your convenience we shall now
offer you a brief summary of the ascension schedule and related subjects cov-
ered in these writings.  
232 
         

                                       Final 1998 Comments from the Guardian Alliance  
Communicators responsible for Keylontic Transmission
         of data contained in the 1998 Amenti Transmission
Transmitting Speakers (Metaterrestrials) :
         D-12 Universal Federation, Council of Twelve, also known as The
         Guardians of the 12 Pillars  and The Founders,  charter members of
         the Interdimensional Association of Free Worlds and The Guardian
         Alliance.
        HU-5 Breneau Matrix via D-l2 Melchizedek-D-6 Sirian Council Trans-
         mittance Pattern.
Supervisory Matrix (Ultra-Terrestrials) :
         Azurite Council of the Ra Confederacy Meta-galactic Core
Contributing Speakers and Technical Specialization
         Extraterrestrials:  Palaidorian Gestalt D-6, Elohim Cloister D-9, Sirian-
         Arcturian Coalition for lnterplanetary Defense HU-2, Zhar Confed-
         eracy HU-2, Pleiadian Star League Alcyone Council D-5
         Metaterrestrials: Lyran Gestalt D-12, Breneau Collective D-15
         Ultra-Terrestrials : Azar-Azara and Melchazedakz Gestalts Meta-
         Galactic Core.
                     
                                                                                                  
           233
                                                                                                                                                              
                                  

                                                                                                                                                                            
                                                                          12
                                  
                                                 
                     
                  Author’s Closing Statement,1998  
    
    In early June 1998 I began the final proof work on my book Voyagers: the
Sleeping Abductees in preparation for its intended fall 1998 release date. Fol-
lowing a joint physical encounter event that took place on  October 25,
1997,  in which a tremendous amount of new data was given and the Bridge
Zone Project was introduced, the book needed to be updated to include what
had been learned through that extraordinary event. During the 1997 encoun-
ter a physical visitation event was orchestrated from my New Jersey home by
a group of ET beings identifying themselves as members of a guardian group
called the Sirian Arcturian Coalition for Interplanetary Defense.  Later I
learned that this group is a member of the larger Guardian Alliance.  
  In the early morning hours of 10/25/1997, following a spontaneous
neighborhood power blackout, orchestration of an eerie syncopated light dis-
play and mysterious rappings in my daughter’s bedroom, I was physically
escorted outdoors and to a waiting craft that hovered in near silence over my
home. My escorts were semi-solid beings claiming to be of Arcturian origin
and, though their race was unfamiliar to me, the escorts Dralov and Chental
seemed non-threatening. I accompanied them without resistance, as did my
then five-year-old daughter and a visiting UFO investigator who had come to
explore other odd phenomena that I had recently reported. We were taken  
 via “blue beam” into a craft that hovered over my home. We were then   trans-           
  port ed to a massive Arcturian mother-craft named Ashalum.     
                                           The investigator and I were separately given a pri-  
vate tour of the craft then brought to a large auditorium                                        
where other humans waited for a lecture to be held on                             
the“State of Current Earth Affairs.” In the lecture, the         
 various unrelated groups of humans attending were pro-  
 vided with incredible technical data explaining the  
upcoming Bridge Zone Project, the approaching tim-  
continuum shift, IntruderET agendas (Dracos-Zeta Resistance) and the
necessity for humans to take action now. We were asked to share what we had
234 
     


 
                   Author’ s Closing Statement, 1998
learned and to begin assisting others to protect themselves from Intruder
manipulation and in preparing for the time continuum shift. (A full account
of the 10/25/1997 encounter can be found in Contact Forum: The Journal of
the Fifth World,  January-February 1998 issue, V olume 6, Number 1). ¹ 
     Before the Voyagers  book could go to press, the new information was to
be incorporated into the text, so in early June 1998 I busied myself with these
last-minute preparations. Little did I know at the time how far a journey I
would travel before the Voyagers  book was complete. I felt as if  I lived several
decades during the span of three months that it took me to bring this book to
a close. Over the last three months, The Voyagers series has undergone a
transformation, and with it my personal life has also been transformed.  
   On June 26, 1998 I received a vivid subtle contact experience during a
meditation. In this experience a being came to me in a vision and suddenly I
found myself in a state of  bi-location.  While fully awake and aware in my liv-
ing room, I was also simultaneously wide awake and embodied in a new envi-
ronment that looked vaguely familiar to me from earlier teleportation
abduction experiences. Oddly, in this encounter I was not in my “astral body”
for a “mental bi-location” journey, a state of awareness with which I am quite
accustomed, but rather I knew that my physical cells had somehow been
duplicated. My awareness was stationed simultaneously in two versions of my
physical body, in two separate locations. The place to which I was taken was
somewhat familiar, but I did not know its location.  
   However, the being that brought me to this place was quite familiar to
me. She is a human-Guardian ET hybrid named Charleamea . I knew Char-
leamea well, as she was the product of a “ missing fetus” pregnancy/abdu-
tion I had experienced in 1995. The 1995 event was quite traumatic for me at
the time, but later, in early 1997, I was taken by Guardians via teleportation
abduction to meet the child that had been removed from my body in order to
ensure her survival. I observed in awe that a child that should technically
have been no more than two years of age appeared to be the size of a 6-year-
old human and had the maturity and intelligence equivalent to that of adult
human genius. On June 26, 1998 Charleamea made contact with me at the
request of the Guardian Alliance and somehow “split me in two” to bring me
to this mysterious place. Gazing around at what appeared to be the interior of
a massive crystal-lined cave, I asked Charleamea where this beautiful place
was located. She told me “You have entered the Halls of Amenti via the
Hawaiian portal passage.” Prior to this experience I had never heard this
name before.  
  Charleamea proceeded to tell me that something terribly important
had just occurred on this 26th day of June, an event the Guardians had hoped
and prayed for but did not expect to take place. Excitedly she repeated sev-_____ __________________  
1. For a copy ple ase contact ARhAyas Productions, Sarasota, Fl.  
235 
                                                                                                                                                      
                                                                                                                  
                                                                                                     
 

     Author's Closing Statement, 1998   
eral times “The Arc is Sparked!” as I looked at her numbly, lacking compre-
hension. Then we were met by several other, human-looking Guardians and I
was told that I would be given a Keylontic transmission to translate regarding
this event and that when I was through translating the data I would under-
stand. I was taken to a crystalline chamber within the crystal-cave room in
which we stood.  
     Once inside, the chamber filled with intense blue light that began to
vibrate through my cells; I knew that I was being programmed with the trans-
mission in digital-data form. The blue light reached a level of intensity and
high pitched frequency filled the chamber. Suddenly I lost consciousness in
my double-body and was once again singly focused within my body in the liv-
ing room. As I sat on the couch, intense waves of electrical energy passed
through my body, and when I closed my eyes I could clearly see these waves
of ultra-blue light with my inner vision.  
    I sat very still, observing the waves and feeling the near-rapturous sensa-
tions they created within my body cells. After several minutes, the waves
slowed, and the energy “settled” into my nervous system. Suddenly millions
of Keylontic symbols ﬂashed through my mind and inner vision so rapidly
they almost blurred. As this phenomenon subsided a sudden burst of knowl-
edge just opened up inside of me.  
   Suddenly I remembered large blocks of my incarnational history , I
remembered why I had come to Earth this time around and how all of my
other incarnations had been part of the same purpose. Sitting motionless on
the couch I fully remembered myself as an eternal soul, for the first time in
this lifetime. The purpose for all of my past experiences of ET encounters,
visitations and abductions became crystal clear and I began to consciously
remember my soul agreements with other humans here to assist Earth in her
coming changes. Information and memory ﬂashed through my mind and my
body cells seemed to “sing” with recognition. More and more pieces of my
personal history poured through me and the memory expanded to include
human history over vast amounts of time.  
   Then some deeper part of me responded with recognition that con-
sciously I did not possess. This deeper self said, “Wait! What has happened?
That  information has not been available on Earth or accessible to Earth
humans for five million years!” My personality did not know, but my soul-self
understood that “something big had happened.” Then Charleamea telepathi-
cally whispered in my mind.  
      “ The Arc Has Sparked, ” Charleamea again repeated. “The seal on the
Arc has released, the Arc of the Covenant has opened. ” Suddenly the memory
stopped racing through my mind and my sense of expanded consciousness
“pulled in” a little. I felt a huge quantity of electrical data being pulled into
my auric field and knew the Keylontic transmission was ready for translation.
As the experience ended I was awestruck with what had just passed through
236 
    
     

     Authors Closing Statement, 1998  
me. It had moved so quickly that I could hardly “catch” any of it to translate
into words. The bits of memory and cognition I could retain involved my per-
sonal incarnational history and an odd knowing that I had repeatedly incar-
nated as a member of a soul group called the Keepers of the Blue Flame.  But
I would not rediscover what that term meant until completing translation of
the Keylontic transmission.  
     I was told in the dream state that evening that the new transmission must
be translated as soon as possible and added to the existing Voyagers books.
When I began translation of this material, I had no idea how extensive this
addition would become or that I would be given first hand experience in the
subject matter discussed. From June 27th, 1998, until the day of this writing
September 14, 1998, I have spent the majority of my days and nights in trans-
lation. Everything contained within the updated material is completely new
to me; I learned as I translated. Several times during the translation of this
material, I received powerful infusions of energy running through my body as
I transcribed, energy that could be seen through inner vision as blue waves of
light.  
   T oward the end of this transmission I came to understand that these
waves represented the beginning of a  Blue W ave Infusion that accompanied
my personal Heart Star-Solar Activation. I knew absolutely nothing about
these things prior to the June 26th encounter, but suddenly I was living the
realities of which the Guardians had spoken. I learned of soul contracts and
those I personally came to serve, I learned of the Palaidorians and the Priests
of Ur whom I had encountered various times since childhood but never knew
by name. Throughout this three-month period of translating the Guardians’
6/26/98 Keylontic transmission, I have been personally transformed in ways
words cannot describe. It has been a soul awakening. The V oyagers series has
also been transformed. Voyagers: Secrets of Amenti was born.  
   I know that the information contained within the updated pages may
seem utterly unbelievable to many people. We have such a small concept of
the nature of our race that it may be hard to fathom the true greatness hidden
within our evolutionary blueprint. It may be difficult to imagine that the uni-
verse is as glorious as it truly is after viewing it in such limited terms for so
many eons.  
     Do I personally believe the things of which the Guardians have spoken?
You bet I do! I am living the reality of these experiences. Are “Stellar Wave
Activations and Infusions” real? They certainly seem to be real when I feel
this energy periodically rush through my cells, expanding my consciousness
and triggering greater amounts of memory within me, bringing me ever-closer
to feeling at-one-ment with my soul and with the universe; or when Blue
Wave Infusions begin during the dream state and astral projection then pro-
pel me back into my body with such force that the physical body grows hot
with vibrating blue energy running through its cells. The concept of wave
237 
                                                                                                                          
                                                                                                                   
      

Author’ s Closing Statement, 1998  
infusions is also quite convincing when observing large sheets of violet light
cascading through the atmosphere within the room. Though the violet light
sheets do not occur frequently, I have witnessed this effect with a few other
people on several occasions. Will I do as the Guardians suggest and begin to
prepare my body for Stellar Activations and DNA assembly? You bet I will! If
for no other reason than “ What if they are right?”  
  The Guardians have repeatedly demonstrated to me that they know
what they are talking about. I am now paying very close attention to what
they have to say. They have earned my respect with the incredible logic of
the data they provide and they have earned my love through the incredible
transforming, healing events of soul integration I have been privileged to
experience through my work with the Guardian Alliance. They have cer-
tainly accelerated my spiritual evolution; now it is time to discover if indeed
cellular evolution can also be accelerated. Before the 6/26/98 transmission
words such as the Sphere of Amenti, Morphogenetic Waves, Stellar Activa-
tion, Star Crystal Seals  and Stellar Spiral Alignments meant nothing to me;
I had never heard of these terms before. As far as I was concerned, the Arc of
the Covenant represented a fictitious box of something-or-other that was
sought in an Indiana ]ones movie. The concepts of Palaidorian Birthing
Contracts and Contract Bonds,  coming avatars and Indigo Children were
also new to me. The history of the races as presented in this transmission was
utterly foreign to me, yet “felt right” intuitively and in terms of biological cel-
lular memory. I now feel privileged and grateful to have access to such infor-
mation. The Guardians’ teachings offer tools of empowerment for those who
are ready to learn. I consider myself an avid and attentive student of the
Guardian Alliance.  
   This book is written for those who are on the path of awakening, for
those who intrinsically know they are meant to become V oyagers or sense
they are members of the Blue or Violet Flame soul groups. But it is also writ-
ten for others who would like to understand the changes facing humanity at
this juncture of time and space and for those who seek effective methods
through which these changes can be handled. This book is a primer and
serves to set the elaborate conceptual foundations through which under-
standing of the present human condition can be accomplished. This book is
intended for those who are ready to understand the multidimensional drama
of which Earth has always been a part. I hope the knowledge contained
within this book may inspire, uplift and empower the reader, as it has done so
for me.  
       God Bless, and may your V oyage to awakening be sweet and rapture  
filled.  
        —Ashayana Deane 9/14/ 1998  
238 
 

                                                                                                    
                                                                                                                     
                                                                                                
                                                                                                                       The “I Am" Prayer
                                            T HE I AM PRAYER
                                       I AM a Child of the Original ONE,
                                         I AM a Ray of the Original Sun,
                                           I AM Wholeness, I AM Love.
                                I AM the Truth that Spans the Sands of Time,
                                  I AM the Rainbow of the Very First Shine,
                                              I AM Music, I AM Light.
                                        Let the Light Descend Upon Me,
                                      Guide the Way with Golden Light,
                                    No Other God will Stand Before Me...
                          As I Embrace the One True Life I was Born to Live...
                                         By the Will of the Original ONE.
                                       I AM a Face of the Original God,
                                    I AM a V oice of the Original Sound,
                          I AM a Wave Upon the Ocean of Eternal Light.
                          I Reach My Arms Up Unto the Heavens, and say,
                                                 I AM THIS I AM.
                                     The Presence of the Ancient One
                                       Springs Forth at My Command.
                                               I AM One With God,
                                                 I AM THIS I AM...
                                   And, as I Decree It, So It Is.
239 
                            

                     2001 Update Section
                                       
                                       
                
                 13:  Emergency Release GA
                                            A NEW LEVEL OF (CONTINUOUS) REVELATION          
     The information contained in Chapters 1 through 12 of this book rep-
resents a complete reprinting of the original text contained within the first 
printed edition of Voyagers  Volume 2 The Secrets of Amenti . However, 
since the first printing of this book, and its companion, Voyagers Volume 1:   
The Sleeping Abductees , literally massive amounts of new and detailed 
information covering a wide variety of subject matter  has been progressively 
provided by representatives of the Guardian Alliance.. The progressive dis-
pensation of “next level” data includes subjects such as the Science of Cre-
ation Mechanics, 15-Dimensional Physics and intensive natural healing  
and spiritual development programs  as well as profound revelations of data 
pertaining to humanity’s ancient Forbidden History , the realities of Earth’s   
Planetary Templar Complex Star Gate system  and the  intimate relationship
between our lost history, the star gates and the realities of our contemporary 
global drama .  
    The new information presented from this page forward represents a brief 
summary of some of the most urgent material provided since September 
2000 . At the time of the Voyagers Series Books first release in May 1999, 
the dispensation of data concerning the previously mentioned subjects was
caught within an intensive, volatile interstellar political drama ; a drama             
existing “behind the scenes” which dictated the amount of revelation  that 
could be immediately permitted until the inherent political atmosphere had     
reached a more conclusive direction. When the V oyagers book CDT-Plate 
translations were first presented, the Guardian Alliance and other interstellar      
races of the Founders Emerald Covenant Christiac Co-evolution peace  
treaty were embroiled in extensive political negotiations  concerning two pri-
mary ''ET" visitor races, both of whom have shared a long and difficult rela-
tionship with Human civilizations of Earth. These negotiations began in       
November 1992 , when a series of Emerald Covenant treaties called the Ple-  
iadian-Sirian Agreements  were formed between Guardian Emerald Cove-
241 
                            
                                                                                                                                          
 


       2001 Update Section  
nant races and a large group of extraterrestrial or “Angelic” (AKA multiple
density) races collectively called the  Anunnaki.  The two primary biological
lines of the Anunnaki race are the pure-strain  Annu-Elohim  Anunnaki, the 
Bipedal Dolphin People of Densities 2-4 Sirius A and Arcturus,  and many 
various competing  race strains of Anu-Seraphim aquatic-ape-Fallen Ser-
aphim-hybrid Anunnaki of Nibiru,  the Pleiades,  Alpha-Omega Centauri, 
Orion, and Andromeda.    
    THE ANUNNAKI, THE 1992 PLEIADIAN-SIRIAN AGREEMENTS 
                            AND FALLEN ANGELIC (ET) RACES  
    The Anunnaki races have had an intimate relationship with human 
evolution for many millions of years, and unfortunately, this relationship has
rarely demonstrated peaceful co-evolutionary objectives. The Anunnaki race 
identity includes a variety of different interstellar races, all of which have one
thing in common; they were originally created by and through a self-pro-
claimed “anti-Christiac” Fallen Angelic collective called the Annu-Elohim . 
Within the original text of this book no differentiation was made between 
the Elohei-Elohim feline-hominid Human Christos Founders race and the 
Fallen Annu-Elohim  aquatic-ape-cetacean collective that took an anti-
Christiac stance against their Elohei-Elohim kin 250 billion years ago.  
       The timing as to when this distinction was to be made among contempo-
rary human populations depended upon the Emerald Covenant negotiations 
of 1992. Revelation as to this Elohim distinction and the volumes of history
that pertain to their involvement in human evolution was conditional upon
whether or not the Annu-Elohim collectives would choose to abandon their 
long-held dominion agenda in favor of the Emerald Covenant Co-evolution 
treaty during the 2000-2017 Stellar Activations Cycle. If the Fallen Annu-
Elohim collectives chose to honor co-evolution with the races of Earth, the
history of horrors  they have intentionally inflicted upon the earthly races 
would be released more slowly, allowing the Annu-Elohim and their inter-
stellar races time to demonstrate their proclaimed “good faith” within the 
co-evolution agenda, while allowing the humans of Earth a bit more time to
evolve in spiritual maturity so they would not seek to retaliate against the
Annu-Elohim races, and especially the earthly Human-hybrid descendants of 
the Anunnaki and Annu-Elohim, out of revenge for the historical horrors 
they have visited upon the human race.   
       The Founders and Emerald Covenant races were hoping that humanity
could be spared a direct and immediate confrontation  with the trauma of 
its past.  Such confrontation with the truth of human heritage is ultimately 
inevitable for final healing  to occur, but the “blow would be softened” if 
compassion, spiritual strength, forgiveness and understanding could first be 
fostered within the human collective prior to facing the enormity of what 
242 
                                       

                                     The Anunnaki, the 1992 Pleiadian-Sirian Agreements...  
has transpired on Earth  to bring human civilization to its present state  
of painful limitation and relative amnesia.       
    When the first printing of the Voyagers Series books occurred in May 
1999, historical references pertaining to the Annu-Elohim and Anunnaki 
involvement with Earth were presented in a neutral  context,  providing the 
general atmosphere of human evolution, but the “gory details” were not then 
revealed.The timing and method for revelation of the details depended upon 
whether or not the Annu-Elohim and their numerous Anunnaki races   
refused to abandon their intended agenda  of destroying the Human race of 
Earth during the 20002-2017 SAC.   
    The Annu-Elohim created the Anunnaki races about 568 million years 
ago in reaction to creation of the Elohei-Elohim Human Guardian  race; the 
Anunnaki were created with the intention of their race serving as the vessel 
through which the Christiac Human race would be destroyed to provide the 
Annu-Elohim Fallen Angeli totalitarian collective with exploitative domin-
ion over 11 dimensions of our Time Matrix.   
    For many millions of years, Emerald Covenant races have  attempted to
cultivate peaceful co-evolution between the Human and Anunnaki races in 
order to assist both species in fulfilling  their original potential of becoming     
“Christed” (able to achieve ascension and perpetual life expression) races. At 
various periods in our shared history, many Anunnaki races chose to reclaim 
their Christiac potentials through entering the Founder’s Emerald Covenant
to receive the DNA Template Bio-Regenesis  (regeneration) that would 
allow their vision of freedom  from the anti-Christiac control of the Fallen
Annu-Elohim collective to be actualized. Unfortunately for the Anunnaki     
races of the Emerald Covenant and for the Human races on the Christiac 
path who have attempted to help them, the Annu-Elohim Fallen Angelic 
collectives have done everything in their power to enslave the Anunnaki 
species as an “expendable tool” for Human destruction . Historically the
Fallen Annu-Elohim have consistently put forth great efforts of overt and
covert manipulation to prevent the Anunnaki from defecting from the anti-
Christiac agenda in favor of the Founders’ Emerald Covenant freedom
  agenda.   
     In November 1992, the Pleiadian-Sirian Agreements  emerged 
    through a confrontation between Anunnaki  races of the Fallen Annu-Elo-
him, competing Fallen Anu-Seraphim Anunnaki and Drakonian-Reptilian-
Insectoid races of the Dimension-10 Fallen Seraphim collective and the 
Human and Guardian races of the Emerald Covenant. All interstellar races 
knew since 22,326 BC  that this confrontation was likely to occur during the 
long-anticipated 2000-2017AD Stellar Activations Cycle ; only humanity has 
been “left in the dark” regarding knowledge of these events, precisely due 
to the interstellar political realities  that have existed on Earth since 22,326
BC. The 1992 agreements marked the entry of several previously Fallen
243 
                                                                                                                                     
                                                                                                                                                                                                     

                2001 Update Section  
Anunnaki collectives  into the Emerald Covenant following their many
thousands of years of covert manipulation of Earth Human and Anunnaki-
Human-hybrid races. The Fallen Angelic Anunnaki groups who entered the 
Emerald Covenant in 1992, after a long history of running manipulative 
“One World Order”anti-Christiac dominion agendas on Earth are as follows:  
 •  The J ehovian-Sirius-A Anunnaki that run Galactic Federation  and  
     Ashtar Command ¹   
 •  The “ Archangel Michael”  Nephite-Nephilim-Necromiton Anun-  
      naki-hybrid collective of Orion, Alpha-Centauri, Sirius A and   
     Andromeda .²                                          
 •  The Anu-Seraphim Alpha-Omega-Order Templar Melchizedeks ᵌ.        
 •  The Thoth-Enki-Zephelium- (Zeta) Anunnaki collective of Nibiru    
     and Sirius A .4                   
 •  The Enoch Jehovian-Anunnaki collective of Arcturus and Orion .5   
    •  The Anu-Seraphim Pleiadian Samjase-Anunnaki  of Alcyone and  
     their Enlil-Odedicron  and Marduke-Necromition Nibiruian  
     allies .6  
   In 1992 all of the above Anunnaki groups officially entered the Emerald
Covenant in an effort to gain support from Emerald Covenant races  in their
intended stand against the competing Reptile-Insectoid Rigelian-Zeta-
Zephelium, Omicron-Drakonian (Dragon-Moth) and Odedicron-Avian-
Reptilian Fallen Seraphim races of Orion, the  Necromiton-Andromie “Bee-_________________________________________  
1.     Last defected from the Emerald Covenant in 10AD , after several brief periods of entry 
       and  defection before and after the 9558 BC Atlantian ﬂood.  
2.    Defected from the Emerald Covenant in 148,000 BC  to run Jehovian-Annu-Elohim
        Earth dominion agendas and were directly responsible for the Nephilim invasion that                 
               ended Human Seeding-2 during the Thousand Years War of 846,800 BC.  
3.     Have run Drakonian-Centaur-Necromiton-Andromi Anunnaki-hybrid dominion agen-
         das on Earth, in competition with the Jehovian-Annu-Elohim agenda, for thousands of 
       years on behalf of the Fallen Anu-Seraphim collectives.  
4.  Once-trusted Anu-Seraphim Anunnaki members of the Emerald Covenant since 246,000BC,           
     defected from the Emerald Covenant in 22,340 BC  to join the Lucifer Rebellion                                              
         Anu-Seraphim Anunnaki Race Supremacy world dominion agenda.  
5.    Once-trusted Annu-Elohim Jehovian-Anunnaki members of the Emerald Covenant, 
        defected from the Emerald Covenant first in 10,500 BC Atlantis to join the Luciferian 
         Covenant, re-entered in 2250 BC following betrayal by the Anu-Seraphim “Luciferians”, 
        leading to Enoch’s 2024 BC service as an Emerald Covenant CDT-Plate Speaker, then 
     defected again in 10 AD  on behalf of the Annu-Elohim Jehovian-Anunnaki world 
      dominion agenda, until  Enoch petitioned for re-entry into the Emerald Covenant in 
      1983 AD.  
6.   Have run world dominion campaigns on Earth since 250,000 BC,nearly ended Human 
        Seeding-3 through forced occupation of Earth between 147,900 BC-75,877 BC, initiated
         the formalized Luciferian Covenant of 10,500BC and directly orchestrated the 9558 BC
       Atlantian ﬂood and subsequent “House Cleaning” of Earth’s historical records.  
244  
                                                                                                                 

           Solar Star Gate-4 and Anunnaki defection…
tle-People”  and their “ Men In Black”  hybrids, and the Centaur  and Mar-
duke-Dramin-Anunnaki-Omicron hybrids of Alpha and Omega Centauri.  
 SOLAR STAR GATE-4 AND ANUNNAKAI DEFECTION FROM THE 
                        1992 PLEIADIAN-SIRIAN AGREEMENTS   
    If the Anunnaki races had remained loyal to the 1992 Emerald Cove-
nant Pleiadian-Sirian Agreements, the contemporary Earth drama would 
have unfolded much differently than it has,  as the united Emerald Covenant
 Guardian Races and Anunnaki legions could have easily protected the peo-
ples of Earth from the intended 2000-2017 One World Order dominion cam-
paign of the united Drakonian Agenda Fallen Seraphim races. In this event,
the new updated material in the Voyagers  Books would have focused exclu-
sively upon preparing humanity for the inevitable physical meeting  of the
Emerald Covenant and Anunnaki races, and providing humanity with the 
Sacred Science training  needed for humans to resume their original position
as guardians of Earth’s Planetary Templar Complex and the Halls of Amenti  
star gates. Unfortunately, the well-intended 1992 Emerald Covenant Pleia-
dian-Sirian Agreements did not last.   
    When the January 2000  Consummation of the 2000-2017 Stellar Acti-
vations Cycle came around, the Anunnaki legions refused to return control 
of Universal Star Gate-4,  the Solar Gate, over to Emerald Covenant Azurite 
Universal Templar Security Team protection as they had vowed to do in 
1992. Instead, the controlling factions of all of the previously mentioned 
Anunnaki groups, except for the Enochian-Jehovian-Anunnaki collective, 
defected from the Emerald Covenant, reverting to their previous Luciferian 
Covenant and Jehovian One World Order dominion agendas. Since 10 AD, 
Enoch’s loyalties had been to the Jehovian-Nephite One World Order 
dominion agenda until he petitioned for Emerald Covenant re-entry in 1983 
via a Founders’ Redemption Contract; the contemporary works of Enoch pro-
duced prior to 1983 reflect his previous affiliation. When the other Anun-
naki groups defected from the 1992 Pleiadian-Sirian Agreements, Enoch 
remained loyal to the Emerald Covenant cause, and continues to do so as of 
this writing; a status that could change at any time due to continuing pressure 
from the Fallen Jehovian-Annu-Elohim collective of Density-3 Arcturus.  
    The competing Luciferian Covenant and Jehovian Anunnaki dominion 
agendas both hold at their core the intention of using Solar-Star Gate-4, and
an artificial stellar body known as the Nibiruian Battlestar  (AKA  the Bibli-
cal “Wormwood”), to force cataclysmic pole shift on Earth between 2003-
2008, in order to exterminate human populations  in the quest for dominion 
of the Halls of Amenti star gates.  The Nibiruian Anunnaki had seized con-
trol of Solar Star-Gate-4 from Emerald Covenant Guardian race protection 
during the Lucifer Rebellion of 25,500 BC , at which time they used Battle 
Star Nibiru to force Earth’s Templar into an artificial alignment with the
245 
                                                                                                                 
                                                                                                                                                                            
                                                                                                                                              

   2001 Update Section  
planet Nibiru. If Earth’s electromagnetic fields were not properly realigned
with the natural Pleiadian-Spiral alignment of the Universal Star Gates, 
Earth would be forced into pole shift as the 2000-2017 Stellar Activations
Cycle progressed. The Emerald Covenant races initiated the 1992 Pleiadian-
Sirian Agreements as a means of preventing this pending (and long-prophe-
sied) Earth pole shift drama, in hopes that the Human and Anunnaki-hybrid
races of Earth could be spared this catastrophic destiny.  
    The Anunnaki legions chose to enter the 1992 Pleiadian-Sirian Agree-
ments only because their original take-over plans had been somewhat 
thwarted by human Illuminati Zeta Treaty agreements  of the 1930’s, through 
which the Omicron-Drakonian and Odedicron-Reptilian legions gained an 
unanticipated strategic advantage over Anunnaki influence in the contem-
porary Earth drama. The Anunnaki legions chose to break the 1992 Pleia-
dian-Sirian Agreements because Emerald Covenant Founders would not give
in to their demands that the entire human race of Earth be placed under the 
sole elitist dominion of Annu-Melchizedek Anunnaki hybrid races of Inner 
Earth.  
    The Anunnaki broke their original 1992 agreements of shared Human 
and Annu-Melchizedek co-guardianship of Earth’s Templar, and attempted to
use their “trump card” of holding Solar Star Gate-4 as a means to blackmail 
the Founders into placing human destiny “under the thumb” of Anunnaki 
race supremacy.  To agree to such a demand would represent the equivalent of
selling Earth humanity into perpetual Anunnaki slavery,  and the Hidden
Forbidden History of Earth as faithfully recorded on the Emerald Covenant
CDT-Plate holographic discs, clearly demonstrated that such an act  of per-
mitted Anunnaki supremacy on Earth would guarantee the rapid termination 
of the Human species.   
     When the Christos Founders Emerald Covenant races refused to submit 
to the Anunnaki’s self-serving demand of dominion over of humanity’s right to 
freedom and equality, the Anunnaki legions of the 1992 Pleiadian-Sirian 
Agreements all defected, except for Enoch’s group , from the Emerald Cove-
nant in a unified stance, believing that in their unity they could achieve 
Earth dominion through strategic victory over both the feared Drakonian 
Agenda Orion force and the Emerald Covenant Guardian races. The Emer-
ald Covenant Founders races continued negotiations  with any Anunnaki 
groups still interested in peaceful resolution of this building con ﬂict, and on 
July 5, 2000 a new treaty called the  T reaty of Altair ,  was agreed upon; most 
of the defecting Anunnaki groups reluctantly agreed to re-enter the Emer-
ald Covenant upon the Emerald Covenant races’ promise to assist them in the
presently unfolding Orion Wars of Density-3, in which Fallen Annu-Elohim 
Anunnaki holdings in Orion were under aggressive militant attack by the
Omicron-Drakonian  and Odedicron-Reptilian legions of Orion.  
246 

        
                                                                                       The    July 5, 2000, Treaty of  Altair...     
                    T HE JULY 5, 2000 TREATY OF ALTAIR AND                                                                                                                        
ANUNNAKI SABOTAGE OF THE 9/2000 UK EXPEDITION   
        Through the Treaty of Altair, the Anunnaki races of Orion were 
granted the Founders protection from the Drakonian invasion, if the Anun- 
naki legions would honor their original 1992 Emerald Covenant promises,
abandon their intended Earth dominion agendas and immediately release 
solar Star Gate-4 into the protection of the Emerald Covenant Azurite Uni-
versal Templar Security Team. In July 2000, the Anunnaki legions grudgingly
agreed, and in August 2000,  members of the Azurite Security Team  gathered 
at Machu Picchu, Peru to facilitate Emerald Covenant races in the transfer 
of Solar Star Gate-4 into Guardian Alliance Founders’ protection. The Peru 
event went smoothly, and once again the Emerald Covenant races were 
hopeful that the long-pending earthly “Final Conflict Drama”  between 
Human, Emerald Covenant and Fallen Angelic Anunnaki and Drakonian 
forces could be peacefully avoided. The Solar Star Gate-4 transfer to Guard-
ian protection was to be completed in September 2000,  during an event
 scheduled to take place at Stonehenge, England , the location in Earth’s Tem-
plar to which the Nibiruian Battlestar  and artificial planetary alignment 
with Nibiru are anchored. As per the Treaty of Altair, the Anunnaki races
agreed to secure their many Ley Line holdings in England  from Drakonian
race interference, so that members of the Azurite Templar Security Team 
could gain safe passage  to England to complete the final transfer of Solar-Star 
Gate-4 into Guardian protection.  
         On September 12, 2000 , just before the final transfer was to take 
place, the Anunnaki, in a blatant act of betrayal and unanticipated Treaty of 
Altair defection,  used their Ley Line system in England, in co-operation with 
local Omicron-Drakonian  legions, to launch an aggressive psychotronic
 attack  on members of the Azurite Security T eam in England. The Azurite 
Security Team, unaware of what had taken place, was told without explana-
tion in an emergency Guardian Alliance dispatch, to immediately return to 
Guardian Secured Grid Space , and that the scheduled teaching workshops
in U.K must be temporarily postponed to protect attendees  from the
potential harm of anticipated further psychotronic attacks, since the once-
secured England Grid Space had been compromised. The Azurite Security 
     Team immediately cancelled the remaining U.K schedule and returned  to 
Guardian Alliance secured Grid Space in Sarasota, Florida,  to find out what 
  on Earth had happen to cause the U.K Mission to be so rapidly aborted.  
        Upon our return home to Florida, I received a massive dispensation of 
material regarding the political events surrounding the Treaty of Altair. For 
GA security reasons I had been told nothing of this treaty or the volatility of 
the interstellar political atmosphere prior to our journey to England. Prior to 
September 2000 I simply knew that our site work, called Planetary Shields
Clinics,  in Peru and England was intended to assist the Emerald Covenant
247 
                                                                                                               

    2001 Update Section  
races in realigning Earth’s Merkaba Fields with Solar Star Gate-4, to ensure
our planet’s safe passage through the unfolding SAC. The news regarding the 
Treaty of Altair and of the severity of the political drama concerning the con-
temporary Anunnaki “visitor” groups was as new to me in September 2000, as 
it was to others. The news was not good news ,  n o r 
was it particularly welcomed by me, as it brought me into a full and abrupt 
personal confrontation with the realities of our ancient history and how 
these realities were presently manifesting again within the core of our con-
temporary “New Age and UFO Movement”  drama. Even though I had 
plenty of my reincarnational memory open (since birth), and was quite aware 
of some of the ancient horrors that had transpired (some of which I recall 
having lived, and died, through) during periods when the Fallen Angelics  
had turned their full attentions toward Earth, revelation of the Treaty of 
Altair data sent me temporarily into a “Dark Night of the Soul”.  
          Each progressive wave of new revelation required that I face the physical 
reality of what was taking place just beneath the seemingly calm surface  of 
our three-dimensional world, and how this illusion of calm  could be literally ,
permanently and globally shattered at any moment  due to the presently hid-
den realities of interstellar politics. I did not react to the new revelations with
fear; instead, the revelations inspired within me a series of emotional 
responses  that can only be described as the release of ancient experiential
trauma long buried in cellular memory, through which an expanded cogni-
tion of just how “real” the contemporary drama is, came fully into focus. The 
first feeling was one of wanting to deny the reality of our present circum-
stances, because these circumstances are not the way I would personally like
them to be; yet with this feeling came a knowing that in denying the exist-
ence of an undesirable reality you fully throw away any personal power you 
might posses to heal the condition.                                                                                                                                                                                                                                                                        
Healing comes from identifying the problem and taking effective and 
 appropriate action through which the undesired condition can be remedied.
Though in the face of this new information I could observe within myself 
how the three-dimensionally focused personality could be tempted  to utilize 
the emotional escapism of denial  in order to avoid confrontation with a real-
ity it was never trained to face, my greater Eternal Self  “simply knew better”.
Denial gets you nowhere fast —it is simply a way of creating for yourself a 
“glass house” to live in, and if you are going to hide out in glass houses you’d 
better hope that all of your neighbors are friendly and none of them like to 
play baseball. Denial of the new information was not an option  for me,
for deep within me I knew what the GA had revealed was the truth , and that in 
denying this truth I would not only be deluding myself,  but I would be mis-
leading anyone who depended on me to accurately report the contents of 
CDT-Plates and the GA dispensations.  
248 
  
                                                                                                                          
                                                                  

                                                                                    
                                                                     The July 5, 2000, Treaty of Altair…
Having rejected the potential option of self-deluding denial, the second 
emotional response to the new data that I observed within myself was a tem-
porary feeling of “ almost numbness ”, as my ancient selves and contemporary 
self collided in a moment in time with so much sensory overload and intrinsic 
cognition that the limitations of the physical neuro-networks in my manifest 
form temporarily shut down, conveniently shifting me into “observational 
mode”. From this temporary state of disengagement from direct emotional 
reaction, I was able to observe that a part of me felt a peculiar sense of vio-
lation,  not so much for myself, but on behalf of all humans. As if in this final 
revelation of truth, a final discovery of “how things really are and have been”, 
there was somehow an accompanying loss of innocence . Like a child being 
thrust prematurely from a finely sheltered nursery into a battleground of war, 
having been long protected from perception of the atrocities that can and
  often do occur . This “loss of innocence” feeling might be compared to how 
one would feel after dedicating one’s life to a particular company, for exam-
ple, then discovering to one’s horror that the company was knowingly and 
without remorse allowing its employees to be poisoned, while fully intending 
to dismiss them with no accountability for assisting with the medical bills. 
Or perhaps, discovering that your spouse had not only been “having an affair”, 
but had been conspiring with the “other” to have you killed so they 
could collect the insurance policy. A  rude and painful awakening  occurs 
when you discover that things you have believed in for a very long time, 
things perhaps you have built your life around, have  never been what they 
appeared to be,  but rather an expertly crafted  pack of lies created to harm 
and enslave you. When we desire to “know the truth”, and then the truth is 
revealed, what do we do if it is not the truth we wanted to hear?  
    As the GA  dispensations continued following the initial revelations of
 the Treaty of Altair, I realized how grateful I was to finally understand , yet I 
also acknowledge how “Knowing” has suddenly and forcefully “burst my 
bubble ” of naïveté  concerning the type of world within which we presently 
live. At least in America, a country that until recently had not witnessed the
  tragadies of major airborne war on its mainland territories, we seem to be 
raised with a few cultural blind spot  in which we come to believe that “Oh,
it couldn’t be that bad”, or “That could never happen to me”. Confrontation 
    with the revealed logistics of the behind-the-scenes interstellar drama
    showed me just how ﬂimsy such naïvely optimistic attitudes  really are, and
how ill prepared one will be in the face of adversarial conditions if these atti-
tudes of pseudo self-reassurance are indulged.   
    Pessimism and paranoia are not the answers either, for by their very 
nature both  are  disempowering and self-defeating choices of emotional response. 
When on September 12, 2000 the Anunnaki legions defected from their
Treaty of Altair agreements, the  entire contemporary drama  took a turn 
toward the more extreme  in potential experiential outcomes. These poten-   
249                    
                                                                                                                   
                                                                                                                   
 

2001 Update Section  
tials had existed all along, but the GA had been trying to “ease us into ” an 
understanding of our current circumstance, rather than thrust us into a rude 
awakening  that had the potential to generate fear, anger, outrage and panic,
instead of the calmly rendered effective action  that is required to remain 
personally empowered under the present circumstances. Following the Sep-
tember 12, 2000 Anunnaki defection, the GA had no choice but to reveal 
the whole truth of our history and what has been done here at the hands of 
the Anunnaki, because if we didn’t become “wise to the game”  very quickly, 
humanity was about to be “played as terminal fools”.  
                   
            THE SEPTEMBER 2000 UIR AND THE EDICT OF WAR                         
        The most immediately pertinent and pressing truth  that emerged from 
revelation of the Hidden Forbidden History , is facing the fact we are pres-
ently under a state of  covert global  (and galactic)  war , a war of which our 
populations have no directly tangible evidence. How can I make such an 
apparently threatening and most unwelcome statement while still expecting 
myself to be considered a spiritually awakened being? I can make this state-
ment as a  calm statement of fact because I have been made aware that on
 September 12, 2000 the Anunnaki legions not only defected from the peace 
agreements of the Treaty of Altair, but they subsequently  joined forces with 
the previously competing Drakonian Agenda legions, thanks to the Necro-
miton-Andromie’s instigation of forming a “ United Intruder Resistance ” 
(UIR). As a strategic move to ensure the success of the One World Order  
Earth dominion agenda held by each of the competing Fallen Angelic groups, 
the Necromiton  race of Density-3 Andromeda,  the “ beloved Andromies ” 
who have been in contact with several prominent people in the UFO Move-
ment, opened negotiations between the competing Fallen Angelic collec-
tives, successfully bringing most of them together to take a united stance 
against the Emerald Covenant peace treaty and freedom agenda. On Septem-
ber 12, 2000 the GA was given the  ultimatum  that 50,000 of its Grail Line 
Indigo Children could be evacuated out, then the rest of human populations 
were to be left to the agenda of the UIR. Unfortunately, the UIR races 
intended to  instigate pole shift  on Earth between 2003-2008  to “clear the 
real estate”, allowing the humans of Earth to survive just long enough to be 
used to access Earth’s Star Gate opening codes, at which time all, including
the “Chosen Ones” would be destroyed . On behalf of humanity, 
the Founders, the GA, the Maharaji  “blue humans” of Sirius B, the Sirian Coun-
cil, the Lyran High Council and the many billions of Emerald Covenant 
races in our 15-Dimensional Time Matrix told the UIR to “stick their ultima-
tum where the sun doesn’t shine” and refused to withdraw suppor t of Earth’s 
populations. Promptly, and as expected, the UIR issued an Official Edict of 
War against the Founders and Emerald Covenant legions.  
250  
                                                                                                                  
                                             

                                                                 
                                                    The September 2000 UIR and the Edict of War 
        In t erms of intergalactic politics, an Edict of War issued against the 
Founders races really is a “big deal”; and one that contains the potentialities
of intergalactic cataclysmic consequences not often witnessed in our Time 
Matrix. The last time a full Edict of War was issued against the Founders and 
Emerald Covenant races was when Anunnaki legions attempted to destroy
humanity and take over Earth 5,500,000 years ago  during the First Seeding 
of humans on Earth (see page 17), which concluded in the Electric Wars 
that brought Human Seeding-1 to an abrupt and cataclysmic end. Our con-
temporary drama does not have to conclude with the Electric Wars history
repeating itself, but much of the outcome will depend upon what we, as the 
humans of Earth, choose to do, or not to do in the next nine-year period.
       Presently, the greatest threat to our global well being is not the UIR 
itself but rather our amnesia and resulting ignorance  as to how to handle
ourselves effectively. If  we  all sit around and wait for the  “First Contact Mass 
Landing ” to occur,7 to “prove” to us that our ET visitors are real, by THEN, 
know it is too late to do anything other than seek out the nearest Guardian 
evacuation team.  If the First Mass Contact drama does take place, as the 
UIR presently intends  (anywhere between 2002 end and 2005), they will have 
already gained full control of Earth’s portal systems, and will be able to ini-
tiate pole shift precisely when desired via the Nibiruian Battlestar , the crys-
talline installation beneath Stonehenge, England  and their global network 
of subterranean bases  located across the planet. Prevention is the only way
to solve this drama peacefully  before it goes any further.   
    If the UIR movement has its way , the illusion of peace  on Earth will be
maintained until they have their photo-sonic beam-ship fleets in position , 
cloaked within the lower Dimension-4 frequency bands(as many are already)
The fleets will be positioned over numerous secondary Target Sites and 24 Pri-
mary Target Sites , Earth’s 12 Primary Star Gate “Signet Sites”  and their cor-
responding 12 “Templar  Cue  Sites” , the activation sites for the corresponding
Star Gates.   
        Once fleets are positioned, progressive  instigation and amplification of 
conflict and regional wars among human nations will be further implemented 
via psychotronic technology,8  a process of scalar impulsing that has already
begun; Bosnia was the first mass experimental test run, and several other tests
have been already initiated in China,  the Middle East,  Russia and the USA.        
As “ETs” remain a hidden potentiality  to the masses, instances of “Mother    
Mary”, “Jesus”, “Buddha” and “Holy Figure”  holographic inserts  associated     
“Crying Statues and Paintings” and related pseudo-Divine phenomena will 
progressively appear to groups of humans who are mentally ensnared  in both
     _____________________________   
                       7.    In these ''landings,'' false personifications of '' Jesus, Mary and Moses '' will most likely
                                 emerge from a space ship to greet you.                                                                                                                                                 
                          8.    bio-neurological scalar pulse transmission
                      251                                                                                  
                                                                                                                      
                                                                                                                        
                                                                                                                                        

  2001 Update Section           
Traditional and New Age religious dogmas, promoting reassurance that “Gods 
Chosen Ones” will be “saved” in the “Great Cleansing” or “Tribulation”.  
    If the UIR, and their “Puppet Operatives” among the Human Illuminati 
are permitted to continue with their plan, certain hybrid-target-viruses  will be
released among select populations to reduce the number of races considered by
the Fallen Angelics to be expendable; the AIDS virus  was simply an exper-
imental test run originally orchestrated by the Drakonian Agenda Rigelian Zeta  
races via the their Human pawns within the Illuminati World Management 
Team Interior World Government.  The “chemical seedings” known as the
“Chemtrails Phenomenon”  is part of this plan, as certain chemicals that will 
facilitate the activation of the virus once it is released, are presently being 
imbued into the local atmosphere in target locations.   
        As the UIR plan goes on, the HAARP installation and several other 
related global 'facilities' will be activated to broadcast a mass “ Frequency 
Fence ”, a Photo-sonic scalar pulse technology that can harness human
brain-wave patterns  via bio-neurological blocking into a selected frequency
range within which the natural perceptual facilities can be technologically 
manipulated; the target date for the Frequency Fence is 2003-2004 . Once 
“the stage is set” , and global human con ﬂict, fear and instability has reached
its intended peak, the UIR intends to  stage a Mass Landin g, with Galactic 
Federation,  the Pleiadian-Nibiruian Anunnaki,  the Dracos  Reptilian-
hybrids of the Omicron-Drakonian collective and a few Rigelian Zetas 
thrown in for good measure, leading the way. The invading ﬂeets will “ Come 
in Peace as the Peacemakers ”, claiming they are our ancient creator Gods 
and kin who have intervened to “protect us from destroying ourselves and our 
planet”; they will present seemingly miraculous cures for cancer and several 
other diseases (including the plagues they seeded) and provide seemingly
amazing technologies for environmental cleanup …the personifications of 
“Angels sent from above” . If their plan proceeds as intended, the Pope and a 
collective of global religious leaders will gather to inform the public of this 
“Great gift from God”, seducing the masses  into blind subservience to the
“New Angelic World Government”; a “Unified Humanity in the eyes of 
God”. All of these things are part of the UIR strategy to directly and physi-
cally infiltrate global human culture. If we allow them to go this far, our
“United Nations” will be “welcomed” into the Fallen Anu-Seraphim Anun-
naki controlled “ Federation of Planets” , which is a  cover-name  stolen from a
once-valid Emerald Covenant collective, that is now used to refer to territo-
ries conquered by the Anu-Seraphim Anunnaki; territories that exist under
full Anunnaki totalitarian exploitation and dominion. Then and only then,
will the final phase  of the invasion plan be set in motion.  
    In the final phase of the UIR plan, which must occur before the natural 
2012  opening of the Halls of Amenti star gates if the takeover is to succeed, 
Earth’s portal system will be used to invade the territories of Inner Earth , the
252 

                                                                
                                                                          The September 2000 UIR and the Edict of War
 control matrix for the Halls of Amenti Star Gates, which are the real object 
of the UIR conquest. Once Earth’s portals are used to invade the Inner Earth 
Amenti Temple-Generator Complexes , unannounced pole shift on Earth 
will be rapidly set in motion via the Nibiruian Battlestar and a stunned 
humanity will have little more than three days  time to contemplate
“what just hit them”.   
    This is the UIR Plan,  numerous phases of which have already been set
in motion. When the potentialities of a “Zeta Ruled Society” were revealed 
in the 1997-98 GA dispensations that were first published in the 1999 release 
of Voyagers Volume-1:The Sleeping Abductees,  the possibilities of what 
could occur in the event of a UIR Final Conflict Drama were not even 
addressed. At the time of the V oyagers Series 1999 first printing, the 
Founders and Emerald Covenant races were confident that the 1992 Pleia-
dian-Sirian Agreements with the Anunnaki legions would ensure that the 
Orion Zeta forces would not succeed in their intended 2000-2017 attempt of 
instilling a One World Order totalitarian rule on Earth. If left to their own 
devices, the Rigelian Zeta legions would have  “settled for” general dominion
of Earth and forced enslavement  and exploitation of human populations, 
rather than pole shift destruction. But when January 2000  brought the con-
firmed news that a Stellar Activations Cycle would indeed take place on
Earth, even the Zeta and Human Illuminati initiatives were overrun by the 
involvement of the “ big guns ” from of the Fallen Annu-Elohim and Fallen 
Seraphim collectives of Density-4 Dimensions 11 and 10 respectively. The 
“big gun” Fallen Dark Avatar  collectives “play for keeps”, and are not inter-
ested in enslaving humanity; they desire to destroy humanity,  as the once-
Angelic Human species has historically been the primary obstacle  to the
Fallen Angelics in fulfillment of their age-old intention to take full control of
this Time Matrix. Since 22,326 BC , when Emerald Covenant forces blocked 
consummation of a pending SAC to prevent the “big gun” Fallen Angelics
from seizing Earth and the Halls of Amenti, the Fallen Dark Avatar collec-
tives have watched and waited for the 2000-2017 SAC,  with the intention 
of “finishing what they had started”  in 22,326 BC. January 2000 heralded
confirmation of the 2000-2017 SAC, and the whole mess of the “ Final Con-
flict Drama ” was rapidly brought to our earthly door. The present drama and 
its potential consequences are much more serious  and potentially damaging
than those first revealed in the “Zeta Ruled Society” probability depicted in 
Voyagers V olume-1.   
    But we still have time to prevent this mess, if we get our collective
human act together. Fear is the most useless, self-indulgent response we 
can choose to entertain ; no one is going to “fix this for us” but ourselves, and
if we are wallowing in fear like quaking ninnies we will guarantee our own
defeat. Fear is a chosen respons e and so too is courage  and calm, centered 
action; if necessary, allow a bit of natural fear to move through  you and out, 
253                                                                                                                        
                                                                                                          

  2001 Update Section  
then stand up and be effective anyway —humanity holds the power to see 
this thing through to a peaceful outcome of freedom, but only if we become 
rapidly responsible in employing informed, effective attitudes...and...action. 
      Humanity is not alone or unsupported in this rapidly manifesting
Final Conflict Drama; there is much more direct support from interstellar 
Emerald Covenant nations than there is force behind the UIR. The only rea-
son Guardian legions have not made direct, public contact with humanity to 
warn and prepare us for this political confrontation is because the Pleiadian-
Nibiruian Anu-Seraphim Anunnaki forces have held control of  Universal
Solar-Star Gate-4 since 25,500 BC, and have, since the time of the 1992 Ple-
iadian-Sirian Agreements, threatened to use Solar Star Gate-4 and the
Nibiruian Battlestar to  initiate immediate pole shift and destruction on 
Earth if Emerald Covenant representatives attempted to make mass contact
to warn humanity.   
    It was in the Anunnakis’  vested interests to hold off on pole shift because
 fulfillment of their intended One W orld Order dominion agenda and subse-
quent seizure of the Halls of Amenti star gates requires the temporary use of 
humans to open the Security Seals on Earth’s star gates, which the Fallen 
Angelics cannot full access without human biology (i.e DNA Template).
They would have “cleared the real estate” by now if their plan did not require
the use of the specific scalar-wave templates characteristic of human biology
to access the electromagnetic Star Gate Security Coding on Earth’s Plane-
tary Shields scalar template. Only human biology possesses the Security 
Codes to Earth’s Templar, because the Angelic Human species was created  as 
the legitimate Guardian race of this planet, and thus received from the 
Founders races the Planetary Star Gate codes of Earth and the Halls of 
Amenti star gates, within the biological design of the species DNA Template.
This fact of human biology has been the primary reason that humans have 
been historically preyed upon by Fallen Angelic legions, but has also served 
as our primary means of protection from being completely destroyed by the 
Fallen Angelics in their quest for the Halls of Amenti; as long as we are 
needed to open Earth’s Star Gate Security Seals, they don’t dare destroy us if 
they hope to claim control of the Halls of Amenti star gates. But once we
have been sufficiently used to open the Templar Security Codes of Earth dur-
ing an active SAC, we rapidly become expendable. And this is precisely 
what we have been “set up for” since the 22,326 BC cancelled SAC ended
in a stalemate between Emerald Covenant and Fallen Angelic races.  
254 
 

                                                                         
                                                   The D-12 Planetary Security Seal, Planetary Shields...                                                                                                
                  THE D-12 PLANETARY SECURITY SEAL, PLANETARY SHIELDS                                       
                                              CLINICS, AND CRISIS  INTERVENTION  
    If GA  forces had demonstrated a show of power through orchestrating
a mass contact drama to warn humans  of the Anunnaki and Drakonian
intentions, the Anunnaki intended to abort their desired outcome of strategi-
cally using humans to “open the Amenti Gates”, and would settle instead for
destroying contemporary humans via  immediate pole shift, while capturing a
few humans as potential enslaved “Gate Code breeders”. The Anunnaki 
legions, as well as the Drakonian legions, have long understood that if
humanity became awakened,  the Fallen Angelic Amenti dominion plan 
would rapidly come to a screeching halt. Humanity has a hidden power 
within the DNA Template,  through which the innate Planetary Star Gate 
Security Codes can be used to trigger activation of a  natural 12-Dimensional 
Planetary Security Seal  within Earth’s Templar, which if successfully erected,
would permanently protect Earth’s portals and Star Gates  from any further 
Fallen Angelic infiltration. Humans are the greatest threat to the Fallen 
Angelic agenda,  and for this reason they have gone to great lengths to ensure
our genetically-induced race amnesia  and our ignorance to the Sacred Sci-
ence Physics knowledge  through which humanity can regain its intended 
guardianship of Earth’s Templar Complex star gate system. The contemporary
hidden battle with the Fallen Angelic-ET legions cannot be won with exter-
nal weapons and overt war ; the Photo-sonic and Photo-radionic weapons
capacities of the Fallen Angelic legions makes contemporary human weapons
technologies appear as child’s toys in comparison. In terms of the present 
conflict drama, a military stance on humanity’s part is utterly useless, as
humans are literally  “fighting invisible dragons  (and Anunnaki) —a hidden 
adversary that cannot even be tangibly identified due do their superior inter-
dimensional cloaking technologies . Technologically, we're “gonners”. Exter-
nal Technology is not the medium through which the contemporary “playing 
field” becomes leveled for fair play. Knowledge of genuine spirituality, Per-
sonal and Planetary Templar mechanics  and the dynamics of human biology 
and DNA will be the deciding factors in this Final Conflict drama. In this 
regard, “the organic God-given brain and the biological DNA  are might-
ier than Photo-sonic swords born of unnatural external technologies”;
humans can, in the SAC of the present generation, set this planet free from 
27,500 years of covert ET enslavement  by effectively using their God-given
gifts of biology and Spirit.    
    The technology through which humanity can reclaim its freedom and 
intended heritage during the 2000-2017 SAC, and by which the previously
described UIR One World Order dominion agenda can be stopped in its 
tracks, is an internally directed Divine Science technology called  Planetary 
Shields Clinics.  The technical dynamics  of Planetary Shields Clinics are 
beyond the scope of this book; the GA and Azurite Templar Security Team
255 
                                                                                                                                                                                                                             
                                                                                                                                            

  2001 Update Section  
has been directly engaged in conducting advanced Masters Templar training 
workshops  and active Planetary Shields Clinics  since January 2000,  with 
the intention of assisting Earth and humanity in safe- passage through the 
2000-2017 SAC. As per the 1992 Pleiadian-Sirian Agreements, the Anun-
naki legions of the Galactic Federation, Ashtar Command, the Pleiadian-
Nibiruian Council, the Alpha-Omega Templar Melchizedeks, the Thoth-
Enki-Zephelium (Zeta) Nibiruians, the Enoch-Jehovian-Anunnaki collec-
tives and the “Archangel Michael” Nephilim-Nephite collectives were 
entrusted  to assist the GA and Emerald Covenant races in orchestrating 
Planetary Shields Clinics to ensure a safe 2000-2017 SAC. Only the Enoch-
Jehovian-Anunnaki collective has thus far  remained loyal to that 1992
promise. When the Anunnaki legions defected from the 1992 Pleiadian-Sir-
ian Agreements in January 2000, then rendered their final blow of human
 betrayal  in entering the July 5th, 2000, Treaty of Altair only to use this tempo-
rary status as a means of attempted sabotage against the Azurite Security 
Team, then defecting to support the September 12, 2000 Edict of War issued 
by the UIR, the GA and Emerald Covenant races have been on “ Red Alert ” 
and a direct Crisis Intervention plan  has been set in motion.  
        A  very specific program of “Crisis Intervention” Planetary Shields 
Clinics  has been mandated by the Founders, through which Emerald Cove-
nant races and humans who care enough to assist, can manually recode the 
electromagnetic programs in Earth’s Templar and Star Gates that otherwise 
allow the Anunnaki legions to hold Earth in false alignment with Nibiru via 
the Solar-Star Gate-4. The Anunnaki need Earth’s present artificial align-
ment with Nibiru to retain control of Solar Star Gate-4; without control of 
Solar Star Gate-4, the Anunnaki, and thus the UIR, lose their ability to 
force planetary pole shift on Earth . If humans can assist the Emerald Cove-
nant Guardian Races from the Interdimensional Association of Free Worlds
and Azurite Universal Templar Security Team  to restore the natural align-
ment of Solar Star Gate-4 via releasing the artificial Nibiruian programs  in 
Earth’s Templar that  presently hold  Solar Star Gate-4 under Nibiruian con-
trol, the UIR will lose its present “trump card” in this Final Con ﬂict drama. If 
Emerald Covenant races are successful in realigning Earth’s Templar and 
Solar Star Gate-4 to their natural orientation to the Pleiadian-Alcyone Spi-
ral, the previously mentioned 12-Dimensional natural Security Seal  on 
Earth’s Templar can be effectively triggered into activation, blocking UIR 
ﬂeets from entering Earth’s portal and vortex system any further. The chal-
lenge  of the Emerald Covenant Crisis Intervention Program is that it must 
reach a certain stage of advancement  before August 2003 , when the UIR
intends to begin positioning its Photo-sonic Beam-Ship ﬂeets over the previ-
ously mentioned 24 Primary Target Sites  to begin transmission of the 2003-
2004 Frequency Fence  via linking the transmissions of the beam ships 
with the HAARP grid network of Earth.  
256  
                                                                                                                                                                                                                                              

                         
                                     Invasion Agenda, HAARP , Merkaba-Reversal and the Rude Awakening
                      
               INVASION AGENDA, HAARP , MERKABA-REVERSAL,                                                                        
                                           AND THE RUDE AWAKENING   
    Linking of the Invasion Fleet, cloaked in D-4 Frequency Bands, to the
  HAARP grid network of Earth requires the use of the Nibiruian aligned 
Solar-Star Gate-4 ; if this link is successfully made in 2003, Emerald Cove-
nant  forces  can   do   nothing    to    prevent  the UIR from orchestrating the pole 
shift scenario at their whim. If the Emerald Covenant Crisis Intervention 
Planetary Shields Clinics are successful by 2003 , and Solar Star Gate-4 is 
returned to the Founders' protection, the Invasion fleets will be unable to
link with the HAARP network,  which was installed on Earth under the
orders of the Zeta Rigelians of the 1930’s Illuminati Human-Zeta Treaties, in 
anticipation of the 2003 Frequency Fence initiative, which originally was an
 Drakonian-Zeta agenda that was consolidated  into the UIR OWO agenda on 
September 12, 2000.  If Emerald Covenant Planetary Shields Clinics are not 
successful by 2003, the only recourse to protect human populations will be
attempted Emerald Covenant evacuations , which will most likely bring a 
“star wars” drama  rapidly down on humanity’ s head (as has repeatedly
occurred during SAC periods in the past), along with the obvious global
political  panic and chaos that would result from such a drama. If evacuations 
become the only recourse during the present SAC drama, only humans with 
a minimum of 4.25 Strand Sustainable DNA Template activation will be 
able to biologically survive the portal transit to safe ground.9 
    The “Divine Beauty” and simplicity of the Emerald Covenant Crisis
Intervention Plan is that running the Planetary Shields Clinics to clear 
Earth’s electromagnetic grid system requires no militant stance of aggres-
sion, no projection of personal power onto some “Guru, God, Angel or 
channel” outside of yourself, no adherence to any dogma or sacrifice of 
present belief systems, no hatred toward any “enemy” seen or unseen, and 
no entrapment within ideologies of powerlessness and victimization. The 
Planetary Shields Clinics through which Earth can be set free require only 
a willingness to re-awaken to the Sacred Templar Mechanics that were     ____________________________________________  
                     9.     The GA’s Kathara Bio-Spiritual Healing System,  and the DNA Template Bio-Regene-
                sis T echniques  excerpted from this program that appear at the end of this book , are the 
              fastest methods  of naturally activating the dormant 12-Strand DNA  T emplate of
               humans. Most humans are presently at only a 3 to 3.5 Strand DNA Template activation
               level; an insufficient DNA  activation level for sustained portal transit that would result in
                 biological spontaneous combustion if off-planet evacuations were attempted. Not only 
               will the Kathara Healing System rapidly advance natural healing potentials,  assist in 
               expediting genuine personal spiritual integration and progressively build a natural 
               immunity in the personal bio-energetic field and body to psychotronic manipulation , it 
               will stimulate at least enough DNA  Strand T emplate activation for the human biological 
               organism to sustain a minimum 4.25 DNA  Strand T emplate activation level should off-
               planet evacuation become necessary . The Kathara Healing program is highly recom-
                                            mended for obvious reasons; and these are the very reasons that the GA provided the trans-  
                lation of the ancient Kathara Healing teachings in February of 2000.  
                             257                            
                        
                                                                                                                                               

                                                                                    2001 Update Section
once practiced as “daily common knowledge” among the pre-Ancient 
advanced Angelic Human cultures.  True Templar Technology  has always 
been an internal technology  that operates through advanced, natural, Inter-
nal Merkaba Mechanics ; organic dynamics of interdimensional electromag-
netic energy exchange that take place naturally between the Earth’s core 
scalar-wave blueprint (the Planetary Shields ) and the scalar-wave blueprint 
or “Divine Blueprint” of the human DNA Template.  Internal Merkaba T em-
plar Mechanics, when practiced with integrity, are the very same dynamics of
 energy that allow for full spiritual integration  of higher dimensional con-
sciousness into embodied expression within the physical human form, and 
which allow for the once-natural human attribute  of Atomic Transmutation 
and  self-directed Ascension  out of manifest density.10 
    If you have had the misfortune to unknowingly study Merkaba Mechan-
ics under the Anunnaki “edited teaching system, ” you will have learned 
only enough about Merkaba to know how to “ inadvertently ” link your per-
sonal Merkaba Fields to those of other people to form an amplified “Group 
Merkaba”, without securing the natural integrity  of your own bio-fields via a 
natural D-12 frequency alignment to your personal internal D-12  Pre-matter
Christos level of personal anatomy.11 Once you have been taught to indis-
criminantly “open your fields and activate your Merkaba”, you will also have 
been unknowingly  directed to “ run your Merkaba spin ratios in reverse ”. 
Since you have depended upon the Anunnaki “teachers” to “enlighten” you 
about the “secrets of  Merkaba”, you personally have no idea how a Merkaba 
Field  is really supposed to be activated  or maintained, so you can’t tell the 
difference when you are being conned  into running the External Reversed
Merkaba  which blocks your ability to embody natural D-12 frequency for 
genuine higher DNA Strand Template activation. And if you have bought
into the Anunnaki Merkaba Systems  presently being taught through the 
Thoth-Enki-Zephelium Nibiruian Anunnaki and the Alpha-Omega Order  
Templar Melchizedek Anunnaki legions that defected from the 1992 Pleia-
dian-Sirian Agreements, and their recent cohorts in the '' Archangel 
Michael,''12 Galactic Federation  and Ashtar Command  Anunnaki collec-
tives, you will not realize that your inadvertently created External Reverse -
Merkaba field  is being actively used to amplify the 34-Top-Magnetic-
Counter-clockwise, 21-Bottom-Electrical-Clockwise  and BASE-1 1-accel-
eration Nibiruian Reverse-Merkaba spin ratios  in Earth’s grids. Through 
this External Nibiruian Reverse-Merkaba field that some Humans are being  
tricked into creating , the Nibiruian hold on Earth’s Templar is amplified, 
while the human participants are unknowingly “ down-loading ” their inher-_________________________________  
10.  Via Universal Star Gate passage.  
11. You wo n’t have learned much about the reality of your 15-Dimensional Anatomy from
       the Anunnaki either.  
  12.  More aptly described and historically known as ''Arch-Demon Michael. ''  
                                                                                                                
258                        

                     
                     
                        Merkaba Mayhem, REAL Ratios and the Nibiruian Checkerboard Mutation
ent DNA Template Planetary Templar Security Codes into Earth’s grids to 
assist the UIR  in gaining open access to Earth’s Star Gates.   
     These are items just a few of many little facts that the Anunnaki “ascen-
sion programs” fail to mention to the Humans they are sweetly patronizing
 and covertly brainwashing into assisting the UIR objective  through “ chan-
nel Contact ” directives in the New Age Movement. Heads Up, Guys!  Time 
for the Rude Awakening!   
    Do you trust your own potential, inborn Inner Christos Connection , or 
have you inadvertently placed your power , your free will mode of thinking , 
and your potential for true “Christed Consciousness ” and spiritual mastery, in 
the hands of some glorified, self-proclaimed angel or "demi-god" that prom-
ises to create ascension and Christ Consciousness for you?     
    It is a very good time to muster enough humility to take this question 
very seriously.   
         MERKABA MAYHEM, REAL RATIOS , AND THE NIBIRUIAN 
                                CHECKERBOARD MUTATION                
        The natural ''Christiac Merkab '' spin ratio for a being in Density-1/
dimensions 1-2-3, which allows for natural , progressive , automatic Merkaba
Field acceleration and 12-Strand DNA Template activation  for  attainment 
of real D-12  “Christ Consciousness”, Ascension and Star Gate passage, is as 
follows: 33-and-one-third-Top-Electrical-Clockwise, over 11-and-two-
thirds-Bottom-Magnetic-Counter-clockwise,  which is the natural Merkaba
 spin ratio for Density-1 Earth, when Earth’s grids are not being artificially 
forced into mis-alignment with Nibiru. Merkaba Fields govern the circula-
tion and ratios of particle and anti-particle energy  in matter and within the 
human body. It is due to the artificial Reverse-Merkaba spin of Earth’s Den-
sity-1 Merkaba Field , which the Nibiruians orchestrated during the 25,500 
BC Lucifer Rebellion, that the matter base of Earth, and thus that of the 
Human body has been mutated into having two-thirds more particle density 
than the natural blueprint for Density-1. This Nibiruian Legacy and Hidden 
Horror of History of Earth’s 25,500 BC Planetary Merkaba Reversal, which is 
known as the “ Checkerboard Mutation ,” and its continuing devastating con-
sequences regarding Human evolution, DNA and the biological integrity of
all Earth species, are addressed in detail in the forthcoming GA CDT-Plate 
translations. The true Density-1 natural Internal Merkaba Spin Ratios  pre-
viously mentioned can be manually reset  to progressively heal the personal 
Reverse-Merkaba and its resulting  mutations of the DNA  T emplate within 
the Human body, even though Earth’s grids will continue to carry this distor-
tion until Solar Star Gate-4 is brought back into its natural Alcyone-Spiral 
alignment. To maintain the natural personal Merkaba Spin, it must be manu-
ally reset in the body every 24 hours,  or the Reverse-Merkaba  
Spin in the Earth’s grids will override the personal restoration.  
259  
                                                                                           
                                                                                                   
 

      2001 Update Section  
    Advanced Emerald Covenant Merkaba teachings are in the process of 
being released, but are beyond the scope of this book. The four Bio-Regene-
sis Techniques  (see page 493) begin the process of healing the personal
Merkaba and DNA Template. When the Human Merkaba Vehicle is func-
tioning properly, both males and females use the same “androgynous”  Har-
monic Merkaba Spin  and the small internal D-1 Merkaba Field within the 
Tailbone  is not stationary —it rotates, as it is intended to do . The “fixed” 
tailbone Merkaba Field  is the mark of the Nibiruian Merkaba-Reversal  that 
keeps the physical body literally locked into its present time vector  and 
unable to achieve Star Gate passage —Another  of several other “little secrets  
'' that Thoth and his friends conveniently  forgot to mention to their human 
“students”.  
    One is better off using the D-12 Based Maharata Current Bio-Regene-
sis Techniques  (see page 503) until more advanced, genuine Merkaba  
Mechanics are available, as these Techniques will begin to automatically 
reset the natural Density-1 Merkaba Ratios in the body. Further techniques 
to accelerate  and fully activate  the natural Merkaba are on the way. Most  of 
the humans who have fallen into using or teaching  the Nibiruian Reverse-
Merkaba  have been covertly “set up” by the Thoth-Enki-Zephelium or 
Alpha-Omega Templar Melchizedek Anunnaki races to propagate this Base-
11-Reverse Merkaba  perversion. Most, but not all, human teachers of Merk-
aba do not realize that they have been deceived in this way, and are not
intentionally bringing harm to their students; the teachers themselves are
being victimized and deceived by Fallen Angelic contacts.  
 
                                                     260
                     

                                                                          14   
                                                                 
                                               
                                                                                                                                                                            
                 
    The Angelic Human Heritage
   and Rainbow Roundtables
  •  Our mystical teachings and religions of today emerged from the distant past
      of the Pre-Atlantian era. Mystical and religious teachings have covertly
   directed evolving humanity toward very specific objectives; objectives
    pertaining to a Hidden Sacred Mission of Planetary Guardianship that the
     Angelic Human race was seeded on Earth to fulfill. Originally all mystical
     and religious teachings were intended to guide us toward fulfillment of this
     Sacred Mission, but due to intentional distortions of Sacred Spiritual-Sci-
    ence texts many of the ancient spiritual education systems now mislead
   humanity into creating the opposite of what our original Sacred Mission
     intended.  
  •  In exploring the realities of our ancient “Forbidden History”  we rediscover
 the true origins and nature  of the Angelic Human race . In rediscovering
 our true origins and nature we reclaim our memory of the original Sacred
  Mission of Planetary Guardianship that our race has come to Earth to
  fulfill and the methods of Divine Spiritual-Science Mechanics  by which
 our Sacred Mission can be successfully accomplished.  
 •  The keys to understanding our present-time global drama  are hidden within
       the ancient Secrets of Lemurian and Atlantian civilization.  T o under-
       stand the significance of the Lemurian and Atlantian Empires of the more
        recent past, we need to move further back in time to the initial civiliza-
       tions of 12-Tribes Angelic Human Seeding-3 , the origins of the present
        Angelic Human race. Through knowledge of our origins we will rediscov-
       er what our race came to Earth to accomplish. Identifying the Original Di-
       vine Objective  of the Angelic Human race will enable us to examine
        spiritual and mystical creeds more clearly , with an eye toward differenti-
       ating between what leads us toward or away from our race’s Original Di-
          vine Objective.  
    261 
                                                                                                                     
                                                                                                                     
            


  
The Angelic Human Heritage and Rainbow Roundtables  
 
• The Keys to Effective Action Today are held within the Secrets of our Pre-  
     Lemurian-Atlantian origins, through which our race’s Original Divine  
     Objective and the methods of its accomplishment are rediscovered.  
             
        GENETIC ASCENDANCY OF ANGELIC HUMAN LINEAGE  
• Breneau Founders Races:  Emerald, Gold and Amethyst Order Breneau  
Emerald Order-Elohei-Elohim, Gold Order-Seraphei-Seraphim,  
Amethyst Order Bra-ha-rama  
Density-5 Primal Light Fields (Dimensions 13-15)  
Ante-matter Wave Form, 950 Billion Years Ago  
• Anuhazi:  Elohei-Elohim Feline—Hominid Emerald Order  
Density-4 Pre-Matter Hydroplasmic Field (Dimensions l0-12)  
Pre-Matter “Liquid Light” Form “Christos Race”  
950 Billion Years Ago Lyra-Aramatena  
• Azurites 48-Strand DNA Template Angelic Hominid  
Blue-skinned, feline-avian-cetacean hominid  
Anuhazi  (feline-hominid, Elohei-Elohim Emerald Order) +  
Cerez  (avian-hominid, Seraphei-Seraphim Gold Order) +  
Inyu (cetacean, Bra-ha-Rama Amethyst Order)  
Densities-1-4 (Dimensions 1-12)  
Pre-matter, Etheric, Semi-Etheric and Physical Matter Forms  
250 Billion Years Ago All Universal Star Gate locations  
 • Oraphim 24-48 Strand DNA Template Angelic Human  
Azurite of Sirius B + Anuhazi of Lyra-Aramatena.  
Densities 2-4 (Dimensions 4-12)  
Pre-matter, Etheric Matter, Semi-Etheric Matter Form  
568 Million Years Ago Sirius B, Procyon, Orion-Mintaka, Gaia  
Tara, Alcyone, Altair  
• Turaneusiam-1 Angelic Human 12-Strand DNA Template- Tara and  
     Maharajhi 24-48 Strand DNA Template Blue Human Sirius B  
 (Maharajhi = Oraphim-Human + Sirius B Azurite)  
 Densities 2-3 (Dimensions 4-9)  
 Etheric Matter, Semi-Etheric Matter Form  
 560 Million Years Ago Tara, Sirius B  
•  Maji Cloister Host Race Angelic Humans 12-48 Strand DNA Templates and
     Turaneusiam-2 12 Tribes Angelic Human 12-Strand DNA Templates  
Densities 1-4, (Dimensions 1-12)  
Pre-matter, Etheric, Semi-Etheric, and Physical Matter Form  
Seeding-1 Ur-Tarranate-Cloister 249,998,000 BC-24,998,000 BC  
Seeding-2 Dagos-Cloister 3,698,000 BC-846,800 BC  
262 
                                                                 

   
                        12-Tribes Seeding~3 Genetic Ascendancy
 Seeding-3 Urtite-Cloister 798,000 BC
 Earth, Tara, Gaia and Parallel Systems
                             
         12-TRIBES SEEDING-3 GENETIC ASCENDANCY
• Urtite-Cloister Host Race for Seeding-3 12-Tribes Races
      Serres-Egyptian (Pleiadian Serres avian-hominid + Seeding-2 Br eanoua-Atla-
             nian Cloister + Aryan Root Race) + Hebrew (Seeding-2 Hibiru +
             Melchizedek Mixed Cloister) + Seeding-2 UrAntrian- Lamanian Clois-
             ter.
• The five Palaidia Urtite-Cloister Maji Grail Lines
      144,000 (12 Tribes of 12,000) simultaneously seeded on Earth in 798,000
            BC in 24 different subterranean locations (6,000 each) to begin An-
            gelic Human 12-Tribes Seeding-3 . The later evolutionary cycles of the
            Angelic Human Cloister Races and Root Races, including the Le-
            murians, Atlantians and Aryans emerged from the five Palaidia Ur-
            tite-Cloister Races.
• three Urtite-Tri-Cloister Races (Indigo Type-1)
     (Carry combined DNA Template coding of Urtite-Cloister + Shambali +
            Bhrama. Mixed—Cloister races that evolved in Inner Earth after the
            846,800 BC end of 12-Tribes Seeding-2.)
• Mu’a Urtite-Cloister (Muarivhia)
       Keepers of the Blue Flame Eckatic Codes;
       43-48 Strand DNA Templates
• Yu Urtite-Cloister
       Keepers of the Gold Flame Polaric Codes;
       37-42 Strand DNA Templates
• Ur Urtite-Cloister (Urta)
       Keepers of the Violet Flame Triadic Codes
       31-36 Strand DNA Templates
• 2 Urtite-Bi-Cloister Races (Indigo Type-2 )
       (Carry combined DNA Template Coding of 2 Urtite-Tri-Cloister Ra ces)
• Breanoua Urtite-Cloister (Mu’a + Yu Urtite-Tri-Cloister)
       Keepers of the Blue-Gold Flame Eckatic-Polaric Codes
       28-30 Strand DNA Templates
• Rama Urtite-Cloister (Yu + Ur Urtite-Tri-Cloister)
       Keepers of the Gold-Violet Flame  Polaric-Triadic Codes
       24/25-27 Strand DNA Templates
263
                                                                                                                                

  The Angelic Human Heritage and Rainbow Roundtables  
          THE AZURITES, IAFW, ORAPHIM-ANGELIC HUMAN, MC               
       PRIESTS OF UR, AND INDIGO CHILD EIEYANI GRAIL LINE
      Throughout the long history of the Founder Race “ Angelic Wars ” 250
billion-570 million years ago,  the Emerald Order Elohei-Elohim Anuhazi
Feline-hominids, Gold Order Seraphei-Seraphim Cerez  Avian-hominid and
Aethien  Mantis and Amethyst Order Bra-ha-Rama Inyu  Cetacean and
Pegasai Winged-horse-deer  races worked to restore Universal Star Gates 11
and 12. Following destruction of Lyra-Aramatena and Star Gate-12, the
Emerald Order Breneau and their Elohei-Elohim Feline-hominid races were
appointed by the Yanas Collectives from beyond the Time Matrix, to serve as
the Primary Universal Templar Security  T eam in our Time Matrix. The Elo-
hei Emerald Order Feline-hominids were commissioned to organize and assist
guardian nations in securing the Universal Templar Complex from Fallen
Angelic Race dominion, and to implement genetic Bio-Regenesis Programs
to assist fallen races in re-evolving their original potentials of ascension.
Upon request of the Yanas Collectives, the Density-5 Breneau Orders and
their Emerald Order Anuhazi Feline-hominids, Gold Order Cerez Avian-
hominids and Aethien Mantises and Amethyst Order Inyu Cetaceans and
Pegasai Winged-horse-deer races created the universal service organization
called the lnterdimensional Association of Free Worlds-IAFW.  
         In order to provide greater protection and healing efforts in our Time
Matrix, Emerald Order Elohei-Elohim Anuhazi  Feline-hominids, Gold
Order Seraphei-Seraphim Cerez Avian-hominids and Amethyst Order Bra-
ha-Rama Inyu Cetaceans  (forefathers of the Whale and aquatic Dolphin)
co-created a new guardian-healer race called the Azurites. The Azurites  are
a blue-skinned land-water mammal feline-avian hominid, some bearing
feathered heads and wings, which were created 250 billion years ago with
the formation of the IAFW.  The Azurite Race, carrying the full spectrum of
the three Founders Race’s original core genetic templates or ''Ascension
Codes,'' represented a new “ Yani ” (meaning “Yanas embodied”) race-form
through which the Density-5 Breneau and Yanas Ascended Masters Collec-
tives from beyond the Time Matrix could incarnate directly into the density
systems. The Azurite Yani race line was simultaneously seeded into every
Density Level in our 15-dimensional Time Matrix, placed in galactic and
planetary proximity to the 12 Universal Star Gates  of our Universal T em-
plar Complex. The Azurite Yani race was placed under the guidance of the
Emerald Order Breneau Elohei-Elohim Feline-hominid Universal Security
Team. The Azurites were appointed by the Yanas and Density-5 Breneau
Orders as the Azurite Universal Templar Security Team , commissioned to
protect and repair the structural integrity of our Time Matrix and with assist-
ing all races in their evolution to ascension and freedom from the Time
Matrix.  
264 
 
 
                                                          

                                                                                                  
                                   The Azurites, IAFW/, Oraphim-Angelic Human...
         About 570 Million years ago , the Angelic Wars between the fallen
Annu-Elohim Anyu aquatic-apes and Bipedal Dolphin People and fallen Ser-
aphim Insect, Omicron-Dragon-Moth, Dino and Odedicron-Lizard races had
escalated to the point of potentially imploding this Time Matrix. The
Breneau Orders of Density-5, with assistance from the Azurites and Emerald
Covenant races in the Time Matrix, repaired Star Gates 11 and 12. Able to
implement direct access to our Time Matrix once again, the Density-5
Breneau Orders intervened, offering the second restatement of the Emerald
Covenant , through which members of any of the races could re-enter co-cre-
ative, co-evolution agreements.  
    Many of the fallen Seraphim Insect, Drakon-Moth and Lizard races and
some of the Annu-Elohim Dolphin People and Anyu Aquatic Ape races
entered this peace treaty. Fallen races entering the Emerald Covenant
restatement 570 million years ago agreed to work together under the direc-
tion of the Elohei-Elohim Anuhazi Feline-hominid, Seraphei-Seraphim
Cerez Avian-hominid and Aethien Mantis and Bra-ha-Rama Inyu Cetacean
and Pegasai Winged-horse-deer races. As per the Emerald Covenant restate-
ment 570 million years ago, the Azurites and Emerald Covenant guardian
races would assist fallen races to reverse-mutate their faltering genetic tem-
plates. In return for this guardian race assistance, regenerated fallen races
would assist guardian races to restore the integrity of the Universal and Inter-
planetary Templar Complexes and bring peace to our Time Matrix. Races
entering the Emerald Covenant restatement agreed to allow the Breneau
Orders to incarnate into our Time Matrix by entering another new life form
that would, like the Azurites, carry the genetic imprint of all stellar Founder
Races.  
     This new life form, which would also harbor the consciousness of the
Breneau Orders and Yanas Ascended Masters Collectives in manifest
form, would serve as the embodied, commissioned Keepers of the Univer-
sal Templar Complex, assisting all stellar races in ful filling their potentials
of ascension and freedom from the Time Matrix . The new guardian race,
intended to evolve to relieve the Azurite Yani of their long tour in density ,
would bring the co-creation agreements of the original Emerald Covenant of
Aramatena  back into play . The new race was intended to become the next
generation of the Universal Templar Security Team in our Time Matrix. Cre-
ation of the new race was intended to be a “ changing of the guard,”  through
which the Azurite Yani could transfer their commission in time to the new
race and ascend out of the Time Matrix to return to At-One-ment with
Source. This new race was created with the intention of embodying and
restoring to the races of our Time Matrix, peace, love and harmonious, coop-
erative evolution. Like the Azurite Yani, this new biological race would
present a genetically perfected form  through which the consciousness of any
stellar collective could incarnate to reclaim the original integrity of its
Ascension Codes ; the new race was called the Turaneusiam  or the Angelic 
265 
    
                                                                                                                                                
                                                                                                                                                 
                  

  The Angelic Human Heritage and Rainbow Roundtables  
Human  of Density-2 T ara. The seed race for the Angelic Human was the
Densities 2-4 Oraphim,  meaning “ Children of the Light”  in reference to
their Breneau Order creators of the Density-5 (dimensions 13-14-15) Kee-
Ra-ShA Primal Light Fields.               
        CREATION OF THE ORAPHIM-TUR ANEUSIAM ANGELIC  
                        HUMAN CHRISTIAC-RISHIC GRAIL LINE  
     The Oraphim are a hybrid form of Lyra -Sirius A Anuhazi  (Elohei Emer-
ald Order Feline-Hominid), Sirius B Azurite Yani  (Elohei Feline-hominid,
Seraphei Avian-hominid and Bra-ha-Rama Inyu Cetacean) and Pleiadian
Serres  (Density-2 Seraphei A vian-hominid). The Oraphim  were seeded 568
million years ago  on Density-3 Sirius B, Procyon, Orion-Mintaka and Gaia
and Density-2 Sirius B, Pleiadian-Alcyone, Altair and Tara,  to begin cre-
ation of the Angelic Human  lineage. At the time of their creation 568  
million years ago,  a specialized group of Oraphim were further hybridized with
the Azurite Yani race of Sirius B, to create the Azurite-Oraphim “Blue
Human” Maharaji  lineage of Sirius B, the progenitors of the Christiac -
Maji-Indigo Child Grail Line on Earth.  The Sirius B Maharaji Azurite-Ora-
phim genetic line became further intertwined with the Turaneusiam Angelic
Human lineage of Tara 550 million years ago  through Bio-Regenesis pro-
grams  for the faltering Taran Oraphim-Turaneusiam Human race line.  
      One branch of the Maharaji Azurite-Oraphim human race line of T ara
became the Melchizedek Cloister Priests of UR Grail Line . The Taran MC
Priests of Ur Angelic Human Grail Line families became members of the
Azurite Universal Templar Security Team  and founded the egalitarian
Priesthood of Ur and the  original Azurite Temple of the Melchizedek
Cloister universal service organization on Tara. Another branch of the Taran
Maharaji Azurite-Oraphim lineage, the Ur-Tarranates,  seeded the 12-Tribes
Earth Angelic Human  lineage 250-25 million years ago. (For more informa-
tion on Indigo Children-Maharaji-MC Priest of UR Christiac Grail Lines ,
see Voyagers Volume 1, 2nd Edition). The original Lyran-Sirian-Pleiadian
Oraphim  prototype is a thin, 12-20 feet tall androgynous  feline-avian-
human land-water mammal “ Breatherian ” (does not eat; draws nourishment
directly from the atmosphere in which it is placed).  
     The original Oraphim have translucent deep tan or powder-white to
pale-blue skin, elongated skulls, petite, childlike  facial features, six fingers
and toes, and no ears or small cat-like ears on the side of the head. Some
have small cat-like lips and with a split in the upper lip and a feline nose ,
others have small, thin lips  with a mild downward dip in the upper lip that
resembles the shape of a tiny bird beak, with a petite human-child-like nose.
Some Oraphim have pure white head hair  resembling long, soft fur, others
are bald or have soft, white-feathered skulls.  All have hairless bodies and
large, slanted almond-shaped eyes of golden, electric blue or violet hue,
  266  
 
                                                                                           
                                                                      

                                                                  
                                                                        Creation of the Oraphim-Turaneusiam...
with pure white vertical pupils , thin eyelids with fine white eyelashes and
no eyebrows . 
     Several specialized Oraphim strains are more Feline, A vian or Cetacean
in biological structure. Specialized Emerald Order Elohei-Elohim Oraphim
strains appear as large upright feline-hominids with pure white fur cover-
ing the body , non-clawed paws and tails; Oraphim felines resemble the
white Persian cat species  of Earth and they often overshadow  this earthly
feline of their genetic association to interact with Density-1 Earth. Special-
ized Gold Order Seraphei-Seraphim Oraphim closely resemble the Eagle and
Swan avian species of Earth, having smaller eyes, wings and avian-hominid
bodies covered with pure white, soft blue-gray or jet black feathers . Spe-
cialized Amethyst Order Bra-ha-Rama Oraphim  are Cetacean, most  closely
resembling the Aquatic Dolphin and Whale specie s of Earth. Unlike the
Bipedal Dolphin People of the fallen Anu-Elohim, the Oraphim Cetaceans
do not have arms or legs , and though capable of breathing air or water, they
are designed for mobility in ﬂuid, not on land.  
     The Oraphim Cetaceans are pure white or pale-light-blue  in color, and
specialize in transmitting the sound  tones that hold the scalar-wave temples
for universal structure in order . The Oraphim Cetaceans created several
Dolphin and Whale species on Earth, to serve as their emissaries in maintain-
ing Earth’s biosphere. The fallen Annu-Elohim Bipedal Dolphin People have
also seeded several strains of  Dolphin, Whale and Shark species into Earth’s
biosphere, in attempt to gain sonic control over Earth’s Manifestation Tem-
plate. Though it is nearly impossible to detect the differences between the
Oraphim Cetacean and Annu-Elohim Cetacean species, there are a few sub-
tle differences  observable between them. Oraphim Cetacean  strains tend to
be lighter in skin color , are more vegetarian in diet, prefer warmer waters ,
are more receptive to human contact , have a more gentle, feminine mater-
nal nature and emit higher-pitched sound frequencies  than their fallen
Annu-Elohim Cetacean kin.  
     In their organic state , when they are not intermingling with other race
strains for the purpose of assisting in DNA Bio-Regenesis programs, the Ora-
phim Feline-Avian-Cetacean-Humans have full conscious power  over phys-
ical manifestation and de-manifestation, allowing them adaptability to
almost any environment and Density Level in which they are placed. The
Oraphim can “shape-shift” at will, and their biological forms are immortal
until they fully transmute out of the Time Matrix. After ascending out of the
Time Matrix, an Oraphim must rebirth in a new immortal body form to reen-
ter the Density systems of the Time Matrix. Though they are biologically
androgynous and do not have external manifestations of gender difference,
the “ male ” Oraphim  form carries a stronger electrical field and specializes in
electrical transmission of energy , while the “ female” Oraphim  form carries
a stronger magnetic field and specializes in magnetic reception of energy .
Like the Azurites, in combining of male-female bio-energetic fields, the Ora-
267 
                                                                                                                                                                                                                                   

The Angelic Human Heritage and Rainbow Roundtables  
phim have the greatest ability of any race in our Time Matrix to transmit and
receive the frequencies of the electromagnetic Primal Life Force Currents in
our Time Matrix. This energy reception-transmission ability makes them bio-
logically able to perform intensive structural repair of the universal mani-
festation template  in our Time Matrix, allowing them the capacity to ful fill
their creation commission as evolving guardians and Keepers of the Univer-
sal Templar Complex.  
     Oraphim can procreate independently,  but prefer procreation through
fusion or coupling of the bio-energetic fields of gender-twin mates . During
Oraphim procreation an energetic birth sack  is painlessly expelled from the
navel region of either male or female. The energetic sack contains cellular mat-
ter formed through the combined genetic imprint of the parents, or a replica of
the singular parent’s genetic imprint. Once the sack is expelled from the body,
the new incarnating Oraphim soul begins fetal integration. Gestation of the
Oraphim birth sack varies, depending upon the environment into which they
incarnate. The birth sack is placed within a planetary soil “nest,” then into a
water or fluid environment organic to the planet, allowing the incarnating
Oraphim to adopt the natural template structures characteristic to the envi-
ronmental system into which it is incarnating. After water or ﬂuid gestation,
the Oraphim embryo rapidly grows to the size of a human child of 8-12 years,
and emerges from the birth sack, fully sentient, mobile, telepathic and with full
regional spoken language capacity . The Oraphim race is the Seed Race from
which the Angelic Human Turaneusiam  emerged, and represents the state of
evolutionary fulfillment in time toward which all human races are re-evolving.
Like the Azurite Yani, the Oraphim race has a 24-48 Strand DNA Template ,
which embodies the full spectrum Ascension Codes through which transmuta-
tive ascension out of the Time Matrix can be achieved.  
    The Oraphim Seed Race of T ara represents the genetic ancestral heritage
from which the Turaneusiam Angelic Human 12-Strand DNA Template
emerged 560 million years ago  on Density-2 (dimension 4-5-6) T ara. The
Taran Turaneusiam Angelic Human is the genetic ancestral lineage  from
which the “Turaneusiam-2” 12-Tribes Angelic Human race line was seeded on
Earth 250-25 million years ago.  Contemporary humanity is part of  Angelic
Human 12-Tribes Seeding-3;  the first 2 seedings of the Angelic Human 12-
Tribes on Earth were destroyed through progressive infiltration and warring
with Fallen Angelic (“ET”) races. 12-Tribes Seeding-3 began in 798,0001 BC,
with introduction of the five Palaidia-Urtite Cloister  races, who composed the
first 12 simultaneous settlements  of the Seeding-3 12-Tribes. The Palaidia
Races are referred to as “ Maji Grail Line Angelic Humans ,” possessing 24-48
Strand DNA Templates  characteristic to the Lyran-Sirian-Oraphim Angelic
Human genome. From the five Palaidia Urtite-Cloister Seed Races  of
798,000 BC, Seeding-3 of the 12-Strand DNA Template Angelic Human  lin-
268 
 
                                                      

                   
                                                               
                                                               Seeding the 12 Urtite-Cloister Palaidia Empires           
    eage was progressively orchestrated on Earth, as part of a larger trans-time
                 Sacred Mission of Planetary Guardianship.  
    Members of the Palaidia Maji Grail Line Races have repeatedly incar-
   nated  during various periods of Seeding-3 Angelic Human evolution, to keep
  the 12-Strand and Maji Grail Line DNA Template potential alive within
  the Earth Human gene pool. The Angelic Human and Maji Grail Line gene
   pool has been kept alive on Earth to enable the Angelic Humans to complete
  the “ Sacred Mission ” which humanity had been seeded on Earth to ful fill.
  The Palaidia Maji Grail Line races have been incarnating on contemporary
  Earth  for the past 100 years ; they are referred to as the '' Indigo Children -
   T ypes 1 and 2.  The term “ Indigo Children ” refers to the frequencies of the
 6th-dimensional wave band, the Indigo wavelength  of the 15-Dimensional
  Spectrum.  Maji Grail Line Indigo Children are born with the 6th-Strand
  T emplate  of their 24-48 Strand DNA  T emplates activated at birth , whereas
  Angelic Humans with 12-Strand DNA  T emplates are born with three strands
  of 12 activated. Activation of the 6th-DNA  Strand T emplate allows the D-6
  Indigo wave spectra  and the D-6 consciousness  characteristic to this wave-
  length, to embody within the Indigo Child fetal body . The Palaidia Race
  Angelic Human Maji Grail Line Indigo Children T ypes-1 and 2 have been
   progressively incarnating on Earth in preparation for the Sacred Mission  of
  the long awaited 2000-2017 Stellar Activations Cycle.                        
           SEEDING THE 12 URTITE-CLOISTER PALAIDA EMPIRES  
    The secrets to unraveling the riddles of contemporary humanity’s origins 
and heritage lies in the distant past, within the first 12 Palaidia Empires  of
Urtite-Cloister races , through which the five Urtite-Cloister , five Cloister  
and 7 Root Races  (See  ''Root Races - Cloistered Races'' on page 15) of the
Angelic Human lineage emerged to commence Seeding-3  of the 12-Tribes . 
Each of the 12 Palaidia Empires  were constructed simultaneously , under-
ground, beginning in 798,000 BC . The Palaidia Empires were founded by
the five Seed Races  of the 25-48 Strand DNA  T emplate Maji Priest-King
Holy Grail Line  as its members incarnated through the Urtite-Cloister  
Angelic Human Host Race  of Seeding-3 (See page 56).  
            The Seeding-3 Urtite-Cloister Host races were seeded following the 
   organizational pattern set by the 549,998,000 BC  Taran Covenant of
   Palaidor  (See Page 6) which was previously utilized in both the Seeding-2
   Dagos-Cloister  and Seeding-1 Ur-Tarranate Palaidorian-Cloister Host   
   Race seedings. In accordance with the traditional race-seeding format, the    
   12 Palaidia  Empires of the Urtite-Cloisters were seeded upon the locations  
   of the 12 Templar Cue Sites. The 12 Templar Cue Sites  correspond to   
   the 12 Crystal Pylon Temple Signet Site  star gates of Inner Earth , and 
 serve as the “trigger sites” for remote activation of surface Earth’s 12Tem-
plar Signet Site  star gate opening points. Each of the 12 Palaidia Empires 
were co-founded by Urtite-Cloister Race strains carrying the five Cloister 
 269 
 
                                                                                                        
  

   The Angelic Human Heritage and Rainbow Roundtables  
Race  genetic codes of the 12-Tribes Angelic Human  line, seeded by  a spe-
cialized Urtite Tri-Cloister Maji Holy Grail Line Seed Race .  
                                    URTITIE-TRI-CLOISTER MAJI HOLY GRAIL LINE  
                                                               FLAME KEEPER S 
    The Maji Holy Grail Lines emerging into the Urtite-Cloister lineage of
12-Tribes Seeding-3 all incarnated directly from the Density-5 Primal Light 
Fields, or the Primal Sound Field s from beyond the Time Matrix. The initial 
Palaidoria Empire Urtite-Cloister Maji Holy Grails  were  Rishi and 
Ascended Master “Yanas”  consciousness incarnating directly into the  
earthly drama.  The Urtite-Cloister Maji incarnated into specific Tri-Cloister 
body forms  carrying the 24-48 Strand DNA Template . The Tri-Cloister 
genetic code  carried the DNA  T emplates of three  Cloister race lines com-
bined,  plus that of the Shambali and Bhrama Mixed Cloister Angelic 
Human lines that had evolved in Inner Earth  after the cataclysm of the 
Thousand Years War of 846,000BC  that ended 12-Tribes Seeding-2 (see
 page 43).  Each Maji emerged into Density through one of the 3  Primary 
Founder Race Breneau Collectives, each from one of the 3  Primal Light 
Fields  of Density-5 (See page 48).                           
    The Urtite-Tri-Cloister Maji Holy Grail Lines  that founded the 12 
Palaidia Empires were incarnate members of the Emerald Order, Gold Order
  and Amethyst Order Y anas Collectives, the  “Eieyani ” Ascended Masters , 
from the Primal Sound Fields  beyond the Time Matrix. The High Council 
Emerald Order  Elohei-Elohim “ Blue Flame Keepers ” Grandeyanas  incar-
nated from the Eckatic Level of the Energy Matrix Primal Sound Fields. The 
Middle Council Gold Order  Seraphei-Seraphim “ Gold Flame Keepers ” 
Wachayanas  incarnated from the Polaric Level , and the Base Council Ame-
thyst Order  Bra-ha-Rama “ Violet Flame Keepers ” Ramyanas incarnated 
from the Triadic Level  of the Energy Matrix. Each of the first Urtite-Tri-
Cloister Priest-King Lines (both male and female were referred to equally by
the same title) carried the Eieyani Priest of Ur Ascended Master genetic
code. Through the Eieyani Priest Maji Urtite-Tri-Cloister DNA Template , 
the “ Rainbow Ray Current ” could be embodied, for remote activation  of
the Signet Shields, Signet Plates  and Templar Cue Sites  of Earth’s Templar. 
The “ Rainbow Ray Current ” is composed of the Khundaray Current   standing-
wave frequencies of the Primal Sound Fields from beyond the Time 
Matrix, the Kee-Ra-ShA Current  standing-wave frequencies of the Density-
5 Primal Light Fields and the Maharata Current standing-wave frequencies of 
the Density-4, Dimension-12 Pre-matter Hydroplasmic “Liquid-Light” Chris-
tos Fields.  
270 
                                                                                                                                     

                  Shambali, Bhrama and Annu-Melchizedek Races of Inner Earth.
              
            SHAMBALI, BHRAMA, AND ANN-MELCHIZEDEK  
                                      RACES OF INNER EARTH.  
    The two Mixed Cloister races of Inner Earth  with which the Urtite-
Tri-Cloister Maji genome  is combined are races of the Inner Earth regions 
that received genetic enhancement  from the Sirius B Maharaji  blue humans 
following their exile to Inner Earth during the Thousands Years War  of 
846,800 BC  (see Page 43).  Previous to this genetic acceleration, Inner Earth 
Shambali and Bhrama  Mixed Cloister  races had emerged into Inner Earth from 
12-Tribes Seeding-1 during the Electric Wars  of 5,498,000 BC  (see 
Page 18 ). They were originally members of the 12-Strand DNA T emplate 
Christiac Grail Line  Angelic Human Cloister race lines of Seeding-1 . Exiled 
Shambali and Bhrama  races of Seeding-2  integrated  into their related Inner 
Earth cultures exiled from Seeding-1, then received further genetic accelera-
tion from the Maharaji blue human Christiac-Rishic Grail Line race of Sirius 
B. Following this genetic acceleration, which was obtained through consen-
sual intermarrying of family lines from Shambali and Bhrama races with
Maharaji blue human family lines residing in Inner Earth, the Mixed Cloister
Shambali and Bhrama race lines evolved into 24-48 Strand Christiac-Rishic  
DNA Templates. This genetic enhancement allowed them to serve as the
two primary guardian races  for the Crystal Pylon Temples , Halls of 
Amenti and the activated star gate system  of Inner Earth’s Templar ; a posi-
tion they still hold today.    
     The Shambali are  a Melchizedek and Breanoua Mixed Cloister  race, 
plus Maharaji  blue human, and the Bhrama  are a Melchizedek and Ur-
Antrian Mixed Cloister  race, plus Maharaji .  The Shambali inhabit the clois-
tered Shambali-Ionian Islands  and parts of the Inner Earth Agartha conti-
nent called Shamballah . The Bhrama nations are concentrated on the
Agartha continent, which supports various strains of occasionally conflicting
races . Presently the Annu-Melchizedek  Anunnaki-Human Bio-Regenesis 
races, exiled from surface Earth during the Lemurian and Atlantian cata-
clysms of 50,000 BC, 28,000 BC  and 9558 BC,  represent one of the largest 
populations in the Inner Earth territories of Agartha.  Due to the Pleiadian-
Nibiruian Anunnaki Fallen Angelic Legion’s recent refusal  of the Emerald
Covenant , many Annu-Melchizedek races of Inner Earth have joined the 
United Intruder Resistance (UIR)  campaign of overthrowing Emerald 
Covenant races for dominion of the Halls of Amenti  star gates and the terri-
tories  of Inner and surface Earth. The Shambali and Bhrama races of Inner 
Earth and the Palaidorians of Tara are the appointed Azurite Universal Tem-
plar Security Team guardians and Keepers of the Halls of Amenti star gates
and of the natural Universal Star Gates in Density-1 (dimensions1-2-3). 
The Palaidorians of Tara  (see Page 6) have held this Azurite Universal Secu-
rity Contract since the initiation of the Covenant of Palaidor  just prior to 
the 549,998,000 BC Taran cataclysm (see Page 2). The Shambali and 
271 
      
                                                                                                                                                                                                                                                          
                  

  The Angelic Human Heritage and Rainbow Roundtables  
Bhrama  races of Inner Earth were officially entered into the Palaidorian Cov-
enant and Azurite Universal Templar Security Team following their genetic 
acceleration after the Thousand Years War in 846,800 BC. Since this time
the Shambali and Bhrama races of Inner Earth are also referred to as
“Palaidorians ”, just as their Taran Palaidorian elders.    
                          THE THREE PRIMARY URITITE-TRI-CLOISTER MAJI FLAME                                                        
                                            KEEPER HOLY GRAIL LINE   
                                           SEED RACES OF THE PALAIDIA EMPIRES  
         The Emerald Order  Elohei-Elohim Maji DNA Template embodies  the
full spectrum of the  Eckatic Codes , the electro-tonal patterns, or DNA “ Fire 
Letters ”, corresponding to the first level  of individuation from Source, the 
Eckatic Level  of the Energy Matrix. Beings with  Eckatic DNA Templates,
such as the Emerald Order  Urtite-Tri- Cloister Maji, incarnate from the  Eckatic
Level-1  of the Primal Sound Fields ; they are legitimately considered  Level-1
Ascended Masters . Eckatic DNA Coding  allows an embodied being to run 
the Full  Blue-Gold-Violet  “Flame-Tones ” of   the Khundaray Primal Sound 
Currents and all Primal Creation Currents below , through the physical body,
when the Eckatic DNA Codes are activated.  The Emerald Order Elohei-Elo-
him Maji incarnate through a Tri-Cloister genetic template composed of 12-
Tribes  Melchizedek Cloister- “white ”-skinned line,  Breanoua Cloister  “red”
-skinned line and Yunaseti “black”-skinned line, combined with a dominant 
Shambali and recessive Bhrama Mixed Cloister  genome from the Inner 
Earth Palaidorian  races . The Emerald Order Urtite-Tri-Cloister Maji Holy 
Grail line races of Seeding-3 are called the Muarivhia  seed race , sometimes 
referred to as the Mu’a. The Urtite-Tri-Cloister  Emerald Order Maji Chris-
tiac-Rishiac Holy Grail Lines  are called the Keepers of the Blue Flame- Guard-
ians of the Eckatic Codes.” ¹ . The Muarivhia, or Mu’a  Urtite-Tri-Cloister Maji 
Christiac-Rishiac Grail Line has a 43-48 Strand DNA Template ; in their 
present incarnations on Earth, the Mu’a, along with Maji from the  Yu Seed 
Race  line are called Type-1 Indigo Children; the Mu’a are Emerald Order 
MC Indigos .  
     The Emerald Order  Mu’a,  and their ascendant race  lines , are the only 
human races on Earth whose DNA Templates  are imbued with the full spec-
trum of 144 Universal Signet Master Key Codes² corresponding to  Universal 
Star Gates 1 through 12 . The 48-Strand DNA Template Mu ’a races have all 
144 of the 144 Universal Signet Master Key Codes, and all  1728  (144 
Encryption Keys per Gate x Gates 1-12) of the 1728  Universal Encryption
  Key Codes , encoded  in their DNA.  Individuals of Mu’a genetic coding, who 
have a  fully activated 48-Strand DNA Template , are the only individuals on______________________________  
 1.  In ancient Egypt, this coveted Eckatic Maji genetic code was referred to as the  “Code of                                 
        the Blue Nile’’  
  2.   12 Master Keys per Gate  x 12 Universal Star Gates.  
272 
                                                                            
     

              The Three Primary Urtite-Tri--Cloister Maji Flame Keeper Holy Grail Line                                                               
Earth  capable of running  the full “Rainbow Ray Current”  to single-handedly
open the  four Density Levels  of Earth’ s 12 Primary Signet Site  Star Gates. 
They are the only humans on Earth able to individually initiate remote act-
ivation  of 12th Signet Shield, 12th Signet Plate and 12th Templar Cue Site, 
the 12th Signet Set  through which all other Signet Sets  and Earth’ s 12 Tem-
plar Signet Site  star gate opening points are activated and directed.  
   The Gold Order  Seraphei-Seraphim Maji DNA  T emplate embodies the 
full spectrum of the Polaric Codes , the Fire Letters corresponding to the sec-
ond level  of individuation from Source, the Polaric Level  of the Energy 
Matrix. Beings with  Polaric DNA  T emplates , such as the Gold Order  
Urtite-Cloister Maji , incarnate from the  Polaric Level-2  of the Primal
Sound Fields ; they are legitimately considered  Level-2 Ascended Masters . 
Polaric DNA Coding  allows an embodied being to run two-thirds of the 
Khundaray Primal Sound Currents, the  Gold-Violet Flame Tones, and all 
corresponding Primal Creation Currents below , through the physical body, 
when the Polaric DNA Codes are activated.  The Gold Order Seraphei-Sera-
phim Maji incarnate through a Tri-Cloister genetic template composed of 12-
Tribes Melchizedek Cloister- “yellow”-skinned line , Yunaseti Cloister  “yel-
low”-skinned line and  Hibiru “ white”-skinned line, combined with equal 
proportions of the Shambali and Bhrama Mixed Cloister  genome from the 
Inner Earth Palaidorian races . The Gold Order Urtite-Tri-Cloister Maji
Holy Grail line races of Seeding-3 are called the Yu Seed Race . The Urtite-
Tri-Cloister  Gold Order Maji Christiac- Rishiac Holy Grail Lines are called 
the ''Keepers of  the Gold Flame —Guardians of the Polaric Codes ’’3.          
    The Y u  Urtite-Tri-Cloister Maji Christiac-Rishiac Grail Line has a 37-
42 Strand DNA Template ; like their Palaidia Urtite-Tri-Cloister kin the
Mu’a (Muarivhia), the Yu Seed Race in their present incarnations on Earth
are also called Type-1 Indigo Children; the Yu are Gold Order MC Indigos.  
Other than the Mu’a , the Gold Order  Yu, and their ascendant race lines, 
are the only human races on Earth whose DNA Templates are imbued with 120 4
of the  144 Universal Signet Master Key Codes  corresponding to Universal
Star Gates 2 through 11. The 42-Strand DNA Template  Y u races have 120
of the 144 Universal Signet Master Key  Codes,  and 1584 5 of the 1728  Uni-
versal Encryption Key Codes, encoded in their DNA. Other than Mu’a 
race incarnates,  individuals of   Yu genetic coding  are the only human indi-
viduals on Earth  capable of single-handedly opening the  four Density Lev-
els of Earth’ s Primary Signet Site Star Gates  2 through 11 . Only Mu’a can
open Universal Star Gates 1 and 12.  Yu incarnates can run two-thirds  of the 
Rainbow Ray Current to initiate individual remote activation  of 11th Signet
      _______________  
3.   In ancient Hebrew teachings, the coveted Polaric Maji genetic code was referred to as the 
       ''Code of the Golden Dawn.''  
4.    12 Master Keys per Gate x Gates 2 through 11  
5.    144 Encryption Keys per Gate x Gates 1-11  
273 
                                                                                                                     
                        

The Angelic Human Heritage and Rainbow Roundtables  
Shield, 11th Signet Plate and 11th Templar Cue Site ;  the 11th Signet Set  
through which all other Signet Sets below 11,  and the 2nd through  11th of 
Earth’s 12 Templar Signet Site  star gate opening points, are activated and
directed. Only the Mu’a’s 12th-Signet Set has the power to override and 
redirect the 11th-Signet Set to which the Yu are entrusted as guardians.  
    The Amethyst Order Bra-ha-Rama Maji DNA Template embodies the
full spectrum of the Triadic Codes , the DNA Fire Letters  corresponding to 
the third level  of individuation from Source, the Triadic Level  of the Energy 
Matrix. Beings with Triadic DNA Templates , such as the Amethyst Order  
Urtite-Cloister Maji, incarnate from the  T riadic Level-3  of the Primal 
Sound Fields ; they are legitimately considered Level-3 Ascended Masters . 
Triadic DNA Coding  allows an embodied being to run one-third  of the 
Khundaray Primal Sound Currents, the Violet Flame Tones, and all corre-
sponding Primal Creation Currents below , through the physical body, when 
the Triadic DNA Codes are activated.  The Amethyst Order Bra-ha-Rama 
Maji incarnate through a Tri-Cloister genetic template composed of 12-
Tribes Melchizedek Cloister-“red”-skinned line , Hibiru Cloister  “white”-
skinned line  and Ur-Antrian “brown”-skinned line , combined with a domi-
nant Bhrama and recessive Shambali Mixed Cloister  genome from the Inner 
Earth Palaidorian races . The Amethyst Order Urtite-Cloister Maji Holy 
Grail line races of Seeding-3 are called the Urta  seed race , most often 
referred to as the Ur. The Urtite-Cloister Amethyst Order Maji Christiac-
Rishiac Holy Grail Lines  are called the '' Keepers of the Violet Flame-Guard-
ians of the Triadic Code ''6. The Urta, or Ur Seed Race Urtite-Tri-Cloister 
Maji Christiac-Rishiac Grail Line has a 31-36 Strand DNA Template . Like 
their kin, the two Secondary  Palaidia  Urtite-Bi-Cloister Maji Flame Keeper 
Holy Grail Line Seed Races, the Breanoua and Rama Seed Races , the Ur
Seed Race  in their present incarnations on Earth are called Type-2 Indigo 
Children; the Ur are Amethyst Order MC Indigos.  
    The Amethyst Order  Ur, and their ascendant race lines,  are the only 
human races on Earth, other than the Mu’a  and Yu , whose DNA Templates
are imbued with 487 of the  144 Universal Signet Master Key Codes  corre-
sponding to Universal Star Gates 5 through 8.  The  36-Strand DNA Tem-
plate Ur races have 48  of the 144 Universal Signet Master Key  Codes,  and
11528 of the 1728  Universal Encryption Key Codes, encoded in their 
DNA. Other than Mu’a and Yu race incarnates,  individuals of  Ur genetic 
coding  are the only human individuals on Earth  capable of single-handedly
  opening the  four Density Levels  of Earth’ s Primary Signet Site Star Gates  5 
through 8 . Only  Mu’a  can open Universal Star Gates 1 and 12, and the full 
__________________________________  
6.   In ancient Sumerian culture, the coveted Triadic Maji genetic code was referred to as the 
        '' Code of the Violet Sun '' 
7.     12 Master Keys per Gate x 4 Universal Star Gates  
8.     144 Encryption Keys per Gate x Gates 1-8  
274 

      The Three Primary Urtite-Tri--Cloister Maji Flame Keeper Holy Grail Line                                                              
spectrum of Star Gates 1 through 12.  Y u can open Universal Star Gates 2 
through 11 .  Ur  incarnates can run one-third of the Rainbow Ray Current to
initiate individual remote activation of  8th Signet Shield, 8th Signet Plate 
and 8th  T emplar Cue Site ;  the 8th Signet Set  through which Signet Sets
below 8,  and the 5th  through  8th of Earth's  12 Templar Signet Site  star gate 
opening points can be activated and directed. The Mu’a’s 12th-Signet Set 
and the Yu’s 11th Signet Set , have the power to override and redirect the 8th
Signet Set  to which the Ur are entrusted as guardians.  
      The three Primary Urtite-Tri-Cloister Maji, with a 36-48 Strand Maji
DNA Template, incarnated as members of the Azurite Universal Templar 
Security Team, collectively carrying the Universal Master Signet Key Codes
to the 12 Star Gates of the Universal Templar in their DNA Templates. The 
Universal Signet Master Key Codes are the 144 Master Key Codes9 
and the 1728 Encryption Key Codes10  corresponding to the Universal Level of 
the 12 Universal Templar Star Gates. The three Primary Urtite-Tri-Cloister 
Palaidia Empire Seed Races were entrusted with the power to remote acti-
vate the 12 Star Gates of the Universal Templar . The Star Gates of the
Universal Templar are the 12 primary Star Universal Star Gates that open
vertically between the four Density Levels in our Time Matrix ; the Uni-
versal Templar is the Primal Energy-Feed System to which all Galactic, Plan-
etary and Personal Templar complexes are connected. In founding the 
underground cities of  the Palaidia Empire  in  798,000 BC , the Mu’a  (Muar-
ivhia), Yu and Ur  (Urta) Urtite-Tri-Cloister Flame Keepers Maji Grail Line 
Angelic Human Seed Races set up the foundation structures  upon which
Earth’s Templar Complex  was intended  to function throughout 12-Tribes
Seeding-3 .  They, and their Holy Grail Line ascendants to the present time ,
represent the common seed  from which all contemporary humans  of Earth 
originally emerged  before Fallen Angelic corruption of the Angelic Human  
gene code.   
     The Mu’a, Yu and Ur Seed Races  are members of the Azurite Univer-
sal Templar Security Team embodied in Maji Christiac-Rishic Angelic 
Human form. They carry the genetic potential  to run the Rainbow Ray Cur-
rent, the Universal Primal Light-Sound Currents, into Earth’s Templar for
remote activation of Earth’s Star Gates, and the 12 Primary Star Gates of the 
Universal Templar. As  representatives of the Yanas, Breneau and Founders’ 
Emerald Covenant , the Emerald, Gold and Amethyst Order Maji have 
returned to contemporary Earth incarnation as Types-1 and 2 Indigo Chil-
dren . The indigo Children Types 1 and 2 have returned in hope of assisting
the Angelic Human 12-Tribes  of  Earth to finally fulfill the Sacred Mission 
of Planetary Guardianship  for which they were originally commissioned.  
  _______________________________________________  
   9.   12 Master Keys for each of 12 Universal Star Gates  
  10.  144 Encryption Key Codes for each of 12 Universal Star Gates  
 275 
                                                                                                             
                                                       

The Angelic Human Heritage and Rainbow Roundtables  
                  THE  TWO SECONDARY URTITE-BI-CL OISTER  
         MAJI FLAME KEEPER HOLY GRAIL LINE SEED RACES  
                                 OF THE PALAIDA EMPIRES  
    The three Primary Urtite-Tri-Cloister Maji Seed Races were combined to 
create the two  Secondary Urtite-Bi-Cloister Maji race lines  with  24-36
Strand Maji DNA Templates , who serve as members of the Azurite-Amenti 
Galactic-Planetary Templar Security Team. The two Secondary Maji Flame 
Keeper Holy Grail Line Seed Races responsible for co-founding the Palaidia 
Empires  of 798,000 BC are the Breanoua  and Rama Urtite-Bi-Cloister 
Seed Races, which emerged simultaneously with the Urtite-Tri-Cloister Maji 
races within the underground Palaidia Empires of 798,000 BC . The Brean-
oua Urtite-Bi-Cloister Maji Race  emerged through combining the genomes  
of the Emerald Order Mu’a (Muarivhia) and Gold Order Yu  Urtite -Tri-Clois-
ter Maji race lines, to form a race line that would carry the portions  of the 
1728 Universal Encryption Key Codes  characteristic  to the Mu’a and Yu  
races. The Breanoua race lines are known as Keepers of the Blue-Gold Flame,
as they can embody and run the Blue and Gold spectrum  of the  Primal 
Sound-Light Currents  through their DNA Templates. Breanoua races and 
their ascendancy lines have a 28-30 Strand DNA Template , categorizing 
their contemporary incarnations as Type-2 Indigo Children . The Breanoua 
30-Strand DNA Template  is imbued with 3611 of the 144 Universal Signet 
Master Key Codes  for Universal Star Gates 9, 6 and 3.   The Breanoua 30-
Strand DNA Template  contains  288  Universal Encryption Key Codes  for 
Universal Star Gates 12 and 11 and the 1296 Universal Encryption Codes
corresponding  to Universal Star Gates 1-9; a total of 1584 of 1728 Univer-
sal Encryption Key Codes.12 The  30-Strand DNA  T emplate  Breanoua  races 
have 36 of the 144 Universal Signet Master Key  Codes,  and 1584  of the 
1728 Universal Encryption Key Codes, encoded in their DNA.  
     The Rama Urtite-Bi-Cloister Maji Race  emerged through combining 
the genomes  of the  Gold Order Y u and Amethyst Order Ur  (Urta)  Urtite -
Tri-Cloister Maji race  lines, to form a race line that would carry the portions  
of the 1728 Universal Encryption Key Codes  characteristic to the  Yu and 
Ur races. The Rama race lines are known as Keepers of the Gold-Violet
Flame , as they can embody and run the Gold and Violet spectrum  of the Pri-
mal Sound-Light Currents through their DNA Templates. Rama races and 
their ascendancy lines have a 25-27 Strand DNA Template, categorizing 
their contemporary incarnations as Type-2 Indigo Children. The Rama 27-
Strand DNA Template is imbued with 3613 of the 144 Universal Signet Mas-
ter Key Codes for Universal Star Gates 10, 7 and 4.   The Rama 27-strand
______________________________  
11. 12 Master Keys per Gate x 3 Universal Star Gates.  
12.  144 Encryption Keys per Gate x Gates 1-9 and 11-12 = 144 x11 = 1 584.  
13.  12 Master Keys per Gate x 3 Universal Star Gates.  
276 

   The Two Secondary Urtite-Bi-Cloister Maji Flame Keeper Holy Grail Lin e 
DNA Template contains  1440 Universal Encryption Codes corresponding 
to Universal Star Gates 1-10.14 The 27-Strand DNA T emplate Rama races
  have 36 of the 144 Universal Signet Master Key Codes, and 1440 of the 1728  
Universal Encryption Key Codes , encoded in their DNA. The two  Second-
ary Urtite-Bi-Cloister Maji  Seed Races, the Rama and the Breanoua, collec-
tively carry, within their 25-30 Strand DNA Templates, the Galactic Signet 
Key Codes;  the Signet Master Key Codes and Signet Encryption Codes of the 
Galactic and Planetary Levels of the 12 Universal Star Gates. The three Pri-
mary Urtite-Tri-Cloister Maji Seed Races, the Mu’a (Muarivhia), Yu and Ur, 
collectively carry, within their 31-48 Strand DNA Templates, the  Universal 
Signet Key Codes;  the Signet Master Key Codes and Signet Encryption 
Codes of  the Universal, Galactic and Planetary  Levels of the 12 Universal 
Star Gates.  
     The  five Palaidia Urtite-Cloister Maji Christiac-Rishic Holy Grail Line 
races, the Mu’a, Yu, Ur, Breanoua and Rama, founded the 12 Palaidia 
Empires that began 12-Tribes Angelic  Human Seeding-3 in 798,000BC.  The
12 Palaidia Empire Maji  races are the Seed Races through which the five 
Urtite-Cloister Maji  Races  of the Urtite-Cloister Empires on surface Earth 
emerged between 798,000 BC and 500,000 BC. The five Urtite-Cloister 
Empire Maji  Races that emerged on surface Earth through the 5 Palaidia 
Urtite-Cloister Maji lines  carry the same race names as their Palaidia Urtite-
Cloister forefathers, the Urtite-Cloister Mu’a (Muarivhia), Yu, Ur, Breanoua
and Rama. The Urtite-Cloister Maji races that founded the surface Earth
Urtite Empires carry 12 to 24 Strand DNA Templates containing the 144 
Planetary Master Key Codes and 1728 Planetary Encryption Key Codes; the
Planetary Signet Key Codes  of the Amenti Templar Planetary Security 
Team. The 5 Urtite-Cloister Empires of surface Earth are the Seed Races 
through which the 5  Cloister Races (7 to 12 +1 Strand DNA Template) and 
seven  Root Races  (2–6 + 7-12 Strand DNA  T emplate potential) of the con-
temporary 12 -Tribes Angelic Human Races emerged (see page 15) to form
the genetic origins of the contemporary human race. The first 2 Angelic 
Human Root Races, the Polarians and Hyperborneans, evolved on Etheric 
Density-3 Gaia. The remaining 5  Cloister and 5 Root Races  of the Seeding-3 
12-Tribes Angelic Human “Maji King” Christiac-Rishic Holy Grail Line,
progressively emerged on Earth through the 5 Urtite-Cloister Empire Maji 
Races that emerged on surface Earth from the 798,000BC Palaidia Empires.  
______________________________  
14.  144 Encryption Keys per Gate x Gates 1-10 = 144 x10 =1440  
277 
                                                                                                           

   
     The Angelic Human Heritage and Rainbow Roundtables                                                   
                                               THE RIDDLE OF THE “ROUNDTABLE” — 
                         LOCATION OF RACE SEEDINGS AND RITES OF THE ROUNDS 
                           
                              Palaidia Empire Geographical Settlements and  
                                   DNA Template-Star Gate Correlation  
      The significance of understanding the nature of Palaidia Urtite-Cloister
Races from which contemporary humanity emerged is not only  in that we 
can regain insight into the original majesty and “Divine Nature” of the 
human genome  and the  hidden purpose of humanity’s Divine Mission that 
the human genome implies. Through understanding the design and purpose  
through which the Palaidia Races were seeded also reveals the intrinsic
design and hidden purpose behind and within humanity’s genetic evolution ,
and where within this greater evolutionary design our contemporary human 
culture  fits. 
        The five Palaidia Races were seeded in precise locations  on Earth that 
corresponded directly to the locations of Earth’s 12 Templar Cue Sites  (see 
page 269 ). Earth’s 12 Templar Cue Sites  mark the surface Earth locations of 
the 12 Inner Earth Star Gates  and Crystal Pylon Temples , through which
the opening of surface Earth’s 12 Primary Templar Signet Site star gates
could be manually directed .   Not only were the five Palaidia Races distributed
among Earth’s 12 Templar Cue Sites, they were distributed with precision .
The DNA Template  encoding of each Palaidia Urtite-Cloister race directly 
correlated  to the 12 Master Key Codes  and 144 Encryption Key Codes
of each Signet Set that corresponded to the Templar Cue Site  to which they
were assigned. The Palaidia Races were settled in geographical areas in 
which their DNA Template encoding corresponded directly to the Star 
Gate affiliated with that location. The five races  of the Palaidia Empires col-
lectively carried the 12 Universal Master Key Codes and 144 Universal 
Encryption Key Codes  through which the 12 Planetary, Galactic and Uni-
versal star gates of our Time Matrix  could be brought into remote activa-
tion. The Mu’a (Muarivhia) races carried the 43-48 Strand DNA Templates
corresponding to Universal Star Gates 1 through 12 , and were thus 
assigned to Earth’s Templar Cue Site 12  as Guardians of the 12th Gate.  In 
the Primal Order  of dimensionalized frequency fields, the highest frequency 
fields have the greatest power, and thus the dimension-12 Star Gate-12  nat-
urally possesses overriding directional power  over the 11 Star Gates  below
its placement in frequency. The 12th Gate in the  Universal T emplar is the
frequency passage that opens to dimension-12  of the Density-4 Pre-matter
 ''Liquid Light'' field , the Universal Christos “ Divine Blueprint ”; the  
“Shield of Aramatena ” (see