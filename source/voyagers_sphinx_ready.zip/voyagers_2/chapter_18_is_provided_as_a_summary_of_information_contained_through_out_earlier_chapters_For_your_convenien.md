Chapter 18 is provided as a summary of information contained through-
out earlier chapters. For your convenience, this information is formatted in
condensed form, as data sheets called At-A-Glance Blow-Up Charts . Sub-
jects are addressed by topic heading and are summarized on one data sheet for
easy reference. Condensing information for the data sheets requires a small
size type. The At-A-Glance Blow-Up Charts are formatted for easy photo-
copier enlargement.  
                                                                          AT-A-GLANCE BLOW-UP CHARTS
  1. Recent History and Current Events page 435
  2. Amenti Ascension Program page 436
  3. The Seven Seals page 437
  4. The Six Silent Ascension Avatars page 438
  5. Time Mechanics page 439
  6. Time Continuum Progression page 440
  7. Time Shift Continuum Progression I Phantom Earth page 441
  8. Time Shift Continuum Progression ll Bridge Zone page 442
  9. Time Shift Continuum Progression Ill V oyagers Leap page 443
   10. Origins, Secrets of Amenti page 444
   11. The Three Seedings and the Root and Cloister Races of Amenti page 445
                                            
                                                          DATA SUMMARIES
          1. The Six Silent Ascension Avatars page 446
          2. The Three Tracks of Time page 447
                         434


                                                                                                         Data Summaries
                                        Recent History and Current Events
                                                 At-A-Glance Blow-Up Chart
                                                                     1748 - 6/26/1998
1748: Genetic mutation Zeta Seal from Zetas’ future Frequency Fence contaminates Earth via Sphere of Amenti.
1902: Guardians orchestrate astral body realignments on some humans to release Zeta Seal mutation in race.
1906: Guardians destroy asteroid that was heading for Earth's orbit, in deep space. Fragments hit Earth.
1916: WW 1 Zetas begin speculation on Earth studying genetic content.
 1926 : Zetas begin surveying Earth to assess conditions regarding their future Frequency Fence
 1930 : Zetas begin early genetic experimentation & hybridization program on Earth during 1930's & 1940's.
 1940 : WW2. Zetas assist Nazis then convert to assisting USA, treaties with Allies formed MJ12.
 8/12/1943 : Philadelphia Experiment. Zetas instigate USA to rip hole in space-time, Zeta ships begin altering sun.
 1952-1968 : Earth scientists observe instabilities on sun, unaware of 1943 Zeta cause. Concern of Pole Shift
 8/7/1972 : Solar ﬂare explosions begin. Red Pulse due by 9/1973 would de stroy Earth life. Guardians intervene.
 1972 : Guardians 11:11/12:12 Frequency Fence to protect from Red Pulse & begin genetic repair abductions                    
 1973 :Guardians begin infusions of energy on sun to repair solar damage from Zetas 1943 sun manipulations
1973 -1/11/1992 : Guardians employ Holographic Inserts to maintain illusion of Earth stability while sun realigns
1982: Guardians split and divert course of asteroid due to hit Earth.
1982-1984:  Most Zeta groups enter Guardian treaties & stop take-over plan Dracos-Zeta Resistance refuses
8/12/1983:  Dracos-Zetas instigate Montauk Project, create 2nd space-time rip & begin creating clones and infiltrates
1984: Guardians discover 2976 AD Earth destruction as result of Zeta in filtration, create Bridge Zone Project
10/1986 : 1st Seal on Arc of Covenant opens, Sphere of Amenti begins descent; 9540 BC Frequency Fence lifts
8/16/1987 : Harmonic Convergence. Guardians granted permission to activate Bridge Zone Project intervention
1/1988 : Sphere of Amenti returns to Earth. Earth's 1st primary V ortex -Arizona USA - opens.
9/1989 : Guardians finish repair of Solar Fields 8 & begin infusions of D-4 frequenc y to Earth, to raise core vibration
1/11/1992 : Guardians reenter 11:11 magnetic codes to Earth core, 11:11/12.12 Frequency Fence begins release
6/1992 : Earth's 2nd primary V ortex - Jerusalem, Israel - opens.
7/26/1992 : Avatar 1 of Six Silent Ascension Avatars is born; 7th level avatar
12/12/1994 : 11:11/12:12 Frequency Fence lifted. Ancient Ur-Tarranates leave Amenti to human care.
1995: Guardians initiate Portal Protection Project to secure Earth' s V ortices from lntruder in filtration
6/1996 : Earth's 3rd primary V ortex - Himalayan Mountains. Asia - opens
6/24/1996 : Avatar 2 of Six Silent Ascension Avatars is born; 8th level avatar
12/1997 : Anunnaki Resistance begin manipulating humans from D-4 via Jerusalem & Manhattan vortices
1/1998:  Prospects of 2nd Seal on Arc of the Covenant opening on time bleak, Earth ascension & rescue doubtful
2/1998 : Elohim's early birth of avatar 3; opens 2nd Seal on Arc of the Covenant. Rescue resumes
6/26/1998 : Avatar 3 of Six Silent Ascension Avatars is born 2 years early; 9th level avatar.
2nd Seal on Arc of the Covenant opens. Fate of human destiny changed. Ascension Program
& Bridge Zone Project rescue mission will occur.
                                                                       ©2002 Ashayana Deane
                                                                                                                                                 
               
                435
                                                                                                                                                         

                 Data Summaries and At-A-Glance Blow-Up Charts
                                      Amenti Ascension Program
                                            At-A-Glance Blow-Up Chart
                                              6/26/1998 – 6/2047
6/26/1998 : Bridge Zone Project & Ascension Program resume. Morphogenetic Wave begins to build.
8/30/1998 : 3-day incubation Rite for humans with Palaidorian Birth Contracts for indigo Children held
in Agartha. Parent couples attend via astral teleportation. Birthing Contracts finalized.
1999-2004 : First birthing wave for 144,500 Indigo Children
1/1/2000 : TRANSCENDENCE DAY . Guardians call Earth Light-Workers to hold lnter-dimensional
Resonant Tone. Earth's 4th V ortex - Giza, Egypt - opens. Blue Flame begins 12-year descent to Earth
5/5/2000 : Solar Spiral aligns, Earth begins Solar Activation. Earth begins shift to HU-2 time cycle.
9/17/2001 : Guardians complete Giza alignment with Pleiadian-Alcyone Spiral
2001 : Dracos-Zeta Resistance tentative plan for public landing.
Guardians plan ''ﬂy-bys" if Earth changes are to come.
6/2002 : Earth receives Blue Wave infusion
                        8/12/2003 : Dracos-Zetas plan experiment to bring cloaked ships in for Frequency Fence transmissions.
Spring 2004 : lf 2003 experiment successful Dracos-Zetas begin EMP Frequency Fence transmissions.
6/2004 : Pleiadian-Alcyone Spiral aligns, Earth's Pleiadian Activation. V ortex 5-Machu Picchu,Peru-opens
9/9/2004 : Avatar 4 of Six Silent Ascension Avatars will birth; 10th level avatar. Must arrive by this date.
2005-2017 : Second birthing wave of 5,500 Indigo Children
6/2006:  Earth receives Violet Wave infusion
2006 : Dracos-Zetas will begin broadcast of Holographic inserts if Frequency Fence was set in 2004.
6/2008 : Sirian Spiral aligns, Earth begins Sirian Activation. Earth completes shift into HU-2 time cycle.
V ortex 6 - Caucasus Mountains, USSR- opens
7/22/2008 : Avatar 5 of Six Silent Ascension Avatars will birth; 11th level avatar. Must arrive by this date.
6/2010 : Earth receives Gold Wave lnfusion
1/1/2012 : Earth's 7th   V ortex - Andes Mountains, South America - opens
5/5/2012 : 12:01 am 6th of Six Silent Avatars will birth; 12th level avatar. The grids of Earth & Tara begin to
merge. Blue Flame embodies in Keepers oF the Blue Flame. Mass awakening occurs Halls of Amenti
open & Ascensions begin. 3 Flame Holders called to Giza to activate Hall of Records.
12/21/2012 : Earth enters Holographic Beam, particle base begins to separate. Morphogenetic Wave begins
to crest. Polarity of Earths particle base reverses. Hall of Records begins transmitting through Earth's grid.
1/1/2017 : Violet Flame embodies in Keepers of the Violet Flame.
5/5/2017-6/30/2017 : 3-day particle conversion period NlGHT OF THE 2 MOONS takes place. Arcturian,
Orion & Andromeda Spirals align with Earth for 3 days & Earth receives 3 final Stellar Activations &
Stellar Wave Infusions. Earth, Tara & Gaia in full alignment with Meta-Galactic Core & Holographic Beam.
Ascension portals to Gala open for 3 days. Morphogenetic Wave completes cresting. Earth's Magnetic
Fields collapse for 3 days. Earth completes passage to Bridge Zone & Phantom Earth separates from
Earth to return to the D-3 time cycle.
7/2017 : Earth passes out of alignment with Gaia & Holographic Beam. Ascension portals to Gaia close.
Earth's magnetic fields return. Grids of Earth & Tara begin to separate.
1/1/2022 : Grids of Earth & Tara complete separation, Halls of Amenti close to the masses & mass
ascension period comes to a close. Earth stabilizes within the Bridge Zone time continuum.
Energy infusions through Earth's grid cease. Earth's 7" V ortex - Andes Mountains, South America - closes.
1/1/2022-6/2047 : Earth's 6 remaining primary V ortices close, V ortex 6 to V ortex 1. Ascension cycle ends.
         
                                                                      ©2002 Ashayana Deane
                  436

                                                                                                                           
                                                                                                              Data Summaries
                                                            The Seven Seals
                                                        At-A-Glance Blow-Up Chart
                                                          Earth’s 7 Primary Vortices
                                   Opening-Activating and Closing-Deactivating Schedule
                 VORTEX & LOCATION                               OPENING CYCLE       CLOSING CYCLE
                              #                                                                     FULLY ACTIVATED       FULLY CLOSED                         ________________________________________________________________________________
                         1      Painted Desert, Arizona USA                      1/1988 -  6/1992              6/2042  - 6/2047
                         2      Jerusalem, Israel                                          6/1992  - 6/1996               6/2038  -6/2042
                         3      Himalayan Mountains, Asia                        6/1996 - 1/2000              1 /2035  - 6/2038
                         4      Giza, Egypt                                                 1/2000  - 6/2004               6/2029 - 1/2035
         5       Machu Picchu, Peru                                     6/2004  - 6/2008              6/2025  - 6/2029
     6      Caucasus Mountains, USSR                        6/2008  - 1/2012              1/2022  - 6/2025 
7       Andes Mountains, South America               1/2012  - 6/2017              6/2017  - 1/2022
As each vortex progressively opens and activates, the dimensional frequency
bands that correspond to the vortex number begin transmitting through Earth's
morphogenetic field. This causes the Sphere of Amenti to begin transmitting its
morphogenetic imprint for that dimensional frequency band through Earth's grid. The
frequency imprints for DNA strands 1 - 8, which are stored within the morphogenetic
field of the Sphere of Amenti (along with the imprints for strands 9-12), progressively
transmit through Earth's grid, as the dimensional frequency bands that correspond to
each strand begin transmission . The frequency bands of D-8 Meta-galactic Core, which
accelerate activation of the 8th DNA strand, transmit through Earth's grid when Earth's planetary
core comes into a direct 3-day alignment with the cores of Tara, Gaia and the Meta-galactic
Core, as Earth aligns directly with the Holographic Beam. The imprints for DNA strands 9-12 do
not transmit through Earth's grid; they are accessible only through the grid of Tara. Activation of
strands 1-8 on Earth allows for ascension to the Taran time cycles, from which the imprint for
strands 9-12 can be accessed.
  The human bio-energetic field picks up the DNA imprint through its direct contact
with the bio-energetic fields of Earth's grid, which provides humans with the opportunity
to add that imprint in its operational DNA construction. The process of activating the new
imprint takes place as the strand imprint is pulled from the bio-energetic field, into the
personal morphogenetic field, at which point the new imprint will begin manifestation
within the operational DNA strands . DNA strand mutations are purged from the race
morphogenetic imprint in the Sphere of Amenti and the strand imprint is realigned with the
12 strand DNA pattern by the successive births of the 6 Silent Ascension Avatars.
Transmission of the corrected DNA strand imprints through Earth’s grid allows a
reverse-mutation of various ascension-inhibiting human genetic distortions to take place .
Earth's 7 Primary Vortices  open only during the two ascension cycles, at the beginning and
end of a 26,556-year Harmonic Universe Euiago time cycle, The energetic dynamics that Earth
now approaches, as it enters the ½ cycle point in its 2nd ascension cycle, are unprecedented
within the annals of recorded human history . The coming of these events has been symbolically
foretold through oral and written tradition for thousands of years.
                                                                            ©2002 Ashayana Deane   
                     437                                                   
                                                                                                                                                                       

     
                Data Summaries and At-A-Glance Blow- Up Charts
                                                    The Six Silent Ascension Avatars
                                                    At-A-Glance Blow-Up Chart
       AVATAR    DATE        SOUL             SOUL               ALIGNS         TURNS
             #             OF         ESSENCE      ESSENCE          DNA                33
                         BIRTH      NAME            LEVEL              STRAND
____________________________________________________________
           1           7/26/1992            LAU CHA-             7th LEVEL                  STRAND                2025 AD
                                                          SAN                        A V ATAR                          2                                    
                                                                                                                                                                                            
                     ---------------------------------------------------------------------------------------------------------- --------------     
                                    2           6/24/1996             BRAHAMHAN     8th LEVEL                 STRAND                2029 AD
                                                                                   MAHA-TIA           A V ATAR                          3
                     ---------------------------------------------------------------------------------------------------------- --------------
                                    3            6/26/1998**         JEHOV ANI-            9th LEVEL                 STRAND               2031 AD
                                                                                   AHMBRA              A V ATAR                          4
                     ---------------------------------------------------------------------------------------------------------- --------------
                                    4            9/9/2004-T          ALLUREA-           10th LEVEL                  STRAND              2037AD-T
                                                                                  DON-                     A V ATAR                            5
                                                                                  MELCHIOR
                     ---------------------------------------------------------------------------------------------------------- --------------
                                    5            7/22/2008-T       RElON-BEN-         11th LEVEL                STRAND                2041AD-T
                                                                                 AZARTAN              A V ATAR                              6
                ------------------------------------------------------------------------------------------------------------------------
                                     12:01am
                                        6            5/5/2012              SANANDA-BEN- 12th LEVEL                STRAND               2045AD
                                                                                  JEVOHI                   A V ATAR                             7
                   _________________________________________________________________ 
T = birth is scheduled for this date, but may occur any time earlier, most likely
following the birth of the previous avatar. Birth must occur no later than
scheduled date. Birth will remain as scheduled  unless circumstances warrant
change. ** = avatar 3 was not scheduled to birth until 2000 AD, but Elohim
arranged the birth 2 years early to open the 2nd seal on the Arc of the Covenant,
so the ascension schedule could remain on course. NOTE:  There will also be
144,000 + ''indigo Children " born between 1999 - 2017  They will carry the 6
DNA strand Paradisian Race Imprint , that of the fully embodied HU-2 soul essence.
They represent  D-6 soul essence  and will birth via the frequencies of the D-6 Sirian
Spiral , which falls within the inter-dimensional lndigo light wave spectrum , thus
their name. Activation of the 6th DNA strand of a minimum of 144,000 individuals is
essential for Earth's passage into the Bridge Zone. The D-6 souls will birth on Earth
to serve in ful filling this requirement. The 6 Silent Avatars and indigo Children are born
via Palaidorian Birthing Contracts  and Contract Bonds.
                                                       ©2002 Ashayana Deane
                  
                  
                  438

                       
                        Data Summaries and At-A-Glance Blow-Up Charts
                                          Origins - Secrets of Amenti
                                            At-A-Glance Blow-Up Chart
Human Origins : Humanity began 560 million years ago, as an Immortal Race called
the Turaneusiam on planet Tara in Harmonic Universe-2 (HU-2). The Turaneusiam race
had a 12 strand DNA morphogenetic imprint that allowed for embodiment of the 12 dimensional
frequency bands of an HU-4 avatar identity. Humans were created as a planetary guardian race
of God-like beings.
Lost Souls of Tara:  Through a Turaneusiam created cataclysm on HU-2 Tara 550 million
years ago part of Tara's grid fragmented into HU-1 through the core of the 8th Pleiadian star,
forming 12 planets that became Earth's solar system. Many of the Immortal Souls of Tara were
fragmented into HU-1 with the lost portions of Tara; they became known as the Lost Souls of
Tara or the Fallen Angels. The Palaidorian and Ur-Tarranate races of Tara created a project
through which the lost souls of Tara could re-evolve into their original 12 strand DNA immortal
imprint and be freed from HU-1.
The Sphere of Amenti  race morphogenetic field was created to give the soul fragments of Tara
that were lost in the Earth's dimensional fields the pattern of the 12 strand DNA imprint, through
which they could re-evolve into their original Turaneusiam form. The Sphere of Amenti served as 
a Host Matrix (surrogate morphogenetic field or "form-holding blueprint") through which the
Lost Souls of Tara could evolve and return home. The Amenti rescue mission represents a Host Soul 
Matrix Transplant on the species level. All present Earthly strains of human have evolved through the 
morphogenetic imprint of the Sphere of Amenti.
Seeding the 12 Tribes of Amenti:  Through the Sphere of Amenti race morphogenetic field 7 Root  
Races and 5 Cloister Races  were created, through which the 12 strand DNA imprint could be 
rooted into Earth biology to evolve. The first 2 Root races were etheric in nature and evolved on
HU-3 D-7 Gaia, setting the pattern of the 1st DNA strand into Earth's planetary morphogenetic field.
The remaining 5 Root Races & 5 Cloister Races were to be seeded on Earth & Tara during
different time periods. Each Root Race would assemble and evolve 1 DNA strand imprint from Amenti
into Earth's biological gene pool. The Cloister Race appearing with each Root Race would evolve the 
imprints for strands 7-12 as dormant gene codes along with the imprint for the strand carried by their
Root Race. The Cloister Races allowed the strands of cellular transmutation to remain alive within the 
biological gene pool.
The 3 Seedings:  The Amenti Rescue Mission failed twice due to Interstellar Wars over humanity's 
right to evolve on Earth. The Palaidorians, Ur-Tarranates & other guardian races of Tara, HU-2 
and HU-3 had to re-seed all but the first and second Root and Cloister Races 3 different times. The
present human lineage is part of the 3rd Seeding. Present day humans are primarily of the 5th Root 
Race Aryan  and Hibiru  Cloister Race strains. Some members of the 6th Cloister Race, the 
Melchizedeks , are also present on Earth and 150,000 7th Race Paradisian  souls, the 
Indigo Children , will be incarnating on Earth between 1999 - 2017 to accelerate the genetic 
evolution of the races and to help Earth shift to the Bridge Zone time continuum.
The Arc of the Covenant  is a time portal passage between Earth and the Andromeda galaxy
that was created 840,000 years ago by guardian races. I was used to store and protect the
Sphere of Amenti until the Sphere could be returned to Earth's core. The Arc allowed the Sphere
of Amenti to descend from Andromeda when Earth's core reached a high enough vibration rate.
Races of the 3rd Seeding were birthed into ﬂesh through the Arc of the Covenant. Arc was originally 
called the Arch of the Covenant of Palaidor, denoting the Palaidorian Covenant through which the 
Amenti Rescue Mission was begun 550 million years ago.    
                                                                                  ©2002 Ashayana Deane   
                                444
                            

                           Data Summaries and At-A-Glance Blow-Up Charts
                                                  THE SIX SILENT ASCENSION A V ATARS
      During the ascension cycle of 2017 AD six avatar souls will incarnate on
Earth in order to serve various roles within the plan of human ascension and
evolution. An avatar soul is a soul essence possessing a minimum level of
over-soul consciousness, fully embodied within the physical incarnation; it is
a master-soul that incarnates from a position within Harmonic Universe 3 or
4. An avatar will have a minimum of 7-dimensional frequency bands within
its genetic imprint, and a minimum of seventh DNA strand activation at
birth. The human genetic prototype can hold only 12-dimensional frequency
bands within its imprint, a 12-strand DNA code. Avatars will thus have
between 7 and 12 DNA strands activated in their genetic code. (The last
12th-level avatar to incarnate on Earth was Jesheua-12, AKA  Jesus Christ/
Sananda - 12BC - 27 AD). The six Silent Ascension Avatars assisting in the
2017 ascension cycle will be born approximately four years apart beginning in
1992, the last being born in 2012. Though there will be several other avatar
souls incarnating on Earth during this period, the six Silent Ascension Ava-
tars hold a very special purpose of realigning the DNA imprint for the human
race within the morphogenetic field of the Sphere of Amenti.  
       As their respective soul essences pass through the Sphere of Amenti, the
frequency bands carried in their energetic essence will purge mutations from
the human DNA imprint, allowing DNA strands 2-7 to realign with the orig-
inal 12-strand DNA pattern of the HU-2 Turaneusiam-human prototype.
Without the birth of these avatars mutations within the human DNA code
would prevent humans from properly assembling and activating the DNA
strands and humanity would be unable to achieve acceleration of evolution
and ascension to the Bridge Zone, Tara or beyond. Each avatar is assigned to
the realignment of one DNA strand, which will be achieved as the soul
essence passes through the Sphere of Amenti during fetal integration.  
       When the avatars turn 12 years of age they will begin awakening to their
chosen service mission on Earth and by age 22, if their awakening proceeds
properly, they are scheduled to begin active service to further the evolution-
ary development of humans within the Bridge Zone Earth. The success of the
ascension program is dependent upon the births of the six Silent Ascension
Avatars proceeding according to schedule. They are called the Silent Avatars
because their identities, religious affiliations and geographical locations will
be undisclosed to the public during the ascension period. Their identities will
not be revealed until they have reached the age of 33 and their service mis-
sions come into mass awareness.  
446 

                                                                                                                  
                                                                                                   The Three Tracks of Time
                              
                             THE THREE TRACKS OF TIME  
Earth’s populations will permanently divide into three separate groups
2012-2017  
                 Time Track 1—Voyager Ascension—Tara D-4 Time Cycle  
Time-traveling V oyagers - 5532.5-year Leap into the Future (Tara AD  
7549.5)  
   •   Humans who are able to assemble and activate a minimum of the fifth
DNA strand will have the opportunity to transmute the body structure into
light & teleport through the portal passages of the Halls of Amenti to arrive
on planet Tara. Tara is Earth in the future space-time coordinates of the Har-
monic Universe-2 time cycles. Transfer to Tara represents a 5532.5-year time-
travel journey into the future. Humans teleporting/time-traveling to Tara are
called V oyagers.  
   •   V oyagers will experience subtle or direct contact by other V oyagers, ET
or metaterrestrial guardian groups prior to the ascension period, through
which they will receive training & make travel arrangements. V oyagers must
complete a minimum of two Stellar Activations to biologically tolerate trans-
port to Tara. V oyagers who are near 5 DNA strand assembly but assembly is
not quite complete cannot pass through Amenti directly. They will be pri-
vately escorted to guardian Transport landing sites & will travel to Tara via
interdimensional spacecraft.  
     •   Once arriving on Tara V oyagers will be given lodging & will attend ori-
entation classes to assist them with integration into Taran society as time-
travelers from the past. Taran culture is built upon the Law of One & is quite
Heavenly compared to Earthly existence.  
   •   V oyagers will find themselves in less-dense, more perfected versions of
their present bodies, free from disease, the necessity of death and the cycles of
reincarnation in HU-1.  
    •   Humans who have assembled the fifth DNA strand, but whose physical
bodies are beyond repair & will not permit the strand to activate, will physi-
cally die in usual terms then pass through the Halls of Amenti as conscious-
ness, to incarnate into an immortal body through a Taran parent couple.  
     •   In some cases couples or groups will be able to ascend together & will
be able to remain together on Tara if they choose to do so.  
   •   Full memory of multidimensional experience will return to the V oyag-
ers & they will have open relationships with ET and metaterrestrial commu-
nities while evolving on Tara.  
    • Few will take the path of the V oyager, but it is the path of choice & the
opportunity of many life times for those who can qualify.  
447 

Data Summaries and At-A-Glance Blow-Up Charts  
   Time Track 2—Phantom Earth Descending Planet—D-3 Time Cycle  
                  Descending Humans — Return to the Present (Earth AD 2017)  
        • Humans who do not assemble all of the fourth and _ of the fifth DNA
strands will remain within the D-3 time cycle when Earth completes the
ascension period in 2017 and will follow the path of the Phantom Earth
Descending planet. If the Dracos-Zeta Resistance is successful in orchestrat-
ing the Frequency Fence in 2004, these populations will fall under covert
Dracos-Zeta bio-neurological mind control.  
        • Major Earth changes will occur on the Phantom Earth, due to the Fre-
quency Fence and Descending Humans will face disruptions in existing social
structure &  in filtration of the Dracos-Zeta hybrids.  
         • If the Frequency Fence is stopped, Descending Humans will face Earth
changes to a lesser degree and retain their existing level of freedom of choice,
but will become bio-energetically severed from their higher-dimensional
identity, Soul Matrix and evolutionary blueprint. This separation from the
Soul Matrix will cause a genetic mutation through which only the third
DNA strand can assemble. Over several generations this mutation will cause
break down of the genetic code and the inability to reproduce.  
         • Descending Humans will no longer be able to access multidimensional
awareness and will be unable to ascend out of HU-1 after death or reincar-
nate without a Host Matrix Transplant. Without an energetic link to a Soul
Matrix the consciousness becomes finite and will eventually fragment into
the Uni fied Field of HU-1 as undifferentiated units of consciousness.  
      • Experientially , Descending Humans will face some degree of Earth
changes, an acceleration of disease & deterioration during the ascension
period and will find that portions of Earth’s populations have literally van-
ished without a trace following 2017.  
        • Earth’ s primary particle base and morphogenetic field will transfer to
the Bridge Zone, D-3 Earth will represent the Phantom particle base left over
from Earth's transition & will become a Descending Planet, unable to evolve
out of the HU-1 time cycles.  
        • This is the least favorable path, with far reaching evolutionary conse-
quences, but will be experienced by large numbers of the population if they
do not rapidly awaken & take responsibility for conscious evolution.
448  

                                                                                              
                                                                                                        The Three Tracks of Time
                                                  Time Track 3—Night of the Two Moons—  
                                           Bridge Zone Earth—Agartha—D-3.5 Time Cycle     
            Bridging Humans – Earth’ s 2213-year Leap into the Future (Agartha AD 5336.5)  
          
        • Humans who achieve assembly & activation of all of the fourth & _ of
the fifth DNA strand & who complete a minimum of 1.5 Stellar Activations
will be able to pass into the Bridge Zone-Agartha time continuum with Earth
in 2017. The primary 3-dimensional particle base of Earth, Earth’s core mor-
phogenetic field & the Sphere of Amenti race morphogenetic field will make
this transition. Some localized Earth changes may occur in regions of grid
instability as Earth transitions to the Bridge Zone. Transfer to the Bridge
Zone represents a planetary acceleration of time, through which Earth will
shift to a space-time location 2213-years in the future, from its present space-
time station.  
         • Bridging Humans will perceive a progressively more distinct separation
of those following the old paradigm & the new as 2012 approaches & popula-
tions begin to group by higher & lower particle pulsation rhythms. These
groups will literally “fall out of each other’s range of perception” by 2017. Peo-
ple of the new paradigm will progressively experience more rapid expansion
of consciousness & multidimensional perception, as a natural part of the
Stellar Activations they will encounter.  
    • Bridging Humans will experience more noticeable change than
Descending Humans will as Earth completes the 2017 transition. During the
3-day particle conversion period of 2017 they will find that many structures
that are composed of lower vibrating, inorganic substances & Descending
populations, will literally vanish or de-manifest. The most apparent change
will be in the sudden appearance of buildings & other structures of civiliza-
tion that were not there before, as portions of Agartha become visible. lt will
seem as if these structures “had always been there but had been forgotten”.
This will cause a bit of temporary space-time & memory disorientation for
Bridging Humans as their neurological structures adjust to the new electro-
magnetic pulsation rhythms of the Bridge Zone.  
    •Bridging Humans will have the opportunity to become V oyagers
through the natural acceleration of DNA assembly that will occur as a result
of Bridge Zone Earth's Stellar Activations.  
        • Those who do not V oyage will evolve within a more enlightened Earth
culture, in which new forms of free energy & Keylontic science applications
are discovered.  
       • Perceptually , Bridging Humans will experience a sense of less weight
within the atmosphere & their physical bodies & the body will have a
renewed sense of energy, health & vitality. As the higher chakra centers acti-
vate conscious integration of the soul identity will accelerate.     
449        
                                                                                                                                                                                                              

Data Summaries and At-A-Glance Blow-Up Charts
     •   During the 3-day period populations of Bridge Zone Earth may experi-
ence the visual phenomenon of the appearance of bright moon halos or two
distinct moons, thus the Bridge Zone is known as the path of the Night of the
two Moons.
    •   Bridging Humans will be free from Dracos-Zeta manipulation & will
have progressively more open relations with guardian ET cultures.
     •  The Halls of Amenti ascension passages & the Hall of Records race
history will be open to populations of Bridge Zone Earth & a new age of
enlightenment will begin.
     •   The Bridge Zone represents the ful fillment of a guardian initiated Earth
rescue mission through which the integrity of the human evolutionary blue-
print will be secured. Bridge Zone Earth is the second most desirable path &
one that will be taken by about 8% of Earth's populations.
                                    
                               CHOOSING YOUR FUTURE
          The path you will find yourself on between 2012 - 2017 will be deter-
mined by your choices now. The key to ascending to the Bridge Zone or Tara
is Bodily Transmutation, which is achieved through the rapid assembly and
activation of DNA strands & the awakening of dormant gene codes. DNA
evolution can be accelerated by consciously using the bio-energetic chakra
system to activate the dormant Star Crystal Seals within the human body &
bio-energetic field. These hidden morphogenetic seals control the operation
of the DNA and when activated allow for transmutation of the cellular struc-
ture from one space-time station to others. Earth’s upcoming Transmutative
Stellar Activation period will allow humanity the opportunity for rapid Star
Crystal Seal activation & DNA acceleration, through which transmutative
self-evacuation from Descending Earth can be achieved. You have free will to
choose what future you will see, within the greater framework of Earth’s evo-
lutionary course; this course now offer three primary options.
______________________________________________________________                                                                                                  Choose Well._______________________________________________________________
      •   For more information on Stellar Activations & Bodily Transmutation
         see page 464.
         450
                                                      

                    
                                             Appendix II                                  
                                       
                                          
                                Introduction to Keylonta
                                        
                                 THE SCIENCE OF LIGHT, SOUND, THE SUB-CONSCIOUS
                                         SYMBOL CODES, AND THE BASE CODES OF MATTER
                              
                                                 Exploring Ultra-Micro Particle Mechanics
        Keylonta is the science of energy dynamics as they apply to a multidi-
mensional, perpetual motion universe. lt is the primary foundation upon
which all advanced sciences and technologies of light, sound, frequency, and
electromagnetic energy are built. Keylontic Science deals with the underly-
ing structures of electromagnetic energy through which all matter forms are
constructed and with the attributes of electro-tonal energy structure through
which consciousness achieves diversification and individuation. Foundations
of Keylontic Science arise out of a larger category of multidimensional scien-
tific study known as the Science of Vibrational Mechanics . The Science of
Vibrational Mechanics utilizes a schematic of cosmic order that is created
through the inherent dynamics of fission and fusion of electro-tonal energy
units, an order through which the natural laws of the cosmos are set and held
in motion. Keylontic Science employs these natural laws as they apply to the
structures and dynamics of energy, matter and consciousness that are created
through these laws. Keylonta can be viewed as the science of creation, for it is
through the dynamics of Keylontic Science that creation takes place. There
is an organizational intelligence and sentient creative force of vast propor-
tions that is responsible for the design and creation of the cosmos. Through
Keylontic Science we can explore the dynamics of energy and consciousness
through which the cosmos and all forms and beings within it, receive this
design through the Central Creative Source.  
      The cosmic schematic is organized into a formation of two polarized
Cosmic Cores and 12 Meta-Galactic Cores, both united through and existing
within the Central Source of Creation. The Guardians refer to this Central
Source as the Yunasai and it is the sentient, creative identity-in-energy
451 
                                                                                                                                      
        


                                                                                                                     
Introduction to Keylonta  
through and within which the cosmos and its parts manifest. The 12 Meta-
Galactic Cores of the cosmos pair to form six primary reality fields in which
multidimensional reality systems take place.  
          Each of the six pairs of reality fields contains two 15-dimensional systems,
that are referred to as 15-dimensional Matrices.  In one 15-dimensional
Matrix there is one set of 15 dimensions that compose the particle universe
and one set of counter-rotating 15 dimensions that compose the anti-particle
reﬂection of the parallel universe. All life, evolution and form manifestation
takes place within the six 15-dimensional Matrices. The principles of energy
and consciousness that form these reality fields are the same as those that
manifest life forms and sentient consciousness within these fields; the same
dynamics of energy inter-relationships apply to the macrocosm and the
microcosm. The science of Keylonta allows us to study ourselves as interwo-
ven integral parts of this greater structure of the cosmos.  
      Keylontic Science has many diverse applications from communication,
healing, acceleration of the genetic code and advancement of spiritual evolu-
tion to the creation of advanced technologies such as manufacture of interdi-
mensional transport craft and free energy devices to the maneuvering of
time-space portals. Mastery of multidimensional science requires having
knowledge of the minute, electro-tonal units of energy that form all particles
and frequency bands within dimensional systems and the dynamics of elec-
tro-magnetism created through the interplay of these ultra-micro energy
units. Consciousness and matter are both composed of these units of electro-
tonal energy and so both spiritual and scienti fic mastery are brought together
through the applied knowledge of these electro-tonal energy dynamics. Key-
lontic Science provides the foundations of knowledge upon which mastery of
matter and consciousness can be achieved.  
        Keylontic Science derives its name from the word Keylon.  A Keylon is a
composite of ultra-micro electro-tonal energy units called Partiki.  Keylons
group with other Keylons to form dimensionalized, crystalline structures of
energy that exist as the base morphogenetic (form-holding) templates behind
and within all matter forms, particles and consciousness. Keylons compose
the frequency fields of sound and light upon which the entire Cosmic matrix
is structured; the Uni fied Field of cosmic energy is composed of groups of
crystalline Keylons. Keylons also compose the morphogenetic template of
electro-tonal and electromagnetic energy upon which the human DNA,
genetic code, physical body, bio-energetic chakra system and multidimen-
sional aspects of consciousness (the spiritual body) are built. In studying Key-
lons and the energetic dynamics inherent to Keylontic Science we can learn
to consciously direct the path of our physical and spiritual evolution.
Through this knowledge we can one day learn to master the contours of mat-
ter and consciousness as they apply to the simultaneously co-existing space-
452 

                                                                        
                                                                         Six Primary Elements of Keylontic Science
time fields of the 15-dimensional Matrix, within which our present existence
takes place.  
   T o begin utilizing the potentials of Keylontic Science for personal devel-
opment, we must become aware of the basic components of which our bodies,
minds, consciousness and spirit are composed. Once we are aware of our per-
sonal energetic composition, we can begin to learn how to direct our inher-
ent energy to affect desired change within the physical, emotional, mental
and spiritual aspects of our existence. Keylontic Science offers us the oppor-
tunity to explore and utilize the portions of our personal reality that presently
remain hidden from our conscious view. The basic principle in using Keylon-
tic Science is to understand the mechanics by which the elements of Keylon-
tic Science interrelate with the components of multidimensional anatomy.
The first step in the study of Keylonta is becoming familiar with the six pri-
mary elements of Keylontic Science.  
                  
                                     SIX PRIMARY ELEMENTS OF KEYLONTIC SCIENCE       
     1. Partiki : Partiki represent the units of crystalline morphogenetic sub-
stance out of which particles and anti-particles emerge. Partiki are units of
electro-tonal energy-identity that emanate from a central cosmic source
called the  Y unasai.  Partiki are the primary units of energy that form all mat-
ter, anti-matter, pre-matter and non-matter substance. They are units of mul-
tidimensional light-sound and consciousness that represent minute
projections of energy-identity from the central creative cosmic source. Partiki
are the organizational intelligence and operational “life-force fuel” behind
and within all manifestations and consciousness. Partiki operate as minute
self-regenerating “ fission-fusion generators.” Through the dynamics of their
interaction they create and maintain the electromagnetic fields of sound fre-
quency and light spectra of which the cosmos is composed.  
            Partiki are the smallest units of energy in the cosmos  (one could find 800 bil-
lion billion Partiki units in an average 3-dimensional photon). They exist
within and beyond all particle and matter structures and represent the
“divine substance” out of which the cosmos is composed. Through interior
polarization and replication, created through self-generated fission and
fusion, Partiki manufacture two intrinsic sub-units of crystalline morphoge-
netic substance that serve as blueprints for rhythms of pulsation through
which particles and anti-particles manifest. The Partiki sub-units that pulsate
the fastest are called Partika  and they set the pulsation rhythm through
which Partiki units will group to form anti-particles.  
      Partiki sub-units that pulsate more slowly and appear in conjunction
with the Partika are called Particum.  The Particum set the pulsation rhythm
through which Partiki units will group to form particles  that are a slower pul-
sating reflection of the Partika anti-particles. Together the Partiki, Partika
and Particum set the foundations for particle and anti-particle manifestation
453 
                                       
             

Introduction to Keylonta  
within the Uni fied Fields of the 15-dimensional Matrix. They are the ener-
getic substances, through which the base electro-magnetism that keeps the
universe and parallel universe in motion is manufactured.  
   Each Partiki perpetually breaks down into Particum and Partika, particle
and anti-particle, while simultaneously replicating the original Partiki,
through the act of internal fission. The replication serves to retain the pat-
tern of the original, while the Particum and Partika serve to draw other Par-
tiki units from the Uni fied Field. The Particum and Partika are then
magnetically drawn back together in an act of fusion, through which they
merge with the replica of the original Partiki out of which they were created.
During fusion the Particum and Partika draw new energy patterns in the form
of Partiki units back into the morphogenetic structure of the original Partiki,
which expands the original pattern while retaining its organic integrity.
Through this process crystalline composite forms are created, which serve as
the morphogenetic blueprints through which individuated forms and identity
will manifest.  
  The Partika perpetually circulate energy from the original Partiki
through the Cosmic Matrix and the Particum perpetually draw energy from
the Uni fied Field of the Cosmic Matrix back into the morphogenetic form of
the Partiki, expanding its original form. Through this dynamic a perpetual
motion, expanding and contracting universe and parallel universe are perpet-
ually re-created and eternally sustained.  
       Partiki can be viewed in spiritual terms as units of the identity of  God, the cen-
tral creative source . All things are composed of Partiki and thus all things,
beings and consciousness are intrinsically holy as they are composed of and
united through the eternal substance of God. This God-substance of Partiki
allows for individuation of form and identity to be created, creates diversi fica-
tion through a greater field of uni fied consciousness and manufactures the
morphogenetic design through which all individuation and manifestation
takes place.  
    2. Partiki Grids: Partiki units group by like polarization, electrical Par-
tika to Partika, magnetic Particum to Particum, forming strings of energy
units called Partiki Strands.  Partiki Strands group with other such strands to
form geometrical “fabrics” or grids of electro-tonal, electromagnetic energy
that serve as a template of light spectra and sound tones upon which particle
and anti-particle structure forms. These templates of Partiki units are called
Partiki Grids  and they form a Uni fied Field of living energy substance
through which all things in the cosmos are energetically united.  
     All forms of matter and consciousness possess a Partiki Grid at the core of
their individual structure that holds the morphogenetic imprint for the form
or identity and the intrinsic base pattern for the particles and anti-particles
that will manifest that form into matter. The personal Partiki Grid is inti-
mately interwoven with the greater Partiki Grid of the Cosmic Uni fied Field.
454 
 

                                                                         Six Primary Elements of Keylontic Science
All things are eternally, energetically connected to the energy-identity of the
Yunasai/God through the electro-tonal, electromagnetic reality of the Partiki
Grids. Following the pattern of organizational intelligence set by the Yunasai
and carried within the Partiki units, Partiki Grids draw in more units of Par-
tiki from the Uni fied Field, forming more complex geometrical arrangements
of Partiki Strands which become the crystalline dimensionalized templates
upon which all forms are constructed. Partiki strands represent the fibers out
of which individuated morphogenetic fabrics are woven and are the second
state of being between pure conscious energy-identity and manifestation of
form.  
        Partiki Grids represent the morphogenetic fabrics into which tapestries of crys-
talline matter blueprints are laid and are the third state of being between pure con-
sciousness and manifestation of form.  
        3. Keylons:  Keylons are dimensionalized, geometrically formed Partiki
composites, composed of more complex arrangements of Partiki Strands that
form around the base structure of the Partiki Grids. Keylons are minute crys-
talline structures composed of Partiki that form the dimensionality of con-
sciousness and matter. Keylons and the Partiki within them are the “building
blocks of frequency” or sound tones, which are the core structures upon
which matter and consciousness are built. Keylons direct the rhythm of
expansion-projection and contraction-retraction of Partiki units throughout
the cosmos and within the Partiki Grids of all forms. They set the foundation
structures upon which biology and the perception of space, time and matter
are built. Partiki units set the base electromagnetic fields through which
dimensionalization takes place and Keylons direct the contours of how Par-
tiki units will build up into form within those electromagnetic fields. Keylons
form the crystalline matrix of electro-tonal energy that runs through all
things.  
       Keylons represent the primary tapestries of crystalline morphogenetic matter
blueprints upon which sub. particle and sub-anti-particle pre-matter substance will
form. Keylons are the fourth step between pure consciousness and form manifesta-
tion. 
       4. Keylon Codes:  A Keylon Code is a complex grouping of Keylons that
further direct the contours of energy upon which forms are built. Keylon
Codes serve to direct the in- ﬂow and out- ﬂow of Partiki unit energy within
the morphogenetic blueprint of a form into more specific patterns, rhythms of
movement and electro-tonal vibration. All forms of matter and conscious-
ness are structured upon speci fic sets of Keylon Codes that determine the base
atomic and genetic makeup of a form and the characteristics of consciousness
the form will possess. Keylon Codes represent complex patterns of interwo-
ven sound tones and light spectra that form compound morphogenetic crys-
talline structures that serve as the templates of living light and sound to
455 
                                     

Introduction to Keylonta  
which pre-matter sub-particles and matter and anti-matter particles will
adhere.  
      Keylon Codes create and hold together the primary morphogenetic
structure of individuated form; they are the primary structure and organiza-
tional collective intelligence within all things. The manifest attributes of all
matter forms and consciousness can be affected through directed alteration of
existing Keylon Code structures.  
            Keylon Codes represent the compound tapestries of crystalline morphogenetic
matter blueprints upon which pre-matter, anti-matter and matter particles will
 form. They are the ﬁfth state of being between pure consciousness and form mani-
 festation and serve as the complex, multidimensional, morphogenetic blueprint
through which all individuated forms manifest.  
       5. The Crystal Body:  This term is used to refer to the multidimensional
Keylon Code structure of a matter form or form of consciousness. The Crystal
Body represents the individuated morphogenetic construction of a form
through which the contours of its manifest attributes will take shape. The
morphogenetic Crystal Body sets the manifest characteristics a form will pos-
sess, its intrinsic sub-atomic structure, body rhythms, metabolic rate and the
foundations of DNA, the manner in which Partiki units will move through
the form and the type of conscious awareness the form will embody. The
human Crystal Body encompasses 12 dimensions of identity, sound frequency
and light spectra and sets the structure for the bio-energetic chakra system,
auric field and electromagnetic Merkaba Fields (counter-rotating spirals of
multidimensional electromagnetic energy through which the auric field is
formed).  
            The Crystal Body represents the collective ﬁfth state of being between pure con-
sciousness and form manifestation, in relation to an individuated construction of
consciousness or matter . Through the Crystal Body the electromagnetic Merk-
aba Fields of a form are designed and constructed.  
      The Merkaba Fields represent the sixth state of being between pure conscious-
ness and form manifestation.  Through the counter rotating electromagnetic
fields of the Merkaba Fields the contours for the bio-energetic auric field and
chakra system are formed in accordance with the design set by the Crystal
Body.  
            The bio-energetic auric ﬁeld and chakra systems represent the seventh state of
being between consciousness and manifestation.  The bio-energetic field then
serves to direct Partiki units from the Dimensional Unified Fields into parti-
cle or anti-particle construction through which the DNA and biological par-
ticle base of a form is set in to the dimensional framework. Through the bio-
energetic system the pre-matter construction of a biological form is created.
This pre-matter construction is referred to as the Nadis  and Nadial Capsule.
The Nadial Capsule separates the levels of the auric field and the identity
into 3-dimensional divisions and the Nadis serve as a system of minute pre-
456                                                                    

                                              Six Primary Elements of Keylontic Science  
matter channels through which Partiki unit energy from the auric field ﬂows
into the particle manifestation of the body.  
        The Nadis and Nadial Capsule represent the eighth state of being between con-
sciousness and manifestation. The particle and anti-particle construction which
builds up through the pre-matter Nadis into a form's manifest particles or anti-parti-
cles following the design set by the Crystal Body, represent the ninth state of being
between consciousness and manifestation.  The multidimensional spiritual body
of the Soul Matrix and Over-Soul Matrix are part of the individuated mor-
phogenetic Crystal Body of humans, and these aspects of Eternal identity are
composed of Keylon Codes, Keylons and Partiki units, just as the physical
body is composed of these substances. The Crystal Body serves as the under-
lying structure of all matter and consciousness, connects the physical aspects
of being and identity to the multidimensional Soul and Over-Soul Matrices
and connects each individuated form to the greater Crystal Body of the Cos-
mic Uni fied Field. Through directed interaction with the morphogenetic
Crystal Body both genetic and spiritual aspects of human evolution can be
expanded and accelerated.  
       6. Light-symbol Codes:  A Light-Symbol Code is a pattern of electro-
tonal energy composed of speci fic Partiki configurations that make up fre-
quencies of sound and spectra of light. These patterns of light and sound
direct the speed, angles of interface and patterns of refraction and replication
that Partiki units will follow within the Keylon Code structure of the Crystal
Body. Light-Symbol Codes control the way energy will move and manifest
within a form; they serve as the organizational “program” within all Keylons.
By altering the Light-Symbol Code program within the Keylon Codes of the
morphogenetic Crystal Body, the structure of the Keylon Codes and thus the
manifestations they create can be changed.  
       Human evolution of body and consciousness can be accelerated by acti-
vating certain Light-Symbol Codes that are presently dormant within the
Keylon Code structure of the Crystal Body. Once activated these dormant
Light-Symbol Codes direct the morphogenetic Crystal Body, bioenergetic
auric field and chakra system and DNA to operate in new ways. Light-Sym-
bol Codes direct sound tones and light spectra within the contours of the
Crystal Body. This directive serves to control the relationships between Par-
tiki units in the Crystal Body, which translates into operational instructions
for the bio-energetic system and DNA to follow. Light-Symbol Codes can be
used to direct patterns of frequency into the bio-energetic field and DNA in
very speci fic ways that will allow dormant potentials of the DNA to come
into operation. The DNA directs the manifest functions of the physical body
and the physically embodied consciousness, following the design set by the
Light-Symbol Code program within the Crystal Body.  
      Cellular Transmutation can be achieved by adding new frequency pat-
terns into the Crystal Body by changing the program of the Light-Symbol
457 
                                                                                                                
 

Introduction to Keylonta
Codes to hold the new frequency patterns. The use of internal and external
sound frequencies, light spectra and electromagnetic emanations creates hid-
den Light-Symbol Codes within the Crystal Body, which can program the
body toward health and wellness or disease and deterioration. The mind can
be used to direct speci fic Light-Symbol Codes and the electro-tonal programs
they carry into the Crystal Body to create healing, expansion of the genetic
code and conscious awareness and acceleration of multidimensional physical
and spiritual evolution. Through conscious direction of the Light-Symbol
Code programs the body can be freed from its present space-time orientation
by altering the particle pulsation rhythms of the body's dimensional particle
base, once the genetic code has been expanded.  
   Keylontic Science employs knowledge of the interrelationships between
these six primary elements to integrate the aspects of multidimensional iden-
tity and to create positive change and acceleration of evolution for all life
forms in the cosmos. Keylonta is also used to create tactile technologies that
assist in harmonious evolutionary progression. Keylontic Science is the study
of morphogenetic fields and the processes by and through which conscious-
ness becomes manifest. Units of identity from the central creative source
move through and build themselves up within the following states of being,
to become manifest forms and individuated identities as they evolve within
the 15-dimensional system:
1.   Morphogenetic Partiki Units of pure undifferentiated consciousness,
2.   Morphogenetic Partiki Strands,
3.   Morphogenetic Partiki Grids,
4.   Morphogenetic Keylons,
5.   Keylon Code Crystal Body composite morphogenetic fields,
6.   Electromagnetic Merkaba Fields,
7.   Bio-energetic fields and chakra systems,
8.   Pre-matter Nadial substance,
9.   Particle and Anti-particle construction,
10. Simple to complex matter and anti-matter forms, elemental composites,
     biological life-forms and sentient conscious identity and
11. Expanded compound morphogenetic identities of pure sentient conscious-
     ness, possessing complex 15-dimensional Crystal Body structures.Keylon-
     tic Science studies and implements the natural laws and dynamics
     inherent to the creation of matter and the evolution of consciousness.
      
   The Science of Keylonta can be viewed as the science of Light and
Sound (electro-tonal units of Partiki), the Sub-conscious Symbol Codes
(Light-Symbol Codes that program the Crystal Body and operate on a sub-
conscious level) and the Base Codes of Matter (the crystalline Keylon Codes
458 

                                           Six Primary Elements of Keylontic Science
that make up the morphogenetic Crystal Body and form the basis of all struc-
ture). In simple terms Keylonta is the science of Creation and Consciousness,
through which mastery of mind and matter can be achieved and by which spiritual
integration and reunion with our creative Source is accomplished . The dynamics of
Keylonta continually operate within every human being and connect each
human to everything in the cosmos, regardless of whether humanity is con-
scious of this process. The science of Keylonta allows humans to become con-
scious co-creators within the multidimensional reality fields of the cosmos.
Keylonta is the scientific reality behind all of the sacred practices of religions
and mystical traditions. It represents the place where science meets its soul
and religion acknowledges the dynamics of energetic reality inherent to
spirit. Keylonta is the science of the future and of the ancient past, reaching
backward and forward through time to help humanity rediscover sovereignty
over its being today.                    
     Example of a Partiki Grid
“Lines of Light,” composed
of minute, electro-tonal Par-
tiki strands cross over and
through each other, creating
a myriad of geometrical
forms that serve as a “fabric
of light and sound,” or Par-
tiki Grid . The Partiki Grid
serves as a “collector” of Par-
tiki units, pulling in new
Partiki. As Partiki units
build up within the Partiki
grid, they begin to form more
complex structures of elec-
tro-tonal impulse that
become imbedded in the grid
as crystalline Keylon configurations, or Keylon Codes . The Keylon codes set
and hold the structure for all manifestations of matter, pre-matter, anti-mat-
ter and energy fields. Partiki Grids create  the Unified Field of Energy and
Consciousness,  within which all things in the dimensionalized universe
reside and Keylon Codes create individuation of form and consciousness
within the Unified Field. Keylon Codes direct the patterns of Partiki fission/
fusion and the patterns of refraction and replication of electro-tonal energy
that allow for differentiation of form and consciousness within the unified
Partiki grid of  the Cosmic Matrix.         
459 
                                                                                                  


                                                                                        
                                                                                                  Welcome to the Fifth World
                         2.    A Light-symbol code program entered
                               into a Keylon code within a Partiki 
                               grid                                                                                              
                                                                                                        
                                                   WELCOME TO THE FIFTH WORLD
    Many tribal cultures throughout our recent history have shared a rich tra-
dition of prophecy regarding the transitions Earth will encounter during its
2017 ascension cycle. Prophecies of events to come during this period have
been interwoven with race creation stories and mythologies for over 26,556
years. Though the Bridge Zone Project is a new addition to the roster of
events soon scheduled to occur, intuitive knowledge of the ascension cycle
period and the close of the 26,556-year Euiago time cycle has remained alive
within numerous cultures of Earth for thousands of years. This hidden knowl-
edge has shown itself within the Biblical prophecies of Revelations; it was the
foundation for many rites of passage among the Essenes and other historical
mystical societies.  
    Reference to this ascension cycle can be found within the calculations of
the Mayan calendar and inscriptions within the ancient Egyptian pyramids
and this knowledge has played a major role within the rich tapestry of Native
American oral tradition. The knowledge that Earth and the human race
would face something monumental during the “end times” has been the com-
prehension of visionaries throughout the course of recorded history. The “end
times” represent the point in Earth’s evolution when the planet has com-
pleted a cycle of 26,556 years and moves forward through its ascension period
to begin a new cycle.  
   Our upcoming “end times” hold a promise not present during the end
times of past 26,566-year cycles, for this is the first time the planetary grid
will vibrate high enough to allow planetary dimensional ascension to take
place. This opportunity has not been available on Earth for over 200,000
years. The Bridge Zone Project is made possible precisely because Earth is
approaching the end of its present time cycle. If it were not for the Bridge
Zone Project, Earth would once again be unable to ful fill the promise of
ascension, as without guardian intervention Earth’s grid would not have
reached the necessary level of vibration. The planet would have remained
within the HU-1 dimensions for another 26,566-year cycle. The new cycle
would have reached an early close with the destruction of Earth before the
next ascension period occurred.  
461 
                                                                                                                                               

 
                        Introduction to Keylonta
     In many Native American traditions, the coming “end times” ascension
cycle period is viewed as a transition from what is known as the Fourth
World to the Fifth World. The transition is perceived in relation to a much
longer cycle of history in which humanity evolved through three previous
“worlds,” or time periods marked by advanced civilization and high techno-
logical achievement. Contemporary historical analysis does not yet include
these hidden aspects of human evolution. The truth of humanity’s lost past
has remained protected through cultures living more closely in harmony with
the Earth’s natural cycles. We are indeed now approaching the Fifth World.  
  WORLD ONE:  560,000,000—550,750,000 years ago . The Alania
and Lumia of Tara, before the fall to HU-1.  
   WORLD TWO:  250,000,000—25,000,000 years ago . The five Clois-
ter Races of the 12 Tribes seeded on Parallel Earth.  
   WORLD THREE:  25,000,000—5,500,000 years ago . The First Seed-
ing of the 12 Tribes on Earth. The five Cloister Races and Root Race Three:
Lumanians and Four: Alanians. Ended via Electric Wars.             
    WORLD FOUR:  3,700,000 years ago to present. The Second Seeding
3,700,000—848,000 years ago, Root Races Three: Lamanians, Four: Atlanians
and Five: Ayrians and their Cloister Races. Ended via The Thousand-Year
War. The Third Seeding 75,000 years ago to present, Root Races Three:
Lemurians, Four: Atlanteans and Five: Aryans and their Cloisters.  
       Welcome to the Fifth W orld!  
      Between 5/ 5/2000-2017 Earth will make its transition from the present
 Fourth W orld of the D-3 time cycle, into the Fifth W orld of the Bridge Zone
 and Taran ascension time cycles. Due to the Guardians' Bridge Zone Project ,
  the cataclysmic events originally associated with the ''end times'' prophecies
 have been largely avoided. Though there may still be warfare and geographi-
              cal changes in some areas, the scale of these events will be much smaller than
              those foretold through ancient prophecies. There will indeed be a ''cleans-
               ing,'' as predicted by some Native American traditions. As the Earth sepa-
              rates into higher and lower vibrating particle bases, Bridge Zone Earth and
               Phantom Earth each will be ''cleansed'' of the other . Populations of the
                  Bridge Zone Earth will rise to face a new dawn of evolution within the new
             Fifth W orld of enlightenment, progress and achievement. Those on Phantom
              Earth will not make this transition and will remain within the digressing
              Fourth W orld evolutionary cycle of a Descending Planet in the D-3 time con-
                          tinuum.  
                     462  
                           
           

                                                    
                                             Appendix  III
                                                                      
                        
                                                                        Ascension Cycle Dynamics  
    Earth is approaching a time continuum shift between 5/5/2000-2017.
This continuum shift represents a literal planetary time acceleration. Time
accelerations constitute an increase in particle pulsation rhythm for the
three-dimensional particle base of Earth. The human body exists as an intrin-
sic part of the particle content of Earth. As Earth's particle base accelerates in
pulsation rhythm, the particles that compose the human auric field will also
increase in pulsation rhythm. If the physical body and bio-neurological struc-
ture of the body are not prepared to synthesize the faster pulsating particles of
the auric field, this time acceleration will manifest as acceleration of the cel-
lular deterioration process.  
     For the body to retain its vitality through the Earth’s time acceleration,
the particle pulsation rhythm of the body’s three-dimensional particle base
must also increase. The Morphogenetic Seed Crystal Seals within the bio-
energetic system of the human body keep the body's particle base locked into
the pulsation rhythms of dimensions 1-3. In order to accelerate the pulsation
rhythm of the body’s particles, the Seed Crystal Seals must be released, to
unlock the body’s particles from the pulsation rhythms of dimensions l-3.
Seed Crystal Seals are opened by activation of the body’s Morphogenetic Star
Crystal Seals.  
     Star Crystal Seals are activated by awakening the dormant morphoge-
netic chakra centers and drawing new frequency patterns through the chakra
system and into the Star Crystal Seals. Activation and release of the Crystal
Seals creates activation of the dormant Silicate Matrix DNA Fire Codes
which in turn manufactures blood-crystal structures that raise the body’s met-
abolic rate and prepare the body for cellular acceleration. Stellar Activations
and Wave Infusions  are the process by which the Star Crystal Seals are acti-
vated and  Stellar Spiral Alignments  are the catalysts through which Stellar
Activations can occur. Humans who complete a minimum of 1.5 Stellar
Activations will be able to raise the particle pulsation rate of the body suffi-
ciently to avoid adverse effects of Earth’s time acceleration. The following
463 
                                                                                                                                      


                 
                         Ascension Cycle Dynamics
                 information provides an introduction to the science of cellular transmutation
                           through particle acceleration.
                        
                                      STELLAR ACTIVATIONS                    
                  Transmutative Activations—Planetary and Persona l 
      All matter forms and forms of consciousness, including planetary bodies
and human bodies, are manifested through a morphogenetic (form-holding)
imprint, which exists as a quantity of crystalline, electro-tonal energetic sub-
stance that is composed of speci fic patterns of frequency. This morphogenetic
imprint sets the pattern for a form within the 15-dimensional Uni fied Field of
energy substance. The morphogenetic imprint holds the instructions and
design for form-building in a type of digital or electronic encoding, known as
Keylon Codes. Forms come into manifestation and evolve, as patterns of fre-
quency are drawn into the form’s morphogenetic field, from the dimensional
frequency bands of the Uni fied Field of energetic substance within which the
morphogenetic field is placed. This drawing-in of frequency progressively
expands the morphogenetic field and creates evolution of form progressively
upward through the 15-dimensional universe.  
      Within the 15-dimensional Uni fied Field, the morphogenetic field cre-
ates structures of multidimensional electromagnetic energy, around and
through which the matter form will manifest. These multidimensional EM
fields are collectively referred to as the bio-energetic system or the auric field
of a manifest form. All manifest forms possess a bio-energetic system/auric
field. The auric field has seven primary, inner layers through which physical
manifestation takes place and which correspond to dimensional frequency
bands 1 through 7. The auric field also has seven outer layers, which repre-
sent the form-holding morphogenetic imprints for the seven inner layers of
the auric field. The seven outer layers correspond to dimensional frequency
bands 9 through 15. The 14 layers of the auric field are connected to each
other through a central point within the eighth dimension Meta-galactic
Core. This center point represents the point through which a form’s original
morphogenetic imprint was entered into the 15-dimensional system.  
      All forms and beings are thus indelibly connected to each other and the
universe through interwoven morphogenetic fields that are united through
the D-8 center point. Energy moves from the seven outer morphogenetic lay-
ers of the auric field, through the seven inner layers and into manifestation
within dimensions 1-7, through the structure of dimensional Merkaba Fields
(sets of counter-rotating, electromagnetic energy spirals). Each form has fif-
teen dimensional Merkaba Fields, which hold its morphogenetic imprint
intact within the 15-dimensional Uni fied Field. Through the rotation of the
15 Merkaba Fields, an energy structure in the form of an “egg” or capsule is
formed within the dimensional Uni fied Field of each of the 15 dimensions.
464                                      

                                                                                                                     
                                                                                                                 
                                                                                                              Stellar Activations
Through these dimensional energetic capsule structures, the chakra system,
or dimensional energy supply system, is formed. Through the chakra system a
form’s particle base builds up into structures of multidimensional matter. The
15 energetic capsules exist within the same space, separated by variance in
dimensional particle pulsation rhythms. The energetic form of the capsules
gives the auric field the appearance of capsules within capsules, or 15 distinct,
interpenetrating, capsule-shaped layers.  
      The process of dimensional ascension and biological and planetary evo-
lution is the process of accretion or the drawing of successive multidimen-
sional frequency bands into the morphogenetic field. As a planetary body or
human body evolves through frequency accretion, the energetic capsules
within the auric field progressively undergo transmutation of form. Once a
morphogenetic field has accreted most of the frequency bands from the three
dimensions that compose one Harmonic Universe, the energy capsules that
correspond to these three lower dimensions begin to dissolve. The particles
contained within the dissolving auric capsules open into the auric capsules of
the next three highest dimensions, in the next Harmonic universe up. This is
the energetic dynamic by which forms and consciousness progressively evolve
from one Harmonic Universe to the next.  
      The process of dissolving the lower-dimensional energy capsules and
transmuting their particle content into next Harmonic Universe is referred
to as a  Transmutative Activation  or Stellar Activation.  Stellar Activations
are a natural part of the accretion/evolution process, and occur as the pulsa-
tion rhythm of particles in the lower three dimensions speeds up into the
rhythms of the next three dimensional frequency bands. Through the process
of Stellar Activations the levels/capsules of the auric field progressively open
up into each other, dissolving the dimensional frequency barriers that kept
the levels separate within the morphogenetic field. The levels dissolve as the
morphogenetic field progressively draws in more frequency patterns from the
dimensional Uni fied Fields.  
       As the levels dissolve, progressively more energy and awareness merge
with and become held within, the matter-form, and the matter-form shifts
from one set of dimensional time continuum cycles to another. Earth and the
human populations are now approaching a series of Stellar Activations, as
part of Earth’s natural 26,556-year Euiago cycle. The auric field of the planet
and those of Earth’s populations will undergo transformation between 2000
AD-2017 AD. In order for humans to achieve ascension to the Bridge Zone
Earth and avoid becoming trapped in the D-3 time cycle, a minimum of one
and one half personal Stellar Activations must take place. Earth will experi-
ence six such activations between 2000-2017.  
       Humans who do not prepare the body, consciousness and chakra system
for these activations will be unable to shift into the Bridge Zone time contin-
uum or ascend to Tara and beyond. (This applies to disembodied, HU-1 soul
465 
                                     
                                                                                                                                                                                                                        
    

Ascension Cycle Dynamics  
essences, as well as to souls living within HU-1 bodies.) They will also expe-
rience varying degrees of disruption within their personal auric field, chakra
system, DNA and physical, mental and emotional bodies.  
  The Transmutative Activations are referred to as Stellar Activations
because the infusions of progressively higher-dimensional frequency bands
that transmit into the auric fields of Earth and humans, enter into the Earth’s
bio-energetic field through a chain of spiraling, dimensional Merkaba Fields.
The frequency infusions come to Earth following a path of Merkaba Fields
that runs through various star systems before entering Earth’s system through
the Pleiadian-Alcyone and Solar spirals.  
   The six Transmutative Activations, with which we are now concerned,
interface with Earth through the following spiraling, inter-stellar energetic
path: D-10 Lyra-Andromeda, D-9 Andromeda-Galactic Core Morphogenetic
Field, D-8 Meta-galactic Core and Orion, D-7 Arcturus, D-6 Sirius, D-5 Ple-
iades-Alcyone, D-4 Solar Spiral, D-3 Earth. As each of these spiraling Stellar
Merkaba Fields come into alignment with each other and with the three-
dimensional Merkaba Fields of Earth, the frequency patterns associated with
each spiral progressively enter into the Earth’s bio-energetic system and core.
This infusion of multidimensional frequency, which transmits to Earth in the
form of light, sound, electromagnetic and scalar waves that are beyond pres-
ently identi fied spectra and frequency bands, directly alters the particle pulsa-
tion rhythm of Earth’s three-dimensional particle base. This in turn directly
affects the bio-energetic fields of all life forms on the planet and thus the met-
abolic and biological processes of the body that are controlled through the
personal bio-energetic field.                                        
                                 STELLAR WAVE INFUSIONS  
                                                                    Transmutative Wave Infusion s      
       Blue Wave D-5/D-6, Violet Wave D-6/D-7, Gold Wave D-7/D-8, Silver Wave D-8/D-9,
        Blue-Black Liquid Light Wave D-9/D-10 and Silver-Black Liquid Light Wave D-10/D-11
   As the Stellar Activations progressively take place, infusions of UHF
energy begin running through the auric fields of Earth and humans, causing
particle pulsation rhythms to increase and accelerating the Stellar Activation
process. Six Stellar Activations will soon occur on Earth and humans work-
ing to build DNA will also have the opportunity to undergo six Stellar Acti-
vations. Stellar Wave Infusions are a natural part of the DNA evolution
process and will become part of the experiential reality of humans upon the
Bridge Zone or Ascension paths.  
   The first Stellar Activation begins following an infusion of energy into
the Earth’s core, through which the Earth’s core particle pulsation rhythm is
raised high enough to merge with the frequency bands of the first Stellar Spi-
ral, when it aligns with Earth’s Merkaba Fields during the ascension cycle.
466 

                                                                                                                    
                                                                                                             
                                                                                                            Stellar Wave Infusions
Normally the ascension cycle initiates because the human populations of
Earth have reached a high enough vibration of consciousness and DNA
assembly level to pull Stellar Frequency into their bio-energetic fields. 
   The bio-energetic fields of the human collective then serve to raise the
particle pulsation speed of Earth’s grid, which raises the pulsation rhythm of
Earth’s core high enough to link with the Stellar Spirals when they begin to
align with Earth’s Merkaba Fields. Thus humans assist the planet in its parti-
cle evolution. If the consciousness, DNA and bio-energetic fields of humans
are not at a high enough particle pulsation rhythm when the Stellar Spirals
align with Earth, the Earth’s core pulsation rhythm will be too low to link
with the frequencies of the Stellar Spirals. In this case Earth’s Stellar Activa-
tions would not take place, the planet would remain within its HU-1 time
cycle until the next Stellar Spiral alignment and the opportunity for acceler-
ated planetary evolution and dimensional ascension would pass by.  
   If the Guardians had not intervened and arti ficially infused Earth’s core
with D-4 frequency, Earth would not have been able to link with the Stellar
Spirals during this ascension cycle; the opportunity for Earth’s ascension to a
faster moving time continuum and escape from Dracos-Zeta Resistance in fil-
tration would not have been available. The human collective consciousness
alone did not reach a high enough vibration level, the DNA had not assem-
bled enough to create the initial Earth-grid acceleration that would prepare
Earth to receive the frequencies of the Stellar Spirals. The Guardians inter-
vened directly to avert the pending destruction of Earth and the Pleiadian
Star system that would otherwise have taken place in 2976 AD due to Dracos-
Zeta Resistance in filtration. Originally the Guardians planned only to assist
in stimulating the Earth’s core and aligning Earth’s Merkaba Fields to receive
the Stellar Spirals during the ascension period. The rest was to be left up to
humanity’s ability to evolve. Once the pending cataclysm of 2976 AD was
discovered, direct intervention in Earth’s affairs was permitted.  
    Because of the Guardians efforts, Earth is now prepared to receive its first
Stellar Activation on 5/5/2000. During the past seven 26,556-year Euiago
cycles, Earth has been unable to successfully link with the Stellar Spirals to
achieve Stellar Activations. Earth is now approaching the end of its eighth
Euiago cycle, which would naturally occur in 4230 AD, at the close of the
present ascension cycle. Earth and the human lineage have been trapped in
the HU-1 time cycles for 210,216 years to date. The coming period of Stellar
Activations has not been available to or witnessed by members of the present
lineage of the human race, which began with the Third Seeding of the Root
Races 75,000 years ago.  
   Because of the Guardians’  intervention and the necessity of the Bridge
Zone Project, this opportunity and the challenges it will present are available
to the current generation of humans. The events that will occur on and with
467 
                          
               

Ascension Cycle Dynamics  
the molecular and bio-energetic structure of Earth during the 2000-2017 AD
Stellar Activation cycle are unprecedented in recorded human history.  
   The first Stellar Activation begins as a result of Earth’s core pulsation
rhythm reaching a sufficient rate of speed to link with the first aligning Stel-
lar Spiral. Stellar Wave Infusions begin after the onset of the first Stellar
Activation. Halfway through the first Stellar Activation, the first Stellar
Wave Infusion begins. Through the Infusion, the frequency bands of the next
Stellar Activation are entered into the personal morphogenetic fields of
humans and the morphogenetic field of Earth’s core, while the first Activa-
tion is still underway.  
   When the first Stellar Activation is complete, all frequency bands associ-
ated with it have been released from the Earth’s morphogenetic field and are
transmitting through Earth’s grid. The next Stellar Activation begins as the
frequency bands entered into the Earth's morphogenetic field during the first
Stellar Wave Infusion cycle begin to transmit through Earth’s grid. This
sequence of Activation-Infusion-Activation continues through the six Stel-
lar Activations, and each Activation has a Stellar Wave Infusion halfway
through its activation cycle. The process operates within the human auric
field, DNA and body in the same way that it occurs within the Earth’s auric
field and particle body.  
   The first personal Stellar Activation occurs when the fourth DNA strand
begins to assemble (the fourth strand begins to assemble when the personal
morphogenetic field is at a 3-accretion level—all of the frequency bands of
D-1 through D-3 have been drawn into the morphogenetic field.) When half
of the fourth DNA strand is assembled (accretion level 3.5—all of dimen-
sional frequency bands one through three and one-half of the fourth-dimen-
sional frequency bands, are drawn into the morphogenetic field) the first
Stellar Wave Infusion begins within the human auric field and body.  
    By the end of the first Stellar Activation, the first level of the D-1 etheric
body auric capsule dissolves and its particles expand into the D-4 astral cap-
sule and increase their pulsation rhythm to that of the D-4 time cycle. As
each Stellar Activation and Wave Infusion continues, the HU-1 dimensional
auric capsules progressively dissolve and the particles pass into the HU-2
auric capsules, then the HU-2 particles expand into the HU-3 auric capsules
in like fashion. The auric level separations within the human auric field pro-
gressively collapse and the corresponding chakra centers activate and release
their seals. These bio-energetic changes cause higher-dimensional frequen-                                                                                        
cies to transmit through the DNA and body cells, which transmutes the cel-
lular structure, as the particles of the HU-1 body merge with their anti-
particles and increase their pulsation rhythm to that of HU-2.  
  The consciousness is transferred into the time cycles and three-dimen-
sional perceptual experience of HU-2 Tara, HU-3 Gaia or beyond, depending
468 

                                                                                                                   
                                                                                                             Stellar Wave Infusions
upon the level of Stellar Activation that is completed. These are the dynam-
ics of the science of ascension, which is one application of Keylontic Science. 
   The term Stellar W ave Infusion is derived from observation of the actual
energetic process that takes place as these higher-dimensional frequencies
enter the auric field. Once a DNA strand has reached one-half assembly, the
frequency bands from the dimensions above begin to ﬂow in spiraling, ener-
getic waves or sequential pulses of energy, through the lower-dimensional
Merkaba Fields of the body. When viewed with higher-sensory vision, the
energies carried on these energetic wave pulses appear as an infusion of col-
ored electricity or light spectra, bearing the hue associated with the dimen-
sional frequency band carried on the wave.  
   Stellar W ave Infusions not only affect the subtle body structures of the
human aura and chakra system, they directly interact with the physical body
construction, and can be felt as infusions of “jittery”, higher-vibrating electri-
cal current running through the body cells. As the Activations progress, the
Infusions become progressively more noticeable and intense, creating tem-
perature variations, changes in hormonal activity, alterations in sleeping and
eating patterns, fluctuations in bodily energy levels, change of the metabolic
rate, heart rate and breathing patterns, and various other bio-chemical and
neurological symptoms.  
    In bodies that are unprepared to receive the increase in particle pulsation
rhythms brought on by the Earth’s Stellar Activations, the Stellar Wave infu-
sions will create a mounting sense of mental, emotional and biological
fatigue. During Earth’s activations, the energetic systems of humans are
placed under a progressively increasing amount of electromagnetic stress at a
sub-atomic level. This stress will manifest itself in a variety of ways within
the human organism. Physical “sparking” of increased static electricity,
(which can occasionally affect the function of electrical and magnetic appa-
ratus) may develop in some individuals, until the auric body balances the
new frequencies within the body systems.  
   For most people the infusions will not produce such pronounced symp-
toms, but will rather manifest as progressively less subtle symptoms of degen-
eration, lessening of vitality and physical deterioration. The Stellar
Activations and Infusions progressively cause more noticeable physical symp-
toms, which begin subtly and progressively intensify. Through learning to use
the chakra system properly and developing the ability to consciously use
these new frequencies for positive evolution, the potential undesirable effects
of Earth’s Stellar Activations can be avoided.  
    The symptoms produced by Stellar W ave Infusions can be frightening if
one does not understand what is taking place and they can be life threatening
if the lower chakras have not been balanced and the physical body has not
been prepared for these alterations. Through  the Stellar Activations and
469 
                                                       

                     
                        Ascension Cycle Dynamics
Wave Infusions new areas of the brain are brought out of dormancy and the
glandular systems of the body, such as the Thymus, Thyroid, Pineal and Pitu-
itary glands, undergo metamorphosis. People who choose the path of ascen-
sion, or who do not want to end up trapped in the D-3 “Phantom Earth” time
cycle, will need to be aware of these changes. In future communications we
will provide more detailed technical information as to how the Stellar Acti-
vations and Stellar Wave Infusions can be handled with as little discomfort as
possible. At this time we would simply like you to become aware of the con-
cepts of which we speak, so you may begin to consider how you will approach
the coming changes.  
    People who have not chosen the path of conscious, accelerated ascen-
sion still need preparation to accommodate these changes. The Earth body
will undergo six Stellar Activations and Infusions between 5/5/2000 and
2017, whether or not your personal bio-energetic system has been prepared. If
you do not know how to balance your personal subtle energy bodies in the
face of Earth’s grid accelerations, you may find rapid deterioration of your
physical, mental and emotional systems. Your soul identity will attempt to
balance the energies and prepare your body to handle the new frequencies,
but you need to work consciously with your higher identity to employ
changes in habitual mental, emotional and physical activities that may be
detrimental to the process. The Guardian Alliance will offer a program for
Ascension Cycle Adaptation as soon as possible, for those who are interested
in gaining survival skills in this area. For now, you can simply learn about the
auric field and chakra systems through available resources, and begin working
to clear and balance your in-body chakras through energy work, visualization,
toning and other holistic health practices.  
                                     THE STELLAR BRIDGE                                                     
                  Stellar Spirals, Stellar Activations and Wave Infusions  
   During the two ascension cycle periods at the beginning and end of a
26,556-year Harmonic Universe Euiago cycle, certain alignments of multidi-
mensional Merkaba Fields take place. At these times, the spiraling electro-
magnetic currents of the multidimensional Merkaba Fields blend into each
other, forming a large 15-dimensional, spiraling pathway of energy transit
from the Meta-galactic Core at D-8 to all of the other dimensional systems.
These spirals of EM energy run through various galaxies and star systems
before entering into Earth’s solar system. There is a natural pathway of inter-
dimensional Merkaba Field alignment through which these energies interface                                                                                               
with Earth during the second ascension cycle period.    
   The form-holding morphogenetic imprint for the Milky Way Galaxy exists 
within the frequency bands of D-9, thus D-9 is considered to represent 
the Galactic Core. (D-8 holds the morphogenetic field for the entire 15-  
470                                                                                                                              

                                                                                                                         
                                                                                                                   The Stellar Bridge
dimensional Universe, and is thus considered the Meta-Galactic Core.) The
D-9 Galactic Core is located, in spatial terms, within the Andromeda Star
System. Part of Andromeda is located within D-10 frequency bands and is
connected to the D-10 Lyra Star system (Lyra extends from D-10 through D-
12) and part of Andromeda is located within D-9 frequency bands.  
    The Merkaba Field spirals of the Andromeda system are composed of D-9
and D-10 frequency bands and when this D-9/D-10 Merkaba Field interfaces
with the D-1/D-2/D-3 Merkaba Fields of Earth, D-9/D-10 frequencies trans-
mit into Earth’s core and run through Earth’s grid. The D-9/D-10 Merkaba
Fields cannot directly interface with the lower-dimensional Merkaba Fields of
Earth, these EM spirals must connect with a series of other stellar Merkaba
Field spirals in order for a “frequency bridge” to be established between the
higher and lower-dimensional Merkaba Field spirals.  
    This frequency bridge occurs only during certain time periods, when the
Merkaba Fields of these various star systems come into direct alignment with
each other, four times every 26,556 years; twice at the beginning and twice at
the end of the 26,556-year period. When this alignment of spiraling EM
Merkaba Fields occurs, Earth has the opportunity to raise the pulsation speed
of its particle base into that of higher-dimensional time cycles. At these times
interdimensional portals/passageways between Harmonic Universes, dimen-
sional bands and time cycles open and a planet or person can ascend into the
planetary systems of higher-dimensional time cycles or out-of-form manifes-
tation.  
  The pathway of multidimensional, inter-stellar Merkaba Field spiral
alignment runs from the higher-dimensional fields of D-10 Lyra-Andromeda,
through D-9 Andromeda-Galactic Core, D-8 Orion-Meta-galactic Core, D-7
Arcturus, D-6 Sirius, D-5 Pleiades-Alcyone and into the D-4 Solar Merkaba
Field spiral, then down into the D-3/D-2/D-1 Merkaba Fields of Earth. Each
of these inter-stellar dimensional Merkaba Field spirals is referred to as a Stel-
lar Spiral.  Each Stellar Spiral bears the name of the star system through
which it flows and carries within its energy field the light spectra and fre-
quency bands embodied within that star system.  
    Earth is now approaching the alignment of the Stellar Spiral Bridge that
runs from D-9 Andromeda down through the D-4 Solar Spiral to Earth.
Earth’s alignment with each spiral of the Stellar Spiral Bridge occurs in six
phases, beginning with the D-4 Solar Spiral upward through the D-9
Andromeda Spiral.  
    The point at which a Stellar Spiral aligns with the Merkaba Field spirals
of Earth begins a Transmutative Stellar Activation.  Between 5/5/2000 and
2017 Earth will experience six Stellar Activations, through which the six
Stellar Spirals of the multidimensional Earth-to-Andromeda Stellar Bridge
progressively align with Earth’s Merkaba Fields. During each Stellar Activa-
tion, the dimensional frequencies carried within the activating spiral begin to
471 
                                                                                                                                            
 

Ascension Cycle Dynamics  
transmit through Earth's core morphogenetic field and grid, raising the pulsa-
tion rhythms of Earth’s 3-dimensional particle base. It is through this process
that Earth’s grid is raised into the HU-2 time cycle to merge with the grid of
Tara. Before a Stellar Activation begins, the frequencies of the activating
Stellar Spiral are entered into Earth's core morphogenetic field through a
Stellar Wave Infusion.  In simple terms, a Stellar Wave Infusion begins when a Stellar Spiral
begins to align with Earth’s Merkaba Field spirals, and through the Stellar
Wave Infusion, the frequencies of that Stellar Spiral begin to enter Earth’s
core morphogenetic field. A Stellar Activation occurs as the Stellar Spiral
comes into full alignment with Earth's Merkaba Field spirals. At this time,
the frequencies from the Stellar Wave Infusion that have been building up
within Earth’s morphogenetic field begin to release from the morphogenetic
field and transmit through Earth’s 3-dimensional grid and particle base.  
   When half of the frequencies of a Stellar Spiral are released into Earth’ s
grid, halfway through the Activation, the remaining frequencies of the Stel-
lar Spiral completely “download” into Earth’s morphogenetic field. Once all
of the frequencies of a Stellar Spiral have fully entered Earth's morphogenetic
field, the next dimensional Stellar Spiral begins alignment with Earth and
the next Stellar Wave Infusion begins.  
   When half of the frequencies of the new Stellar Spiral have entered
Earth’s morphogenetic field, all of the frequencies from the previous Stellar
Spiral complete activating/transmitting through Earth’s grid, the previous
Stellar Activation ends and the next Activation begins. Halfway through the
next Activation, the previous Wave Infusion ends and the next Wave Infu-
sion begins. The process of Stellar Activations and Stellar Wave Infusions
represents a complex, multidimensional synchronization of Stellar Spiral
movement. It is not necessary to comprehend the complexities of this pro-
cess, but at this time it is important for you to know the basic mechanics of
Stellar Spiral alignment, as you will be faced with these conditions between
5/5/2000 and 2017.  
   Earth will experience six Stellar Activations and W ave Infusions, which
will alter the pulsation speed of Earth’s three-dimensional particle base, as
progressively higher frequencies are transmitted through Earth’s grid. If
Earth’s core had not been raised to a high enough particle pulsation rhythm,
via the Guardians D-4 frequency transmissions, the Solar Spiral would not
have been able to transmit its D-4 frequencies into Earth's core when the
Solar Spiral aligns with Earth’s Merkaba Fields on 5/5/2000. Earth would
have been unable to begin its Stellar Activations and Wave Infusion cycle,
and thus would have remained trapped within the D-3 time continuum,
unable to enter the Bridge Zone continuum.  
   The outcome of this would have been planetary destruction in 2976 AD,
due to Dracos-Zeta Resistance in filtration. We want you to understand the
472 

                                                                                                    
                                                                                                  Morphogenetic Crystal Seals
principle of raising core pulsation rhythm high enough to receive frequency
transmissions from the Stellar Spirals, for this principle applies directly to
your bodies and consciousness, as well as to planetary energy dynamics.  
   If the core energy centers within your bodies are not raised to sufficient
pulsation rhythm to receive the stellar frequencies which will be transmitting
through Earth’s grid during Earth's Stellar Activations, you will be unable to
accompany Earth in the Stellar Activation process. In this case, Earth will
make the shift into the Bridge Zone time continuum, but you will not; you
will find yourselves stationed upon the ''Phantom Earth'' Descending Planet.
On Phantom Earth you will be cut off from your soul matrix and evolutionary
blueprint and in need of a Host Soul Matrix Transplant in order to continue
evolution. Humans are connected to their HU-2 soul matrix via the Sphere
of Amenti race morphogenetic field, which will remain at the core of Bridge
Zone Earth. This condition can be avoided through conscious participation
in the Stellar Activation process.                         
                          MORPHOGENETIC CRYSTAL SEALS  
       Seed Crystals, Star Crystals and Transmutation of the Human Body  
   As Earth enters its cycle of Stellar Activations and Stellar Wave Infu-
sions, humans also have the opportunity to participate in Activations and
Infusions, which will accelerate the evolution of the DNA, body and con-
sciousness and allow humans to enter the time continua of the Bridge Zone
or Tara, for continued evolution. The process of Stellar Activations, as it
applies to people, operates energetically in a way similar to that of planetary
Activations. In planetary Activations, progressively higher-dimensional
sound frequencies and light spectra run through the Earth's grid and three-
dimensional particle base, as the Earth's Merkaba Fields link with and draw
energy from the Stellar Spirals.  
   In humans, the three Merkaba Fields of the physical, mental and emo-
tional levels of the bio-energetic field draw energy from the Stellar Spirals via
the Earth’s three-dimensional Merkaba Fields and grid, through the higher-
dimensional chakras. This energy then moves into the three-dimensional
body via the lower-dimensional chakras. Once stellar frequency is pulled into
the human bio-energetic field, it is passed into the multidimensional, per-
sonal morphogenetic field of the human via Stellar Wave Infusions, just as
stellar frequencies are added to the Earth’s core morphogenetic field through
Wave Infusions.   
  Planetary bodies and human bodies are multidimensional in structure.
The primary morphogenetic identity (form-holding pattern) for galaxies,
planets and people is held within the entry point to the 15-dimensional sys-
tem, the D-8 Meta-Galactic Core. From that point the morphogenetic design
spreads outward into each of the 15-dimensional particle fields. The slower
473 
                                                                                                                                                                                                                             
  

Ascension Cycle Dynamics  
moving particle fields of dimensions 1-7 hold the morphogenetic design of a
form as it will manifest within varying degrees of matter density. The faster
moving particle fields of dimensions 9-15 hold the morphogenetic design of a
form as it exists in terms of pure, electro-tonal conscious energy. Morphoge-
netic dimensions 9-15 are connected to dimensions 1-7 through the D-8
Meta-Galactic Core and energy continually circulates through this 15-
dimensional structure.  
   The collective Uni fied Field of the 15-dimensional Universal system is
referred to as the 15-Dimensional Matrix. Both planets and people are organ-
ically connected to each of the 15 dimensions within the 15-dimensional
Matrix. The 15-Dimensional Matrix is structured into five groups of three
dimensions called Harmonic Universes and portions of the personal and
planetary morphogenetic fields are contained within each of the five Har-
monic Universes. Earth represents the HU-1 portion of the planet, Tara rep-
resents the HU-2 version of Earth and Gaia represents the HU-3 version of
Earth. In terms of humans, the incarnates of Earth are the HU-1 expressions
of the personal morphogenetic field, the Soul Matrix or Dora (dimensions 4,
5 and 6) is the HU-2 version of the personal identity and the Over-Soul
Matrix or Teura  (dimensions 7, 8, and 9) is the HU-3 version of that iden-
tity. In like fashion, Tara can be viewed as Earth’s soul and Gaia as Earth’s
Over-soul. There are also versions of each planet and person that exist as
non-matter energy forms within HU-4 and HU-5.  
   Each planet and person is connected to each of the seven lower-dimen-
sional fields by a minute crystalline pattern of frequency that represents one-
dimensional level of the personal or planetary morphogenetic field. This
minute crystalline structure is called a Morphogenetic Seed Crystal; it serves
to keep the multidimensional aspects of the identity connected to each other
and to the primary morphogenetic imprint within the D-8 Meta-galactic
Core.  
  There are 15 Morphogenetic Seed Crystals within the morphogenetic
structure of a planet or person, one corresponding to each of the 15 dimen-
sions. The Seed Crystals serve as seals that keep the morphogenetic field sep-
arated and locked into each dimensional band; thus we refer to them as Seed
Crystal Seals. The Seed Crystal Seals control the speed at which fourth-
dimensional Merkaba Fields will rotate, and so direct the pulsation rhythm of
particles within each dimension. Along with the Seed Crystal Seals there are
15 more minute patterns of crystallized morphogenetic frequency that exist
within the bio-energetic structure of a person or planet. Whereas the Seed
Crystal Seals set the morphogenetic field into the center of each dimension,
the other 15 seals are placed between dimensional bands and serve to regu-
late the function of the Seed Crystal Seals. The 15 morphogenetic seals exist-
ing between dimensional bands in the bio-energetic structure of a planet or
person are called  Star Crystal Seals or Fire Crystals.  The Star Crystal Seals
474 

                                                                                                            
                                                                                                  
                                                                                                  Morphogenetic Crystal Seals
control the angle at which the Dimensional and Harmonic Merkaba Fields
will rotate, thus they direct the angular rotation of particle spin between the
dimensional bands of a forms particle construction. The Star Crystal Seals
control the operation of the Seed Crystal Seals in each dimension and can
release the Seed Crystal Seals, allowing the dimensionally separated portions
of the morphogenetic field to merge with each other.  
   The D-2 Orange-Gold Flame of Earth’ s morphogenetic field, the D-5 Blue
Flame of Tara’s morphogenetic field and the D-7 Violet Flame of Gaia’s mor-
phogenetic field, which we have previously discussed, represent three of the 15
planetary Morphogenetic Seed Crystal Seals which connect the planet to its
15-dimensional morphogenetic field. Earth-Tara-Gaia also has 15 Planetary
Star Crystal Seals, which exist within various locations throughout the 15-
dimensional universe, that keep the dimensional planetary particle fields sepa-
rate and regulate the angle of rotation of the planetary Dimensional Merkaba
Fields.  
    Planetary Star Crystal Seals regulate the evolution of planets and stars over
extensive periods of time, through directing the orbital patterns of planets, stars
and galaxies. The upcoming ascension period is possible precisely because of
the natural function of the Planetary and Galactic Star Crystal Seals. The
Planetary and Galactic Star Crystal Seals direct the angle of rotation of the
Universal Merkaba Fields, which allows the Dimensional Merkaba Fields of
Star Systems to come into direct alignment at certain times to form a Stellar
Spiral Bridge.  
   This process creates Stellar Spiral Alignments, such as the one Earth is
now approaching. During the Stellar Spiral Alignments the Morphogenetic
Seed Crystals of Earth, Tara and Gaia will temporarily release or open, allowing
the particle base of the planets to raise in pulsation rhythm for grid merger.
Through the Stellar Activations that will accompany the Stellar Spiral Align-
ments, higher-dimensional frequency from the Stellar Spirals will enter into
the Star Crystal Seals of the planets. The Planetary Star Crystal Seals will then
transmit this frequency into the Planetary Seed Crystal Seals that are located
within the centers of the primary vortex/portal systems of Earth, Tara and Gaia.
Through this energy infusion Earth’s particle base will be shifted into the
Bridge Zone time continuum. The Stellar Activation process works the same
way in relation to the human body.  
   The multidimensional bio-energetic field of the human, like that of a
planetary body, possesses 15 Seed Crystal Seals which control the pulsation
rhythms of the body’s multidimensional particle base. The human body is
connected to its HU-2 Soul Matrix, HU-3 Over-soul Matrix and Morphoge-
netic Identity of HU-4 and HU-5 through its 15 Seed Crystal Seals. The
human bio-energetic body also contains 15 Star Crystal Seals that control
475 
          

Ascension Cycle Dynamics   
the operation of the Seed Cr ystal Seals. The Seed Crystal Seals of the human
body are located at the center of the 15 primary chakra centers, nine of
which are located within the physical body structure.  
    Of the n ine embodied chakras, two are presently dormant; these will be
called into activation in humans participating in Stellar Activations. The six
remaining chakras exist within the bio-energetic field, some close to the
body, others extending outward into the galaxy. The six disembodied chakras
connect the human bio-energetic system and dimensional Merkaba Fields to
the Merkaba Fields of Earth and the Stellar Spirals. The disembodied higher
chakra centers will also be called into activation during Stellar Activations.
The human bio-energetic field also contains 15 Star Crystal Seals which con-
trol the function of the Seed Crystal Seals and the angle of rotation of the
personal Dimensional and Harmonic Merkaba Fields. Six of the Star Crystal
Seals are located outside of the body, nine are stationed within the body at
various levels of dimensional frequency.  
   The Star Crystal Seals of the human body are presently in a dormant
state, which keeps the Seed Crystal Seals of the chakra system closed, the
body’s particle base and consciousness separated and the personal Dimen-
sional Merkaba Fields locked into their respective dimensional frequency
bands. These conditions keep the human locked within the space-time coor-
dinates of Earth's present time cycle. For humans to shift out of the D-3 time
cycle and into the Bridge Zone with the majority of Earth’s particle base, the
human body must complete a minimum of 1.5 Stellar Activations. Through
the process of the first two Stellar Activations, two Star Crystal Seals will
activate and two Star Crystal Seals will release, allowing the particle pulsa-
tion rhythm of the three-dimensional human body to increase and the angu-
lar rotation of particle spin to shift into that of the HU-2 time cycles.  
     Each of the six Stellar Activations the Earth will encounter between
2000 and 2017 can also be achieved by humans upon the planet, because the
interdimensional Stellar Spirals come into alignment during this time period.
Each of the six Activations will activate various Star Crystals Seals within
the human body, if the human chakra system is used appropriately to draw in
frequency patterns and light spectra from the Stellar Spirals.  
     When the Star Crystal Seals activate, as a result of this infusion of fre-
quency, each progressively opens various Seed Crystal seals within the
chakras. Through this process, the HU-1 incarnate’s Merkaba Fields open
into and merge with the HU-2 soul matrix Merkaba Fields, allowing the
human body and consciousness to progressively transfer its particle content
out of HU-1 into HU-2, then from HU-2 into the Over-soul matrix of HU-3.
This is a complicated process of interdimensional energy dynamics. For our
discussion, it is enough for you to know that the Star Crystal Seals and Seed
Crystal Seals exist as part of your bio-energetic make up. These energy cen-
476 

                                                                                                                           
                                                                                                               The Silicate Matrix
ters will be used during Stellar Wave Infusions and Activations, in order to
transmute the particle content of the body and consciousness out of the D-3
time cycles and into the HU-2 time cycles of Bridge Zone Earth or Tara .
                                 THE SILICATE MAT RIX        
       The Crystal Seals, Seed Codes, Fire Codes and The Silicate Matrix  
  The process of assembling DNA strands by working with the higher
chakras is the process of bringing frequency from the Stellar Spirals into the
Star Crystal Seals. There is an intimate relationship between the Seed Crys-
tal Seals, Star Crystal Seals and human DNA. Each Seed Crystal corresponds
directly to and controls the basic function of one strand of DNA. The foun-
dations of human DNA are minute templates of crystallized frequency—elec-
tro-tonal sound patterns and electromagnetic light spectra that magnetically
group into crystalline form. These minute, multidimensional crystalline tem-
plates are referred to as DNA seed codes . 
    Of the 15 Seed Crystal Seals within the bio-energetic body of the human,
12 Seed Crystal Seals governs the function of the DNA Seed Codes within
the 12-strand DNA imprint; one Seed Crystal Seal directs the Seed Code of
one strand of DNA. The Star Crystal Seals of the bio-energetic body also cor-
respond to the DNA. Within the morphogenetic imprint for human DNA
there are dormant gene codes that correspond to the Star Crystal Seals; as
long as the Star Crystal Seals are not activated, these gene codes will remain
dormant. Each Star Crystal Seal is composed of half of the frequency patterns
of the dimension above it and half of those from the dimension below.  
  There are 12 dormant DNA  codes corresponding to 12 Star Crystal
Seals and each code carries the frequencies and light spectra contained
within the Star Crystal Seal. These dormant gene codes allow for the sepa-
rate DNA strands to “plug into each other”, a condition necessary for Cellu-
lar Transmutation. The 12 dormant gene codes corresponding to 12 of the 15
Star Crystal Seals are individually referred to as Genetic Time Codes, Codes
of Transmutation or  Fire Codes . Collectively the 12 Fire Codes are known as
the Silicate Matrix  or the Crystal Gene. This is the original gene construc-
tion of the human organism.  
   Due to various genetic mutations, a very small percentage of humans
presently carry the entire Silicate Matrix in the personal morphogenetic
imprint for the DNA. Through distortions within the DNA Seed Codes, the
Fire Codes of the Silicate Matrix break down and can no longer function.
Without the functional Silicate Matrix, the Star Crystal Seals of the bio-
energetic body cannot activate and thus the body cannot achieve cellular
transmutation. Without operational Fire Codes, the body becomes locked
within its dimensional space-time station. The Fire Codes of the Silicate
477 
                                                                                                                                                                                                              

    Ascension Cycle Dynamics  
Matrix are restored to f unction through correcting distortions within the
DNA Seed Codes; as the Seed Codes are repaired, the Fire Codes reassemble.
   During the upcoming ascension period and through the birth of the Six
Silent Ascension Avatars who will realign the DNA imprint, the distorted
DNA Seed Codes will be corrected in the race morphogenetic field, making
it possible for large numbers of people to reverse-mutate their DNA strands.
This reverse-mutation will allow for the Fire Codes of the Silicate Matrix to
begin re-assembly in people who do not carry this imprint, restoring the
body’s ability to activate the Star Crystal Seals and achieve cellular transmu-
tation.  
    This process will not take place automatically . It requires conscious par-
ticipation to prepare the body for these changes. The Higher Self and Soul
level aspects of personal identity will do much of the work, but the choices of
the conscious personality will have great bearing upon the outcome of these
multidimensional processes. Every thought and activity will either assist the
Higher Self in preparing for these changes or detract from its efforts to do so.
In subsequent books we of the Guardian Alliance will provide exercises
through which you can begin to consciously participate in this process. For
now we would simply like you to become acquainted with these hidden
dynamics of the science of ascension.                                                         
                                                   DNA 101                                                          
                                                   Definitions  
 1.    Seed Crystal Seals:  Minute crystalline frequency seals within each chakra
and auric field level of the 15-dimensional human bio-energetic field, that
keep particles and anti-particles in one dimension separated from each
other. Each Seed Crystal Seal corresponds to the frequency bands of one
dimension and directs the function of one DNA strand that corresponds
to that dimension. One Seed Crystal Seal separates the particle and anti-
particle units of the DNA strand, keeping the body’s particle base polar-
ized and locked into that dimensional band.  
The separation of particle and anti-particle caused by the Seed Crystal
Seal keeps the body’s particle base locked into the time continuum and
particle pulsation rhythm characteristic to that dimension. The Seed
Crystal Seals control particle pulsation rhythm, keeping it consistent with
the pulsation rhythm of the dimensional band in which the Seed Crystal
Seal is located. The Seed Crystal Seals control the speed at which the
Dimensional Merkaba Fields spin. Release of a Seed Crystal Seal allows
the particles and anti-particles of one dimension to fuse and to accelerate
in pulsation rhythm, causing the Dimensional Merkaba Field to accelerate
its speed of rotation.  
478 
  
 

                                                                                                                                                                                                                                                               
                                   DNA 101
When  the body’s particles in one dimension fuse and accelerate and the
rotation speed of the Merkaba Field increases, the Star Crystal Seal
between that dimensional band and the dimensional band above releases.
Seed Crystal Seals are considered Horizontal Seals, as they control the
horizontal movement of frequency bands, light spectra and particles in
one dimension. There are nine Seed Crystal Seals located at the center of
nine primary chakras within the structure of the physical body and six
located at the center of chakra centers outside of the physical body, for a
total of 15 Seed Crystal Seals within the design of multidimensional
human anatomy.  
2.   DNA Seed Codes—Base Codes And Acceleration Codes:  Units of
minute crystalline frequency that form the morphogenetic templates for
DNA strands. The template for one DNA strand is composed of 12 mag-
netic particle units and 12 electrical anti-particle units. The 12 magnetic
particle units are called Base Codes. The 12 electrical anti-particle units
are called Acceleration Codes.  
Each DNA strand is composed of the frequency patterns and light spectra
of one dimensional band. All aspects of human DNA are built upon this
morphogenetic template of 12 Base Codes and 12 Acceleration Codes.
The DNA Base Codes in one DNA strand represent the 12 magnetic base
tone frequencies of one dimension that corresponds to that strand and the
DNA Acceleration Codes represent the 12 electrical overtone frequencies
contained in one dimensional band. The electrical overtone frequencies
of a dimension correspond to the magnetic base tone frequencies of that
dimension's anti-particle counterpart in the parallel universe.  
The 24 Seed Codes of one DNA strand serve to set the body’s particle and
anti-particle content into the dimensional band corresponding to that
DNA strand, in both the particle and anti-particle universe. Each set of
Base Codes and Acceleration Codes in one DNA strand is controlled by
one Seed Crystal Seal, which serves to keep the particle Base Codes and
anti-particle Acceleration Codes of the DNA strand separate, thereby
maintaining the body’s particle base within the pulsation rhythms of that
dimension. Release of the Seed Crystal Seal allows Base Codes and Accel-
eration Codes in the DNA to fuse or “plug into each other” and accelerate
in pulsation rhythm. This allows the body’s particle and anti-particle base
in that dimension to fuse and accelerate in pulsation rhythm.  
The fusion of DNA Base Codes and Acceleration Codes causes minute
crystalline structures to manifest within the molecular structure of the
blood, which prepares the body’s bio-chemical, cellular, hormonal and
metabolic systems for acceleration of particle rhythm and transmutation.
Dimensional particle rhythm acceleration causes the Star Crystal Seal
479
                                                                                                         
                                                                                                              

Ascension Cycle Dynamics
between that dimension and the dimension above to release. Release of a
Star Crystal Seal activates a dormant Genetic Time Code or Fire Code
within the two DNA strands corresponding to that Star Crystal Seal.
3.   Star Crystal Seals: Minute crystalline frequency seals between chakras
and auric field levels within the 15-dimensional bio-energetic human
body, that keep particles and anti-particles from one dimensional band
separate from those in the dimensional bands above and below.
Each Star Crystal Seal corresponds to and is composed of the frequency
bands from the dimension above and from the dimension below the Star
Crystal Seal. The Star Crystal Seal directs the interaction between the
two DNA strands that correspond to the dimensions above and below the
Star Crystal Seal. One Star Crystal Seal separates the particles and anti-
particles in one dimension from the particles and anti-particles in the
dimension above, another separates the particles and anti-particles in that
dimension from those in the dimension below.
The Star Crystal Seals keep the particle fields of the three-dim ensional
body and multidimensional consciousness separate by controlling the
angular rotation of particle spin between the 15 dimensions. The separa-
tion of particle fields into three-dimensional groupings, which the Star
Crystal Seals create, keeps the particle content of the body locked into the
three-dimensional field of one Harmonic Universe. The Star Crystal Seals
control the angle at which the personal Dimensional Merkaba Fields will
rotate and thus also control the body’s relationship to the Harmonic
Merkaba Field (the three-dimensional Merkaba Field of one Harmonic
Universe). Release of a Star Crystal Seal allows the personal Dimensional
Merkaba Fields to align on a vertical axis with the Harmonic Merkaba
Field , which causes the Harmonic Merkaba Field rotation to accelerate,
aligning it with the Merkaba Field of the three-dimensional Harmonic
Universe above. Release of the Star Crystal Seal also allows the particles
and anti-particles in one three-dimensional field to merge, fuse and trans-
mute into the dimensional bands of the Harmonic Universe above.
As a Star Crystal Seal releases, a dormant DNA code called a Genetic
Time Code or ﬁre code activates within the two DNA strands correspond-
ing to the Star Crystal Seal. Star Crystal Seals are considered Vertical
Seals, as they control the vertical movement of frequency bands, light
spectra and particles between dimensions. There are nine Star Crystal
Seals located within the structure of the human body, and six located
within the multidimensional bio-energetic body (outside of the physical
structure), for a total of 15 Star Crystal Seals within the design of multidi-
mensional human anatomy.
 480

                                                                                                                                              
                                                                                                                         DNA 101
  4.       DNA Fire Codes—Activation Codes:  Units of minute crystalline fre-
quency within the dimensional morphogenetic imprint for the DNA that
link DNA strands together and allow for cellular transmutation, teleporta-
tion, time travel and dimensional ascension to take place. Also referred to
as Codes of Transmutation or Genetic Time Codes. One DNA Fire Code
corresponds to each Star Crystal Seal. Each DNA strand contains half of
the Fire Code that corresponds to the Star Crystal Seal from the dimen-
sional band above the dimensional band to which the DNA strand corre-
sponds. It also contains half of the Fire Code corresponding to the Star
Crystal Seal from the dimensional band below that corresponding to the
strand.  
The DNA Fire Codes allow one DNA strand to “plug into” and fuse with
another. When DNA strands fuse, the Base Codes and Acceleration
Codes of one strand merge with those of the strand above, fusing particles
and anti-particles between dimensional bands. This allows the three parti-
cle bases of a three-dimensional human body to merge, the separation
between them dissolving. When the three-dimensional particle bases of a
body in one Harmonic Universe merge, the particles and anti-particles are
able to rapidly accelerate pulsation rhythm, turn into light waves and
transmute into the dimensional bands of the Harmonic Universe above.
The Fire Codes activate when their corresponding Star Crystal Seals
release.  
Once activated, the Fire Codes rapidly accelerate the assembly and activa-
tion of the Base Codes and Acceleration Codes of the strands to which
the Fire Code is attached. The Seed Crystal Seal in the next chakra up
then releases and particles and anti-particles within the dimensional band
corresponding to that Seed Crystal Seal fuse, activating the next Star
Crystal Seal. When the Fire Codes activate, the blood crystals (formed by
the release of successive Seed Crystal Seals), merge, forming complex
blood crystal structures, which carry the frequency patterns of three
dimensions. The three-dimensional blood crystals trigger further bio-
chemical, cellular, hormonal and metabolic acceleration. This biological
acceleration allows the body to raise the rhythm of particle pulsation and
shift the angular rotation of particle spin. The three smaller dimensional
Merkaba Fields of the body merge and open into the Harmonic Merkaba
Field, which then merges with the Harmonic Merkaba Field of the Har-
monic Universe above. The body cells accelerate, transmute into light
then re-manifest within the three-dimensional field of the Harmonic Uni-
verse above.  
There are 12 Fire Codes dormant within the original human 12-strand
DNA imprint, each corresponding to one of 12 Star Crystals. The 12 Fire
Codes are collectively referred to as the Silicate Matrix or Crystal Gene-
481
                                                                                                           
  
 

Ascension Cycle Dynamics  
the Gene of Transmutation. The  Fire Codes break down through distor-
tion in the DNA Seed Codes and become dysfunctional until the DNA
Seed Codes are realigned. The Star Crystal Seals of the bio-energetic body
cannot release unless the Silicate Matrix is operational.                              
                          DNA Mutations and the Ascension Cycle  
    Prior to mutation of the human genetic code, the process of Seed Crystal
Seal, Star Crystal Seal and Fire Code activation happened automatically as a
natural part of the biological evolutionary process. As the morphogenetic
field drew in frequency from the dimensional Uni fied Fields, progressively
assembling those frequencies into the DNA imprint then activating the
imprint through manifesting a corresponding DNA strand, the Seed Crystal
Seals would naturally release. Then the next Star Crystal Seal would release
and the DNA Fire Code would activate, progressively transmuting the cellu-
lar structure into less dense states of matter. The body systems were under
conscious control and the Immortal Human could choose desired time-space
placement by consciously altering the personal Merkaba Fields, bio-energetic
structure and particle pulsation rhythm. Presently these processes do not
operate as they were intended due to various DNA strand distortions and
mutations.  
  The coming ascension period of 2012-2017 offers humanity a rare
opportunity to rapidly reverse-mutate these genetic distortions, realign the
DNA imprint with its original 12-strand pattern and accelerate the evolution
of biology and consciousness by thousands of years. Humans who do not
make the shift to Bridge Zone Earth will not have this opportunity again, for
the Stellar Merkaba Spirals do not fully align with the Merkaba Fields of a
Descending planet. The DNA of humans on the Descending Phantom Earth
will undergo another mutation; the DNA will be unable to assemble beyond
the third strand and portions of the fourth strand that had begun to assemble
will dismantle and de-activate. This genetic mutation can be remedied only
through a Host Matrix Transplant, through which a Soul Matrix from HU-2
allows the HU-1 incarnate to energetically and genetically braid into its Soul
Matrix morphogenetic field. Individuals of Phantom Earth who do not have
Host Matrix Transplants will find their genetic codes, bodies and conscious-
ness deteriorating over several generations until the ability to reproduce is
lost. Cloning tactics further reduce the genetic imprint and ultimately will
not preserve the species. This is precisely the condition that occurred within
the Zeta race strains.  
  Due to the Stellar Spiral Alignments, Stellar Activations and Stellar
Wave Infusions of the ascension period, the process of cellular transmutation
can be brie ﬂy called into action. This will allow for a self-generated bio-ener-
getically induced transmutative evacuation from Phantom Earth to take
place, for those who participate in the Stellar Activation process. The DNA
482 

                                                                                                                        
                                                                                                                                    
                                                                                                                                 
                                                                                                                                DNA 101
strand mutations will be cleared from the race morphogenetic field of the
Sphere of Amenti and the corrected imprint will be transmitted through
Earth's grid into the bio-energetic fields of humans who have prepared their
system to receive these energies.  
       The frequencies carried on the Stellar Spirals can then create activation
and release of the Star Crystal Seals, which will allow the Seed Crystal Seals
to open and the DNA Fire Codes to activate. Through this Star Crystal Seal
Activation process, the particle pulsation rhythms of the body and conscious-
ness can be accelerated and the DNA rapidly assembled and activated, so
individuals may shift into the Bridge Zone or Taran time cycles. Each of the
upcoming six Transmutative Stellar Activations will allow various Star Crys-
tal Seals to release and DNA strands to activate. A minimum of 1.5 Stellar
Activations must occur for an individual to successfully shift into the Bridge
Zone. Those who do not make the shift will end up on Phantom Earth in the
D-3 time cycle after 2017. Reincarnation out of HU-1 will require a Host
Matrix Transplant.  
      Releasing of the Star Crystal Seals of the human body is a complicated
process of multidimensional physics. We do not have enough time to teach
you of the intricacies involved in this process. For this reason our future work
will focus upon bio-energetic techniques you can use to facilitate the process,
rather than on laborious conceptual foundations such as those presented in
this book. It is important that you comprehend the basic concepts of these
energetic dynamics so future exercises will make some bit of rational sense to
you. To take this opportunity for accelerated evolution, you simply need to
know how to use your mind to direct frequency. You also need to know what
frequencies are available at what times via the Stellar Spirals, how to bring
these frequencies into your bodies and where to direct them once you have
drawn them in.  
     Frequencies from the Stellar Spirals are drawn into your body via the
higher-dimensional chakras; the chakra centers located outside of the body
that are primarily dormant at this time and do not transmit frequency directly
into the lower, in-body chakras. By intention you can use the Stellar Spiral
frequencies to activate these higher chakra centers, then draw energy from
the Spirals through the activated chakras into the lower chakras and the
appropriate Star Crystal Seals.  
483 

Ascension Cycle Dynamics
                                           You must know:
   A. What Stellar Spirals carry what frequencies and when the Spiral aligns with Earth,
                                         making those frequencies available.
 
  B. Where your higher and lower chakras and Star Crystal Seals are located, what
 frequencies each chakra can draw in and how the chakras correspond to the Star Crystal
                                                    Seals you need to activate.
    The in-body chakras of 1-7 correspond to the frequency bands of dimen-
sions 1-7. The higher-dimensional chakras that correspond to dimensions 9-
15 are called Morphogenetic Chakras, as they open into and draw energy
from the morphogenetic fields of dimensions 1-7, which are correspondingly
located in dimensions 9-14.  
    The lower dimensions and chakras are linked to the higher dimensions
and morphogenetic chakras through the Meta-galactic Core at D-8 and the
eighth chakra; the activated eighth chakra allows you to draw frequency from
the morphogenetic chakras down into the lower chakra centers.  
   T o activate certain Star Crystal Seals you will open the morphogenetic
chakra that corresponds to the lower chakras with which that Seal is associ-
ated, then draw frequency from the morphogenetic chakra into the Star
Crystal Seal.  
     It is not difficult to do once you understand the correspondences between
the lower chakras, their Star Crystal Seals and the morphogenetic chakras.
For your convenience we provide the following charts.  
               ASCENSION CYCLE DYNAMICS AT-A-GLANCE
                                         BLOW-UP CHARTS
1.  Crystal Seals and Chakras Correspondence Chart, see page 485.
2.  Stellar Activations, Stellar Spiral Alignments and Star Crystal Seal Acti-
             vations Chart, see page 486.
3.  Crystal Seals, Dimensional Placement and DNA Correspondence Chart,
             see page 487.
4.  15-Chakras and 15-Star Crystal Seals Anatomical Placement Chart, see
             page 488.
5.  Six Personal Stellar Activations and Wave Infusions Chart, see page 489.
6.  Planetary Stellar Activations and Wave Infusions Chart, see page 490.
7.  Stellar Activations and Wave Infusions Schedule, see page 491.
8.  Stellar Spiral Alignments Schedule, see page 492.
484

            
                                                 Ascension Cycle Dynamics At-A-Glance Blow-Up Charts
                                         6 Personal Stellar Activations and Wave Infusions Summary
                                            The Star Crystal Seal - DNA Transmutative Activations Available to Humans 5/5/2000 -2017
1  D-4 SOLAR - HEART STAR  - ACTIV ATION: D-4 Solar Spiral Aligns 5/5/2000
        ' DATES A V AILABLE FOR ACTIV ATION : 5/5/2000 - 2022 general populations
         STAR CRYSTAL SEAL ACTIV ATES : # 5 D-4/D- 5 BLUE STAR CRYSTAL  chakra 4 Heart Chakra
      RELEASES STAR CRYSTAL SEAL : # 2 D-1/D-2 Orange Star Crystal Seal opens
      DNA:  Strand 4 assembles & activates  Fire Code : ½ strands 1-2 activate  ACCRETION LEVEL : 3 to 4
      CHAKRAS:  draw frequency  from Solar Spiral through chakras 11 & 12, into chakras 4 & 5 then into
      Blue Star Crystal Seal
      Blue Wave Infusions  of D-4/D-5 frequency begin at Blue Star one-half activation                                             __________________________________________________________________________________ _____
                                      2   D-5 PLEIADIAN - SOUL SEAT  -ACTIV ATION : D-5 Pleiadian-Alcyone Spiral Aligns 6/2004
         DATES A V AILABLE FOR ACTIV ATION : 9/9/2004 - 2022 general populations
            STAR CRYSTAL SEAL ACTIV ATES:  #6 D-5/D-6  INDIGO STAR CRYSTAL , In 8thchakra between chakras 4 & 5
  RELEASES STAR CRYSTAL SEAL : #3 D-2/D-3 Yellow Star Crystal Seal opens
  DNA:  Strand 5 assembles to activate 2012 -2022 Fire Code : strands 2- 3 activate ACCRETION LEVEL : 4 to 5
  CHAKRAS:  draw frequency from Alcyone Spiral through chakras 10 &11 into chakras 5 & 6 then into
   Indigo Star Crystal Seal
      Violet-Blue Wave Infusions  of D-6/D-7 frequency began at lndigo Star one-half activation                                         ______________________________________________________________________________________ __
3  D-6 SIRIAN  - EARTH STAR - ACTIV ATION: D6 Sirian Spiral Aligns 6/2008
   DATES A V AILABLE FOR ACTIV ATION ; 7/22/2008 - 2017 day-3 of conversion period 5/5/2017 - 6/30/2017
   STAR CRYSTAL SEAL ACTIV ATES  # 8 D-7/D0 GOLD STAR CRYSTAL : chakra 12 6" below feet
   RELEASES STAR CRYSTAL SEAL : #5 D-4/D-5 Blue Star Crystal Seal opens
   DNA : Strand 6 assembles to activate 2017 day-3 Fire Code : strands 4-5 activate ACCRETION LEVEL : 5 to 6
   CHAKRAS:  draw frequency from Sirian Spiral through chakras 12, 9 8& 8 then into chakra 7, back to 12 and
   into Gold Star Crystal Seal
   Gold Wave lnfusions  of D-7/D-8 frequency begin at Gold Star one-half activation
                                             __________________________________________________________________________________ _____
                      4   D-7 ARCTURIAN -  CORE STAR - ACTIV ATION : D-7 Arcturian Spiral Aligns 2017 day-1 Holographic Beam
.     DATES A V AILABLE FOR ACTIV ATION  2017 day-1 through day-3 (between 5/5/2017 - 6/30/2017)
      STAR CRYSTAL SEAL ACTIV ATES . # 9 D-8/D-9  SILVER STAR CRYSTAL , above navel
      RELEASES STAR CRYSTAL SEAL  #6 D-5/D-6 Indigo Star Crystal Seal opens
      DNA  Strand 7 assembles, activates day-2, 6 activates  Fire Code : strands 5-6 activate ACCRETION LEVEL :6 to 7
       CHAKRAS  draw frequency from Arcturian Spiral through chakras 8 & 9 then into Silver Star Crystal Seal above
      navel
      Silver Wave Infusions  of D-8/D-9 frequency begin at Silver Star one-half activation
                                        _______________________________________________________________________________________ _
 
                                  5  D-8 ORION - EARTH CORE - ACTIV ATION : D-8 Orion Spiral Aligns 2017 day-2 Holographic Beam
                                          DATES A V AILABLE FOR ACTIV ATION : 2017 day-2 through day-3
                                          STAR CRYSTAL SEAL ACTIV ATES: D-9/D-10 BLUE-BLACK CRYSTAL  chakra 13 In Earth's Core
                                          RELEASES STAR CRYSTAL SEALS:  # 7 D-6/D-7 Violet Star #4 D-3/D-4 Green Star & ½ #1 D-1/D 15 Red Star
                                                DNA : Strand 8 assembles, 7 & 8 activate  Fire Code : strands 6-7,3-4, ½ 1-2 activate ACCRETION LEVEL :7 to 8
                                     CHAKRAS : draw frequency from Orion Spiral through chakras 13. 7 &6, into 9 & 10 then into Blue-Black Crystal
                                           Seal in chakra 13 at Earth’s Core
                                    Blue-Black Wave Infusions  of D-9/D-10 frequency begin at one-half Blue-Black Star activation
                                       _______________________________________________________________________________________ 6  D-9 ANDR OMED A-GALACTIC CORE -ACTIV ATION :D-9 Andromeda Spiral Aligns 20I7day-3 Holograph ic Beam
           DATES A V AILABLE FOR ACTIV ATION : 2017 day-3
           STAR CRYSTAL SEAL ACTIV ATES : D-10/D-11 SILVER-BLACK CRYSTAL.  deep space
           RELEASES STAR CRYSTAL SEALS : #8 D-7/D-8 Gold Star Crystal Seal opens
           DNA : Strand 9 assembles & activates  Fire Codes : strands 7-8 activate  ACCRETION LEVEL : 8 to 9
          CHAKRAS : draw frequency from Andromeda Spiral through chakras 6 & 5, into 10 & 11 then into
           Silver-Black Star Crystal Seal in deep space through Andromeda
           Silver-Black wave Infusions  of D-10/D-11 frequency begin at one-half Silver-Black Star activation
                                                                                ©2002 Ashayana Deane        
                              489  
                                                                                                                                              
              
                                                                                                                              

                     Ascension Cycle Dynamics
                                             PLANETARY STELLAR ACTIVATIONS AND WAVE INFUSIONS
                                               The 6 Stellar Activations Earth Will Face Between 5/5/2000 and 2017.
 1    D-4 SOLAR ACTIV ATION : D-4 Solar Spiral aligns with Earth
  DATE:  5/5/2000 - 6/2004  EARTH ACTIVATION
  EARTH VORTEX OPENS : V ortex # 4 - Giza Egypt - 1/2000 - 6/2004
  BLUE WAVE INFUSION : 2002 -2006  D-5 BT & D-6 OT frequencies enter Earth's Core
  DNA:  DNA strand it 4 assembles and activates, Blue Star  crystal activates
  EARTH ACCRETION LEVEL : 2 to 3)  HUMAN ACCRETION LEVEL : 3 to 4
  (Earth accretion level presently 2.5, Human average presently 3 to 3.5 accretion)                                _________________________________________________________
      2   D-5 PLEIADIAN ACTIV ATION : D-5 Pleiadian-Alcyone Spiral aligns with D-4 Solar Spiral & Earth
           DATE:  6/2004 - 6/2008 EARTH ACTIVATION
         EARTH VORTEX OPENS:  V ortex # 5 - Machu Picchu, Peru - 6/2004 - 6/2008
         VIOLET WAVE INFUSION : 2006 -2010  D-6 BT and D-7 OT frequencies enter Earth's Core
         DNA : DNA strand # 5 assembles, activates after 5/5/2012, Indigo Star crystal pre-activation
         EARTH ACCRETION LEVEL : 3 to 4 HUMAN ACCRETION LEVEL : 4 to 5
         ( accretion levels 4.5= Bridge Zone 5 = Tara, Indigo Star activates after 5/5/2012)                                _________________________________________________________
                           3  D-6 SIRIAN ACTIV ATION : D-6 Sirian Spiral aligns with D-5 Pleiadian-Alcyone Spiral. etc
           DATE:  6/2008 - 1/2012 TARAN ACTIVATION
       EARTH VORTEX OPENS : V ortex # 6 - Caucasus Mountains, USSR - 6/2008 - 1/2012
       GOLD WAVE INFUSION : 2010 -2014  D-7 BT & D-8 OT frequencies enter Earth's Core
       DNA:  strand # 6 assembles, Gold Star & Indigo Star  crystals activate 5/5/2012-2017
       EARTH ACCRETION LEVEL  : 4 to 5  HUMAN ACCRETION LEVEL : 5 to 6
           (grids of Earth & Tara begin to merge and Ascensions to Tara begin 5/5/2012)                                _________________________________________________________
      4  D-7 ARCTURIAN ACTIV ATION:  D-7 Arcturian Spiral aligns with D-6 Sirian Spiral etc via Holographic Beam
           DATE : 5/5/2017 - 6/30/2017 day 1 -2017 TARAN ACTIVATI ON
        EARTH VORTEX OPENS:  V ortex # 7 - Andes Mountains, South America - 1/2012 - 6/2017
         SILVER WAVE INFUSION:  day 1 -2017  D-8 BT & D-9 OT frequencies enter Earth's Core
    DNA:  strand # 7 assembles strands 5, 6 & 7 activate, Silver Sta r crystal activates for 3 days
    EARTH ACCRETION LEVEL : 5 to 6 HUMAN ACCRETION LEVEL : 6 to 7
    (Earth, Tara and Gala align with Holographic Beam Ascensions to Gaia)                              _________________________________________________________
    5    D-8 ORION ACTIV ATION : D-8 Orion Spiral,. M .G. Core align with D-7 Arcturian Spiral, etc via Holographic Beam
 DATE : 5/5/2017 -6/30/2017  day 2  -2017 GAIAN ACTIVATION
 EARTH VORTEX OPENS:  Portals between Earth, Tara, Gaia and D-8 Meta-Galactic Core open.
 BLUE-BLACK LIQUID LIGHT WAVE INFUSION : day 2 -2017  D-9 BT & D-10 OT enter Earth's Core
 DNA:  strand # 8 assembles & activates, EARTH CORE Blue-Black Star  crystal activates for 24 -48 hours
 EARTH ACCRETION LEVEL : 6 to 7  HUMAN ACCRETION LEVEL : 7 to 8
 (Ascensions to Meta-galactic Core)                                                                                                                                                                      _________________________________________________________      
                           6  D-9 ANDROMEDA ACTIV ATION : D-9 Andromeda Spiral align with D-8 Orion Spiral. etc
   DATE : 5/5/2017 - 6/30/2017 day 3 -2017 GAIAN ACTIVATION
   EARTH VORTEX OPENS:  Portals open between morph dimensions 9-15, D-8 M G Core and Earth-Tara-Gaia
   SILVER-BLACK LIQUID LIGHT WAVE INFUSION : day 3-2017 D-10 BT& D-11 OT enter Earth s Core
   DNA : strand # 9 assembles. Silver-Black Star  crystal activates for 12 -24 hours
   EARTH ACCRETION LEVEL : 7 to 8 HUMAN ACCRETION LEVEL : 8 to 9
   ( Phantom Earth and Bridge Zone separation. Ascensions to D-9 +)
                                         _____________________________________________________________________________
      DNA strands will ac tivate only if the strands below have been fully assembled and activated .
       2017: 3-day particle conversion period, Earths particles and populations separate into different time tracks
        2022 Mass Ascension cycle ends.  BT or OT = base tone or over tone frequencies
                                                       ©2002 Ashayana Deane
490 
                                                                                   
                    

                                                
                                                                             Appendix IV
                                                                                                                                
                                                                 
                                                              
                                                                   
                                                            Field Techniques                         
     FIELD TECHNIQUE 1: EXERCISE TO RELEASE CRYSTALLIZED
                        THOUGHT PATTERNS FROM THE DNA
                           AND CELLULAR MEMORY IMPRINT
• By moving the focus of your conscious attention into a slower-moving pul-
     sation pattern, you will be able to release the thought patterns stored with-
     in your cells. When you relax your mental focus and slow your heart and
     breathing rates, your consciousness expands and begins to pulsate faster,
     while the pulsation rhythm of your body’s particles slows. From this
     quickened state of consciousness, you can then consciously shift the par-
     ticle-pulsation speed of your awareness into very slow pulsation rhythms.
• First, you will visualize moving your consciousness through a dark tunnel, with a
bright light at its end (the same effect as in a Near Death Experience, which
occurs for the following reason). Moving into the light represents the
quickening of the particle pulsation rhythm of your consciousness, for
which you are aiming in this exercise. You perceive the “dark tunnel” as
your consciousness moves from its D-4 pulsation rhythm, through  the 90°
shift in angular rotation of particle spin that exists between the D-4 and
D-5 frequency bands, and into the faster pulsation rhythms of D-5 fre-
quency. The “light at the end of the tunnel” represents the collective re-
ality fields of the D-5 frequency bands, (and the D-5 consciousn ess
contained there within), as viewed in condensed form, by consciousness
stationed in lower dimensions. One moves closer to the light as the par-
ticle pulsation rhythm of the consciousness accelerates to the rhythm of
the D-5 frequency bands. The light will appear to take on spherical form,
like a blazing sun, as the consciousness nears the D-5 pulsation rhythm.
One merges with the light when the consciousness has reached D-5 pul-
sation rhythm. This is the process you will encounter after death, but it
can be used consciously while you are still in body, for many different pur-
poses. When you perceive the light you are seeing the fifth dimension.
• Once visualizing yourself in the light, submerge yourself within it and feel that light
         move through every cell in your body, imagine it moving through your DNA.
      This raises the pulsation rhythm of the body’s particles by infusing them
493 
                                                                                                                                                                                                                                           
                                     


    Field Techniques
within the D-5 frequency patterns carried by your accelerated conscious-
ness, bringing what is stored within the cells closer to the range of your
conscious perception. When you view your body from this D-5 state of
consciousness, you will notice areas of the body that appear quite light
filled, and others that appear dark. The dark areas represent parts of the
body in which slower-pulsating particles are stored, the dark areas are the
karmic imprints you seek to release.
•  Next, move your attention into one of the dark areas as fully as possible, feel its
sensations and become aware of the pulsation rhythm of the energy in that inter-
nal space. It will have a distinct feel of rhythm that you can detect if you
move your attention into i t.
• Become aware of the difference between the pulsation rate of your con-
sciousness and that of the dark area, then  consciously slow the pulsation rate
of your consciousness to match that of the dark area. Feel yourself moving
down into the blackness of the dark space, slowing the rhythm of your
consciousness, spreading out, and becoming one with the area. As you
proceed to move your consciousness into the area, you will feel a distinct
sensation of the stopping of expansion. This occurs when your conscious-
ness has fully expanded itself into the morphogenetic field of t hat dark
area thought-form. You have become one with the thought pattern, you
are the pattern. You do not have to identify the contents of the thought
pattern in order to release it, though you may begin to receive ideas, im-
ages or emotional qualities from the thought-form as you proceed through
this exercise. Let the impressions pass by your attention, and keep focused
on the exercise. In merging your awareness with the dark thought-form,
you have moved the station of your consciousness from the D-4 level,
through the D-5 level and down into the frequency bands in which that
thought-form originated. You have entered its source of creation and
merged your identity with that of the identity who created the pattern.
You have become the creator of the thought pattern. Being its creator, you
can now change it.¹
• Once you have become one with the crystallized thought-form, sense the
    shape and boundaries of its energy structure. It will have a form and struc-
    ture of energy that you can “feel out” with your consciousness.
• Feel your awareness expand into every layer of the energy form, as if you are fill-
    ing a balloon with water or a box with sand, until you can feel your con-
    sciousness take up every inch of area within the structure of the thought-
    form. Once you feel completely expanded into the thought-form, begin
    to recreate it.
    ___________________________________
1.      Note : Having the ability to consciously shift your entire awareness into the D-5 level is                  
         an attribute of complete fifth DNA strand assembly and activation, which most humans
         do not yet possess. When you use your present imagination to create the inner experience
         of this merger, you actually accelerate the assembly of strands four and five and rapidly
         increase your accretion level. The more you practice such exercises, the more your aware-
         ness will be able to access the D-5 pulsation rhythm, which will make the D-5 merger pro-                                                                                                                                                        
                    gressively more tangible and “real” in terms of physical perception and embodiment of D-
         5 frequency. Any exercises that mentally “take you into the light" will do this for you.           
494

     Field Technique 1: Exercise to Release Crystallized Thought Patterns
• Call light to yourself. Imagine that you can see light streaming in from a beam
       above you, as if there was a sun positioned above your consciousness.
• Breathe light from that sun, into your consciousness and feel it make the pulsation
rhythm of the thought-form and your consciousness move faster. See the dark
area that is presently “you” become more and more light filled. Begin to
hear the sound pitch of the energy in the thought-form and hear its fre-
quency raise, as more and more light enters the thought-form. Allow the
sound and sensation of expanding light to fill your entire consc iousness,
and continue to draw light in, until you sense a distinct stop to the sensa-
tion of light expanding. The thought-form has now reached its maximum
holding capacity for UHF energy.
• Now, imagine that the sun above you is moving down, into your consciousness
 and the thought-form. When the sun enters the thought-form, the thought-
form explodes and the crystalline energy substance, of which its morpho-
genetic field was made, literally blows apart. The thought-form no longer
exists as a reality within your body or consciousness, its particles of energy
substance have been released. The energetic reality of this process is that
of using inner light (visualizations) to guide UHF sound patterns into a
thought-form morphogenetic field. The UHF sound patterns literally
shatter the energy structure of the thought-form, breaking apart the crys-
tallization of slower-pulsating energy particles, just as certain tones of
sound can cause a glass to shatter in the physical world. Through engaging
in this process, you are literally merging the slower-pulsating crystallized
particles with their anti-particles, through the thought-form of the sun
that you created during the visualization. That “sun” image translates
through your body consciousness as D-5 through D-8 frequency, the fre-
quency bands of transmutation through which particle and anti-particle
merge. When you merge multidimensional particles and anti-particles you
create photons. Through this exercise you have created a burst of photo-
nic energy within the frequency bands in which the thought-form crystal-
lization had been.
• To conclude this exercise , focus upon the image of the sun causing the thought-
 form to explode. Imagine that you can feel this explosion within your body as a
 sudden burst of energy that runs through your cells from the area in the body
 where the dark area had been. Visualize this occurring, and see that the dark area
 is now ﬁlled with radiating light. You may not have to imagine the sensation
 of energy rushing through you at all, for this is the energetic reality of what
 is taking place. The degree to which you can sense this energy release will
   depend upon how sensitized your neurological structure is to higher fre-
    quency energy. This sensitivity will increase the more you engage your
  consciousness in activities such as this exercise. Exercises like this activate
 dormant DNA codes, which program the body to build new neuro-pas-
 sageways and nerve endings. This increases the body’s ability to sense sub-  
   tle energy and expands the perceptual range of consciousness while it is                                        
 focused in the body.  
 
  • As you visualize photonic light running through your body , consciously guide
       that light directly into the DNA, while holding the intention that the body will
       use this energy to accelerate the DNA-building process, under the direction of    
495
                                                                                                                                 
                                                                                                                 

                                                                                                                      
Field Techniques
the soul matrix identity. Visualize minute photonic particles moving into and ad-
hering to your double helix DNA strands, until you perceive all of the light par-
ticles that were released, as merging with your DNA.
• Complete the exercise  by visualizing your consciousness returning into the bright
 light sun, then move your awareness backward through the dark tunnel until it
 is focused in your present moment station of consciousness.
                    FIELD TECHNIQUE 2: THE MAHARIC SEAL
• The teachings of the Guardian Alliance are vested in the Law of One; the
interconnection, and Interdependence , of all dimensions of “reality”...
and the Living God, or Spirit, alive within all things.
• All Guardian Alliance teachings are “state of the art,” and specifically ac-
knowledge the scientific/ energetic foundations of “Oneness,” together
with clear emphasis on the unification of science with Spirit, t he “Chris-
tos Within,” and the absolute association with Esoteric Metaphysical Or-
der.
• The practical purpose of these teachings is to truly free and empower all,
through expanded consciousness and educated enlightenment, through
which reverence, respect, love and co-operative co-creation are fostered
within the Global Community. These perspectives fully embrace geo-
physical planetary healing as an intrinsic consequence of personal align-
ment and expansion.
• The personal-planetary technique given here is a key-stone tool of such im-
portance that it is made freely available to everyone. Like all Temple tech-
niques and tools, the Maharic Seal is grounded firmly in Univers al
Unified Field physics, ancient Merkaba Mechanics and Matter Template
Science (a.k.a. the “Divine Blueprint”).
•These techniques are known as “ Bio-Regenesis Technologies"  which were once
 common knowledge, taught in the Pre-Ancient Mystery Schools of ad-
 vanced human cultures; these were regarded as standard, as well as essen-
 tial, daily practice.
• The Maharic Seal , like all Bio-Regenesis Technologies , implies application of
speciﬁc conscious energy, directed to, and within, the core manifestation
template of the body. This technique directly activates the specific math-
ematical -geometrical relationship within, and between, the  Angelic Hu-
man and the planetary, organic, evolutionary blueprint utilizing the
hydroplasmic frequencies of the 10th, 11th and l2th Dimensional “ Maha-
ra Current .” The Maharic Current was fully re-anchored on this planet for
the first time in about 210,000 years, at the GRU-AL point, Sarasota, FL,
Signet 2 point of the Planetary Templar Grid, on May 5, 2000.
• The Maharic Seal  is a major tool by which the purpose, intention, awareness
   and effect of the Angelic Human  can be significantly accelerated in a gen-
   uine, substantial and high impact fashion.
496

                           
                          Field Techniques
                                    
                             Regular use o f the Maharic Seal will:
• Begin the process of activating the 8th through 12th chakras of the personal
     Kathara Grid;
• Assist the opening of Crystal Seals in the body (which otherwise block
    DNA activation);
• Open the Planetary Bio/Feed Interface within the personal body, enabling
  the body vehicle to become a truly effective tool for lasting, planetary  grid
  and sacred site work;
• Trigger DNA activations which progressively and automatically activate
       the full Merkaba;
• Enable healers to transmit 12D frequency sub-harmonics, providing more
       powerful, longer lasting (often permanent) healing facilitation -free of
       personal and client energetic field distortions;
• Protect users from “disharmonic” energies associated with “channeling,”
       healing, Astral projection, and other means of personal field infiltration;
• Assist Indigo Type III children anchor the higher frequencies which cause
       fractious behavior (administered via parent);
• Amplify the results of spiritually focused activity;
• Harmonize personal & environmental energies;
• Create Morphogenetic Re-patterning , clearing karmic / miasmic imprints                           
   which otherwise block DNA activation (and the attainment of true con-
     sciousness expansion and full embodiment of the "Christos Principle'');
• Realign, revitalize and regenerate all aspects of the physical and subtle body
      systems;
• Trigger activation of 11th and 12th sub-harmonics in every DNA strand
 which assists correction of code reversal and the effects of interaction with
 other code mutated partners;
• Prepare and equip practitioners to receive and hold the increas ing ﬂow of
 higher frequency energies ﬂowing into the Planetary Grids and personal
 morphogenetic fields arising from the intensifying Stellar Activation Cy-
 cle now underway (2000-20l7).
498

                                                        
                                                                          The Personal and Planetary Maharic Shields Chart                                                                                                                
Temporary Maharic Seal Technique Steps
   Short Version of the Maharic Seal™ Bio-field Clearing, Alignment and Pro-
      tection Technique from the Kathara Bio-Spiritual Healing System ™
      Program . For temporary restoration and maintenance of personal Bio-
      Field Integrity and Physical Revitalization.
                                                                                                                                                      
  Prior to use: Read through  the steps and practice the visualizations and their se-
      quence slowly,  for familiarity.
1. Imagine the two-dimensional image of a “Merkaba Star” or six-pointed
        “Star of David,” in the color of Pale Silver, as if the image is drawn on a
  black background on the inside of your forehead. This image represents a
  composite scalar wave pattern Keylontic Symbol Code called the “Hi-
  erophant.” Its color denotes the frequency spectra of the 11th and 12th
  Dimensions, and its form, combined with these color frequencies, repre-
  sents the control code of the l2th dimensional frequency band. It is the
  Key Code to unlock the 12th Dimensional Maharic Shield in the personal
  and planetary scalar grids.
2. Inhale , while visualizing the Hierophant Symbol at the center of the brain,
       in the Pineal Gland.
3. Exhale, while using the exhale breath to firmly move the Hierophant down
        the Central Vertical Body Current (energy current in the center of the
        body), then out between the legs and straight down into the Earth’s core
        (your 13th Chakra).
4. Inhale, while imagining that you can see at Earth’s core a huge, Disc-shaped
         Crystalline Platform of Pale Silver Light that extends outward on a hori-
zontal plane through the entire body of the Earth and out into the atmo-
sphere. Visualize the Hierophant suspended in the center of the disc (this
image represents the Planetary Maharic Shield, the scalar wave grid com-
posed of dimension 10/11/12 frequency, with the Hierophant Key Code
positioned to activate the Planetary Shield.)
5. Exhale,  while pushing your breath outward into the Earth’s Maharic Shield,
          imagining as you exhale that the force of the breath has made the Earth’s
          Maharic Shield begin to spin.
6. Inhale,  using the inhale breath to draw Pale Silver Light from Earth’s spin-
        ning Maharic Shield into the Hierophant positioned at the center of the
        Planetary Shield.
7. Exhale,  using the exhale breath to push the Pale Silver Light throughout the
        entire Hierophant making the Hierophant glow and pulsate with Pale Sil-
        ver Light.
8. Inhale, imagine that the glowing Pale Silver Hierophant momentarily ﬂash-
        es Crimson Red and returns to Pale Silver. Then use the inhale breath to
       draw the Hierophant vertically up from its position at Earth’s core, to a po-
       sition 12" below your feet (the position of your dormant personal Maharic
       Shield scalar-wave grid). As you inhale the Hierophant upward from
       Earth’s core, imagine that it trails a thick cord of Pale Silver Light behind
       it. Qne end of the Silver Cord remains attached to Earth’s core, the other
       attached to the Hierophant (the Cord represents an “Energy Feed Line”  
     499                                                                                                      
                                                                                                 
  
                                                                                                                        

  
Field Techniques
      through which you will draw energy up from the Earth’s Maharic Shield
      into your personal Maharic Shield)
9.   Exhale,  with your attention on the Hierophant positioned 12" below your
      feet and use the exhale breath to push a burst of Pale Silver Light outward
on a horizontal plane from the Hierophant. Imagine that a Disc-shaped,
Crystalline Platform of Pale Silver Light about 4' in diameter, extends on
 a horizontal plane 12" beneath your feet around the Hierophant at its cen-
 ter. (This image represents your personal Maharic Shield.)
10. Inhale,  while using the inhale breath to draw more Pale Silver Light up
   through the Pale Silver Cord from Earth’s Core, into the Hierophant at
   the center of your personal Maharic Shield.
     
11.  Exhale,  using the exhale breath to push the Pale Silver Light from the Hi-
          erophant, out into your Maharic Shield. Imagine that your Maharic
          Shield now pulsates, as it fills with the Pale Silver Light from Earth’s Core.
12.  Inhale,  again drawing more Pale Silver Light up from Earth’s Core through
      the Pale Silver Cord into the Hierophant, and imagine the Pale Silver
      Cord expanding to four feet in width, forming a Pillar of Silver Light run-
      ning up from Earth’s Core directly into your four-foot-diameter Maharic
      Shield.
  13.  Exhale,  again using the exhale breath to push Pale Silver Light from the
        Hierophant outward into your Maharic Shield, while imagining that your
     Maharic Shield “takes on a life of its own,” the disc suddenly “folding
     upward ” with a “ popping ” sensation, to form a 4' diameter pillar of Pale
     Silver Light all around and running through your body.2
 14.  Inhale,  imagining that the inhale breath draws the Pale Silver Light from
      the Pillar encasing the body into every body cell. Sense the tingling feel-
      ing as the Pale Silver Light moves through the physical body.
 15.  Exhale, imagining that you can feel the energy of the Pale Silver Light ex-
       panding into every cell of the body and then outward around the body
       into the Bio-field.
   16.  Breathe naturally for a minute or two, as the feeling of the Pale Silver Light
      moves through you, while sensing the energy presence of the Maharic Seal
      Pale Silver Pillar 4' around your body. The more time you spend breathing
      and sensing the energies, the more dimension 10/11/12 frequency you are
      drawing into your Pillar, which will increase the length of time the Maha-
      ric Seal Pillar will remain in your Bio-field.
 17.  Return your attention to the Hierophant still positioned 12" below your
        feet.
18.  Inhale , using the inhale breath to draw the Hierophant up through your
       Central Vertical Body Current, then out the top of your head (the 7th
       “Crown” Chakra), to a point about 36" above the head (the 14th Chakra).
_______________________
 2.    This is your Maharic  seal, a temporary scalar-wave pillar of dimension 10/11/12 frequency
         light that blocks out disharmonic frequencies from dimensions 1 through 12 and begins to
         realign disharmonic frequencies in your body and bio-fi eld to their original perfect natural
         order.
500
                        
                

                                                             The Personal and Planetary Maharic Shields Chart
19.   Exhale for cefully , using the exhale breath to rapidly expand the Hi-
     erophant outward on a horizontal plane at the 14th Chakra, until the Hi-
     erophant suddenly “disappears” from view, with a mild “popping”
     sensation.
20.  Breathe normally, while visualizing for a moment a brilliant 4' Pale Silver
     Pillar of Light extending from the Earth’s Core upward, fully encasing
     your body and extending far above the head, into Earth’s atmosphere and
     to a single Star of Pale Blue Light far off in deep space. Your Maharic
     Shield is now temporarily activated, and your Maharic Seal Pillar is tem-
     porarily manifest within your Bio-Field. The Maharic Seal will remain in
     your Bio-field anywhere from 20 minutes to 1 hour at first. The more this
     exercise is practiced, the longer the Pillar will remain.
21.   For quick reinforcement of the Maharic Seal, once the full process has
     been run within 24 hours: Simply imagine a spark of Pale Silver Light at
     the Pineal Gland, exhale it rapidly down to Earth’s Core and imagine the
     Earth’s Maharic Shield spinning. Call to mind the Pale Silver Cord and
     inhale the 4' diameter Cord all the way up around you, forming the Pillar,
     attaching it “out in deep space” to the Star of Pale Blue Light.
• The Short Version of this technique provides a “manually created” tempo-
     rary Maharic Seal in your Bio-Field, and requires manual resetting every
     24 hours, with frequent reinforcement during the day. Using and practic-
     ing the full version of this technique, as described in the Kathara Bio-Spir-
     itual Healing SystemTM Level-l  Maharic Recoding Process TM, will
     progressively program the Cellular Memory of the body to hold the Ma-
     haric Seal for prolonged periods of time. With consistent practice of the
     full technique, over an extended period of time, the Maharic Seal will
     function automatically as a permanent fixture within your B io-field.
• In the meantime, the Short Version of this technique, coupled with rein-
     forcement throughout the day, will provide Bio-field protection and gen-
     tle, regenerative Core Template realignmen t for all aspects of the
     physical and Subtle-Energy-Body- systems. It is recommended to use at
     least this Short Version of the Maharic Seal technique prior to ANY en-
     ergy work, “channeling,” or Astral and Dream Projection. It will not only
     provide protection from disharmonic energies; it will also amplify the re-
     sults you desire to gain from these activities.
501 
                                                                                                            

                         
                         Field Techniques
                 FIELD TECHNIQUE 3: THE MAHARIC QUICK SEAL
1.  Work with a 24 pointed, 3 Dimensional Star (Hierophant) and be aware
       that you will be working with beings known as the Breneau Rishi.
2.  Begin by slowing your breathing, as you imagine or visualize a 24 point, 3-
       Dimensional, Hierophant at the Pineal Gland in the center of your brain.
       Visualize the Hierophant surrounded by a Pale Blue Sphere of Light.
(The Blue Sphere serves as a buffer for your readiness to accept the frequencies
       associated with using the 24 pointed Star; the Blue Sphere holds the en-
       ergy for you until your body can handle the energy. If you can handle it,
       the energy will simply pass through the blue sphere).
3. Inhale,  as if you are going to grab the Blue Sphere containing the 24 point
       star located at the Pineal, and on the Exhale move the 24 point star/ Blue
       Sphere, all the way down to Earth’s Core. Try to hear a sound tone as the
       Hierophant/ Sphere hits the Planetary Shields.
4. Inhale  and draw the Hierophant/ sphere up to your Personal Maharic Shield
       12" below your feet. . .and Exhale  while watching the Pale Silver-Blue
       sphere expand out to a large sphere. . .and watch as your Maharic Shield
       pops out as a disc, about 4' in diameter, Pale Silver with a light coating of
       Pale Blue.
5. Bring your attention to the center of your Maharic Shield 12" below your
       feet. . .and Inhale the 24 point Star (only) up into the Heart Chakra. Ex-
       hale , expanding the frequencies of the 24 point Star into the Heart
       Chakra.
6. Inhale  to grab the 24 point Star, and exhale , pushing the Star up into the
       14th Chakra 36" above the head. Imagine that the 24 point Star is spin-
       ning in a clockwise direction in the 14th Chakra. As you do this, try to
       feel/sense the energy around you, just a few inches out from your body.
7. Now, put your attention into your Maharic Shield 12" below your feet, take
       a couple of relaxing breaths and inhale deeply pulling the Pale Silver and
       Blue energy up, as if you are pulling on your Maharic Seal to latch it on to
       your 14th Chakra. Try and feel the sensations just a few inches from your
       body now-feel the difference if you can. This procedure gives you a Quick
       Seal.
8. Now envision the cord of Pale Silver Maharic Light that would normally
       come up with your Shield and focus on the Earth’s Core. Begin drawing
       energy all the way up the 4” diameter cord and into the body.  Inhale  the
       energy up into the Heart Center, and expand it there. Begin to form a Pale
       Silver ball of Maharic frequency.
On each exhale  send your energy down to the Earth’s Core to bring up another
       load of Maharic frequency, up from the Planetary Shields, expand it into
       the Heart center and repeat several times. Notice that the Cord grows
       larger as you do this, expanding from approximately 4" to 6 to 8" diameter,
       until finally it feels like a skin around (as well as wit hin) your body. . .as
       you load your Astral field with Maharic Frequency.    
502                            
                          
                                         

   
                                                                              
                                                                                     Field Technique 4: The Maharata
9. Move your attention to the Pale Silver ball you have created in your Heart
Center,  inhale  and move it up to the 14th Chakra 36" above your head. . .as
you do, feel for the sheath of Maharic Frequency encasing your etheric
body, close to your skin. ɜ
                     
                               FIELD TECHNIQUE 4: THE MAHARATA
                                  Anchoring the Planetary Christos Field
                           The Group Maharic Seal - Building the Um Shaddai Ur
                                    “Pillar of First Cause/ Eckatic Light”
1. One Breath + three
       Breath 1—Visualize Hierophant Symbol Code  at the Pineal Gland.  Inhale,
             then exhale forcefully , moving the Symbol Code down the Central
           Body Current  and into Earth’s core
    Three  breaths —Take 3 full breaths, and on each exhale  push firmly into
               the Symbol Code at the Earth’s core, making the Symbol Code spin,
               and visualize each breath expanding into a huge spinning DISC of
               Pale Silver Light , in the center of the Earth; the disc spins, moving
               faster with each breath.4
2. One Breath—On the next  inhale , draw the spinning Symbol Code up to 12"
        below the feet , visualizing a 4' diameter tube  of Pale Silver Light trailing
        from Earth’s core... following the Symbol Code. Exhale , and push the
        spinning disc of Pale Silver Light  outward, 12" beneath the feet.  This is your
        personal Maharic Shield.
       
       Three breaths —Take 3 breaths, and on each exhale , push the breath out-
             ward into the disc making the disc spin faster.
3. One Breath + three  
      
      Breath l— On the inhale,  draw a large amount of Pale Silver Energy up
     through the tube- from the Earth’s core, and exhale  this energy into the
     Maharic Shield  DISC , 12" beneath your feet. Visualize the disc “pop-
     ping ” into a Vertical Pillar of Pale Silver Light  - completely surrounding,
     and penetrating,  your body; while connecting with the Silver  tube,  to   
     form a large tube/pillar  of Light  extending from the Earth’s core. . .up
     into the Earth’s atmosphere to a pale blue speck of Light at the center
     of the sun; aligns with the Eckatic Level of the Energy Matrix. Visu-
     alize your body as being sealed within  the Silver Pillar - this is your Per-
     sonal Maharic Seal.
        
       Three breaths—Take 3 breaths; on the  inhale  draw energy up from Earth’s
                 core to the 4th Heart Chakra.  On the exhale,  push the breath from the
                 Heart Chakr a into the tube of Pale Silver Light around you; each
                 Breath making the Pillar appear brighter and stronger.___________________________________________________________
3.       This Maharic/ Christos skin charges and saturates your etheric body. Try to feel the peace-
          fulness and all-knowing nature of this frequency.
4.       This is the Earth’s Maharic Shield—the Shield of Aramatena.
503

  Field Techniques
3. One breath —Take a slow, full, inhale  drawing a thick current of energy up
from Earth’s core to the Heart Chakra . Then, exhale sharply, directing the
breath energy to a point at the center of the group circle.5 As you exhale , vi-
sualize your Pillar replicating . One Pillar remains around you,6 and another
replica  expands outward around the entire group. Visualize a large Silver
disc growing  out from the group center point , 12 ” beneath the surface you are
standing on , forming a platform upon  which the group stands. This is the
group Maharic Shield, through  which the Um Shaddai Ur Pillar will electro
  magnetically ground into Earth’s Maharic Shield.
  4. Three breaths : Take three final breaths, and with each one, inhale and visu
          alize a stream of Pale Silver energy coming up through the feet from
          earth’s core and simultaneously down from the Sun through the top of the
          head. . .the two streams of energy meeting to form one thick Silver stream
         at the Heart Chakra. Exhale  Maharic frequency into the group center
         point.
    After the third energizing breath, simply breathe normally, as each exhale
moves energy into the group center point. Stand with the group for a
few moments and visualize the Um Shaddai Ur Pillar of Light emanat
ing from the Sun, through the group Pillar and group Maharic
Shield. . .and into the Earth core Maharic Shield
___________________________
5.      Or into focus object , if one is used.
6.      This is your Personal Field Seal.
504

                                                                                                                                                                     
 2001 Update Summary Charts
                         
           Crisis Intervention Expedited Amenti Opening Schedule 2000-2012
                                            Summary Chart (3 Pages)
Abbreviations Key: SAC = Stellar Activations Cycle. GA= Guardian Alliance. UlR= United lntruder Resistance. NDC-Grid=  Nibiruian Diodic 
Crystal Grid. NCT-Bases = Nibiruian Crystal Temple Bases. PSC Seals = Planetary Star Crystal Seals.
J-Seals = 7 unnatural Planetary Jehovian Seal implants. J-DNA Seals  = 7 unnatural Jehovian implants that manifest in the DNA with J-Seal 
release. APlN = Atlantian Pylon Implant Network global ''microchip'' grid. LPlN= Lemurian Pylon Implant Network global ''microchip'' grid. RRT=
''Rainbow Roundtable'' Masters Planetary Templar Merkaba Mechanics.
1992 November : Anunnaki reluctantly enter Pleiadian-Sirian Agreements, give up OWO agenda fearing Drakonian
OWO defeat, enter Emerald Covenant, promise to assist Founders Christos Realignment Mission; Founders
postpone Christos Realignment date from 2012 to end of continuum cycle 4230AD to give Anunnaki races time for
DNA Bio-Regenesis.
2000 January 1 : FL Shields Clinics,  Transcendence Day successful, Stellar Bridge Grounds 12-Code. Anunnaki
negate 1992 Emerald Covenant Pleiadian-Sirian Agreements for OW0 agenda.
2000 March:  Egypt Shields Clinic , D-8 Seal of Orion Templar Security Seal released.
2000 May 5:  FL Shields Clinic,  Solar Spiral Alignment, Earth enters Solar Activation, Planetary Templar begins 12-
Code activation.
2000 July 5:  Anunnaki reluctantly reenter GA Pleiadian-Sirian Agreements/ Treaty of Altair  fearing Drakonian or
Emerald Covenant victory.
2000 August : Macchu Picchu Peru Shields Clinic  Anunnaki reluctantly begin agreed Solar SG-4 transfer to
Eieyani-GA.
2000 September 12:  Anunnaki break Treaty of Altair, join United Intruder Resistance (UIR)  OW0 War Edict with
Necromiton-Andromies/Drakonians, attack indigo Templar Security Team, sabotage agreed NDC-Grid GA transfer
Stonehenge England.
2000 September-2001 April : GA War Crisis Order, revelation of Atlantian Conspiracy Agenda, institute early RRT
plan; return agenda to original ''Christos Realignment Mission'' December 21, 2012. Begin Emergency intervention.
2001 May : RRT Kauai Hawaii  GA Crisis Intervention; SG-6 Sirius B/Halls of Amorea opened. NCT-Base Kauai
realigned. PSC Seals #1/ #2, J-Seals #1 ''White Horseman''/ #2 ‘Red Horseman‘ release, DNA Seals #1/ #2,
J-DNA Seals #1/#2 Initiate.
2001 July:  RRT Ireland  Cue-Site-11 realigned, Star Gate-11 activates, 11:11 clearing starts. RRT England  GA NDC-
Grid Nibiruian Wormwood-Stonehenge link severed, NCT-Bases England, Iran, Pakistan  realigned. PSC Seal #3,
J-Seal #3 “Black Horseman‘ release, DNA Seal #3, J-DNA Seal #3 Initiate.
2001 August:  Mass DNA 12-Code Awakening Initiates (originally 2012 May 5).UlR expedites OWO/Frequency
Fence. Eieyani Reserve Intervention Program initiated ; 720,000 Eieyani Indigos adult Walk-ins  due by
December 2002. PSC Seals # 1/ #2, DNA Seals #1/ #2, J. Seals #1/#2 Consummate/Activate.
2001 September 1 : First Team of indigo Eieyani Reserve Walk-ins to Earth via Halls of Amorea/ Sirius B SG-6
2001 September 3:  GA complete Giza/Alcyone Spiral alignment ( originally 2001 September 17 ). Blue Wave
infusion  D5/D6 activates Earth Core ( originally 2002 June ). RRT Sarasota FL  GA start Trion/Meajhe Field via Bi-
Veca/Tri-Veca Codes. NCT-Bases Sarasota FL, Bermuda  partially realigned, UIR Psycho-tronic attack. PSC Seal
#4 releases, DNA Seal #4 initiates.
2001 September 11 : UIR launches ''Trumpet'' Phantom Pulse; Dove/Phoenix/Serpent APlNs ''on line'' with Falcon
Wormhole. UIR Frequency Fence/ Psycho-tronic Pulse Program transmits. WTC/Pentagon Disaster Trigger Event
OWO WW3 agenda. UIR expedited Frequency Fence begins transmitting September 12, 2001.
2001 October;  UlR ampliﬁes Frequency Fence/ Psychotronics. RRT PA;  GA ampliﬁes Trion/Meajhe Field Level-1
“4 Faces of Man” LPlN  via Khu-Veca Code, blocks United Resistance remote Philadelphia APIN site activation.
2001 October end: GA Level-2 “4 Faces of Man” LPIN , via Dha-Veca Code. PSC Seal # 3, DNA Seal #3, J-Seal/J-
DNA Seal #3 Consummate/Activate.
2001 November:  Blue Wave infusions D5/D6 grid accelerations start; RRT Sarasota FL , GA Level-3 ''4 Faces of
Man'' LPlN Blue Wave activation  via Rha-Veca Code. NCT-Bases Sarasota FL, Bermuda  fully realign.
2001 December:  Alcyone Spiral aligns with Earth, Pleiadian Activation  begins, Vortex/Star Gate-5  Macchu Picchu
starts opening cycle ( originally 2004 June ). Veca Code NYC Trion Field Link indigo Outreach Program.
                                                                                                   ©2002 Ashayana Deane
                                  510
                                                            
             
                                                                                  

                                                                                                         2001 Update Summary Charts
2001 December end : RRT Macchu Picchu Peru , GA anchor Trion/Meajhe Field to Vortice/StarGate-5 , Level-4 "4
Faces of Man" LPIN.  PSC Seal # 4, DNA Seal #4 Consummate/Activate. PSC Seals #5/ #6/ #7, DNA Seals #5/ #6/
#7 Initiate. NCT-Bases Machu Picchu Peru , Portugal  realign.
2002 January:  Blue Wave Infusion complete, Violet Wave Infusion  D6/D7 activates Earth Core (originally 2006
June ). RRTs Lake Titicaca Peru , GA anchor Trion/Meajhe Field to Vortice/StarGate-7 Level-5 "4 Faces of Man ''
LPlN . UlR Trumpet Pulse Falcon-Phoenix Wormhole merger  attempt. NCT-Bases Lake Titicaca Peru, Giza
Egypt, South Pole, Mauritania West Africa realign . PSC Seals #8/ #9, J-Seals #4 ''Pale Horsemen''/#5 release;
DNA Seals #7#8, J-DNA Seals #4/ #5 initiate.
2002 April:  Violet Wave infusions D6/D7 grid accelerations start. RRT Sarasota FL, GA Level-5 "4 Faces of
Man" LPIN Violet Wave activation  amplify Trion/Meajhe Field. PSC Seals # 5/ #6/ #7, DNA Seals #5/ #6! #7
Consummate/Activate early April. PSC Seals #8/ #9, J-Seals #4 ‘Pale Horsemen‘/ #5, DNA Seals #8/ #9 and
J- DNA Seals #4/ #5 Consummate/Activate mid April.
2002 May-June : Sirian Spiral aligns with Earth, Sirian Activatio n begins, Vortex/Star Gate-6 Russia begins
opening cycle (originally 2008 June ). RRTs Paxos Greece, GA Level-7 "4 Faces of Man" LPlN activation,  link
Earth's ''4 Faces of Man'' LPIN to '' Guardians of the 12 Pillars " Trion Field, realign/ activate Cue Sites . NCT-
Bases Paxos Greece, Central Mexico, Cyprus, Easter Island, Rome ltaly, Johannesburg South Africa, Brazil
realign. Inner Earth to Earth portals and Meajhe Zone sites  begin open cycle. Begins Earth to Inner Earth Bridge
Zone and Trans-Harmonic Meajhe Time Cycle  merger.
2002 July:  RRTs Bermuda and Sarasota FL , GA Level-8 "4 Faces of Man" LPIN , amplify Trion/Meajhe Field
''Buffer Blanket'' and begin Falcon/ Phoenix Wormholes / Intruder APlNs CAP  lo stop UIR 2003 invasion.
Expected UIR ''Phantom Pulse" assaults  attempt to prevent Wormhole Capping; potential excessive storm
activity Atlantic Ocean/Gulf of Mexico.
2002 August-September:  Violet Wave Infusion completes, Gold Wave infusion  D7/D8 activates Earth Core
(originally 2010 June). RRTs Tibet and Sarasota FL , GA Level-9 "4 Faces of Man '' LPlN , NCT-Bases Lhasa
Tibet, Xian China, Hamandan Iran  realign. PSC Seals #10/ #11/# 12, J-Seals # 6 ''great quake''/ #7 ''Golden censer-
7Angels-7 Trumpets" release. DNA Seals #10/ #11/ #12, J-DNA Seals #6! #7 initiate J-Seal # 6 possible quakes
Peru/Chile. UIR Jehovian ''Chosen One" Frequency Fence transmission Pineal Block.
2002 November-December:  Earth‘s Vortex /Star Gate-7  begins open cycle ( originally 2012 January).  Gold Wave
infusions start  D7/D8 grid accelerations . RRTs France and Sarasota FL,  GA Level-10 "4 Faces of Man" LPlN ,
SG-12 France begins open cycle, starts D-12 Planetary Maharic Shield  protection. Last NCT-Bases Iraq, Bosnia
realign. Galactic SC Seal #13 release; indigo DNA Seal #13 Initiates. PSC Seals # 10/ #11/ #12, DNA Seals #10/
#11/ #12, J-Seals # 6/ #7 Consummate/Activate. UlR Trapezium Orion/HAARP pulse attempt to destroy SG-12 ;
''Golden Cense '' Revelation . 720,000 Eieyani-indigo Reserve Team  Walk-ins complete by 2002 end.
2003 January : Meajhe Zone sites  fully open, GA advance private contacts, continue amplifying Trion/Meajhe
Field/Bridge Zone link/Planetary Maharic Seal. GA programs  shift to prep of indigo MC Regent Consulate Team for
DNA Activations/ ''Safe Zones"/ early 3-Day Particle Conversion Period . Rebel Omicron-Drakonian Illuminati
escalate external political warfare.
2003 March : Planetary-Galactic SC-Seal #13, indigo DNA Seal #13 Consummate/Activate.
2003 April:  RRTs various, GA Level-11 "4 Faces of Man" LPIN, ''Great White Lion" APIN  start, efforts to balance
grids to lessen storm/ quake/ volcanic potentials, World Peace Efforts .
2003 May-July:  GA amplify Great White Lion APlN, ﬁnal prep for August 2003 Show Down. UlR ''UFO activity''
increase prep for intended late 2003 ''First Contact''; Frequency Fence/ Psycho-tronic attack amplify, ''Un-natural
Disaster'' population reduction. Increased Nuclear War issues  potential involving India. UIR ''Human Greeting
Teams '' contact, ''ET in ﬁltrate'' placed.
                                                             
                                                                                           ©2002 Ashayana Deane
                             511 
                                                                                                                                                                                                          
                                                                                                                                                                                                            
    

2001 Update Summary Charts
2003 August 8-20 : Earth's Merkaba 100-year Magnetic Peak August 12, 2003 . The GA /UIR ''Show Down''
August 8-20. RRTs India and Sarasota FL , GA Level-12  "4 Faces of Man " LPIN,  realigned NDC-Grid/24 NCT-
Bases to phase-lock Earth/ Bridge Zone,  Guardians of the 12 Pillars link to Meajhe Time Cycle via ''Rainbow Ray "
Pillars.  Earth LEVEL-3 D-12 Planetary Maharic Seal,  SG/ Ley Lines #1/#2/ #3 D3 Nethra Phase Merkaba
protection, Level-3 Falcon-Phoenix Wormholes Cap. Universal SC Seals #14 /#15 release. Indigo DNA Seals #14/
#15 Initiate. UIR Dimensional Blend Experiment  attempt to un-Cap‘ Wormholes, merge Earth/Phantom Matrix,
erode Level-3 Maharic Seal before Level-6 ampli ﬁcation. Level-3 Maharic Seal prevents UlR 2003 First Contact
Mother-ship entry, reschedule 2005 for 2008-2011 ﬁnal invasion.
2003 November : Earth/ Tara grids begin merger via Inner Earth Bridge Zone, GA activate Hall of Records  Egypt,
Mass Awakening/DNA 12-Code Activation re-commences alter September 12, 2001 block ( originally 2012 May 5 ).
2003 December : Inner Earth portals full open,  Amenti SG  open begins ( originally 2012 May 5 ). December 21-22,
2003,Earth begins Holographic Beam  entry, Hall of Records begins transmit ( originally 2012 December 21 ). GA
activates '' Golden Eag le'' APIN,  connect to ''Great White Lion''  APIN/ ''4 Faces of Man'' LPIN, disables Necromiton-
Andromies ''White Eagle'' APlN. GA slow Earth core to postpone 3-Day Particle  Conversion Period to 2006.  UlR
intensiﬁes New Age/UFO/ Religious manipulation " ideological war".
2003 December-2006 June:  Earth progresses to LEVEL-6 Planetary Maharic Seal,  SG/ Ley Lines #1-#6 D-6
Hallah Phase Merkaba  protection in preparation for 2006. GA " Emergency Contingency Plan"  Level-12 Maharic
Seal to prevent cataclysm if Particle Conversion Period occurs before 2006. If UlR OWO invasion 2005, GA issue
Level-9 Maharic Seal in areas that can hold D-9 Quatra Phase Merkaba protection.
2006 June:  Earth to LEVEL-9 Planetary Maharic Seal,  SG/ Ley Lines #1-#9 D-9 Quatra Phase Merkaba
protection. GA attempt Quatra Phase Merkaba for entire planet but not likely. Between June-December 2006, 3-Day
Particle Conversion Period  (Re: