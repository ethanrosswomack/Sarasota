Chapter 12). The specific DNA Template
    Fire Letter Sequence program unique  to each of the 12 Tribes seed races
       is referred to as the '' Tribal Shield. '' 
    • The DNA Templates of all contemporary humans originally emerged from
       one of the 12 T ribes,  which were composed of various combinations  of
      the five Palaidia Urtite-Cloister seed races . When we activate the Tribal
        Shield, via our innate Inner Christos Divine Blueprint, through using the
          Master Symbol-Color-T ones  that correspond to our Tribal Shield im-
        print, we progressively realign the Fire Letter Sequences in our DNA
        T emplates to their original, organic Christiac order . Realignment of the
      DNA  T emplate with the innate personal D-12 Christos Blueprint allows
      the 12-Strand DNA  T emplate to realign distortions, so the Strand T em-
       plates can activate in the  specific sequence  for which they were designed.
      Activating our Tribal Shield allows the '' Internal Star Gate '' within our
       DNA  T emplates to open, creating a direct  energetic conduit of frequency ,
       and bridge of conscious awareness,  between our present incarnation  and
     our other simultaneous incarnations that exist now in other space-time
      vectors of the Cycle of  the Rounds . To create the Trans-Time Connec-
      tion through which the Planetary Christos Realignment  can be fulfilled,
       our personal DNA  T emplates must progressively open to allow the fre-
       quencies  from the other related Time Vectors  to enter Earth’ s present
                      Time Vector  
  • The human DNA Template was designed to allow for this Trans-Time Con-
     nection frequency bridge. Through activating the proper sequences  with-
    in our DNA  T emplate Tribal Shield, we progressively allow the proper
   sequences of the Universal D-12 Maharata and Rainbow Ray Current to
    enter our bodies. From our sequentially activated DNA  T emplates, we
       then pass the proper sequences of frequencies  from the Universal Chris-
       tos Blueprint into Earth’ s Planetary Shields, resetting the part of the D-12
      Shield of Aramatena to which our race cycle is assigned, within Earth’s
   Manifestation T emplate. The Angelic Human race was designed to fulfill
   this Divine Commission.  As we assist the planet to become “Christed”
      (embody its full D-12 Christos Blueprint), we in turn progressively return
     to our originally Christed state, as our personal Christos Blueprint  em-
   bodies. Through embodiment of our personal lnner Christos Divine Blue-
         print, we achieve genuine spiritual actualization  and reclaim our
   dormant ability to pass through the 12 Universal Star Gate ''Ascension
   Passage '' at will, in fulfillment of our intended Angelic Human mastery
     of the space-time-matter experience.  
  • When we use the knowledge gained from Element-1: The 12 Tribes and
       Races List , Element-2: The Signet Maps and Keys , with Element-3: Rite
      of the RRT T ribal Shield Activation , we become empowered  Angelic
        Humans  capable of fulfilling the Planetary Christos Realignment Mis-
        sion . As empowered Angelic Humans, we reclaim our heritage, our innate
       divinity , our ability to love unconditionally and wisely , and we reclaim
    308  

                                                                               
                                                                              Tribal Shield Dynamics  
our personal and collective freedom  to have a direct, immediate and per-
sonal co-creative relationship with Source-God. The Tribal Shields Acti-                     
vation teachings show  how  to activate the appropriate frequencies in our
DNA Templates, and where  to direct those frequencies into the Planetary
Shields, to anchor the part of the Universal Christos Blueprint that we
were personally commissioned to deliver when we entered the Angelic
Human incarnational cycle. Activation of the Tribal Shield allows us to
work alone or in groups  to achieve accelerated personal spiritual devel-
opment  and to orchestrate effective, remote planetary restoration  with-
out having to physically visit the locations of Earth’s Star Gates and
Templar Cue Sites. Through Tribal Shield Activation we reclaim the
ability to remotely activate the 12 Signet Shields and Signet Plates,
Earth’s  Star Gates and the Planetary Christos Blueprint.  
309 
                                      

                                                                               
                 
                                                                15
                          
                       
                     The Atlantian Conspiracy and
                                    Roundtables
                                        LONG-TERM PROBLEMS AND IMMEDIATE SOLUTIONS
                                          
                                              Rainbow Roundtables
 • The Sacred Science Mechanics  by which the Planetary Christos Realign-
        ment can be fulfilled have long been hidden within the Legends of King
         Arthur  and the '' Knights of the Roundtable. ''
 • The '' Roundtable '' of Arthurian Legend referred to Signet Councils . The
        word “Signet” refers to '' Star Gates .'' In the ancient knowledge of the
        Palaidia Urtite-Cloister races, the Signet Councils were the specific
          groups of Angelic Humans  that assembled to  run the corrected Fire Let-
        ter Sequences into Earth’s  Planetary Shields  during SACs,  to prevent
        pole shift and progressively restore  Earth’s D-12 Christos Divine Blue-
           print (the Shield of Aramatena).
 • The “Roundtable” of Arthurian Legend referred to the “Rainbow Round-
        table” (RRT) . The RRTs are groups of Angelic Humans assembled in the
         4 Evolutionary Rounds  who are commissioned to run the “Rainbow
        Ray” or “Khundaray” Primal Sound Current  from beyond the 15-Di-
         mensional Time Matrix, into Earth’s Planetary Shields during SACs .
          Running of the Rainbow Ray during SACs enables the planet to retain its
             natural electromagnetic balances to avert pole shift and restores the or-
        ganic D-12 Planetary Christos Alignment.  
  • Since the 9558 BC Atlantian Flood , knowledge of the RRTs  has been in-
       tentionally  hidden  from the Angelic Human races of contemporary Earth,
       by Human Illuminati and Fallen Angelic  races that desire to create pole
       shift during the long-anticipated 2000-2017 SAC.  They hope to use the
       2000-2017 SAC to finally fulfill their plan of clearing Earth’s real estate”
         of Angelic Human races to later resettle their hybrid races on Earth, “after
         the dust settles,” under a “One World Order” Anti-Christiac Agenda of
       totalitarian exploitation and dominion .
310 
 
 
     


                                                                                                                             
                                                                                              The Atlantian Conspiracy
                                  THE ATLANTIAN CONSPIRACY
     • The Fallen Angelic/ Illuminati Human Anti-Christiac Agenda gained a
                stronghold on Earth in 25,500 BC when Nibiruian Marduke-Anunnaki
                ( Anunnaki + Omicron  Drakonian) seized control of Nibiru and Earth’s
                D-4 Universal Solar Star Gate-4 , in an event known as the '' Lucifer Re-
                  bellion. '' 
   •  The name  “Lucifer”  comes from a hybrid Pleiadian-Nibiruian Anunnaki
                     Race that emerged through combining the Density-2 Nibiruian Lulitan
                     family of the Thoth-Enki-Zephelium (Zeta) Anunnaki lineage with the
                     Satain  family of the Marduke-Anunnaki line and the D-11 Necromiton
                    (''Beetle-reptile'') Fallen Seraphim race of Andromeda (most contempo-
                     rary '' Andromie '' channels  are these). From this hybridization the Pleia-
                      dian Samjase-Luciferian Anunnaki and Marduke-Necromiton-
                     Luciferian Anunnaki Races of Sirius B, Nibiru and Alpha and Omega
                     Centauri emerged. This collective of Anunnaki Races promoting an
                     Anti-Christiac dominion agenda became known historically as the '' Lu-
                     c iferians ,'' and were occasionally joined by other Anunnaki and Illumi-
                             nati Human race lines in their “Quest for the Holy Grail.”
  • The '' Holy Grail '' is a term used in reference to the 1 2 Universal Signet
        Star Gates of the Universal Templar Complex,  to which the  Angelic
          Human Race holds the Sacred Commission of “ Guardian .” The “Grail
          Quest” began long before Angelic Humans were seeded on Earth and it
                 has been  the primary theme of motivation  behind all of the Forbidden  and  
               recorded-distorted human history.  
        • The Grail Quest for Earth’s Planetary Templar Star Gates continued into
               Angelic Human 12-Tribes Seeding-3 , following destruction of Seedings-
                1 and 2 via Grail Quest Wars with Anunnaki and Drakonian  Fallen An-
              gelic Legions. During the 25,500 BC Lucifer Rebellion , Anunnaki Lu-
              ciferians gained partial control  over Earth’s Templar through a device
              called the Nibiruian Diodic Crystal (NDC) Grid , which is still in oper-
              ation today  and serves a key role  in the potential outcome of the 2000-
              2017 SAC  
   • In 22,326 BC the Luciferian Anunnaki races decimated guardian races at-
       tempting to intervene in an event known as the Eieyani Massacre, which
         took place on the remnants of the Lemurian Continent  now known as
       Kauai, Hawaii. In 21,900 BC  they collapsed the Firmament Hydro-sus-
         pension Fields of Lohas, northeast Atlantis  in the Lohas-Celtec-Dru-
          idec Freeze Out,  in an attempt to destroy the Maji Angelic Human Grail
          Kings in exile there; this event gave us our last major glacial period of
              21,900 BC-14,000 BC . In 20,000 BC  they staged the Vicherus-Sa-
        cheon Invasion of Russia.  In 10,500 BC  the next phase of the Luciferian
            dominion plan unfolded in an event called the Luciferian Conquest , at
            which time the Atlantian Islands of Nohasa and Bruah  fell to Annu-
           Melchizedek Anunnaki-Human hybrid and Fallen Jehovian and Lucifer-
        ian Anunnaki control.  
  311  
                                                                                                             

                                                                       The Atlantian Conspiracy and Roundtables
  • The Anti-Christiac Agenda of the Luciferian Anunnaki Races (not all
       Anunnaki are in the “Luciferian” category; some run competing dominion
       agendas) was formerly mandated in Bruah Atlantis in 9560 BC  under
       an Agreement called the Luciferian Covenant.  The Luciferian Covenant
         is part of  3 competing One World Order dominion agendas  collectively
       referred to as the Atlantian Conspiracy . The Anunnaki Races of the Lu-
       ciferian Covenant orchestrated the “Atlantian Flood” in 9558 BC  and
         the intentional “re-writing” of human history  since this time. Forbidden
             History reveals a  long-term plot  within which the Anti-Christiac Agen-
         gas of the  Atlantian Conspiracy  emerged after the flood  into the  present
       day.  
   •  The Luciferian Covenant continued after the 9558 BC ﬂood in the  8,900
        BC “Larsa King” Sumerian Invasion, the 8,400 BC “Scarab King”
        Egyptian Invasion , and the 7,500 BC Knights Templar Invasion . The
           infiltration continued with the 5,900 BC Centaurian War, when the
       Sirius B Maharaji  (Blue Human Guardians) intervened directly with air
    raids to prevent Drakonian and Luciferian Forces from claiming world do-
      minion. This event is partially documented  in the ancient Hindu text of
    the Mahabharata.  
    • In 3,650 BC  the Nibiruian Luciferians orchestrated the Mayan Raids , and
          in 3470 BC the “Babble-On” Massacre  was waged, in which Pleiadian-
         Nibiruian  legions, Galactic Federation and the Annu-Melchizedek Hu-
          man Illuminati gained temporary control  over the Maji Grail Kings’ “ Arc
       of the Covenant  Gold Box ,” which contain the “ Rod and the Staff ” star
        gate tools. In conjunction with the Nibiruian-Diodic-Crystal-Grid at
        Stonehenge, England, the Arc Tools  were used in Babylon  to cause tem-
          porary collapse of Earth’s magnetic grids  and to set portions of the Fire
                         Letter Sequences  in Earth’s Planetary Shields into reverse sequence.  
                   • Planetary Shield distortions of the 3470 BC “Babble-On” Massacre  caused
      mutation in the human DNA Template  that shortened human life span ,
      blocked Higher Sensory Perception,  caused loss of  Race Memory and
        ''scrambling '' of our original language patterns,  which are built upon
          DNA Template Fire Letter Sequencing . Our race has been amnesiac,
      dying young and “babbling on”  in rhetorical con ﬂict ever since. This his-
                         torical event was recorded  as the Biblical “Tower of Babel”  story.  
                 
                   • Following the Babble-On Massacre of 3470 BC, Fallen Angelics selected
            “Chosen Ones, ” Annu-Melchizedek hybrid descendants, for minimal
              DNA Template repair and implantation , through which the Luciferians
          and competing Jehovian-Anunnaki and Drakonian legions could begin
             their progressive infiltration  of human spiritual and political systems.
             Through the technology of remote '' channeling '' conducted through un-
         natural DNA Template implantation,  the “Chosen Ones” have been
         progressively fed Anunnaki History and distorted patriarchal ''War
                 God” spiritual teachings, in a strategic and intentional replacement of
               the Angelic Human heritage. They are once again '' channeling '' to us
               and visiting today  as the dominant force  in the New Age and UFO
              Movements.  
        312   
   

                                                                             
                                                                                              
                                                                                                     The Atlantian Conspiracy
                         • “D-12 Maharic Sealed Channels”  can create protection  from interdimen-
             sional manipulation of their natural bio-neurological communication
                lines.  
   •  Following their 2668 BC Djoser Invasion  of Egypt, Galactic Federation
               continued their previous alliance with the Anunnaki of the Luciferian
               Covenant, temporarily stealing the Arc of the Covenant Gold Box and
               Tools in 2024 BC . At this time they launched an attempted world do-
                 minion assault  called the Dead Sea Conquest,  beginning with Babylonia
                  and Sumerian Cities  in the areas of the Dead Sea ; the Biblical stories of
                    the destruction of “ Sodom and Gomorrah ” referred to this event. “God”
                   did NOT destroy these ancient cities any more than “God” orchestrated
                 the scrambling of the languages in the 3470 BC Babble-On Massacre;God
               is NOT a Fallen Angelic-ET.  If Maji Grail King Angelic Human Races
               had not retrieved the Arc of the Covenant Gold Box and Tools in 2024
                    BC, the Jehovian and Luciferian Anunnaki Races of the Galactic Fed-
                  eration  would dominate the world by now.  
    •  Since the time of the staged 9558 BC  Atlantian ﬂood, human history has
                      been a progressive advancement  of the Atlantian Conspiracy and Lu-
                 ciferian Covenant  Anti-Christos Agendas. The stories of Noah, Abra-
                      ham, Moses, the Hyksos Kings and the ''3  Christs '' are key pieces to the
                Atlantian Conspiracy drama. At the center of this drama are the Arc of
                      the Covenant Gold Box,  its star gate tools  and the core objective  of the
                 ancient Fallen Angelic/ Illuminati Human Grail Quest.  
      •  Competing Jehovian-Anunnaki, Luciferian Anunnaki and Omicron , Od-
                                       edicron and Zephelium (Zeta) Drakonian/Reptilian Fallen Angelics  and
              their Annu-Melchizedek Illuminati Human hybrid race descendants¹
                   share one objective-dominion of Earth, in order to claim Earth’s Halls
                   of Amenti Star Gates.  
   •  If the Fallen Angelic races can gain dominion of Earth’s Halls of Amenti
            Star Gates, they intend to use the Amenti Star Gates to destroy Univer-
               sal Star Gate-12 in Density-4.  Destruction of Universal Star Gate-12
                          would effectively seal off from Density-5 Founders Race protection,  11-
            dimensions  of our 15-Dimensional Time Matrix. The manifest life field
             would become “imprisoned in time” for Fallen Angelic exploitation and
            dominion, unable to fulfill the natural evolutionary process of ascension.
           This is the core motivation behind the Fallen Angelics’ continuing Grail
             Quest. Prevention  of this Anti-Christos Agenda is the purpose for which
            the Angelic Human Race  was created 560 million years ago.  
     • To accomplish their objective of claiming Earth and the Amenti Star Gates,
            Fallen Angelics need to possess the Arc of the Covenant Gold Box and
            star gate tools , and to achieve critical mass population  of their hybrid-
               human races, whose DNA Templates  carry reverse sequenced Fire Let-
          ters.  During a Stellar Activations Cycle , the Arc Tools, the still-func-
          tioning Nibiruian-Diodic-Crystal Grid  (from 25,500 BC), Nibiruian
    ______________________________________       
1.     Known as the Leviathan Anti-Christiac : King lines.    
 313                                                      
                                                                                                       

                                                                          
    The Atlantian Conspiracy and Roundtables
  
                 controlled Solar Star Gate-4  and the false-planet Battlestar Nibiru  can
               be used to create intentional pole shift  on Earth to ''clear the real estate.''
     •  If they can successfully exterminate Angelic Human Races from Earth, the
             Luciferian and Jehovian Anunnaki Races intend to return their ''Chosen
              Ones''Annu-Melchizedek descendant humans to Earth during the SAC.
              The “Chosen Ones”  will be used  to run critical mass reversed Fire Let-
              ter Sequences  into Earth’s Planetary Shields  and the Amenti Star Gates
                 in fulfillment of the Anunnaki Anti-Christos Grail Quest Agenda. This
                plan was formalized in the  9560 BC Luciferian Covenant  and has been
                   progressively unfolding . Since 9560 BC the anticipated date  for the Final
              Con ﬂict and intended, orchestrated pole shift  has been the 2000-2017
              SAC.  Now.  
          • Many times throughout the advancement of the Atlantian Conspiracy,
                Guardian Races of the Emerald Covenant have repeatedly intervened.
                  Guardian races have kept the Angelic Human and Maji Grail Line
               DNA Templates  alive within the human gene pool,  so Angelic Humans
                could rise together  during the 2000-2017 BC Final Conflict drama , to
                fulfill the Christos Realignment Mission and prevent further advance-
               ment of the Atlantian Conspiracy.  
    • During the Christ Drama of 12 BC-27  AD the Founders’ Emerald Cove-
                     nant  CDT-Plate teachings  were translated by the 3 Maji Grail Line
                 Speakers,  Jesheua Melchizedek  (aka Jesus Christ), John the Baptist and
                     Miriam, to prepare humanity  for the 2000-2017 Final Conflict.
   • The heart of the 12 BC-27 AD Christ Drama  was not only CDT-Plate
              teachings; Jesheua, John, Miriam and a group of Maji Grail Line Angelic
              Humans were on a Emerald Covenant Grail Quest Mission to secure
                 Earth’s Star Gate-11  from Anunnaki and Drakonian Race infiltration.
                       Both Luciferian and Jehovian Anunnaki Races, and their Annu-
                 Melchizedek Illuminati descendants seek to claim the Arc of the Cove-
                 nant Gold Box and star gate tools to  take control of Earth’s Star Gate-
               11, for use in  imploding Universal Star Gate-12  during the 2000-2017
              BC Stellar Activations Cycle . This plan was known since the success of
                 the 25,500 BC Lucifer Rebellion.  
      • Jesheua and his Universal Templar Security Team intended to use the Arc
              of the Covenant Gold Box star gate tools  (“Rod and Staff”) to release
              Anunnaki Nibiruian Diodic Crystal Grid Crystal  control over Earth’s
                Templar and Solar Star Gate-4. The mission of Jesheua, John, Miriam and
              the Maji was intended to prepare the Angelic Humans of Earth to fulfill
                      the Christos Realignment Mission  during the anticipated 2000-2017
                 SAC . In 23 AD  Jesheua and his Maji were attacked by the Annu-
                Melchizedek Hyksos and Hassa Leviathan King  races, in an event called
              the Essene Divide , which rendered them unable to fully complete  their
              intended journey to the lands previously known as northern Lohas At-
              lantis , the location of Earth’s Star Gate-11.  
        •  To protect the Arc of the Covenant Gold Box and star gate tools, John and   
              Miriam completed part of the journey  to Lohas, burying the Arc of the
                    Covenant Gold Box and tools in the area now known as the Vale of Pew-
           314
     

                                           
                                              King Arthur and the Knights of the Roundtable
      sey, England.  Jesheua and his group of Maji served as a Signet Council , a
        group of Angelic Human Maji commissioned to '' Run the RRT '' prepar-
       ing Earth’s Planetary Shields for the 2000-2017 SAC.  
• The CDT-Plate teachings  of these 3 Essene Emerald Covenant Speakers
           contained the Planetary Templar Mechanics  by which the Planetary
       Christos Realignment could be achieved in the 2000-2017 SAC. These
           teachings were later stolen, edited and falsified int o a Religious Control
            Dogma in 325 AD , by the Council of Nicaea and the Drakonian Infil-
        trated Church of Rome;  the falsified CDT-Plate  teachings of Jesheua,
       John and Miriam were interwoven with Annu-Melchizedek Leviathan
        King Anunnaki history  to create the Canonized Bible.  
• The Mission of Jesheua, John and Miriam later resumed between 559-608
        AD,  when the '' Quest for the Holy Grail '' the Atlantian Conspiracy
       and the hunt for the Arc of the Covenant Gold Box and star gate tools
       continued in the drama of King Arthur and the Knights of the Round-
        table.  
                 KING A RTHUR AND THE KNIGHTS OF THE ROUNDTABLE
•  King Arthurus , or “Arthur” was born from a Druidec Maji Grail King lin-
          eage  originally from Nohasa and later exiled to Lohas Atlantis.  Arthur
         and his selected Signet Council “Knights”  were commissioned to fulfill
       the 10 AD-27 AD Emerald Covenant Mission that Jesheua, John the Bap-
         tist, Miriam and the Essene Maji were unable to complete due to the Hyk-
       sos-Hassa King raids in the 23 AD Essene Divide. Arthur’s legendary
       sword ''Excalibur '' was a battle sword fashioned to hold the Staff star
         gate tool  from the Arc of the Covenant Gold Box,  which Arthur and
           Victorous  (son of Meridan) retrieved from the Vale of Pewsey  in En-
        gland, where John and Miriam had buried it in 23 AD.  
   
• Victorous , son of Meridan , came to be known as “ Merlin ” Arthur’s Vizier
       and court mystic in the Arthur Legends. Victorous’ father Meridan was a
        Knights Templar Annu-Melchizedek  Black Arts Occultist, his mother
        was of a Celtec Maji Grail King line  originally from Lohas Atlantis. Vic-
       torous’ life and service to King Arthur were overshadowed by the struggle
         of “good vs. evil” that existed within his genetic programming.  
• Arthur’s wife  Guinevere  was of a Celtec Maji Grail King  line originally
        from Lohas Atlantis. Guinevere’s sister Saleane , not Guinevere, was the
        lover of Arthur’s imposter Knight “ Sir Lancelot, ’’ a Luciferian Knights
           Templar sent in to sabotage the Emerald Covenant Mission. Knights
       Templar Annu-Melchizedek races intentionally distorted  true Arthurian
        period history. Teachings of the RRTs and Star Gate Signet Councils
         were hidden in occult secret societies of the Knights Templar. The histor-
         ical  realities  of the Maji Grail King lineage and Arthur’s Emerald Cov-
            enant Mission were intentional “ re-written Nibiruian Anunnaki
          style ,” romanticizing Victorous (''Merlin'') and other characters that as-
           sisted the Knights Templar in undermining Arthur’s  Emerald Covenant
          Mission .      
    315                                                                                          
   

                                             The Atlantian Conspiracy and Roundtables
 • Throughout the Arthurian drama (559-608) the Luciferian Knights Tem-
            plar Annu-Melchizedek Illuminati Human  races, under the direction of
           the Galactic Federation  and the Pleiadian-Nibiruian Anunnaki  races,
           quested to steal the Arc of the Covenant Gold Box and “Excalibur
          Sword” Staff  star gate tool from Arthur’s guardianship. Arthur and the
         Signet Council Knights quested to retrieve the Rod star gate tool  and the
         Star Gate-11 control device called '' Signet Shield-11 '' which had been
         stolen from the Essenes by the Hyksos Kings and Knights Templar in the
          23 AD Essene Divide. The ancient “ Quest for the Holy Grail ,” or quest
          for control over the Star Gates of Earth’s Planetary Templar, and the At-
           lantian Conspiracy agendas continued....  
     •  Despite Victorous’ (“Merlin’s”) frequent betrayals of his Emerald Covenant
         agreements, Arthur, Guinevere  and the Knights of the ''Rainbow
           Roundtable '' completed one phase  of their Emerald Covenant Mission.
           They were successful in retrieving the Rod  star gate tool and Signet
           Shield-11  from the Luciferian Knights Templar Annu-Melchizedek Illu-
          minati Humans. Arthur relocated the Arc of the Covenant Gold Box
         with Rod, Staff and Signet Shield-11  to their intended destination at the
            control center for Star Gate-11,  in the lands once called Lohas Atlantis.
            The authentic  Arc of the Covenant Gold Box with its star gate tool con-
         tents, still remains, under Maji Grail King protection, where Arthur bur-
          ied it in 608. 
   •  Arthur and his Knights were unable  to fulfill the entire Emerald Covenant
          Mission of disengaging  the 25,500 BC Nibiruian Diodic Crystal Grid
          network at Stonehenge, England,  to free Solar Star Gate-4  from remote
          Nibiruian Anunnaki control, in  preparation  for the anticipated 2000-
         2017 SAC  and intended fulfillment  of the Planetary Christos Realign-
         ment Mission.  
  •  Since King Arthur buried the Arc of the Covenant Gold Box in 608 AD,
             the Luciferian Knights Templar, Jehovian and Drakonian Annu-
           Melchizedek Illuminati Human lines have quested  to claim the Arc of the
           Covenant Gold Box from its resting-place in Lohas Atlantis. To conceal
          knowledge of the unidentified Lohas-Atlantis location of the Arc Box un-
          til it could be located and confiscated, the Luciferian Knights Templar,
         under direction of Galactic Federation , began a crusade to destroy or dis-
         tort any remaining records of Atlantis.  Further distortion of historical
         records and intentional “planting” of falsified Atlantian Maps were tac-
          tics used to deter competing Illuminati Human forces  from retrieving the
             Arc Box, and thus control of Earth’s Templar, before the Luciferian
          Knights Templar could stake their wrongful claim.  
 • After the 608 AD Arthurian Grail Quest, competing Illuminati Human
          Annu-Melchizedek races progressively rose to positions of political power
         within the global arena, launching continuing campaigns of disinforma-
         tion, historical distortion, Genocide Crusades against  each other and
          against Angelic Human and Maji Grail King 12-Tribes  races. In 1244
          AD the Cathars, Maji Grail King  families of southern France were de-
           stroyed by the Omicron-Drakonian held Church of Rome in the Albigen-
               sian Crusade.  Many murderous crusades followed, including the      
        
         316   
                

                                                    King Arthur and the Knights of the Roundtable        
         decimation of the Bruah-Atlantis and Mu’a-Lemuria Maji Grail King
          Amerind  lines of North America,  in the European quest for the '' New
           World .'' 
      • It was long known among the competing Knights Templar, Jehovian and
         Nephedem  (Omicron-Drakonian) Annu-Melchizedek Illuminati Human
          inner circles  that the “New World” of America  was the Old World  of
              which Bruah-Atlantis,  the location of the central control site ''Gru-AL
           Point '' for Earth’s Planetary Shields, was once part. The competing quests
          for control of Lohas-Atlantis-Star Gate-11,  the Bruah-Atlantis Gru-AL
            Point  and the other Star Gate locations  in Earth’s Templar Complex
         have been at the heart of the continual con ﬂict and race hatred and do-
         minion campaigns throughout our recorded human history.  
     • The three competing factions of Annu-Melchizedek races, representing the
          Luciferian, Jehovian and Drakonian Dominion Agendas , emerged from
           our ancient pre-Atlantian past,  through Lemuria, Atlantis and our early
           recorded history into the powerful global infrastructure  of the contem-
            porary Interior World Government Illuminati One World Order Agenda.
            As part of the planned, pre-meditated Atlantian Conspiracy strategy, in
           1750 AD the Galactic Federation and Pleiadian-Nibiruian Luciferian
  Anunnaki  races began making remote contact  with “Chosen Ones,” de-
   scendants of their respective Annu-Melchizedek Illuminati races, who
    carried the DNA Template implantation  allowing for telepathic rapport
   from their genetic ancestral line. After rising to covert power in Europe
   and various other regions, Galactic Federation and the Pleiadian-Ni-
   biruians motivated the American Revolution  and the founding of the
 United States of America via Secret Society Occult School  “inspiration”
of their Luciferian Knights Templar Annu-Melchizedek Illuminati rac-
 es. This contact progressed from in filtration of ancient traditional reli-
 gious control dogmas  with their “Inner Circle Elite” Occultists, into what
 has become the “ New Age Channeling Movement.”  The New Age
 Movement is primarily dominated by Jehovian-Sirius A, Luciferian-Pleia-
 dian-Nibiruian, Marduke-Necromiton-Luciferian-Alpha  Centauri and Sirius
 B, Luciferian Centaur-Omega  Centauri  and some Necromiton-An-
 dromie channel contacts . 
   • Following covert surveillance  that began in 1916, the Zeta  (“Little Grey”)                                                                                                    
races began physical interaction with Earth on behalf of the Zephelium
         (reptile-insect) Drakonian Agenda  races of Orion. In the 1930s and
        1940s  Illuminati Human Annu-Melchizedek descendants of the Zepheli-
        um-Zeta, Omicron-Drakonian (''Dragon-Moth'') and Odedicron (Rep-
        tile-Avian) Drakonian Agenda races of Orion entered One World Order
         Dominion Treaties  with the Orion Zeta Rigelian  races. The Zeta Trea-
         ties  initiated the formation of '' Majestic-12 '' which began the “ contact
          phenomena ” of what has become the contemporary '' UFO Movement. ''
        In 1 983 the Orion Omicron and Odedicron Drakonian  Agenda Legions
          assumed the leadership role in the Zeta Treaty agreements.  
       • In the 1930s the Necromiton  (Beetle-reptile-insect-hominid) races of An-
            dromeda  became involved with certain factions of the Drakonian Illumi-
        nati Human Interior Government, initiating the '' Men in Black ''   
                                                                                                                         
       317

                                                                                                                                                                                  
   The Atlantian Conspiracy and Roundtables                                                                          
        
             phenomenon; some assisting the Luciferian Pleiadian-Nibiruian races of
            the Luciferian Covenant,  others supporting the Drakonian Agenda races.
   • In November 1992, the Emerald Covenant Maharaji Blue Human and
         Azurite  races of Sirius B, the Serres-Pleiadian  (avian-hominid) races of
          Alcyone and the Lyran-Sirian Anuhazi  (feline-hominid) Founders races
   negotiated the Pleiadian-Sirian Agreements.  In these agreements the
   Luciferian Pleiadian-Nibiruian Anunnaki  races, Galactic Federation
  and a few Jehovian-Anunnaki  races agreed to enter the Emerald Cove-
  nant  peace treaty for co-evolution with the Angelic Humans of Earth in
  a united stand  against the Drakonian Legions’ Anti-Christiac Dominion
  Agenda. The Anunnaki races  vowed to assist in the 2000-2017 SAC
   Emerald Covenant Planetary Christos Realignment Mission.  They
  promised to disengage Nibiruian Diodic Crystal Grid  control of Earth’s
  Templar and to return Solar Star Gate-4  control over to the Founders’
 Emerald Covenant races by 2000, to prevent the scheduled pole shift that
   Galactic Federation had intended to orchestrate as per the Atlantian
 Conspiracy Luciferian Covenant.
  • In January 2000,  when the SAC commenced, most of the Anunnaki Le-
  gions defected  from the 1992 Pleiadian-Sirian agreements, reverting to
their Luciferian Covenant Dominion Agenda. On July 5th , 2000  further
negotiations with the Anunnaki legions culminated in their return to the
Emerald Covenant via an agreement called the Treaty of Altair;  they
were required to release the Nibiruian Diodic Crystal Grid and Solar Star
Gate-4 by August 2000.
  • On September 12th,  2000 the Necromiton Andromie “Men In Black”  of-
          fered co-conspiratorial deals to Luciferian and Jehovian Anunnaki and
          Drakonian races. Galactic Federation  and most members of the Anunna-
          ki legions defected from the Treaty of Altair  to join the United Resis-
          tance (UIR) . The UIR is a co-conspiratorial plot  through which
          Resistance Legions intended to covertly evacuate small numbers  of their
          respective “Chosen Ones” and “clear Earth’s real estate” via pole shift  be-
           tween 2003-2008,  to achieve fulfillment  of the Luciferian Covenant
          Atlantian Conspiracy Agenda between 2008-2012 .
  • On September 12th, 2000 the UIR  Legions  issued an edict of war  against
          Emerald Covenant Guardian races if they did not withdraw support  for
          the Angelic Human 12-Tribes  of Earth. Guardian Nations refused to
         abandon humans  and Earth to Fallen Angelic dominion and exploitation.
         We are now facing the Final Con flict drama  of the ancient Atlantian
         Conspiracy .
  • As the Atlantian Conspiracy advanced from the 9558 BC Atlantian Flood,
          Emerald Covenant  races  knew that the 2000-2017 Stellar Activations
           Cycle  would be the time for  fulfillment of the  Planetary Christos Re-
           alignment,  and that if negotiations with Fallen Angelic legions were not
         successful the Final Conflict drama  would ensue. In preparation for these
         anticipated events,  the Maji Grail King lineage  Indigo Children Types-
            1 and 2  have been incarnating on Earth for the past I00 years. The Maji
           races are here to assist the Angelic Human 12-Tribes of contemporary   
  318  

                                   
                                Progression of Major Events in the Atlantian Conspiracy
  Earth  in completing the Emerald Covenant Mission that King Arthur,
        and Essene Jesheua before  him, were unable to fully complete.
   • To prevent pole shift  in the 2003-2008 period, the Nibiruian Diodic
Crystal Grid  of Stonehenge, England and Earth’s Star Gate-11  must be
re-calibrated  using early activation of D-6 Sirius B Star Gate-6  to over-
ride the D-4 Nibiruian Alignment before 2003 . This will release the D-4
Solar Spiral  from Nibiruian control, preventing the massive  pole shift the
UIR intends. This is the Sacred Mission that Essene Jesheua  (Jesus
Christ), King Arthur  and many Maji Grail Kings before them were at-
tempting to accomplish.
    • Once the Nibiruian hold on Earth is released, the Planetary Christos Re-
  alignment Mission  can be completed  if the Angelic Human 12-Tribes of
  Earth  can successfully “ Run the RRT .” Running Earth’s RRT can be
   done only by the Angelic Human and Maji Grail Line 12-Tribes of
    Earth , whose DNA Templates  carry the DNA Signet Codes  that corre-
 spond to the  correct  Fire Letter Sequences  in Earth’s Planetary Shields.
  Through completing the Christos Realignment Mission by “Running the
   RRT” Star Gate Signet Councils today, the ancient Anti-Christiac At-
  lantian Conspiracy  One World Order Dominion Agenda of the contem-
  porary UIR can be overcome in our present time period.
                            
                              PROGRESSION OF MAJOR EVENTS
                             IN THE ATLANTIAN CONSPIRACY
• 50,000 BC- Lemurian Holocaust: Jehovian Anunnaki  and their Annu-
        Melchizedek Urantia  Illuminati Humans infiltrate Lemurian Muarivhi,
        allow Dracos²  infiltration, culminates in destruction of Muarivhi Pacific
        Continent.
    • 28,000 BC-Atlantian Holocaust: Sirius A Jehovian and Pleiadian-Ni-
        biruian Luciferian Anunnaki and their Annu-Melchizedek Illuminati Hu-
         mans attempt to seize Inner Earth and Atlantis, culminating in cataclysm
         that reduces Atlantic Continent to  three Island Nations: Bruah, Nohasa
        and Lohas.
   • 25,500 BC-Lucifer Rebellion: Nibiruian Marduke-Anunnaki ³ race line
         seize control of Nibiru and D-4 Solar Star Gate-4,  begin Anunnaki Race
        Unity dominion campaign and plant Nibiruian Diodic  Crystal Grid Plan-
         etary Templar Control Network in at Stonehenge, England  (before
         ''Standing Stones''). Anunnaki races infiltrate Bruah, Nohasa and Lohas
         Atlantis.
        • 22,326 BC-Eieyani Massacre: United Pleiadian-Nibiruian Luciferian
        Anunnaki and Marduke-Anunnaki  decimate  Eieyani Maji Races at
        Kauai, Hawaii  location and seize major territories of Bruah and Nohasa
          Atlantis , sending Atlantian Semoli-Bruah and Druidec-Nohasa Maji
        Grail King races into exile  to Lohas, Atlantis and Ionia ( Italy, Greece)
   
     ________________________
   2.    Omicron-Drakonian + Human
   3.    Anunnaki + Omicron Drakonian
  319
  
   
                                                                                                        
                                         

                             
   The Atlantian Conspiracy and Roundtables
• 21,900 BC-Lohas-Celtec-Druidec Freeze Out: Pleiadian-Nibiruian Lucifer-
       ian Anunnaki and Galactic Federation intentionally collapse Firmament
       Hydro-suspension Field over Lohas, Atlantis to force Maji Grail King
       lines away from Lohas Star Gate-11; culminates in 21,900 BC-14,000 BC
      Glacial Period.
       . 20,000 BC-Vicherus-Sacheon Invasion: Alpha-Centauri Marduke -Necro-
       miton-Anunnak i and their Vicherus Annu-Melchizedek  race and Pleia-
          dian-Nibiruian Samjase-Luciferian-Anunnaki  and their Sacheon
      Annu-Melchizedek race invade Angelic  Human Tribe-6  and exiled
        Celtec-Lohas and Druidec-Nohasa Atlantian Maji Grail King lines in
       Caucasus Mountains, Russia , in attempt to destroy Grail Lines . Begin
      intentional concealment of Celtec and Druidec Atlantian Maji Grail
      King and Angelic Human Tribe-6  racial identity. The Vicherus races he-
        came known as the '' Vikings ,'' the Sacheons  as the '' Saxons ,'' both
      groups often “ painting themselves blue ” in honor of the Luciferian Al-
      pha-Omega Centauri Centaur race . In order to hide knowledge of the
       Atlantian Maji King Grail Lines, the “blue raiders ” were later falsely
      identified in historical record as the “Celtics”  of Ireland, the Druidecs as
      the ''Druids.''
  •  10,500 BC Luciferian Conquest: Atlantian Islands of Bruah and Nohasa
        fall to Pleiadian-Nibiruian Luciferian and Sirius A Jehovian Anunnaki
       and Annu-Melchizedek control; the Atlantian Conspiracy  develops  high
      level organization.
 •  9,560 BC Luciferian Covenant: Pleiadian-Nibiruian Samjase-Luciferian
        Anunnaki  (“Blonds”), Sirius B Marduke-Anunnaki  (Anunnaki + Omi-
        cron “Dragon-Moth”), Enlil-Odedicron (Anunnaki + Reptil e-Avian),
         Thoth-Enki-Zephelium  (Anunnaki + Zeta) and Marduke-Necromiton-
       Luciferian (Anunnaki + Alpha-Omega Centauri Blue Centaurs), Galac-
       tic Federation and Nohasa Atlantis Jehovian-Urantia  and their respec-
        tive Annu-Melchizedek races enter full alliance under the One World
         Order Anti-Christos Agenda  formally mandated through the Luciferian
        Covenant. Omicron-Drakonian and Odedicron-Reptilian races of Orion
       form second competing Orion-Drakonian One World Order Agenda.
       Main Sirius A Jehovian-Anunnaki (“Bipedal Dolphin People”) race form
       third competing Jehovian One World Order Agenda.
•  9,558 BC Atlantian Flood: Luciferian-Anunnaki  and portions of  Galactic
      Federation  orchestrate Atlantian Flood in an attempt to take over  Giza,
      Egypt Great Pyramid Teleport Station and its true Arc of the Covenant
      Andromeda Portal Passage. Thoth-Enki  Annu-Melchizedek Illuminati
       Humans that took over Bruah Atlantis  follow initiatives of the Samjase-
       Luciferian-Anunnaki '' Larsa King '' that took over Lohas Atlantis,
         sending EM Pulse from Bruah Generator Crystals to Giza, causing major
      ﬂooding via final collapse of Firmament Hydro-suspension F ield over No-
       hasa and Bruah Atlantis. Only portions of the Atlantian Islands sink; ma-
       jor parts of Bruah, Nohasa and Lohas  Atlantis still remain above water.
      In 9540 BC  the Sirius B Maharaji Blue Human Emerald Covenant Races
      give Rod and Staff  Star Gate Tools in “Arc of the Covenant Gold Box”
      to Maji Grail King  lines of Earth to keep open contact with Inner Earth
 320 
   

                                  
                               Progression of Major Events in the Atlantian Conspiracy
       races via Earth’s portal system. Luciferian, Jehovian and Drakonian quest
       for possession of the Arc Tools  begins, as does intentional falsification
       and eradication  of Angelic  Human historical  record  to conceal the
       knowledge and location of Lohas Star Gate-11 , the lands of which sur-
       vived the Atlantian Flood.
•  8,900 BC Sumerian Invasion: Luciferian and Jehovian Anunnaki and Dra-
       konian  Races and their Annu-Melchizedek legions all raid Angelic Hu-
      man Tribe-10 resettlements of Sumerian UR  and surrounding territories
        (Iraq-Iran) in quest for Star Gate-10  control and Arc of the Covenant
       Gold Box Tools . Samjase-Luciferian-Anunnaki lines as “Sumerian Larsa
      Kings. ” Jehovian Anunnaki lines as “ Hassa Kings and Midianite-Hyk-
       sos Kings, ” Marduke-Anunnaki and Drakonians as Babylonian and
       Akkadian Dragon Kings,  Thoth-Enki-Anunnaki as '' Snake Brother-
       hood Kings .'' Evidence found in Sumerian “Larsa Kings List” tablets.
•  8,400 BC Egyptian Invasion: Thoth-Enki-Zephelium-Anunnaki and their
       Bruah-Atlantis Annu-Melchizedeks raid Egypt from Sumeria , over-
       throwing Serres-Egyptian Pre-dynastic Grail King lines as the Osirius
       King  line. Enlil-Odedicron-Anunnaki  combine, creating the Osirius-
       Isis-Horus King Line, Samjase-Luciferian-Anunnaki Sumerian Larsa
      Kings  combine creating the Egyptian “ Scarab King ” line that dominated
        Dynastic Egyptian History in competition with the Marduke-Anunnaki
       Drakonian Agenda '' Set King '' line. With Galactic Federation  assis-
        tance, Jehovian-Anunnaki Annu-Melchizedek Midianite-Hyksos King
      lines later invade in 1670 BC,  leading to the “Exodus” in 1476 BC  un-
       der Tuthmosis III.
•  7,500 BC Knights Templar Invasion:  Luciferian Covenant Anunnaki races
      raid Celtec and Druidec Maji Grail King races that returned to Lohas At-
       lantis territories in 13,000 BC from exile in the Caucasus Mountains, Rus-
       sia. Forced interbreeding between Nibiruian Thoth-Enki, Pleiadian-
        Nibiruian Samjase-Luciferian and Alpha-Omega Centauri Marduke
      Necromiton-Luciferian Anunnaki Annu-Melchizedek Illuminati Human
      lines and Maji Grail King lines for Illuminati race DNA Template up-
      grade. Creates Luciferian “Super-race” Knights Templar-Sumerian Larsa
        King + Egyptian Osirius-Isis-Horus Scarab King+ Egyptia n-Midianite
      Hyksos King + Indian Centaur King Annu-Melchizedek Anunnaki plus
        Celtec-Druidec Atlantian Grail King (forced interbreeding). Ancestors
       of contemporary Freemasons.
•  5,900 BC Centaurian War: Luciferian Anunnaki Races steal Arc of the
        Covenant Gold Box and Star Gate tools, attempt to cause pole shift from
           Nibiruian-Diodic-Crystal Grid at Stonehenge, England, to claim Earth’s
                    territories. Omicron-Drakonian, Alpha-Centauri Luciferian Centaurs,
           Marduke-Anunnaki and Jehovian Anunnaki races begin counter attacks
       in England, India, Egypt, Tibet, Ionia and North America. Sirius B Maha-
       raji Blue Human Emerald Covenant Races intervene with air raids to stop
       Luciferians’ use of the Arc Tools for pole shift. Maji Grail Kings retrieve
       Arc Box. Partly recorded in Sanskrit Mahabharata Texts.
  321
      
                                                                                                            
                                                                                                                             

                                   
 The Atlantian Conspiracy and Roundtables
  •  3,650 BC Mayan Raids: Luciferian Anunnaki raid Mayan Angelic Human
  12-Tribes in Yucatan and progressively infiltrate selected 12-Tribes settle-
   ments throughout South, North and Central America.
 • 3,470 BC Babble-On Massacre: Galactic Federation and Luciferian Pleiadi-
    an and Nibiruian Anunnaki races steal Arc of the Covenant Gold Box
  and star gate tools, attempt world dominion beginning in Marduke-Anun-
  naki Drakonian-held Babylon. Temporary planetary magnetic grid col-
    lapse created, using Arc tools at Babylon and Nibiruian-Diodic-Crystal-
    Grid at Stonehenge, England, to create reverse-Fire-Letter-Sequence dis-
  tortions in Earth’s Planetary Shields, which caused major mutations in the
  function of the Angelic Human DNA Template. Erased Race Memory,
  blocked natural Kundalini ﬂow in body causing Pineal, Thalamus, Hypo-
    thalamus and Thyroid Gland malfunctions that shorten human life span
    and block interdimensional perception in all but implanted Annu-
          Melchizedek “Chosen Ones” and scrambled natural language patterns.
    Recorded as “Tower of Babel” story in Bible. Grail King races retrieve Arc
        of the Covenant Box and Tools, preventing advancement of world do-
  minion through intended pole shift.
 • 2,668 BC Djoser Invasion: Galactic Federation, Luciferian and Jehovian
   Anunnaki infiltrate Sakkara, Egypt,  with Pharaoh Djoser and their Lu-
   ciferian Knights Templar  “Super-race” and Midianite races of Israel and
   Sumeria. Serres-Egyptian-Lohas Atlantian Grail King Pharaoh Imhotep
  deposed in peaceful surrender. Imhotep remains with Djoser regime as
    “lesser of the apparent evils” compared to the Marduke-Anunnaki Drako-
     nian Agenda invasions progressively advancing from Babylonia.
  • 2,024 BC Dead Sea Conquest: Galactic Federation and Luciferian Anun-
   naki  races steal Arc of Covenant Box and Tools again, launch world do-
  minion campaign again in Babylonia, extending into Dead Sea area
    between Israel and Jordan. Destroy Sumerian cities once located in Dead
    Sea region. Recorded as “ Destruction of Sodom and Gomorrah”  in the
    Bible. Maji Grail King races retrieve Arc of the Covenant Gold Box and
     tools, preventing spread of Anunnaki world dominion.
 • 1670 BC-1550 BC Hyksos Invasion: Medianite-Hyksos King  Jehovian
 Annu-Melchizedeks cross with Luciferian Knights Templar Anu-
  Melchizedeks from Sakkara, Egypt Djoser  lineage. Infiltrate Egypt from
   2668 BC and finally take over Egyptian Dynasty as Hyksos Kings in 1670
  BC.  1550 BC  Drakonian Agenda Pharaoh Ahmose deposes last Hyksos
  King Pharaoh Kamose, leading to 1476 BC Hyksos Exodus  under Dra-
  konian Agenda Pharaoh Tuthmosis III.  Under Galactic Federation di-
   rection, Hyksos intend to invade and destroy Angelic Human Hebrew
  Tribe-2 in Israel.
  • 1459 BC Israel Crusade: Hyksos  from Exodus instructed by Galactic Feder-
    ation and Luciferian Anunnaki  to use stolen Arc of the Covenant Gold
     Box Star Gate '' Rod and Staff '' tools to destroy Hebrew Angelic Human
    Tribe-2.  Intend to claim Israel  as their “Promised Land” as beginning of
     intended global dominion pole shift Luciferian Covenant agenda. Serres-
     Egyptian Maji Grail Kings  exiled in desert retrieve  Arc of the Covenant  
322 
      

       
                                                    Progression of Major events in Atlantian Conspiracy
       
            Gold Box and tools  preventing the Hyksos’ destruction of Hebrew Tribe-
            2. Hyksos do not get their “Promised Land,” the story of the Hyksos Exo-
            dus intentionally integrated into Hebrew and Christian historical teach-
            ings to conceal  Hyksos Annu-Melchizedek presence.  
                         • 1458 BC Hatshepsut Invasion: Serres-Egyptian Maji Grail King Pharaoh
Queen Hatshepsut  of Egypt receives Arc of the  Covenant Gold Box  and
tools from desert Maji Grail kings after they stop Hyksos Israel Invasion.
Her part-Drakonian half-brother Tuthmosis III  invades Hatshepsut’s
     Temple and steals Arc Box.
         •  1353 BC Fall of Akhenaton: Attempt to enter Hyksos-Egyptian King line
into Serres-Egyptian Maji Grail King  line for Galactic Federation-Hyk-
sos Emerald Covenant entry and Hyksos genetic Bio-Regenesis Program.
Pharaoh Akhenaton  fails in his intended Emerald Covenant Mission in
favor of Anunnaki Luciferian Agenda  and is killed by competing Drako-
nian Agenda Uncle. Galactic Federation  defects from Emerald Cove-
nant.
              • 906 BC Fall of Solomon’s Temple: King Solomon,  (Hyksos Annu-
Melchizedek + Serres-Egyptian Maji Grail Line), son of Hyksos King
David , is guided by Galactic Federation  to use stolen Arc of Covenant
Gold Box tools  to destroy Hebrew Angelic Human Tribe-2 races of Israel
to claim “Promised Land” and advance global dominion . Pleiadian-Serres
Emerald Covenant race of Alcyone  intervenes directly with beam ship,
intending to teleport Arc Box and tools  out of Solomon’s Temple  and
return it to Maji Grail king protection, preventing Solomon’s assault on
Hebrews and advancement of the pole shift agenda. Galactic Federation
attempts to teleport Arc Box to their Pleiadian Ship but miscalculate , de-
stroying Solomon’s Temple  completely with a Photo-Radionic Wave          
beam . Pleiadian-Serres retrieve Arc Box and prevent pole shift agenda.
             •  26 BC Roman Invasion:  Omicron-Drakonian  legions of Orion  move their   
Nephedem Annu-Melchizedek Illuminati  races into political power
within the Ionian Empire of  Italy, deposing Angelic Human Tribe-5  
 of Italy and Ionian exiled  Celtec, Druidec  and Seminol  Atlantian Maji             
      Grail Kings to create stronghold of Roman Empire  dominion. Progres-
 sively infiltrate and transpose their race identity  over the Angelic Hu-
 man Tribe-5 and Maji Grail Line Ionians of Italy  and begin corruption 
 of Ionian Grail Kings’ Sacred CDT-Plate Spiritual Teachings  to create
 the foundations for the “ Church of Rome ” Catholic Religious Control 
 Dogma political machine. 
                 •  23 AD Essene Divide:  Galactic Federation  unites groups of Luciferian
  Hyksos King  and Jehovian Hassa King  Annu-Melchizedeks  to raid Em-
  erald Covenant Mission of Maji Grail King Essenes , Jesheua (Jesus
   Christ), John the Baptist and Miriam  in Tel el Amerna , Egypt . Due to 
   Essene Divide raids, Jesheua’s Grail King Essenes are unable to fulfill in-
  tended mission of disengaging the  Nibiruian Diodic Crystal Grid  to free 
   Solar Star Gate-4  and Earth’s Star Gate-11 to  prepare for the 2000-2017
  AD SAC and scheduled Planetary Christos Realignment Mission. The Maji 
    Essenes had fulfilled part of the mission by reclaiming  the Rod Star Gate     
323
                                                                                                                                                                                                             

                                             
                   The Atlantian Conspiracy and Roundtables
tool and its Arc of the Covenant Gold Box  from  Galactic Federation’s        
Noah-Abraham-Moses Hyksos Annu-Melchizedek  illuminati line, but       
could not recover the Staff tool. Following failure of the intended Plane-       
tary Security Mission, Jesheua, John, Miriam and several Maji Grail King      
Essenes hid Arc of the Covenant Gold Box  and its Rod tool in Vale of       
Pewsey, England  via Tel el Amarna Inner Earth portal  passage.  
•	325 AD Council of Nicaea : Omicron-Drakonian legions motivated their       
     Nephedem Annu-Melchizedek Illuminati races governing the Roman      
      Empire  to temporarily join forces  with Galactic Federation  and the Ple-     
      iadian-Nibiruian Anunnaki . In this unholy alliance , the Nephedem, Lu-      
      ciferian Knights Templar, Hyksos King and Jehovian Anunnaki Hassa      
    King Annu-Melchizedeks assembled to '' come up with a cover story '' to      
      hide from public record the realities of Jesheua’s Emerald Covenant Mis-      
      sion . Groups of Hassa King Rabbis , Hyksos Kings  and Knights Templar     
      Priests , and Roman Nephedem Knights of Malta  launched a Crusade to         
      confiscate all records  of the Emerald Covenant Essene CDT-Plate trans-      
    lations. They combined various elements of true history and spiritual      
      teachings with numerous falsifications  and massive omissions of Templar         
      and Ascension teachings, to create the patriarchal, false-God control      
      dogma creed  that became the “ Canonized Bible ”. Their intentions were      
    to forcefully hide all knowledge  of the Emerald Covenant Christos Re-      
      alignment Mission while they searched for the Arc of the Covenant  Gold      
      Box. They intended to claim the Arc Box and prevent the “common peo-      
    ple”from having the Maji Grail King knowledge of the Roundtables , to     
    insure victory of their Anti-Christiac One World Order  dominion agen-               
      da during the 2000-2017 SAC .  
•	608 Arthurian Grail Quest:  Maji Grail King Arthur  (born 559AD) and the             
   ''Knights of the Round Tabl '' were the Maji Grail King Melchizedek                 
   Cloister Regents  who protected the “ Holy Grail ” Knowledge of Earth’s       
   Planetary Templar Complex. Arthur, Guinevere and the Roundtable             
   Knights held the Planetary Security Commission of reclaiming the Staff       
   tool from the Hyksos Illuminati and were intended  to run the RRTs to            
   disengage the Nibiruian Diodic Crystal Grid , in fulfillment of the            
   Jesheua-John-Miriam Emerald Covenant Mission. Though Merlin  assist-       
   ed in the return of the Staff  Star Gate tool (the “ Sword Excalibur ”) to      
   Maji Arthur’s protection,''Merlin'' (Victorous) later betrayed the Emer-       
   ald Covenant Mission in favor of the Hyksos-Knights Templar Galactic            
   Federation  World Dominion agenda. Arthur successfully returned the       
   Staff tool to the Arc of the Covenant Gold Box and relocated the Arc       
   Box  containing the Rod and Staff from the Vale of Pewsey, England to       
   where it remains hidden today . Arthur and his Knights were unsuccessful            
   in disengaging the Nibiruian Diodic Crystal Grid. But at least they man-       
   aged to hide the Arc of the Covenant Gold Box  and Rod and Staff  tools           
   from Galactic Federation,  their  Hyksos-Knights Templar  and the even-       
   tually competing Nephedem-Drakonian Knights Malta, preventing them       
   from fulfilling their planetary genocide  and takeover  agenda. The              
   “Quest for the Holy Grail ” and “Search for Arc of the Covenant Gold                  
   Box ” has continued ever since.             
   324    

                                                            
                                                             
                                     
                                              Progression of Major Events in Atlantian Conspiracy
        . 1244 AD Albigensian Crusade:  Church of Rome Nephedem Annu-       
                        Melchizedek Illuminati , on behalf of the Omicron-Drakonian OWO      
                        (One World Order) agenda, launch a genocide campaign  against the Maji      
                        Grail Line Cather i, the Tribe-12 , Star Gate-12 Guardians in southern       
                     France. The campaign was initiated to stop the Catheri from using their      
              Roundtable knowledge  to disengage the Nibiruian Diodic Crystal Grid,      
                        knowledge gained from CDT-Plate-12 , which was in possession of the       
                        Catheri at this time. The Catheri’s “last stand” was at Monsegur, Southern      
                        France, an event historically recorded as the “Albigensian Crusade”, in       
                        which the Catheri were cornered and burned alive  at the order of the       
                        Church of Rome and accomplices in the government of France. A small       
                        group of Catheri escaped with CDT-Plate 12 , and numerous volumes  of                              
              pure Jesheua-Essene records , which were hidden in France  and will one                         
              day provide witness to the realities of the Atlantian Conspiracy.    
•	 1500 AD Ameka Crusade: The quest for the'' Holy Grai '' continued as               
    Hyksos-Knights Templar  Annu-Melchizedek Illuminati races and Omi-       
    cron-Drakonian Nephedem Annu-Melchizedek  Illuminati races ad-       
    vanced their OWO agenda in pursuit of the “ Holy GRU-AL ”.The  Gru-            
    AL POINT  is the central control point  for Earth’s Templar  and both com-      
    peting groups intended to hold dominion  over the lands of the Gru-AL       
    Point when the 2000-2017 SAC  arrived. The'' Protestant & Catholic             
    Invasion '' of  Native American Tribes  began. The name ''America ''       
    came from the name of one of the Emerald Covenant Maji Grail lines        
    known as the Ameka,  who were protectors of the Gru-AL Point . The                 
    Gru-AL Point was known to exist in the lands of the North American       
    continent , a territory once held by Atlantis . Guided through “ Mystical       
    Secrets Societies ” set up by their respective Fallen Angelic kin, competing          
    groups of Annu-Melchizedek Illuminati races launched a progressive in-       
    filtration and takeover of the North American continent. Each intended       
    to destroy  the exiled Lemurian and native Seminol and Ameka '' Native              
    American '' Maji Grail Line Tribes who had knowledge of Running the              
    Roundtables , in a systematic take-over of the North American Templar. 
       '' America '' was founded by the Luciferian Hyksos-Knights Templar Annu-                               
              Melchizedek Illuminati , who now go by the name of “ Free Masons ”, on                         
              behalf of Galactic Federation  and the Pleiadian-Nibiruian Anunnaki                     
              races of the 9560 BC Luciferian Covenant.  Competing Illuminati groups                      
             and their Stellar co-conspirators intended to use the North American                      
              Gru-AL Point , and their holdings of Star Gate-11 Europe , Star Gate-4                                    
              Egypt and  Star Gate-10  Middle East , to gain full control of Earth’s Tem-                     
             plar on behalf of their Stellar contacts during the 2000-2017 SAC .
                 It was anticipated by all that the “ Final Conflict Drama ” and the “ Battle of      
                  Armageddon ” would take place as the competing Drakonian and Anun-          
                  naki descendant Annu-Melchizedek Human Illuminati legions ''battled it      
                  out'' for control of Earth’s Templar during the long-awaited 2000-2017      
                  SAC. Neither side anticipated that there would be enough surviving An-                    
             gelic Human 12-Tribes and Maji races left with knowledge to run the      
                  Roundtables to prevent the Illuminati, known as the “ Leviathan Force, ”      
                  from succeeding  in their OWO agenda. Included in this OWO agenda    
                 325
                                                                                                                            

              
                The Atlantian Conspiracy and Roundtables
        was the re-initiation of  contact with the Fallen Angelic/ET Legions  as
the SAC   drew closer. The Fallen Angelics intended to slowly make their 
presence known then come in to “ stake their claim ” as the 2000-2017
SAC approached 2012 AD.  The Drakonian- Reptilian-Centaurian  de-
scent Annu-Melchizedek Illuminati races attempted, but failed, to claim 
world dominion over their Anunnaki adversaries via their representative
Hitler in WW2 . Both Illuminati forces have been competing for political 
world dominion . They have been the predominant, hidden source of 
war, race hatreds and territorial, financial and religious competition  be-
hind and within world governments, until the September 12th, 2000
UIR. On September 12, 2000, most competing Illuminati races, and their 
respective Fallen Angelic “ring leaders” agreed to take a united stand
against Emerald Covenant races  to ensure success of the OWO dominion 
agenda and destruction of the Angelic Human races during the 2000-2017
SAC.                 
      . 1750 AD Nibiruian-Re-acquaintance: Pleiadian-Nibiruian Anunnaki                      
            races and Galactic Federation  began initiating remote “ Channel Con-
              tact ” with their '' Chosen Ones ,'' providing contrived spiritual teachings
              intended to develop into the later “ New Age Movement ”, through
                which direct Fallen Angelic/ET contact could be made with little human                     
           resistance . 
    • 1916 Zeta Surveillance: Zeta races begin participating in the Earth drama 
             on behalf of the Zephelium-Zeta Rigelian and Odedicron-Reptilian (Ori-
             on) agenda. 
 
•  1930-1940's Covert Treaties:  The Zeta negotiate covert treaties with                                                                                                    
    Nephedem Annu-Melchizedek Illuminati human government, through                                                                
    which “ Majestic-12 ” and the contemporary “ UFO Movement ” emerge
          on behalf of the Drakonian OWO agenda, which initiated as a result
          of the pending Anunnaki takeover agenda. Anunnaki Fallen Angelics ad-
          vance their remote “Channel” contact with selected humans.  
             
•  1983 Orion Intrusion: Omicron-Drakonian races of Orion get directly in-                      
    volved in the drama, forming alliances with the Odedicron-Reptilian and                 
    Dracos races; Zeta’s lose footing in Illuminati affairs as Drakonians take                         
    over Zeta Treaties, some Zetas leave, Rigelian Zetas join to strengthen             
    Drakonian forces in Earth affairs. 
•   1992 Pleiadian-Sirian Agreements: Pleiadian-Nibiruian Anunnaki  and             
     Galactic Federation  races enter Emerald Covenant  peace treaty when they             
     realize that they may succumb to Drakonian Force in the anticipated 2000              
     -2017 Final Con ﬂict Drama. Agree to turn Solar Star Gate-4  control back              
     over to Emerald Covenant races, to end the Atlantian Luciferian Cove-                  
     nant  for co-evolution programs, to assist Emerald Covenant and Human       
     races in running proper Roundtables  to block further Drakonian infiltra-       
     tion and promise to disengage Nibiruian Diodic Crystal Grid by January 1,              
     2000 . The “New Age Movement” takes a turn toward the Light.
    •  1999 Centaurian-Necromiton Intrusion: Drakonian agenda Necromiton-                
       Andromi and  Alpha-Omega Centauri races get involved to reinforce the               
       Drakonian agenda in reaction to Anunnaki joining the Emerald Covenant.    
     326
                                                      
                                                               

                                                                
                                                           
                                                       Progression of Major events in Atlantian Conspiracy
                      
                      •  January 2000 SAC Rebellion: When Stellar Activations Cycle com-
    menced on January 1, 2000, Galactic Federation and Pleiadian-Nibiruian
      Anunnaki groups defect from Emerald Covenant  once Stellar Activa-
      tions Cycle was confirmed, as Fallen Angelic Annu-Elohim offer full sup-
      port to the Anunnaki OWO agenda.
•   July 5, 2000 Treaty of Altair: Galactic Federation and most Anunnaki 
     groups grudgingly accept re-entry into the Emerald Covenant to secure 
     greater protection when Annu-Elohim  of Sirius A  and Arcturus suffer 
     heavy losses to the Fallen Seraphim Drakonian  force in Density-3 Orion. 
•   September 12th, 2000: Necromiton-Andromie  and Alpha-Omega-Centau-
                      ri  races convince many Drakonian and Anunnaki legions to form a 
        “ United Resistance Alliance ” (UIR) against the Emerald Covenant to 
         ensure fulfillment of their common interest in the OWO dominion agen-
         da. Galactic Federation, Ashtar Command  and most Anunnaki Legions 
         break the Treaty of Altair  to join the UIR. UIR adopts the Anunnaki 
         Luciferian Covenant agenda , which includes “termination” of the An-
         gelic Human races of Earth and forced pole shift, induced via Battlestar
         Nibiru  (“Wormwood”) and the Nibiruian Diodic Crystal Grid. Septem-
         ber 12, 2000 UIR offers Emerald Covenant races an ultimatum.  UIR
         would allow the Lyran-Sirian Guardian races to evacuate  50,000  of their
         '' Indigo Children Maji Grail Lines ,'' then the rest of Earth’s populations 
         would fall prey to fulfillment of the Luciferian Covena nt agenda. Emerald 
         Covenant Races refuse on behalf of all Angelic Human and Hybrid pop-
        ulations of Earth that desire to live in freedom and in order to prevent
         Earth’s Halls of Amenti star gates from falling under UIR dominion. UIR
         issued a formal Edict of  War  on September 12, 2000, against Emerald Cov-
         enant races and the Angelic Humans of Earth.  
                                    
Galactic Federation  and Ashtar Command  is beginning to mobilize their 
             “ Human Ground Crews ” teaching their followers to expect a'' landing ''
              in which ''complete human compliance'' is promoted. The political arena
              is now being set for the UIR’s intended 2003 Mass Mind Control initia-                        
             tive and most humans are completely unaware of what is taking place.
              Emerald Covenant races are intending to awaken the Indigo Children as 
              quickly as possible. The Indigo Children are being prepared now to run 
              RRTs  in order to disengage the Nibiruian Diodic Crystal Grid  through 
              which pole shift can be forced and to seal Earth’s portal system from 
              planned Fallen Angelic 2003-2004  invasion. Before 2003 , Emerald Cov-
              enant races will know if the RRTs are successful and if fulfillment 
              of the Atlantian Conspiracy can be prevented. If not, preparations are al-
              ready underway to assist Humans in DNA Template Activation so some 
              may become biologically capable of portal evacuation.   
                          Sometimes truth is stranger than Fiction.            
                          327                                                                                                           
                          
                                                                                                                                                         

   The Atlantian Conspiracy and Roundtables
                     CORE TEMPLATE GRIDWORK IS REQUIRED
                       to prevent fulfillment of the UIR OWO Agend a
• Through quickly re-learning how to '' Run the Rainbow Rounds ,''Angelic
     Human and Hybrid races can prevent pending Anunnaki-Drakonian 
     OWO dominion during the 2000-2017 SAC. Properly executed RRTs
     can fulfill the Emerald Covenant Christos Planetary Securit y Commission 
       of disengaging the Nibiruian Diodic Crystal Grid  and freeing Solar-Star                                      
                         Gate-4 , which will prevent Fallen Angelics any further access to Earth’s                                         
                 portal-vortex system . Running the Signet RRTs to reclaim Earth’s Tem-
     plar from Fallen Angelic dominion has been known for thousands of years 
     as the 11:11/12:12 Christos Reclamation Mission, the Divine Commis-
     sion previously attempted by Jesus-John-Miriam, King Arthur-Guinev-
     ere-Knights, the Catheri,  the Native Americans and numerous other 
     Maji Grail Line Races  throughout history since the  25,500 BC Luciferian
     Rebellion.
                                                     
                                           Now it is up to Us. 
CREATION OF THE LEVIATHAN FORCE &  RELATED HISTORY
                                              
                                    798,000 BC - 33,000 BC
 250,000,000 Years Ago—
      Parallel Earth Human Seeding-1 five Palaidorian Cloisters
25,000,000 Years Ago—
      Five Human & Five Palaidorian  Cloisters seeded on Earth
5,500,000 Years Ago—Human Seeding-1 destroyed via Electric Wars
 3,700,000 Years Ago—Human Seeding-2
 848,800 Years Ago—Human Seeding-2 destroyed via Thousand Years War                          
                       ANGELIC HUMAN SEEDING-3—
                   CONTEMPORARY LINEAGE BEGINS
798,000 BC—- five Palaida-Urtite-Cloisters Angelic Human Seeding-3: Round-1
669,000 BC-250,000 BC—Rama & Temple Wars Anunnaki/Drakonian In-
       vasions, Nephedem-Drakonian & Urantia-Jehovian-Anunnaki Illumi-
       nati hybrid-humans
250,000 BC—Enki-Enlil-Marduke Pleiadian-Nibiruian Anunnaki (Aquatic-
       ape-hominid) create Lulcus-Neanderthal Primate-hominid slave-race via
       raiding Angelic Human colonies
246,000 BC—Maharaji bring Emerald Covenant Restatement peace treaty to
       Earth races, Angelic Humans enter & Thoth-Enki Anunnaki enter for
       DNA Bio-Regenesis
208,216 BC—SAC, Drac Invasion, Fall of Brenaui, 10-Code Pulse & pole shift
208,100 BC—Urtite-Cloister Human: Round-2 subterranean resettlements
328 
                                                                                           

                                           
                                   Angelic Human Seeding-3 — Contemporary Lineage Begins
155,000 BC—Emerald Covenant Anunnaki Bio-Regenesis Program begins:
      Lulcus-Neanderthal Hyperbornean-Human  upgrade-1 to hybrid Luhari-
      Cromagnon-1
152,000 BC——Luhari Anunnaki-hybrid Ur- Antrian-Urtite-Cloister -Human
      Emerald Covenant (EC) upgrade-2 to E-Luhli-Levi-Cromagnon-2 , ﬁrst ca-
      pable of natural procreation with Humans; Levi-hybrids raided by Drac &
      Anunnaki Fallen Angelics, Anti-Christos Leviathan Force  competing Illu-
      minati genetic lines begin
151,000 BC—E-Luhli-Levi hybrid Breanoua-Urtite-Cloister-Human  EC up-
      grade-3 to E-Luhli-Judah Homo-sapiens
150,000 BC— Jehovian  Wipe out. Competing Drac & Jehovian (Dolphin Peo-
      ple) Anunnaki attempt to seize Earth & Inner Earth. Maharaji of Sirius B
      prevent take over; Firmament Hydro-Suspension fields collapse initiating
      glacial period.
148,000 BC—E-Luhli-Judah hybrid Hibiru-Urtite-Cloister-Human  EC up-
      grade-4 to E-Luhli-Nephi.Jehovian Anunnaki  launch aggressive raids on
      Nephi hybrid races creating the Nephite-Jehovian-Hibiru Illuminati hy-
      brid genetic line
148,000 BC-75,000 BC— Anu Occupation ; Sirius A & Arcturian Jehovian-
      Anunnaki  attempt Earth takeover, launch genocide programs against An-
      gelic Human, Drakonian-Nephedem & Nibiruian Anu-Anunnaki Earth
      races. Enlil-Enki-Marduke Pleiadian-Nibiruian Anunnaki lines unite,
      overthrow Jehovians & seize control of Earth. Emerald Covenant races
      exile & subterranean settlements. Nephedem- Drakonians, Jehovian-
      Anunnaki & Nibiruian Anunnaki Raider Wars begin
75,000 BC—Nibiruian Anu-Anunnaki attempt to seize Inner Earth portals,
      Inner Earth races unite in Inner  Earth Rebellion,  overthrow Anu-Anunna-
      ki dominion of surface Earth, reinstating Urtite-Cloister-Human sover-
      eignty over surface Earth
73,000 BC—Cloister-Human: Round-3  seeding begins with Ur-Antrian Cloister
71,000 BC—Root Race-Human: Round-4  seeding begins with Lemurians
72,000 BC— Breanoua-Cloister-Humans  seeded
 68,000 BC—Root Race-Human Atlantians seeded & E-Luhli-Nephi hybrid
       Melchizedek-Urtite-Cloister -Human EC  upgrade-5 to Annu-Melchizedeks.
       Drakonian, Jehovian-Anunnaki & Anu-Anunnaki Leviathan Illuminati
       hybrid races progressively raid Annu-Melchizedek races creating various
       competing Anti-Christos Agenda hybrid “ Templar-Meichizedek”  Levia-
       than “Super-races”—the Leviathan  Force, leading to the Atlantian Con-
       spiracy & present drama
66,000 BC- Hibiru-Cloister-Humans  seeded
63,000 BC—Root-Race-Human-Aryans
33,000 BC— Melchizedek-Cloister-Humans  seeded & 22,500 BC Eieyani Grail
       Line begins
329 
                        
                                                                                                  

The Atlantian Conspiracy and Roundtables                            
                               SUMMARY OF THE ATLANTIAN CONSPIRACY
50,000 BC - Lemurian Holocaust
28,000 BC - Atlantian Holocaust
25,500 BC  -Lucifer Rebellion
22,326 BC - Eieyani Massacre
21,900 BC - Lohas-Celtec-Druidec Freeze Out
20,000 BC - Vicherus-Sacheon Invasion
10,500 BC - Luciferian Conquest
9,560 BC - Luciferian Covenant
9,558 BC - Atlantian Flood
8,900 BC - Sumerian Invasion
8,400 BC - Egyptian Invasion
7,500 BC - Knights Templar Invasion
5,900 BC - Centaurian War
3,650 BC - Mayan Raids
3,470 BC – Babble-On Massacre
2,668 BC - Djoser Invasion
2,024 BC - Dead Sea Conquest
1,670-1,550 BC - Hyksos Invasion
1,476 BC - Hyksos Exodus
1,459 BC - Israel Crusade
1,458 BC - Hatshepsut Invasion
1,353 BC - Fall of Akhenaton
906 BC - Fall of Solomon’s Temple
26 BC - Roman Invasion
23 AD - Essene Divide
325 - Council of Nicaea
608 - Arthurian Grail Quest
1244 - Albigensian Crusade
1500 - Ameka Crusade
1750 - Nibiruian Re-acquaintance
1916 - Zeta Surveillance
1930-1940 - Zeta Treaties and MJ-12
I983 - Orion Intrusion
1992 - Pleiadian-Sirian Agreements
November 1999 - Centaurian-Necromiton Intrusion
January 2000 - SAC Rebellion
July 5, 2000 - Treaty of Altair
September 12, 2000 — United Intruder Resistance (UIR)
February 2001 - Grid Spiking Campaign
2003 - Intended Dimensional Blend Time Rip
2004 - Intended Frequency Fence
2008 - Intended Pole Shift via Nibiruian Battle Star and NDC-Grid
2012 - Intended Resistance Re-settlement & Inner Earth Crusade
330
                                         

                            Note On 12-Strand DNA Template Activation:  BE AWARE
      NOTE ON 12-STRAND DNA TEMPLATE ACTIVATION:
                                          BE AWARE
                                 Averting the Seduction of the “Quick Fix” and “Ego Pat”
• No Human on Earth  at this time has true 12-Strand DNA Template  ac-
     tivation or consummation , as the Planetary Shields cannot yet sustain bi-
     ological presence that holds continually activated D-12 frequency. 
     Distortions in the Race Genetic Imprint caused by the Planetary Shield
     severely block natural 12-Strand DNA Template activation, even if the
     Planetary Shields could sustain 12-Strand Activated Biology. Without
     consistent  use of DNA Template Bio-Regenesis technology and related
     Core Template Kathara Healing modalities, no human  on Earth at this
     time would  achieve genuine  12-Strand activation  during the  contemporary
     evolution cycle.
• Competing false 12-strand DNA activation programs are presently being
     run via unsuspecting New Age & UFO Movement “Channels & Contac-
     ees,” by Jehovian¹ Dolphin People Anunnaki and Pleiadian-Nibiruian²
     Anunnaki-Drakonian-Reptile hybrid races . The largest False DNA Ac-
     tivation - “Ascension” Program is conducted by the '' Alpha-Omega  Tem-
     plar Melchizedek Anunnaki-Drakonian Alliance ," which is composed of
     Centaur & Drakonian-Anunnaki races of Density-2 & 3 Alpha Centauri  and
     Omega Centauri,  the Necromiton-(Beetle-Reptile)-Anunnaki hybrid
     race of Andromeda3 and several other related Fallen Angelic Collectives
     following the Omicron-Drakonian-Zeta-Illuminati  “One World Order”
     dominion agenda. One of the most prominent expressions of the Alpha-
     Omega-Centaurian-Andromie Anunnaki-Drakonian-Necromiton col-
     lective refers to itself as the '' Archangel Michael '' Matrix,  a Bio-neuro-
     logical Mass Mind-control Program  run via the Alpha-Omega
     Collective, that is literally “broadcast into Earth’s airwaves to unsuspect-
     ing channels” from Parallel Earth  through the NDCG . False 12-Strand
     DNA Activation Programs are geared toward  ''Monadic Reversal '' - re-
     versing the Fire Letter Sequences  in the Human DNA Templates to cre-
     ate Reverse Sequence 11-Strand Activation  in humans, so human DNA
     will assist the Fallen Angelic mission  of gaining control of Earth’s Plan-
     etary Shields & Star Gates on a reverse-11 activation4 during the 2000-
     2017 SAC.
• Fallen Angelic and Illuminati Human Leviathan races use the seduction of
     false claims of “Easy DNA Template Activation” and false promises of As-
     cension without providing the details of the mechanics  by which these dy-
     namics naturally take place. If we know the mechanics  we can detect when
     they are being intentionally misused to orchestrate Anti-Christiac Do-
     minion agendas. The tactics of false “Quick-Fix Claims” and false promis-
     es are further coupled with false “sugar and spice,” in which our egos are
__________________
 1.  Sirius A, Arcturian, & ''Galactic Federation"
 2.  Anu-Seraphim Aquatic-ape-hominid
 3.  ''Andromies" &''Men-in-Black"
 4.  34-CCW/21-CW Nibiruian Merkaba                                                                               
333 
                                                                                                      

   
                     
                          The Atlantian Conspiracy and Roundtables
    
     fed as we are told “what we want to hear” and “how great and Beloved we
      are,” while being covertly “railroaded right under our own noses.” If we do
      not “fall for” the age-old “Quick-Fix” and “Ego-Pat” Seductions, we can
      avert Fallen Angelic and Illuminati manipulation tactics and learn how
      things really work , so we become empowered to set ourselves, and assist oth-
      ers, too to set themselves free. We can “Activate our 12-Strands of
      DNA,”5  but it takes work, a labor of Divine Love, and it requires Divine
      Sacred Science knowledge .
  • DNA Template and Kundalini Activations do not occur via “wishful think-
              ing” or “hopeful  spiritual intention ”—they   are  processes  of    natural  Bio-Spiritu-
     al Creation Physics , which occur via educated, conscious direction of
     energy and genuine Spiritual Wisdom. There is a natural Divine Right
     Order of energy mechanics that governs the manifestation of conscious-
     ness in biological form; the mechanics of this order must be understood
     and appropriately applied if one expects to attain genuine, essential , Bio-
     Spiritual Mastery.
      
                        __________________________         
           5.   24-48 Strands for Indigos
         334
                       

                                                 
                                                      16 
                                                                                        
                                             
                                                              
                                    
                  The 9/11 WTC/Pentagon Attack
                                      and the
                      Illuminati One World Order                
          Due to the continuing barrage of “stop-the-presses” new emergency
release information provided by the Guardian Alliance (GA) since the
United Intruder Resistance (UIR) Edict of War on September 12, 2000,
preparations for this updated Second Edition (2e) printing of Voyagers II  has
taken far too long. Information that was originally intended to become a
simple glossary for this book rapidly expanded in size to become another book
in its own right. This partially completed new book was then quickly put “on
hold” as a progressive series of GA emergency release dispensations rapidly
accumulated over 400 pages. Meanwhile, our Planetary Shields Clinics
workshop and site work excursions were scaled up to top GA priority,
solidifying into an immediate Crisis Intervention Program  called the
Emerald Covenant Masters Templar Planetary Stewardship Initiative . As
we began our new Ireland-England Planetary Shields Clinics tour in July
2001,  I was able to finally complete the “2001 Update” and related materials
for Voyagers II  , 2e. After a year’s worth of frustrating but unavoidable delays,
the lovely people with Saintly Patience at Granite Publishing could finally
''put the book to rest'' with ful fillment of its second printing— or so we all
thought . As this book was about to go to press in September 2001, the
''unbelievable '' occurred.  The events of September 11, 2001 , which we
have all rapidly come to know so well, intruded into the American heartland
and homeland with all of their inherent, numbing, horrific fervor, and “life as
we’ve known it” in the USA was suddenly and abruptly “changed forever.”
The events of the 9/11/2001, terrorist attacks  upon the NYC World Trade
Center Towers  and the Pentagon  in W ashington, D.C., have literally and
rapidly cast not only America, but literally the entire world,  into a
completely new and utterly “alien” uncharted political landscape , the
implications of which most peoples of all nations are presently struggling to
comprehend.  
   The old American expression of shared national mourning and
cultural, mental and emotional fixation that was once expressed by a
generation before in the query of “Where were  you when Kennedy was shot?”
     has now been permanently deposed from its once-prominent position within
      335 
                                                                                                                                               


                                                                                      
 
The 9/11 WTC/Pentagon Attack and the Illuminati One World Order  
the national collective mind. The old question has now been indelibly and
forcefully replaced within THE collective cellular memory of the American
psyche  by the query of “ Where were you on 9 /11/2001?”  within this
general question and ''query of our times'' the answer to which is fully
branded into the memory of many American citizens, resides the even more
important silent questions of '' What in the world is going on? '' and '' How
will all of this affect us ?'' The horrific events of 9/ll, and even more so their
potential rami fications, have made questions regarding the “Kennedy
Assassination” and other unresolved issues and shocking moments of our
collective past seem almost irrelevant. Events prior to the Trade Towers/
Pentagon attacks literally pale by comparison to anything we have known
since WW2. Due to the collective “emotional-mental stun factor” generated
by the “9/ll Disaster,” and the obvious resultant aftermath  of “ major
movement within the global political landscape ” that now dominates the
focus of world attention, many previously important questions may fall
away from mass attention . In some cases such environmentally forced
redirection of our mental and emotional focus from fixation on past events
and issues represents a potential healing catharsis within the collective
psyche, as individuals and nations begin to reassess and redirect their
priorities. But in other cases, distraction from pertinent past concerns can
prevent us from acquiring the very answers we seek concerning the     
contemporary drama .       
    
              ''UFO INVESTIGATION” AND “TRIGGER EVENTS''  
    One of the most important multifaceted issues  that might readily and
“conveniently” succumb to further malnutrition of mass attention is the
highly complex issue of '' UFO investigation. '' The “UFO issue” is, in truth, a
compendium of a  variety of  interrelated subjects:  “UFO sightings”; crop
circles; ET visitation/abduction; the “UFO Movement”; the “New Age
movement”; “angelic” contact; “channeling” communication; “spiritual
development”; “ascension teachings”; “official denial”; “Illuminati One-
World-Order agendas”; “forbidden archeology”; and the multitudes of
related, politically charged, '' conspiracy theories '' one must inevitably
address if thorough investigation of the “UFO issue” is to be ascertained. In
our present drama, seemingly born of very “3-D international political
issues,” it is more important than ever to keep questions of the “UFO
issue” firmly and foremost in mind.  The answers to the most ominous'
''silent questions'' of “What in the world is going on? and ''How will this
affect us?'' do not reside within the well-orchestrated “3-D political forum”;
these answers exist squarely within the core of the “UFO issue.” The tragedy
of the Trade Towers/Pentagon Attack is a global “wake up call” for 
''things unknown as-yet-to-come .'' Unfortunately, such an event, which
could serve as our greatest catalyst for mass awakening, is instead being
utilized to serve as our greatest mass distraction from the knowledge our
world most needs to rapidly comprehend.  In the immediate aftermath of the
911/2001 Terrorist Attack, three of the greatest and fully justifiable
unspoken questions  within the minds and hearts of the courageous people
who have supported the GA work since 1999 were as follows. “ Did the GA
know this attack would occur ?” “If not, and the GA supposedly knows so       
336         

                         OWO Master Plans, GA State of War Alert and Imminent Crisis Order
        much, then why didn’t they know ?'' ''If they did know, then why didn’t
they stop it or warn us? '' Along with questions regarding GA awareness, the
same questions were understandably directed toward myself, and
my associates MC.'' Did we know? '' “ What did we
know? '' ''Couldn’t we, through our GA Guardian contacts, have done
something to prevent it ?'' 
    As this book was ready to go to press, the “Unbelievable Events” of 9/
11/2001, unfolded, and with them a massive wave of personal and public
questions that cried out for answers. Though the final text of this book was
intended to be complete with the “2001 Update” material, Granite
Publishing rightly and wisely requested that a further update covering the
Trade Towers/Pentagon Attack  be provided as conclusion to Voyagers II  2e.
As “fate” or '' Divine Synchronicity '' would have it, the printing deadline for
this book had not yet passed when these monumental events of mass mayhem
occurred. In this final emergency release update of Voyagers II  2e, I will do my
best, as GA representative Speaker, to address the most obvious questions
regarding the “9/11 Disaster.” More importantly, I will try to brie ﬂy explain
within the limited space remaining in this book, the relationship between
the “9/11 Disaster” event and the GA emergency release materials that we
have been progressively teaching within the public forum since the end of
2000.  It is within our understanding of the '' Big Picture '' drama  that Real
comprehension  of events such as the “9/11 Disaster” can be gained. Real
comprehension is essential if we are to recognize that this seemingly isolated
event of international horror represents the greater reality of what is called a
''Trigger Event ,'' which is an external, mass event that is covertly
orchestrated by seemingly unrelated ''hidden forces '' from “behind the
scenes”—an event that represents the “pressing of the start  button” within
the invisible Illuminati World Management Team machine. Trigger Events
are orchestrated strategically from off-planet sources  in order to set in
motion, through remote psychotronic mobilization  of the unsuspecting on-
planet Illuminati force,  a series of national and global changes  that are
intended to move the global arena toward fulfillment of hidden Fallen
Angelic/Intruder ET objectives. It is through understanding these hidden
objectives  as they exist behind and within the global drama that we, as
individuals and nations, are empowered to choose educated, effective action
through which the ideals of peace, freedom, brotherhood and love can be
attained .  
               OWO MASTER PLANS, GA STATE OF WAR ALERT  
                              AND IMMINENT CRISIS ORDER   
    The '' 2001 Update '' materials  preceding this text were completed
and submitted to the publisher in early July 2001 . They contain a brief
summary of GA emergency release dispensations  that have been
progressively provided since the September 12, 2000, Edict of War  was
issued by the Fallen Angelic/''Intruder ET'' UIR .¹ Before any obvious
                
       ________________________________  
         
                          1.     Anunnaki/Andromie/Centaurian/Zeta/Drakonian/Reptilian/Illuminati “Unholy Alliance"
                                     
                            337  
                                 

                                                                                                                              
The 9/11 WTC/Pentagon Attack and the Illuminati One World Order  
indication  was made apparent within the “external world,” the GA ’ s
information provided since September 2000 and brieﬂy summarized in the
original “2001 Update” section of this book, revealed that contemporary
Earth is caught within a long-anticipated, “presently hidden ” inter-
dimensional, Interstellar War. A war that would become “all too real” to
us in “3D” terms  if humanity was unwilling to assist Emerald Covenant
nations in peacefully securing Earth’s Templar/Star Gate Complex  from
further Fallen Angelic/Intruder ET/Illuminati in filtration before 2003.
Within the GA security release dispensations we were gently shown that not
only was humanity facing the challenges of planetary physics  inherent to
natural SAC’s, but we were also faced with progressively growing obstacles
created through the actions of “human” Illuminati  races manipulated by the
Fallen Angelics. The 2001 GA revelations exposed the long-term, highly
organized and progressively orchestrated Fallen Angelic directed Atlantian
Conspiracy² '' Illuminati OWO Master Plan ,'' which has been a core
commonality between the various competing Fallen Angelic/Intruder ET
races since 9560 BC Atlantis.  This information revealed the true scope  of
the drama we are presently in3, the scope of this drama and the long-term
Illuminati OWO Master Plan is massive  and “bone chilling” (if you don’t
understand the peaceful solutions).  
    Of greatest signi ficance, the 2001 GA revelations brought into focus the
details of the intended stages  of the contemporary phase  of the Illuminati
Master Plan , so we can become aware of the basic progression of events we
would see  should the Illuminati Master Plan advance. When the Anunnaki
races defected from the Emerald Covenant to support the UIR’s September
12, 2000, Edict of War, the various Illuminati OWO Master Plan agendas of
previously competing Fallen Angelic/Intruder ET factions were blended into
a dominant uni fied strategy . This uni fied strategy combined various previous
initiatives of several Fallen Angelic groups into the UIR Illuminati OWO
Master Plan,  directed by the Necromiton-Andromie  force. Renegade Fallen
Angelic legions of Omicron-Drakonian,4 Odedicron (Reptile-avian),
Necromiton5 and rebel Anunnaki who refused to join the UIR are still
attempting to orchestrate their original OWO agendas, but all have lost
critical amounts of support from Earthly Illuminati collectives. As of October
2000,  the predominant force  within the covert Interior World
Government ( see Voyagers I ) Illuminati World Management  Team  is now
the UIR Fallen Angelic collective. This '' shift in Illuminati administration ''
has already become subtly apparent within the external, political
maneuverings of various nations since October 2000 . The subtle shifts
(and some not-so-subtle) within our global political arena, which have taken
place since October 2000 in response to the covert influence of the
September 2000 UIR Edict of War, represent only the beginning
externalization  of the UIR OWO agenda into the visible “Official Reality”
arena.  
                             ________________________________
                   2.     See  Forbidden Testaments of Revelation , forthcoming.
                     3      lbid.
                     4.     Dragon Moth
                     5.     Andromie Beetle-insectoid-hominid 
                  338   
                 

                                                 
                                                                
                             Star Gate-6 and the Selenite Crystal Temple Network
                                                      
                                                      STAR GATE-6  
                       AND THE SELENITE CRYSTAL TEMPLE NETWORK  
                
    Since the GA ’ s direct intervention with initiation of the Bridge Zone
Project  in 1983 (see “The Bridge Zone Project” on page 142), the GA  have
been peacefully and diligently working to prevent advancement of the
various competing Fallen Angelic/Intruder ET and Illuminati OWO agendas
on Earth. Through the peaceful tools  of inter-stellar Emerald Covenant Co-
evolution Peace Treaty negotiations and strategically applied and directed
Masters Inter-Galactic Templar Mechanics , there was great hope of avertin g
the long-anticipated 2000-2017 SAC Final Conﬂict drama. The GA had also
explained from the beginning that whether or not Illuminati OWO
dominion agendas could be averted would depend a great deal upon the
progression of choices  made by both earthly Human and Illuminati
collectives.  Though several major victories in the name of Human freedom
have been peacefully won through progression of the GA Crisis Intervention
Initiative, the realities of potential advancement of Fallen Angelic and
Illuminati OWO dominion agendas has not, as yet, been brought to an end.
Alongside the recent collection of strategic victories won through the GA
Peace Effort,  there have also been numerous setbacks.  The most notable
recent setbacks to the GA Peace Effort are the September 12, 2000,
Anunnaki defection from the Treaty of Altair and resultant UIR Edict of
War , and recent challenges associated with the Montauk Project . These
issues of inter-stellar political setback have spawned further, mounting
concerns regarding the challenges of planetary physics  posed by the
progressing 2000-2017 SAC. Emerald Covenant nations have not only
entered a State of War Alert  in response to the building tensions, continued
volatility and the September 2000 Edict of War within the inter-stellar
political  drama —they are also under a State of Imminent Crisis Order . The
Imminent Crisis Order was issued due to the progressively increasing
instability of Earth’s planetary Templar Complex  and potentially
cataclysmic reactions, in terms of planetary physics, that may now occur
during the 2000-2017 SAC as a result of the UIR’s more aggressive use of EM
scalar pulse technologies.  
    During our Labor Day 2001 workshop  of September l-3, the GA
provided a new level of high security data pertaining to two areas of pending
crisis.  Attending Indigo Children were asked to assist Emerald Covenant
nations in an immediate Top Priority Crisis Intervention strategy , and we
were provided with additional introductory training in even more advanced
Masters Templar Mechanics, called “ Veca-Code Mechanics ,” and planetary
healing outreach. The first area discussed was that of the present acceleration
of Stellar Wave Infusions  (see “Stellar W ave Infusions” on page 466) into
Earth’s Planetary Shields. In  May 2001 , as necessitated  by the September
12, 2000,  Anunnaki defection from the Treaty of Altair agreements, the
Maharaji Council triggered early activation of the D-6 Sirius B Star Gate
(Density-2), in order to begin overriding Nibiru’s Photo-sonic hold  on
Earth’s planetary Merkaba, Templar and EM fields. If this initiative were not
taken, the Anunnaki of the UIR intended to use the Nibiruian Templar      
339                    

                                            
    
                    The 9/11 WTC/Pentagon Attack and the Illuminati One World Order
connection to force cataclysmic pole shift  on Earth by 2008; Earth’s Templar
had to be freed from its arti ficial Nibiruian alignment by 2003  or pole shift
could not thereafter be prevented. Star Gate-6 was not originally scheduled
to enter its opening cycle until 2008 , four years after the 2004 opening cycle
of Star Gate-5 Alcyone. One of the greatest challenges  posed to Earth by
expedition of SG-6 activation is that of retaining the delicate EM balances
of the planetary grids  as Earth’ s Planetary Shields6 rapidly activate in
accelerated sequence  in response to ampli fied and expedited D-4, D-5 and D-
6 Stellar Wave infusions. The Emerald Covenant nations took this step of
mandatory Crisis Intervention as a '' Calculated Risk ,'' knowing that it would
be very difficult  to realign and hold balance within Earth’ s T emplar as the
SG-6 infusions progressed. This step would never have been taken  if it had
not been the only remaining strategy  available to prevent the UIR
Anunnaki from using Nibiru’s arti ficial link (Nibiruian Diodic Crystal, or
NDC, Grid; see page 311) to Earth’s Templar to force rapid pole shift. The
only other option  for protecting Earth populations from pending cataclysm
during the 2000-20l7 SAC would be physical evacuation ; an action that
would have its own inherent set of nearly insurmountable challenges.  
    Following the September 12, 2000, UIR Edict of W ar, the UIR had
initiated accelerated reactivation of the Montauk Project  (see page 136)
facilities in Long Island, NY , for use in ampli fied ULF EM scalar pulse
transmission . If the UIR was successful in their intention of forging a link
between the Rigelian Zeta controlled Montauk facility  and the Anunnaki
controlled NDC-Grid  at Stonehenge, nothing would be able to prevent
advancement of the UIR pole shift agenda. By November 2001  Emerald
Covenant nations initiated an Imminent Crisis Order  in relation to Earth
Crisis Intervention efforts; as part of this emergency intervention initiative,
SG-6 and the l2-dimensional Star Gate passage known as the Halls of
Amorea7 were activated. Since May 2001, continual Photo-sonic
transmissions from SG-6 Sirius B  have been progressively used to hold
stable and gently realign the vertical axis of Earth’s planetary Merkaba field;
to prevent geoclimatic and tectonic instability as Earth’s Planetary Shields
commence rapid D-6 activation. ln July 2001 , the central control
installation of the NDC-Grid  beneath Stonehenge was re-coded to a  D-12
program , severing the long-standing, arti ficial link between Earth’s Templar
and that of Nibiru. There are 24 subterranean main control ''Nibiruian
Crystal Temple Networks '' on Earth that serve as the main global
transmission networks of the NDC-Grid “Checkerboard Matrix” Planetary
Templar control program. The 24 Nibiruian Crystal Temple Networks on
Earth must also be manually re-coded to a 12—code Pulse  before the end of
2002 , if the 2003-2008 pole shift is to be averted. With the assistance of the
Azurite “ Signet Rainbow Roundtables ” Templar Security Team, the GA
have been advancing these planetary healing efforts through a program called
the Emerald Covenant Masters Templar Planetary Stewardship Initiative
(AKA “ Planetary Christos Realignment Mission ”). 
                                ____________________________
  6.   scalar templates
  7.   see Masters Templar  Coursebook , forthcoming.    
 340 

                                                        
                                                       Star Gate-6 and the Selenite Crystal Temple Network
    
    Note:  A few of the many “ Supplicant Sites ,” or smaller Selenite and
Quartz Crystal Matrices  that are connected to the main Nibiruian Crystal
Temple Network sites as transmission tributaries,  were discovered recently
in Mexico by scientists.  Information of this discovery was released to the
public this year , with expedition photographs  showing breath-taking, massive
Selenite Crystal rods. These Selenite rods are small by comparison  to those of
the many main network installations. Photos and information concerning the
“Ofﬁcial Science” aspects of this discovery can be found on various Internet sites.
Since childhood, I knew that this ancient Inter-stellar Crystalline Photo-sonic
communications and transmitting network existed. On several occasions, GA
Priests of UR escorted me through the Cloaking Shield  (Photo-sonic security  force
ﬁeld) of the subterranean Crystal Caverns system  that links Earth to the portals
of the Inner Earth Time Cycle. The Nibiruian Crystal Temple Network
communications and transmission network is connected to and run through the
Crystal Caverns system. The Emerald Covenant Maharaji of Sirius B  seeded
the original installations of the Crystal Temple Network over 3 million years ago,
during Human Seeding-2; since that time additions of “younger” Nibiruian
Selenite rods were added during different historical periods when Nibiru was under
Emerald Covenant protection. Nibiruian Anunnaki seized control  of the
Nibiruian Crystal Temple Network during the 25,500 BC Lucifer Rebellion  in
Atlantis and used it in conjunction with the NDC-Grid, to control the main
Axiatonal and Ley Lines of Earth’ s Templar, and to progressively block
Guardian nation communication  within Earth since the 9558 BC Atlantian
ﬂood. . 
     During the 1992 Emerald Covenant Pleiadian-Sirian Agreements  the GA
gained partial, temporary  access  to the Nibiruian Crystal T emple Network,
which has enabled them to regain partial protection  over some of Earth’s Templar
and to open limited communication and Photo-sonic transmission lines to Earth.
The Nibiruian Annunaki and Galactic Federation began activating the
Crystal Temple Network for scalar pulse transmission in 1942,  in an
unsuccessful attempt  to block Zeta and Illuminati races from conducting the
1943 Philadelphia Experiment , which would hamper the Anunnaki’ s intended
2000-2017 OWO dominion agenda. Presently “the battle is on ” as the UIR,
several smaller competing Fallen Angelic collectives and Emerald Covenant nations
covertly struggle to gain primary control  over Earth’ s Crystal Temple Network
before 2003 , using Planetary Templar and Merkaba (EM ﬁeld) Mechanics and
scalar pulse technologies. The recently revealed Selenite caves  in Mexico  are a
very small Supplicant Matrix,  recently activated  by the UIR as a scalar
transmitting station;  this installation connects to the larger tributary systems
surrounding the main Nibiruian Crystal Temple  base in Central Mexico . The
UIR permitted this Selenite cave to be “found”  by releasing the Cloaking
Shield surrounding it, in preparation  for their intended covert physical
infiltration  of   Earth. For the Nibiruian Crystal Temple Network bases to activate
 at full scalar-transmission capacity , the Cloaking Shield buffer must be de-
activated, which leaves the usually invisible/cloaked installations vulnerable to
   inadvertent Human “discovery.” Other, related Crystal Temple cavern systems,
    containing Selenite, Quartz, Amethyst, Diamond  and various types of Beryl
     deposits,  will be “found” within the next 3-9 years;  two are due for activation
       and ' 'discovery '' around the end of 2002  (locations not yet revealed to me by GA   
        341  
          
                                                                                                                                                    

                   
                   
                    The 9/11 WTC/ Pentagon Attack and the Illuminati One World Order
for security reasons) . More information on the Nibiruian Crystal Temple Network
and related subjects can be found in our Masters Templar Coursebook (now
available) and forthcoming  Forbidden T estaments of Revelation book.
    The UIR and Illuminati collectives have a vested interest in
preventing the Emerald Covenant nations from re-coding the Nibiruian
Crystal Temple Network to a 12-Code Pulse, as this would place these
Planetary Templar Control scalar pulse transmission stations out of the
UIR’s D-11 frequency range.  Under natural D-12 programming, the NDC-
Grid and Crystal Temple Network would be inaccessible to UIR
manipulation  and could then be used by Emerald Covenant nations to
rapidly place Earth’s Templar, and the “ Montauk Problem”  under a D-12
Security Seal.  If Earth’ s natural D-I2 Planetary Maharic Seal can be
stimulated into activation, any further advancement of the UIR Illuminati
OWO Master Plan and pole-shift agenda will be prevented. The UIR OWO
Illuminati Master Plan, which now hinges on their ability to implement a
global mass '' Frequency Fence '' by 2003,  requires the use of the Nibiruian
Crystal Temple Network for continual transmission of the Frequency Fence
Sub-ULF scalar pulse program. During the GA/Eieyani Labor Day 2001
workshop of September 1-3, the GA explained that the UIR had initiated an
aggressive, expedited step of advancement of their Illuminati OWO Master
Plan.  Expedition of their already delayed OWO Master Plan was successfully
initiated by August 30, 2001 , in an attempt to gain control of the Nibiruian
Crystal Temple Network before Emerald Covenant nations could complete
their intended l2-Code Pulse re-programming before 2003. GA Templar
Mechanics conducted during the January 2001  Florida Azurite gathering
had temporarily thwarted  the UIR from achieving full activation of the
Montauk facility. The GA had successfully re-programmed to a natural 12-
Code Pulse, the main planetary Axiatonal Line  connected to Montauk,
which had been used for UIR global scalar pulse transmission. By September
2001 the UIR had activated, and interconnected for purposes of frequency
amplification , a series of   smaller global   Ley   Line tributaries    running   through
the Montauk facility.  
            
   TRION-MEAJHÉ FIELDS AND EXPEDITED AMENTI OPENING
     Due to the UIR’s August 12-30, 2001, full activation of the Montauk
facility, combined with the May 2001 early activation of Sirius B Star Gate-
6, Earth is now in “ Big Trouble .” During our Labor Day 2001 workshop, the
GA/Eieyani calmly explained that due to this recent advancement of the
UIR Illuminati OWO Master Plan they would now have to take “ final
emergency measures ” to prevent pole shift and to stop further expedition of
the UIR agenda. We were provided with new, introductory teachings on
Veca-Code and Trion Field Masters RRT Templar Mechanics , through
which we can assist the Emerald Covenant nations in creating a Planetary
Trion  (or “Trinity”) Field . A successful Trion Field  will allow Earth’ s now
precariously balanced EM grids, Planetary Shields and Merkaba Field to be
directly linked  into Planetary Shields of the Inner Earth  time continuum.
Earth’s Templar will be simultaneously linked into the Planetary Shields of a
free counter-part of “Future Earth” that exists in a Trans-Harmonic
Accelerated Time Cycle called the Meajhé Zone .8 The Planetary Shields  
342      

                                                      
                                                         Trion-Meajhe’ Fields and Expedited Amenti Opening
from the two other Time Matrices will serve as massive Photo-sonic
Anchoring Rods  (huge standing-columnar-waves of 15-dimensional,
inaudible sound ) called Trion Pillars . Once anchored in Earth’s Planetary
Shields, the Trion Pillars will draw Earth’s Star Gates and Shields into
natural alignment with the Inner Earth time continuum, so the Bridge Zone
Time Continuum Shift can progressively proceed. This “three-way link” or
“Trinity Bond” between the three Time Matrix systems  will create enough
D-12  (and higher) frequency thrust  to allow the Guardian nations to
complete their 12-Code Pulse re-programming of the Nibiruian Crystal
Temple Network and Earth’s Templar before 2003 . If the Trion Field is
successful, the UIR will be unable to fulfill their intention of expediting their
Frequency Fence project in 2002-2003 to rapidly advance their OWO
agenda. Earth’s Planetary Shields will progressively return to their organic
EM balances under a natural D-12 Planetary Maharic Seal , averting pole
shift and preventing further Fallen Angelic/Intruder ET infiltration and
manipulation during the SAC. This is the focus of the Founders’  Planetary
Healing endeavors and Peace Efforts, from now until 2003 end. Much hangs
in the balance.  
    Presently Earth’ s Planetary Shields are activating at an alarming rate,
drawing in massive amounts of frequency from Sirius B SG-6 due to the
UIRs’ full activation of the Montauk facility and related installations. This is
causing a progressive Time Acceleration  of Earth’ s passage through the 2000-
2017 SAC. If Earth does not succumb to the now-advancing UIR Illuminati
OWO Master Plan, the '' Amenti Ascension Schedul '' (see page 201) will
reach ful fillment much earlier  than originally anticipated. Emerald
Covenant races are unable to prevent  this undesired acceleration of Earth’ s
SAC, as the UIR’s psychotronic transmissions have triggered the automatic
frequency acceleration sequences  in Earth’ s Planetary Shields; the most the
GA can hope to do is to stabilize Earth’s Templar  as the SAC rapidly
unfolds. The opening of the Halls of Amenti Star Gates , originally due to
occur in 2012, the coming 2017 “ Three-Day Particle Conversion Period”
and all Stellar Wave infusions  initially due prior to 2012 will now occur
between 2003-2006 . If the Trion Field  is successfully created before 2003 , a
''frequency blanke '' called a Meajhé Field,  can be constructed within
Earth’s magnetosphere and outer atmosphere , which will buffer Earth  from
many effects of these accelerated frequency infusions. The Meajhé Field,
created through a temporary merging  of Earth’ s Planetary Merkaba Field  and
that of the Meajhé Zone Time Matrix, can absorb  much of the excessive
frequency  that will otherwise bombard  Earth’s Planetary Shields  and
collapse Earth’s magnetic fields and atmosphere during the Three-Day
Particle Conversion period.  
     In the Labor Day 2001 workshop most of us were deeply sobered  by the
GA/Eieyani’s technical physics answer to the question of “ What will Earth
life experience during this accelerated phase before the Three-Day Particle
Conversion Period? ” This information is too lengthy for inclusion in this
book; I will simply say that  if the Meajhé Field is not created  “you wouldn’t
_____________________________  
8.      See: Forbidden Testaments of Revelation , forthcoming.   
343 
                                                                                                                                                      
    

                       
                        The 9/11 WTC/ Pentagon Attack and the Illuminati One World Order
want to be here.” One summary clue  is the scienti fic term called Hydrogen
Burning . All Emerald Covenant Crisis Intervention efforts  are now
directed to creating the  Trion Field and Meajhé Field  on Earth and blocking
the UIR Frequency Fence, between now and 2003 . There is no time left for
wasting energy with Illuminati sparring matches or countering
disinformation campaigns ; “the Game is On ,” people, and the advanced
Masters Planetary Templar Mechanics is literally the only solution  to this
dilemma. If the  real truth  as explained above is a “bit too much to handle,”
then perhaps the Big Picture will begin to make more sense through
understanding the smaller, but equally bothersome, reality of the  now-
rapidly advancing UIR Illuminati OWO Master Plan . On the last day of
our Labor Day 2001 workshop, September 3, eight days prior to the 9/11/
2001 Trade Towers/Pentagon Terrorist attack , the GA revealed the
second, interconnected “pending crisis” issue . The UIR and Illuminati had
finally managed to fully expedite activation of the Montauk facility and its
global scalar pulse transmission network . The UIR’s schedule of advancing
their Illuminati OWO Master Plan, which originally involved initiation of
the “ 2003  Dimensional Blend Experiment ” (see page 110) and “ 2004
Frequency Fence,” had been expedited and fully set in motion . Phase 1 of
their intended Frequency Fence would need to be forcibly implemented
before 2003  if they were to prevent Emerald Covenant nations from
permanently securing under a natural 12-Code Pulse the 24 Nibiruian
Crystal Temple Network transmission sites. More disturbingly, the GA
revealed that the first major move  in expediting the UIR Illuminati OWO
Master Plan  into externalized motion  had just begun . The GA security
release data revealed in the Labor Day 2001 workshop was not the first
warning  the GA  had provided regarding the potentials of horror  inherent to
the Illuminati OWO agenda.  My first chilling glimpse  at this reality came in
October 1999,  about one year before  the inter-stellar political drama
escalated to its present state of chaos through the consolidation of Fallen
Angelic invasion forces in the September 7-12, 2000,  formation of the UIR.
                     
                THE OCTOBER 1999 CLASSIFIED DOCUMENT,  
                  PSYCHOTRONICS, MONTAUK AND OWO  
    In the only  ''Classifie '' dispensation  of data the GA  had ever given, a
53-page manuscript  was transcribed in October 1999 , detailing some of
what the then-dominant Zeta Rigelian-Dracos/Drakonian and Anunnaki
OWO forces had in store if the GA Peace Effort could not prevent
advancement of their agendas . Only a few copies  of this transcript were
produced, and I was permitted to share them with only a few close friends and
people directly involved in the GA work. The information contained in this
GA dispensation detailed some disturbing Illuminati actions  that were
already occurring in 1999  and revealed data on a few very frightening
potential events  that would emerge into “Official 3-D reality” if the Emerald
Covenant Crisis Prevention Initiative failed. The Emerald Covenant
Founders’ races had deemed the October 1999 Classified information
unsuitable for public release at that time.  They knew the information would
generate unnecessary fear  over events we might likely avert  via GA  Peace 
344 
                 
                       

                                           The October I999 Classi ﬁed Document, Psychotronics, Montauk and
 Efforts. These revelations of Illuminati activities would also serve to initiate
 an even great slander/disinformation/public attack campaign  against the
    GA  work and me personally , among Anunnaki representatives within the
     New Age Movement and Zeta-Dracos representatives in the UFO
 Movement. The deciding factor preventing this data from being authorized
 for public release was that disclosure  would cause the then- extremely fragile
  and rapidly disintegrating 1992 Pleiadian-Sirian Agreements  to be
 shattered completely.  
                      Unknown to me at the time, in 1999,  Emerald Covenant nations were
deeply immersed within terribly volatile, top-security politically sensitive
negotiations  with major Anunnaki nations, attempting to persuade them to
honor their 1992 peace treaty promises. In 1999, Emerald Covenant nations
still had hope  that the 2000-2017 Final Conﬂict drama on Earth could be
averted through ful fillment of the 1992 Pleiadian-Sirian Agreements. The
''last ditch attempt '' at resurrecting this failed 1992 peace treaty between
Guardian and Anunnaki legions was the July 5, 2000 , Treaty of Altair,
which had failed miserably  by September 12, 2000, resulting in the UIR
Edict of War. Throughout 1999, the GA and Emerald Covenant nations had
been trying desperately to prevent the event of war with the Anunnaki ,
due to their NDC-Grid stronghold over Earth’s Templar. Factions of the
Anunnaki legion (ruling portions of Galactic Federation, Ashtar Command,
Alpha-Omega Order Melchizedeks and Nibiruian Thoth-Enki-Zephelium
Anunnaki) had defected  from the Pleiadian-Sirian Agreements and made
“friendly enemies deals”  with a faction of the competing Dracos  Omicron
Drakonian hybrid race in March 1999.  In the Dracos-Anunnaki agreements,
the Nibiruian Councils  (of “Nine,” “T welve” and “T wenty-Four”) mandated
that a program of Human Genocide  would be immediately initiated  to
reduce the numbers of Human populations,  so easier advancement of the
Anunnaki-Dracos Illuminati OWO Master Plan could proceed.  
        The October 1999 Classi fied information detailed that a type of  
Psychotronic scalar-pulse technology  called a “ Phantom Pulse ” would be
transmitted to key locations  on Earth via the Montauk facility  and low-
scale activation of portions of the Nibiruian Crystal Temple Network . The
“Phantom Pulses” would progressively amplify  over time, beginning within
the areas of Earth’s Planetary Shields into which they were sent, due to the
progression of the SAC.  The purpose of the Phantom Pulse transmissions was
to progressively send digitally encoded Psychotronic Mind Control
directives  to certain segments of international populations , through which
the “3-D event” of Human war,  escalating rapidly into a WW3
“Armageddon” scenario,  would unfold within the Human drama. The
progression of '' Trigger Events '' through which this “Human War” would be
   progressively instigated  via Psychotronic transmission, would not begin until
  the Phantom Pulses had reached a critical mass transmission strength  in
    Earth’s grids. In synchronization with the originally scheduled progression  of
   Earth’ s SAC, the first set of Psychotronically induced “ Trigger Events ,” and
  their resulting “3-D political actions”  orchestrated by targeted individuals
    and collectives, were intended to begin in 2002 . The October 1999 classi fied
     document further explained that a smaller, less developed version of this            
technology had been tested by the Rigelian Zeta-Dracos Alliance in the area  
             345   
                                                                                                                                               

                         
     
       The 9/1 1 WTC/Pentagon Attack and the Illuminati One W orld Order
of Bosnia , and that it was “working successfully” to instigate Human
political unrest . The document further revealed that between  June-July
1999  the Zetas, with assistance from the Anunnaki, reactivated a portion of
the Zetas’ scalar transmission facility at Montauk  to amplify the capabilities
of this Psychotronic technology.  
    It was further explained in the October 1999 dispensation, that on
August 11, 1999 , the first set of Three Phantom Pulses,  directed to
American targets , was issued by the UIR. The first pulse sequence was sent
into the Roswell, NM,  vortex system, the second to the Castle Rock Vortex
in Sedona, AZ , and the third was transmitted into the Montauk-Long
Island-Manhattan, NY,  vortex system. The document then mentioned that a
second set of Phantom Pulses was intended  to be issued into Primary
Vortex-2 Jerusalem, Israel on November 18, 1999  and the third and final
set of “ first phase” pulses were scheduled for China  on December 12, 1999.
All of these targets were hit with ampli fied Psychotronic scalar Phantom
Pulses as scheduled.9 The information pertaining to the Anunnaki-Dracos-
Zeta intended dates  of first wave Phantom Pulse transmissions was obtained
by Enoch,  the Density-3 Immortal Jehovian Anunnaki-Human hybrid, who
had appealed for an Emerald Covenant Redemption Contract  in 1983.
Since 1983, Enoch had remained loyal to the Emerald Covenant, and also
throughout the 1992-1999 Pleiadian-Sirian Agreements, following his long
stint of service as a major player within the Jehovian Anunnaki OWO
dominion agenda  between 10 AD and 1983 . In 1999, Enoch was able to
secretly obtain this Anunnaki military strategic information from his
contacts within the Jehovian Anunnaki legion (Arcturus, Orion, Sirius A).
The information presented in the October 1999 Classi fied document was
entrusted to me only so that I would begin to really understand the
seriousness of Earth’s position , and so that I could present some of the
information on solutions to the public in 1999 . This public presentation
was conducted and filmed on December 12, 1999 , in a large NYC
workshop , through which the first grouping of the Azurite Templar Security
Team was formed. At this time the Emerald Covenant agenda  was focused
exclusively upon continuing GA/Founders Emerald Covenant inter-stellar
political negotiations  in hopes of bringing the Anunnaki and their Illuminati
forces back into the Pleiadian-Sirian Agreements peace treaty, and upon
preparing the Azurite Security Team for Masters Planetary Shields Clinics.
Planetary Shields Clinics are the only technology  through which this OWO
agenda and Phantom Pulse technologies can be stopped.  
    The Emerald Covenant nations, with help from the East Coast U.S.
Azurite Team, achieved the first major, and utterly essential preliminary
victory in their Crisis Intervention Program —“Grounding of the Stellar
Bridge” on a “12-Code Pulse” during the “ Transcendence Day Stand” of
January 1, 2000.  With this accomplishment, Emerald Covenant nations
were finally “ in the game ” and had a decent chance of protecting Earth and
humanity from the advancing Illuminati OWO agenda and Nibiruian
                        __________________________                 
                     9.     GA began immediate intervention measures, but due to Nibiruian Anunnaki hold over
                             the Crystal Temple Network, could not fully prevent the Phantom Pulse transmissions
                   
                  346
                 
               
                    

                                    
                                                     Sleepers, Terrorists, Remote Viewing, RITs and the NET
Council mandate of Human Genocide. The “ Frequency War”  was on
between the Guardian and Fallen Angelic nations; the victor would control
Earth’s Planetary Templar Complex and thus the ultimate fate of the 2000-
2017 SAC and consequently Earth’s immediate destiny. When Anunnaki
legions finally fully defected from the Emerald Covenant Treat of Altair on
September 12, 2000, joining and expanding the forces of the UIR,  the
Emerald Covenant nations went under a State of War Alert.  The October
1999 Classi fied document covered a variety of related issues, focusing on
peaceful solutions;  this document is too large to include here and more
recent data is far more pertinent. The most intriguing aspect  of the October
1999 dispensation is that it clearly identi fied that the GA  had learned that
the then-dominant OWO dominion agenda of Fallen Angelic/Intruder ET
forces had an established agenda  of orchestrating Human Genocide  for
specific mass population reduction.  The Zeta-Dracos-Anunnaki force
intended to covertly use Psychotronics  to “Trigger” speci fic actions within
the ranks of their Illuminati “puppets”  in the Interior W orld Government,
to remotely i nstigate WW3  among Human nations. Reducing specific
Human and Indigo Child populations on Earth was part of their larger Earth
infiltration and physical invasion plan,  through which they intend to
progressively secure, first covert then overt, physical presence  on Earth, in
preparation for seizing dominion of Earth and the Halls of Amenti Star
Gates.  
                     SLEEPERS, TERRORISTS, REMOTE VIEWING,  
                                           RITs AND THE NET  
    Following the October 1999 classi fied dispensation, the GA
infrequently provided bits of additional non-speci fic information  pertaining
to various Fallen Angelic/Intruder ET and Illuminati intentions,  such as
Psychotronically triggered Illuminati terrorist acts,  including the use of Bio-
terrorism . I was told, in various brief personal discussions with GA members
in 1999 and early 2000, that there were “Illuminati Sleeper groups”
(unnamed and unidentified) of various nationalities scattered within about
15 major  (unnamed) countries . They said world governments knew since
their beginning formation in the 1960s-1980s that the various “Sleeper”
Terrorists Groups existed and had most of them already under constant
surveillance. The “Sleepers” were intended as the eventual targets of
Psychotronic ''Triggering '' launched by the Zeta-Dracos-Anunnaki Fallen
Angelic collectives if their OWO Master Plan progressed beyond 2002 . The
GA did not stress the “Sleepers” as being the primary threat to planetary
security; the greatest threat was the intention of the Fallen Angelic forces to
trigger Wars between Nations . In 1999-early 2000,  the Illuminati Sleeper
groups were not intended  as the force that would start  the ''WW3 '' drama;
the Fallen Angelics simply intended to use them after the fact  of major
global war , as covert militia operatives. The GA intended to warn the
public of any known Sleeper activity if that ''time ever came. '' Our
attentions were focused upon securing Earth’s Templar from further Fallen
Angelic/Intruder ET in filtration and upon peacefully preventing further
347 
                                                                                                                                      
                                                                                                                                         

  
                      
                       The 9/11 WTC/ Pentagon Attack and the Illuminati One World Order
advancement of the Zeta-Dracos-Anunnaki Illuminati OWO Master Plan
through Masters Planetary Templar Mechanics, in order to prevent WW3.
  The Emerald Covenant nations have kept Sleeper groups under
surveillance  whenever possible, but this is often dif ficult, as they are
frequently moved around to different locations. The GA explain that
Illuminati “Sleeper” groups are moved about within the many geographical
locations on Earth where the planetary Axiatonal Lines, Ley Lines,
Planetary Shields and Crystal Temple Networks are controlled by Fallen
Angelic/Intruder ET collectives . In these areas Emerald Covenant nations
face great difficulty in electronic, Photo-radionic and Photo-sonic
surveillance as the Fallen Angelics use “jamming” scalar pulse frequencies to
“retain their privacy.” “ Remote Viewing,”  or mental surveillance through
projection of 3-D consciousness into the D-4 “Astral” field, is the most
effective method of Sleeper surveillance, but this too has its drawbacks in
relation to monitoring of Fallen Angelic/Illuminati operatives. A small
group in each Illuminati Sleepers force collective is trained in Remote
Viewing detection,  by their Fallen Angelic directors; these individuals can
sense “incoming astral presence.” Remote Viewing technology is far more
developed than is realized in mainstream society . Not only are there many
human and Illuminati Remote Viewing surveillance teams presently active
on planet, but there are also several collectives of highly trained “Remote
Interactive Teams” or “RITs ” that utilize advanced astral field technologies
for D-4 astral interaction and manipulation of individuals and populations.
These groups of “higher ranking,” Ultra-security clearance Illuminati
operatives are trained literally in Astral Combat and In filtration. 
            In some Earth locations, large underground Illuminati laboratories  are
set u p for training, tracking and directing RIT programs; these facilities
utilize advanced bio-electrical technologies  and mechanically transmitted
EM currents  combined with induced neurochemical compounds  to “force”
RIT subjects “out of body” via DNA Template/Pineal stimulation. Most
Illuminati RIT members do not realize that they themselves are fully
Tagged  a n d  t h a t  t h e i r  t r a i n i n g  a g e n t s  k e e p  t h e m  u n d e r  continued-
surveillance mind control . More advanced “Master RIT Programs” utilize
skilled consciousness projection without the use of mechanical, chemical or
external electrical support . Such “Master RITs” are few and far between
because development of natural consciousness projection skill  requires
sustained DNA Template activation and higher-dimensional consciousness
integration, which presents the opportunity  for the personal Soul, Over-Soul
             or A vatar consciousness level to  intervene  and inspire the RIT to peaceful  
           solutions. Fallen Angelic Master RIT Programs involved with Earth do not
  use Human or Illuminati subjects, as there is too great a risk of the earthly  
   subject becoming free from Fallen Angelic covert manipulation. Master RIT s  
     are composed fully of Fallen Angelic/Intruder ET ''dark soul/oversoul/avatar
        coll ectives, whose higher station of consciousness are also corrupted into
           exploitative,power-conquest agendas. Non-terrestrial Master RITs often       
       target Human and Illuminati individuals for intended ''bio-energetic field/
         
          
           348  
     
      

                            
                                                   Sleepers, Terrorists, Remote Viewing, RITs and the NET
Astral Attachment,” or in some cases for partial or full-body possession via
DNA Template bonding.The lower echelons of Illuminati RITs are often sent to deliver
frequency implants  called '' Tag'' into the D-4 astral- field of unsuspecting
humans. These digitally encoded EM implants  serve as dormant triggers  that
are activated and deactivated via targeted remote scalar pulse transmission,
causing the individuals to fall into Illuminati mind control  at times when
they are needed as covert Illuminati operatives. When the implant is de-
activated, the person “returns to normal” often with no conscious memory of
what transpired when the implant was active. Astral Frequency Implants, or
Tags, are very often used to control, activate and “awaken” Illuminati
Sleeper groups,  as they allow for specific instructions of action  to be
remotely transferred  via digital scalar pulse into the subject’ s mind. The
subject experiences them as “ personal thoughts ” or sometimes as “voices
from spirit/God,” etc. The Tags utilized by Illuminati RIT forces have a short
“life span” —their EM frequency programs become non-distinct and disperse
over time, thus requiring repeated remote “Tagging.” Tags also have a limited
receiving range ; if the subject’s body moves out of range of the intended
scalar pulse transmitting facility, the Tag will fail to operate. For this reason
there are a multitude of Tag Tracking Units  orbiting around Earth in the D-
4 frequency bands; these mechanical constructs track the Tags and serve as
scalar pulse relay stations for roving Tag activation. People can easily protect
themselves  from these seemingly elaborate Illuminati and Fallen Angelic/
Intruder ET schemes by simply consistently and frequently using the Maharic
Seal technique  (see page 496). The Maharic Seal manually activates the
natural D-12 frequency sub-harmonics  within the Human and Illuminati-
hybrid DNA template, creating an organic, temporary D-12 ''Frequency
Sea'' in the personal bio- field, DNA and consciousness. This D-12
Frequency Seal will clear astral Tags, prevent further Tagging  and block
Master RITs from bio-field Astral Attachment and DNA  bonding.  Our lack
of awareness as to the existence of these technologies and how to easily
protect ourselves against them is the only reason these forces can affect us.
          In relation to Emerald Covenant nations tracking Illuminati Sleeper
groups on Earth, Remote Viewing is the only effective method of
surveillance, but it is not a “foolproof” technology. Planetary Shields scalar -
pulse interference  creates perceptual “ buffer screens ” even to the D-4
Astral perception, and many Sleeper groups are hidden beneath'' holographic
insert fields ,'' which are mechanically generated  to “give false readings” in
Remote Viewing surveillance. Presently, the D-4 frequency bands of Earth
are literally surrounded by multiple layers  of Fallen Angelic constructed
buffer screens, holographic insert  fields and EM “Detection Blankets”;  this
planetary '' Astral Mess '' is referred to in the English language as “ The
NET”;  the “ Nibiruian Electra-static Transduction” field. The NET was
originally constructed in Atlantis by invading Nibiruian Anunnaki races
beginning in 25,500 BC, and was “anchored” into Earth’s Shields via the
NDC-Grid and Nibiruian Crystal T emple Network . In 9558 BC  the
Anunnaki fortified the NET, as they have at various times since then,
progressively intercepting all natural electrical transmission lines to and from
            Earth. Since 9558 BC the Anunnaki have been preparing the NET to be
                           
                            349  
                        
                                                                                                                                         

                        
                    
                       
                         The 9/11 WTC Pentagon Attack and the Illuminati One World Order
“lowered” into D-3 frequency bands as a Frequency Fence,  through which
they intended to gain easy control  over Earth populations during their
scheduled 2000-2017 SAC invasion.10 In the 1943 Philadelphia
Experiment,  Zeta Rigelian races “poked holes” (electromagnetic openings)
in the NET, enabling them to create a “doorway” into our space-time
coordinate. Emerald Covenant nations have been working to “break through
the NET” for many thousands of years, having some temporary, localized
victories in certain periods.  
           In the 1992 Pleiadian-Sirian Agreements  peace treaty , the Nibiruian
Anunnaki permitted Emerald Covenant nations limited use  of smaller
frequency relay transmission lines of the NET for communication purposes,
and promised to disengage the NET and its manipulative programs by 2000 ,
in preparation for the SAC. From 1992-1994  the NET was used to amplify
frequency through which the Zeta-Rigelian/Dracos Montauk facility  was
temporarily disabled.  During mid 1998-1999,  as the Nibiruian Anunnaki
launched their first mass defection  from the Pleiadian-Sirian Agreements,
the NET was interfaced with the Zeta-Rigelian/Dracos Montauk facility .
The NET-Montauk interface  was a collaborative Zeta-Rigelian/Dracos and
Nibiruian-Anunnaki effort to prepare for “ Lowering the NET ” into the D-3
Frequency bands via interface with earthly electrical grid technologies , to
create their jointly-intended sinister '' Frequency Fence ” mass mind control
network in 2004.  In September 2000 , the  NET  and Frequency Fence
initiative  came under UIR control  and the intended target date  for
beginning the Frequency Fence  was pulled forward from 2004 to 2002 .
Since 1998  Emerald Covenant nations have used their limited access to
NET transmission lines to begin “ poking holes ” in the NET. They are now
progressively working to dissolve the NET through  progressive 12-Code
Pulse re-programming  of the 24 Nibiruian Crystal Temple Network bases
through which the frequencies of the NET are anchored into Earth’s
Planetary Shields.  
    Over the last 100 years , Anunnaki races have been using the NET to
transmit speci fic technological information  to strategically positioned,
selected Illuminati Sleepers,  through which “ Human science”  could “slowly
advance” via covert Anunnaki “inspiration.” Since 1943 the Zeta-Dracos
have been running a counter “ ET technology training program ” on Earth in
hopes of capturing full control of the Anunnaki NET for use in their own
agendas. In 1999 the Anunnaki and Zeta-Rigelian/Dracos forces agreed to
“work together” to prevent Emerald Covenant nations from disengaging the
NET.  
    The “ Intruder ET technology training ” that has been literally
electronically inserted  “into the minds of men” was “ paced”  so that Human
science  would selectively advance  to the development of the specific
technologies  that would be needed to “ lower the Frequency Fence ” into the
D-3 frequency bands. The “man-made” electrical grid networks of Earth, and
literally all core radio, television, fiber optics, digital, EM pulse, sonic pulse
and microchip technologies  have emerged in human civilization through the
                           _______________________                                                                             
                  
                      10. “Galactic Federation” has been the primary “NET Maintenance Crew.”
                       350  
                       

 
                             
                                                     Sleepers, Terrorists, Remote Viewing, RITs and the NET
“genius” of people selected for covert “Fallen Angelic/Intruder ET
inspiration.” If Emerald Covenant races  had been able to provide humanity’s
technological education over the past 10,000 years , natural, thought-
directed subtle-wave technologies  built upon organic Creation Physics,
Core Scalar Template Dynamics and Sacred Planetary Templar Merkaba
Mechanics  would have long ago  transported Earth’ s peoples beyond all
“Earthly Limitations.” A race does not need airplanes when knowledge of
natural portal and star gate passage is used effectively. One does not need
light bulbs when one knows how to project self-contained, luminescent Bio-
Dion Field standing-waves, or when a civilization utilizes the natural global
free energy systems inherent to Earth’s Templar Complex. (A few things to
which we can eventually look forward when Earth becomes a free planet.)
Emerald Covenant training would have also served to provide the cultural
Spiritual and Social Ethics  through which the power of science can be used
to enhance and free consciousness  within the manifest experience, rather
than degrade and enslave it.  
     The earthly “ ground technologies ” that are now commonplace in
developed nations are not the benign and helpful  “miracles of human
science” that they appear to be . Their development was covertly
orchestrated off-planet, with the following intentions in mind:  
       • T o strengthen the frequencies of the D-4 NET , progressively
drawing the NET into the D-3 frequency band.  
     • T o suppress the natural DNA Template and Pineal activation  in
Humans that would normally occur during the 2000-2017 SAC, in order to
harness human consciousness  into the 3-D field. If our fourth DNA strand
were not partially blocked from activation, we would all be able to see that
the D-4 frequency bands  surrounding Earth and our local galaxy presently
look like an “ ET Parking Lot ”! If Human and Indigo DNA is suppressed,
they cannot effectively run the natural 12-dimensional Kundalini-Maharata
Life Force Currents  through the body , which are needed to run RRTs  into
         the Planetary Shields during SACs.  
         • T o amplify existing DNA mutations  in Human, Indigo and
   Illuminati races for lowered immune system response , to expedite biological
  deterioration of select populations in preparation for, and during, the 2000-
 20l7 SAC.  
          • T o create frequency weakness  in the D-4 Human, Indigo and
  Illuminati Astral body  so astral Tagging , bio-field in filtration and  Mind
    Control  can be easily and covertly orchestrated on a mass level.  
           • T o interfere with natural function of human brain-waves, blood
    and hormonal systems  in order to amplify humanity’ s present entrapment
  within the biological form.  
           • To distract human attention  fully into the external world and into
  disempowering dependence upon external technologies, so the natural
     powers of mind, spirit and DNA remain undeveloped . These are only some
   of the things our “modern” technologies were intentionally designed  to do
  for us; while keeping us joyfully enamored  with their apparent advantage
  (Atlantis revisited ! ). 
            But now that these technologies are here, they can be used to promote  
                 well being  rather than damage. (We are not an “anti-technology” religious-   
              351 
                       
                                                                                                                              
                                                                                                                      

                             
               
                        The 9/11 WTC/ Pentagon Attack and the Illuminati One World Order
dogma group!) At the expense of sounding redundant, I will point out that
the D-12 frequencies generated in the personal biology via consistent use of
the Maharic Seal will progressively clear and neutralize  the personal effects
of damaging electromagnetic emissions. If you can generate, through
educated mental direction of bio-energy , organic D-12 sub-harmonics
through nano-second activation of the dormant portions of your DNA
Template and bio-field, you do not need external “ devices ” such as “Tachyon
Field Interceptors ” to protect you from Earth’s present environment. There
are numerous other natural means of protection  that, if used with the
Maharic Seal , will amplify personal immunity  to such damaging '' invisible
Wave fields '' 
         If Emerald Covenant nations successfully create a D-12 Planetary
Maharic Seal  during this SAC, Earth’s environment will also progressively
heal, clear and neutralize the damaging effects of these technologies; the
technologies themselves will be steadily evolved  to a more advanced, ethical
order of Sacred Physics applications. In greater terms, advancement of our
Fallen Angelic/Intruder ET inspired “Human technology” was intended not
only as a control mechanism for Human populations; our “deceitful Stellar
neighbors” have bigger plans in mind . Contemporary Global technologies
such as the HAARP project, Montauk facility (see page 136), electrical and
nuclear power plants, computers, satellites and EM-sonic scalar-pulse
technologies were “given to us” so we would already have core technological
installations built on planet.  These technologies all have the  capacity to be
linked together , through the Nibiruian Crystal Temple Network and inter-
dimensional space craft, to create a massively powerful Photo-sonic Pulse
generation and transmission system . “Conveniently,” this is the precise
system that the Fallen Angelic/Intruder ET races need to forcibly ''blow
through '' the Cloaking Shields  (Photo-sonic security force fields) that
protect the portals  connecting surface Earth and the Inner Earth Time Cycle,
where the Halls of Amenti  Star Gate control Temples11 are located.
     Over the last 100 years, Human and Illuminati races have served the
Atlantian Nibiruian Anunnaki invasion force  well as a source of amnesiac
''technological slave labor ”; and our '' slave masters '' are intending to soon
reap the harvest we have so painstakingly cultivated unknowingly on their
behalf. It’s time to “Wake up, world!”  and face the hard fact that what we
are now experiencing in “3-D” is the beginning of an anticipated and highly
strategic climax of the long-nurtured Anunnaki Luciferian Covenant
agenda of 9560 BC.  (An agenda that has recently become more tightly
focused, powerful and organized, via consolidation of a variety of once-
competing OWO agendas, through formation of the UIR.) The diabolical
Luciferian Covenant itself is part of a much older, larger, less organized
collection of competing Fallen Angelic/Intruder ET  intended invasion
forces  that have been collectively orchestrating the Atlantian Conspiracy,
                  the roots of which go back over 200,000 years . All of these competing
                    OWO Fallen Angelic/Intruder ET dominion agendas have always shared one
                           core ''Prime Initiative ''—full physical conquest of surface Earth as the               
                           _______________________
                             11.       See Crystal Pylon Temples, in Forbidden Testaments of Revelation,  forthcoming  
                              352
                           

                                                   
                                                     Sleepers, Terrorists, Remote Viewing, RITs and the NET
strategic location  from which full physical invasion  of the Inner Earth  Time
Cycle and Halls of Amenti control sites  was intended to be launched.
Between 50,000 BC-9560 BC  the advanced Human civilizations of
Lemuria  (Mu’a) and Atlantis  were progressively invaded  by competing
Anunnaki and Drakonian  agenda races, via forced Fallen Angelic/Intruder
ET hybridization , through which the Illuminati-hybrid “puppet races”  (the
“Leviathan Force”) was created. Between 9560 BC-9558 BC  the Anunnaki
invader race gained control of what remained of Atlantis through use of  the
NET  and its mind-controlled  Illuminati  hybrid team. In 9558 BC  they
orchestrated a massive “Planetary House Cleaning, editing and re-writing” of
our Human historical records, and have methodically orchestrated each
stage of the Luciferian Covenant  since, in preparation for the final intended
invasion of the 2000-2017 SAC . Sometimes truth is, indeed, much stranger
than fiction.12 The Anunnaki would have us totally “under their spell” by
now if the Zeta-Rigelian and Drakonian OWO forces, and the Illuminati-
hybrid Sleepers hadn’t been “giving them a run for their money” since
         1943.  
          This explanation of our history and present circumstances seems surreal
and perhaps “fanciful.” Even if this information were not drawn directly from
the CDT-Plate ancient history records  (which it is), this scenario  takes a
turn toward the plausibly real  when we begin to see how contemporary
global 3-D events fit into the context of this advancing Illuminati OWO
Master Plan. What do  Sleepers, RIT s, the NET , Intruder ET T echnology
and the Fallen Angelic '' Atlantian Conspiracy dram '' have to do with the
9/11 Disaster?  Everything.  A review of recent history directly pertaining to
these subjects, and a glimpse at the Fallen Angelic UIR Illuminati OWO
Master Plan, will provide the context  through which the direct connection
between mass events such as the very real “9/ll Disaster” seemingly “unreal”
Atlantian Conspiracy can be most easily understood. The recent historical
context  from which our present drama has emerged begins with the 1930s’
Zeta Treaties  and ends with the 1992  Pleiadian-Sirian Agreements  and
their final September 12, 2000, dissolution  into the UIR Edict of W ar .
              
                
             
                          ________________________
                             12.   The long and war-torn  real history of this ongoing Amenti conquest is detailed in Forbid-
                                        den Testaments of Revelation , forthcoming.
                                
                         353  
                                            
                                                                                                                                   
                                                            

                                                          
                                    
                                        17               
                            
                                                                           
                                                                                      
                 The Phi-Ex Wormhole and
                              Illuminati OWO
                                           THE BERMUDA TRIANGLE, PHI-EX WORMHOLE,
                                                 FALCON MATRIX AND WORLD WAR II          
    Prior to the Anunnaki’s September 12, 2000, defection from the Treaty
of Altair Emerald Covenant peace treaty, GA Races were hopeful that
cooperation between Guardian races and the previously ill-intended
Anunnaki would allow for a peaceful resolution  to the Final Con flict drama
that had been “brewing” since the 9560 BC Luciferian Covenant . Since
November 1992, Emerald Covenant races have had to make concessions
regarding the expedient release of data  in order to maintain peaceful
cooperation from Anunna ki collectives controlling the NET . In 1992, the
GA knew that the interstellar political circumstances were extremely volatile
as Earth approached the 2000-2017 Stellar Activation Cycle  (SAC). They
also knew, since the last failed SAC of 22,326 BC  had ended in a  
''stalemate '' between the competing agendas of the Drakonian/Reptilian,
Anunnaki and Emerald Covenant races, that the 2000-2017 SAC  would
represent the climax  of a long-term battle between the forces of freedom  and
those of dominion.                  
      The 1992 Pleiadian-Sirian Agreements arose out of necessity, if peace
were to be maintained and cataclysm averted during the 2000-2017 SAC.
The opportunity for these well-intended but ill-fated peace agreements arose
from the actions of numerous Illuminati hybrid-human collectives since the
early 1930s . As explained in Voyagers I , certain factions within several world
governments had made covert treaties  with the Drakonian Agenda Rigelian
Zeta-Zephelium ¹ races of Orion —and thus the '' Zeta Treaties '' and '' MJ- 
12'' were born. Because of these intended “One World Order ”Drakonian/ 
Reptilian dominion treaties, competing Anunnaki forces who, since 
Atlantis, had been “nurturing” their Illuminati hybrid “Sleeper” races on
 Earth for their intended 2000-2017 takeover, suddenly found that their long-
anticipated position of covert power had been compromised. Since formation 
of the Anunnaki Luciferian Covenant of 9560 BC,  Anunnaki legions had
________________________  
                                1.     insectoid/reptile
                            354
               
                         


                                                              
                                                                               The Bermuda Triangle, Phi-Ex Wormhole... 
orchestrated a progressive in filtration of Human 12-Tribe culture and
systematic destruction and distortion of the Human historical records via
their Annu-Melchizedek  human-hybrid Illuminati race lines. Since
formation of the ancient Luciferian Covenant, the Anunnaki had intended
for these Illuminati race “Sleepers ” to be in position for overt Anunnaki
infiltration and takeover of Earth via the “ Savior Space Brothers ” deception
drama when the long-awaited 2000-2017 SAC arrived.  
    Anunnaki races of Nibiru, Pleiades-Alcyone, Sirius A, Andromeda,
Alpha and Omega Centauri, Arcturus and Orion had progressively gained a
stronghold on Earth through the 25,500 BC installation of the Nibiruian
Electro-static Transduction (NET)  and Nibiruian Diodic Crystal (NDC)
Grid at Stonehenge. Since the 9558 BC  Anunnaki-orchestrated “Atlantian
Flood” drama and '' Planetary Housecleaning '' (removal of historical records
and planting of false historical evidence), the major interstellar Photo-sonic
Communications system of Earth, the Nibiruian Crystal Temple Network,
was Anunnaki controlled via the NET, making Emerald Covenant Guardian
race communication with human populations progressively more di fficult.  
        The Anunnaki races were not the only ones running the long-term
“infiltration through hybridization agenda ” since initiation of the 9560 BC
Luciferian Covenant  in preparation for the One W orld Order dominion
conquest scheduled for the 2000-2017 SAC. Numerous factions of
Illuminati-Human-hybrid races of both Anunnaki and Drakonian/Reptilian
descent were created through raiding of the Atlantian Annu-Melchizedek
hybrid race line that emerged from the Emerald Covenant Anunnaki DNA
Bio-Regenesis Program .² The warring and conquest documented in known
“Human” historical record since 9560 BC has been an illustration of the
progressive power quest between competing factions of Illuminati hybrids for
Earth Star Gate site dominion.  The true Race Identity  of Human l2-Tribe
races progressively became “lost in the shuffle” and engulfed by Illuminati
hybrid race identity, as Illuminati hybrid races, always directly but covertly
motivated  from “behind the scenes” by their respective Fallen Angelic
collectives, launched their competing territorial dominion campaigns.  
         The elite '' Masters of War '' that have held, by force, positions of
political, religious and economic power throughout our known history from
Sumeria, Babylon, Egypt and Rome, up to the present-day covert '' World
Management Team ,'' are the Illuminati hybrid “Sleeper Races.”  The
Illuminati hybrid Sleeper Races are the Earthly representatives  of competing
Anunnaki, Necromiton and Drakonian/Reptilian Fallen Angelic legions,
and they have been the motivating force behind literally all “human” politics
since the 9558 BC “fall” of Atlantis. Illuminati hybrid Sleepers are but a
minority  within Earth populations, but they are those presently in positions
of greatest power  and in ﬂuence behind  the global political, religious and
economic infrastructure . Like Earth’s Human races, Illuminati Sleeper races
have been subjected to literally thousands of years of false cultural and
religious programming  via implanted Anunnaki and Drakonian/Reptilian
indoctrination . Most Sleeper races do not consciously know  of the reality of
                          ______________________________________
                           2.     See Forbidden Testaments of Revelation , forthcoming.   
                                355       
                                                                                                                                        

                                                          
        The Phi-Ex Wormhole and Illuminati OWO  
Fallen Angelics/ETs —only the few elite, key controllers  among each
Sleeper faction are permitted conscious knowledge of covert Fallen Angelic/
ET contact,  and none are permitted full knowledge regarding the real Fallen
Angelic/ET agendas.  Fallen Angelics historically control their Sleepers to
serve as their “ expendable pawns ” upon “Chess-board Earth,” through
remote NET-transmission of subliminal psychotronic EM scalar-pulse
programs and astral Tagging. Though Illuminati hybrid Sleeper races appear
both outwardly and genetically like “common humans,” due to genetic
mutations  that began in 25,500 BC, they do not have the human soul
essence . The Sleepers are incarnates from the Fallen Angelic/ET collectives
that control them; genuine Human 12-Tribe incarnates emerge from a once-
ascended master Guardian Maji Grail Line soul collective, not from the
Fallen Angelic collectives from which Illuminati Sleepers emerge.  
    The various competing Anunnaki and Drakonian/Reptilian Illuminati
hybrid Sleeper Races have been a hidden, predominant reality on Earth
since  155,000 BC . Since the 9560 BC  formalization of the Anunnaki
Luciferian Covenant, the competing family lines  of Illuminati Sleeper Races
have been part of a progressively orchestrated, highly organized long-term
strategic plan  to create Fallen Angelic '' Master Races '' on Earth in
preparation for the 2000-2017 SAC . Through these Fallen Angelic
Illuminati hybrid Sleeper Master Races, the competing legions of Anunnaki
and Drakonian/Reptilian interstellar collectives each intended to achieve
dominion of Earth’s Star Gates during the 2000-2017 SAC.  The strategic
plans of Fallen Angelic/Intruder ET Earth-dominion agendas that were set
forth in the ancient Atlantian Conspiracy  all held the intended scheduled
climax  as the 2000-2017 SAC . It was known by all Visitor races since
22,326 BC Atlantis , that the competing Fallen Angelic collectives intended
to wage war with each other , via manipulation of their Illuminati hybrid
Sleeper races, during the 2000-2017 SAC , in the final dominion quest  for
Earth’s Halls of Amenti Star Gates. The carefully cultivated and strategically
positioned Illuminati hybrid Sleeper Races  were intended, by each of the
competing Fallen Angelic factions, to serve as the tools through which this
war would be won . Since the 25,500 BC Lucifer Rebellion, Atlantian
invasion and resultant progression of Fallen Angelic territorial in filtration of
Earth, Emerald Covenant Indigo Children and Angelic Human 12-Tribe
races  have also retained their presence  on Earth, despite continually
advancing Illuminati hybrid and Fallen Angelic persecution, political
infiltration, false cultural indoctrination and attempted genocide. Guardian
races too have their Angelic Sleeper Races , incarnate representatives of the
Founders’ Emerald Covenant  Co-evolution Peace Treaty , who were long
intended to awaken and serve as the  peaceful healers and bringers of
Freedom  when the Final Conﬂict drama of the 2000-2017 SAC emerged.  
    Until the early 1930s, the Anunnaki legions  believed that they had
the upper hand  in regard to defeating Humans and Drakonian/Reptilian
legions in completion of the 2000-2017 One World Order Dominion agenda.
The Anunnaki Illuminati hybrid Sleeper Race family lines of the Knights
Templar, Free Masons, Hyksos  and related factions immersed within certain
contrived “religious” persuasions were in positions of global power, each
serving in administration over large, unsuspecting, amnesiac, (via DNA   
356  
   

                                                               
                                                                        The Bermuda Triangle, Phi-Ex Wormhole...
mutation) indoctrinated collectives of Angelic Human populations. The
majority of Human populations  existed in an  easy-to-direct amnesiac state
of Lost Race Identity and religious/scienti fic/historical cultural
Disinformation Propaganda control.  Competing Drakonian/Reptilian
legions would have a difficult time mobilizing their own Illuminati Sleeper
Race forces due to the Anunnaki’s predominant control of the NET and
Earth’s interstellar communications systems. In the early 1900s, Zeta-
Zephelium races  from an adjacent Time Matrix ( see Voyagers I ) managed to
break through the Anunnaki NET, by forcing a “hole in the cap” of a sealed,
ancient  Atlantian wormhole . This wormhole, one of two  remaining from
the technological abuses of ancient Atlantis,  is an artificially created trans-
dimensional, geophysical anomaly  that has existed in the Atlantic Ocean  off
the coast of what is now Savannah, GA , since 10,500 BC.  The two ancient
Atlantian wormholes are in the Atlantic Ocean on Axiatonal Line 7 , at
about 69.5° W longitude off the eastern U.S. coast. The first wormhole is on
horizontal Ley Line 3,  the Star Gates-3-Bermuda/ 9-Bam T so Tibet
“Bermuda-Jerusalem-Afghanistan-Pakistan-Bam Tso-Nagasaki Line ” at
32° N. The second is on horizontal Ley Line-4/10 , the Star Gates-4-Giza/10-
Abadan-Iran “ Giza-Persian-Gulf-Mid Way Line  ” at 30° North latitude.
Collectively, the two Atlantian wormholes, and the various Templar '' Port
Interface Networks '' connected to them, are responsible for the odd
phenomena of  plane/boat disappearances and electromagnetic anomalies  in
the area of the Atlantic called the '' Bermuda Triangle .'' 
    The Zeta races began surveillance of Earth territories and were rapidly
joined by an aggressive, militant Zeta race from Orion Rigel , who took over
administration of Zeta Earth missions on behalf of the Drakonian/Reptilian
Agenda.  By the early 1930s , through covert, direct physical contact , Zeta-
Rigelian forces had seduced a majority of key controllers  in the global
political community within both the Anunnaki and Drakonian/Reptilian
Illuminati hybrid Sleeper races into entering the Zeta Treaties  to stand
against what they presented as the “pending Anunnaki invasion.” At this
point “ MJ-12 ” and key components of the '' World Management Team ''
covert Interior Government were mobilized into a uni fied organization under
the Drakonian One World Order Agenda . Through the unanticipated
events  initiated by the Zeta Treaties , Anunnaki legions were forced to
initiate select, covert physical contact  with key figures in their Illuminati
hybrid factions, in an attempt to persuade them to break the Zeta treaties in
favor of Anunnaki  (Pleiadian-Nibiruian) allegiance.  
    Though the Anunnaki gained some converts  through these attempts,
the majority of   Illuminati hybrid races remained compromised by the trickery
of the Zeta Treaties, as the Zetas provided key weapons technologie s to
further their interests in the WW2 drama . Anunnaki races refused to provide
weapons technologies, as they feared their Illuminati hybrid races might use
such technologies against them  if the Anunnaki could not maintain critical
mass control of Illuminati races. As the “ UFO/Abduction Movement”
progressed following the dominant  Drakonian/Reptilian Zeta Agenda , the
Anunnaki began an aggressive covert counter-campaign using Psychotronic
scalar pulse technologies  and the NET to “awaken” their civilian Anunnaki
Illuminati hybrid Sleeper Races . The Anunnaki “trump card ” of the NET/    
357     
 
                                                                                                           

                                     
                      
                         The Phi-Ex Wormhole and Illuminati OWO
NDC Grid3  was used to initiate Psychotronic transmission of '' channeling ''
contact  with Illuminati Sleepers and Humans within the private sector.
Through this covert application of selective  mass mind control,  progressive
cooperation of unsuspecting people was garnered to advance the Anunnaki
dominion agenda, culminating in the creation of what has become the “ New
Age Movement. ” Throughout the building fiasco of Earth Illuminati-
Interstellar politics, Emerald Covenant Guardian races  made numerous
attempts at physical contact with key members of all Illuminati factions and
Human governments. Guardian races offered protection from both
Anunnaki and Draconian/Reptilian invasion if Illuminati and Human
Interior Government controllers would willingly honor the tenets of
egalitarian freedom, non-exploitation and peaceful coevolution  as long-
stated within the Emerald Covenant. Direct Guardian intervention in
Earth’s affairs required World Management Team controllers to discontinue
their programs of “Official Denial,” reveal the truth of the Atlantic
Wormholes, and Visitor Contact , to the public and to present to all
populations  the free-will  choice of entering the Founders’  Universal
Emerald Covenant Peace Treaty.  
   Guardian races explained that advanced Star Gate sciences and
Planetary Templar technologies  would be provided in stages as needed, to
create peaceful protection  of Earth’ s territories from further invasion. In
order for direct Guardian assistance to be given, the Illuminati hybrid races
who were controlling Earth’s infrastructure on behalf of competing Fallen
Angelic factions would need to accept the peaceful methods of intervention
offered by the Emerald Covenant races. Guardian nations would not endorse
the use of, nor provide, advanced weapons technologies  for the pending
Earth con ﬂict; such technologies would not secure the victory of freedom;
they would ensure only planetary destruction . The Illuminati would need to
put aside their own One World Order dominion agendas , exploitation of
Human populations and intentions of war in favor of peaceful interplanetary
and interstellar coevolution  built upon the freedom teachings of the
Emerald Covenant and Lyran-Sirian free cultural model. Illuminati races
within the covert Interior Government and World Management Team
repeatedly refused Guardian offers of assistance  in favor of the One World
Order dominion agendas and promises of power-hoarding  offered by
competing Anunnaki and Drakonian/Reptilian forces.                      
                         
                        
                           ________________________________
                              3.     See  Masters Templar Coursebook , now available.
                                358
                                
                         

                                                          The Phi-Ex Wormhole, and the Phantom Matrix ''Pit'' —1943
                                                             THE PHI-EX WORMHOLE,
                                                    AND THE PHANTOM MATRIX “PIT”—1943
                  
      In 1943  the Zeta/Drakonian agenda gained further strength  through
initiation of the Philadelphia Experiment , in which another '' time-rip Worm
hole'' or Port Interface Network (PIN),  was made in Philadelphia, PA,  via
the first Atlantic Wormhole. This PIN connected numerous points in Earth’s
global geography to the adjacent Time Matrix that is partially under Zeta/
Drakonian rule. The adjacent Time Matrix  to which Earth’ s new I943
wormhole network was connected once existed as part of our own Time
Matrix. Through repeated abuse of Advanced Scalar Pulse technologies ,
this portion of our Time Matrix imploded  250 billion years ago  forming an
11-dimensional Black Hole Sub-Time Distortion Cycle  within the
structure of our 15-Dimensional Time Matrix. This progressively contracting,
unnatural Black Hole Sub-Time Distortion system is known as the '' Phantom
Matrix ;'' in Biblical terms the Phantom Matrix is described as “t he
Bottomless Pit,”  and is also referred to as '' Hell'' and '' Hades .'' 
         The Fallen Angelic/Intruder ET races  that have plagued our Time
Matrix throughout history are the DNA-mutated/consciousness-distorted
life-forms  that emerge from the Phantom Matrix into our Time Matrix in an
attempt to “energetically feed” their slowly imploding, dying system by
harnessing life force from our living system. During the August 12, 1943,
Philadelphia Experiment, Zeta forces tricked Illuminati races  into
employing technologies that the Zeta knew  would create active Wormhole
links  between the Phantom Matrix and Atlantic Wormhole.  In 1943, not
only were the main East Coast power centers of the US  linked to the Zeta-
controlled Atlantic Wormhole, but an entire  network of wormhole links
was also created. The Zeta Phi-Ex Wormhole network extends diagonally
from Portland, ME- Boston, MA- Montauk, NY- Philadelphia, PA-
Washington DC- Mt. Mitchell/Asheville, NC- SW Florida, Atlanta-GA ,
horizontally across the US to Alaska,  spanning both the Pacific and Atlantic
Oceans into N. Ireland, across Europe and into Vietnam and Japan . Key
Illuminati controllers were tricked by the Zetas into orchestrating this
“experiment” under the false pretense of developing military “Cloaking”
(invisibility) technologies. In one well-orchestrated technological
deception , the Zeta-Rigelian Drakonian force had literally “carved out their
intended territory” across the global map,  gaining covert control of many key
Axiatonal Lines, Ley Lines and Star Gate sites  in Earth’ s Planetary T emplar,
while striking terror into the hearts of their Illuminati collaborators. (The
''Trojan Horse '' of the Atlantian NDC-Grid revisited). The Zeta and
Illuminati creation of this Wormhole network had unanticipated
consequences  for the Drakonian agenda races—the '' Phi-Ex  (Phi-ladelphia
Ex-periment) Wormhole ” allowed for yet another Fallen   Angelic “player”
to directly enter the contemporary Earth game.  
                    
         NECROMITON-ANDROMIES AND THE “UNHOLY ALLIANCE”
 
        A Fallen Angelic race, which had long intended dominion over the
   Zeta/Drakonian legions of the adjacent Phantom Time Matrix and which
   had gained partial access to the Atlantian Wormhole the Zetas opened in the
     359  
                                                                                                                              
                                                                                                                                                                                 

                                                                                                                                                                                                                                                     
                        
                          The Phi-Ex Wormhole and Illuminati OWO
early 1900s, was also able to gain easy open access to Earth territories via the
Phi-Ex Wormhole. The most diabolical player  in the Earth drama is the
ancient race called the Necromiton —a hybrid Insectoid Beetle-Reptilian
Anunnaki-hominid-hybrid  race from the adjacent Andromeda  galaxy . The
Necromitons are feared and hated by most Anunnaki and Drakonian/
Reptilian races, and like their competitors, the Necromitons have had
Illuminati hybrid Sleeper Races  positioned among human populations of
Earth since the Atlantian period. The Necromiton races are the leaders of an
Unholy Fallen Angelic Alliance  that involves several powerful renegade
rebel races . Included in this Unholy Alliance, and directed by Necromiton
“Andromie” administrators  are the following collectives:  
     • The Blue Centaurs  and Anunnaki-hybrid Centaurian  races of Alpha
and Omega Centauri.  
    • The Orion Black League Human-Reptilian hybrid “ Noors ”4 of
Alnitak-Orion, the Pleiades, Andromeda and Vega-Lyra . 
    • Also included are several rebel factions  of both Anunnaki and
Drakonian/Reptilian legions, including factions of the “Archangel Michael”
and Annu-Melchizedek Anunnaki Nephilim  rebel races and rebel portions
of the Omicron-Drakonian5 collective of Alnitak-Zeta and Alnilam-Epsilon
Orion.  
  The Phi-Ex W ormhole born of the 1943 Philadelphia Experiment
presented the Necromiton force with renewed opportunity for large-scale
Earth in filtration.  Necromiton Andromie race operatives have become
known as the “ Men in Black”  within the contemporary UFO drama.  
   Between 1930-1943, most Necromiton-Andromies were not
particularly interested in participating overtly in the “Final Con ﬂict” Earth
drama being set up by competing Anunnaki and Drakonian/Reptilian
factions. The Necromiton had an Earth Star Gate dominion agenda of their
own, which originally included extermination of all Earth races, including
the Illuminati hybrid operatives of the other Fallen Angelic collectives.
Originally the Necromiton intended to build their underground power bases
and “wait and see” whether the Drakonian/Reptilian or Anunnaki forces
“won the Final Con ﬂict,” intending then to “ depose the victors ” and claim
Earth, Inner Earth  and the Halls of Amenti  Star Gates for their own. The
Necromiton races planned to take direct action only if the 2000-2017 SAC
fully commenced , as the Amenti Gates could not be accessed otherwise. No
one knew for certain until 1998  whether or not Earth’ s core vibration would
sustain commencement of the pending SAC, but all interstellar races were
''positioning their Illuminati operatives '' for the dramas that were due to
rapidly emerge should the SAC commence in 2000.  
    Unlike Anunnaki and Drakonian/Reptilian races, the Necromiton were
not interested in dominion of surface Earth, because their primary genetic
strains cannot live long under surface-Earth conditions. Their interest in
Earth is strategic only ; Earth is the primary point in our Time Matrix from
which the Halls of Amenti Star Gates can be potentially invaded. When the
                         
                          ______________________________
                             
                                4.     Red-haired Human-looking Omicron Drakonian-human hybrids
                                 5.     Dragon-Moth       
                           360                      
                     

                                             
                                                  
                                                '' Big Brother Drac,'' the Andromies, Hiroshima and Hitler
Zeta-Rigelians advanced their OWO agenda by creating the Phi-Ex
wormhole, the Necromiton set up underground  bases in certain strategic
locations, beginning limited covert  contact  with key members of their
Illuminati Sleeper races for “future reference.” From 1943  forward, both
Anunnaki and Drakonian/Reptilian legions and their Illuminati hybrid loyals
contrived competing “step-by-step” strategic plans  by which covert political
infiltration, leading to One World Order surface Earth dominion between
2008-2012,  would be progressively set in motion. The Zeta-Rigelian
Drakonian agenda had advanced rapidly following the 1930s’ Zeta Treaties,
quickly over-powering the previously Anunnaki-dominated covert
Illuminati political landscape . In the early 1930S, the '' Majestic-12 ''
Illuminati head of Zeta-Drakonian-agenda operations had progressively
infiltrated key positions of world politics, most notably in the U.S.A., which
the Anunnaki Illuminati had historically boasted as their “stronghold” since
their “Yankee” victory over the Drakonian “Rebel” force during the
American Civil War.6 In the l930s the Zetas assisted in creating central
organization of the covert World Management Team  on behalf of the
Drakonian agenda, through which global economic and political powers
were centralized  under the covert governance  of a hidden Zeta-Rigelian
Drakonian totalitarian “Big Brother.”  
                    
                          “BIG BROTHER DRAC,” THE ANDROMIES,  
                                      HIROSHIMA AND HITLER 
   Compromise of the American Constitution  had been orchestrated by
Anunnaki Illuminati  via manipulation of American banking laws, in their
quest for covert economic control during the late 1800s  and early l900s.
The American Constitution  was further violated  by the Zeta-Drakonian-
agenda Illuminati in the 1930s , with the creation of the privately held
interests of the U.S. Federal Reserve and several other acts of “underground
sleight-of-hand.”7 As the Zeta-Drakonian Illuminati organization of MJ-I2
was quietly expanded into what became the U.S. CIA, the previously covert
Anunnaki Illuminati control of the American political-economic machine
fell to the equally covert “hostile takeover” of the advancing Zeta-Drakonian
''Big Brother '' game-plan. Adopting the strategies of the Anunnaki
Illuminati before them, the Zeta-Drakonian Illuminati created a complex
''underground '' system  of '' Black-Budget Funding '' networks, including
covert drug and arms running, to fund building of underground Zeta -
Drakonian Bases  and further the quest for covert Big Brother territorial
dominion.  
  World War II  began in 1939  as the Zeta-Rigelian Drakonian-agenda
force launched a covert territorial conquest and race supremacy/genocide
campaign through their Illuminati hybrid “fall guy” Adolf Hitler . The
                            
                             _______________________
                     6.   Sadly , it is primarily Humans who end up “playing the soldiers” that lose their lives
                        unknowingly on behalf of the covert Illuminati-ET alliance and their '' Illuminati arm-
                                        chair warriors .''
                7.   The external aspects of these covert Illuminati in filtration of U.S. and world political and
                                        economic systems are well chronicled by various “conspiracy theorists” of our time.
                               361
                                                                                                                                                 
                                                                                                                               

                                                                                                                                                                                         
The Phi-Ex Wormhole and Illuminati OWO  
political quest was covertly motivated by Star Gate territory control,  the
“Holy Grail Quest” for Earth’s Templar,  as it had been in WW1 and all
Human wars since Atlantis. In WW1 and WW2  all groups were covertly
competing for territories that could be used for Port Interface Networks
connecting to the A7/L3 Falcon wormhole.  Once the Zetas had “opened the
cap” on the Falcon wormhole on Axiatonal Line-7/Ley Line-3, territories
connecting with this coordinate through Earth’s natural Ley Line structure
became “prime real estate”  for their use as Falcon wormhole Port Interface
sites.  
     In WW2,  select members of Japan’ s Illuminati elite were covertly
“inspired” by a faction of the Necromiton-Andromie  race that at the time
chose to compete with the Zeta-Rigelian legion for Port Interface Site
dominion in various regions. The U.S.A. and Japan became entangled  with
each other over intended dominion of Ley Line-3 Port Interface Site
control.  In 1940 , the Necromiton-Andromies began covert contact with
their Illuminati hybrid family lines in the areas of Hawaii and Nagasaki and
Hiroshima, Japan. Nagasaki  is a prime Port Interface Site  on Falcon
wormhole Ley Line-3 ; the Necromitons inspired their members of the
Japanese and Hawaiian Illuminati to begin construction of two underground
marine bases  in these regions. The Nagasaki-Hawaii Necromiton bases
would prevent the Zeta-Drakonian races from expanding their Falcon Port
Interface Network as they planned to do during Earth’s scheduled ''Magnetic
Peak '' of August 12, 1943. The greatest objectives of the Zeta-Rigelian
Drakonians in 1940-1941  were reducing concentrations of Angelic Human
Maji and Necromiton Illuminati family lines  inhabiting the Nagasaki-
Hiroshima areas, and thwarting Necromiton base-building  by having
Human government attentions scrutinize Hawaiian territories. The
Necromiton Fallen Angelics would be left without their Illuminati “surface
work force” in Japan, local Angelic Human Planetary Shields guardian races
would be destroyed and any covert Necromiton marine activities around
Hawaii would be instantly detected and exposed should the Necromitons
attempt to proceed. To “solve” their pending problem, the Zeta-Rigelians
directed their Illuminati family lines in Tokyo and other regions of Japan to
launch a “secret attack” on Hawaii. Simultaneously, the  Zeta-Rigelians
warned their Illuminati key controllers in the U.S.A. that the attack was
coming, but that they should do nothing . 
     Once the December 7, 1941 , Japanese attack on Pearl Harbor  was
completed, the American Illuminati were then directed to enter territorial
war but to '' wait until the appropriate time ,'' to use the Zeta-Rigelian -
inspired atomic bomb. Meanwhile, on August 12, 1943,  the Zeta-Rigelians
inspired their Illuminati within the Allied forces to orchestrate the infamous
“Philadelphia Experiment ” during Earth’s stronger 20-year August-12
“Magnetic Peak” cycle.  Through Zeta trickery the Phi-Ex wormhole and
Falcon Port Interface Network were brought into global operation in 1943.
The Zeta—Rigelians intended to open the final links of the Phi-Ex Falcon
Port Interface Network  during the August 12, 1945 , yearly planetary
Magnetic Peak. The Necromiton-Andromies were using a Cloaking
Protection Field around their progressing underground base at the Nagasaki
Port Interface Site, which would prevent the Zeta-Rigelians from opening 
362      

                                                 '' Big Brother Drac,'' the Andromies, Hiroshima and Hitler
and claiming the site under their control in August 1945. As the Zeta-
Rigelians had planned since 1941 , the “ time had come ” to inspire the US
Illuminati to direct Human troops to use their A-bomb to “flatten”
Hiroshima and Nagasaki . This military atrocity was ordered to break
through the Necromiton photo-sonic cloaking screen  and to “clear the real
estate” of Necromiton Illuminati “cells” for Zeta-Rigelian Drakonian
Illuminati “resettlement.” On August 6, 1945, Hiroshima , the Necromiton-
Illuminati controlled Cloaking Shield main generator system and a city
composed almost completely  of innocent Angelic Humans  of “ Yu Urtite-
Cloister Maji Grail Line ” descent fell amidst radioactive rubble. The Zeta-
Rigelian command waited until August 9, 1945,  before giving the order to
strike Nagasaki . The rapidity of the second strike ensured that the
Necromiton would have insufficient time thereafter to erect a temporary
Cloaking Shield in an attempt to prevent the Zetas’ scheduled August 12 ,
1945, Sub-space Sonic scalar pulse.  
    The Zeta-Rigelians’  August 12, 1945, Phi-Ex sonic scalar pulse  put
the Nagasaki Port Interface Site “on line” with the Zeta-Drakonian-
controlled Falcon wormhole and Phi-Ex Network. By August I3, 1945, the
Nagasaki Phi-Ex Port Interface link had proved successful, and the Zeta-
Rigelians informed Japanese Illuminati controllers that it was “time to
surrender,” that the “Nagasaki Mission” was completed. On  August 14,
1945 , the Japanese Emperor gave consent to Japan’s compliance with the
Allied demand for surrender.8 Securing and activating the Nagasaki Port
Interface Site under Zeta-Rigelian Drakonian control  was the real reason
behind Japan’s attack on Hawaii and America’s “return retaliation.” The
Japanese Illuminati majority, individual “Sleepers” covertly placed within
positions among Human government elite, agreed to participate , as did the
American Illuminati, only because the Zeta had threatened them  that if
they did not comply, atomic bombs and sonic pulses would be used to destroy
their entire countries. This threat gives one some insight into the “Mind
Games”  Fallen Angelics like to play , and also into the reasons why
Illuminati races are most often too frightened to rebel  against Intruder ET
orders. Drakonian, Necromiton and Anunnaki Fallen Angelic races
continually use these types of Mind Games to keep their Illuminati key
controllers in subservient compliance.  
    What was going on with the Nazis during the WW2 period was
equally as reprehensible.  The Zeta-Rigelians assisted in developing the
Nazi movement of WW2,  supporting and '' nurturing '' Hitler  and his inner
circle Drakonian Illuminati crew; the Nazi Illuminati elite had also entered
Zeta Treaties in the early 1930s, agreeing to “ reduce populations ” of several ,
primarily Angelic Human ''pure-strain '' ethnic groups . The Zeta-Rigelians
instructed their Illuminati operatives in the U.S.A. and several European
countries to financially fund the Nazi movement  “without leaving a paper
trail.” While keeping an external posture of Allied loyalty  to maintain their
                        _________________________________                          
                              8.    This is the real reason why Japan didn’t immediately surrender after the first,
                                         Hiroshima, strike.  Their Zeta-Rigelian Drakonian-agenda Illuminati “elite” were
                                         instructed to wait until Nagasaki , the Port Interface Site , had been “taken care of                                                                                   
              before agreeing to surrender.  
                                                       363                                  
                                                                                                                                           
                                                                                                 

                         
                   
                        The Phi-Ex Wormhole and Illuminati OWO
hidden positions within Human governments, the Illuminati operatives in
several Allied  countries covertly funded Nazi objectives . The Necromiton-
Andromies  made covert physical contact with Hitler , “playing on” his
personal prejudice against Jewish races. They convinced him to assist in the
Necromitons’ plan  of keeping the Zeta-Rigelians ''in their place,'' by
providing small “gifts” of metaphysical Templar knowledge  that allowed
the Nazis to unearth certain ''valuable relics '' from the Grail Quests of
ancient times. Consequently, Hitler '' got carried away with himself '' in his
genocide campaign against Jews,  on behalf of his Necromiton-Andromie
affiliations. In Hitler’s Zeta-Drakonian “deals,” he had been instructed to
reduce numbers of only certain Jewish family lines associated with the
''true Hebrew '' Angelic Human/Indigo Child Maji Grail Line lineage.
Hitler had been warned to leave ''untouched '' families of the Drakonian
''Hibiru Illuminati ,'' a Hibiru-Drakonian Illuminati hybrid lineage
descended from the ancient Atlantian “Hassa King” family line  that has
been progressively masquerading under “Jewish disguise ” since the
Atlantian period. But in his overzealous quest for race supremacy, and
“double-dealings ” with the Necromiton-Andromie force, Hitler’s “ethnic
hunting” became indiscriminate,  and several Hibiru-Drakonian Illuminati
families, favored by the Zeta-Rigelians, were destroyed.  
   The Zeta-Rigelian Drakonian force promptly gave the order to
international Zeta-Drakonian Illuminati conclaves to withdraw all support
from the Nazi campaign  and to assist the Allied Illuminati  controllers in
orchestrating the defeat of Nazi Germany. This information has been
provided by the GA/Eieyani for inclusion in this book, so readers may begin
to realize the extent to which the covert Fallen Angelic presence and the
advancing invasion has determined the external events that Humans have
lived through and died from for so long.  The realities of covertly inspired
Fallen Angelic/Illuminati-orchestrated “Human Wars” are now emerging
into the global arena  once again as the UIR advances the final strategies  in
its OWO, Star Gate quest, '' Final Conflict '' dominion campaign. We will all
become a bit wiser, less likely to get caught up in the Final Conﬂict War
Game and perhaps become a bit more compassionate toward those who fall
to this ploy, if we look to the true causal element  behind these “W ar
Dramas.” Fallen Angelic/Intruder ET races covertly motivate this  “Victim-
Victimizer” drama among Human nations in order to support their own
“Unholy Grail Quest” initiatives.  
   Ninety-Nine percent of the people working for and within their
national government communities have no idea  of the Atlantian Conspiracy
that has operated behind world politics for thousands of years. This is
especially true in America , where most military personnel, even in the
highest ranks, honestly still believe that the U.S.A. is a democracy  that
they would willingly give their lives to defend. The truth hurts —the core
infrastructure of America,  like that of all global nations since the 1930s,
has been covertly and progressively compromised and ''absorbed '' by the
covert Big Brother Zeta-Rigelian Drakonian World Management Team .
                    What even most conspiracy theorists do not yet realize is that '' at the top '' of
                          this corruption there exists Fallen Angelic/lntruder ET masterminds  who  
                       have had the Illuminati races terri fied to rebel  since the  Zeta Treaties  of the 
                         364  
                           

                                               “Big Brother Drac, ” the Andromies, Hiroshima and Hitler
1930s. As painful as it might be for Americans to confront, (and it is
painful!), we have been living under the contrived  ''illusion of freedom ''
while our nation and our planet has been in the clutches of a progressively
advancing, cunningly orchestrated Intruder ET invasion for the last 70
years —an invasion that was planned, and methodically implemented  by, our
unwelcome Visitors since 9560 BC Atlantis.  Human nations have been
intentionally driven around in mental circles within a “fantasy world,” a
''perceptual bubble'' of manipulated security and ''Official Denial.'' If the
United Intruder Resistance (UIR) succeeds in ful filling its 2001-2008
OWO Progression Schedule, our collective ''wake-up call '' will soon pass
the ''sell-by '' date.  If they did not need  human populations  to assist them in
running the Star Gate Security Access Codes during the SAC, they would
have “gotten rid of us” long ago.  
___________________________________________________________
That Humans have managed to hold their own this far, despite what has been
       done covertly to intentionally enslave the Human race since Atlantis,
                     is a testimony to the true strength of the Human spirit.___________________________________________________________
      
         The  SAC  dominion  strategies  of   all  Fallen   Angelic/ET    Illuminati  OWO
agendas became highly organized, formalized and slowly implemented by
1972 , with ﬂuctuations of power between various competing Anunnaki and
Drakonian-agenda factions being covertly “played out” within various
external, international political and economic dramas. The common aspect
of these hidden global political agendas was the '' Final Conflict '' drama , in
which Human races, unknowingly headed by the covert manipulation of
competing Illuminati hybrid Sleeper races under subliminal Fallen Angelic
Psychotronic control , would be slowly and systematically  led into creating a
final Human global war.  Through this Fallen-Angelic-scheduled WW3
Final Conflict drama , the outcome of the Anunnaki vs. Drakonian/Reptilian
One World Order Dominion agendas would be determined. The competing
Fallen Angelic legions of all sides  intended to have unsuspecting humans
and Illuminati hybrids  “fight the battle”  against each other,  while the
covert  instigating force  of the victorious Fallen Angelic collective  would
later come to “claim battle field Earth for re-settlement.” At this point, the
“dominion victor” would then have to face the Necromiton force.  
365 
               

                                                   18       
                                   
                                      
                                          
                                     
                    The Hidden Game-board
                          Final Conflict Drama
                              
                                           APIN SYSTEMS; THE FALCON, THE ANDROMIES
                                                           AND THE DOVE 1943-1951
    From 1943, the Zeta-Rigelian-Drakonian force continued to “spread its
wings” of inﬂuence across the globe following their 1943 success in creating
the Phi-Ex Wormhole network. Drakonian Illuminati races became painfully
aware that the Zeta Rigelians had intentions of orchestrating mass genocide
among select populations  in preparation for the 2000-2017 Final Con flict
with the Anunnaki and Necromitons. In the late 1930s , the Zetas began
experimenting with '' Ethnic Viruses '' (DNA/race type speci fic) as they
explored their options for reducing select Human, and competing Illuminati,
populations during the SAC drama. Beginning in late 1943,  the Zetas
began using their Phi-Ex Network technology  (code-named '' the Falcon, ''
after the Atlantic wormhole’s ancient Atlantian name) for testing of sub-
space sonic scalar pulses  to induce localized, targeted “natural disasters”  in
desired areas.  
    Primary locations for Zeta/Illuminati sonic scalar pulse testing  have
included areas of Alaska, Antarctica, Australia, Central America, Mexico,
the Middle East, various desert regions and beneath the Atlantic, Paci fic and
Indian Oceans, the Aegean, Mediterranean and Caspian Seas, the Sea of
Japan, Persian Gulf and Gulf of Mexico. Throughout the 1950s , the
Necromiton-Andromie  force became more actively involved in Illuminati
contact and began to assemble teams of Illuminati ''converts '' from the
Zeta-Rigelian Drakonian international Illuminati ranks. In 1951  certain
factions of pro-Anunnaki Necromiton-Andromies from Omega Centauri
accepted Templar conquest “deals”  from a competing Jehovian-Annu-
Elohim Anunnaki  OWO invasion force from Sirius A, Arcturus  and the
Trapezium  (Theta) star cluster in '' Orion’s Sword .'' The Bipedal Dolphin
People, Anunnaki and Annu-Elohim Fallen Angelic forces that comprise
this ancient Lemurian-Atlantian Jehovian-Nephite Invasion Team  are
collectively known as the '' Dove .'' 
    The '' Dove '' symbology  refers to the physical shape , when viewed from
the air with photo-radionic scanning equipment, of their global Atlantian
Pylon Implant Network (PIN) Control Grid  that was last implanted into
366 
                        


                                                                           The Lion, the “Lamb,” the Sphinx and the Eagle
Earth’s Planetary Shields during the 25,500 BC Lucifer Rebellion. The
“Falcon Phi-Ex PIN ” connecting to the Zeta-Rigelian Drakonian “Falcon
wormhole,” is also one of these ancient Atlantian PIN Control Grids, as are
numerous others  soon to be discussed. These Atlantian Pylon Implant
Network (APIN) systems  were in active use as tools of territorial dominion
by various competing Fallen Angelic/Intruder ET factions throughout the
Atlantian period. APIN systems differ in the type of Planetary Shield
implanting  that is used, but all implanting utilizes sophisticated crystal-based
technologies  similar to the silicon-based microchips  used in conventional
computer technologies. The APIN systems can be compared to massive
global grid  systems made of strategically placed  ''crystalline microchips ''
that interface directly with the natural, multidimensional, electromagnetic
energy conduits of Star Gates, Axiatonal and Ley Line systems  organic to
Earth’s Templar. APIN technology is not intrinsically a “negative”
technology, but rather an environmentally valid application of the natural
spiritual and scientific laws of Creation Physics. Before these technologies
fell into the hands of Fallen Angelic races, they were used openly by various
Guardian races in many universal systems  to facilitate and enhance the
experience of evolution and ascension for all. Prior to the Lucifer Rebellion
of 25,500 BC , Emerald Covenant Founders races and the Angelic Human
and Indigo Maji races of Earth utilized APIN systems for everything from
global free energy systems, climate stabilization and healing, to inter-stellar
sub-space communications and broadcasting networks . 
            THE LION, THE “LAMB,” THE SPHINX AND THE EAGLE  
    The Angelic Human and Indigo Maji races of Earth originally had two
great global APIN systems  on Earth that operated Earth’ s T emplar naturally
on a D-l2 “ 12-Code Pulse Christiac Current ” through Star Gate-12 , its
corresponding Inner Earth Star Gate-12 “ Cue Site ” and interface with
Earth’s natural Crystal Pylon Networks (CPNs). The Emerald Covenant
APIN systems were known as the '' Great White Lion '' and the ''Golden
Eagle .'' The Founders designed the blueprint of their APIN systems  with
two primary criteria in mind—first, that the APIN was precisely calculated
mathematically to encompass and modulate natural frequencies through
the 12 Primary Star Gates, Axiatonal and Ley Line systems in Earth’s
Planetary Templar . Second, once the technical elements of the APIN “grid”
were in place, the Founders desired to “ leave a part of themselves reflected
in the APIN ” to remind the races of Earth that they were never alone or
abandoned. The “design” of the Founders’ APINs was also to serve as a “ sub-
sonic planetary identification flag” when viewed from space via Photo-
radionic scanning equipment. (See APIN diagrams pp. 527-530). The Great
White Lion APIN system  belonged to the Elohei-Elohim Christiac
Founders  races of D-12 Aramatena-Lyra —the feline-hominid Anuhazi
Leonine  race. The Great White Lion’ s '' heart '' was located at Earth’s Star
Gate-12—Montsegur, France . The “throat  from which the lion roared” was
at Star Gate-1l, Southern England.  Its “head” looked out to the west,
cresting the north polar regions, spanning central and northern Europe,
across Atlantis and into northeastern North America. The '' body  of the
Lion'' lay at rest across the expanse of the Asian continent,  while the Lion’ s   
367 
                                                                                                                                            

                                                                   
                        The Hidden Game-board Final Conﬂict Drama
''great front paws '' stretched out across North America and northern South
America, its rear left paw shrouding the continent of Africa. The “tail” of the
Lion extended outward and down from the far eastern side of the Asian
continent, through Australia, south to Star Gate-1 at Halley, Antarctica,
then curved back up and northward to encompass the southern portion of
South America. The Elohei-Elohim Anuhazi installed the “Great White
Lion” APIN system on Earth in stages, beginning just after the “Electric
Wars” of 5.5 million years ago.  
    Though Earth’ s continents and land masses have changed position
several times since the Electric Wars, Earth’s Star Gates always remain in
the same positions  within Earth’ s Planetary Shields Scalar T emplate. Earth’ s
crust ''slides across '' the fixed geographical Star Gate coordinates of the
Planetary Shields; APIN systems are installed along precise coordinates
within the Planetary Shields,  and thus the form of the APIN systems
remain constant in relation to variable planetary surface geography . The
original Egyptian Sphinx  had the face of a lion , not of a man. The design for
the Sphinx was chosen, by the Indigo Child Maji, Angelic Human and
Emerald Covenant-loyal Annunaki races of Earth, as a tribute to the Elohei-
Elohim Leonine Christos Founders race. The structure broadcast a statement
to the Fallen Annu-Elohim and Annunaki Fallen Angelic collectives that
the Earth races were united under the common banner of the Founders’
Emerald Covenant Co-Evolution Peace Treaty . The design of the original
Sphinx was a three-dimensional representation of the Great White Lion
APIN system, created from translating the Founders’ APIN maps , as held in
the Emerald Covenant CDT-Plate records. The primary purpose of the Great
White Lion APIN was to assist Earth through natural Stellar Activation
Cycles  until Earth’ s Planetary Shields could be repaired  from the damage
incurred during the Electric Wars cataclysm. If the Great Lion, and its
companion “ Golden Eagle ” APIN systems had not been installed following
the Electric Wars, Earth would suffer cataclysmic pole shift during every
SAC , and eventually the planet would implode due to the severity of its
Scalar Template distortions.  
    The Great White Lion APIN was modeled  in the image of the feline-
hominid  Elohei-Elohim Leonine Christos Founders of D-12 Lyra,
Aramatena . It represented the D-12  (silver- white ) Lyran-Sirian APIN
system of Earth, the “anchoring rod” and stabilization grid  for 12 Primary
Axiatonal Line “vertical frequency conduits ” running along the polar
North-South  longitudes in Earth’ s T emplar Complex. The companion
Golden Eagle APIN system  belongs to the Emerald Covenant Cerez-
Seraphei-Seraphim Avian  races and Aethien-Mantis  races of D-8 Mintaka,
Orion  and the related Serres Avian-hominid  races of Alcyone, Pleiades.  
   The Golden Eagle, modeled in the image of the A vian (bird people)
Cerez, is the D-8 “anchoring rod”  and stabilization grid  for the 12 Primary
and many secondary horizontal Ley Line systems  running East-West  along
the equatorial latitudes of Earth’s Templar, and for the diagonal Ley Line
system. The Great White Lion  is the “ Guardian of the North and South”
and the Golden Eagle  is the '' Guardian of the East and West .'' The “Great
White Lion,” has its heart at Star Gate-12,  through which the silver- white,
 D-12 “Christos” frequency  of the planetary Pre-matter Template,  or
   368  
 

                       
                                                                The Lion, the “Lamb,” the Sphinx and the Eagle
''Divine Blueprint '' opens into Earth’s Planetary Shields. The Great White
Lion became the symbol of the eternal Christos Founders Elohei-Elohim
Anuhazi races, the  L yran-Sirian Guardians of Earth’s D-12 Christiac
Divine Blueprint —the “ The Powerful Lion with the Pure, Christed Heart
of a Lamb. ” In technical terms, the Great White Lion and its Golden Eagle
companion APIN systems literally hold Earth’s shattered Planetary Shields
and scalar template together during SACs.  
   Interestingly , in the Jehovian Anunnaki/Fallen Annu-Elohim
distortions added to the ancient Emerald Covenant texts  that later became
the Bible,  the Jehovian “promise” was that the day would come '' when the
Lion would lie down with the Lamb .'' What the Jehovians failed to explain
was that the '' Lamb ''—the Star Gate-12 ''Heart of the Great White Lion ''
APIN—was '' sacrificed and cut out upon the altar '' of the Fallen Angelic
Omicron Drakonian  (“Dragon” APIN) force of Alnitak, Orion, during the
last consummated SAC of 208,216 BC . At this time, Earth’s Templar
activated on an unnatural 10-Code Pulse,  blocking activation of Star Gate-
12 and “stilling the heart of the Lion,” due to Omicron invasion. The Annu-
Elohim also fail to mention that in 25,500 BC , their Jehovian Anunnaki
assisted the Marduke-Luciferian Anunnaki of Alpha and Omega Centauri  to
''seize the Lion '' by its Star Gate-11 England '' throat '' via the NDC-Grid.¹
Since this time, the Jehovian Anunnaki and various competing Fallen
Angelic factions have “ quested to tame the Lion ” APIN system under their
respective dominion, and have progressively used the NDC-Grid to prevent
the Elohei-Elohim Founders from accessing the Great White Lion APIN to
assist the peoples of Earth. The Jehovians intend for the '' Lion '' APIN  to
''lie down with the sacrificed Star Gate-12 Lamb ,'' to be  ''resurrected '' and
re-activated under the dominion of the Fallen Annu-Elohim, when they
succeed in pulling Earth into the Phantom Matrix . They hope to ''re-start
the heart'' of the Lion by arti ficially linking Earth’s Star Gate-12 Lamb to the
Star Gate-11 ''throat of the Lion.'' If the Jehovians have their way, the ''Lion
will have its heart in its throat,'' and both the “Lion and the Lamb” will '' lie
down together before the alter of Jehovah ,” to be “resurrected” by the Fallen
Annu-Elohim, as an '' energy-vampiring '' system to feed the Phantom
Matrix.  
     Sad, isn’t it ? Here humanity was led to believe that the statement of
“When the Lion lies down with the Lamb” represented a time when “Peace
and love, and the end of fighting, would come between the aggressive and the
passive, and we’d all enter the kingdom of Heaven joyously together.” This
example illustrates beautifully the cruel sense of humor, manipulative
soothsaying  and outright deception  offered to us by the Fallen Angelic
Annu-Elohim Jehovian Anunnaki collective. What the Jehovian Anunnaki,
and the other Fallen Angelic collectives did not anticipate was that the
''Heart of the Lion '' would begin '' beating with a 12-Code Pulse '' at the
January 1, 2000 , commencement of the present SAC. This is precisely
what has occurred  due to continuing Elohei-Elohim and Seraphei-
Seraphim  crisis-intervention  efforts   in  the  contemporary  drama.  Now  all of
___________________________  
                              1.    See Masters Templar Coursebook. 
                             369  
                                                                                                                                        

The Hidden Game-board Final Conﬂict Drama  
the Fallen Angelic collectives are in a ''race for time'' to fulfill their intended
OWO dominion agendas, in hopes of preventing the Great White Lion and
Golden Eagle APIN systems from fully awakening from their long slumber. If
the Great White Lion and its Golden Eagle companion awaken, the
numerous APIN systems belonging to the Fallen Angelic races will be
progressively healed and re-coded to a natural “Christiac D-12 12-Code
Pulse. ” In this case, Earth, Inner Earth and the Halls of Amenti will be
permanently spared further advancement of the Fallen Angelic dominion
campaign. The Big Question  is ''Can the Great White Lion and the Golden
Eagle be healed and awakened in time ?'' 
     As the Great White Lion, and a return to the L yran-Sirian Christiac,
love-based culture model that it represents, struggle now to awaken , the
Golden Eagle has a '' rapid healing '' to complete before its “wings are opened,
free to fly.” During the 25,500 BC  Lucifer Rebellion, when the Marduke-
Luciferian-Anunnaki and Necromiton-Andromie-Annunaki-hybrid races of
Alpha and Omega Centauri , and the Thoth-Enki-Zeta Anunnaki  races of
Nibiru implanted the Nibiruian Diodic Crystal Grid (NDC Grid) in Earth’s
Templar, the “Lion was grabbed by its Star Gate-I1 throat” and the ''Eagle
was Caged.'' The Golden Eagle  APIN system fell to Necromiton-Andromie-
agenda Anunnaki forces , as the NDC Grid  was used to reverse the natural
scalar template sequences (''Fire Letters'') on Earth’s  Primary Ley Lines 4
and 10 . The horizontal L4/L10 ''double Ley Line '' emerging from Star
Gate-10 Abadan, Iran , and Star Gate-4 Giza, Egypt , is the L4/L10 ''Giza
Ley Line, '' the East-West  center-line axis  upon which the Golden Eagle
APIN system  is structured. (See APIN diagrams pp. 527-530.)  
      
                             THE WHITE EAGLE AND THE MELCHIZEDEK DECEPTION          
    Since 25,500 BC, the Golden Eagle APIN system has been “held
hostage”  and used to “do the bidding” of the Necromiton-Andromie-
Anunnaki, Nephilim and Marduke-Luciferian Anunnaki  of Alpha and
Omega Centauri.  This group proudly refers to themselves as the '' Alpha-
Omega Order of Melchizedeks '' and uses the symbol of a White  Eagle  as an
antagonistic mockery to the Emerald Covenant races , denoting the Alpha-
Omega’s (unfortunate) victory in claiming the Guardian Cerez’s Golden
Eagle APIN. The Golden Eagle was intended to become the symbol of a
free America when the U.S.A. was formed . Instead, the '' white-headed ''
Bald Eagle  became the national mascot, symbolizing the Alpha-Omega
Order’s partial victory  in becoming the directors of a controlling portion of
the US. Illuminati force— the Free Mason-Knights Templar legion.  ''Arch-
(fallen)- angel  (Nephilim) Michael '' is a ''pet contact nam'' used by this
diabolical anti-Christiac Melchizedek collective, as is the '' Alpha-Omega
Melchizedek Orde r.'' At certain times throughout history the Founders had
entrusted this collective to join the Emerald Covenant on “ Redemption
Contracts ,” through which their races could be assisted in gaining freedom
from the Phantom Matrix via restoration of a D-12 Pre-matter “Christiac”
                    Divine Blueprint Template. Repeatedly they  have used  such opportunities  
              to exploit other races and compromise Emerald Covenant freedom
                         
                            370  
             

                             
                          The Sacred Cow, Faces of Man, Easter Island Heads and the Trion Field
agendas , just as their Anunnaki groups have done in their September 12 ,
2000 , defection from the Emerald Covenant Treaty of Altair.  
   lt is important in the contemporary drama for people to realize that the
Melchizede k Cloister and “Order of the Yunasai”  is the universal
organization of the Emerald Covenant Christos Founders races in this Time
Matrix. The Cloister promotes  egalitarian, non-gender biased spiritual -
science freedom teachings for all, and does not promote the utter falsehood
of the “Christ Cruci fixion” story, nor “worship” of external gods.
Melchizedek “priesthoods” of the Alpha-Omega Order  are control
paradigms  based on the dogmas of the Fallen Annu-Elohim, Anunnaki and
Necromiton races, originating from the Phantom Matrix.  As of the Alpha-
Omega false order of Melchizedek’s September 12, 2000, entry into the
United lntruder Resistance (UlR) Edict of War, the Melchizedek Cloister
will no longer offer peace negotiations  to these groups that include their
demand of non-disclosure  regarding their true history of deception and
manipulation of earthly populations. The Alpha-Omega Melchizedek Order
will no longer be permitted to “hide beneath the skirts” of the Emerald
Order    Melchizedek   Cloister   and   the   Christiac Freedom    Agenda, for   which
it stands.             
 THE SACRED COW, FACES OF MAN, EASTER ISLAND HEADS
                                   AND THE TRION FIELD  
   The Cerez-Seraphei and Elohei-Elohim Leonine Emerald Covenant
races will free the caged “White Eagle” APIN and restore the Golden Eagle
to its original dignity  and the Great White Lion APIN will soon awaken
with a loving roar . With the awakening of the Great White Lion and the
Golden Eagle, yet another once-sacred APIN will be restored to its original
grace. The APIN known as the Blue Oxen,  or the '' Sacred Cow ,'' originally
the contact network between Earth and the Maharaji Blue Human
guardians of Sirius B Star Gate-6 , Council of Azurline, once held all of
India  and portions of Eastern Europe and Asia  in its protective embrace.
(See APIN diagrams pp. 527-530.) The Blue Oxen APIN system was jointly
created by the Sirius B Maharaji and a Density-3 Emerald Covenant Bovine
race² from Anteres  and Altair  called the Rashayana  of the Bra-Ha-Rama
Amethyst Order.  
    The Oxen design for the APIN was chosen by the Sirius B Blue Human
Maharaji as a tribute to the Rashayana for their assistance. The Blue Oxen
APIN was created as a specialized interplanetary contact network  in 22,500
BC, in conjunction with a more sophisticated PIN system implanted by the
Emerald Order Founders. In the 10,500 BC  Luciferian Conquest, the Blue
Oxen APIN system was overtaken by the Blue Centaur Fallen Angelic
collective of Omega Centauri,  and has been utilized since this time to
further the OWO dominion agendas of the '' Centaurians '' and their frequent
allies, the Necromiton-Andromie-Anunnaki of Alpha and Omega
Centauri . Through the Final Conflict drama of the 2000-2017 SAC, the
Blue Oxen will also be reclaimed by the Maharaji, to once again become the
                             _____________________________
                              2.    Oxen-shaped biology, Etheric-matter density. 
                                371  
                        
                                                                                                                                                 

                       
                       
                       The Hidden Game-board Final Conﬂict Drama
“Sacred Cow” it was designed to be. The reason why Emerald Covenant races
can succeed  in protecting humanity during the Final Conﬂict drama of the
2000-2017 SAC is due to a specialized APIN system  that allows Earth’ s
Planetary Shields to connect directly with Earth’s counterpart planet in a
different Time Matrix called the Trans-Harmonic Time Cycle . Through this
specialized Founders’ APIN, Earth can enter what is called a Meajhé Field,
Trion Field , or “Tri-Veca Time Continuum,”  through which the planet will
be prevented from being drawn into the Phantom Matrix, and pole shift will
be averted during the 2000-2017 SAC.  
   In 22,500 BC,  just before the failed SAC of 22,326 BC , the Azurite -
Eieyani Universal Star Gate Security Team  of the Inner Earth  Time Cycle
visited the remaining Lumerian Islands  (Muaravhi) and the Mu’a Maji
Human races residing there. With the assistance of the Mu’a,  the Azurite-
Eieyani “Indigo Children”  implanted another PIN system , an advanced
Lumerian -Pylon-Implant Network (LPIN) , in an attempt to stabilize Earth’s
Templar and “resurrect” the Great White Lion and the Golden Eagle APINs
in preparation for the 22,326 BC SAC. The Azurite LPIN  was known as the
''Faces of Man ,'' ancient depictions of which can still be found in the
''heads '' rock  sculptures of Easter Island  off the coast of Peru, which were
erected by Mu’a race descendants after their exile from Kauai, Hawaii.3
There are '' 12 Heads '' in the Faces of Man LPIN system—one  set of four
Heads on Earth,  another set of four Heads on Parallel Earth and the final set
of four Heads on Inner Earth . Collectively, the 12 Faces of Man are known as
the '' Guardians of the 12 Pillars. '' Each set of four Lumerian Pylon Implant
“Faces” grids connects directly to the other two corresponding sets of “four
Faces” on Parallel and Inner Earth. When the Faces of Man LPIN is
activated, four massive pillars of inaudible, interdimensional standing
sound waves  anchor in Earth’s Planetary Shields through the “four Faces”
template. The four Sound Pillars in each planetary body carry the full
frequency spectra of dimensions 3-6-9-12,  a frequency combination known
as the '' Halls of Amorea Passage .'' 
    The Halls of Amorea Passage frequency bridge connects Earth, its
Parallel and Inner Earth directly to the Universal Pre-matter Template
“Divine Blueprint” of Aramatena-Lyra  (“Double-Double”), via D-6 Sirius B
Star Gate-6, D-9 Star Gate-9 Mirach Andromeda  and the  T rans-Harmonic
Time Cycle . The Eieyani intended to activate the Faces of Man LPIN system
during the 22,326 BC SAC,  to place Earth under full D-12 Maharic Shield
and to seal the Phantom Matrix  before the Fallen Angelics of Atlantis
succeeded in drawing Earth into the black hole. In 22,326 BC, in an event
called the Eieyani Massacre,  the Thoth-Enki-Zeta Anunnaki of Nibiru
destroyed the Eieyani civilization in what is now Kauai, Hawaii ; the Eieyani
races would need to wait until the next SAC, the 2000-2017 SAC,  to
complete activation of the Faces of Man LPIN system. The “Faces of Man”
LPIN system was designed in the image of the  Angelic Human race and the
Azurite-Eieyani Maji Indigo Children races of Inner Earth . The “four Faces
                        _____ ___________________
                            
                             3  Other as-yet-undiscovered “Head” sculptures exist in other areas of the globe as well, cre-    
                                     ated at various times to mark planetary grid positions signi ficant to activation of the Faces
                                     of Man LPIN.   
                               372  

   
      The Sacred Cow, Faces of Man, Easter Island Heads and the Trion Field
of Man” LPIN of Earth emerges from a central point  in Earth’s geography in
the Gulf of Guinea , where the '' chins '' of the “four heads” meet at Longitude
0° and Latitude 0°, where the vertical Greenwich Meridian intersects the
Equator. From this center point, each “head” extends as a pillar, two running
horizontally east/west, one above and one below the equator, and two
running vertically north/south, one on each side of the Greenwich Meridian.
The “four Pillars of the Faces of Man” intersect again, where the “front tops
of their heads” connect at Longitude 180° E-W and Latitude 0°, near
Howland Island  in the Equatorial Center Paci fic Ocean.  (See APIN
diagrams pp. 527-530.)  
   T h o u g h  F a l l e n  A n g e l i c s  h a v e  m a d e  n u m e r o u s  a t t e m p t s  a t
compromising the four Faces of Man LPIN system since its installation in
22,500 BC, none have succeeded in “cracking its coding.” The four Faces of
Man LPIN runs on what is called the Khundaray/Kee-Ra-ShA Primal Life
Force Currents  from dimensions 13-14-15 and the Trans-Harmonic
“Trion” Currents  from beyond this Time Matrix. These powerful interstellar
frequencies are far beyond the range and power of those accessible to Fallen
Angelic races. Once brought into critical mass activation , through Humans
and Indigos running “Tri-Veca Rainbow Roundtables,”  the four Faces of
Man and Guardians of the 12 Pillars LPIN system will rapidly clear and
override Planetary Shield distortions  caused by the APIN systems of the
Fallen Angelics. Activation of the four Faces of Man will progressively bring
the Emerald Covenant '' Great White Lion '' and ''Golden Eagle '' APIN
systems fully into original working order, allowing Earth’s grids to remain
balanced as the Phantom Matrix wormholes are sealed  during the 2001-
2004  period of the present SAC. The Great White Lion, Golden Eagle and
the four Faces of Man are the ancient '' Guardians of the Four Corners of
the Earth. '' If humanity assists the Emerald Covenant races in “ Awakening
the Ancient Guardians ''-the LPIN/APIN  systems  left behind as our
Lumerian/Atlantian Legacy—further progression of the UIR OWO
dominion agenda can be averted.                           ____________________________________________________________      
                   If we do not assist, the Illuminati agenda will continue,
         leading humanity into global War, physical “Intruder ET” Invasion,
                                    and pole shift between 2003-2008.                         ____________________________________________________________           
      If we do not think the potential dangers of the Fallen Angelic/Illuminati
OWO agenda are real, perhaps  this  point  will  be  ''driven home''  if  we  explore
a bit more about how the agendas of the Falcon, the Dove, the Serpent, the
Phoenix and the Dragon have unfolded since 1951. It is the progressive
advancement  and  final   amalgamation  of     these   fallen   Angelic   agendas  that
brought us to the ''Trigger Event '' of the September 11, 2001, WTC/Pen-
tagon  Terrorist Attack, and the grim   reality of   progressive international
war that this Trigger Event was intended to set in motion .  
373                                    
                                                                                                                              
                        
                                                                                                                

                        
                        The Hidden Game-board Final Conﬂict Drama
                                                           THE FALCON, PHOENIX PROJECT
                                   AND THE ANDROMIE-RIGELIAN COALITION 1951-1983                                          
     In 1951,  the Alpha-Omega Necromiton-Andromie-Anunnaki
accepted “deals” of collaboration offered b the Jehovian Anunnaki “Dove”
collective , through which they would combine the stolen ''White Eagle '' and
the specialized Jehovian '' Dove '' APIN systems . (See APIN diagrams pp.
527-530.) Together, the '' White Eagle'' and the ''Dove '' would attempt to
open the second ancient Atlantian Wormhole, the ''Phoenix Wormhole ,'' in
order to claim dominion over the Zeta-Rigelian/Drakonian Falcon
Wormhole and Phi-Ex Port Interface Network. The Eagle-Dove Anunnaki
collective was unable to successfully open the Phoenix wormhole, at
Axiatonal Line-7/Ley Line-4 , until the opportunity presented itself in 1972
as other Anunnaki forces who controlled the ancient Phoenix and Serpent
APIN systems  accomplished the feat for them. Presently , due to the 1951
Alpha-Omega Necromiton and Jehovian Anunnaki alliances, the “ Eagle
flies with the Dove,”  and since September 12, 2000 , these combined forces
have made further deals with the '' Falcon, '' ''Phoenix ,'' ''Serpent '' and
“Dragon,” to form the collective anti-Christiac force of the UIR OWO
dominion campaign. The Jehovian Dove and Necromiton-Andromie “White
Eagle” progressively launched sonic scalar pulse  transmissions throughout
the 1950s,  in hopes of opening the ancient Phoenix wormhole to defeat the
rising Zeta-Rigelian/Drakonian Falcon. The Sonic Pulse  and '' Ethnic Virus ''
testing programs  of the covert '' Falcon '' were accelerated in the 1960s, when
they and the Drakonian Illuminati began using the Falcon Network to create
targeted climatic and seismic disturbances  to further their hidden political-
positioning agendas  in the international arena. The Andromie-Necromiton
White Eagle and Jehovian Dove forces continued a quiet invasion strategy of
building subterranean and marine bases in key Star Gate control areas of
Earth, and began making more direct contact with key controllers in several
Illuminati factions. The various competing Pleiadian and Nibiruian
Luciferian Anunnaki forces  were “in a tizzy ,” as they watched their long-
cosseted, exquisitely orchestrated, Atlantian take-over agenda become
progressively “hi-jacked” by the Drakonian force.  
     In 1972  the Zeta-Drakonian Falcon force began to expand the next
intended wave of territorial conquest, attempting to use the Phi-Ex
Network  to gain control over the Anunnaki’ s “prize possession,” the Great
Pyramid of Giza, Egypt . Since Atlantis, Planetary Star Gate-4 at Giza has
assisted the Anunnaki in controlling the D-4 NET,  as it is the site where
Universal Star Gate-4 , the D-4 astral Solar Gate , connects to Earth’s
Planetary Shields. The Luciferian Anunnaki intervened directly in 1972,
in a partially successful attempt at preventing the Zeta-Drakonian Falcon
Phi-Ex Network from overtaking Anunnaki holdings at Giza. The  Pleiadian
Samjase-Luciferian-Anunnaki  made alliances with the Nibiruian Enlil-
Odedicron-Reptilian Anunnak i. Together they used the portions of the
NDC Grid, the NET and Nibiruian Crystal Temple Network that they could
collectively access, to expedite the agenda they had originally intended for
the 2000 commencement of the SAC.  
374    
                        
                           

     
                                                                                                 
                                                                                              The Falcon, Phoenix Project...
    The '' Phoenix Project ,'' which had existed since the beginning as part of
the 9560 BC Luciferian Covenant, was actively launched in February 1972.
The Pleiadian/Enlil-Nibiruian Anunnaki force simultaneously transmitted
sub-space scalar sonic pulses  from Density-2 Alcyone and the Nibiruian
Battlestar “Wormwood”  into the D-4 Solar Gate  to Giza (Ley Line-4), Iran
(Star Gate-10) and into Earth’s NDC-Grid at Stonehenge, England
(Axiatonal Line-l1, or A11). The specialized A11-L4 pulses  merged at their
intersection point  in the Atlas Mountains  of W . Algeria then traveled west
beneath the Atlantic Ocean to their intended destination, the second of the
two “capped” Atlantian Wormholes , referred to since Atlantian days as the
“Phoenix Matrix .” The Phoenix wormhole, opened by the Pleiadian-
Nibiruian Anunnaki in 1972, is positioned directly at the interface point  of
Ley Line-4, the '' Giza Horizontal ,'' and Axiatonal Line-7 (vertical), which
intersect off the coast of St. Augustine, FL , in the Atlantic, directly south
of the Falcon wormhole.  The “Frequency W ar” began in earnest when the
Necromiton-Andromie White Eagle and Jehovian Anunnaki Dove began
aggressive territorial conquest campaigns, gaining partial control of the
Phoenix Wormhole, in an attempt to protect their interests from the
advancing Pleiadian-Nibiruian Anunnaki competition.  
     As the Pleiadian-Nibiruian “reptile Anunnaki league ” advanced their
agenda, the Jehovian Dove and Necromiton-Andromie White Eagle  began
more direct contact with their Illuminati Sleeper races. Enoch , then heading
the Jehovian Dove OWO agenda, produced his “training manual” to lead
unsuspecting Humans and Illuminati Sleepers to assist in bringing the Dove
APIN system into activation . Although Enoch and some of his Jehovian
Anunnaki (Sirius A, Arcturus, Trapezium, Orion) petitioned for Emerald
Covenant Redemption Contracts in 1983 , the “Jehovian OWO Agenda”
has been continued by the Jehovian Anunnaki majority and their Illuminati
contacts under the name of Enoch, much to Enoch’s present disapproval. The
White Eagle Necromiton-Andromie league  began upscaling its
''Harvesting '' agenda,  orchestrating numerous contacts with Illuminati and
Human individuals to “invite” them into their Templar Alpha-Omega Order
“Melchizedek Priesthood.” Ordinands and followers alike received,
unknowingly, astral field Tagging  linking their DNA Templates  to the
Necromiton-Andromie Matrix, through which they could unknowingly pass
on the “same privilege” to others in the form of false  “Melchizedek
Ordinations.”4 As the Jehovians, Necromiton-Andromies and Zeta-
Rigelian/Drakonians progressively advanced their agendas throughout the
1970s into the early 1980s , giving rise to more international “political
issues” of territorial conquest, the Pleiadian-Nibiruian Anunnaki continued
their own conquest efforts.  
    A  series of smaller EM scalar pulses were used by the Pleiadian -
Nibiruians  between 1972 and 1980  to progressively open the ancient
Phoenix APIN system,  which connects to the Phoenix wormhole. The
Phoenix APIN  is a large APIN system running East-West along the L4/L10
                          ____ ________________
                         
                                4.    Nothing outrages the Founders quite as much as observing the sacred Melchizedek Clois-
                                           ter Emerald Covenant spiritual-science teachings abused and misused in such a way.    
                                375                                                            
                                                                                                                                                               

                                                                                                                                         
                        
                        The Hidden Game-board Final Conﬂict Drama
                  Giza-Iran center line.  The '' hear''  of the Phoenix is Star Gate-4 Giza,
Egypt ; the ''eye'' of the Phoenix is Star Gate-10 Abadan-Iran  (near Persian
Gulf); the body of the Phoenix extends across the Atlantic and North
American continent; and its wings spread eastward to “meet its tail” in the
Pacific Ocean. (See APIN diagrams pp. 527-530.)  
     In 1976 , another Nibiruian Anunnaki  contender, the Thoth-Enki-Zeta
group , temporarily joined the Pleiadian Samjase-Luciferian and Nibiruian
Enlil-Odedicron reptilian Anunnaki contingent to activate the '' Serpent ''
APIN system.  The '' Thoth group ,'' most frequently affiliated with the
''Galactic Federation '' mixed Anunnaki league and the Necromiton-
Andromie Anunnaki  early alliances following the fall of Atlantis, “turned
coats” for a brief period, just long enough to receive the assistance of the
“Phoenix” group in activating the Thothian Serpent APIN system. The
Serpent APIN system has its “head” in Central America and Mexico. It coils
southward into northwestern South America, back northward, spanning the
entire eastern USA, then stretches across the Atlantic Ocean, with its
“heart” at England Star Gate-11, its body curving down through the Middle
East and Star Gate-4 Giza, and its “tail” extending north through Eastern
Asia. (See APIN diagrams pp. 527-530.) By 1983,  the Thoth group returned
to its “White Eagle” affiliations, once again competing with the Pleiadian-
Nibiruian Anunnaki of the Phoenix Project, while the Galactic Federation
focused upon supporting whomever appeared to be leading in the Fallen
Angelic “race” for final OWO dominion.  
       
                           ANDROMIE-RIGELIAN COALITION, THE DRAGON, BIN LADEN
                                          AND THE “WAR ON TERRORISM” 1980-2001                 
   By the early 1980s, Pleiadian-Nibiruian Anunnaki legions  had made
alliances with various factions of the regained strongholds within several key
positions of the Illuminati World Management Team,  threatening previous
Zeta/Drakonian Illuminati dominion. In hopes of retaining Zeta/Drakonian
dominance within the covert global Interior Government sector, Zeta
Rigelian  races of Rigel Orion petitioned the assistance and collaboration  of
the Necromiton-Andromie  races. The Rigelians negotiated between
Drakonian-sympathetic factions of the “White Eagle” Necromiton-
Andromies, and the Omicron-Drakonian and Odedicron-Reptilian legions of
Orion, forming the Andromie-Rigelian Coalition ; a ''friendly enemies '' deal
aimed at disempowering the advancing ''Phoenix Project'' Anunnaki
Illuminati influence on Earth. Not all Necromiton ''White Eagle'' factions
agreed to participate in the pro-Drakonian agenda Andromie-Rigelian
Coalition,  due to favored connections among the '' Dove '' Jehovian
Anunnaki races. The factions of the White Eagle Necromiton-Andromies
that favored the Zeta-Rigelian/Drakonian Falcon agenda entered the
Andromie-Rigelian Coalition, and began using their access to White Eagle
APIN sites to further the Falcon agenda. The White Eagle Necromiton-
Andromies opposed to the Falcon agenda  offered greater support to Jehovian
Anunnaki Dove  factions, and Ashtar Command’s  ''Arcturian '' Anunnaki
lent their assistance to the White Eagle-Dove cause. Many Drakonian,
Reptilian and non-Rigelian Zeta forces, opposed to or fearful of the  
376 
                 
                 

          
   Andromie-Rigelians, Dragon, bin Laden and the “War On Terrorism”...  
Necromiton-Andromie force, refused to enter the Andromie-Rigelian
Coalition deals, and the Drakonian/Reptilian Illuminati races began
breaking into opposing factions,  causing ripples of further instability within
the external world political drama.  
    The majority of Omicron-Drakonians5 of Alnitak Orion, and a large
faction of Odedicron-Avian-Reptiles  from Alnilam-Orion, refused the
Andromie-Rigelian Coalition ''White Eagle-Falcon'' deal, and set their sights
on activating their ancient '' Dragon '' APIN system,  which had been
implanted in Earth’s grids in 75,500 BC.  The Dragon APIN has its “head” in
what is now far eastern Siberia  and northeastem China  and Japan . Its long,
thick “body” extends westward across Asia, the Middle East, Africa, Russia,
Europe, crosses the Atlantic ocean to the Central USA and south into
South America. (See APIN diagrams pp. 527-530.) The majority of the
''Dragon '' agenda races also refused to join the UIR  deal of September 7-
12, 2000, choosing instead to “fight to the end” for the Omicron/Odedicron
Drakonian OWO agenda.  
    In our contemporary drama, the Islamic extremist faction  called the
Taliban of Afghanistan , is headed by several, well-placed Illuminati that are
covertly motivated by the Omicron-Odedicron ''Dragon '' agenda  Fallen
Angelics. The terrorist group of Osama bin Laden , on the other hand, works
a ''double-agenda '' on behalf of the UIR Zeta-Rigelian “Falcons” and the
Omicron-Odedicron Dragon force. In the WTC/Pentagon drama  of
September 11, 2001, the bin Laden group was covertly motivated by the
UIR to assist them in creating the “ Trigger Event ” that is intended to set the
''wheels'' of the WW3 drama  in motion. The UIR also knew that this event
of bin Laden terror would ensure that the rebelling Dragon agenda Taliban
Illuminati would be forced out of power in Afghanistan , making way for
UIR governance. As the UIR intended, the many Angelic Human and Maji
populations of Afghanistan  would be ''conveniently'' reduced in number
through orchestration of this international drama. The bin Laden terrorist
group evolved first under the Falcon agenda  in the 1970s, covertly motivated
by the Zeta-Rigelians with Psychotronic scalar pulses, to '' build the
movement '' that was  intended  to become a Falcon '' Sleeper Cell Force ,''
once the Final-Conflict WW3 drama had begun. Due to the UIR’s present
acceleration of their OWO dominion plan , the bin Laden group was instead
used to set the UIR WW3 drama in motion.  
    The Eieyani tell us that there are numerous such '' Illuminati Sleeper
Cells '' of various ethnic, cultural and religious backgrounds  in at least 15
different countries . Various Fallen Angelics began organizing these
Illuminati factions in the 1950s-1960s , in order to ''have them in place
awaiting their awakening,'' when the Final Conﬂict began. The
contemporary '' War On Terrorism '' goes much deeper and ''higher '' than
world political leaders suppose ; it is a war that cannot be won until the
causal element of the hidden Fallen Angelic/Intruder ET presence is fully
identi fied. The Final Conquest for Star Gate and Templar control site
dominion is on, and the WW3 drama is the method by which the Fallen
                             _________________________
                             5.  Dragon-moths   
                                                                                                                377                                                                                                                    
                                                                                                                                                                                                                                                

                           The Hidden Game-board Final Conﬂict Drama
Angelics of the UIR intend to lay claim to desired territories, while
reducing numbers of Angelic Human and Indigo Children populations .
     Areas such as Pakistan, Iraq and Iran  are territories housing key access
sites to the coveted  Star Gate-10,  so these areas, as well as several others,
will be preliminary “zones of conquest”  that the UIR will attempt to secure
under UIR Illuminati governance. Egypt, home of the OWO key control site
Star Crate-4, will experience sporadic areas of rebellion as “Dragon” agenda
Illuminati races are motivated by the Omicron-Drakonian forces to resist the
national-compliance inherent to UIR objectives.  
    Tibet , home of Star Gate-9 , is also precariously perched to become the
objective of competing Dragon and UIR-Dove “affections.” Jerusalem,
Israel,  has long been a battleground for control of Primary Planetary
Vortex-2,  a direct link to Star Gate-2,  the Gru-AL  “Holy Grail Point” of
Sarasota, Florida , which is the '' control gate '' for Earth’s Planetary Shields.
And the U.S.A . has been, since formalization of the Luciferian Covenant in
9560 BC Atlantis , the intended arena  within which the Fallen Angelic
Final-Con ﬂict drama '' Battle of Armageddon '' is planned to unfold, making
way for the '' Rise of the One World Order. '' The Emerald Covenant races
have repeatedly returned to Earth incarnation in attempts to prevent this
Fallen-Angelic-devised ''End Times '' scenario  from occurring.  
          
                   MONTAUK PROJECT, “WAR IN THE HEAVENS, ”  
            SONIC PULSE AND “UN-NATURAL DISASTERS” 1983  
    Through the Andromie-Rigelian Coalition deals of the early 1980s ,
Illuminati races originally running the Falcon agenda under command of the
Rigelians and the Zeta Treaties suddenly found their 1930s Zeta Treaties
were nulli fied. The fate of the Drakonian Illuminati was placed forcefully
and precariously in the hands of the new, fully dictatorial Necromiton -
controlled Andromie-Rigelian-Coalition.  T o strengthen the Necromitons’
covert access to Earth territories, the 1983 Montauk Project  was organized
by the Necromiton-Andromie White Eagle  and Zeta Rigelian/Drakonian
Falcon  forces, through cooperating (and now terri fied of rebelling) Illuminati
factions.  
   Through the Montauk Project, the Phi-Ex Wormhole from 1943 was
“spliced into,” directing a main channel to Necromiton-Andromie Alpha-
Omega Centauri territories in the adjacent Phantom Time Matrix . The
Necromiton races now had extensive access to Earth territories, and they
began a covert genocide program  against Illuminati races that would not join
the Andromie-Rigelian Coalition. The Illuminati fiasco of the 1930s-1940s
turned into the Illuminati chaos of 1983.  In response to the threat of the
Andromie-Rigelian Coalition, the Omicron-Drakonian  forces of Alnitak
Orion  sent large fleets into the Density-26 and Density-37 territories
surrounding Earth-Tara-Gala, with the intention of protecti ng the interests
of the original Drakonian/Reptilian Dragon OWO agenda. In response to
this advancing Drakonian/Reptilian presence, various competing Anunnaki
________________________  
                              6.    Dimensions 4-5-6.  
                                 7.    Dimensions 7-8-9.
                               378                                                                                                               
                                                                                                                                             
   

                                                                                                  
                                                
                                         Guardian Intervention and the Bridge Zone Project 1983-1992
legions of Sirius A, Arcturus, Pleiades-Alcyone, Nibiru, Andromeda,
Orion, the Galactic Federation and Ashtar Command  sent ﬂeets of
reinforcements into proximity of Earth access points.  
    Warring  in Densities 2 and 38 broke out between competing Anunnaki
and Drakonian/Reptilian forces, in both our Time Matrix and the Phantom
Matrix. The '' war above '' became the covert  ''War of Frequency '' below , as
each group intensi fied its use of sub-space sonic scalar pulse technologies  to
secure their holdings of various APlN sites. The progressive use of covert
sonic pulse technologies, which was progressively accelerated by the Fallen
Angelic legions since the  1950s , was directly responsible for a host of
regionally cataclysmic “natural disasters,”  particularly those involving
Earthquake and Hurricane  events. (“Sonic Pulse “Un-Natural Disasters”
1935-1992 Summary Chart” on page 522.)  
                            
                                     GUARDIAN INTERVENTION  
                AND THE BRIDGE ZONE PROJECT 1983-1992 
      Throughout this mess of interstellar chaos at our earthly door , Emerald
Covenant Maharaji  fleets from Sirius B , Tara and Gaia and the many
interstellar Emerald Covenant nations have tried to sustain a frequency
“buffer zone ” around Earth access points. The GA, Eieyani and Founders
have done their best to prevent this growing intergalactic “Battle of the
Angelic and Fallen Angelic Kingdoms” from descending into Density-1
Earth territories. The Emerald Covenant Founders races of Lyra Aramatena9
intervened directly . They became aware that by  2976  Earth would be
destroyed, before the intervention opportunity  of another SAC  could occur,
if Zeta Rigelian/Drakonian occupation of Earth was successful during the
2000-2017 period. Between 1983-1984  the Founders, GA, lnterdimensional
Association of Free Worlds and Emerald Covenant nations created the
Bridge Zone Project  crisis-intervention plan (see page 142).  
   Through tenets of the Bridge Zone Project initiative , Amnesty
Contracts were offered to any interstellar races in our Time Matrix willing to
enter the Emerald Covenant Peace Treaty. Redemption Contracts  were
offered to the Fallen Angelic/ET races from the Phantom Matrix, in which
they would receive the extensive assistance needed  to become free from the
Phantom Matrix Time Cycles, if they would enter and honor the Emerald
Covenant. Many non-Rigelian Zeta races  accepted Amnesty and
Redemption Contracts, fearful of the building “ Super-Stellar-powers Final
Conflict” drama.  Guardian races were hoping that Anunnaki legions  could
be persuaded to give up their long-held OWO dominion agenda to make a
United Emerald Covenant Stand  against the dominant Drakonian/Reptilian
Necromiton-Andromie/Zeta-Rigelian “Falcon” force. Smaller factions  of
some Anunnaki collectives, such as the Jehovian Enoch collective  of Sirius
A, Arcturus and Orion, gave up their previous OWO Jehovian Anunnaki
dominion agenda  in 1983 for Emerald Covenant Redemption Contracts.
___________________________  
8.    Dimensions 4-9.  
9     Lyra Aramatena is Density-4, dimensions 10-11-12 and appears as the star “Double Dou-                                                                     
       ble” in Lyra from Density-1 Earth view.   
379                                                                           
                                                                                                         

                           
                          The Hidden Game-board Final Conﬂict Drama
Other Anunnaki factions, such as Ashtar Command , the Nibiruian-Thoth-
Enki  collective, the Galactic Federation , the Pleiadian-Samjase-Luciferian
collective, the Marduke-Dramin  collective, the Alpha-Omega Nephilim
Annu-Melchizedeks  and Necromiton-Andromies  held onto their respective
OWO agendas until their “ ultimate stronghold”  was considerably
compromised in 1992.                       
                        THE PLEIADIAN-SIRIAN AGREEMENTS  
                               AND HURRICANE ANDREW 1992 
    Since implementation of the NDC-Grid Photo-sonic installation and
the NET of 25,500 BC Atlantis,  the Anunnaki races have steadily moved
their intended Atlantian Conspiracy Luciferian Covenant OWO dominion
agenda forward through remote Photo-sonic control  of Earth’ s Planetary
Templar Complex via the NDC-Grid.10 Throughout the progression of the
1980s Andromie-Rigelian Coalition agenda, the Anunnaki races remained
confident of their ultimate victory and OWO dominion within the pending
2000-20I7 AD SAC Final-Con ﬂict drama. The Anunnaki believed that they
would be able to use the NET to awaken and manipulate enough of their
civilian Illuminati Sleeper Races, and unsuspecting Human races within the
''channeling '' movement,  to make a stand against the Illuminati factions that
they had lost to the Necromiton-controlled Andromie-Rigelian Coalition.
The Anunnaki intended to use  ''channelers '' to teach unsuspecting
Illuminati Sleepers and Human populations how to orchestrate false
planetary healing operations  utilizing distorted Biotronic scalar-pulse and
Merkaba Mechanics  technologies  that would be ampli fied through the
NDC-Grid.  Through these distorted Biotronic/Merkabic technologies, the
Annunaki believed they would be able to reclaim from competing forces
Earth’s 12 Primary Star Gate territories and corresponding Ley Line systems,
as each Star Gate naturally opened during the 2000-2017 SAC.  
    In  1992  Anunnaki legions were confronted with yet another unpleasant
surprise as Andromie-Rigelian and collaborating factions of the Omicron-
Drakonian and Odedicron-Reptilian Falcon force began to utilize the
Montauk-Phi-Ex Wormhole and Falcon APIN system to gain control over
the Anunnaki NDC-Grid and the NET via scalar pulse transmissions.
Suddenly the overly con fident Anunnaki  forces became willing to enter
negotiations for Emerald Covenant Redemption Contracts  with Emerald
Covenant nations.  
    Because the Anunnakis feared complete loss of their NDC-Grid/NET
stronghold on Earth, some of their leading factions reluctantly entered the
Emerald Covenant Pleiadian-Sirian Agreements  in November 1992 . In
these agreements, the Pleiadian and Nibiruian Anunnaki  legions and
portions of Galactic Federation  and Ashtar Command  agreed to put the
NET/NDC-Grid installation  and their artificial hold on Solar Star Gate-4
back under Guardian Azurite Universal Templar Security Team
protection . The Andromie-Rigelian Coalition had their immediate sights set
on conquest of Anunnaki-held Nibiru , a planetary environment more
___________________________  
10.   See Masters Templar Coursebook,  forthcoming.  
380 
                   

                                            
                                          The Pleiadian-Sirian Agreements and Hurricane Andrew 1992
suitable to Necromiton-Andromie biological requirements and a strategic
“power spot ” in relation to conquest of Earth and dominion over the Halls of
Amenti. The Pleiadian-Nibiruian Anunnaki of the “Phoenix” and “Serpent”
APIN systems promised to honor the Emerald Covenant if the Founders
would assist them in using the NET/NDC-Grid to close by force  the
Necromiton-controlled Montauk-Phi-Ex/Falcon Wormhole . If utilized by
Guardian races via Sirius B Star Gate-6 , the already operational NET/NDC-
Grid installation could be reprogrammed to carry and amplify D~12 and
Primal Life Force Trion Currents from beyond this Time Matrix. If returned
to the protection of the Emerald Covenant nations, the NET/NDC-Grid of
Earth had the power to temporarily seal or “Cap” the Montauk-Phi-Ex/
Falcon Wormhole,  preventing the Andromie-Rigelian “Falcon-Eagle,”
Omicron-Odedicron Drakonian “Dragon” and Jehovian Anunnaki “Dove”
raider races from further advancing their Earth-Nibiru-Amenti dominion
agendas. Emerald Covenant races had been trying unsuccessfully to cap the
Montauk-Phi—Ex/Falcon Wormhole since WW2.  On August 12, 1992,  they
had almost succeeded when the Zeta Rigelians, with the assistance of the
Necromiton-Andromie '' Montauk Boys ,'' launched a vicious sonic pulse
transmission from their Star Gate-3 Bermuda base , into the Falcon
Wormhole, further expanding the Falcon  and preventing application of the
frequency cap.  
    The unstable expansion of the Falcon W ormhole caused major deep
marine disturbances  throughout the Atlantic Ocean, reports of which the
Illuminati Withheld from public disclosure. On August 24, 1992 , the Falcon
wormhole amplified the intensity of Hurricane Andrew,  creating wind
speeds in the range of 250-300 m.p.h. Hurricane Andrew changed direction
suddenly , heading for the Dade County, FL, area. The Falcon agenda
Illuminati knew of the direction change in time to call for evacuations , but
their Fallen Angelic Necromiton-Andromie ''commandos'' ordered them to
''misplace '' this information  and give warning only when evacuation time
was spent. The Zeta-Rigelians and Necromiton-Andromie forces used
Hurricane Andrew to secure yet another Human and Maji ''Population
Reduction '' event . The devastation of Hurricane Andrew was one of the
greatest recorded “natural” disasters in US history. When the Pleiadian-
Nibiruian Anunnakis finally decided they wanted to “deal,” and offered to
turn over their NDC-Grid, NET, Phoenix and Serpent APIN systems to
Emerald Covenant races, the opportunity to safely cap the Falcon Wormhole
was finally at hand. In November 1992,  the Pleiadian-Sirian Agreements  of
the Emerald Covenant Peace Treaty were formalized.  
381 
                                                                                                                                             
                     
                                                                                                                            

  
                        The Hidden Game-board Final Conﬂict Drama
                                                  TEMPORARY CAP ON THE MONTAUK
                                                       PHI-EX WORMHOLE 1994-1998           
   When the 1992 Pleiadian-Sirian Agreements were initiated, both
Emerald Covenant and Pleiadian-Nibiruian Anunnaki races, and the
Galactic Federation, made subtle and physical contact  with selected
members of the Illuminati and Interior World Government forces, offering
them opportunity to defect  from Andromie-Rigelian and Drakonian/
Reptilian “ Falcon-Eagle ” dominion. Through a temporary photo-sonic
interface system  created by the Emerald Covenant Maharaji  Blue Human
races of Density-2 Sirius B , portions of the NET/NDC-Grid  were able to
receive and transmit speci fic scalar pulses through Earth’s Templar that
served to '' jam' ' the frequencies  used to sustain the Montauk-Phi-Ex
Wormhole.  
   By 1994 , the united Emerald Covenant and Anunnaki legions
successfully created a temporary ''cap '' on the Montauk-Phi-Ex APIN
system , and a partial cap  on the Falcon wormhole ''hub.'' The Montauk-Phi-
Ex/Falcon cap prevented the Necromiton-Andromies Zeta Rigelian, and
Drakonian/Reptilian fleets from furthering their intended covert infiltration
of Earth’s subterranean bases. The Montauk-Phi-Ex Cap was a temporary
solution that depended upon the Anunnakis upholding the Pleiadian -
Sirian Agreements . In these agreements the Anunnaki legions had promised
to release Earth from Nibiruian subjugation, dismantle the NET  and
return the NDC-Grid and Solar Star Gate-4,  which they had “hijacked by
force” during the 25,500 BC Lucifer Rebellion, back over to the Emerald
Covenant Founders’ protection by 2000.  
   Had the Anunnaki races upheld the Pleiadian-Sirian Agreements,
Emerald Covenant races would have used the NET/NDC-Grid installation
on Earth to accomplish two vital Bridge Zone Project crisis intervention
initiatives.  The most pressing intervention needed was that of rapidly re-
balancing  Earth’ s electromagnetic Merkaba fields to prevent pending pole
shift  from occurring during the 2000-20l7 SAC, due to the original,
inorganic Photo-sonic program of the NDC-Grid. The second intervention
was that of using the  NET/NDC-Grid network during the SAC  to
permanently seal the Montauk-Phi-Ex/Falcon Wormhole and the Phoenix
Wormhole , while activating the Face of Man LPIN system  and the Great
White Lion, Golden Eagle and Blue Oxen APINs . Success in these
objectives would prevent further Fallen Angelic invasion, setting in motion a
Free World Order of Emerald Covenant interstellar co-evolution  on Earth.
  From 1994-1998  Pleiadian-Nibiruian Anunnaki, Galactic Federation
and Emerald Covenant in ﬂuence gained dominance within many Illuminati
factions. Preparations were being made among cooperating Illuminati
alliances to begin non-threatening, progressive public release of ''ET-
           Angelic Presence Confirmation '' via Official Global Proclamation. As part
           of the Pleiadian-Sirian Agreements,  Emerald Covenant races had agreed to
        wait  until humanity had dealt with the initial revelation of the reality and
        immediacy  of ''Visitor Contact '' before releasing the full historical data  
                  
                   382                                              
                          

                               
                                              
                                                 
                                           Temporary Cap on the Montauk Phi-Ex Wormhole 1994-1998
concerning Anunnaki infiltration via the Atlantian Conspiracy Luciferian
Covenant agenda.  
    Without use of the earthly NDC-Grid installation  and natural
realignment of Solar Star Gate-4,  Emerald Covenant races would be unable
to prevent pole shift,  nor would they be able to seal the Montauk-Phi-Ex/
Falcon Wormhole, without launching immediate physical on-planet
presence of fleets capable of advanced Photo-sonic scalar pulse
transmission . If Guardian ﬂeets attempted to deploy direct physical presence
on Earth, they would be intercepted by Necromiton-Andromie, Rigelian-
Zeta, Drakonian and Reptilian fleets, setting in motion a literal '' Star Wars ''
drama within and surrounding D-3 Earth territories. Such a Star Wars drama,
utilizing the Photo-sonic and Photo-radionic technologies possessed by all
interstellar races, would not only decimate large portions of Earth
populations, but would also guarantee pole shift  by further disrupting the EM
balances in Earth’s grids during the 2000-20l7 SAC. An easy, peaceful
victory on Earth over the pending Fallen Angelic/Illuminati OWO Final
Conﬂict drama depended upon the Anunnaki races honoring their
promises of Emerald Covenant support and cooperation with Guardian
nations—promises that were made in the 1992 Pleiadian-Sirian
Agreements.   
        The 1994    capping   of     the    Phi-Ex Wormhole  gave   the  Anunnaki   races
opportunity to once again advance their influence  among the Illuminati
races of the World Management Team. If they had been honoring their 1992
Agreements, this “in ﬂuence” would have progressed in representation of the
Emerald Covenant . The Anunnaki and Emerald Covenant races continued
to initiate a slow but steady “wake-up call ” among their respective civilian
Sleepers. The Anunnaki released the message among some of their channels
that “the Zeta races had left Earth and there was nothing now to fear.” The
originally sinister intentions of the Anunnaki-orchestrated aspects of the
“New Age Movement” brieﬂy became upgraded to support the Emerald
Covenant peace treaty and freedom teachings, creating a renewed solidarity
between once-competing ideological factions in the New Age arena.  
    In 1997  Guardian races began the “wake-up call” to their Emerald
Covenant Speakers and Indigo Children, in preparation for the scheduled
release of the Emerald Covenant teachings pertaining to Masters Planetary
Templar Mechanics, which were to be given once  consummation of the
2000-2017 SAC  was confirmed.  Plans were made among Anunnaki loyal
Illuminati and Human members of the World Management Team to begin
“Official Disclosure ” of “Visitor Race Presence.” Official Disclosure was
intended to prepare human populations to make a united, peaceful stand  in
protecting Earth’s territories from further advancement of the several
competing Fallen Angelic OWO invasion agendas, using the natural,
spiritual-science based tools of Masters Planetary Templar Mechanics.  
    Guardian races intended to release the Emerald Covenant Masters
Templar Mechanics teachings  into the public forum, to educate Humanity
in the methodologies required  to orchestrate Planetary Shields Clinics,
through which Earth’s EM grids could be rapidly healed to prevent pole
shift  from occurring should the 2000-2017 SAC commence as anticipated. If
the 2000-2017 SAC commenced , Guardian races intended rapid    
383  
                                                                                                                                              
                              

  
                    
                        The Hidden Game-board Final Conﬂict Drama
dispensation of information  pertaining to humanity’ s invitation into the
Lyran-Sirian Founders Emerald Covenant Co-Evolution Peace Treaty , and
the awakening and training of the Amenti Planetary Templar Security
Team  was to immediately commence. The Amenti Security T eam was
intended to be trained to assist Guardian nations in using the NDC-Grid
installation  to permanently sever the link between Earth and the
Montauk-Phi-Ex/Falcon and Phoenix Wormhole , preventing further Fallen
Angelic in filtration. Once the Montauk-Phi-Ex/Falcon and Phoenix
Wormholes were permanently shut, Fallen Angelic races would be unable to
send in larger ﬂeets to intercept and initiate “Star Wars” with Guardian ﬂeets
as they made their inevitable '' First Contact '' mission. As 1998 approached,
all appeared to be going relatively well within the delicate political balances
of the 1992 Pleiadian-Sirian Agreements.  
                
         ANUNNAKI DEFECTION, FALCON UN-CAPPED, INDIGO  
                     HUNTING AND EDICT OF WAR 1998-2001 
   When it became clear in June 1998  that the SAC would commence in
2000, the Pleiadian-Samjase-Luciferian, Nibiruian-Enlil-Odedicron,
Thoth-Enki-Zephelium  and Galactic Federation Anunnaki  collectives
immediately defected  from the Pleiadian-Sirian Agreements, seizing this
opportunity to continue activation of the Phoenix and Serpent APIN
systems for Earth conquest. They made deals with the Jehovian “Dove” and
Necromiton-Andromie “White Eagle” to interface their NET/NDC-Grid
and APIN systems  with the Zeta-Rigelian/Andromie Montauk /Phi-Ex
facility  in order to undo the access to Earth’ s T emplar that Emerald
Covenant nations had recently gained. They rapidly began to “set the stage”
for “ Lowering the NET ” into the D-3 Frequency bands via  interface with
earthly electrical-grid technologies  to create the 2004 '' Frequency Fence ''
mass-mind-control network.  
    The Alpha-Omega Nephilim Annu-Melchizedeks  began an aggressive,
sweetly rendered “ Indigo Child Hunting ” campaign within the New Age
Movement, hoping to locate as many Indigo people (especially Type-3
Human-Anunnaki hybrids) for astral Tagging  and DNA  bonding-bio-field
possession. Great efforts were applied to directing the “Channeling”
movement via the NET/Phi-EX  transmitting station, through which a
progressively growing number of infiltrated  Illuminati and Human “ Greeting
Teams ” were assembled among Earth populations ¹¹ 
    As the Anunnaki Greeting T eams advanced in the New Age movement,
many Anunnaki legions that had remained loyal to the 1992 Pleiadian-Sirian
Agreements finally defected under growing pressure from the Galactic
Federation and the Nibiruian Thoth-Enki Anunnaki collectives. Numerous
popular '' Energy/Spiritual Healing Systems '' were in filtrated and
progressively used to orchestrate astral Tagging  in New Age populations.
  
                         _____________________
   
                             11.      Check out the Galactic Federation, “Archangel Michael” and several other very popular
                 New Age and UFO Contact movement representatives and you’ll get an idea of how well  
                 the Fallen Angelic “Greeting Team” effort is going.
                             384  
                           
                     

                                        Anunnaki Defection, Falcon Un-Capped, Indigos, Edict of War. 
Meanwhile, many un-awakened Indigo Children and Humans became
infiltrated with Anunnaki implantation, possession and '' pseudo spiritual ''
indoctrination , and the “Michael Matrix,” Zeta-Rigelian and Dracos stepped
up their own interest in the '' Body-Snatching game .'' This caused a
progression of disputes among Anunnaki factions and between Anunnaki
and Drakonian agenda forces.  
  Between 1998-1999, the Zeta Rigelian and Necromiton-Andromie
Falcon-White Eagle force , with the assistance of their '' Montauk Boys ''
Illuminati, successfully removed the partial cap on the Falcon wormhole and
partially ripped through the Montauk-Phi-Ex wormhole cap. “ Un-capping
the Falcon ” allowed them to reactivate portions of their global Montauk-
Phi-Ex-Falcon/White Eagle APIN system, through which Psychotronic  and
sub-space Sonic Scalar Pulse  transmissions capacity was restored. Since this
1998-1999  fiasco began, Emerald Covenant nations have used their once-
again limited access to NET transmission to '' poke holes '' in the NET, by
which their Indigo Children Types-1 and 2 could receive a rapid emergency
“wake-up call .¹² Expedited Emerald Covenant CDT-Plate translations
began in late 1999, after the original May 1999 simultaneous publication of
the Voyagers I and II.  
  Throughout 1999-2000, Emerald Covenant races have continued
negotiations in attempts to resurrect the Pleiadian-Sirian Agreements with
Anunnaki races, temporarily securing the July 5, 2000, Treaty of Altair
with the Anunnaki and several renegade races, due to the continuing
disputes between Anunnaki and Drakonian agenda factions. Between
September 7-12, 2000,  the Andromie-Necromitons  settled several pending
Anunnaki/Drakonian disputes over intended distribution of captured Inner
Earth territories, the UIR was formed and their War Edict  was issued on
September 12, 2000.  
___________________________________________________________
Since September 12, 2000, Emerald Covenant nations and awakening Indigo
Children and Humans  who have not yet succumbed to Fallen Angelic astral
 tagging, etc., have been working with progressively more advanced Masters
                   Planetary Templar Mechanics  to secure Earth’s Templar
                                       under a critical-mass 12-Code Pulse before the 2003 deadline.                                                      ____________________________________________________________
                             
                             
                             ____________________________
                                 12. Scalar transmissions to activate dormant portions of the DNA Template.
                              385  
                                                                                                                                           
                              

                                                     
                                                                                               19                                                                       
                                                                                                                  
                                     
 
                                           The Wall in Time
                and Atlantian Secrets of the
                   Phoenix and the Falcon
              
                                     DIMENSIONAL BLEND EXPERIMENT, WALL IN TIME,
                                              AND THE ILLUMINATI MASTER PLAN 2003
            
   The contemporary United Intruder Resistance (UIR) Illuminati One
World Order (OWO) Master Plan is an amalgamation of key components
of the previously disclosed competing fallen Angelic/Intruder ET OWO
agendas.  The UIR has adopted the long-planned '' 2003 Dimensional Blend
Experiment '' and “ 2004 Frequency Fence ” plan originally of the Zeta -
Rigelian Agenda.  The Zeta-Rigelians originally got their idea for the
Frequency Fence from the Annunaki NET  plan, in which the Annunaki had
long planned to “Lower the NET into D-3” to create a Frequency Fence
during the 2000-2017 SAC.  
    The Nibiruian Council mandate of Human Genocide  has been adopted,
and its orchestration is intended to occur through the '' Instigation of War
Among Human Nations '' agenda that has been key to most OWO creeds
since their inception. Advancement of the UIR Illuminati OWO Master
Plan depends upon their preventing Earth’s Templar from reaching a critical
mass 12-Code Pulse.  If the Guardian agenda of activating the Four Faces of
Man LPIN system  to create the Trion/Meajhé Field before 2003  is
successful, the 12-Code Pulse will reach critical mass in Earth’s Planetary
Shields, blocking the Dimensional Blend Experiment  and Frequency
Fence . The DNA Templates  of Indigo Children and Humans are now
beginning mass activation,  despite the Fallen Angelic astral T agging
interference; the biology of these races will automatically and progressively
run higher dimensional frequencies into Earth’s grids. A critical mass of
Indigo Children Types-1 and 2¹ have now cleared sufficient amounts of
NDC-Grid distortions from their DNA Templates  and set sufficient
amounts of the 12-Code Pulse in Earth’s Templar . These events will begin
triggering spontaneous DNA clearing and activation in mass Human /
Indigo populations . If these populations continue cleared DNA Template        
                              ___________________________________
                              1.     48- and 24-Strand DNA Templates, respectively.
                                
                            386
                


                                                                                 
                                                                      
                                                                                          
                                                                             Dimensional Blend Experiment, Wall in Time, ...
activation, they will  unknowingly transmit a critical mass 12-Code Pulse
into the Planetary Shields by 2003, preventing ful fillment of the
Illuminati Dimensional Blend Experiment.  
   The “ 2003 Dimensional Blend Experiment ” was intended to directly
link Earth’s Planetary Shields into the Planetary Shields of a counterpart of
Earth, called Phantom Earth , that was drawn into the Phantom Matrix
Black Hole Sub-Time Distortion Cycle  during the '' Electric Wars ,'' which
ended Human Seeding-l on Earth , 5,500,000 years ago.  Since the Electric
Wars there has been a '' Wall in Time ''—a  frequency Cap  between Earth’ s
Planetary Shields and the chaotic Planetary Shields of Phantom Earth in the
Black Hole Phantom Matrix. This Cap was kept in place by the Emerald
Covenant Founders, in hopes that eventually our Earth would evolve to a
sufficient frequency accretion level  through which the '' Wall in Time ''
could be “Uncapped,”  without our Earth and its life field potentially being
rapidly drawn into the Phantom Matrix. This Cap allows the races in
Phantom Earth an opportunity to have DNA Bio-Regenesis, and the
Phantom Earth to receive Planetary Shields repair, so people and planet
could be retrieved from the “perpetual chaotic time loop” of the Phantom
             Matrix to restore natural evolution.  
           Since the end of Human Seeding-1, Earth has been a literal
“battleground ” between the Emerald Covenant Founders races and the
Fallen Angelic/Intruder ET races of the Phantom Matrix. Each group has
fought to attain a critical mass of frequency  in the Planetary Shields of
Earth and its Phantom. If Phantom Earth accretes greater frequency holding
than our Earth, our Earth, its peoples and the Halls of Amenti in the Inner
Earth Time Cycle will be sucked into the Phantom Matrix black hole. If this
occurs, 11 dimensions of our 15-dimensional Time Matrix will become fully
trapped within the Phantom Matrix Sub-Time Distortion Cycle , cut off
from interaction with the Founders of D-12 and up, under Fallen Angelic
race dominion, completely incapable of natural Ascension out of density .
Such an event would provide sufficient energy fuel to feed and arti ficially
sustain the dying Phantom Matrix for many eons to come.  
    Since the 25,500 BC Lucifer Rebellion, the Anunnaki races of the
Phantom Matrix have been progressively draining frequency from our Earth
and transmitting it into the Phantom Earth Shields via the ' 'relay station ''
of the NET, NDC-Grid, the Reverse-orbit Planet Nibiru and the
artificial Nibiruian Battlestar ''Wormwood .''² In the SAC of 22,326  BC,
the Anunnaki almost succeeded in ful filling the Dimensional Blend
Experiment , through which the '' Cap on the Wall in Time '' would have
been shattered and our Earth and the Halls of Amenti Star Gates would
have become fully trapped in the Phantom Matrix. The Eieyani Founders
races stopped the 22,326 BC SAC just in time to prevent this travesty from
occurring. When the Zetas uncapped the Falcon Wormhole in the early
1900s and launched the 1943 Philadelphia Experiment,  the first full link
between the Planetary Shields of Zeta-controlled Phantom Earth and our
Earth was made in our contemporary times.     
                                        ____________________________
                                      
                                             2.     Yes, for the Biblical reference.
                                           387
                                                                                                                                                       

         
                        The Wall in Time and Atlantian Secrets of the Phoenix and the Falcon
    A  “hole was punched in the Wall in Time”  by uncapping the Falcon
wormhole and creating the Phi-Ex Wormhole Port Interface Network
(PIN) Atlantian Pylon Implant Network (APIN) System . Our
contemporary problems mounted when the Pleiadian-Nibiruians uncapped
the neighboring Phoenix wormhole, and they escalated again when the
“Hole in the Time Wall” was further expanded through the Falcon
wormhole during the 1983 Montauk Project.  If the contemporary UIR
succeeds in orchestrating the 2003 Dimensional Blend Experiment , Earth
will ful fill the Jehovian-contrived ''Biblical Revelations Prophecies,''
experience pole shift  and be drawn into “the Pit” of the Phantom Matrix
black hole3 The potentiality of Earth entering the Phantom Matrix is both
spiritually and scientifically devastating . Regardless of whether these
events are interpreted in terms of physics or spirituality, they are real “on
both counts.”  
    Originally , Emerald Covenant races, Humans and Indigo Children entered
repeated Earth incarnations on “ rescue missions,”  in attempts to save the
mentally and biologically mutated races  of the Phantom Matrix from their
return to undifferentiated units of “space dust” at the eventual, inevitable,
implosion of the Phantom Matrix. Now, due to the anti-Christiac applications  of
the NET/NDC-Grid/Montauk-Phi-EX/Phoenix Project  and Fallen Angelic
APIN technologies , the “Cap on the Wall in Time” must be permanently
closed.         
    If the Cap on the Time W all is not closed, Earth, Inner Earth, the Halls of
Amenti and the many universes within the lower 11 dimensions of our l5-
dimensional Time Matrix will implode  during and shortly after the 2000-2017
SAC.  The imploded systems would then chaotically reorganize their matter-
pattern within the Time Loop of the Phantom Matrix black hole.  The
Founders races must do everything in their power to prevent this event from
occurring, or other neighboring Time Matrix systems will be unfairly placed in
similarly grave jeopardy.  
    The present “Final Con ﬂict” drama on Earth will be the deciding factor of
destiny for many civilizations within our Time Matrix system, as well as for Earth
and the Human race. If the Emerald Covenant Masters Planetary Stewardship
Initiative and Bridge Zone Project  are successful, only a portion of Earth’s matter
base and consciousness fields will be drawn into the Phantom Matrix Time
Track  during the Three-Day Particle Conversion Period of our present SAC
(see page 223). The rest of Earth’s Planetary Shields and life-forms with sufficien t
DNA Template activation will experience a progression of linear time events
that will lead to a future in which Earth and her peoples discover the reality of
the Inner Earth Time Cycle . In this future, Earth becomes a free (ascended)
planet  within the Interdimensional Association of Free W orlds and great
Universal Emerald Covenant communities—the '' heavenly Earth '' so often
promised but never “deliverable” by the many oblivious religious dog mas.  
 . .                       If the GA  Bridge Zone Project is not successful, and the UIR’ s 2003
Dimensional Blend Experiment is not prevented by 12-Code Pulse re-coding of
                                                                       __________________________                                              3.     Not a “pretty sight” in terms of scienti fic physics and even more unsavory in terms of con-      
                                         scious spirit.
                            388  
            

                        
                                The WTC/ Pentagon Disaster and the “Secrets of the Phoenix and Falcon”
the 24 Nibiruian Crystal Temple Networks and setting of the Trion/Meajhé
Fields, the Guardians cannot prevent Earth from “joining its Phantom Shadow.”
This is not a decision of Guardian preference, but merely an unavoidable
condition of the natural Laws of Creation Physics  that govern the
manifestation processes of matter and consciousness.  
    Presently , great progress has been made in the Emerald Covenant freedom
agenda. The DNA Templates of Indigos and Humans are now slowly, but
definitely, clearing and activating. Progressive 12-Code Human DNA Template
activation will culminate in Earth’s 12-Code Pulse critical mass re-coding by
2003, if a critical number of Masters Planetary Templar Mechanics “Rainbow
Roundtables” (RRTs) are conducted by Earth populations.  The Emerald
Covenant RRTs are the advanced Biotronic technologies  of the Christos
Founders races. RRTs are the only technologies  by which the “Four Faces of
Man,” “Great White Lion” and “Golden Eagle” PIN Systems can be rapidly
activated to anchor the needed Trion/Meajhé Fields  in Earth’ s Planetary
shields.  
                           THE WTC/PENTAGON DISASTER
        AND THE “SECRETS OF THE PHOENIX AND FALCON”
     •Phantom Matrix. •The 5.5 million-year-old W all in Time. •The
Atlantian Conspiracy and Luciferian Covenant. •The Falcon and Phoenix
Wormholes. •The 1943-1983 Montauk/Phi-Ex Port Interface Network.
•Atlantian Pylon Implant Networks. •The 2003 Dimensional Blend
Experiment. •The NET (Nibiruian Electro-static Transduction field).
•The Nibiruian Crystal Temple Network. •UIR Illuminati OWO Master
Plans. •The September 12, 2000, UIR Edict of War. •RITs (Remote
Interactive Teams) and Astral Tagging •The “UFO and New Age
Movements.” •Fallen Angelic conquest for dominion of the Halls of
Amenti Star Gates. So what do all of these seemingly “far out sci- fi subjects” have to do
with the very real 9/11/2001 WTC/ Pentagon Disaster,  the contemporary
concern over the threat of International Terrorism and the “War On
Terrorism”?  
  Absolutely Everything!  I personally did not fully understand the
connections between the “Big Picture Drama” and our present global terrorist
issue until the GA/Eieyani “ filled in the missing pieces” as I began to prepare
this final update for Voyagers II 2e.  The well-hidden connections between
these ancient and contemporary realities is not remote or vague —it is direct
and scathing; this connection becomes much more obvious when we
understand the “ Secrets of the Phoenix and the Falcon ” and their
relationship to '' ancient '' Atlantis.  The whole story of the Phoenix and the
Falcon could fill several books; I will simply summarize here the most
immediately pertinent aspects of this historical saga.  
    Previous to the 9558 BC “cataclysm” of Atlantis, life was quite different
than it is now on planet Earth. In 28,000 BC, a major cataclysm ripped apart
the large Atlantic continent upon which Atlantis stood, reducing it to
several smaller Atlantian Island Nations. The three Primary Atlantian
         nations  were Ulta-Lohas-Ur , in what had been the Northeast of the
                          
                            389  
                                                                                                                                               
                                                                                                                                                                                                  

                          
                          The Wall in Time and Atlantian Secrets of the Phoenix and the Falcon
Atlantic continent (remains of it are now England, Ireland, Scotland,
Wales), Ulta-Bruah-UR  in the southwest (now Southern Florida, Cuba,
Bahamas, Haiti, Dominican Republic) and Ulta-Nohassa-Ur  in the central
region (now Bermuda lslands).4 
    The Human Atlantian nation became progressively overrun with a race
called the Anu-Melchizedek Leviathans.  The many competing Anunnaki,
Drakonian and Reptilian family lines of the Anu-Melchizedek Leviathan
races were a product of progressive Fallen Angelic raiding  of an Emerald
Covenant hybridization program that began in 155,000 BC.  The Founders’
Emerald Covenant hybridization program was intended to assist the
Anunnaki and Drakonian/Reptilian races that had joined the Emerald
Covenant to regenerate their DNA Templates  to reclaim the potentialities
of ascension. Genetic engineering  was used to combine portions of the
Angelic Human DNA Template with that of a composite Anunnaki-
Drakonian-Reptilian genetic strain, using the Anunnaki slave-primate
Lulcus5 DNA, upgrading the Neanderthal first to the Luhari ,6 then to the E-
Luhli- Levi,7 E-Luhli- Judah ,8 and E-Luhli- Nephi .9 After thousands of years
of evolution on Earth, and 5 genetic upgrades , the E-Luhli-Levi Cro-
Magnon received its final upgrade to the Homo-sapiens-1 Annu -
Melchizedek . The Annu-Melchizedek race, housing incarnations of non-
human  Fallen Angelic souls on Emerald Covenant “Redemption
Contracts,”  resembled the Angelic Human 12-Tribe races because five of 12
Human DNA Strand Templates were genetically engineered into bonding
with the hybrid DNA.  
    From the E-Luhli-Levi  stage, the hybrid races  could , but were not
intended to , naturally procreate with the  Human race,  due to the
compatibility of the lower DNA Strand Templates  between hybrids and
Humans. This made the hybrid races, especially, the most evolved Annu-
Melchizedeks, a prime target for Fallen Angelic races that desired to
                  incarnate their presence on Earth in quest of Halls of Amenti dominion. By
the later Atlantian period of 10,500 BC,  the number of Fallen Angelic
Annu-Melchizedek Leviathan  (of E-Luhli-Levi) hybrid family lines, born of
Fallen Angelic raiding of the hybridization program, exceeded those of the
Emerald Covenant Human and Maji-Indigo races. Throughout much of pre-
ancient history, Earth’s Star Gate system remained open, and interstellar
commerce was commonplace. In later Atlantis, this circumstance led to
invasion , formation of the competing Leviathan Atlantian Conspiracy
OWO dominion agendas  and in 9560 BC  formalization of the Anunnaki -
Leviathan Luciferian Covenant  OWO Anunnaki Master Plan for final
capture of Earth and the Halls of Amenti Star Gates. Human  populations of
Atlantis were progressively driven into exile  in other regions of the globe, as
                         
                          ___________________________________________
                          
                           4.     '' Ulta'' was a term used to indicate ''place of, UR'' referred to ''Light/Spirit'' and, origi-
                                         nally, to “God.”
                                 5.     Neanderthal
                                 6.     Cro-Magnon-1
                               7.     Cro-Magnon-2   
                               8.     Cro-Magnon-3                              
                                 9.     Cro-Magnon-4
                               390  
                

                         
                                 
                                 The WTC/Pentagon Disaster and the “Secrets of the Phoenix and Falcon”
the competing Leviathan races, on behalf of their Fallen Angelic/lntruder ET
kin, battled for conquest of the Atlantic Continent Star Gates.10 
    The Omicron-Drakonian, Odedicron and Zephelium (Zeta) Reptilian
races gained dominance in the Atlantian power struggle, and several
competing Anunnaki forces motivated their Leviathan races to orchestrate a
final victory over the Drakonian/Reptilian and Angelic Human races. This
motivation was formalized in the official agreement of the Luciferian
Covenant OWO Master Plan, what the Anunnakis referred to as the
''Phoenix Project ,'' the name of the Anunnaki-dominion project from the
10,500 BC Luciferian Conquest . In this original Phoenix Project,
Anunnaki Fallen Angelic races of the United Federation of Planets in the
Phantom Matrix  motivated their Leviathan legions on Earth to attempt to
gain dominion over Earth by opening the ''Wall in Time '' that existed
between Earth and Phantom Earth in the Phantom Matrix.  
    The ''W all in Time'' is an artificial frequency barrier that was placed
within the Planetary Shields scalar templates of Earth and Phantom Earth-
the portion of Earth’s Shields that had been drawn into the Black Hole Sub-
Time Distortion Cycle of Phantom Matrix during the Electric Wars 5.5
million years ago (see page 18). The frequency barrier “ Wall”  protected
Earth’s Shields or “Scalar Template,” allowing Earth to continue its natural
evolution within our organic Time Matrix, without threat of Earth, Halls of
Amenti Star Gate control and the rest of our Time Matrix being drawn into
the Phantom Matrix. The Emerald Covenant Founders had erected the Wall
5.5 million  years ago  to protect this Time Matrix from being ''swallowed'' by 
the Phantom Matrix Black Hole. In 10,500 BC  Atlantis, the Anunnaki
Leviathans created a wormhole  frequency bridge between Nohassa Atlantis 
of Earth and the Phantom Matrix planets of Nibiru11 and Tiamat.12 This 
Atlantian ''Hole in the Wall in Time'' was called the Phoenix Wormhole or
Phoenix Matrix  (English translation). Its entry point on Earth was near
Nohassa Atlantis Star Gate-3 , an Atlantian territory called '' Phoenicia ,''
where Earth’s Planetary Ley Line-4-10 (horizontal) crossed through
Planetary Axiatonal Line-7  (vertical).  
    The Phoenix Matrix was “anchored” into Earth’ s Shields, the Golden
Eagle APIN System, the NET and the NDC-Grid through Star Gate-4/ Ley
Line-4  at Giza, Egypt,  and through a secondary Nibiruian Crystal T emple
Network site called '' Cue Site-4 '' in Central Mexico.13 Through the A7/L4
Phoenix wormhole , the Anunnaki were able to electrically interface  Earth’ s
Planetary Shields with those of Nibiru and Tiamat, via their NDC-Grid and
NET  from 25,500 BC. The Anunnaki used the Phoenix Matrix in their long-
term Luciferian Rebellion Master Plan  of drawing Earth and the Halls of
Amenti Star Gates into the Phantom Matrix via merging Earth’s Planetary
                       
                        ______________________                                                10.   SG-11 Lohas, SG-3 Nohasa, and SG-2 Bruah.
                                11.   Density-1.
                                12.   Density-2 Phantom.
                                13.   “ Cue Sites ” are the location points of Inner Earth’s 12 Primary Star Gates, as they
                                        interface with Earth; they are the activation sites  for the corresponding 12 Primary Star
                                        Gates of Earth, which are located in different geographical positions than their counter-
                                        part Cue Sites.    
                              391                                                                                                                
                                                                                                                                  

                       
                             The Wall in Time and Atlantian Secrets of the Phoenix and the Falcon  
Shields with those of Phantom Nibiru and Tiamat, which linked to Phantom
Sirius A  and Trapezium  (Theta) Orion.  This contrived anomaly of
planetary physics would cause part of Earth’s body to burn up, while the
portions that survived black hole transition would emerge in Density-2 as an
“inhabitable moon” to Nibiru . The “ Phoenix14 would rise from the ashes
to be born with a new life ” under Anunnaki exploiting control, and the
Halls of Amenti Star Gates would fall under totalitarian United Federation
of Planets Phantom Matrix dominion. During the 10,500 BC Luciferian
Conquest, the Drakonian/Reptilian/Zeta Leviathan races discovered and
copied the Anunnaki wormhole technology  under motivation of the Zeta-
Dracos, Omicron-Drakonian and Odedicron-reptile avian  races that ruled
Phantom Earth . The “Drakonian Agenda” races created another Wormhole
near the first, on Axiatonal Line-7, Ley Line-3-9 , its “anchoring” position in
Earth’s Shields was located in the Drakonian-conquered Nibiruian Crystal
Temple Network at Star Gate-7,  now Lake Titicaca, Peru . In Atlantis, the
A7/L3  W ormhole was known as the Falcon Matrix —the Drakonian “Bird of
Prey” that would defeat and consume the “Phoenix” wormhole by forcing
Earth’s Planetary Shields into merger with those of Phantom Earth . The
Drakonian agenda races desired to link Earth, once merged with Phantom
Earth, to their intergalactic holdings of Alpha Draconis  in Draco, and
Alnitak, Alnilam, Bellatrix, Rigel and Zeta.  
    When the Falcon Matrix wormhole in the “W all in Time” was in place,
the Andromie-Necromiton  and Centaur  hybrid Fallen Angelic races of
Phantom Alpha Centauri and Omega Centauri and Andromeda raided
Phantom Earth. The Necromiton force temporarily defeated Drakonian rule,
and began using the Falcon Matrix wormhole to raid Atlantis of Earth,
creating a '' Master '' hybrid dominion  race, now called the '' Men in Black ,''
through raiding Annu-Melchizedek Leviathan genetic lines. Fallen Angelic/
Intruder ET races of all kinds emerged from the Phantom Matrix “Pit” to
initiate conquest of Earth.  The Necromiton-Andromie “Alpha-Omega
Anunnaki” races, already in control of the Golden Eagle APIN system  since
the 25,500 BC Lucifer Rebellion, attempted to merge the Phoenix and
Falcon Wormholes , the Golden Eagle APIN and NDC-Grid together, to
secure final territorial dominion of Earth. Emerald Covenant Founders and
Sirius B Maharaji Fleets  intervened directly in Atlantis, squelching the
Luciferian Conquest  and driving Fallen Angelic invasion forces back into
the Phantom Matrix, some escaping into exile on other planets in our Time
Matrix.   
    The Founders '' Capped '' the Phoenix and Falcon Matrix  frequency
bridges to Phantom Matrix, ''patching the holes in the Wall in Time.''
Without planetary access to D-12 frequency , the Founders could not create
a permanent Wormhole ''Cap,'' or activate the Four Faces of Man LPIN  to
restore the Golden Eagle and Great White Lion APIN Systems. In  9560 BC,
the Anunnaki Fallen Angelic races that had escaped to Density-2 Alcyone
and Tara in our Time Matrix motivated their Annu-Melchizedek Leviathan
force of Bruah Atlantis to again open the Phoenix Matrix Wormhole. In
 ________________________
      14.    Phoenicia-Nohassa-Atlantis.
     392
            

                                  
                                         The REAL Founding of America— “Spiking Out the Territory”
9558 BC  this was done as part of the Luciferian Covenant Master Plan to
fully draw  Earth, Inner Earth and the Halls of Amenti into the Phantom
Matrix  Black Hole Sub-Time Distortion Cycle during the next natural
Stellar Activations Cycle—the 2000-2017 SAC.  This plan was also
intended to “ get rid of the competition ” put forth by Angelic Human races
and other members of the Leviathan force who were affiliated with
competing Fallen Angelic collectives.  
   The Thoth-Enki-Zephelium Nibiruian and Samjase-Luciferian
Pleiadian Anunnaki races motivated their Leviathan hybrids to temporarily
''blow a hole in the Cap '' on the Phoenix Matrix wormhole , using the Arc
of the Covenant portal bridge at SG-4 Giza. The Phoenix Matrix was
temporarily opened just enough for the immediate central Atlantian
territories of Nohassa and select portions of Lohas and Bruah to
experience the regional holocaust  of being sucked into the Phantom Matrix .
Forcing the “fall of Atlantis” was only the first step in the Anunnaki OWO
dominion agenda, the climax of which was scheduled for the SAC  of 2000
-2017.  
    When the Phoenix Matrix was opened, Anunnaki forces from Phantom
Nibiru forced additional Photo-sonic scalar pulses  through the NDC-Grid
and Nibiruian Crystal Temple Network of Earth, creating additional
Planetary Shields Distortions and blockages within Earth’s Templar. The
Photo-sonic transmissions pumped through Earth’s Templar from Nibiru in
the Phantom Matrix instantaneously reduced to dust  any buildings,
structures or Atlantian remains on surface Earth that were not placed under
selective Anunnaki force- field protection . The Photo-sonic scalar pulses
and resultant planetary grid distortions caused further mutation in the DNA
Template of Earth’s biological forms, again reduced the life span of all
creatures and ''conveniently'' caused the '' memory files'' stored within the
Human and Leviathan DNA Template to be further '' unplugged. '' The
Anunnaki could not destroy Human and Indigo-Child races  if their Master
Plan was to succeed, as these races were needed to  run their DNA Template
Amenti Security Codes  into Earth’ s Planetary Shields during a SAC, or
Earth’s Star Gates and portals would not open. The Luciferian Covenant
agenda included a massive  ''Planetary Housecleaning , editing and re-
writing '' of any previous records or evidence  pertaining to Advanced
Atlantian Human civilization. The agenda intended progressive claiming of
Earth’s 12 Primary Star Gate  territories  and subjugation of Human and
Indigo races by the Anunnaki Leviathan force, in time for the 2000-20l7
SAC deadline.  
                        THE REAL  FOUNDING OF AMERICA—  
                                 “SPIKING OUT THE TERRITORY”  
           The “ North American ” continent , known then as Ulta-Amekasan-Ur
or Ame-Ka15-Ra,16 which had become inhabitable following the induced
“lce Age” of the 21,900 BC Lohas Celtec-Druidic Freeze-out territorial
                        ________________   
                                              15.   light/spirit body
                                16.   One
                                393 
                      
                                                                                                                                

   
                  
                       The Wall in Time and Atlantian Secrets of the Phoenix and the Falcon
                  conquest, was intended to become the '' New Jerusalem '' of the Jehovian/
Enochian Anunnaki Leviathan, and the new “ Ame- Re-Ka17 of the
Nibiruian Thothian Anunnaki Leviathan.18 The Pleiadian-Nibiruian
Anunnaki’s 9558 BC opening of the Phoenix Matrix was intended to create
climatic instabilities  and a quick-freeze  within select northern and southern
regions. The Pleiadian-Nibiruians planned to “clear the real estate” and
literally '' put it on ice '' to prevent Emerald Covenant races from reinstating
Human and Indigo Guardians there after the orchestrated ''flood.'' The
Anunnaki of the Luciferian Covenant planned to have their '' frozen assets ''
thawed out and populated by their Leviathan race Illuminati Sleepers Power
Elite ,19 in plenty of time for dominion during the 2000-2017 SAC.  
    Prior to the staging of the “fall of Atlantis,” members of the Thothian
Leviathan of Bruah were taken to every continent of Earth, including North
America, where they created a complex system  of what are called “ Atlantian
Spikes ” in Earth’s Planetary Shields. The Spikes, which had been used in
various global areas since implementation of the NDC-Grid at Stonehenge,
are “ Seed Implants ” made of various types of crystalline minerals and
metals,  which are inserted deep into Earth’s Mantle and Crust via photo-
sonic scalar pulse.  When activated , the Spikes become local and regional
transmission stations , originally receiving frequency “broadcasts” from the
NDC-Grid. “Grid Spiking” is one type of APIN system technology , which
is favored by the Pleiadian-Nibiruian Anunnaki. The Phoenix APIN system
“Spiking Campaign” of 9560-9558 BC  Bruah Atlantis connected speci fic
areas of Earth’s Planetary Shields directly to coordinate points  in the
geography of Tiamat  in the Phantom Matrix,  via the Phoenix wormhole.
When activated just before and during the 2000-2017 SAC, as intended by
the Anunnaki, the Spikes would open a series of '' mini-wormholes ,'' directly
to the Phoenix Matrix wormhole, Nibiru and Tiamat, creating powerful
standing-columnar-wave “Pillars” of inaudible sound . The Sonic Pillars
would anchor Earth to the Planetary Shields of Phantom Nibiru and Tiamat.
Through the Spike network of the Phoenix APIN, the NDC-Grid/Nibiruian
Crystal Temple Network Frequency Fence program, which had been
operating in certain regions of Atlantis, at partial capacity since 25,500 BC,
would be ampli fied and strengthened. After the intended ﬂood, the Phoenix
APIN Spike Matrix would allow the NET (Nibiruian Electro-static
Transduction field) to create a global ''perceptual buffer blanket '' that would
prevent species on Earth from perceiving the D-4 Astral Field and would
block Emerald Covenant nations from direct physical and communicative
interference.
           During the 2000-2017 SAC,  the Phoenix Spike Matrix  was intended
to progressively activate via photo-sonic scalar pulses sent through the
          Phoenix wormhole. The NET Frequency Fence  would descend into D-3
                          ________ ____________________
                             
                                17.  “light/spirit re ﬂection”
                                 18.   ln the Atlantian period, the North American continent was named after Human Tribe-3
                                        the Amekasan-Etur,  who had been exiled from their Emerald Covenant post at Nohassa
                                        SG-3 to the North American Continent, as Nohassa and Bruah Atlantis progressively fell
                                        to Leviathan rule after the 10,500 BC Luciferian Conquest.
                                 19.  Knights Templar-Hyksos-Freemasons.
                                394
               
          

                   
                                                      
                                                  The REAL Founding of America— “Spiking Out the Territory”
frequency bands, putting all races under covert Anunnaki Mind Control.
Under Anunnaki Mind Control, Human and Indigo races would mindlessly
follow Anunnaki instructions on running the DNA Template Security
Codes  to open Earth’ s Shields and the final physical Anunnaki invasion  of
Earth would take place without Human and Indigo resistance. Once
physically on planet, the Luciferian Anunnaki intended to complete the final
installation of the 24 Scalar Pulse generator-ampli fication plants  that they
would need to blast through the Cloaking Fields on the Inner Earth portals.
As the Phoenix APIN Spike Matrix moved into full activation while Earth’s
Star Gates progressed in their opening cycle, the Anunnaki would invade
Inner Earth  and connect the Halls of Amenti Star Gate control temples (12
Crystal Pylon Temples of Inner Earth) to the Phoenix APIN Spike Matrix.
Earth, Inner Earth and the Halls of Amenti Star Gates would be rapidly
drawn into the Phantom Matrix black hole , in a position between Tiamat
and Nibiru. In this event, all of Earth’s Life Field would experience  biological
death . But the planetary and personal consciousness  of Earth’ s life-forms
would reassemble along the chaotically grotesque template arrangement of
the Phantom Matrix.  
    In the Phantom Matrix, the consciousness would become trapped in a
distorted image of its original biological or matter form . The distorted body-
thought-form could neither naturally ascend, nor “die” in the usual
manner , but would rather  progressively become more distorted , the
consciousness digressing into perceptual chaos , until eventually the
thought-form-body would implode in upon itself, fragmenting the identity
into undifferentiated units of consciousness  (“space dust”). Survival of
sentience in the Phantom Matrix  is dependent upon devising ways to
literally feed off life-force energies  from other forms in the Phantom Matrix,
or from living beings and living Time Matrix systems. This is how the Fallen
Angelic races sustain themselves, and is precisely why they have tried for 250
billion years (Earth time) to conquer our living Time Matrix and pull it into
their system. Such a feat would provide them with a massive ''food supply ,''
through which to expand and sustain  their continually contracting thought-
form hologram reality field. 
    If the Anunnaki’ s Phoenix Matrix Master Plan  succeeded, the Halls of
Amenti Star Gates would create an open Wormhole interface  into other
living Time Matrices, and the life-forms of Earth  would become entrapped
in deteriorating thought-form bodies  that would become the “ slave demon
force ” of the Fallen Angelic collectives. This was the intention of the
Luciferian Anunnaki when they devised the “Atlantian Flood Drama”; this is
the Destiny of Sorrow  to which they have long desired to condemn our
race . Joining the Fallen Angelics in their finite Phantom Matrix
“holographic prison” is the false ''eternal life '' they have been deviously
promising Human and Illuminati-Leviathan races since the fall of Atlantis.
Real eternal life  is achieved through genuine Ascension and Mastery of
Consciousness within the living Time Matrix . Phantom Matrix ''life-forms''
are not truly “alive” in biological or spiritual terms; they are, in truth, '' living
dead '' races,  finite consciousness thought-form identities  trapped within a
progressively fragmenting and deteriorating Sub-time Universe, who can take
395 
                                                                                                                                                                                                                                                                  
                                                                                                                           

                        
                     
                      
                        The Wall in Time and Atlantian Secrets of the Phoenix and the Falcon
on “biological life” only through using living forms of consciousness as a
Host.  
       Human and Indigo races were sent into this Time Matrix as a guardian,
protector and healer force , intended to protect the living Time Matrix from
the Phantom Matrix system and to assist, if and when possible, in the
reclamation and redemption of the Fallen races and Universal systems.
Presently, we are in the '' Beginning of the End Times '' that the Fallen
Angelics have so often prophesied to us; the Founders Emerald Covenant
Masters Planetary Templar Mechanics  is the only means by which we can
get ourselves out of this Atlantian-created mess. Fortunately for us all, the
Luciferian Covenant plan was not as successful as the Anunnaki
anticipated; if it had been we would not presently have access to any of the
Founders education. The Phoenix Matrix Cap  was opened in Nohassa
Atlantis via a Photo-sonic scalar pulse  that was '' bounced '' from Bruah
Atlantis (the “Gru-AL” central control for Earth’s Planetary Shields),
through Ley Line-4-10,  to Star Gate-4  in Giza, Egypt,  where the Arc of the
Covenant portal bridge to Andromeda was stationed. (See “The Arc of the
Covenant” on page 51). The Luciferian Anunnaki backed Leviathan races
(“Thoth-line” aquatic-ape/Zeta Nibiruian hybrids) of Bruah, had tricked  the
Jehovian Anunnaki backed Leviathan races (Enoch-line Bipedal Dolphin
people hybrids of Sirius A and Arcturus) of Nohassa, into participating in the
9558 BC Atlantian '' Dimensional Blend '' experiment . Both the Thothian
and Enochian Anunnaki factions were “official” members of the Luciferian
Covenant OWO Master Plan, since their respective 22,326 BC and 10,500
BC defections from the Emerald Covenant Co-evolution peace treaty. The
''cover story '' used by the Thothian Leviathan was that, in combining the
powers of Nohassa’s SG-3 and Bruah’s SG-2 together, the usually competing
Anunnaki races could combine their technological powers  to break through
the protective Emerald Covenant Cloaking Shield on the “Andromeda Arc”
portal bridge at Giza. Once the Arc Seal was released, they could “stage a
joint conquest of Inner Earth” and claim the Halls of Amenti Star Gate
control temples. The Thothian races really intended to claim SG-3 control
for themselves and destroy the Enochian “competition.”  
      When the Leviathan races of Bruah and Nohassa launched the Photo-
sonic scalar pulse, the Bruah pulse was purposely sent with an under-
amplified electrical charge . The combined sonic pulse “bounced off” the Arc
Seal at Giza, rather than penetrating it, returned to Bruah via Ley Line-4,
blowing a hole in the Phoenix Matrix Cap as intended . Then the SG-2
Main Power Generator Crystal Temple was used by the Thothian Leviathan
to redirect the pulse through Axiatonal Line-3  that ran vertically through
Nohassa; the pulse refracted an unsuspected back-pulse  to SG-2 Bruah,
reducing the Temples to dust. The central Atlantian Islands of Nohassa were
reduced to what remains as the Bermuda Islands . The land bridge  that
linked Bruah and the North American Continent to the Atlantian land mass
that held the Phoenix Matrix was also destroyed. Lohas in the north, home of
 SG-11,20 suffered the least, while regions in the extreme north and south,
 _________________________
  20.   England-Ireland-Scotland-Wales
 396
               

                                             
                                             The REAL Founding of America— “Spiking Out the Territory”
once habitable lands, experienced ﬂooding and quick-freeze. What the
Thothian Leviathans had not planned on was that members of competing
Leviathan races would survive,  which they did through temporary
evacuation by their respective Fallen Angelic kin. When the sonic pulse was
sent into Axiatonal Line-3 at Nohassa, it “poked another hole in the Cap on
the Wall in Time.” Inadvertently, the Anunnaki had created a  ''tear'' in the
frequency Cap on the Drakonian Fallen Angelic controlled Falcon Matrix
A7/L3-9 wormhole  that led to Phantom Earth.  When the silent Photo-
sonic Pulses hit, portions of the ''Islands of Atlantis '' began to ''sink
beneath the sea .'' The matter of which these geographical regions were
composed, and the life-forms living upon them, literally first “lique fied” into
a semi-plasmic hydro-standing-wave state,  then internally combusted  in a
massive ''flash '' of Photo-radionic light  and '' sank '' into the Black Hole
''Pit'' of the Phantom Matrix.  
    The Planetary Shields distortions resulting from the “fall of Atlantis”
created several frequency '' rips'' in the Anunnaki-controlled NET , which
permitted Emerald Covenant Eieyani races of Inner Earth and Sirius B a
limited amount of time to directly intervene before cataclysmic Earth
changes ensued. The Eieyani temporarily opened some of the surface Earth
portals to Inner Earth and used the Crystal Pylon Temples of the Halls of
Amenti to stabilize Earth’s grids—the Anunnaki-intended cataclysm did not
proceed as fully as the Luciferians had planned . Stabilizing Earth’s
Planetary Shields allowed the Guardians a limited period of time in which
Human l2-Tribe, Indigo and Emerald Covenant Annu-Melchizedek hybrids
were temporarily evacuated to Inner Earth. Drakonian and Anunnaki agenda
Fallen Angelics from Phantom Earth temporarily evacuated their respective
hybrid races via spacecraft. Once the “dust had settled and the waters had
calmed” all races were returned to Earth by their respective resettlement
teams,  and the battle for “critical mass dominion” of Earth’s Templar
began between the Human and Indigo planetary guardians and the
competing families of the Leviathan Force Illuminati-hybrid ''human ''
races . Emerald Covenant races were unable to fully repair the ''holes in the
Wall in Time,'' but the Anunnaki NET  and Phoenix Wormhole APIN
Spiking Matrix  and the Drakonian Falcon wormhole  were  destabilized
during the fiasco, allowing only limited interface  between Earth and the
Phantom Matrix. Emerald Covenant races could not attempt to dismantle
the Anunnaki NET at this time,  as it served as a buffer  for Earth, protecting
it from erratic frequencies that would emerge from the Arc of the Covenant
Andromeda portal without the NET protection. Throughout our known
recorded history , the Leviathan races grew in number, strength and
territorial power under remote Fallen Angelic guardianship . Meanwhile,
amnesiac Human and Indigo races did their best to survive on Earth, and
Emerald Covenant races did their best to assist them via their limited
communicative access through the NET.                          ___________________________________________________________               
                                                                                          The 2000-2017 SAC is the time when the whole mess
                                                           will inevitably “come to a head.”                        ___________________________________________________________                                                                                                     
                                                                                                                                       
                        397  
                                                                                                                              
       

                                                                                          
                          
                           The Wall in Time and Atlantian Secrets of the Phoenix and the Falcon
                                  OUR HIDDEN HISTORY OF SORROW, 9558 BC-PRESENT
   Competing forces from the Phantom Matrix used their limited access to
the Phoenix and Falcon wormholes to misguide their amnesiac Leviathan
Illuminati-hybrid races with falsified historical and religious dogmas , and
''Secret Mystical Metaphysical Societies '' promoting '' Vengeful Creator
God '' propaganda . These falsi fied Control Dogmas , upon which recently-
ancient and contemporary civilizations were built and are still covertly
controlled, were drawn from the once-valid Law of One  freedom-love
spiritual-science texts of the Angelic Human CDT-Plate teachings.  The
Emerald Covenant CDT-Plate  teachings had been the common property of
early Atlantis and Lemuria (Mu’a) and all Human Seedings that came before;
they were the original Founders records, and the basis for the 12 Primary
Spiritual Union Ascension Teachings  of the Human 12-Tribe races. The
original Spiritual Union teachings all agreed with each other,  each
representing the historical, spiritual and sacred science Emerald Covenant
sacred freedom teachings as held in one of the 12 CDT-Plates.  Each of the
12 Human Tribes  had been entrusted as Guardians of the knowledge
contained in the CDT-Plate that corresponded to the Tribe’s Planetary Star
Gate assignment.  The amnesiac Leviathan races , driven and covertly
manipulated into Star Gate territory conquest , progressively waged war and
claimed dominion over amnesiac Human nations , forcibly indoctrinating
Human l2-Tribes into docile compliance  to competing, twisted, Fallen
Angelic false historical, religious and, later, scienti fic creeds. The Indigo
Child Maji Grail Lines  have been the “ Keepers of the Sacred Founders
Emerald Covenant CDT-Plate Knowledge ” throughout our troubled and
progressively violent history.  
    All through this history of sorrow , competing legions of Leviathan
Illuminati families were motivated by their Fallen Angelic taskmasters to
attain possession of speci fic geographical regions and sites  corresponding to
the APIN systems. Only one or two “ Key Controllers”  in each of the many
Illuminati groups  learned that these areas held the Anunnaki Phoenix
Spiking Matrix . Even the Illuminati Key Controllers  were deceived, for
they were not told these sites were '' Anunnaki intended take-over points .''
They were told the lie that these sites were ''sacred and belonged to their
Creator Gods and Angels.'' Since the 9558 BC “fall of Atlantis,” churches,
synagogues, places of ''worship ,'' economic, governmental , and  public
social areas  were repeatedly built over, and around , areas through which the
Phoenix Spiking Matrix  would be run come the 2000-2017 SAC . 
    Many of the Phoenix Matrix territories were overtaken by competing
Drakonian agenda Leviathan Illuminati forces, who would usually destroy
the buildings of their competitors and erect their own edifices to their Fallen
Angelic effigies. At various times, the Anunnaki Fallen Angelics  of Nibiru,
Tiamat and Alcyone would use their Phoenix Matrix, NDC-Grid and NET,
to Cap the Falcon Matrix  wormhole of their Drakonian competitors. The
Drakonian Illuminati would then quest for the territories of the Nibiruian
Crystal Temple Network, successfully gain governing control over some of
the 24 Primary sites and use them to siphon energy from the NDC-Grid  in
order to '' blow the Cap back off '' of the Falcon  wormhole. Anunnaki and
398 
                                                                                    

                                                                                                 
                                                                                                                            
                                                                                                                  Spiritual Manipulation
Drakonian Illuminati factions continually warred over possession of these
“Sleeping Phoenix Spike Sites ” and Nibiruian Crystal Temple Networks ,
all attempting to position themselves appropriately, in preparation for the
''Big Party '' that the Fallen Angelics knew was scheduled to come during
the 2000-2017 SAC.  Our beloved America , as well as  Europe , and literally
all countries on the planet, have been carefully cultivated  through the
Illuminati Leviathan force family lines to reach their present state of
“civilization.”21 America was not “discovered”—it was ''seized'' by competing
factions of (Freemason) Pleiadian-Nibiruian Knights Templar-Anunnaki
and Drakonian-Nephedem  Leviathan Illuminati races, like many other
nations have been. When America was  ''discovered ,'' it was “time” to
prepare for the Big Party and “Sleepers Awakening .” 
      Here we are  today, still  amnesiac, still asleep...as our “Atlantian
Phantoms” emerge with us from the forced slumber of our ancient
Atlantian Nightmare . In the 1920s-1930s  the Zeta races of Phantom Earth
and neighboring Phantom galactic systems broke through the latest
Anunnaki ''Cap '' on the Falcon Matrix  wormhole. The Zeta conned
amnesiac Anunnaki and Drakonian Illuminati races into Zeta Treaty Deals.
In 1943 the Zeta tricked the Illuminati into using their covert control over
unsuspecting Human governments , to orchestrate the 1943 Philadelphia
Experiment , which the Zeta knew would activate the Phi-Ex Falcon
Wormhole APIN system . In 1972  the Pleiadian-Nibiruian Anunnaki
opened the Phoenix wormhole and began activating its APIN system. In
1983  the Zeta further motivated a now frightened and subservient Illuminati
force into the Montauk Project , through which the Phi-Ex/Falcon Matrix
wormhole was further  ''plugged into '' the Necromiton-Andromie
controlled Planetary Shields of Alpha and Omega Centauri. Through the
recent history earlier described in this writing, we have now emerged into the
Mass Drama of the forming of the UIR and their September 12, 2000, Edict
of War. What does this mean  to our world?  It means that the primary ,
once-opposing forces of the Anunnaki and Drakonian agenda legions have
joined with the Andromie-Necromiton force. They intend to combine their
collective, hidden, technological power  of the Montauk-Phi-Ex-Falcon and
Phoenix wormholes and the APIN systems, to ensure that Earth and its
peoples ''have a nice trip'' into the Phantom Matrix Black Hole Sub-Time
Distortion Cycle during the 2000-2017 SAC. The unspoken “motto” of the
UIR might be something like '' Have a Nice Trip... Join Us In the ‘Fall’ ...,''
and I’m not talking about “autumn .'' 
                                      
                                                          SPIRITUAL MANIPULATION              
      The reality of our present drama means that there are hordes of
amnesiac Illuminati Sleepers , ''Human Greeting Teams '' and '' just every-
day people ,'' that are presently the unsuspecting victims of Astral Tagging,
targeted Psychotronic mind control  or DNA bond possession . These are
mostly good-hearted, intelligent people, who think they are ''honoring their
 God, Angel, ET, government or science.'' They are being blindly guided
                           _________________________
                              21.   or might I say “Zombification?”    
                                399                                                                   
                                                                                                                                                      
                    

                                                                
                       
                        The Wall in Time and Atlantian Secrets of the Phoenix and the Falcon
through their chosen ''Pet Control Dogma '' (''Traditional'' or
''Contemporary,'' religious or scienti fic) into unknowingly playing  a
previously assigned role  in the advancement of the UIR Fallen Angelics’
Illuminati OWO Master Plan.  
   The really sad part  is that our race has been, step-by-step, forced,
seduced, deceived, tricked and cajoled into playing these  ''unholy '' roles;
even the Illuminati races,  whom '' anybody in the know likes to blame ,'' are
being victimized and denied the right of true data assessment and free-will
choice.  The Illuminati races within the infrastructure of the covertly
metaphysically motivated Illuminati World Management Team, who serve as
Fallen Angelic puppets, are being “played on” and manipulated by fear for
personal survival and a desire for acquisition of power to prevent pain and
create personal pleasure. These are the same motivations behind the actions
of the ''spiritual'' peoples of traditional and New Age affiliation, who think
worshiping an ancient book, or surrendering personal power to an external
''God,'' ''ET,'' ''Angel'' or ''channel'' is the ultimate expression of spiritual
development and will ''make everything all right.'' Fear, the ''Pleasure-Pain
Principle '' and Disinformation  are the common control elements  by which
Illuminati and Humans become easily misled into surrendering their power to
something outside of themselves. Once this ''outside source '' has your
power, compliance with the approval of that source becomes, implicitly,
the only way to feel empowered.  
    The Anunnaki-dominated New Age ''pseudo-Ascension '' spiritual
movement (most of it inspired by the ''Templar Melchizedek'' false ascension
teachings of Anunnaki’s Thoth, pre-Emerald Covenant Enoch, ''Archangel
Michael & Friends,'' ''Jehovah,'' ''Maitreya,'' ''Lord Melchizedek and spiritual
hierarchy,'' the Urantia etc....) inherently promotes a fear-based paradigm  of
''Light, Love and Pretend Away the Darkness '' dogma . These groups prey
on the spiritual longings  of Christians and Hebrew peoples, borrowing the
false ''Crucifixion of Christ '' story from Anunnaki & Drakonian “edited and
embellished” (see Council of Nicaea, page 315) traditional texts22 The fact
that the false “Crucifixion Story” has been so predominant in the founding of
so many cultures for the last 2000 years gives one some idea of just how
successful the Anunnaki have been in using the NET, NDC-Grid and
their manipulated Illuminati-hybrid Leviathan races to ensnare our minds .
Since the 9558 BC Atlantian “flood” was staged, such “ spiritual rape by
religious control dogma deception”  has been propagated in every culture  by
various competing Fallen Angelic/Intruder ET forces via “channeling” to,
and manipulation of, their amnesiac Illuminati races. Perversion  of the
once-Sacred Emerald Covenant Spiritual-Science Maharata-Templar
teachings that formed the 12 Global Freedom Religions that were
humanity’s heritage  from the Ancient of Days until Atlantis, has been done
as a s trategically planned and progressively implemented  element  of the
Atlantian Conspiracy agenda . Most people who succumb to these mind
                        _______________________                       
                    22.    It truly amazes me how many people are so attached to the Anunnaki-implanted false-
                                  hood that ''Christ was Cruci fied.'' You would think people who cherish all Jesheua was
                                            and stood for would be delighted and joyful to discover that he ascended via the Arc of
                                            the Covenant portal passage without a nail hole in sight!
                        400
                   

                                                       
                                                  
                                       Breeding a Final Conﬂict Army and Planetary Shields Reversal
control games are literally terri fied to face the facts of our present reality that
they have been led to believe exist, and so afraid to face reality that they
must defend at all costs the illusion of 3-D safety . Denial is one of the greatest
forms of fear, and it usually requires that the fear itself be denied . 
                             
                                                BREEDING A FINAL CONFLICT ARMY
                                            AND PLANETARY SHIELDS REVERSAL
      The “twist the true teachings” game was implemented by competing
Fallen Angelic legions for very speci fic reasons —long-term population
control  was one objective. “ Getting rid of the competition in the name of
defending your God ” is a tactic that has been, and still is being,  used  by
competing Fallen Angelic legions to turn factions of Illuminati and Human
populations against each other.  This has been done throughout recorded
history by competing Fallen Angelic factions, to secure Star Gate and APIN
Site territories  and to ensure that '' critical mass dominance '' of their chosen
Leviathan race  would be secured and ready  for the scheduled  2000-2017
''Invasion Party ,'' This is the same reason we have been told by both
Anunnaki and Drakonian pseudo-Gods to '' go forth and multiply ,'' in
conjunction with the falsehood  that “ birth control is a sin .” Along with this
ploy went the editing of the Sacred Teachings  that explained how birth
control is naturally achieved . And the Anunnaki “fail to mention” in their
false “We are your Creator Gods” propaganda that they intentionally caused
DNA mutations that increased female ovulation  in Human females from
the previous, natural, “ once every three years ” cycle to its present monthly
cycle . Why ? So we’d all be '' good little breeders '' to make sure they had the
needed ''head count '' on planet when the 2000-2017 SAC  came. Once
upon a time, when Earth was not being remotely run by mentally ill Fallen
  Angelic invaders , Humanity knew how important it was to keep a natural
  balance between and among species numbers; these balances were always
  respected. All species knew instinctively when “enough was enough,” and
      their bodies naturally complied by not permitting conception to occur .
    Human races had the ability to consciously choose whether or not to
  conceive once every three years,23 and parents knew who the incarnating
  soul would be and held memories of other lifetime relationships with the
  soul.  
       Our races have been deceived into utterly destroying the once-natural
balances of life on our planet  in order to raise an amnesiac , easy to covertly
  direct ''Fallen Angelic Inside Invader Force .'' If there are enough Human
   bodies on Earth carrying the natural Planetary T emplar DNA  Security Codes
 and the DNA  T emplate can be altered to run the Security Code frequencies            
into the Planetary Shields in reverse sequence during the SAC, Earth’s
  Planetary Shields  will fully reverse  their natural spin and polarity . Full
     reversal of Earth’s Planetary Shields will permit Earth’s Shields to merge with
     those of a Planet in the Phantom Matrix. Over-breeding  has produced a
                  massive population. The “ Checkerboard DNA Mutation ” has reversed the
               Human DNA Template Security Codes and personal Merkaba Fields (which
                       _____________________
                        23.    In even earlier days, it was seven years.
                              401
                                                                                                                                                                                                                                         
  

                                    
      
              The Wall in Time and Atlantian Secrets of the Phoenix and the Falcon  
         
               give Planetary Shields access), and we have been denied all memory and
           knowledge —most of us don’t even know that Earth’s Templar, Star Gates
             and Planetary Shields exist. Sounds like the ''perfect set up ,'' doesn’t it ? But
            the positioning of our race to ful fill the Fallen Angelic/Intruder ET Halls of
           Amenti Hijack Master Plan doesn’t stop here. Fortunately , the solutions to
             our rather massive  contemporary problems are not nearly as complex as the
                                  problems   themselves. RRT   Biotronic Technologies and   Masters   Planetary
               T emplar Mechanics  are the tools through which we can set ourselves, and
                  Planet Earth, free.  
                                       
                             
                                        402
                                      
                                             

                                           
                                                
                                                20
                                    
                              
    
    
  HAARPs,Trumpets, Horsemen,
                  and Heaven                             
                                                 WHAT REALLY HAPPENED ON 9/11/2001 
                                                
                                                      HAARPs, DNA and the Mass Awakening                    
      Like the sadly manipulated spiritual movements of humanity’s last
10,000 years the '' science-technology movement ,'' unfortunately, is the only
one which “appears” to offer something more empowering. Such “beauty is
only skin deep” when it comes to both the spiritual and scientific
perspectives through which we attempt to comprehend the meaning and
purpose of our lives. This was not always the case. In fact, our present
condition of innocence about “what makes the universe go ‘round” is a rather
recent evolutionary detour taken in 9558 BC, when we “lost our way,” and
our memory, as we emerged from the ruins of Atlantis. Presently, people who
are learned in the scientific traditions most often succumb to the Drakonian -
inspired ego-trip propaganda  of '' scientific expertise ,'' whereby most of
humanity’s best “rational minds” believe that they know that ETs, angels,
souls and God do not really exist. Psychology  has done its part well in
feeding the covert Fallen Angelic One World Order (OWO) dominion
agenda, by unknowingly promoting utterly false interpretations of the
workings of the Human mind . People who begin to “get a glimpse above the
Anunnaki NET” into the higher dimensional frequencies, or report “alien
abductions,” or begin to remember “other lives,” or think that “mass
conspiracies might exist” are conveniently labeled as “mentally disturbed.”
Classic psychiatric responses to the above noted perceptions include
“Psychics are charlatans—there’s no such thing as ESP”; “Sleep disorders
cause abduction hallucinations and the illusion of out-of-body travel”;
“multiple personality syndrome creates false memories of reincarnation”; and
 finally “Conspiracy theorists are paranoids or have savior complexes.” Oh,
  please....  
      One of the most valuable contributions our Fallen Angelic inspired 
Scientific Establishment has contributed to the “Silent Invasion” agenda,
with the assistance of the Illuminati-manipulated U.S. government, is
creation of the infamous '' High-frequency Active Aural Research 
Program ,'' or HAARP . You know the one...that '' Angels Don’t Play .'' Both
  scientists and outer External Government authorities have created the
   403  
                                                                                                                                                                                                                                                            
                         
                                                                                                                          


                        
                        
                         HAARPs, Trumpets, Horsemen, and Heaven
HAARP installation with no knowledge whatsoever  that it is anything but a
“potentially useful, though possibly risky” technology. Even the few elite, “in-
The-know,” members of the Illuminati World Management Team don’t know
the real ET -intended application of the HAARP  installation  and its other
hidden “sisters.” The elite “Key Controllers” within Illuminati
establishments do know it is intended to assist the “Visitors” in creating the
Mass Frequency Fence —they have been told the Frequency Fence is needed
to “prevent mass panic” when the ETs make their “public debut.” The
HAARP installation is a high-frequency radio transmitter complex
positioned in Gakona, South Central Alaska  160 miles north east of
Anchorage. It is operated (unknowingly on behalf of “guess who”?) by the
U.S. Navy and Air Force, and Phillips Laboratories. The U.S. military
intends to use HAARP to focus a billion-watt pulsed radio beam into
Earth’s outer atmosphere . Transmission of this beam will supposedly form
Ultra-ULF waves and’ bounce them back to Earth. The Ultra-ULF waves are
intended to '' improve submarine communications '' (not to mention ET
underwater base communications ) and will allow detection of subterranean
phenomena such as “oil reserves and underground missile silos.”1 
       Much public controversy has emerged around the potential dangers  in
using the HAARP network, due to the claims of some researchers that it will
''blow 30-mile holes in Earth’s upper atmosphere '' and might possibly
''disrupt the subtle magnetic energies of Earth and biological life-forms .''
Oh brother. . .here we go!  
      Under natural environmental conditions, dormant portions of the DNA
templates of biological life-forms spontaneously and progressively activate in
reaction to the frequencies of Stellar Wave Infusions that occur during
SACs. This natural DNA function allows the physical, emotional and
mental body structures to create temporary adaptability  to the increased
UHF of SACs, preventing illness and premature death . The DNA
template responds to the planetary electrical and magnetic fields , and
certain kinds of “disruptions” in the magnetic balances of Earth’s outer
atmosphere block the natural DNA-activation process. Temporary Scalar-
pulse disruption of Earth’s outer atmosphere is precisely the method used by
Galactic Federation in 3470 BC , on behalf of the Nibiruian Council, to
further “erase” our then-re-surfacing Atlantian race memory and to further
scramble our DNA templates and language patterns. Presently, due to efforts
of the Emerald Covenant races and lndigo Children of Earth, who have been
consciously working with Bio-Spiritual tools to heal and activate their DNA
templates; spontaneous, natural, critical-mass DNA activation has now been
triggered within the Human and lndigo masses. It is for this precise  reason
that the United Intruder Resistance (UIR) has accelerated the schedule of
its Illuminati OWO Master Plan from the intended 2002-2003 to August
12, 2001, which is when the “Big Game” really began.  
  Human DNA  is designed to enter this natural Spontaneous Mass
Activation cycle  during SACs, in response to increasing frequencies within
_____________________  
1.   Conveniently, the HAARP will be very handy in locating underground bases, “parked
        space ships,” Nibiruian Crystal Template Network sites  and APIN Systems  as well!   
404 
 
1 

                                                                        
                                                                                    What Really Happened on 9/11/2001
Earth’s Planetary Shields; Human DNA progressively activates the 12th-sub-
frequency band in each of 12 Human DNA Strand Templates, creating a
progressive natural Maharic Seal  and resulting biological immunity to SAC.  
    T o the great dismay of the UIR, the “ Mass Awakening ” has now begun,
which means that even unaware Humans, all over the planet, will now
progressively and unknowingly begin running D-12 frequency into Earth’s
Planetary Shields. After thousands of years of forced DNA template
repression, the Bio-electric Conductor of Human biology  is finally
awakening to do what it was designed to do—transmit 12-Code Pulses  into
Earth’s Planetary Shields, via the DNA Template/Merkaba/Kundalini-
Maharata Current connection. This is Divine Biotronic Technology at its
best! Through the Bio-electric Conductor of the Human body, Earth’s
natural D-12 Planetary Maharic Seal Templar protection field will be
progressively triggered into activation. As the Human DNA Template
awakens, the ancient Emerald Covenant ''Four Faces of Man,'' ''Great White
Lion'' and ''Golden Eagle'' APIN Systems  (see page 527) will
synchronistically come to life, ushering Earth into the “protective blanket” of
the Trion/Meajhé Field (see page 517).  
       Fallen Angelic races of the Phantom Matrix cannot utilize full-spectrum
D-12 frequency or higher—their biology and technologies  are limited to D-
10 to D-11.5 transmission/reception capacity. The D-12 Hydroplasmic
''Christos'' Maharata frequency and Trion Field Primal Creation Currents
will naturally override any Phantom Matrix distortions within Earth’s
Planetary Shields and biological DNA, if D-12 frequency reaches a critical
mass charge  in Earth’s Templar.  Currently , the UIR  has realized that it is
now '' in a race for time ,'' Their originally intended 2003-2004
''Dimensional Blend Experiment '' (see page 386) and '' Frequency Fence ''2
will not occur if D-12 frequency reaches Critical Mass  in Earth’ s Planetary
Shields before 2003 . 
      Critical Mass 12-Code Pulse will be achieved in 2002 if people
continue to assist Emerald Covenant races in Rainbow Roundtables
(RRTs) to activate the Four Faces of Man LPIN and build the Trion/
Meajhé Field and if the  Mass Human DNA  A wakening continues. The
Checkerboard Matrix DNA  Mutation that reversed the Security Code
sequences in Human DNA and Merkaba Field was carefully orchestrated by
the Annunaki Invasion force since 25,500 BC, and painstakingly nurtured
since the 9558 BC fall of Atlantis.'' Due to efforts of the Indigo Children in
working directly with Emerald Covenant nations and DNA Bio-Regenesis,
Maharata Merkaba and RRT technologies to clear ''Checkerboard DNA
Reversal'' distortions, the organic sequencing  of frequencies is now activating
in the Mass DNA Template, clearing ancient distortions as it goes.3 The
entire, long-suffered Fallen Angelic OWO Amenti dominion Master Plan
                        _____________________
2.     Pre-invasion Mass Mind Control/DNA and Pineal Gland suppression campaign.
3.     We have just begun offering “Advanced Personal Coping Skills” programs regarding
        Spontaneous Mass DNA Template purging  and activation. We need to learn to handle
        these organic “purging” energies in our bodies, minds and emotions or these energies will     
        “throw us all for a collective loop.” This DNA purging will affect all Humans and Illumi-
        nati-hybrid races via the Planetary Shields scalar template.         
405                                         
                                                                                                                      
                                                                                                                                                                                                                                                                                
            

                                                                        
                        
                        HAARPs, Trumpets, Horsemen, and Heaven
will be shut down completely if Earth reaches 12-Code Pulse Critical Mass
before 2003. Suddenly their plan has begun to “turn in on them.” All of those
multitudes of excess Human bodies that Fallen Angelics have so carefully
“cultivated” to become their “Reverse Security Code Amnesiac Inside
Invasion Force” in the Final Conﬂict drama are now Spontaneously Healing.___________________________________________________________   
  If the Fallen Angelics don’t do something to prevent further Human DNA
  activation, their “ Human Amnesiacs Force ” will become the “ Awakened
    Human Victory Force ,” the very force by which the Fallen Angelics
                                      diabolical agenda is defeated.   ___________________________________________________________
     The UIR Fallen Angelics are now scrambling to motivate their
Illuminati Sleeper puppets of the World Management Team to force
through immediately their OWO Master Plan.  As they have always known,
it must be done carefully, and in stages, or else public suspicion and mass
chaotic rebellion might occur. The UIR Illuminati have started their OWO
Master Plan off with a bang—actually, more like a “boom,” three big ones
and one small one, to be precise.  
      On Monday September 3, 2001,  the last day of our Labor Day
Workshop, the CIA/Eieyani informed us that the UIR had begun a certain
type of “Phantom Pulse” transmission  through the Montauk-Phi-Ex Falcon
APIN System, which interrelates with UIR Beamships via the earthly
HAARP network . The Eieyani explained that the UIR had begun linking
their D-4 Cloaked Beamship crafts into the hidden HAARP installations
(see page 257) to begin Frequency Fence transmission now, rather than
waiting until their originally scheduled target date of 2004. These
transmissions are intended to rapidly lower the NET Frequency Fence  into
the 3-D frequency bands to prevent continuation of the Spontaneous Mass
Human DNA Template Awakening  that is now occurring. The GA  have
since explained that the HAARP facility in Alaska  is the least powerful of
all and was not the facility from which the August 12, 2001, pulses were
launched . The Alaskan HAARP was created  as a ''decoy ''—there are 12
other similar facilities on Phantom Earth,  that interface with our Earth  via
the Falcon APIN system  and the Drakonian-controlled sites of the
Nibiruian Crystal Temple Network.4 
      The Phantom Earth HAARPs, originally Zeta-Rigelian technologies,
are the intended primary transmission stations  in the OWO agenda.
Unfortunately, Angels do Play These HAARPs —fallen angels,  and they
play “Trumpets” too . The Intruder ET Technology code named the
Trumpet  has been used on Earth by the Jehovian Annunaki and
Necromiton-Andromie Fallen Angelics—primarily during various time
periods when our ancient Intruders desired to “keep the earthly populace in
line.” Classic Biblical references pertaining to the use of the “ Trumpet
 T echnology ” can be found in the stories of the “Walls of Jericho Tumbling
                        ______________________                         
                      4.  The Anunnaki originally entered the 1992 Pleiadian-Sirian Agreements because they
                       had lost programming control of all but 9 out of the 24 Nibiruian Crystal Temple Net-
                      works to Drakonian, Reptilian and Necromiton conquest that resulted from the Zeta
                                   Rigelians’ success in expanding the Falcon Matrix wormhole during the 1983  Montauk   project.    
                                                                                                             
                          406

                                                              
                                                           The Hidden Realities of the WTC/Pentagon Disaster
Down” and the likewise the “Tower of Babel,” and in the fall of “Sodom and
Gomorrah.” The Bible, which derived from Jehovian embellishments of
edited Emerald Covenant Essene CDT-Plate translations, presents colorful,
encoded stories of Intruder  ET/Fallen Angelic technological dominion  of
earthly races  presented under the guise of “ the Wrath of God.”  Decoding
the truths hidden within the drama of the Biblical Revelations  story will
assist us in comprehending the position Earth is presently in regarding
advancement of the Fallen Angelic OWO dominion agenda, and the
advanced technologies they have at their disposal. Full translation of the
“Revelations Story” is extremely pertinent to our times, but this subject is
beyond the scope of this book. Further materials concerning the
''Revelations of Revelation '' will soon be available in other texts. For the
purposes of this writing, l will simply address the subject of the “Trumpets,”
which feature prominently in Chapters 8-11 of the Book of Revelations. Just
as Fallen Angels are skilled HAARP players, they are equally “talented” in the
diabolical arts of '' Trumpeteering .'' It is within the Silent Symphony of the
Fallen Angelic “Brass Section” that the hidden reality  of the September
11, 2001, WTC/Pentagon Terrorist Attack Disaster can be found . 
                 
                                          THE TRUMPETS, TOWERS AND TERRORISTS—
                         THE HIDDEN REALITIES OF THE WTC/PENTAGON DISASTER
     The '' Trumpet '' technology  in which the Jehovian Annunaki and
Necromiton-Andromie Fallen Angelic races specialize is a physical
technology  that utilizes a mechanical frequency generation apparatus to
create and project very specific sound structures  to desired long-range
targets.  The Sound Structures are specifically formed sub-space wave fields
composed of micro-sub-atomic units called Mions.  Mion units are a natural
part of manifest matter, composed of groups of the smaller Partiki, Partika
and Particum units (see page 453) that form the blueprints of matter. Mions
represent the stage of transition  between the scalar-standing-wave Partiki
Grid Template and the manifest quarks, mesons, mueons, and sub-atomic
particles, that group to form the atoms, molecules and matter structures that
our contemporary scientists presently recognize.  
     The Trumpet technology utilizes specifically calibrated electromagnetic
wave fields, combined at precise angles of interface , which, when '' sparked ''
with a specific type of electrical charge, create a “ Sub-space Sonic Beam ”
that is literally shaped like a trumpet. The '' Trumpet '' Sub-Space Mion Field
wave-form  has a long tubelike extension emerging from its point of
projection to its target. At the target site, the Trumpet wave-field expands
outward into an inverted cone, like the “head” of a trumpet instrument. The
Mion vibration rhythm  of the Trumpet wave-field can be precisely
calibrated  to “match” the scalar-template of any matter form. Once the
''Form-lock '' is established, the vibration rhythm of the Trumpet wave-field
is progressively accelerated, which causes the template of the matter-form to
which it is bonded to instantaneously shatter. When the scalar-template of a
wave-form shatters, the physical matter structure literally “de-manifests” into
vapor , leaving only a trace of residual ash behind. The Trumpet technology 
407     
                                                                                                                                                    

                                
                         
                         HAARPs, Trumpets, Horsemen, and Heaven
can be used with loving intention in a variety of ways, but in the hands of
Fallen Angelic races, the Trumpet is a weapon of mass destruction.  
   Strong Trumpet Pulses are more difficult to direct with pin-point
accuracy over long distances—matter surrounding the Trumpet Pulse target
can be structurally affected in long-range, amplified Trumpet Pulse
projection. The Jehovian Anunnaki and Necromiton-Andromie races of the
UIR knew this on August 12, 2001 , as they strategized their plan to fully re-
open and activate the Montauk-Phi-Ex Falcon Matrix APIN system, and
connect it to the “Grid Spikes” of the Phoenix APIN system. The
''Trumpets '' stationed on Alpha Centauri and Arcturus in the Phantom
Matrix would have to be used via Phoenix wormhole transmission, if the UIR
was to fulfill its mission of activating and connecting three of the Primary
Phoenix Spikes to the Montauk-Phi-Ex Port Interface Network and
Falcon wormhole.  
      The site of the WTC Twin Towers buildings in New York City  is one
of numerous Phoenix Spike Sites in NYC that connect directly to the
Phoenix wormhole via the Manhattan V ortex and Montauk-Phi-Ex Falcon
APIN. The area of the Pentagon that was damaged in the September 11,
2001, terrorist attacks was built over another Primary Phoenix Spike site, as
are numerous other buildings and the White House, in the Washington,
D.C., area. The third Phoenix Spike site the UIR had hoped to “put on line”
with the Falcon is located in Philadelphia, PA.  The UIR mobilized the bin
Laden Sleepers group to orchestrate the “terrorist attacks” in NYC and
D.C.  in order to produce a '' cover '' to hide the potential effects of the
Trumpet Pulse  that was to be sent to the Phoenix Spike sites at these
locations. If the WTC Towers “just happened to fall down,” and if part of the
Pentagon ''just happened to collapse'' around the same time, somebody would
definitely take notice. The terrorist attacks  were staged by the bin Laden
and related UIR Illuminati Sleeper factions to create a “public smoke
screen” should the Trumpet Pulses cause collapse of the buildings atop the
Phoenix Spikes . This is the reality  of what took place on September 11, 2001,
as the UIR began their aggressive campaign to accelerate their OWO
dominion agenda.  
    In orchestration of the 9/11/2001 event, first a sub-space sonic
amplification pulse  was rendered on August 12, 2001 . This slower-moving
ULF scalar pulse  was simultaneously launched from two locations  during
the yearly planetary '' Magnetic Peak '' cycle that climaxes on August 12.5
The first sonic pulse was sent from an area in Central Mexico  called ''Cue
Site-4,'' an Annunaki ''Serpent'' Base (Thoth-Enki-Zeta Nibiruian
Annunaki), via the Chihuahua, Mexico, Nibiruian Crystal Temple
Network.  The pulse was sent first north, then east along horizontal Ley
                           
                             ____________________________
                5.   A planetary ''Magnetic Peak'' occurs when the planetary Merkaba Field reaches its fastest
                      spin rotation, which amplifies all types of scalar projections. Primary Peaks occur between 
                      August 7-16, with the climax speed consistently occurring on August 12. Stronger peaks
                      occur on August 12 every 20 years, and the strongest every 100 years. The 1943 Philadel-
                    phia Experiment and 1983 Montauk Project were launched on the 20-year August 12
                     Magnetic Peak. The UIRs’  intended Dimensional Blend Experiment  is planned for the
                              100-year Magnetic Peak of August 12, 2003.   
                   408                                              
                     
                                   

                                                 
                                                         
                                                          The Hidden Realities of the WTC/Pentagon Disaster
                 Line-2,  and passed through the Star Gate-2 Gru-AL Point  at Sarasota, FL,
on September 3, 2001.6 
      The Mexico Pulse intercepted the second pulse off the coast of St.
Augustine, FL, at vertical Axiatonal Line-7, the Falcon wormhole,  on
September 7 . The second “sonic slow pulse” transmitted on August 12, was
released northward from the Zeta/Necromiton-Andromie “Falcon” Base
beneath Lake Titicaca, Peru,  on Axiatonal Line-7. The two ULF sonic
pulses interfaced at the Falcon wormhole  on A7/L4, and were then further
amplified and transmitted via Ley Line-3 to the Star Gate-3 “Falcon” Base in
the Bermuda Islands . The amplification pulse was held at SG-3 Bermuda
until September 11, 2001 . On September 11, the '' Dove '' group  (Jehovian
Annunaki), using the Phoenix wormhole at A7/L4, and the '' White Eagle ''
group (Necromiton-Andromie Alpha-Omega), using the Falcon wormhole,
simultaneously transmitted two massive sub-space '' Trumpet Pulses .'' The
Trumpet Pulses were projected from the Falcon/Phoenix wormholes through
Ley Line-3 to the Bermuda Base. At the Bermuda Base, the Trumpet Pulses
were then combined into one, accelerated via the stored amplification pulse
and directed from the Bermuda Base  through the Montauk-Phi-Ex Port
Interface Network  and into the subterranean WTC NYC  Phoenix Spike
location. Moments later the first plane struck the first WTC tower, as the
UIR had previously arranged and delicately coordinated. Another Trumpet
Pulse was released for WTC Tower 2 and another for the Pentagon, using the
same procedure. The Eieyani explained that the Philadelphia, PA , Phoenix
Spike site was also intended as a UIR target on September 11, but the
“cover,” the fourth plane, never made it to its intended destination, and so
the “fourth Trumpet” didn’t “sound.”  
       Other Primary  Phoenix Spike sites on the UIR “first wave” activation
list include Atlanta-GA, Las V egas-NV , Spokane-W A, St. Louis-MO),
Denver/Boulder-CO, Miami-FL, London-England, Iraq, and Palestine. There
are “ Three Waves ” of such Phoenix Spike site activations planned by the
UIR. Localized '' Unnatural Disasters ,'' as well as '' official war strikes '' and
''terrorist activity '' will be tactics used to ''cover'' the covert activities of
Trumpet Pulse Phoenix Spike site activations. The Eieyani did not become
aware of the UlRs’ Phoenix Spike Site activation initiative until the morning
of September 11 , although they were aware that sonic pulses had been issued
on August 12. During our Labor Day workshop on September 3, the Eieyani
had warned us that the UIR had taken aggressive steps to fully re-activate the
Montauk-Phi-Ex facility and that the UIR OWO agenda was now
advancing. The Eieyani discovered the UIR Trumpet Pulse initiative just
after the first plane was in the air.  
    The Eieyani have stated that at this time, they made contact with nine
other GA contactees  in three countries outside of the U.S.A. , motivating
these individuals (unknown to me) to place nine separate telephone calls  to
various governmental agencies in the U.S.A., warning of the pending
                          __________________________
                             6.     Our Labor Day group was “hit” with this disruptive sonic pulse when it passed through
                                         the Gru-AL as we began our RRT work at Sarasota Beach the evening of September 3. I
                                         didn’t discover until later Eieyani dispensations revealed exactly what had occurred that    
                                         evening.
                            409
                                                                                                                                                               

                       
                        HAARPs, Trumpets, Horsemen, and Heaven
attack. Each call was dismissed as a ''hoax'' at the receiving end, and the
Eieyani could do nothing directly to prevent fulfillment of the UIRs’ bin
Laden/Trumpet Pulse initiative.  
                           
                       UIR OWO MASTER PLAN AGENDA   
      Although the hidden reality of activating Phoenix Spike sites via
Trumpet Pulses was a primary Illuminati objective behind the September 11,
2001, “terrorist attack,” there were also other UIR objectives served
through staging of this event. The intended plan for advancement of the
UIR OWO agenda has always included creation of specific effects within
the world political arena that are intended to serve the Fallen Angelic
invasion schedule. Polarization of the global political arena is one effect
that will serve to expedite war among Human nations, and will set up the
“good-guy-nations vs. bad-guy-nations” population division that the Fallen
Angelics need in order to implement their physical contact phase of
invasion.  
      T ake notice that in the “New W ar On T errorism,” U.S. political leaders
are priming the international public for total polarity of national affiliation.
Since the 9/11 disaster, it has been repeatedly propagandized that nations
who will not support the U.S. initiated “Anti-terrorism Coalition” are thus
“supporting terrorism”-''If you are not with us, you are against us.” This
stance has, in one utterly smooth and superficially “justifiable” motion,
forced all world nations to either “side with the Anti-terrorism Coalition” or
become a target of suspicion, potentially suffering economic sanctions or
military reprisals from nations of the Anti-terrorism Coalition.  
      Though the need for international unity in standing up against terrorism
is needed, we all wish that such unity for a common cause would be entered
honestly, without the condition of utter duress that world governments are
presently facing in regard to their stance on the Anti-terrorism Coalition. I
have observed in utter amazement how swiftly the planet has been utterly
polarized around this issue. On the surface, it is understandable that the
event of terrorism would be officially designated as an internationally
unacceptable action that calls for “retribution.”  
       But when one is aware of the “Hidden Element” of the Fallen Angelic/
Intruder ET/Illuminati “Silent Invasion,” it becomes apparent that the mass
surface events have much more meaning than “meets the eye.” Since 1998,
the Eieyani have gently warned those who cared to listen that the UIR was
involved in instigating global war among Human nations in order to reduce
Human populations and to covertly position world government organizations
for later intended physical ET invasion.  
       As Humanity progressively gets “caught up” in the war drama, which
at this point we have little choice about, the UIR “Silent Invasion” moves
nicely along, undetected, right under our noses. The New Age and UFO
Movement people, who have been misled into believing that they are
“immune” to being affected by national and international war issues because
their “ET-Angels” will save them, are in for a rude awakening. Eventually
they will discover that “bombs and bullets” can disrupt their “positive
thought-constructed lives” just as much as anyone else’s. The big awakening
will come when they realize that it is some of their “beloved ET-Angels” that  
410            
                          
                                                                    

                                                                                  
                                                                                 UIR OWO Master Plan Agenda
  have planned and orchestrated these conditions of Human war all along, in
order to advance a OWO invasion/dominion agenda. A progression to mass
war among Human nations will first of all allow Illuminati races to reduce
the numbers of 12-Strand DNA-activating Human populations, and
secondly, it will prepare the global political arena for the Fallen Angelics’
intended staged “First Contact” event. The “Human Greeting Teams,”
which are presently being set up by Fallen Angelics via their “channel”
contacts in the New Age and UFO Movements, are a key element to the
OWO plan. Through these unsuspecting Human groups, seemingly friendly
“ET-Angels” will be able to get their physical presence fully and covertly “on
planet,” undetected by mass populations and government officials, so that
direct infiltration of world governments and Illuminati factions  can begin.  
    The Fallen Angelics hope to create an atmosphere of Human fear,
suffering and population reduction over a period of a few years, while
advancing private contact with their Human and Illuminati "chosen ones."
The UIR knows that progressive environmental and climatic emergencies
will arise due to escalating electromagnetic imbalances in the planetary grids,
brought on by the Illuminati Frequency Fence. Environmental atrocities,
coupled with the progression of Human war, will methodically reduce
Human populations, while moving the “survivors” into a progressively
greater sense of desperation, yielding intensified “prayers for redemption” and
adherence to the promises of salvation offered by religious dogma. After a
certain point of cultivated global crisis is reached, and general ''Martial
Law” governance affects all nations due to the progression of the war drama,
selected members of the global political and religious Illuminati will prepare
the public for contact with "Friendly ETs" via mass media "Official
Disclosure." Once first contact is made, tentatively scheduled for 2005 after
a series of great Storms emerge from erratic progression of Star Gate opening
in the SAC, the UIR intends to ''save us from ourselves.'' They intended to
present themselves to us as the "great saviors from above," who have “come
in answer to our prayers”7 
     If the OWO plan proceeds, Fallen Angelic groups such as the Galactic
     Federation will openly emerge to politically ''back'' the global government
   ''good guys'' that appear to be those ''fighting for freedom'' against countries
    that appear to represent the ''bad-guy'' end of the “good vs. evil” staged
   polarity drama. W orld religions of the “positive polarity group” will have
    been “nurtured” to a point of ''Unity through T olerance" by the time First
    Contact is staged. Our newly introduced ''friendly space kin,'' endorsed by
       Illuminati-controlled governments of the UIR and W orld Management
  T eam, will then further global religious unity through demonstration of
    contrived religious dogma that becomes the basis for a new global political
               order . Human-looking ET representatives of the ''United Federation of
     Planets'' intend to show false historical and genetic evidence that the
      Annunaki groups are the creators of Human life and that they have returned
     to lead us to an ''enlightened'' future. ''Miracle Cures'' will be offered for                           ________________________                                       7.     First Contact could come at any time, if the UIR thinks its scheduled OWO Master Plan
                                          “Dimensional Blend Experiment” will fail and they opt for direct, rapid, physical inv asion
                                          under the “friendly space brother" ploy.    
                             411                                                                                          
                                                                                                                               

                      
                        HAARPs, Trumpets, Horsemen, and Heaven
healing and environmental cleanup, and new global governmental
structures will be imposed  as a condition of the “good-guy group” being
accepted as the “official world government,” so Earth may be entered as a
''Sovereign Global State in the United Federation of Planets ." The “United
Nations” will be “upgraded” to the UPF—the '' United Planetary
Federation ,” and we will find ourselves as “lowly subjects” upon a planet
ruled by the Fallen Angelic Annu-Elohim and Annunaki of Nibiru, Tiamat,
Sirius A, Arcturus and Trapezium Orion. The Annunaki will introduce the
Drakonian, Reptilian and Necromiton-Andromie races as our joint “allies,”
and global territories will be divided up among various ET factions , with
Human and Illuminati puppet-governments appointed by the UIR
orchestrating international political, economic, religious and social affairs
from behind the scenes. ''ETs" will then walk openly among us and
''undesirable '' populations  that refuse to “buy into” the propaganda
promoted through “official” religious, political and governmental channels,
will be quietly disposed of. The UIR agenda requires that Human populations
be seduced into the “necessary state of willing compliance” by 2006-2007.
      Uncontested visible physical “ET” presence on Earth is intended to be
achieved through amalgamation of the “contactees” of the New Age and
UFO Movements with the powers of Illuminati-controlled traditional official
government and religious organizations, and quiet “eradication” of opposing
forces. Once this is achieved, the UIR intends to complete physical building
of the Photo-sonic Transmission plants that they need to break through the
Cloaking Shields on the Inner Earth portals.
      By 2008,  planetary pole shift will begin, and our “ET brethren” will
abandon us to “unnatural disaster” and calamity  while they stage their
intended physical invasion of Inner Earth  and the Halls of Amenti Star
Gates. This  is the UIR OWO Master Plan , which can still be prevented
through activation of the Emerald Covenant Founders’ Four Faces of Man
LPIN System  (see page 526) and the Trion-Meajhé Field  (see page 517).
      When the Eieyani roughly explained this UIR OWO Master Plan to me
throughout 1999,  I couldn’t imagine how such utter dominion of world
governments could take place so quickly within the ''real world .'' How
could the many nations of Earth be rapidly banded into “Us vs. Them” global
polarity? How could the masses be moved into receptivity to a “Unified
Religion” that would leave us all gullibly vulnerable to the “ETs-as-saviors”
drama? How could religious freedom in the U.S. be hijacked into a
governmentally endorsed set of alternative doctrines, with which non~
compliance would become a “criminal act”? My personal difficulty in
believing that an ET “Silent Invasion” could be set in mass motion rapidly
enough  for the UIR’ s 2008 deadline rapidly turned to a sense of horrified
awe as I observed the post-9/11/200l political machine grind into motion.  
      Suddenly we are right smack in the middle of the polarization  of
international consciousness,  with “good guys” uniting to “fight terrorists"
and “bad guys” assisting terrorists. Suddenly everyone is “getting in touch
with traditional gods,” driven by the mourning and fear generated by the
WTC/Pentagon terrorist attack event. And suddenly, the message of
“brotherly interfaith tolerance” is being promoted within the political arena,
bringing  the once-adversarial world “superpower religions” of Christianity 
412 
                        
                    

                                                                        
                                                                                          UIR OWO Master Plan Agenda
and Islam together under the common banner of anti-terrorism, while
Islamic extremists use their religion as an excuse for destruction of others
different than themselves. Although there are definite advantages to such
unification of nations that will foster a much-needed advancement of Human
rights advocacy, this interfaith unity promoted under the banner of political
government also threatens to more fully reunite the powers of ''church and
state. '' If things proceed as the UIR plans, the “state,” or political
government, even in the U.S.A. where religious freedom is supposed to be
constitutionally protected, will again be empowered as the arbitrator of
personal spiritual belief systems. At this point, all the U.S. government needs
to do is put out propaganda that any spiritual organization they covertly
disapprove of is “suspected of terrorist activity,” and the public will be blindly
supportive of whatever action the government deems necessary to “dispose
of the threat.” The massacre of the “Branch Davidians" at Waco, TX, is an
example of how such scenarios of governmental religious repression could
easily be orchestrated without causing American public uproar. In the
U.S.A., we have come to take certain freedoms of speech, religious belief,
travel mobility and “unencumbered passage” as constitutionally protected
rights. As I observed the U.S. political reaction to the 9/11 disaster, I realized
just how fragile our American illusion of freedom really is.  
      Suddenly , people are frightened of a perceived ''outside threat'' so they
willingly accept ''military presence'' at airports and support increased
governmental covert surveillance of civilian populations as ''needed safety
precautions.'' All that is required to ''push the envelope'' just a few steps
further is another atrocity like the 9/11 disaster, and the American public
will accept, with little if any opposition, the need for government imposition
of general ''Martial Law.'' If the present military campaign of bombing in
Afghanistan extends into Iraq and other areas, as the UIR plans, then the
US. President will be ''rightfully empowered'' and apparently “forced” into
activation of the U.S.  ''War Powers Act '' and FEMA . Once the “War
Powers Act” becomes reality in the U.S.A., the ''Rights of the People,'' as
once protected by the American Constitution, will be effectively suspended.
By the time this book reaches publication, the ''War Powers Act'' may have
already become an American reality. Meanwhile, as the international
community becomes progressively more distracted by the growing D-3 “war
drama,” the UIR Fallen Angelics and their Illuminati races covertly advance
their physical “ET” contact/invasion drama.  
       Unfortunately, there is a  pending crisis of even greater concern  brewing
beneath the external and covert Illuminati dramas-Earth is presently fully
ensconced within the very tangible realities of physics  characteristic to a
Stellar Activations Cycle (SAC) . Earth’s Star Gates are now fully opening for
the first time in 210,216 years,  and Earth’ s Planetary Shields scalar-
template is in a terrible disarray of electromagnetic imbalance due to past and
present abuse by Fallen Angelic and amnesiac Human nations. Planets
physically  pole shift  if they cannot hold the progressive infusion of frequencies
that naturally emerge through the Planetary Templar during SACs. Masters
Planetary Templar Mechanics  are the only tools through which such core
challenges of planetary physics can be overcome. We need to start paying 
413  
                                                                                                                          
                                                                                                                    
                                                                                                                                   

                        
                       
                        HAARPs, Trumpets, Horsemen, and Heaven
          
                        active attention to this greater reality if we hope to pass through the 2000
                          2017 SAC with any degree of safety . 
                               DECODING “REVELATIONS”—THE OWO  SCHEDULE
     Since the Jehovian Annunaki Fallen Angelics’ edited, and partially re-
wrote, the original Essene Emerald Covenant CDT-Plate translations that
were supposed to be the foundations for the Holy Bible, we have been
progressively ''set up'' to assist the Jehovian Invasion Team to fulfill their
OWO vision. The Jehovian OWO agenda of the '' Dove '' APIN  system
group , as of the September 12, 2000,  has become formally incorporated into
the general OWO invasion plan of the UIR. 
    The reality of planetary physics  we presently face can best be illustrated
by ''decoding '' portions of the Biblical ''Revelations '' story  that directly
apply to our contemporary circumstance. We will receive greater benefit
from the “Revelations” story if we can begin to understand the truths and
contrived agendas hidden within this Jehovian-written intended dominion
schedule . The most important aspects of the Book of Revelations have to do
with the stories of the '' Seven Seals ,'' the ''Four Horsemen of the
Apocalypse ,'' the ''Seven Angels with their Seven Trumpets ,'' the ''24
Elders '' before the ''Golden Altar'' and Jehovian ''Throne,'' and the '' Four
Beasts before the Altar/Throne .'' 
   Interestingly in recent modern translations of Biblical Revelations, the
mentioning of the '' Four Beast '' before the Throne of Jehovah has been
lifted in status from its earlier “beastly” translation, to become the ''Four
Living Creature'' before the Throne—yet another subtle little sleight-of-
word translation to further distance us from awareness of the true hidden
translation of this text. We have discussed the ancient microchip-like
technologies  of the APIN systems  left in Earth’ s Planetary Shields from the
Atlantian period (see page 367). The APIN grid networks were designed by
their various creators in the shapes of animals or birds , when viewed from
space with photo-radionic scanning equipment. In the story of Jehovian
Revelation,''St. John the Divine'' reported witnessing the ''Four Beasts''
before the Throne; the first was like a ' 'Lion ,'' the second like an '' Ox,'' the
third had a '' Face like a Man '' and the forth was as a ''Flying Eagle.'' It is no
coincidenc e that the four most powerful PIN systems  on Earth are those
created by the Emerald Covenant Founders races—the Great White Lion
Elohie APIN, the Blue Oxen  Maharaji APIN, the Four Faces of Man
Eieyani LPIN and the Golden Eagle  Seraphei APIN. The Jehovian ''vision''
given to ''St. John'' was a cleverly disguised, almost literal symbolic depiction
of the Jehovian Annunaki and Annu-Elohim intention of securing the
Founders’ APIN systems under dominion of the ''Throne of Jehovah .''
This interpretation of the ''Four Beasts'' in Revelation is not “guess work” or
presumption, it is the truth of Revelations decoded,  as contained within the
Founders CDT-Plate records.  
     In truth, the Jehovian Revelations story is a step-by-step illustration of
the Jehovian Anunnaki’s intended invasion schedule . The reason that it is
pertinent to briefly explore the '' Revelations Schedule '' has to do directly
with the '' Four Horsemen of the Apocalypse '' element, the Horsemen that
         are released upon the Earth to begin delivery of the “wrath of God  
                           414  
                                   

                                                              
                                                                     Decoding ''Revelations'' —the OWO Schedule
(Jehovah),” with ''opening'' of the first four of '' Seven Seals ." We need to
understand the truths that Revelations has been hiding from us , because
''Seal '' numbers 1 and 2 ''opened '' in May 2001 , releasing the '' White
Horseman '' and the '' Red Horsemen .'' ''Seal'' number 3 ''opened '' in July
2001, setting the  “Black Horsemen” free, and “ Seal” number 4 will “open”
in January 2002 , releasing the ominous '' Pale  Horse ,'' For anyone
unfamiliar with the Biblical Revelations story, the “Horse stories” go like
this: “...and I watched the Lamb ( see page 367, ff .) open the First of Seven
Seals ...and behold a White Horse , its rider held a bow8 and he was given a
Crown9 and he rode out ...to conquer.” And the lamb opened the Second
Seal . . . . .and behold a Red Horse , ...its rider given the power to take peace from
the Earth and to make men slay each other ; and he was given a mighty
sword. 10And the Lamb opened the Third Seal . . .and behold a Black Horse,  its
rider was holding a pair of scales in his hand.. ¹¹ When the Lamb opened the
Fourth Seal, ...and behold a Pale Horse ...its rider’s name was Death, and
Hell12 followed close behind . They were given the power over the 4th part of
the Earth13 to kill by sword, famine and plague and by the wild beasts of the
Earth....     
      By the time we get to  cthe '' Sixth Seal '' opening, which in technical
terms soon explained will occur between August-September of 2002,  the
''Horsemen'' have done their damage, and we find the following revelation:
''When the  Sixth Seal opened there was a  great Earthquake, the sun turned
black,...the moon turned red .14 
    As if Seal 6 didn’t promise enough damage, there its yet the '' Seventh
Seal,'' which sets loose the “ Seven Angels with Seven Trumpets ...'' By the
time the ''Third Angel sounds the Third Trumpet,'' '' a great star, blazing like a
torch, fell from the sky on the third part 15 of the rivers. . .and the name of the Star
was Wormwood .'' W e have already explored the sub-space sonic-Mion-wave-
field projection technology of the ''Trumpets''; it just so happens that
''Wormwood'' refers to the Nibiruian Annunaki Battlestar ''Wormwood ''
which the Nibiruians have used since 25,500 BC  to keep the Nibiruian
Diodic Crystal Grid (NDC-Grid)  sonic grid control machine operational in
Earth’s Planetary Shields. This is the very same ''Wormwood'' Nibiruian
Battlestar that, since 9560 BC, the Jehovian Annunaki intended to “knock
out of the sky” with their unholy ''Trumpets,'' when they waged their
competing OWO dominion campaign against the competing Nibiruian
Annunaki group during the 2000-2017 SAC.  
      It is time to pay attention, folks ! lt is no coincidence that four months
after release of the Second Seal  and Red ''Horsemen '' (the one “given the
                             ____________________________________
8.    Refers to Sagittarius constellation, Lagoon-''Hourglass Nebula''
9.    Refers to Nebula double halo.
10.  Biblical “swords” refer to speci fic photo-radionic light frequencies.
11.  Refers to the Libra constellation and symbolically to the “weighing of Earth's frequencies”
       through which Earth’s future Time Cycle will be determined
12.  Refers to the 'Pit'' of the Phantom Matrix" Black Hole system.
13.  Refers to the D-4 Astral Plane of Earth’s planetary anatomy.
14.  Both refer directly to a visual anomaly that naturally occurs when Earth passes into the
       Three-Day Particle Conversion Period  of a SAC. See page 223.
15.  Refers to the D-3 reality plane, where we all presently live.   
415                               
  
                                                                                                                                                                
                    

                        
                         HAARPs, Trumpets, Horsemen, and Heav en
power to take peace from the Earth and make men slay each other”) that we
suddenly find our nations immersed within the “New War on Terrorism.”
Already the bombs are ﬂying. Opening of the Fourth Seal (due by summer’s
end 2002) and release of the Pale  Horse  is the point in Revelations when
things begin to get really “ickey”—the rider named “Death” and the “Pit”/
Phantom Matrix/ Wormhole Crew  follow close behind. But until we come to
understand “ What the heck are these horses and horsemen anyway ?” these
revelations will have little rational meaning. It is vitally important to our
collective planetary well-being that we f inally comprehend the real meaning
of the ''Four Horsemen of the Apocalypse, '' the '' Seven Seals '' and the
''Seven Angels with Seven Trumpets .'' Here follows the truth of what we
will all move through during the next seven years of the SAC.  
                            
                   REVELATIONS AND “SAINT JOHN THE DIVINE”                
           In the Jehovian Annunaki falsification of original Essene scripture,
there were numerous historical references to the “ Trumpets of God ” and
their powers to render the “Wrath of God” on behalf of the “righteous.”16 As
previously discussed, the Biblical “ Trumpet ” was an Atlantian ''code word ''
for the sub-space Sonic-Mion-Field projection technology  that has been
used by the Jehovian Annunaki as a remote-range weapons system  since
pre-Atlantian days. Just as the ''Trumpet'' and ''Four Beasts'' references held a
hidden meaning  that was not at all ''spiritual'' or “esoteric” in nature, but
rather a specific reference to a tangible, Annunaki-created scientific
technology , so too do the other elements of the Revelations story have a
hidden technological meaning . The references pertaining to the “Trumpets,”
their “Angels,” “the Four Horsemen,” the “Altar of Gold before the Throne”
and the “24 Elders before the Throne” now found in the Biblical Revelations
story were  not part of the genuine Founders’  Emerald Covenant CDT -
Plate translations rendered by the Essenes.  
      These colorful pictures of symbolic code  were part of a Holographic
Insert Program  initiated by the Fallen Angelic Jehovian Annu-Elohim and
Bipedal Dolphin People Annunaki of Sirius A and Arcturus  in the
Phantom Matrix . The stories were based partially upon fact , in relation to
the technological reality  of the natural Planetary Seals that do release or
“open” via Star Gate-12 (the “Lamb”) during SACs. To “invent” their own
version of “Revelations,” through which the Jehovian dominion agenda was
intended to be fulfilled, the Jehovian Annunaki gave, as a series of
Holographically generated NET “visions,” a twisted version of the original
Atlantian Emerald Covenant Revelation story.  
     The individual responsible for what has emerged as the “Biblical
 Revelation” interpretation became known as “ St. John the Divine ,” who was
 in truth a female Emerald Covenant “Flame Keeper ,” born of Blue Flame
 Melchizedek mother and Jehovian Annu-Melchizedek father . The Jehovian
 Annunaki used this individual, through astral Tagging , via their portion of  
 the NET , to bring “prophecy” that would prepare those who followed to
                         ________________________
                 16. The  true  God Spirit is not wrathful, nor vengeful, but immature Fallen Angelic Annunaki
                                         and Anu-Elohim false godlets are.
                               416
                  
            
     

                                  
                                                        
                                                    The “Seven Churches,” “Seven Angels” and “the Dove"
fulfill the Jehovian OWO agenda . Emerald Covenant teachings of the D-8
Gold light fields of Orion Mintaka , Universal Star Gate-8, were distorted
into the “ Gold Altar before the Throne ” symbolism. The '' 24 Elders before
the Throne '' represented the Fallen Angelic Jehovian Annu-Elohim
forefathers of the Annunaki Nibiruian Council of 24 , which was controlled
by Jehovian ''pure-strain'' Bipedal Dolphin People Annunaki '' Overlords .''
The ''visions'' given to ''St. John'' were a symbolically encoded
interpretation of the intended Jehovian OWO agenda  scheduled to unfold
between 2001-2008 AD, during the anticipated SAC. The Jehovian “Book of
Revelation” was based upon Jehovian Annu-Elohim knowledge of Atlantian
Emerald Covenant Templar teachings pertaining to Planetary Seals  and the
behavior of Planetary Seals during the anticipated 2000-2017 SAC. The
Jehovian Revelation story audaciously depicted what the Jehovians intended
to do to Earth’s Planetary Shields, during the Final Conflict drama that
was scheduled to unfold between 2000-2017.  
   
                           THE “SEVEN CHURCHES, ” “SEVEN ANGELS” AND “THE DOVE”             
       Th e ''Angel'' word in the Jehovian Revelations story does not refer to
       singular ''Divine People.'' The symbol code of ''angel '' was used to represent
    an advanced technology  called the Jehovian Hyperdimensional Cone,
      which utilizes external Merkaba Mechanics —-an external energy
  technology  that was seeded into Earth's Planetary Shields , much as were
   t h e  a f o r e m e n t i o n e d  P h o e n i x  S p i k e s  a n d  A P I N  s y s t e m s .  T h e
    Hyperdimensional Cones (HD-Cs)  were placed as standing-conical-scalar
   wave clusters  imbued into Selenite and quartz rods,  which were originally
  implanted  into the Earth’ s crust, mantle and Planetary Shields  during
  earlier Atlantian periods, in an unsuccessful attempt to fulfill the Jehovian
   OWO dominion agenda during the 22,326 BC SAC.  
      Like the Phoenix and Falcon wormhole APIN systems, the HD-C
network  represented an interface between Earth and the Phantom Matrix.
Unlike the Phoenix and Falcon “holes in the Wall in Time,” the HD-C
network was more like “ Cracks in the Wall in Time .” The HD-C Network
of the Dove did not become fully operational until the 10,500 BC creation of
the Phoenix wormhole, which the Jehovians used to increase the function of
their Dove APIN HD-C network. The Anu-Seraphim Nibiruian Annunakis
created the Phoenix wormhole during the 10,500 BC Luciferian Conquest .
This was a time in Nibiruian history in which the Anu-Seraphim Annunaki
races of the “Councils of 9 and 12” rebelled against the Annu-Elohim Over-
lords" of the '' Council of 24 Elders .'' When the Nibiruians created the
Phoenix, the Jehovian Annunaki and their Annu-Elohim ''Council of 24
Elders'' began implanting Earth’s Planetary Shields with further elements
of the original 22,326 BC HD-C technology .                                        
      The Phoenix W ormhole created a weakness within the surrounding
                  frequency field of the ''W all in Time.'' The Jehovians were able to use these
                 weaknesses to create a network of thin, interwoven frequency bands,
  anchored through the HD-C implants, that ran from the Phoenix Wormhole                          
access point like “cracks,” into control areas of Earth’s Planetary Shields. The  
areas of Earth in which the HD-C implants were placed  were linked to the    
portion of D-7 Universal Star Gate-7 Arcturus  that was under Jehovian  
      417       
                                                                                                                                                                                  

                       
                    
                        HAARPs, Trumpets, Horsemen, and Heaven
Annunaki and Annu-Elohim dominion. Seven massive Crystal Pylon
Selenite Rods  were placed within the Arcturian SG-7 control grid , before
the SG-8 galactic core “Golden Altar and Throne.” These were described as
the “ Seven Candlesticks which are the Seven Churches ” in Biblical
Revelation. The '' Seven Stars which are the Seven Angels of the Seven
Churches " referred to the Seven Prime HD-C implants  in Earth’ s Planetary
Shields that anchored the Seven Arcturian Pylon Selenite Rods
“Candlesticks/Churches” into Earth’s grids. This is not ''Divine
Construction ''—it is the anti-Christiac work of advanced  subtle-wave
broadcasting technology  employed for intended planetary dominion and
destruction.  
      The HD-C network was intended to serve as a series of ''Siphoning
Channels. '' Portions of Earth’s Shields and selected populations could be
pulled through the Phoenix Wormhole into the Phantom Arcturus Matrix
as the Nibiruians used the Phoenix Wormhole to draw the rest of Earth’s
Planetary Shields into merger with Phantom Nibiru and Tiamat. The
network of Jehovian HD-C implants in Earth’s Planetary Shields is known as
the Dove APIN system , denoting the shape of its primary grid when viewed
from space with photo-radionic scanning equipment. The “Dove,” like the
Falcon, the Phoenix, the Serpent and the Dragon APIN systems, represent
Aerial maps  of the Fallen Angelic/Intruder ET control networks  placed in
Earth’s Templar. The “Dove” was recently revealed in the contemporary
works of Enoch,  while he was supporting the Jehovian OWO agenda before
his 1983  Emerald Covenant Redemption Contract. Specific representation
of these APIN maps  and their contemporary language literal translations
and geographical co-ordinates are contained within the Emerald Covenant
CDT-Plates “Book of Maps and Keys.” The HD-C implants of the Dove
APIN system are frequency generation points  implanted into Earth’ s body
that can create external, artificial, reverse-spin  (Phantom Matrix spin)
Merkaba Vehicles  of various sizes and designs. Once generated, these
spiraling electro-magnetic Reverse Merkaba Fields  can hold a person or
object, or an entire city or continent , depending upon the size of the field,
through hyperdimensional transport into phantom matrix . When used in
specific ways , the HD-Cs form '' Plasma Ships, '' beautiful elongated orbs of
glowing ''living '' light , that can, if programmed to do so, '' step down in
frequency” to form solid-objects , usually Silver metallic “space ships,”
complete with a Jehovian Phantom Crew.  
      When used in other ways, the HD-Cs of the ''Dove'' receive, amplify
and transmit invisible sub-sonic wave fields  from the Pylon Selenite Rod
transmission bases in the Planetary Shields of Phantom Arcturus.  The
Seven Pylon Selenite Rods stationed on Phantom Arcturus are the ''relay
station'' or '' midway station '' through which the frequencies of similar Pylon
Selenite Rod installations on Sirius A  and in Trapezium Orion  and the
Hourglass Nebula  in Sagittarius interface with the living Time Matrix
system. The HD-C points in Earth’s Planetary Shields can be used as Sub-
sonic ULF Scalar Pulse transmitters  that are capable of sending Targeted
Sub-sonic Scalar Pulses  through the Dove Matrix  network grid lines of
Earth, to very precise targets . Like the Falcon and the Phoenix, the Dove
            Matrix is a powerful weapons system , especially when combined with the
                    418 
                      

                              
                                                 
                                                The Seven Seals and the Four Horsemen of the Apocalypse
advanced “Trumpet” technology, as the ancient peoples of Jericho and
Babylon  unfortunately discovered too late, when the “ walls came tumbling
down .” The HD-Cs of the Dove are also capable of interfacing with
Jehovian-programmed Nibiruian Crystal Temple Network sites  on Earth
for interplanetary and inter-stellar sub-space communication  and access to
the NET. The HD-Cs of Earth are controlled by the Jehovian Annu-Elohim
from Arcturus in Phantom Matrix  and from a site on Earth called “ Cue-
Site-8 ” in the Takla Makon-Tarim Basin, Tibet . Presently Cue Site-8 serves
as the “ control matrix broadcast headquarters ” for the YHWH-Metatronic -
Enochian-Jehovian  Annu-Elohim, the Jehovian Annunaki branches of the
Galactic Federation and Ashtar Command , parts of the '' Archangel ''
Michael-Nephilim Matrix  and factions of the “ Great White Brotherhood-
Ruby Order ” Nephilim and related Vairagi  collective that defected from the
Emerald Covenant. The HD-Cs of the Dove Matrix link Earth to the Seven
Selenite Pylon Rods of Phantom Arcturus at Seven Primary Points  in
Earth’s Planetary Shields. At these Seven points in Earth’s Planetary Shields
the seven largest HD-Cs  are placed—the “ Seven Angels of the Seven
Churches ” in the Jehovian “Revelations” story. The “Seven Angels of
Jehovian  Destruction”17 are anchored  into Earth’ s Planetary Shields through
the ''Seven Seals of Jehovah. '' 
                                              
                                                               THE SEVEN SEALS
                                   AND THE FOUR HORSEMEN OF THE APOCALYPSE         
     The seven “anchoring rods,” or '' Seven Jehovian Seals ,'' of the Seven
Prime HD-Cs of the Dove APIN system were placed in Earth’s Planetary
Shields specifically on one vertical column, horizontally across from certain
natural configurations in Earth’s Templar called Star Crystal Seals . The
Seven Unnatural Jehovian Seals  are all positioned along Axiatonal Line-7,
the vertical coordinate upon which both the Phoenix and Falcon Matrix
wormholes  are located, and connect to a secondary set of Seven artificial
Jehovian Seals that are placed within the natural “Seed Seals” of Earth’s
Seven Primary V ortices. (See Star Gates and Seals  diagram Appendix V).
During SACs, the natural 12-Star Crystal Seals  in Earth’ s T emplar
progressively and sequentially activate with Earth’s Star Gates, allowing the
Axiatonal Lines in Earth’s grids to braid so Earth enters natural Merkaba
under D-12 Planetary Maharic Seal. The ''trans-dimensional '' Star Crystal
Seals exist between each of the 12-dimensional Star Gates  in Earth’ s
Templar; when Star Crystal Seals open, they allow the specific dimensions of
frequency from the Star Gate above and below to blend.18 The Seven
Jehovian Seals that hold the Seven “Angels”/Prime HD-C implants of the
Dove APIN system, which link via sub-space sonic frequency bands  to the
Seven Pylon Selenite Rods of Arcturus,19 were placed in correspondence to
                 
                       ________________________________________  
                              17.   Seven Prime HD-C links to the Seven Arcturian Pylon Selenite Rods
                        18.  The Star Crystal and Seed Crystal Seals within the Human  DNA Template  and personal
                           '' Inner Templar " operate the same way to create DNA Strand Braiding  for Atomic
                                         Transmutation and Star Gate passage( ascension).
                                 19.    Seven "Churches/Candlesticks/Spirits of Jehovah God”
                                419
                                                                                                                                 

                
                        HAARPs, Trumpets, Horsemen, and Heaven
Seven of Earth’s Natural Star Crystal Seals . During a SAC, the '' Seven
Unholy Jehovian Angels '' were intended to sequentially activate in response
to natural activation of seven out of the 12 natural Earth Seals; the purpose
of these unnatural Jehovian HD-C '' Seven Seals '' is to progressively r ip
greater “wormholes in the Cap on the Wall in Time .'' 
   When a Jehovian Seal activates , a new Wormhole connection to the
Phoenix Wormhole  is “frequency-punched” into Earth’ s matter base, in the
geographical location of the Jehovian Seal. The Atlantian Dove APIN , like
the Phoenix, Falcon, and several other similar networks installed during the
Atlantian period in preparation for the 2000-2017 SAC, was designed to
rapidly create a massive series of minute Black Holes in the fabric of
Earth’s body,  while creating a frequency barrier around Earth’s
magnetosphere . The ''black hole networ'' is designed to progressively
expand , each ''hole'' opening into the others as the frequency barrier in
Earth’s magnetosphere “holds the planetary mass together” while Earth is
literally '' sucked '' into the Black Hole Sub-time Distortion Cycle  of the
Phantom Matrix. Because several competing Fallen Angelic collectives from
various locations within the Phantom Matrix would attempt to use similar
APIN technological atrocities to accomplish the same feat during the 2000-
2017 SAC, Earth’s Planetary Shields would be literally pulled apart . The
planetary matter base would fragment , its various pieces as held together
within their magnetosphere suspension fields,  would be drawn into orbit
around the Phantom Matrix planets  that exerted the greatest ''magnetic
pull.'' The location in the living Time Matrix where Earth is presently
positioned, would be left with a massive “rip in time,” a Black Hole that
would progressively expand via particle accretion, to eventually “swallow” 11
dimensions of our 15-Dimensional Time Matrix.  
             The first four Jehovian HD-C implants of the Dove APIN are known as
''The Four Horsemen Of The Apocalypse .'' The ''horses'' represent four of
the 12 natural stellar currents , the carrier wave frequencies  corresponding
to the first four  of Earth’ s natural 12-Star Crystal Seals , that will run into
Earth’s Templar to begin activation of the corresponding Star Gates and
Axiatonal Lines. The Seven Jehovian HD-C Seals are placed in conjunction
to Earth’s Star Crystal Seals numbers 1, 2, 3, 8, 9, 10 and 11 . 
      Jehovian HD-C Seal-1 , the '' White Horseman ,'' placed on A7 vertical,
latitude 47.08° N, northeast of  Quebec, Canada, corresponds to Earth Seal- 1
France, which carries the D-11/l2 “Silver-White Maharic light spectra” or
the ''White Horse '' carrier wave.  
      Jehovian HD-C Seal-2,  the '' Red Horseman, '' placed on A7 vertical,
latitude l8.l° S, near the border conjunction of Chile/Peru/Bolivia,
corresponds to Earth Seal-2  near St. Helena Islands, which carries the D-l2/
l ''Red light spectra'' or the '' Red Horse '' carrier wave.  
      Jehovian HD-C Seal-3 , the '' Black Horseman ,'' placed on A7 vertical,
latitude 4l.78° N around Cape Cod, corresponds to Earth Seal-3,  south of
Sofia, Bulgaria, which carries the D-11/10 “Density-3 blue -black  and silver-
black  black light spectra ,'' or the '' Black Horse '' carrier wave.  
            Jehovian HD-C Seal-4,  the '' Pale  Horseman ,'' placed on A7 vertical,
                   latitude 24.92° N, east of Nassau, Bahamas, corresponds to Earth Seal-8 SW
               Las Palmas, Canary Islands, which carries the D-6/7 '' Pale'' Density-2 Semi-  
                          420    

                                                             
                                                 The Seven Seals and the Four Horsemen of the Apocalypse
Etheric and Density-3 Etheric  indigo/violet light spectrum, or the '' Pale
Horse .'' As Revelations 6:7 warns, when the 4th Jehovian Seal  releases, the
Rider named “Death” upon a Pale Horse takes peace from the Earth, with
“Hell” following close behind . “Hell, Hades, the Pit” represent the Pit of the
Phantom Matrix  expanding through Earth’ s Planetary Shields via the
Falcon-Phoenix wormholes  and the various Fallen Angelic APIN systems.
(See: Planetary Seals Locations and Opening Schedule , Appendix V).  
      In the Jehovian Revelation story , the Jehovian Annu-Elohim drew
their sinister inspiration from the true Revelation books  of the Emerald
Covenant CDT-Plate teachings on the Planetary Templar Mechanics of
SACs, which detail the maps and natural functions of the organic 12-Star
Crystal Seals in Earth's Templar during SACs. In Jehovian Revelation, the
“Four Horses” have '' Riders ''—the Four Horsemen , each supposedly '' given
the power by God '' (AKA Jehovian Annu-Elohim and Annunaki) to do
certain very unpleasant things  to the peoples of Earth. '' God '' did not give
these ''Horsemen '' such power or privilege ; the Jehovian  Annu-Elohim
gave themselves this unholy permission  while appointing themselves “in
the minds of man” as “God.”  
      The '' Four Horsemen '' are the “ frequencies of the first four Jehovian
Seals that would ride upon and direct the frequencies of Earth’s natural
carrier waves, the ''horses .'' The Jehovian frequencies would automatically
emerge  with the release of each corresponding natural Seal, due to  the
Jehovian HD-C implants , ''Angels,'' placed relative to the natural Seals. The
Jehovians knew that the ''Horsemen '' would bring death and destruction,
just as the Jehovian Annunaki and Annu-Elohim intended them to do so .
The frequencies transmitted by the first four Pylon Selenite Rods on
Phantom Arcturus were intended to emerge through the HD-Cs
corresponding to the first four Jehovian Seals.  
       As the first four Jehovian Seals released, unleashing the “Four Horsemen
of the Apocalypse,” Earth’s Planetary Shields would begin ripping apart  as
the artificial external Merkaba Fields generated by the HD-Cs held select
portions of Earth’s matter base and populations in trans-dimensional
suspension . The part of Earth’s Template and populations held by the
Jehovian Dove APIN  are intended to go into merger with Density-3
Phantom Arcturus  via the Phoenix Wormhole  and HD-C network . The
Jehovian Anu-Elohim and Annunaki false ''ascended masters'' refer to this as
“ascension”; it is a macabre, unholy, ascension . Unless, of course, one desires
temporary, artificially sustained “eternal” life in a '' living-dead '' thought -
form body , trapped in the Phantom Matrix  as a “demon-on-a-leash,”
commissioned to do the bidding of Jehovian Annunaki or one of the other
unsavory Fallen Angelic dictatorships.  
      The Jehovians were not kidding when they prophesied that '' the Dead
Shall Rise ,'' but unfortunately it was not our long-lost loved ones that would
be returning; the Jehovians were referring to the living-dead  tortured souls
from the Phantom Matrix Pit . Souls that have been “ harvested ”20 by the
                         _________________________                        
                           20.     I.e., kidnapped—consciousness ''soul essence" siphoned into the Phantom Matrix at time
                                              of death.
                              421
                                                                                                                                            

                        
                       
                        HAARPs, Trumpets, Horsemen, and Heaven
Jehovian Annu-Elohim, Necromiton-Andromie, Pleiadian-Nibiruian, Zeta-
Rigelian, Odedicron-Reptilian and Omicron-Drakonian “Grim Reaper”
collectives  since the Dove, White Eagle, Phoenix-Serpent, Falcon and
Dragon APIN systems were set in motion in ancient Atlantis.  
      In Biblical Revelation the Jehovians depict their great battle and
intended victory over the “Great Beast.” At the heart of the “battle with the
Beast” story is the Jehovian Annunaki and Annu-Elohim’s long-term
competition with the Omicron-Drakonians and the Marduke-Satain family
Anunnaki of Alnitak, Orion and Alpha Centauri. This story also re ﬂects the
equally vigorous competition between the Jehovian Anunnaki and the
Pleiadian-Nibiruian “Luciferian” Anunnaki (Thoth-Enki-Zeta Lulitan family
line) of Alcyone, Nibiru and Tiamat. These ancient, competing Fallen
Angelic Anunnaki and Drakonian family lines were personified as the
''Satan/Lucifer '' character  in the Jehovian edits of the Bible texts.  
       I truly hate to be the bearer of “bad news,” but the reality of the present,
highly edited and contrived version of the Bible, like that of the Islamic
Koran and other “traditional holy doctrines,” does not represent the
“absolute word of God” that so many people hope it does. ( All religious texts
have been manipulated in this way since the 9558 BC fall of Atlantis). For
over 11,000 years, Human races have been warring and killing each other on
behalf of self-promoted false “Vengeful Gods” from ancient Intruder ET
fiction stories. All the while the truth of the Loving God and humanity’s true
Spiritual Heritage of the Founders Emerald Covenant Freedom Teachings
have been repeatedly suppressed, misused, abused, twisted and defamed on
behalf of our Fallen Angelic galactic terrorists.  
        __________________________________________________________                        
                         How long will we continue to allow these cosmic criminals to use us as pawns
                             in their conquest game for Earth/Inner Earth/Halls of Amenti dominion?                         __________________________________________________________                                         
                           
                                                                 RETURN TO INNOCENCE
                        Salvaging the Sacred. Healing World Religions.
   In the times before the 208,216 BC Fall of Brenaui,21 when the Angelic
Human races of Earth suffered the loss of D-1222 access, all life experience
was a “living prayer” of joyful spiritual and material celebration. In those
times “religion” was not a control dogma used to rob personal power and
dignity from people. In those times, people did not die, they consciously
chose to ascend out of density via the Universal Star Gate system. Science
and Spirituality were fully understood as part of the same Primal Creation
Mechanics  that allowed for the experience of manifest expression and
simultaneous experience of At- one-ment with the true loving God-Source.
Back then, we all knew ourselves, each other, the Earth, and all things  as
blessed expressions of the one God, and we honored all things accordingly. In
                             ___________________________
                             21.   See Forbidden Testaments of Revelation , forthcoming.
                                 22.  Pre-matter Density-4 ''Universal Christos Field.''
                                
                              422
                      
               

                                                                                     
                                                                                                             Return to Innocence
those Ancient of Days, the Days of Innocence , there were 12 Angelic
Human Tribes appointed as the co-Guardians of Earth’s Planetary Templar
Complex. Each Tribe was entrusted with one of twelve Emerald Covenant
CDT-Plates; each CDT-Plate held one-twelfth of the Founders’ Emerald
Covenant teachings on the Nature and Mechanics of Reality, Consciousness
and Manifestation. From the 12 CDT-Plates, protected by the 12 Angelic
Human Tribes, arose the first earthly verbal and written translations of the
Founders’ Sacred Teachings. These text translations were the original Holy
Books  of the 12 genuine components of what is termed ''Religion .'' The
teachings of  all genuine Holy Books complemented each other , honored the
same eternal, loving,  one-God Source that has infinite names and none. All
of the ancient “Holy Books” that still divide our races today originally
emerged from these 12 bodies of once-sacred Emerald Covenant teachings.
In the chaos of Fallen Angelic infiltration of Atlantis, and the progressive
advancement of the Anti-Christiac Phantom Matrix paradigm on Earth that
has occurred since Atlantian times, our sacred religions have been raped
and all but extinguished.  False teachings have been woven between the lines
of truth, and the greatest bodies of truth have been removed entirely.  
       For over 11,000 years, Human and Illuminati-hybrid races, denied the
truth of their history, race identity, memory and immediate relationship to
the God-Force, have been destroying each other and the Earth on behalf of
Intruder ET/Fallen Angelic religious deception . It is now up to each of us to
decide whether or not we love the Living, Loving, Eternal God- presence ,
and the promise of “attainable heaven” that true God-spirit stands for. The
Living God-Presence does not reside in  any book, It resides within each and
every person, place or thing. True “Holy Books” teach us of the eternal truths
of spirit and science, through which we can most rapidly and easily awaken
the God-Presence within. Some people will choose to love more than the
Living-Loving God—the twisted rantings and ravings of vengeful, harsh and
judgmental Intruder ET-false-Gods, because this provides them with false
security and a “socially acceptable” frame of reference. False security and
“fitting in with the local clan” are rather pathetic “rewards” for the payment
of imprisoning one’s soul.  
       The sacred teachings of the 12-Tribe Nations are presently drowning in a
sea of Fallen Angelic lies; it is up to us to save them. Each contemporary
religion holds partial truths and partial lies . It is up to us to find the Living
God-spirit within, through which we can salvage the sacred within each and
every creed, and dispose of the garbage that has taught us to judge and kill
each other, to martyr ourselves, and to unknowingly support Fallen Angelic
agendas. If we desire to find the promised “Heaven on Earth,” we must first
find it within ourselves, which we cannot do while we continue to Crucify
Ourselves  in the name of external W arlords and Wrath-filled False Gods. In
the salvaging of the sacred and discarding of the deception within our world
religious creeds, we can all rediscover God, ourselves and each other, and in
423 
                                                                                                                                    

   
                        HAARPs, Trumpets, Horsemen, and Heaven
that discovery we can begin the journey of our collective Return to
Innocence.  
      God is real.  It is an omnipresent, omnipotent, omniscient Force and
Source of consciousness within which we all reside (even the “bad guys”),
and of which we are all composed. The true God is beyond form
manifestation; and no being can ever be separate from the true God, because
all form manifestation takes place within the Source. Even beings of the
Phantom Matrix are part of the wholeness of God, but they represent the
parts of God’s consciousness that have forgotten their Divine Identity and
have no memory of the wholeness of which they are a part. Phantom Matrix
beings compete for power with others, as they neither acknowledge nor
comprehend the endless supply of living power, energy and love that
eternally circulates between Source and all living things manifest.  
       W e are all directly connected to the real God-Source in every moment;
we can learn the once common-knowledge '' secrets '' of allowing the Living-
Loving God-Presence to progressively embody within us . We do not have
to subjugate ourselves to self-appointed false-God Fallen Angelics who
depend upon taking our energy/power to sustain their own finite supply.
Once we overcome the hurdle of “ external false-God worship ,” and replace
it with “ internal Living-God Worth-ship ,” we will no longer be overly
impressed by, or mentally and emotionally gullible toward, the “space-
brother savior” Fallen Angelic agenda.  
        Ascension is real, but it is not achieved by allowing yourself to be sucked
into the Phantom Matrix due to dogmatic adherence to Fallen Angelic -
distorted ancient texts. The Emerald Covenant Founders Races have always
taught the  original Freedom Teachings  of our Loving Source  and
Inalienable Spirituality , the realities of a loving God that lives within us all.
The Founders also teach the sacred science realities of the Maharata23 for
which the real ''Christ story'' originally stood, and which the real man Christ,
Jesheua Melchizedek, and many others of all religions, once passionately
taught.  
      Long ago, before our planet was “hijacked” by the spiritually and
genetically twisted, mentally disturbed, power-hungry Fallen Angelic souls of
the Phantom Matrix, the Emerald Covenant teachings were Humanity’s
Heritage and common knowledge. The Emerald Covenant teachings were
once the core, heart and soul of every religion. These teachings belong to
the Christian, the Muslim, the Jew, the Hindu, the Buddhist, the Tribal
Shaman....to everyone.  This was true in the days before the “Falcon,” the
“Phoenix,” the “Serpent,” the “Dragon” and the “Dove” laid their territorial
claim on Earth and attempted to possess humanity’s soul. These were the
Ancient of Days , the Days of Innocence,  when Angelic Humans lived in
peace and joyful union  with all other kingdoms in “God’ s House of Many
                              
                             ____________________________
                              23.   Personal Inner Christos, Pre-matter Template and D-12 Divine Blueprint.
                             424
                           
                         

                                                                                             
                                                                                                              Return to Innocence
Mansions” that is our 15-Dimensional Time Matrix System and the many    
others of its kind. These were days before the dereliction of Atlantis. Right
now, in the Bridge Zone Inner Earth Time Continuum that represents
humanity’s victorious future,24 the Days of Innocence are reborn.  
    T oday , we are faced with a truly profound choice. Do we subjugate and
sacrifice our Living Inner Christos25 upon the altar of wrathful Gods from
ancient books, or do we reach within and Godward, to find the Living
Presence of Source that has always been there? These are the most decisive
of times, for in the contemporary drama we will witness the long-foretold
“battle of the Angels.”                                ____________________________________________________________                         
                               The Fallen Angels and the Living Angels will, in these very times, meet, and
                        each individual will face the choice of deciding which type of Angel to be.                          ____________________________________________________________
                        _________________________
                                  24.   Time is simultaneous.
                                  25.   Our D-12 personal Christed Avatar Identity level.
                                425
                                                                                                                                                                                                                                                                                 

                                 
                                                  21
                                                                                                                                                                                                                                                                                                                          
                                                                                                                                   
                              Conclu sion—
                         Earth Changes Potential
                           PLANETARY SHIELDS CRISIS, SEALS AND EARTH CHANGES
       It is important to realize that the “Seven Seals and Four Horsemen”
story of Jehovian Biblical Revelations is a colorfully encoded depiction of
tangible events  of science, technology , the mechanics of planetary physics
and the intentions of the Fallen Angelic visitors, as these elements would
emerge within the 2000-2017 Stellar Activation Cycle (SAC). Presently the
hidden realities of the natural 12 Planetary Star Crystal Seals  and unnatural
Seven Jehovian Seals  (see page 419) have a tremendous bearing upon what
humanity will experience between now and 2008.  
     The 12 natural Star Crystal Seals in Earth’ s Planetary Shields
sequentially and automatically release or “open” in response to the
progressive Stellar Wave Infusions (frequency infusions) generated by the
opening of Earth’s 12 Primary Star Gates. Release of the natural Seals alone
can cause cataclysmic Earth Changes during a SAC, if the Planetary Shields
are not functioning properly. Due to the effects of the Nibiruian Diodic
Crystal Grid (NDC-Grid) technology that has created progressive distortion
within Earth’s Planetary Shields since 25,500 BC,  Earth’ s core scalar-wave
template has suffered extensive damage.  Emerald Covenant Guardian
Nations were faced with a huge challenge in keeping Earth’s Planetary
Shields stabilized  during the 2000-2017 SAC, even before the damage to
Earth’s grids was profoundly increased through the progression of Fallen
Angelic/Illuminati One World Order (OWO) agendas since 1930.  
      V arious Emerald Covenant nations would have liked to have initiated
direct, physical, public contact with the inhabitants of Earth by 1930, so that
this pending planetary crisis could have been handled cooperatively and
directly from surface Earth locations. If it were not for the fact that Human
and Illuminati governments chose to honor the 1930s Zeta Treaties rather
than to accept the Guardians’ offer of Emerald Covenant entry, first contact
with Guardian nations and direct repair of Earth’s Planetary Shields would
have already taken place.  
      As circumstances have dictated since 1930, and even since 9558 BC,
Emerald Covenant nations could not directly intervene via mass physical
contact. If Guardians had attempted mass physical contact, various Fallen
426 
            


                                                          
                                                            Planetary Shields Crisis, Seals and Earth Changes
Angelic legions would have immediately brought this covert intergalactic/
interdimensional war “out into the open,” and human civilizations would
have been decimated by overt Fallen Angelic/Intruder ET warfare waged on
Earth’s territories.  
      If the Illuminati and Human races within the Interior W orld
Government had chosen Emerald Covenant rather than Zeta Treaties in the
1930s, Guardian races could have worked with them to peacefully seal Earth’s
Star Gate and portal system—the Falcon Wormhole (see page 367)—and to
disengage the NDC-Grid. This would have prevented further Fallen Angelic
infiltration and Earth’s Planetary Shields could have been sufficiently
repaired in time for the 2000-2017 SAC. Covert World Management Team
cooperation with the Guardians’ world-freedom agenda in the l930s would
have permitted members of the Sirius-B Maharaji races to be “smuggled” in
to Earth territories without engaging the suspicions and retaliation of Fallen
Angelic legions. Earth’s Templar would have been reclaimed from Fallen
Angelic control and Humanity would have been restored to its rightful place
as Guardians of Earth’s Templar. “ Would’a-Could’a-Should’a ” Hindsight is
the greatest foresight . Unfortunately, Illuminati and Human members of the
covert Interior Government did not accept the 1930 opportunity for a
peaceful resolution and, equally as unfortunate, the Anunnaki races chose to
join the United Intruder Resistance (UIR) OWO dominion campaign on
September 12, 2000. And here we all sit in 2001 as the long-anticipated Final
Conﬂict drama begins the emergence into physical manifestation. The
greatest danger  to Earth populations at this time is posed by the '' Seven
Jehovian Seals '' and the fact that the natural 12-Star Crystal Seals  in
Earth’s Planetary Shields have now begun to open  into severely damaged
Planetary Shields. The damage to Earth’s grids has already reached crisis
proportions, and the UIR intends to amplify this condition beyond repair by
2003.  
      Even in SACs that proceed smoothly , each time a natural Planetary
Star Crystal Seal activates, the frequencies it releases into Earth’s
Planetary Shields progressively exerts nucleic stress  within the
molecules of Earth’s tectonic plates. In areas of the planet where
Planetary Shield distortions  exist, the molecular structure of Earth’ s
plates experiences weakened resistance and less flexibility from this
nucleic stress. The climatic/weather patterns  in such areas become less
stable,  and the tectonic plates become vulnerable to seismic activity .
Each of the natural 12 Planetary Seals releases a progressively higher-
dimensional frequency spectrum  into Earth’ s Shields, thus exerting a
progressively increasing amount of nucleic stress within Earth’s tectonic
plates, which is difficult enough to contend with in areas of Planetary
Shields distortions without adding the unnatural “Seven Jehovian
Seals ” to the mess, which spells '' pending crisis ''—a crisis the Emerald
Covenant nations are presently trying desperately to avoid via remote
frequency transmission into Earth’s Planetary Shields. Without assistance
from Human and Indigo Children in “anchoring” these frequencies into
                 Earth’s Shields via Rainbow Roundtables (RRTs)  and Masters Planetary  
                       Merkaba Mechanics,  Guardian efforts to prevent this crisis would fail.        
                          427  
                                                                                                                                            

                       
                        
                          Conclusion— Earth Changes Potential
The unnatural Seven Jehovian Seals are a despicable atrocity of
technological ''achievement .'' 
      Since 10,500 BC, the implanted crystalline rods of the Jehovian Seals
have lain dormant in Earth’s crust and mantle like hidden “missiles,”
designed to progressively rip Earth’s Planetary Shields apart as Earth’s 12
natural Seals proceed through their opening cycle during the 2000-2017
SAC. Each Jehovian Seal “opens”  and begins activating its frequencies
in Earth's Templar when its corresponding Organic Seal enters its
activation cycle in response to Earth’s particle pulsation (vibration/
oscillation) rhythm. The chaotically arranged, unnatural frequencies of
the Jehovian Seal (the “rider” or “Horseman”) bond to the natural
frequencies transmitted by the Organic Star Crystal Seal (the “Horse”).
The “rider” frequency silently moves with the natural frequency current
into the Axiatonal and Ley Line (ALL) system  corresponding to the
Organic Seal, progressively reversing  the natural Angular-Rotation-of
Particle-Spin ( ARPS , the particle spin axis) within the frequencies of
electromagnetic energy moving through the ALLs. As the currents of
frequency moving through the ALL system progressively reverse to the
unnatural ARPS of the Phantom Matrix , the corresponding portions of
Earth’s Planetary Shields are drawn into electromagnetic bonding with
the D-7 Phantom Arcturus Planetary Shields. The first three Jehovian
Seals reverse the ARPS on the three ALL networks to which they
correspond. The related areas of Earth's Planetary Shields do not begin
ripping apart to bond with the Phantom Matrix until the opening of the
Fourth Jehovian Seal—the ''Pale Horseman .'' 
      Once a SAC has commenced, as the current SAC did on January 1,
2000,  Guardian nations cannot stop or prevent the natural Organic Seal, or
corresponding unnatural Jehovian Seven-Seal release sequences from
occurring. Manual interruption of these processes would cause absolute, rapid
pole shift and cataclysmic Earth Changes,  which Guardian nations can only
prevent by striving to balance the frequencies of the Organic Seals , while
clearing and realigning the chaotic frequencies  of the Jehovian Seals to a
natural “12-Code-Pulse .” The Organic and Jehovian Seal counterpart must
activate before 12-Code realignment can be achieved. Manual resetting of
the natural 12-Code-Pulse “Divine D-12 Pre-matter Blueprint” in Earth’s
ALL system is accomplished through running D-12 frequency ¹ into Earth’ s
Planetary Shields via RRTs conducted at specific times and locations.  
    When an Organic Seal releases, it takes anywhere from three to 12
months for its frequencies to spread through, and reach critical mass within,
the corresponding ALL network. As the Jehovian Seals’ chaotic frequencies
“ride on” the Organic Seal current, the effects of Jehovian Seal “opening”
also emerge and reach critical mass between three and 12 months  after the
Jehovian Seal has released. If the Jehovian Seals release and are not realigned
to a 12-Code-Pulse before reaching critical mass, climatic and/or tectonic
disturbances  will erupt within the geographical regions corresponding to the
Jehovian Seal’s placement. just as is the case with Earth’s 12 Organic Star
                          ___________________
                                1.     “Maharata Current”       
                               428                                                                                                          
                      
                         
           

                               
                          Climatic Disturbances and the Labor Day 2001 Sonic Pulse lnterference
Crystal Seals, each Seal in the Jehovian sequence progression is more
powerful than the one before; the Jehovian Seals 1, 2 and 3 create a lesser
degree of climatic/tectonic disturbance than Jehovian Seals 4 through 7 .
Planetary chaos begins  with release of Jehovian Seal-4 . if the frequencies of
Seal-4 and those before it are not manually realigned to a natural 12-Code-
Pulse as they run through Earth’s Templar.  
      Organic Star Crystal Seals 1 and 2 , and their corresponding unnatural
Jehovian Seals-1 and -2,2 activated in late May 2001 —the planetary effects
of Jehovian Seal-1 and -2 release will begin manifesting between August
2001 and May 2002 . The chaotic frequencies of Jehovian Seals 1 and 2 had
been converted to a  natural 12-Code-Pulse realignment  via RRT s
conducted in Kauai, Hawaii,  when the Seals released in May 2001. Organic
Seal-3 and its unnatural Jehovian Seal-3  counterpart3 activated in late July
2001—its chaotic frequencies had been converted  to a natural 12-Code-
Pulse via RRTs conducted in England  when the Seal released in July 2001.
Between August 15 and September 3, 2001 , the UIR fully activated the
Montauk-Phi-Ex-Falcon wormhole Port Interface Atlantian Pylon
Implant Network (APIN) system , launching the sub-space sonic-scalar
amplification pulse  that passed through the Star Gate-2 Gru-AL Point in
Sarasota, FL, on the evening of September 3, 2001, on its way to the
Bermuda Base (see page 408). On the evening of September 3, 2001, Organic
Star Crystal Seal-4  (which does not have a Jehovian Seal companion)
activated as we gathered at Sarasota Beach following our Labor Day
workshops to conduct an RRT to assist the GA in balancing the Organic
Seal-4 frequencies as they emerged. Just prior to our initiation of the RRT ,
the sonic amplification pulse,4 transmitted from “Cue Site-4" Central
Mexico via the Nibiruian Crystal Temple Network at Chihuahua, Mexico,
rumbled through the Gru-AL Point off the coast of Sarasota Beach.  
                              
                                 CLIMATIC DISTURBANCES  
      AND THE LABOR DAY 2001 SONIC PULSE INTERFERENCE    
  As Organic Seal-4 began to open, the UlRs contrived sonic pulse,
carrying a “ Phantom Pulse ” with reversed ARPS , ran through the Gru-AL
and through the Bio-energetic Fields of the RRT group.5 When the sonic
pulse intercepted the natural current emerging from Organic Seal-4, it
reversed the Seal-4 current to the Phantom Pulse ARPS . Reversal of the
stronger Organic Seal-4 current, instantly began to reactivate the reverse-
ARPS frequencies of Jehovian Seals 1, 2 and 3 that we had successfully
helped to realign to the 12-Code-Pulse during the May and July 2001 RRTs.
                         _____________________________
                            
                              2.    the ''White and Red Horsemen"
                                  3.    the ''Black Horseman"
                                  4.    later used in orchestrating the September 11, 2001, WTC/Pentagon Disaster
                        5.  My ex-husband and I allowed our bio-fields to be used as a “buffer blanket,” to
                                          protect the group from the intensity of this Psychotronic pulse. And I will tell you, this
                               chaotic sonic pulse was powerful; we are still recovering from some of the physical
                                       side effects we incurred from absorbing and transmuting these frequencies. Numerous
                                                      others within the group also reported the experience of “emotional body p urging" follow-
                                         ing the frequencies encountered on the beach that evening.
                          429                                                                                                                                                                                                        
                                                                                                                                        

                        Conclusion— Earth Changes Potential
Despite the terribly disruptive energies of the Psychotronic sonic pulse that
we experienced on the beach the night of September 3, the group managed
to pull itself together and run the RRT as planned. The  RRT was successful;
through this group effort the GA was able to anchor a sufficient amount of D-
12 and higher frequency to bring the Organic Seal-4 current back into its
natural ARPS.  
        By September 10, the September 3 RRT frequencies reached critical mass
in the Planetary Shields, returning the primary Organic Seal-4 frequencies
back to their natural 12-Code—Pulse. Jehovian Seals 1, 2 and 3  have, as of
this writing, partially reverted back to the 12-Code-Pulse clearing , but still
require some additional work before reaching their original state of 12-Code-
Pulse conversion. This means that at least mild climatic disturbance effects
from Jehovian Seals 1-3 are likely to occur between now and July 2002 . Our
groups will be working with the Emerald Covenant nations, running RRTs on
several occasions between October and November 2001 , to clear the
remaining disruptive frequencies now running through Earth’s grids from
Jehovian Seals 1-3.  
      Full clearing of the Jehovian Seals 1-2-3 frequencies must be
accomplished before the coming activation  of Organic Seal-8, with its
Jehovian Seal-4  companion,6 if ampli fied climatic/tectonic disturbances are
to be averted. Organic Seal-8/Jehovian Seal-4 will activate in early January
2002.7 Much to UIR irritation, We're still standin’,  with even greater
strength of spirit and personal resolve than before, despite their attempts at
Psychotronic antagonism of Emerald Covenant groups. It became quite
apparent, in reviewing the events of the evening of September 3, that the
Eieyani were quite serious when they had earlier that day explained that the
UIR was now taking aggressive steps  to rapidly advance their OWO agenda.
Just how aggressive these steps would be did not become apparent until the
morning of September 11, 2001.    
           When Jehovian Seals release, their frequencies can create disruptions for up to a 
1000-2000 mile perimeter s urrounding the Seal’s placement, while the greatest degree 
of climatic or tectonic disruption occurs in the location of the Seal and within 100-200 
miles  of its epicenter. The  Seven Jehovian Seals  are located at different horizontal Ley Line/
Latitude coordinates along the common vertical Axiatonal Line-7 at 70° 
W Longitude, which runs down the eastern Atlantic Ocean.  (See Star 
Gates and Seals Map Appendix-3).  
        Jehovian Seal-1,  the least powerful, is located NE of Quebec, Canada
at 70° W Longitude/47.08° N Latitude . Due to the May 2001 Jehovian
Seal-1 release, this region is likely to experience climatic disturbances or
intensification of natural weather patterns  between November 2001
and May 2002,  with January-February 2002 being the most vulnerable
periods.  
                Jehovian Seal-2,  also released in May 2001, is located where the
                 borders of Peru, Chile and Bolivia meet, at 70° W Longitude/18.1° S
                             _________________________
                              6.    “Pale Horseman”
                                 7.     Organic Seals 5, 6 and 7 will activate in late December 2001.
                              430                      
                  

   
                       
                          Climatic Disturbances and the Labor Day 2001 Sonic Pulse Interference
Latitude; due to Jehovian Seal-2 release, this area is vulnerable to seismic
activity,  especially between December 2001 and March 2002 . 
     Jehovian Seal-3 , released in July 2001, is located at 70° W
Longitude/41.78° N Latitude,  Cape Cod, MA. This area, and regions of
the US east coast , are vulnerable to aggravated storm activity,
particularly between December 2001 and June 2002 , due to Jehovian
Seal-3 release. Jehovian Seal-4 , the “Pale Horse with the rider named
Death,” will release in early January 2002,  as will Jehovian Seal-5.  
     Jehovian Seal-4 , the first of the more powerful Jehovian Seals, is
located east of Nassau Bahamas, at 70° W Longitude/24.92° N Latitude .
If Jehovian Seals 1-4 are not successfully converted to a 12-Code-Pulse
alignment within four months of the Seal’s January 2002 opening, cycles
of progressively more severe tropical storm and hurricane activity
(category 3-5) will emerge in the Atlantic Ocean. The Bahamas, Cuba ,
the east and west coasts of Florida and the Gulf of Mexico border lands
are primary regions to be affected by release of Jehovian Seal-4. Release of
Jehovian Seal-4 marks the beginning of the Jehovian Anunnaki and
Annu-Elohim opening of the “Cracks in the Wall in Time,” (see
page 386) through which geographical regions holding Dove APIN
system implants  will begin opening to the Phantom Matrix.  
      Jehovian Seal-5,  which activates two days following the opening of
Jehovian Seal-4 in January 2002, is located near Copiapo, Chile, at 70° W
Longitude/26.95° S Latitude . If Jehovian Seal-5 is not cleared to 12-Code-
Pulse realignment within four months of its January 2002 opening, this
region is vulnerable to several waves of seismic activity with progressively
increasing magnitude.  
        Jehovian Seal-6,  due to release in August or September 2002,  is located
at 70° W Longitude/ 10.36° N Latitude Venezuela . If we refer to the
Jehovian book of Revelations, the ''Sixth Seal" opening is foretold to bring
on a ''Great Earthquake''.... ''and every mountain and island was moved from
its place''.... Lets hope the Guardian’s 12-Code-Pulse realignments proceed
very well between now and then! 
      Jehovian Seal-7  is located at 70° W Longitude/ 33.13° N Latitude , off
the coast of Charleston, SC. If this Jehovian Seal is not realigned to a 12-
Code-Pulse, massive ﬂooding and category 5+ hurricane activity would
plague the eastern US seaboard, and most of Florida would rapidly become
an underwater Atlantian Theme Park . So much for ''merciful Jehovian
Gods''!  
        They have had all of this planned for us since 10,500 BC, but the '' Seven
   Seals' ' were only the intended beginning ; after the Seals come the “Seven
  Angels and Seven T rumpets '' (see page 414). These bring on ''hail and fire
mixed with blood,'' ''a blazing mountain being thrown into the sea turning
the sea to blood,'' the fall of Nibiruian Battlestar Wormwood on the Rivers of
 the Earth, followed by plagues, Beasts from the Pit and finally the intended                                
grand Jehovian Anunnaki invasion. These guys are real humanitarians!  
  The Indigo Children are the return of the Emerald Covenant Maji Grail
                  Line Eieyani/Humans who have incarnated into this time period to stand
                  with the Human races in prevention of all of the Fallen Angelics’  OWO
          dominion plans. Through loving use of the Founders’ Masters Planetary 
                        431    
                                                                                                                                                                     

                        Conclusion— Earth Changes Potential
Templar Mechanics, we can peacefully prevent ful fillment of the “Final
Conﬂict” drama, finally freeing Earth from over 12,000 years of Fallen
Angelic/Illuminati dominion. I hope we begin to wake up soon because the
“movie” has already started without us.  
      There are many more issues we need to understand in order to help 
ourselves, and our planet through these most important of times. If one has
courage, and wants to make a difference in how this messy “Final Conﬂict”
drama unfolds, if one cares to assist the Guardian nations in preventing
further advancement of the UIR Fallen Angelic invasion of Earth , the place
to begin is at home . Awakening the Inner Christos, your own personal, God-
given D-12 Avatar identity level, which has been long cruci fied upon the
cross of false Fallen Angelic indoctrination and DNA manipulation, waits
sleeping within each of us. The Maharic Shield Bio-Regenesis Techniques
(see page 496) begin the process of this Inner Awakening . If you are moved
to assist the Emerald Covenant Founders nations in the protection and
restoration of this planet, the Masters Templar Coursebook , 
provides instruction on the Sacred Arts/Sciences of
running the Signet (Star Gate) Rainbow Roundtables (RRTs). Through our
participation in ''running of the Rounds'' the Founders’ ancient '' Four Faces
of Man '' LPIN  and the “ Great White Lion ” and '' Golden Eagle '' APIN
grid-micro-chip implant systems can be reawakened to protect Earth from the
Fallen Angelic APIN systems that are now activating in Earth’s Planetary
Shields.  
       This ''Final Battle of the Angels" cannot be won through violent wars,
but victory can be achieved for all peace-loving nations through the
peaceful, Christiac Technologies of Masters Biotronic, Merkaba and
Planetary Templar Mechanics . The choice is ours, and in truth, time is
running out , as the UIR now aggressively advances its Illuminati OWO
dominion agenda in the 3-D arena. How many more atrocities like WW2
and the 9/11/2001 Terrorist Disaster, precursor to WW3, do we need to
see before  we ''get the message? '' 
       This book is by no means the end of the seemingly ''Never-Ending
Vo y a g e r s  S t o r y ' ' - i t  i s  o n l y  t h e  b e g i n n i n g .  B u t  i t  i s  a  m o s t  a p p r o p r i a t e ,  a s  w e l l
as deeply sincere beginning, particularly if one desires to awaken from the
perhaps blissful, but never-the-less amnesiac sleep of Fallen Angelic
manipulation. Each of us has the potential to emerge wide-eyed with wonder
into the new dawn of Human freedom as our Inner Light awakens, to lead our
 living spirits Upward,....Godward,....Home.  
    With light, love and heartfelt condolences to all who have suffered from
  the dreadful events of the 9/11/2001 WTC/Pentagon Terrorist Attack ....
                                          
                                                              May peace be with us all....
                                                                God bless us, everyone.
                                                           —Ashayana Deane, Ekr MC
                                                                    October 10, 2001
                           432
                  
                    

                                                                                                                                   
                                                                                                                                                    Epilog
                                                                                      EPILOG
 
Since the September 12, 2000 United Intruder Resistance (UIR) Edict of
War, Emerald Covenant races have provided us with massive amounts of
data  from the CDT-PLATES,  covering the Hidden Realities of History and
the Mechanics of Running the '' Rainbow Roundtables .'' There is a  Mission
that must be accomplished before 2003 if humanity expects to continue in
peaceful evolution; it is a Mission of Star Gate realignment and disengage-
ment  of the Nibiruian Diodic Crystal Grid  and its 24 Crystal Temple Net-
work Underground Control Bases.  This Mission is called today , as it was
during the times of Jesheua, King Arthur and the Catheri, the Christos  Rec-
lamation Mission . We will do our best to make greater amounts of informa-
tion available to all in the months to come. If you are interested in learning
about Signet Rainbow Round Tables , or other GA programs,
such as DNA Bio-Regenesis Technologies, the Kathara Bio-Spiritual Heal-
ing System  or the T angible Structure of the Soul Accelerated Bio-Spiritual
Evolution Program,  please contact us at the address below:  
                                                               
                                                                  ARhAyas Productions LLC   
                                                                         5020 Clark Rd #307   
                                                                                  Sarasota  
                                                                                  FL 34233  
                                                                  Email: office@arhayas.com
                                                                      Phone: 941-924-8109
                                                                        or visit our website       
                                                       http://www.arhayas.com
                                                                                                                               
                        433

                                         
                                                                          Appendix I
                                                                                 
                                                                                                              
                              Data Summaries and
             At-A-Glance Blow-Up Charts