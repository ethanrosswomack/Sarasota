Chapter 12) that corresponds to the coordinates 
of the Universal Star Gate-12 planet Lyra, Aramatena .  
     In the Founders  plan of creating the D-12 Christos Realignment  within 
the four Densities of the Manifestation Templates of Earth, Tara and Gaia 
and their surrounding galaxies , Universal Star Gate-12  holds the final key
278 
         

                                                                                                    
           The Riddle of the “Roundtable’’
to planetary and galactic Christos Realignment . Through Universal Star
Gate-12, the  D-12 ''Christos Templat''  frequencies can be run through the 
planetary bodies in a galaxy, to  reset  the original natural Pre-matter Tem-
plate , or “Divine Blueprint ”, upon which the galaxy and its planets first
manifested. The Mu’a races  of the Palaidia Empires were designated as 12th 
Gate Universal Guardians , and so they were settled in geographical loca-
tions  of Earth that corresponded to Earth’s activation and opening sites of 
the Universal Star Gate-12  Lyra-Aramatena  Gate. The Mu’a race lines
were incarnate members of the GA’s D-12 Council of Lyra-Aramatena.  
     The Mu’a races held the Universal Signet Key and Encryption Key
  Codes  to all 12 Universal, Galactic and Planetary Star Gates  within  their 
DNA Templates. The Mu’a races were thus settled in locations correspond-
ing to Earth’s  Star Gate-12 , and also in locations corresponding to other
Star Gates  of Earth’ s T emplar that were in most need of additional security .
The Yu races  of the Palaidia Empires carried the Universal Master Key and 
Encryption Key Codes  to Universal, Galactic and Planetary Star Gates  2 
through 11  in their 37-42 Strand DNA Templates .  Universal Star Gate-
11 is the Density-4, D-11  Pre-matter  gate corresponding to Aveyon, Lyra ,
the second most powerful Star Gate  in the Universal Templar . Members of 
the Yu race  are incarnates of the GA ’ s D-11 Council of A veyon , the desig-
nated 11th  Gate Universal Guardians , and thus Yu races were settled in geo-
graphical locations corresponding to Earth’s Star Gate-11  activation and 
opening points. The Yu races were also settled in other gate areas correspond-
ing to Star Gates 2 through 11 , that were in need of additional security. The 
Ur (Urta) races of the Palaidia Empires carried the Universal Master Key 
and Encryption Codes  corresponding to Universal Star Gates 5 through 8  
in their 31-36 Strand DNA Templates , and were thus 8th Gate Universal 
Guardians. The Ur races  are incarnate members of the GA ’ s D-8 Council of
Mintaka-Orion, and were settled in areas of Earth that corresponded to Uni-
versal Star Gate-8 and in areas corresponding to Star Gates 5 through 8  that 
were in need of additional security.    
     The most powerful Universal Star Gates  in relation to the operations of
planetary, Galactic and Universal systems in our Time Matrix, and thus those 
most vulnerable to incursion by Fallen Angelic infiltration , are the D-12
Aramatena-Lyra , D-11 Aveyon-Lyra , D-10 Vega-Lyra  and D-8 Mintaka-
Orion Gates . In addition to these main Universal Star Gates, Universal Star 
Gates 1, 2 and 5 are also points of vulnerability. Star Gates 1, 2, 5, 8, 11 and 
12 are “Control Gates ” in the Universal Templar; they are the “ Gates of
the Middle Pillar ”, a reality that will be further explained shortly. Races such 
as the Mu, Yu and Ur, Breanoua and Rama races of the Palaidia Empires, who 
carry Universal Templar Security  commissions, are always settled in the 
geographical locations of Earth that correspond to the Star Gates  to which 
their DNA Temples are encoded . They are also assigned to Control Gate  
areas that are in need of additional security . The seedings of the Angelic 
279 
                                                                                                           
 

                                                                                                                                                   
    The Angelic Human Heritage and Rainbow Roundtables                            
Human races of Earth were never random  occurrences , nor were the hubs of 
human settlements determined by general environmental factors , such as 
proximity to water and natural food supply. Though environmental factors 
affiliated with the “hierarchy of needs” for human survival are an influence  in 
regard to human settlement on Earth, it is the location of the Star Gates of 
Earth’s Templar  that have always governed every human seeding and reset-
tlement.  The significance of understanding the DNA Template Star Gate 
Correlations  between the “ancient” Palaidoria Races is not only  in that 
through doing so we can identify the core geographical regions from which
  human civilization emerged .  The greatest importance  in understanding the 
DNA Template Star Gate Correlation  lies in that through this realization 
we can begin to understand the personal and collective roles  that contempo-
rary humans  play in relation to the Founders Christos Realignment Mis-
sion.  We can also begin to realize why the true history of our evolution on 
Earth has been saturated with attempts of Fallen Angelic  infiltration and 
intended dominion.   
    The ancient Urtite-Tri and Bi-Cloister Races  that seeded the Palaidia 
Empires of 798,000 BC  represent the  genetic heritage  from which contem-
porary humanity  emerged. The emergence of contemporary humanity was
not an accidental occurrence  that randomly emerged from this previously
organized  Palaidia Empire plan.  The evolution of contemporary humanity 
has always been an intrinsic part of the Palaidia Empire Emerald Covenant 
agenda; humans of the present time  are as much a part of the Founders 
intended Planetary Christos Realignment Mission  as are the Palaidia races 
of ancient times. What was not an intended part of the Palaidia Angelic 
Human Divine Evolution plan  was the degree to which Fallen Angelic infil-
tration, and resulting DNA Template  and consciousness mutation, has pro-
gressively occurred within humanity’s evolution on Earth. Humanity’s
current state of amnesia  regarding its Angelic Heritage, and subsequent   
neglect of its intended Divine Commission  as the force through which 
Planetary Christos Realignment would occur, was not part  of the Founders
plan. This digression of human biology and consciousness was, however , pre-
cisely the intention of Fallen Angelic races , who understood that the 
Angelic  Humans of Earth were a primary obstacle to fulfillment of their
plan  to take over the Universal Templar Complex  in this Time Matrix. 
The human evolutionary design of 12-Tribes Seeding-3 began with the five 
Urtite-Cloister Maji races  that seeded the first 12 Palaidia Empires  in 
regions corresponding to Earth’s 12 Primary Star Gates, but this plan did not
stop with the Palaidia Empire races.   
                     280
                 
                                          

                                                                                                                                                      
                                                               The Riddle of the “Roundtable’’  
                              Cycle of the Rounds, the Divine Blueprint of Human Evolution,                                                                Christos Realignment Mission    
       The Evolutionary Divine Blueprint  of human evolution on Earth was 
designed to accomplish the Founders Planetary Christos Realignment  
through a series of races cycles  called rounds .  Each Round  of human race 
settlement was intended to progressively bring in a cycle of frequencies  from 
the Universal Christos Template , the Shield of Aramatena. The Manifesta-
tion Templates of the Earth-Tara-Gaia body cannot be fully corrected to the
Christos Blueprint all at one time. Manifestation Templates are scalar-stand-
ing-wave grids of interdimensional light and sound frequencies upon which 
the planetary molecular base  builds up into manifestation. The molecular 
structure  of the planetary body must progressively expand to hold the  
greater amounts of interdimensional energy  that will infuse into the Plane-
tary Manifestation Template through the Christos Realignment.  If too much 
frequency is fed into the Planetary Template too rapidly, the physical struc-
ture of atoms, molecules and sub-atomic particles will be unable to alter their
natural vibration rhythm  fast enough to keep up with Template accelera-
tion. If an excessive amount of D-12 frequency from the D-12 Shield of Ara-
matena Universal Christos Blueprint was brought into the Planetary 
Manifestation Templates of the Earth-Tara-Gaia system at one time, the
planetary body would literally explode . The Founders designed the human
evolutionary plan with full understanding of these basic principles of Unified 
Field Physics  and Primal Order Creation Mechanics. The Palaidia Urtite-
Cloister Maji races, as bearers of the greatest amount of frequency  through 
their DNA Templates, were seeded first.  The Palaidia Urtite-Cloister Maji 
presence served to regulate the progressive flow of D-12 frequency into the 
Planetary Shields  of Earth’ s Manifestation T emplate and to set the Core 
Template or “Kathara Grid”  of the D-12 Shield of Aramatena within the
Planetary Shields of Earth-Tara-Gaia. Next, a series of evolutionary Rounds 
would take place , by which Angelic Human races with less sophisticated 
DNA Templates,  and thus less frequency transmission capacity , 
would sequentially cycle  on Earth, to slowly and progressively increase  the 
amount of frequency brought into Earth’s Planetary Shields from the D-12 
Shield of Aramatena.   
     The Cycle of the Rounds  was intended to work in the following manner: 
The Seed Races with the highest DNA Template frequency transmission 
capacity were brought in first to anchor the Kathara Grid Template of the
Shield of Aramatena  into Earth’s Planetary Shields. The energy naturally 
transduced through their accelerated DNA Templates was progressively 
received, stored and released in increments into Earth’s Planetary Shields
through the 12 Selenite Rods in the Crystal Pylon Temples of Inner Earth.  
When Earth entered a natural Planetary Stellar Activations Cycle (SAC),  
the Maji Races would hold the natural configuration of the D-12 Shield of  
281
                                                                                                               
  

The Angelic Human Heritage and Rainbow Roundtables                            
Aramatena  on the planet, serving as a temporary D-12 Christos Grid  
within the Planetary Shields. Through the Temporary D-12 Christos Grid  
formed on Earth by the presence of the  Maji Races,  a quantity of D-12 fre-
quency could be re-introduced into Earth’s Planetary Shields during every 
natural SAC . Through this progressive re-introduction of D-12 frequency 
into Earth’s Planetary Shields, the portions of Earth’s Axiatonal Line and
Ley Line systems  that had been damaged in the 549,998,000 BC cata-
clysm of Tara  (see Page 2), could be progressively realigned  with the Shield 
of Aramatena Christos Blueprint. The physical bodies of the Maji Races  
served as literal conduits of electromagnetic energy,  through which the D-
12 Shield of Aramatena frequencies  could be held on planet  for progressive 
planetary grid repair , until Earth’s grids were repaired sufficiently to hold 
the natural, permanent D-12 Christos Realignment . Originally , all species 
on Earth  were seeded to serve as conduits of frequency  through which the 
Founders  D-12 Christos Realignment could be progressively fulfilled in the 
Earth-Tara-Gaia system.  The damage Earth’s grids incurred through the 
Taran cataclysm made Earth’s Templar Complex  unable to naturally with-
stand participation in a SAC . The Earth-Tara-Gaia system would have 
been a Phantom Planet system  (see page 166), if it had not been for the
Founders’ inplementation of the Angelic Human mission .  Humanity, and 
other species, were seeded on Earth to form a sustaining energetic template  
through  which progressive D-12 Christos Realignment and repair of
Earth’s Planetary Shields  could be rendered over several cycles  of the
 planet’s evolution within the Density-1 Time Cycle .  
     The design of the Cycle of the Rounds began with seeding of the Palaidia 
Urtite-Cloister Maji Races  and was then to continue with progressive 
emergence of races  that carried smaller portions  of the Maji’ s DNA  T em-
plate.  Each race with less sophisticated DNA Templates  served to bring in 
and hold in Earth’s Planetary Shields, specific cycles of  sub-frequency from 
the Shield of Aramatena, during points in the planetary Time Cycle when 
those specific sub-frequencies were needed to amplify and  “fill out the fre-
quencies”, in Earth’s Manifestation Template. In the Cycle of the Rounds 
design, races with greater  genetic sophistication serve to hold in Earth’s Plan-
etary Shields, the 12 Primary  Dimensional Templates of the Shield of Ara-
matena Christos Divine Blueprint.  Races with less genetic  sophistication 
serve to hold additional sub-harmonics of the 144 Secondary Dimensional
Sub-frequency Templates of the Christos Blueprint.  Once they were fully 
seeded and in position within various interrelated Time Cycles of Earth, Tara
and Gaia, the Angelic Human races were intended to hold and direct, within     
the Earth-Tara-Gaia Template, the greatest portions of the D-12 Shield of 
Aramatena Christos Blueprint frequency spectra.   
     The animal, plant,  insect and mineral kingdoms of Earth-Tara-Gaia were
 intended to hold the subharmonics of  the Christos Blueprint. Together , the 
 Angelic  Human  Races and   the  natural  kingdoms of  Earth-Tara-Gaia would
282 

                                                                                            
                                                                                         The Riddle of the “Roundtable’’
bring in and sustain the D-12 Christos Blueprint , progressively healing dis-
tortions in the Earth-Tara-Gaia Planetary Shields to fulfill the natural Chris-
tos Realignment of the Earth-Tara-Gaia systems. As each cycle of human 
race evolution entered  manifestation on Earth, more of the Christos Tem-
plate would be progressively anchored and  integrated into Earth’s Manifesta-
tion Template. When the Cycle of the Rounds was completed, and all 
portions of the 12-Tribes Angelic Human races were in position on planet, a 
final Stellar Activations Cycle  would allow the Angelic Human races to fully 
anchor the D -12 Planetary Christos  Blueprint in Earth’s Template. In com-
pletion of the Angelic Human Mission, the D-12  Maharic Shield of Aramat-
ena Planetary Christos Blueprint would be simultaneously  anchored in 
various interrelated Time Vectors and Time Cycles of Earth-Tara-Gaia. At 
this time, the Planetary Shields would fully realign to their natural D-12 
order, allowing the planet to self-sustain a permanent, natural D-12 Christos 
Alignment.   
    When the full frequency spectrum of the D-12 Shield of Aramatena  
Template Christos Blueprint  is anchored in Earth’s Template “at one time”, 
during a Stellar Activation Cycle when the natural planetary, galactic and 
universal Star Gates open, the Earth-Tara-Gaia Planetary Shields can hold 
the full D-12 Maharata Creation Current. Anchoring of the full D-12 spec-
trum of the Universal Maharata Current, or Pre-matter “Christos Current” 
(also sometimes referred to as the “Photon Belt” or “Holographic Beam”), 
would place the planet within its naturally intended Planetary Maharic Seal. 
    Manual stimulation  of the natural  Planetary Maharic  Seal in numerous 
 concurrent Time Cycles  will allow the planet to  regenerate  its natural ability
 to self-sustain a permanent D-12 Planetary Christos  Alignment.  Restoration 
of the planet’s natural Christos Alignment will  re-establish  the “Divine Right  
Order” of the planet’s original galactic position and Universal Time Cycle 
Alignment.  Under a planetary D-12 Maharic Seal, the four Densities of the 
Earth-Tara-Gaia system can fully re-connect to the Universal Manifestation
Template of our Time Matrix. Rehabilitation of the Earth-Tara-Gaia Plane-
tary Shields through the Christos Realignment will allow the four Densities 
    of the planetary system to re-connect to the Density-5 Kee-Ra-ShA  Primal 
    Light Fields and the Khundaray Primal Sound Fields beyond the Time  
    Matrix. Through this “Divine Connection”, the Planetary Shields of Earth- 
    T ara-Gaia can receive perpetual circulation  of the “Rainbow Ray” Primal 
                Creation Currents from Source. Once the natural Density-4, D-12 Planetary 
                Maharic Shield is restored on Earth, Density-3 Gaia, Density-2 Tara and 
   Density-1 Earth will be restored to the status of Ascension Planets  (see 
   Page 167), their inherent life-fields capable of attaining full Ascension  out of 
    the Time Matrix.   
       Until the Christos Realignment of Earth is completed, most of Earth’ s 
life-field is trapped in time within the finite experience of Density manifesta-
tion, unable to enjoy the Divinely Given Gift of self-motivated  Ascension
283 
                                                                                                                                                                                  

The Angelic Human Heritage and Rainbow Roundtables                            
 and its inherent perpetual renewal of Eternal Life and co-creative life experi-
ence. The Angelic Human lineage of Earth was seeded as an intrinsic part of 
a Divinely Intended  Mission of Planetary, Galactic and Universal Rehabilita-
tion.  This mission was highly organized, beautifully choreographed and 
intrinsically synchronized through the natural cycles of Time in our Time 
Matrix. Time  Cycles are repeating cycles of vibrational  variance inherent to 
the Primal Order of the Unified Field of consciousness and energy that IS our 
Time Matrix. Time Cycles govern the Primal Creation Mechanics, or the 
organic physics of manifestation, by which consciousness experiences the 
worlds of space-time-matter. The design of the Cycle of the Rounds, by
which humanity’s evolution on Earth serves the higher purpose of Universal 
Rehabilitation, is built upon the natural contours of Cycles of Universal 
Time. Each phase of humanity’s evolution on Earth, including contemporary 
human civilization,  is an  intrinsic and necessary part  of this greater Univer-
sal Rehabilitation and Restoration plan.   
FOUR EVOLUTIONARY ROUNDS, CO-RESONANT CONTINUUM 
ALIGNMENT, TRANS-TIME CONNECTION, AND THE CHRISTOS 
                                      REALIGNMENT MISSION  
     The five Urtite-Cloister Maji races that first seeded the Palaidia Empires
of 798,000 BC began the current Cycle of the Rounds  on Earth. The Urtite-
Cloister Mu’a, Yu, Ur, Breanoua and Rama races, each with their respective 
DNA Template Star Gate Correlations, are the seed races from which con-
temporary humanity emerged. Through this ancestral genetic affiliation , the 
humans of contemporary Earth  also hold the DNA  T emplate Star Gate
Correlations inherited through the particular Palaidia Empire race  from 
which their original genetic ancestry emerged. Though we have presently 
lost memory of our greater purpose  within the Planetary Christos Realign-
ment Mission , our current human races are as important as the Palaidia 
Empire races, in fulfillment of the Founders’ Planetary, Galactic and Univer-
sal Rehabilitation plan.   
  The Cycle of the Rounds , through which human evolution was
intended to bring about the Christos Realignment on Earth within a specific 
quadrant of time, is designed to occur in four phases, or four Rounds . The 
First Round  of Seeding-3  Human evolution took place with seeding of the
five 25-48 Strand DNA Template  Palaidia Urtite-Cloister Maji races  of 
the subterranean Palaidia Empires in 798,000 BC , and their subsequent 
emergence onto Earth’s surface between 750,000 BC and 500,000 BC . 
    The Second Round  took place as the five 12-24 Strand DNA Template
Urtite-Cloister Races  emerged in 206,000 BC  from the five Palaidia Urtite-
Cloister Maji races into the 12 Urtite-Cloister Palaidia Empires, and spread 
across Earth’s surface  into areas to which their DNA  T emplates corre-
sponded. The races of Human Evolution Rounds 1 and 2  carried the 12      
284                                                                                                                  
    

                                                                                                  
                                                         Four Evolutionary Rounds, Co-Resonant Continuum...
Universal Master Key Codes  and 144 Universal Encryption Key Codes
of the 12 Universal Star Gates within their DNA Templates ; they anchored
the 12 Primary Dimensional Templates of the D-12 Shield of Aramatena  
within Earth’s Planetary Shields. The Second Round was delayed from its 
originally intended schedule due to warring with Fallen Angelic races  and a 
resulting planetary cataclysm in 208,216 BC . The Third Round  of Angelic
Human evolution took place in 73,000 BC  as the five 7-12 + 1 Strand 
DNA Template  Cloister Races  emerged through the five Urtite-Cloister 
races, carrying sub-harmonics of the specific DNA Template Star Gate Cor-
relations characteristic to the specific Urtite-Cloister Race from which they 
emerged. The Fourth Round  of Angelic Human evolution began shortly        
thereafter, as the five Root Races  with  2-6 Strand + dormant 12-Strand          
DNA Templates  began their progressive emergence into human incarnation in 
71,000 BC , through their corresponding Cloister  race of the five Cloister    
Races  (see page 15).         
    Each of the four Rounds of the Human Evolutionary Blueprint is  
designed to bring into Earth’s Planetary Shields during specific Time Vectors 
a designated portion of the D-12 Shield of Aramatena Christos Template. If 
the Cycle of the Rounds had proceeded without progressive Fallen Angelic
interference, the four Rounds of the Angelic Human lineage would have fully
anchored the D-12 Shield of Aramatena and completed the Christos 
Realignment Mission on Earth long ago. The Fourth Round  of Angelic  
Human evolution is still in progress  from a present-day earthly stand-point , 
as two of the five Root Races  and one of the five Cloister Races  have not
yet entered their birthing cycles on contemporary Earth. In truth, these  
“not yet manifested” Fourth-Round Angelic Human race strains already
exist and are evolving  within higher frequency Density-2 Time Vectors  of 
Earth, that represent a “ future time ” Time Cycle of Density-2  Tara  in rela-
tion to the position of races in contemporary 21st Century Density-1  Earth.   
In the same fashion, the evolutionary Rounds of the Palaidia Urtite-Clois-
ter, Urtite-Cloister, Cloister  and “ earlier ” Root Races  are also occurring
concurrently  with contemporary human evolution, in both higher and 
   lower-frequency Density-1 Time Vectors  of Earth.   
       The design of the Cycle of the Rounds Angelic Human  Evolutionary 
Blueprint re ﬂects the reality of physics  upon which space-time-matter mani-
festation is built ; time is simultaneous . Time Cycles  represent repeating 
cycles of vibrational variance ensconced  within the energetic platform of 
the Unified Field  of consciousness and energy that is the medium within 
which all manifest creation takes place. The repeating cycles of vibrational
variance that form Time Cycles and their inherent smaller Time Vector
cycles , provide coherent sequences of linear vibrational rhythms for con-
sciousness to follow  in order to engage the manifest experience of linear pas-
sage and evolution through time.    
285 
                                                                                                                    
                                                                                                        

 
      The Angelic Human Heritage and Rainbow Roundtables                            
       The Cycle of the Rounds Human Evolution- Christos Realignment Mis-
sion is being fulfilled through the Four Rounds  of Angelic Human Races,
the collective carriers  of the  D-12 Shield of Aramatena  Christos Divine 
Blueprint, being simultaneously seeded in various Time Vectors  of the Earth-
Tara-Gaia Universal Time Cycle .  Through this concurrent, simultaneous
seeding of the Four Rounds, portions of the Christos Blueprint  are simulta-
neously entered  by their designated races , into the four Densities  of the 
Planetary Shields , in their appropriate Time Cycle and energetic coordinate
 of corresponding vibrational co-resonance .  
     The seemingly complex inter-dimensional, inter-time reality of human 
evolutionary design  can be simply understood by viewing each of the four 
Rounds of Angelic Human Seeding-3 as taking place right now , in space-
time vectors connected to but different from  our Earth’s contemporary Time 
Vector. In our Time Vector, Earth has begun the 2000-2017 Stellar Activa-
tions Cycle (SAC) , through which the Earth’s Templar and Star Gates will 
activate.  Activation of Earth’s Templar in the present SAC is progressively
creating a temporary blending of Time Vectors  between the past, present 
and future Time Vectors in which the other Rounds  of the Christos Realign-
ment are concurrently taking place.   
     If contemporary humanity fulfills its intended role as part of the
 Christos Realignment Mission T eam,  by consciously anchoring our portion
of the D-12 Shield of Aramatena Christos Field in our Time Vector, the suc-
cess of the Christos Realignment can be finally achieved. If we do our part, 
we will create a link through time , energetically connecting our present 
Time Vector  to the past and future Time Vectors  in which the other evolu-
tionary Rounds are being successfully orchestrated .  
     Through this Trans-time Connection , our  present Time Vector  will 
“phase-lock”, or lock into alignment with, the probable future Time Vector  
and its corresponding past Time Vectors , in which the Christos Realign-
ment, the Emerald Covenant Lyran-Sirian cultural model and humanity’s 
successful evolution into 12-Strand Angelic Human freedom  are already
manifest . Through doing our part now, we will choose from the present , the 
desired probable future  (from our present standpoint) our race will see man-
ifest. In choosing from the present, the path of an enlightened future and 
“Destiny of Joy” , we will simultaneously re-align our present Time Vector 
with a  more desirable set of past Time Vectors , in which undesirable past 
events will lose their power and in ﬂuence within our experientially manifest 
present and future.  
    In the realities of the Mechanics of Manifestation , the “ point of power 
is always in the present ”. Past and future Time Vectors extend out from 
every present moment point  as a series of electromagnetic “rays”, or inter-
connected, cyclic patterns of linear progression with varying rhythms of 
vibrational oscillation .  A Time Cycle, and its inherent Time Continua and
smaller Time Vectors are all fixed, repeating cycles of frequency character-
286 
                                                                         
 
 
                                                                                                                            

                                                                  
                                  Four Evolutionary Rounds, Co-Resonant Continuum
  ized  by vibrational variance , that cross through each other  at fixed points 
when the frequency rhythms that define each cycle reach a temporary state of 
vibrational co-resonance  (hold the same vibration). Our present moment 
point  emerges as one small point  of vibration-oscillation rhythm within the
greater rhythm  of the Time V ector, Continuum and Cycle within which it is
placed. When our planet enters a point in its fixed linear Time Vector at 
which other Time Vectors cross through our Time Vector, via temporary 
vibrational co-resonance , we have the  power to literally shift our present 
Time Vector  alignment into an alternate linear Time Vecto r with a different
future “ event horizon ”.  
     If our present moment point exists as part of a linear Time Vector cycle in
which undesirable “past” events , serving as the “cause”, have their recipro-
cal “effect” manifestation in an undesirable “future” event horizon , we can 
change our direction from the present by changing our present vibrational 
rhythm.  The present moment  is the “ Cause ”; the past  (lower frequency 
projection) and future  (higher  frequency projection) are the “ effects”  that 
extend backward and forward in time (simultaneously  emerge into lower 
and higher frequency projection) from the frequency pattern and vibrational
 rhythm that defines the present moment point.   
    From the present moment we CAN change the influence of the past , as
well as re-define the future. The past is not changed by negating memory  of 
its reality or by invalidating its apparent manifest existence . The “past”, pro-
jected from one present frequency pattern, must be acknowledged and incor-
porated as part of the present frequency pattern (“past” brought into the
present moment of power). Once the remembered and evidential past  is 
incorporated into the present moment , the entire frequency pattern in the
present  needs to be altered into vibrational co-resonance  with the frequency 
pattern of the desired future manifestation.   
    There are many complex elements to mastering the skill of projecting
desired outcomes into our personal experiential future. Though each individ-
ual does possess the inherent power to create desired manifest experience , 
this personal power  is always tempered and directly influenced  by the larger 
frequency-field  of  the Collective Consciousness. In like fashion, the mani-
festation powers  of both the personal and collective consciousness  are 
directly regulated and influenced by the frequency-field of the Planetary 
Time Continuum  within which personal and collective reality take place.
The frequency field that constitutes the Planetary Time Continuum  is cre-
ated by numerous concurrent Time Vectors and the collective consciousness  
of all manifest kingdoms, from the elemental, plant and animal  kingdoms , to
the human evolutionary collectives , that exist within each Time Vector.  It is 
due to these greater hidden influences  of  the Planetary Time Continuum , 
which operate through the collective sub-conscious  and DNA Templates  of 
incarnate species, that our individual efforts  to achieve precise results in 
287 
                                                                                                              
 
                                                                                                             

The Angelic Human Heritage and Rainbow Roundtables                            
direct manifestation  of desired events often fall short  of our conscious 
expectations.  
    Shifting a present-moment  Time Vector  into a different Time Contin-
uum  that has a more desirable future outcome  than that of the Time Con-
tinuum of which our present Time Vector is a part,  can be achieved from the 
present. But such a Time Continuum shift  can be accomplished only within 
the natural mechanics of physics  that govern the interdependant dynamics
of race, planetary, galactic and universal Time Cycles . One cannot simply 
choose to shift to a different Time Continuum at any moment-point in time ; 
Time Continuum shifts can be made only in present-moment points within
 which other Time Continua interface  with the present-moment Time V ec-
tor through vibrational co-resonance . 
    This principle of “ Co-resonant Continuum Alignment”  applies to the 
smaller time cycles that govern evolution of an individual through one life-
time, and also to the larger Planetary Time Cycles  that govern a planet’ s 
evolution through the Density Levels of our 15-Dimensional Time Matrix. 
Stellar Activations Cycles  (SACs) are points of planetary , galactic and uni-
versal “ Co-resonant Continuum Alignment ” during  which the divergent 
frequency rhythms characteristic to various planetary, galactic and universal 
Time Continua temporarily come into a state of vibrational co-resonance 
(simultaneously reach the same vibration-oscillation rhythm).  
    Points of temporary vibrational co-resonance that naturally occur 
between various Time Continua allow the usually separated Time Continua  
of various systems to cross through and open into each other . Star Gates
represent the geographical and spatial coordinates  at which the vibrational 
co-resonance of multiple Time Continua regularly occurs in fixed, repeating 
cycles  of Co-resonant Continuum Alignment.  At points in a Time Contin-
uum where Co-resonant Vibrational Alignments occur, natural  Star Gates 
open  in the spatial coordinates  that mark the points of vibrational co-reso-
nance  or continuum cross-through.  Star Gates remain open until the vibra-
tional rhythms of the various interfacing Time Continua at the Star Gate
points begin to cycle out of vibrational co-resonance , shifting  the various 
Time Continua out of Co-resonant Continuum Alignment.  Star Gate 
close  as the various Time Continua  move past their vibrationally co-reso-
nant “cross-over” points , and return to their respective fixed, repeating
cycles of vibrational variance. SACs are the periods in linear time when
planetary, galactic and universal Time Continua enter temporary Co-reso-
nant Continuum Alignment; only during SACs can a planetary body be 
shifted from its present Time Vector into a Time Continuum that holds a
 more desirable future outcome.  
    If contemporary humanity can fulfill its intended Fourth Round role  
within the Christos Realignment Mission  during the 2000-2017 SAC , we 
will be able to establish a literal, inter-dimensional electromagnetic Trans-
Time Connection  from our present period, to the SACs taking place in 
288 
                                                                                                                                                       

                          Four Evolutionary Rounds, Co-Resonant Continuum ...
other periods of past and future. In fulfilling our Divinely Intended Mission 
in the present, we will  link Earth’s present Time Vector  to those of SAC’s 
past and future during which the Angelic Human races of the other three 
Evolutionary Rounds  are also fulfilling their Divine Mission of anchoring 
the D-12 Shield of Aramatena Christos Blueprint.  In this way we will put 
Earth’s present Time Vector “on line”  with the probable (to us) future  in 
which the Christos Realignment has successfully occurred.  
    Through aligning Earth’ s present Time V ector with future Time Contin-
uum cycles in which the Christos Realignment is successful, we can shift 
our present planetary Time Vector out of its current probable future of Fallen 
Angelic- Illuminati Human dominion. We can literally realign the event
horizon  upon which our present is moving into the future with the Time Continuum 
event horizon in which our probable future of Freedom and Joy is manifest. The 
concept of Time Shift is simple, but the dynamics of interdimensional physics by 
which a Planetary Time Continuum Shift can tangibly occur are extremely complex ; far 
beyond the sophistication of present earthly science. Though the physics of Planetary 
Time Shift are complex, the methods by which humanity can fulfill its intended 
Fourth Round role in anchoring the frequencies of the D-12 Shield of Aramatena 
Christos Divine Blueprint are, thankfully, relatively simple . The methods by which 
humanity can fulfill its intended Sacred Mission can be found within the Secrets of the
Tribal Shield Rainbow Roundtables.     
        
                            
                                                                 Key   to   Following    Diagram:
The Angelic Human Race was created as the Security Team  for the
Templar Complex Star Gate System  in our Time Matrix. The DNA  
Templates of each Race Line carry portions of the DNA Signet
Codes , or Fire Letter Sequences,  that correspond to the 12 Primary 
Star Gates  on the Regional, Planetary, Galactic  and Universal  Lev-
els. The DNA Signet Codes are “ Flame Codes ,” denoting the spe-
cific primary frequency spectra  of the three Primal Creation  
Currents (Blue-Eckatic, Gold-Polaric, Violet-Triadic) carried in 
the DNA Template.     
       
289

                                                   
                                            
                                                                       The “Cycle of the Rounds”
                                    THE “CYCLE OF THE ROUNDS”           
     The four Interrelated Evolutionary Cycles of 12-Tribes Seeding-3
                                       EVOLUTIONARY ROUNDS  
    • The Seeding-3 12-Tribes Angelic Human Races were seeded on Earth in
         four different interconnected Time Cycles . Each of the four Time Cycle s
        in which the Angelic Human races were seeded represents an evolution-
        ary Race Cycle  or an “Evolutionary Round”  in the “Cycle of the 
            Rounds” Angelic Human  Evolutionary Blueprint.  
  • Each of the four Rounds  in the Angelic Human “Cycle of the Rounds” is
          commissioned to “Anchor” a specific set of interdimensional frequencies
         into Earth’ s scalar-standing-wave Manifestation T emplate, Earth’ s Plane-
          tary Shields , within each of the specific Time Cycles  in which the Angelic
               Human Evolutionary “Round Cycles” are placed. Each Evolutionary
         Round is intended to serve a part in fulfilling humanity’s Divine Commis-
          sion, the Sacred Mission of Planetary Guardianship  for which Angelic
            Humans were seeded on Earth.                                                                                FIRE LETTER SEQUENCES  
  • The Angelic Human and Maji Cloister Races of each Evolutionary Round
      anchor frequency into Earth’ s Planetary Shields through the scalar-stand-
      ing-wave structures that are an inherent part of the personal DNA Tem-
       plate Core. The DNA Templates of the Angelic Human Races within
       each Evolutionary Round Cycle are built upon specific  scalar-standing
         wave Light-Sound patterns called Fire Letter Sequences.   
    • The Manifestation Templates  of all things and systems are built upon spe-
      cific, fixed organizations of dimensionalized frequency bands . Each di-
        mensional band has 12 Fire Letters, or fixed points of consolidated
       frequency; each dimensional band  represents 1 Fire Letter Sequence or
       12 Fire Letters  (12 Fire Letters per Dimension x 1 dimension of manifest-
          tation = 12 Fire Letters).  
      • When Fire Letter Sequences in a Manifestation Template are in natural or-
        der ,  the frequencies in different dimensional bands can  merge  with each
           other.  
  • The 12 Fire Letter Sequences (144 Fire Letters) inherent to the 12-Strand
      DNA  T emplate of each Angelic Human Race in each Evolutionary
      Round correspond to the 12 Fire Letter Sequences  that compose Earth’s
      Planetary Shields . The DNA Templates of each Race in each Evolution-
       ary Round holds a specific portion of the Fire Letter Sequences corre-
          sponding to Earth’s Planetary Shields.   
     • As an Angelic Human Race Round evolves on Earth, the correct Fire Letter
    Sequences of the Universal Christos Divine Blueprint, the D-12 Shield
    of Aramatena  (Earth’s D-12 Pre-matter Liquid-Light Template) transfer
   from the Angelic Human DNA Template into Earth’s Planetary
     Shields.  This transfer of Fire Letter Sequences, or scalar-standing-wave                                                                                                                             
       frequencies, takes place through the Universal Kundalini, Maharata, Kee- 
  291                                                                                                                
                                                                                                                      
            

        The Angelic Human Heritage and Rainbow Roundtables  
   
    Ra-ShA  and Khundaray Life Force Currents that run through the human
     body and Planetary Shields. The process of Fire Letter  Sequence transfer
      from Angelic Human DNA  to Earth’ s Planetary Shields functions proper-
     ly only if the DNA  T emplate Core carries the correct  Fire Letter Se-
      quences  corresponding to the Universal Christos Divine Blueprint
    natural order  of the 12 Dimensions of manifestation within the Universal
       15-Dimensional Scale.           
              ANGELIC HUMANITY’S ORIGINAL SACRED MISSION  
       •  The Divine Commission  of the Angelic Human Race, the Sacred Mission
        for which we were originally seeded on Earth, is to correct the Fire Letter
        Sequences within Earth’s Planetary Shields , which were damaged dur-
      ing the “Fall from T ara” 550 million years ago. This Divine Commission
         is called the Christos Realignment Missio n. 
      • The four Evolutionary Rounds  of the Angelic Human Cycle of the
        Rounds were seeded simultaneously , each within their own Time Cycle
          that is synchronized with the others. The Angelic Humans and all other
             life forms on Earth during each Evolutionary Round all serve a role in an-
          choring a specific portion  of the Fire Letter Sequences  of Earth’ s D-12
          Shield of Aramatena Divine Blueprint.       • The Angelic Human race was commissioned as the  Guardians of the Plan-
      etary Christos Realignment Mission.  The Angelic Human DNA T em-
      plate is designed to carry the correct arrangements of Fire Letter
       Sequences that correspond to the core program  of Earth’ s Planetary
      Shields. If Angelic Humans are not present on the planet, and do not  suc-
      cessfully complete their intended role  during SACs,  Earth’ s damaged
     Planetary Shields can  not synthesize  the infusion of interdimensional
       frequencies  from Earth’ s opening Star Gates. In this event, Earth’ s elec-
         tromagnetic fields reverse polarity  and the planet enters pole shift  during
          a SAC . 
     • The Angelic Human Races of Earth were commissioned to serve as the
        “Frequency Transducers” for Star Gate Frequency  during SACs; a
        “Collective Buffer Blanket”  to prevent pole shift on Earth during SACs,
        while progressively re-setting the Planetary Christos Divine Blueprint
            in Earth’s Planetary Shields.  
     • As the Star Gate frequencies of the Universal Life Force Currents run
              through the human body and DNA  T emplate, the DNA  T emplate pro-
             gressively sends the corrected Fire Letter Sequences  back into Earth’s
        Planetary Shields.  With a  critical mass  of Angelic Humans transmitting
          the corrected Fire Letter Sequences into Earth’s Planetary Shields dur-
          ing a SAC,  Earth’ s grids will progressively receive the Fire Letter Se-
       quences needed for the Planetary Shields to synthesize the Star Gate
                  frequencies normally.                    
                    •  Infusion  of the correct Fire Letter Sequences enables the planet to retain                                
              its natural electromagnetic balances and axis alignment  during  SACs .
                •  If the Angelic Human races in each of the four Evolutionary Rounds  can
                   simultaneously fulfill their part in running the correct Fire Letter Se-
                         292  
     
    

                                                                               
                                   Angelic Humanity’ s Original Sacred Mission
    
          quences into Earth’s Planetary Shields during  a SAC, the Planetary
           Christos Realignment Mission will be successfully completed. Comple-
          tion of the Planetary Christos Realignment will create a natural “D-12
          Planetary Maharic Seal”  in Earth’ s T emplar Complex Star Gates, Ley
          Lines and V ortices. A  natural Planetary  Maharic Seal will return the po-
           tentials of Immortal Life, Star Gate travel and Self-Directed Ascension
           to the Angelic Human Races of Earth, while protecting Earth and human-
               ity from any further Fallen Angelic infiltration.  
    • The last SAC occurred on Earth in 208,216 BC  during the First Evolution-
   ary Round of the Palaidia Urtite-Cloister Race 12-Tribes . In our                    
present Time Continuum, the Palaidia Races were invaded  by Fallen An-
      gelic Drakonian Races from Orion and were unable to successfully com-
     plete their intended Divine Commission. Earth entered pole shift in
                    208,216 BC,  the Palaidia Empires were destroyed and survivors were re-
     settled to begin the Second Evolutionary Round  of the Cycle of the
          Rounds.  
   • Earth’s Planetary Shields have encountered progressively more misalign-
        ment  and corruption  since the failed 208,216 BC SAC. The pattern of
        Fallen Angelic Invasion culminating in pole shift that was set during the
        last consummated SAC has repeated in each Evolutionary Round since
        the pattern was set in 208,216 BC  in our Time Continuum. This Plane-
           tary Karma  pattern is presently set in Earth’s grids as a misaligned series
        of Fire Letter Sequences,  which will cause the pattern to repeat again
           during the 2000-2017 SAC.  
   • Pole Shift  in our present Time Vector can be averted by realigning the cor-
                   rected Fire Letter Sequences in Earth’s Planetary Shields  between
       2001-2012 . This will enable Earth to shift into Trans-Time Alignment
         with the Time Continuum in which the other three Rounds of the Chris-
         tos Realignment Mission are occurring successfully ; the Christos Re-
            alignment Mission will thus finally reach completion . 
                  
                     293                                                                                                         

                                                                
                                                                     The 12 Tribes and the Roundtables
                       THE 12 TRIBES AND THE ROUNDTABLES
  • The 12-Tribes of the four Rounds of the Angelic Human Cycle of the
  Rounds Evolutionary Divine Blueprint were seeded on earth specifically
   for the purpose of serving the Sacred Commission of fulfilling the Plane-
   tary Christos Realignment Mission.  
 • Each of the 12-Tribes in any one Evolutionary Round was composed of var-
    ious combinations of the 5 Primary Races manifest within that Evolution-
    ary Round.  
 • The DNA Templates of each of the 12 Tribes were encoded with the DNA
    Signet Codes encrypted into the DNA  T emplate and each Tribe was seed-
   ed on the two primary locations affiliated with the Star Gate number to
         which the DNA Signet Codes corresponded.  
 • Though numerous periods of Earth changes have occurred since the Round-
      1 Palaidia Urtite-Cloister Empires were seeded in 798,000 BC, the 12
    Tribes of each Evolutionary Round were repeatedly resettled in the same
    geographical regions of Earth that corresponded to the 12 Star Gates of
    Earth to which the DNA  T emplates of the Tribes were “frequency keyed.”
 • The significance in understanding the Angelic Human Cycle of the Rounds
   Evolutionary Blueprint is in that through this understanding we can learn
   much about ourselves and our contemporary drama today . Contemporary
   humanity is part of the fourth Round of the Cycle of the Rounds. Our con-
   tribution during the 2000-2017 SAC is just as important for the success of
   the Planetary Christos Realignment Mission as is that of the Angelic Hu-
        man nations in the other Evolutionary Rounds.  
 • The other Evolutionary Rounds are not a bygone reality of the ancient past;
   they are reality  now .  Time is simultaneous; the other Planetary Time Cy-
    cles within which the other Evolutionary Rounds are taking place exist
   concurrently with our contemporary Planetary Time Cycle, within their
     respective space-time vectors.  
 • The Time Cycles of the past and future Evolutionary Rounds are intimately
   interconnected with our present Time Cycle; each Round directly affects
        the other.  
     
     
        295
           
  

   The Angelic Human Heritage and Rainbow Roundtable
    
        12-CYCLES, SIMULTANEOUS INCARNATION, AND DNA  
 • The reality of the Cycle of the Rounds holds great personal significance  as
                      well as unprecedented collective  importance.  The individuals incarnated
   within the other Evolutionary Rounds are simultaneous incarnations of
   ourselves.  
 • The fact that we exist here today implies that we also have a personal ex-
             pre ssion of self within each of the other Evolutionary Rounds.  
  • In the Cycle of the Round Blueprint there are four Rounds , each containing
    three Planetary Time Cycles , for a total of 12 Planetary Time Cycles  in
    the Particle Universe.  This interwoven set of 12 Planetary Time Cycles
    is called a “ Planetary 12-Cycle.”  There is a corresponding evolutionary
    12-Cycle concurrently taking place within the Anti-Particle Universe of
   Parallel Earth.  The Cycle of the Rounds Divine Blueprint includes both
    the Particle and Anti-Particle  cycles  for a total of “ two Planetary 12-Cy-
    cles” within  the Cycle of the Rounds.  
  • The pattern of “two Planetary 12-Cycles” is the Core Manifestation Tem-
     plate  of the Angelic Human Evolutionary Blueprint. T o incarnate in hu-
     man form a consciousness must adopt this Primal Order  of the Angelic
       Human Evolutionary Divine Blueprint.  
 • Every human incarnate is part of a larger “ family ” of incarnated selves
         called the Personal Christos.  The Personal Christos is the Eternal Per-
       sonal Identity  that includes 1728  simultaneous incarnations, each placed
        within various space-time locations, or  Time V ectors, within the four
           Rounds  of the Cycle of the Rounds.  
 • In each of the four Evolutionary Rounds  there are 216 simultaneously in-
         carnate selves, and their anti-particle counterparts within  the Parallel
         earth system, for a total of 1728  incarnates.1 
    • The 1728 simultaneous incarnations of the Eternal Personal Identity are in-
      carnated into the Angelic Human race forms characteristic to the respec-
            tive Evolutionary Rounds:  Round-2: Palaidia Urtite-Cloister  race.
     Round-3: Urtite-Cloister Race . Round-4: Cloister race.  Round-1: Root
      Races . Each of us have 216 selves incarnate within the Angelic Human
         race lines characteristic to each of the four Evolutionary Rounds.  
 • Each of the three Planetary Time Cycles in each of the four Evolutionary
      Rounds contains 72 Time Vectors.  In one Planetary 12-Cycle  there are
      864 Time Vectors.²  W e each have one incarnate self  in each of the 864
      Time Vectors of one Planetary 12-Cycle and 864 corresponding selves  in
     the Parallel Earth Planetary 12-Cycle. An Angelic Human with a 12-
     Strand DNA  T emplate has 1728  simultaneous selves manifest within
       1728 Time Vectors of Two Planetary 12-Cycles.  
        ___________________________              
    1.   216  selves x 4 Rounds = 864 selves + 86 anti-particle counterpart selves within the Par-
             allel earth system = 1728 selves.  
                    2.   72 Time Vectors per Planetary Time Cycle x 3 Planetary Time Cycles = 216 x 4 Rounds = 
                                  864 Time Vectors.  
 
                       296  
                                                 
1 

                                             
                          12-Cycles, Simultaneous Incarnation, and DNA
•  Indigo Children Maji Grail Line  Angelic Humans with 24-Strand DNA
          T emplates  have 1728 simultaneous selves incarnate in 1728 Time V ec-
          tors in one Planetary 12-Cycle  and 3456 simultaneous selves  in the
         T wo Planetary 12-Cycles  of the Cycle of the Rounds. Maji with  36-
          Strand DNA  T emplates  have 2592  selves in 2592 Time V ectors in one
          Planetary 12-Cycle and 5184 selves  in the Two Planetary 12-Cycles. 48-
          Strand DNA Template Maji have 3456  selves in one 12-Cycle and  6912
             selves  in the two 12-Cycles.  
    • Each of our 1728  Angelic Human selves in their respective Time V ectors
         is interconnected with each other across time  through a shared DNA
          T emplate.  When activated, the 12-Strands  of the 12-Strand DNA  T em-
          plate serve as “ electromagnetic windows ” or “Internal Star Gates”
         through time.  Through the activated 12-Strand DNA T emplate, the fre-
           quencies of energy  and consciousness  of each of the 1728 selves merge
          into an embodied, unified conscious awareness . Each individual incar-
            nate self comes to know itself as an Eternal Christos Avatar Identity  that
          is simultaneously manifesting  in 1728 different Time Vectors , wearing
         the “ costume”  of 1728 different bodies  and personality characteriza-
             tions.   
  • The 1728 simultaneous incarnations of the Personal Christos Eternal Iden-
          tity  represent the '' reincarnational '' heritage  of every 12-Strand Angelic
         Human  being; every human being possesses the dormant imprint of a
         minimum  of the 12-Strand  Angelic Human design. The tangible reality
         of the Personal Christos is held into manifestation within the Personal
         Christos Divine Blueprint ; the D-12  Pre-matter “Liquid-Light” (Hydro-
             plasm) Maharic Shield.  
  • The Personal D-I2 Christos Divine Blueprint Maharic Shield connects
          each Individual Christos self to the larger  D-12 Christos Divine Blueprint
          of the Species. The D-12 Christos Divine Blueprint is called the Tribal
              Shield.  
     • To understand the realities of personal Spiritual Integration  and Actual-
         ization , in order to fulfill our personal life purpose, it is important to
            comprehend the basic Primal Order  structures of energy, the personal D -
          12 Maharic Shield  and the D-12 Species Tribal Shields , through which
            our consciousness manifests in time.  
    • The secrets to reclaiming the Divine Birthrights and Responsibilities  of
        Angelic Human heritage are hidden within the realities of the Tribal
          Shield and  the specific '' Fire Letter Sequence''  of the Tribal Shield that
         manifest within and govern the function  of the Angelic Human D NA
           Template .                                                                                            
     
     
     
      297  
                                                                                                                                                 

                                           
                     
                   The Angelic Human Heritage and Rainbow Roundtables
                  THE  REALITY  OF SPIRITUAL  INTEGRATION  
• Spiritual Actualization  is as much a function of Divine Physics  as it is a
    product of Divine Consciousness . The natural Primal Order of Universal
    Structure sets the Templates of Manifestation  to which consciousness
     must conform  to enter the experience of manifest expression within a
      space-time-matter system.  
• The personal Christos Maharic Shield Manifestation Template and the
     Christos Tribal Shield Species Manifestation Template are microcosmic
      replicas of the macrocosmic Primal Order upon which Universal and Cos-
        mic structure are built.  
 
• The tangible realities of human Spiritual Actualization take place through
     the Primal Order of the Angelic Human 12-Strand DNA Template.
      Each DNA Strand Template  holds a specific set of “Internal Star Gates”
       that allow for the progressive merging of the consciousness and energy fre-
     quencies of the 1728 selves  incarnate within the Two Planetary 12-Cy-
        cles of the Cycle of the Rounds.  
 
• Spiritual Actualization as a reality , rather than as a theoretical concept,
     takes place through progressive activation  of the dormant 12-Strand
     DNA  T emplate.  Each DNA  Strand T emplate corresponds to one dimen-
     sional frequency band, to corresponding levels or dimensions of con-
      scious awareness and to a specific set of incarnations  within the Cycle
     of the Rounds. Spiritual Actualization is accomplished when the 12-
     Strand DNA  T emplate “Internal Star Gates”  have fully opened, allow-
     ing the 12 dimensions  of conscious awareness of the Eternal Personal
      Christos Identity to merge and unify within a singular embodiment, across
        the fields of time.  
• The key to  Spiritual Actualization  is activation of the dormant personal
      12-Strand DNA  T emplate. The most rapid means  of activating the dor-                                                                                                                                             
     mant Angelic Human 12-Strand DNA  T emplate is through activation of
     the T ribal Shield,  the Species D-12 Christos Divine Blueprint, which
     represents the core programming  of the personal D-12 Maharic Shield.
 298                      

                                                                                                                                                  
                                                                                              Activating the Tribal Shield
                         ACTIVATING  THE  TRIBAL  SHIELD  
 •  The 12-dimensional Tribal Shield  is the dormant Species Divine Blueprint
       within the DNA Template core  of the Angelic Human races of the four
            Evolutionary Rounds. The frequencies of energy and dimensions of con-
        sciousness of the 1728 simultaneous selves  of the Personal Eternal Chris-
     tos Identity can be activated in one incarnation  through  sequential
     activation of the Fire Letter Sequences or “Flame Codes ” of the Tribal
          Shield.  
  • The “Flame Code Fire Letters” within the DNA Template are the DNA
      Signet Codes  that correspond to Earth’ s 12 Primary Star Gates  and the
      Planetary Shields  through which the planetary body manifests. The
        Flame Codes serve as the core foundation of the personal 12-Strand DNA
        Template.  
   • The DNA Template Flame Codes of the Tribal Shield allow for the Primal
      Life Force Currents of the Density-5 (dimensions 13-14-15 ) Kee-Ra-ShA
     Primal Light Fields  and the Khundaray Primal Sound Fields  from the
      Energy Matrix, beyond the 15-Dimensional Time Matrix, to embody
        more fully within the Angelic Human form.  
  • A Fire Letter is a fixed point of consolidated frequency  that holds specific
       frequencies of consciousness into manifest form. The Manifestation Tem-
        plates  or Divine Blueprints of all things  manifest are built upon intricate
       patterns of interwoven Fire Letters called Fire Letter Sequences. The
        Flame Codes of the Angelic Human personal DNA  T emplate and Species
        Tribal Shield are composed of the same  Fire Letter Sequences  that make
           up the Divine Blueprint of Earth’s Planetary  Shields.  
    • Activation of the Tribal Shield sets in motion simultaneous “firing” or acti-
      vation of the 144- Fire Letters  (12 Fire Letter Sequences)  of the l2-
       Strand DNA  T emplate, expediting the natural evolutionary process of
        Soul, Over-Soul and Christos A vatar Identity Integration, through pro-
          gressively opening the “Trans-time DNA Template Star Gates.”  
     • Activating the 12-Strand DNA Template allows the D-12 frequency of the
      Universal “Christos” Maharata Current  to activate within and run
      through the Angelic Human DNA  T emplate and into the Earth’ s Plane-
        tary Shields.  Activation of the Maharata Current within groups of An-
        gelic Humans on Earth allows for collective anchoring  of the D-12
   Planetary Christos Divine Blueprint , the Shield of Aramatena , to          
 achieve fulfillment of Angelic Humanity’s Sacred Commission  of the
        Planetary Christos Realignment  Mission.  
    299  

   
                 The fastest means of naturally activating the Personal 12-Strand DNA        
     THE FASTEST MEANS OF NATURALLY ACTIVATING THE
                          PERSONAL 12-STRAND DNA TEMPLATE  
  
  1.Tribal Shield Activation: Activating the 144 Fire Letters of the Tribal
      shield.  
   2.Emerald and Amethyst A wakening 2 Masters Kundalini Activations: Re-
     leasing key Fire Codes  between the DNA  Strand T emplates to allow for
        expedited DNA Strand Braiding.  
3.DNA Template Bio-Regenesis: Progressive use of internally directed DNA
       T emplate Bio-Regenesis technologies for progressive purging of Strand
             T emplate mutations, restoration of the natural D-12 Christos Divine
    Blueprint of the 12-Strand DNA  T emplate and expedited, accelerated ac-
        tivation of the DNA  Strand T emplate Base Codes and Acceleration
           Codes.  
 4.Master Key Codes: Use of the personal scalar-wave-guide Symbol Code Pro-
    grams that correspond directly to the core programming of the personal D-
   12 Maharic Shield for further sequential expedition of Strand T emplate
       Activation.  
5.Melchizedek Cloister Level-3 Regent Ordination: Transmission of the Kee-
      Ra-ShA  Primal Light and Khundaray Primal Sound Field “ Rainbow Ray
     Current ” directly into the personal  DNA  Template  via direct Chakra
      Induction . Sufficient Rainbow Ray frequencies to provide a level-3 Re-
         gent Ordination can be transmitted by a Melchizedek Cloister level-5  El-
          der Consummate or Level-6 Eckar  Indigo Child-Type-1 Maji Grail Line
      Angelic Humans, who have the frequencies of the Primal Creation Cur-
      rents integrated into their DNA  T emplate from birth. Expedites all of the
        above while  providing additional bio-energetic field support  for more
             stable cycles  of DNA Template activation.                           
                           
                                  CHRISTOS IDENTITY INTEGRATION  
Through progressive activation of the 12-Strand DNA Template  the DNA
      '' Internal Star Gate '' between the 1728 simultaneously incarnate selves
        of the Personal Eternal Christos Identity  progressively open . Opening of
          the Internal Star Gates of the DNA  T emplate allows the 12-dimensional
        frequency spectra  of the Soul , Over-Soul  and Christos Avatar Identity
      levels to sequentially and consciously embody within the Angelic Human
     form.  
Soul Integration:  Activation of DNA Strand Templates 4-6  opens DNA
       Star Gates between incarnates in Planetary Times Cycles 1-2-3  and 4-5-
       6 . The 6th-Strand Activated Being possesses 6-dimensional conscious-
      ness , is a fully embodied soul,  can pass through Universal Star Gates 1-
        6  of Densities 1 and 2 via formation of the 6-dimensional Hallah Phase
         Merkaba V ehicle  and building of dimensions 1-6 of the Antahkarana
           Primal Life Force Current.    
      Over-Soul Integration:  Activation of DNA Strand Templates 7-9 opens
      DNA  Gates between incarnates in Planetary Times Cycles 1-2-3,-4  
    301  
                                                                                                                  

       
    The Angelic Human Heritage and Rainbow Roundtables  
   
       5-6  and 7-8-9 . The 9th Strand Activated Being possesses 9-dimensional
       consciousness , is a fully embodied over-soul , can pass through Universal
       Star Gates 1-9  of Densities l, 2 and 3 via formation of the 9-dimensional
       Quatra Phase Merkaba Vehicle  and building of dimensions 1-9 of the
          complete Antahkarana Primal Life Force Current .  
 Christos A vatar Integration : Activation of DNA Strand Templates 10-12
       opens DNA  Star Gates between incarnates in Planetary Times Cycles 1-
       2-3, 4-5-6, 7-8-9  and 10-11-12 . The l2th-Strand Activated Being pos-
         sesses 12-dimensional consciousness , is a fully embodied Christos Ava-
       tar , can pass through Universal Star Gates 1-12  of Densities l, 2, 3 and
         4 via formation of the l2-dimensional Mahunta Phase Merkaba Vehicle
         and building of dimensions 10-12  of the Christos Maharata  Primal Life
       Force Current, capable of full Ascension  out of manifest matter density.  
                      
                             REALITY OF THE ROUNDTABLES  
 • The Planetary Christos Realignment Mission was  designed to take place as
         the members of the Angelic Human races in each of the four Evolution-
         ary Rounds  joined together during Stellar Activations Cycles (SACs)  in
        their respective Time Cycles, to run their DNA  T emplate Signet Code
        Fire Letters  from their Tribal Shield  into Earth’ s Planetary Shields.
 • The groups of Angelic Humans who gather during SACs to run the Rainbow
         Ray Primal Life Force Currents and Star Gate Signet Code Fire Letters
          into Earth’ s Planetary Shields to prevent pole shift  are called Signet
           Councils . The Angelic Human Signet Councils are incarnate members of
       the Azurite Universal Templar Security Team.  
 • The D-12 Shield of Aramatena Planetary Christos Divine Blueprint is re-
      ferred to as the '' Rainbow Roundtable '' Members of the Angelic Human
     Signet Councils  are called '' Rainbow Wearer '' and ''Regents of the
      Rainbow Roundtable. '' These titles indicate the capacity to hold at least
       temporary 12-Strand DNA Template activation,  which  permits the Re-
      gents to run sufficient amounts of the Rainbow Ray Primal Currents to re-
      set the Planetary Christos Divine Blueprint within Earth’ s Planetary
          Shields.  
      Running    of    the    Planetary   Sign et   Rainbow    Roundtables   to     prevent     pole    shift
       during SACs is done in the following manner:  
 l. Activation of the Personal D-12 Maharata Current and Tribal Shield  to
      run the Rainbow Ray Primal Currents  via temporary activation of the
         12-Strand DNA Template.  
                             2. Assembling of Signet Council Regents  at various geographical locations to
                conduct '' Roundtables ,'' using specific '' Signet Stand '' to collectively           
               run the Tribal Shield Fire Letters  into Earth’ s Planetary Shields at
                                  Earth’s 12  Star Gate  opening   points  and  12 Gate   Activation Sites.
   • If an individual Regent can determine which of the l2 Angelic Human
      Tribes represents their genetic lineage , they can direct their Rainbow Ray
      Current and Tribal Shield Fire Letters directly to the Star Gate and Ac-
          tivation Site  to which their DNA Template corresponds.  
    
    302                   

                                                                            
                                                          
                                                     12 Tribe Names and Sacred Psonns  
      •  If the specific 12 Tribe lineage cannot be determined , individuals can use
     the Sound-Symbol Program of “Tribe-13 ” the Universal Tribe  contain-
  ing all 12-Tribes , running their Rainbow Ray Current and Tribal Fire
 Letters into the Gru-AL Point central control point for Earth’s Planetary
 Shields . 
    • The Tribal Shield  is brought into activation through sounding of the com-
                     pound tonal programs  that represent the audible sound translation  of the
                  specific frequencies  carried in the Tribal Shield  DNA  T emplate Fire
                      Letter Sequences.  
                           
                          12 TRIBE NAMES AND SACRED PSONNS  
   • The original names  of the Angelic Human 12-Tribes were spoken in the
    first of five  Christos Languages;  the Mu’a/Anuhazi  language of the
     Palaidia Urtite Cloister Mu’ a  race. Anuhazi (“Mu’a”) is the original  first
   externally spoken language  in our Time matrix, the native tongue of the
        Emerald Order Breneau  and Lyran-Sirian Elohie-Elohim  Christos
      Founders races from Density-5 (dimensions 13-14-15).  
      • The 12-Tribes names  were the audible-tone translations of the specific
       Fire Letter Sequences  contained within the  T ribal Shield DNA T em-
      plates  of each Tribe. The tones of the Tribal names were used to activate
      the 144 Fire Letters  of the Tribal Shield in the personal  DNA Template,
     providing the Angelic Humans races with the ability to consciously reg-
      ulate  the activation level  of their DNA Templates  and Primal Life Force
      Currents.   .The Sound-Tone  programs  that are used to activate the DNA  T emplate
         and Primal Life Force Currents are called ‘ ‘ The Sacred Psonns. ’’ The
     Tribal name  was the Master Psonn . In running the Rainbow Roundta-
     bles, the Signet Council Regents bring their Tribal Shield ‘ ‘Flame Codes’ ’
          into activation by singing rounds  of the Sacred Master Psonns .                                                                      . The true Angelic Human 12-Tribes names were intentionally changed  and       
            the knowledge of the Mu’a Anuhazi language  strategically concealed on           
           Earth by Fallen Angelic legions and their Illuminati Human hybrid races.                
     The tactic of deception was used to ensure that the Angelic Humans of                 
     Earth would be unable to activate their Tribal Shield DNA Template                         
           Flame Codes  to run the Rainbow Roundtables during the 2000-2017 AD                    
              Stellar Activations Cycle, so pole shift and destruction of the Angelic Hu-
          man race would take place during the 2000-2017 SAC.  
 
  • This ill-intended agenda can be stopped if Angelic Humans are willing to
     assist Guardian Nations in running the Rainbow Roundtables between
         2002-2012                           
                  THE THREE KEY ELEMENTS OF THE CYCLE OF THE ROUNDS
                        
                                    Key Element- 1: “The 12 Signet Tribes and Races List”                   
              • The methods by which we can fulfill our intended part of the Planetary
        Christos Realignment  become apparent through understanding Three
                      303  
                                                                                                                                 
            

                 The Angelic Human Heritage and Rainbow Roundtables
      
         Key Elements  of   the  Cycle  of the Rounds  Angelic Human  evolutionary
      design.  
• Element-1. The 12 Signet Tribes and Races List: The list of Signet An-
       cestral Ascendancy ,  which reveals the 12 Signet Tribes appointed as
    Guardians and “Keepers of the Keys” for each of the I2 Universal Star
   Gates and their earthly correspondences. The 12 Signet Tribes and Races
    List traces the genetic lineage  of the 5 Palaidia Urtite-Cloister Angelic
    Human Seed Races that founded the 12 Signet Tribes of Seeding-3  up to
      their contemporary race lines.  Through revelation of Signet Ancestral
    Ascendancy , we can identify the original Signet Tribe  from which our
    current genetic code originally emerged, and thus we can reclaim the
    knowledge of the “ Signet Council ” to which we presently belong. This
    information, recorded on CDT Signet-Plate-12,  allows us to identify the
       Core Signet Key Codes  upon which our  personal DNA  T emplates  are
    built, so we know to which of the 12 Star Gates our  DNA  T emplate is
    ''Keyed .'' Identifying which of the 12 Tribes represents our predominant
       genetic lineage  enables us to discover the core '' Master Symbol-Color -
     T on '' Keys  we need to rapidly initiate accelerated “Fire Letter” activa
       tion sequences  in our dormant 12-DNA Templates, to expedite embod-
  iment of our personal D-12 Inner Christos “Maharic Shield" Template.  
              
        • Progressive embodiment of our Personal Divine Blueprint,  the D-12 Pre-
    matter Maharic Shield  allows us to progressively attain real 12th-dimen-
          sional ''Christ Consciousness, '' rather than false “Christ conscious-
       ness.” False Christ consciousness  teaches us to give spiritual “lip
    service”  and “wishful thinking”  to the concept of becoming “Christed”
     through worship of false externalized gods , but teaches nothing of the re-
     alities of Sacred Science 15-Dimensional Human Anatomy and Ascen-
    sion Physics.  The Founders’  Sacred Science  knowledge represents the
     '' Keys to the Kingdoms of Heaven '' without which one  cannot attain
       genuine Christ Consciousness , Spiritual Mastery or Ascension
            Though full translation of the 12 Signet Tribes and Races List  for          
             Seeding-3 would literally fill thousands of books, a basic analysis  of the An-
       cestral Ascendancy contained in the list, herein, will provide sufficient
    data for many of us to trace our Primary DNA Template Signet Coding .
      Through the rudimentary but accurate listings  provided in this book,
     many of us will be able to identify our original Tribe and Primary DNA
     Template Signet Coding,  and thus the  Star Gate, Signet Set and Master
     Symbol-Color-T ones  to which our DNA  T emplates are “frequency
     keyed.” In Global Healing Efforts, Planetary Templar Grid Work and
     actualizing Earth’ s Christos Realignment , it is essential for us to under-
     stand the Three Key Elements of the Cycle  of the Rounds  Angelic Hu-
     man Evolutionary Design. Understanding the basic realities of the Cycle
       of the Rounds will determine whether we will be lovingly and tangibly ef-
      fective or well meaning but unable to fulfill our good intentions, in our
     planetary healing endeavors. The First Key Element  of the Cycle  of the
     Rounds is the 12 Signet Tribes and Races List , through which we can
     discern which Star Gate is waiting to receive our personal  “piece of the
    Christos ” to '' fill in the frequencie '' of its own Divine Christos Blue-
       print.  
 304 
 

  
                                                 The Three Key Elements of the Cycle of the Rounds  
                            Key Element-2: “The Signet Maps and Keys’ ’  
   • The Cycle of the Rounds Key Element-1, The 12 Signet Tribes and Races
      List, provides us with the first necessary tool  to discovering the Master
      Symbol-Color-T one sequences and Star Gate Signet Council to which
      our personal DNA  T emplates and Soul Contracts, are keyed; our original
       Tribe.  Once we have a basic idea  of what Palaidia Empire Seed Tribe our
      genetic lineage (and our reincarnational lineage  as well!) emerged from,
       we can then utilize the information contained in Key Element-2  of the
       Cycle of the Rounds. Key Element-2  is the Signet Maps and Keys Chart ,
      which reveals the Tonal Encoding  of each 12 Tribe name , the Star
    Gate-Signet Set assignment  of each Tribe, the specific geographical lo-
     cations  of the 12 Templar Signet Site  star gate opening points and their
       corresponding Templar Cue Site  activation points. The  Signet Maps and
       Keys Chart also reveals the  Master Symbol  (frequency director), initiat-
     ing Master Tone Suffix  (frequency activator), the  Psonns  (primary tonal
      activation sequence), Flame Code  (frequency selector: Signet Master
       Key Code) and Master Color  (frequency selector; Signet Encryption Key
         Code) for each of the 12 Tribes. This data represents the ''Fire Letter''
      Frequency Programs to expedite activation  of the personal DNA Tem-
     plate and the  Frequency  Keys by which each of the 12 Star Gates and
     Signet Sets are activated . Like Key Element-1: The 12 Signet Tribes and
       Races List , full translation of Key Element-2: The Signet Maps and Keys
      Chart , would fill many volumes; the Signet Maps and Keys Chart  is
       drawn from the “ Book of Maps and Keys ,” stored on CDT Signet-Plate-
      11. Advanced study of Masters Sacred Physics Mechanics  is required be-
      fore the full body of knowledge  contained within the Book of Maps and
        Keys  can be sufficiently understood and functionally utilized.  
  • Due to the progressive difficulties emerging in Earth’ s 2000-2017 Stellar Ac-
          tivations Cycle (SAC), there is presently no time available to methodi-
         cally initiate advanced study of Masters Sacred Physics Mechanics ; such
         study will be made available to the public if Earth’s 2000-2017 Planetary
         Christos Alignment is successful. If the 2000-2017 '' Bridge Zone Project ''
         (see page 142) and its inherent Planetary Christos Realignment Mission
         (see