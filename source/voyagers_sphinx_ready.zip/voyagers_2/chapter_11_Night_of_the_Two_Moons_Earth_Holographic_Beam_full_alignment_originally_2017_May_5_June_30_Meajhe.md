Chapter 11); ''Night of the Two Moons'' Earth/ Holographic Beam full alignment
(originally 2017, May 5-June 30 ). "Meajhe Zones " in temporary 4.25-D magnetic ﬁeld/ D-9 Quatra Phase
Merkaba  full protection/stable, ‘ Trion Zones”  in D-6 Hallah Phase Merkaba partial protection/ less stable;
Trion/Meajhe Field Buffer Blanket suspends Arcturian/ Orion/ Andromeda Activations frequencies to 2012.
2006-2012 : Earth remains in Meajhe Zone -Quatra Phase Merkaba/ Trion Zone -Hallah Phase Merkaba protective
Bi-Polar Suspension  to 2012 when ﬁnal  time line separation  of Meajhe Zone /Bridge Zone and Trion Zone
/Phantom Matrix  occurs. GA '' Last Call '' for Illuminati and Human Bridge Zone Emerald Covenant Amnesty/
Redemption Contracts .
2011;  UIR attempt OWO invasion/Pole Shift agenda last 3-4 month "window of opportunity'' as Meajhe Zone
Quatra Phase Merkaba slows to complete Bridge Zone shift starting April-July 2011. ''Wlngmakers " Labyrinth
Group tricked by UIR Necromiton-Andromie-Anunnaki hybrid Nephilim ''Corteum '' to build UlR '' BeaST Pulse ''
weapon. UIR intend to use 2011 BeaST Pulse  and Trumpet Pulse to reactivate 7 Jehovian Seals, uncap/ merge
Falcon-Phoenix Wormholes and rip Earth's Planetary Shields apart to merge past-present-future Phantom Earth to
Earth in 2011 . 6520AD-GA's Wingmakers  site holds Founders‘ ''Trump Card" Signet Shield-6;  GA block BeaST
Pulse, prevent 2011 Final Conﬂict drama UIR invasion.
2012 December ; Early December 2012, suspended D7/D8 Gold Wave infusion/ Arcturian Activation , D8/D9 Sliver
Wave infusion/Orion Activation  and D9/D10 Blue-Black Liquid Light Wave Infusion/ Andromeda Activation
frequencies release in Earth grids (originally 2017).  Earth Meajhe Zones remain in 4.25-D Quatra Phase Merkaba
ﬁnal Bridge Zone merger. Trion Zones localized Earth Changes mark passage to Phantom Matrix time line merger.
Earth's Bi-polarized Meajhe Zones/Trion Zones in Trion/Meajhe Field Butler Blanket suspension ﬁnal time line
separation.
December 21, 2012:  Christos Realignment Mission fulﬁlls on Founder's original sch edule of December 21, 2012 due
to Anunnaki detection to UIR; date was set 22,326BC . Earth/lnner Earth/Trans-Harmonic Meajhe Time Matrix
Universal SG-12 SC Seals release, fully link three Time Matrixes. Final 3 ''Christos'' Stellar Wave Infusions/ Lyran
Stellar Activations ; D10/D11 Silver-Black  Liquid Light Infusion/D-10 Lyra-Vega Activation , D11/D12 Pale Silver
Maharata ''Christos'' Liquid Light Infusion/D-11 Lyra- Aveyon Activation , D12/D-15 ''Rainbow Ray" infusion/D-12
Lyra-Aramatena Activation . Earth-Tara-Gaia/Universal '' Christos Divine Blueprint " anchors, P ermanent Level-12
Planetary Maharic Seal /D-12 Mahunta Phase Merkaba , Halls of Amenti/Earth's SGs permanently open , our Time
Matrix/Phantom Matrix permanently severed. Real Age of Enlightenment begins. Mass GA Contact Eieyani/Sinus B
Maharaji/Azurites/Aethien/Serres 2017 .
                                                                   ©2002 Ashayana Deane
512

             
2001 Update Summary Charts
            Progression of Intruder APIN Templar Conquest -Atlantis to 2001
                                         Summary Chart (4 Page)
                    APIN Earth Beginnings : Advanced “Crystalline Micro-chip” Technologies of the ancient Atlantian and Lemurian
                                         APIN (Atlantian Pylon Implant Network) and LPIN (Lemurian Pylon Implant Network) systems
                                                 were implanted in Earth’ s Template during various periods of Atlantis/Lemuria
• 5.5 Million Years Ago : Elohei-Elohim Leonines (Anuhazi) and Seraphei-Seraphim Avians (Cerez-Serres) create          
“Wall in Time” Earth/Phantom Earth barrier, Great White Lion  and Golden Eagle APINs  to hold Earth’s Planetary     
Shields together and prevent Earth’s Phantom Matrix descent after Electric Wars . Founders install 24 NCT-Bases  
          (Nibiruian Crystal Temple Bases) Nibiru interface link 3 million years ago  when Nibiru became Emerald Covenant                
         planet. APIN and NCT-Base conquest battles frequent throughout Angelic Human Seedings 2 and 3. “Lion” APIN       
         shut down by Intruder Omicron-Drakonians in 208,216BC  SAC Fall of Brenaui. Anu Occupation 148,000BC-      
         75,000BC , Nibiruian Anunnaki takeover 24 NCT-Bases, Humans underground exile.
• 75,500BC : Omicron-Drakonian/Odedicron-Reptilian races create '' Dragon '' APIN  in Templar Quest campaign.     
Anunnaki, attempt Inner Earth takeover, Anu Occupation dominion prevented in 75,000BC via Inner Earth Rebellion.      
Pacific Continent ''Lemuria'' destroyed 50,000BC  Jehovian-Anunnaki Templar quest, Arc of the Covenant passage     
relocated from Atlantis to Giza, Egypt. GA, with Emerald Covenant Anunnaki build Mars Base  and 1st Sphinx/Giza     
Great Pyramid  teleport station in 46,459 . Atlantic Continent reduced to islands, Sphinx/Pyramid-1 damaged, natural     
Sirius B alignment severed 28,000 BC  Anunnaki/Illuminati Templar quest. 
• 25,500 BC : Lucifer Rebellion . Pleiadian, Nibiruian and Alpha Centauri ''Luciferian'' Anunnaki Intruder races unite;     
bring NDC-Grid  (Nibiruian Diodic Crystal Grid)/ Battlestar Wormwood Stonehenge link, NET (Nibiruian Electro-     
static Transduction field) '' Checkerboard Matrix '' grid control/DNA mutation technologies to Atlantis for Earth     
Templar dominion.  Nibiruian Anunnaki seize control of Solar SG-4 , and partial control of Giza Pyramid  Earth SG-4.      
24 NCT-Bases overtaken by various competing Intruder factions. Intruder Jehovian-Anunnaki create initial '' Dove ''     
APIN . Golden Eagle APIN  ''hi-jacked'' by Necromiton-Andromies/Nephilim hybrids, run on reverse Phantom Matrix     
current as '' White Eagle '' APIN . Pleiadian-Nibiruian Samjase-Luciferian/Enki-Zephelium/Enlil-Odedicron Anunnaki      
install Level-1 '' Serpent '' APIN.  Progressive Annu-Melchizedek Leviathan hybrid race infiltration of Atlantian culture     
advances. GA/Humans/Indigos/Eieyani successful in preventing full Anunnaki invasion.
• 22,500BC-22,326BC:  Founders realize Phantom Matrix near critical mass accretion to pull Earth in. 22,500     
GA/Eieyani-Indigo Crisis Intervention Team from Inner Earth sent to Lemuria (Mauravhi) for Christos Realignment     
Mission  (Level-12 Planetary Maharic Seal) Earth Rescue plan. Eieyani install advanced '' 4 Faces of     
Man ''/''Guardians of the 12 Pillars '' LPIN  to realign/activate Great White Lion, Golden Eagle APIN’s and draw     
Earth into Meajhe Field for Christos Realignment in 22,236BC SAC. GA Sirius B Maharaji and Anteres/Altair     
Rashayana install Blue Oxen APIN  Interface system. Intruder Jehovian-Anunnaki Dove APIN expanded . Thoth     
breaks Emerald Covenant, leads 22,326BC Eieyani Massacre, Founders Christos Realignment Mission postponed      
to next SAC December 21, 2012, “Final Con ﬂict Stale Mate” to resolve 2000-2017AD SAC.  
• 10,500BC:  Luciferian Conquest : Anunnaki/ Drakonian Leviathan Illuminati Atlantian uprising, competing Templar     
Conquest. Two wormholes constructed in “Wall in Time” between Earth/Black Hole Phantom Matrix. The       
Pleiadian/Nibiruian Anunnaki Phoenix Wormhole/  Phoenix APIN  to Phantom Nibiru/ Tiamat and Zeta-Rigelian/     
Drakonian Falcon Wormhole/Falcon APIN  to Phantom Earth/Alpha Draconis. Two Atlantian wormholes give      
advancing Fallen Angelic invasion forces greater dominion potential over Earth/Halls of Amenti Gates for 2000-     
2017AD SAC. Omega Centauri Intruder Blue Centaurs take over Blue Oxen APIN . Enoch defects from Emerald     
Covenant, assists Intruder Jehovian-Anunnaki to link  '' Dove'' APIN to Phoenix Wormhole , creating the 7     
Jehovian Seals/ ''7Trumpets '' advanced Dove HD-C  (Hyper-Dimensional Cone) APIN.  Mars Base  and      
Sphinx/Pyramid-1 destroyed; Sphinx/Pyramid-2 rebuilt by GA, realigned with Pleiadian-Alcyone following    
        10,500BC squelched invasion. Founders/GA secure temporary Phoenix/Falcon Wormholes Cap ; confine              
        Luciferian Conquest to Atlantian Island territories, temporarily pushing back further Anunnaki invasion of Egypt.  
                                                                                              
                                                                        ©2002 Ashayana Deane
518  
                                                                                                            

                                                                                                                    
                                                                                                  
                                                                                                  2001 Update Summary Charts
.      9560BC-9558BC:  Luciferian Covenant . Atlantian Leviathan Illuminati enter Luciferian Anunnaki dominion cov enant   
9560BC , blow GA Cap off Phoenix/Falcon Wormholes  to stage 9558BC ''Atlantian Flood '' and '' Housecleaning ''   
takeover. Sphinx/Pyramid-2  damaged, Alcyone link broken. GA install 9540BC Frequency Fence  to re-Cap     
Wormholes  and prevent cataclysmic early Blue Flame activation. GA create “ Arc of Covenant Gold Box/Rod and     
Staff Star Gate tools  for Indigo Maji-Human race access to Inner Earth portals. Anunnaki, Drakonian and     
Necromiton-Andromie races and Illuminati hybrids run competing territory conquest agendas since 9558BC, try to     
capture Arc of Covenant Gold Box/Rod and Staff tools to activate their APIN's for Templar dominion. Necromiton-    
Andromies join Blue Centaurs in 5,900BC  Centaurian War  in attempt to use ''hi-jacked'' Blue Oxen APIN India for    
Templar dominion; air attacks squelched by GA Sirius B Maharajhi and Pleiadian Serres. Anunnaki Illuminati     
rehabilitate Sphinx/Pyramid-2  as cultural center 5546BC.  Progressive “ Atlantian Conspiracy ” Templar conquest    
throughout post 9558BC period Sumer to America, Illuminati races infiltrate/hybridize with all major Human 12-Tribe    
cultures; Eieyani-Indigo Maji Grail Line retains pure strain 12-48 Strand DNA to fulfill Christos Realignment Mission    
via RRT’s during long-anticipated 2000-2017 SAC “Final Con ﬂict” drama. 
                                                                                          Wormholes, APIN / LPIN’s 1916-2001
• 1903-1916 : Zeta’s of Phantom Earth open Atlantian Falcon wormhole  off coast of Charleston, South Carolina in    
Atlantic Ocean (was Nohassa Atlantis), begin speculation for invasion . Militant Zeta-Rigelian  force of Phantom    
Alnitak-Orion  take over Falcon Wormhole, begin covert infiltration of Earth governments on behalf of the Zeta-    
Drakonian agenda, overthrowing historically positioned Anunnaki strong-hold on Illuminati covert OWO operations.    
Fallen Angelics begin competing progressive conquest for activation/ dominion of APIN systems in preparation for     
2000-2017 SAC. 
• 1930s:  Zeta-Rigelians make treaties with Illuminati hybrid-human races in several major world governments, begin    
early Zeta Treaties  and Majestic-12 seed group covert Illuminati OWO World Management Team under Zeta’s    
Drakonian Agenda . Zeta-Rigelians set out to activate Falcon APIN,  begin Ethnic Virus/  Sonic Pulse Un-natural    
Disaster  program testing for intended reduction of human populations  if SAC commenced in 2000 and     
abduction/hybridization programs . Zeta-Rigelians assist to organize and strengthen Hitler Nazi movement  via    
physical contact with Nazi Inner Circles; Hitler agrees to advance ''Race Supremacy'' program with intention of     
exterminating specific Hibiru Anunnaki Illuminati hybrid races , while protecting Hibiru Illuminati hybrid lines of    
the Drakonian races. Drakonian Illuminati in Allied Governments  covertly assist Nazis  financing. 
• 1940s:  Hitler  makes double deals  with Necromiton-Andromies, and kills groups of Drakonian Hibiru Illuminati;     
Zeta-Rigelians withdraw Nazi support,  assist Allied Governments in victory over Nazi regime, formalization of MJ-    
12 World Management Team ''Big Brother Drac'' group. Necromiton-Andromie  races attempt to mobilize their     
Illuminati races in Hawaii and Nagasaki Japan  to built underground bases to hi-jack the Zeta-Rigelians Falcon     
APIN Port Interface System at its Nagasaki APIN  site. Zeta-Rigelians instruct their Illuminati hybrids in Japan and    
US via MJ-12, to launch Pearl Harbor strike; US and Japanese Illuminati know plan from start. Zeta’s provided allies    
with A-Bomb technology  specifically to use on Nagasaki, to regain Nagasaki Falcon APIN site under Zeta-     
Rigelian control . Hiroshima Necromiton-Andromie Illuminati wiped out on behalf of Zeta-Rigelian Agenda, Maji     
Grail Line Human YU race Indigos of Hiroshima destroyed , Nagasaki reclaimed under Zeta-Rigelian control.     
Necromiton-Andromies prevented from building Nagasaki base, Falcon APIN continues to be activated by Zeta-Rigelians. 
• 1943 : Zeta-Rigelians expand Falcon APIN system via August 12 , 1943 Philadelphia Experiment , putting east    
coast US Falcon APIN system “on-line” with Falcon wormhole . Create the Phi-Ex wormhole  Port Interface    
Network.
• 1951:  1951 White Eagle-Dove Alliance.  (AKA ''Archangel Michael joins Enoch''). Pro-Anunnaki Necromiton-    
Andromies make deals with Jehovian Anunnaki to combine and activate their respective '' White Eagle '' and '' Dove ''   
APIN systems  to regain Anunnaki OWO dominion over Illuminati force and Earth’s Templar. Attempt to open    
Phoenix Wormhole off eastern coast of Florida. Unsuccessful until 1972. Zeta-Rigelians continue Un-Natural    
Disaster/Ethnic Virus testing, covert Interior Government contact, abductions throughout 1950s-1960s. 
• 1972:  Pleiadian-Nibiruian Anunnaki assist White Eagle-Dove Alliance (AKA. “Samjase, Thoth, Galactic Federation    
and Ashtar Command join Archangel Michael and Enoch) to break through cap on Phoenix wormhole via Solar    
SG-4 sonic transmissions, begin activation of the Phoenix, Serpent , Dove  and White Eagle APIN systems;    
intensifies Solar anomalies from 1943 Phi-Ex opening to Solar Fl are/Red Pulse crisis point. GA implements    
11:11/12:12 Frequency Fence to prevent 1973 Red Pulse destruction, initiate Solar SG-4 repairs. Anunnaki begin    
 regaining strength in Illuminati World Management Team.                        
                                                                                              ©2002 Ashayana Deane
                           519                                                  
                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                   

   2001 Update Summary Charts
• 1980s:  Rigelian-Andromie Alliance. Zeta-Rigelians make deal with Pro-Drakonian Necromiton-Andromie forces, Omicron-
Drakonian races of Alnitak and Dracos hybrids of Earth get directly involved and combine APINs to prevent Anunnaki groups from 
getting upper hand in Illuminati World Management Team. 1983 Falcon-White Eagle- Dragon Alliance.
• 1983:  M o n t a u k  P r o j e c t  orchestrated by Rigelian-Andromie Alliance, further connects Phi-Ex Falcon APIN system of Earth/
Phantom Earth to Phantom Alpha and Omega Centauri and Alnitak Orion . Create Montauk-Phi-Ex Falcon APIN system. 
Drakonian Agenda races regain dominance in World Management Team. Falcon-White
Eagle-Dragon become “ Superpower ” and sets sites on overtaking Anunnaki APIN systems. White Eagle-Dove Alliance seek 
dominion of Phoenix and Serpent APIN’s to prevent Drakonian Agenda advancement. 1983-1984 GA initiates Bridge Zone Project 
and begin Emerald Covenant peace treaty negotiations with Fallen Angelic groups. 1986 GA 9540BC Frequency Fence released.
• 1992 : Pleiadian-Nibiruians (Pleiadian Samjase-Luciferian and Nibiruian Thoth-Enki-Zeta and Enlil-Odedicron Anunnaki ) 
attempt to cap Falcon wormhole to prevent Falcon-White Eagle-Dragon group from overtaking NDC- Grid system. Falcon group 
uses sonics on August 12 , to expand Falcon wormhole , preventing attempted Anunnaki cap; Hurricane Andrew hits east 
coast US August 24 as result of Falcon wormhole expansion and sonics. White Eagle-Dove group continue campaign for control of 
Phoenix wormhole, related APIN’s and Giza.
• 1992 November : Pleiadian-Nibiruian, Galactic Federation and Ashtar Command Anunnaki grudgingly enter Pleiadian-Sirian 
Agreements/ Emerald Covenant, White Eagle-Dove refuse, when Falcon-White Eagle-Dragon Drakonian Agenda races nearly take 
over Phoenix and Serpent APIN’s, NDC-Grid, NET and Giza/Mexico Nibiruian Crystal Temple Network.
• 1992-1994:  Emerald Covenant races with assistance of Pleiadian-Sirian Agreements Anunnaki use Nibiruian NET and NDC-Grid 
to temporarily CAP Falcon wormhole , shutting down Montauk-Phi-Ex Falcon APIN system . Anunnaki races vow to turn 
NDC-Grid, NET and Phoenix-Serpent APIN systems over to Emerald Covenant Founders by 2000 SAC start, for co-operative 
progression of Earth Freedom Agenda and Planetary Christos Realignment Mission.
• 1994-1998:  Pleiadian-Sirian Agreements Anunnaki races gain dominance in Illuminati World Management Team, supposed to 
(as per 1992 Agreements) begin preparing Illuminati for '' Official Disclosure ''/ entry into Emerald Covenant. GA 11:11/12:12 
Frequency Fence released . Rebel Anunnaki groups form and begin using '' Phantom Pulse '' tracer sub-space electrical 
transmissions along known electrical lines for Psycho-tronicsand Anunnaki APINs/NCT-Bases “hi-jack”.
• 1998:  ''Arc Spark'' grid acceleration confirms 2000-2017 SAC will commence in 2000, most Anunnaki join rebel groups/ defect 
from Pleiadian-Sirian Agreements for opportunity to fulfill their original Luciferian Covenant OWO agenda. Anunnaki began 
shutting down Emerald Covenant communication lines in the NDC-Grid, NET and APIN systems. Falcon-White Eagle-Dragon 
Drakonian Agenda group blow CAP off Falcon wormhole, begin competitive campaign to achieve Falcon APIN and illuminati 
dominance. Begin reactivation of Montauk-Phi-Ex- Falcon APIN.
• 1998-1999:  Competing factions of White Eagle-Falcon-Dragon, Rebel Dragon, White Eagle-Dove and Phoenix- Serpent groups 
compete for APIN grid activation, territory dominion and Illuminati dominance. New Age Movement Anunnaki OWO agenda 
“Astral Tagging” domain, UFO Movement Drakonian OWO Agenda “Astral Tagging” domain, numerous Rebel factions from each 
group. White Eagle-Falcon-Dragon continue activation of Montauk-Phi- Ex Falcon APIN sites. Competing White Eagle-Dove and 
Phoenix-Serpent groups accelerate their respective APIN activation.
• 1999:  GA continue GF, Ashtar, Thoth, Samjase, Anunnaki, renegade negotiation in hope of reestablishing Pleiadian-Sirian 
Agreements to prevent escalation of Final Conﬂict drama. Drakonian groups begin Psycho-tronic
Sonic Pulsing to USA, Jerusalem and China for instigation of the WW3 drama; pulses slow-release, intended to take effect end 
2002-2003 .
• 2000  January  1: G A Planetary Shields Clinics start. Emerald Covenant nations/Indigos succeed in activating Earth’s Templar 
on a 12-Code Pulse during 1/1/2000 Grounding of Stellar Bridge. Emerald Covenant races now have ability to override Fallen 
Angelic NDC-Grid, NET, NCT-Bases, APINs, close Atlantian Wormholes and fulfill 22,326BC Planetary Christos Realignment 
Mission; IF critical mass 12-Code-Pulse can activate in Earth’s Templar before 2003 .
• 2000  July 5: Most Pleiadian-Nibiruian Anunnaki and a few Jehovian Dove and Odedicron-Reptilian factions temporarily agree to 
Emerald Covenant Treaty of Altair , due to likelihood of either Emerald Covenant or Drakonian Agenda defeat. Emerald Covenant races 
begin 12-Code-Pulse grid re-coding and Human DNA Template
clearing and activation’s.
                                                                      ©2002 Ashayana Deane
           
\
       520

                  2001 Update Summary Charts
• 2000  August:  Peru, Treaty of Altair races begin transfer of Phoenix, Serpent APINs, NDC-Grid and NET to Emerald 
Covenant control. Emerald Covenant /Indigo races advance 12-Code-Pulse clearings, threatens to override ALL 
OWO agendas by building Planetary Maharic Seal Earth protection field.
• 2000 September 7: Necromiton-Andromie White Eagle groups unite, negotiate Jehovian Anunnaki Dove, Falcon- 
Dragon, GF and Ashtar “friendly enemies” deals to combine White Eagle-Dove-Falcon-Dragon APINs to defeat 
Emerald Covenant and Treaty of Altair Anunnaki races. Necromiton-Andromies petition Pleiadian-Nibiruian Phoenix- 
Serpent and renegade Anunnaki of Treaty of Altair to combine agendas and APINs to enter United Intruder 
Resistance (UIR) OWO Master Plan .
• 2000  September  12: Pleiadian-Nibiruian Anunnaki defect from Treaty of Altair , join UIR, allow Necromiton- 
Andromies/ Omicron-Drakonians to use previously secure Phoenix APIN grids, England, for Indigos Psycho-tronic 
attack. UIR gives ultimatum to Emerald Covenant Founders to abandon Earth and Humans to UIR genocide 
agenda in return for evac’ of 50,000 Indigos (out of 550,000). Emerald Covenant Founders reject UIR attempted 
Black Mail . UIR initiates official Edict of War against Founders, all Emerald Covenant and Human races. GA 
reverts to original December 21,2012 Christos Realignment Mission, begins War Crisis Order and Masters 
Templar Planetary Stewardship Initiative RRT Intervention.
• 2001  May:  Emerald Covenant races initiate Crisis Intervention, early-open Sirius B Star Gate-6 and ancient Halls 
of Amorea Passage in May 2001 , to prevent UIR intended 2003 Dimensional Blend Experiment , Frequency 
Fence and WW-3 invasion schedule. Expedited Amenti Opening and Planetary Seals Release begins. (See Crisis 
Intervention Expedited Amenti Opening Schedule Chart ).
• 2001  August  12: Mass Awakening DNA 12-Code activation begins; UIR expedites OWO ''First Contact'' Invasion 
agenda, accelerates Montauk-Phi-Ex Falcon APIN activation to initiate Phoenix-Serpent-Dove APIN/ Falcon 
Wormhole link. UIR launch 2 ''ULF Sonic Amplification Slow pulses '' from Chihuahua, Mexico and Lake 
Titicaca Peru . NCT-Bases.
• 2001  September  3: Mexico Sonic Amplification Slow-Pulse passes through SG-2 Gru-Al Point Sarasota, FL as 
Indigos assemble for RRT to realign Sarasota FL and Bermuda NCT-Bases. Thoth-Enki-Zeta Nibiruian Anunnaki 
group via Chihuahua Mexico site sends Psycho-tronic “rapid release” pulse along Amplification Slow-Pulse 
frequency to attack RRT group in hope of preventing September 3 RRT. RRT partially successful.
• 2001  September  7: Sonic Amplification Slow-Pulse continues along Ley Line-4 to intersect/bond with Titicaca Sonic 
Amplification Slow-Pulse at Axiatonal Line-7 (70W Longitude). Bonded Sonic Pulse drawn through Phoenix and 
Falcon Wormholes to SG-3 Bermuda Zeta-Rigelian NCT-Base. Sonic Amplification Pulse charge collects at Bermuda 
NCT-Base.
• 2001  September  11: W T C / P e n t a g o n  U I R  W W 3  ''Trigger Event .'' Sonic Amplification Pulse combined with 
''Trumpet '' long-range remote pulses from Phantom Sirius A, Arcturus and Trapezium Orion ''Dove''APIN. 3 
amplified rapid-fire combined Trumpet/Slow-Pulse sub-space sonic pulses , sent from Bermuda Base to NY and 
DC targets , via the Montauk/ Philadelphia APIN sites of Montauk-Phi-Ex-Falcon Port Interface system . The 
4th ''Trumpet Pulse'' not sent to Philadelphia target, as 4 th terrorist plane ''Cloak Event'' did not make it to site. “ 2001 
September 11 UIR successfully linked/ activated WTC/NYC and Pentagon/DC Phoenix Spike sites to Falcon 
Wormhole and APIN system . Terrorist attacks as “ Cloak Event ” cover to hide Sonic Pulse activity damage to
the WTC and Pentagon buildings.
©2002 Ashayana Deane
521

2001 Update Summary Charts                 
     Sonic Pulse “Un-Natural Disasters” 1935-1992 Summary Chart
 Caused by covert Fallen Angelic/Intruder ET and Illuminati use of scalar pulse technologies 
                                                            Earthquakes:
     Date:                            Location:                Mag.                    Sonic Pulse Action
 1935 May 30                 Quetta, Pakistan           7.5           Zeta Population Reduction Test
 1938 November 10       Alaskan Islands             8.3          Falcon Sonics Test
 1939 January 25            Chillan, Chile               8.3          Falcon Population Reduction Test
 1939 December 26        Erzincan, Turkey          8.0          Zeta-Andromie land dispute
 1942 November 26       Turkey                           7.6          Zeta-Andromie land dispute
 1942 December 20        Erbaa, Turkey               7.3          Zeta-Andromie land dispute
1943 September 10       Tottori, Japan                7.4          Phi-Ex Falcon APIN August 12
1943 November 26       Turkey                        7.6           Phi-Ex Falcon APIN August 12
 1944 December 7          Tonankai, Japan            8.3          Zeta-Andromie Phi-Ex dispute
 1945 January 12            Mikawa, Japan              7.1          Zeta-Andromie Phi-Ex dispute
1945 November 27       Iran                                8.2          Falcon Phi-Ex Port link August 12
1948 October 5             Turkmenistan USSR     7.3          Falcon Population Reduction Test
1950 August 15             India/Tibet                    8.7          Falcon Maji Population Reduction
1952 July 21                  Kern County, CA         7.5           Falcon Illuminati Reduction Demo
1954 September 9         Algeria                          6.8          Falcon A11/L4-10 link August 12
1954 December 16        Dixie Valley, NV          7.3          Falcon Phi-Ex Port link November
1957 March 9                Alaskan Islands            8.8          Falcon Sonics Test
1957 July 2                    Iran                               7.4          Falcon-Dove SG-10 land dispute
1957 December 13        Iran                               7.3          Falcon-Dove SG-10 land dispute
1958 July 10                  Lituya Bay, Alaska       8.3          Falcon Sonics Test
1959 August 18             Montana                       7.3          Phi-Ex Falcon APIN August 12
1960 May 22                 Chile                             9.5          Falcon Maji Population Reduction
1963 July 26                  skopje, Yugoslavia       6.0          Dove APIN site activation
1966 August 19              Varto, Turkey              7.1           Zeta-Andromie land dispute
1968 August 31              Iran                              7.3          Falcon APIN site SG-10 activation
1970 March 28               Gediz, Turkey             7.3           Andromie-Dove raid on Falcon
1970 May 31                  Peru                             7.8           Falcon Phi-Ex Titicaca Port link
1972 April 10                 S. Iran                          7.1           Phoenix wormhole February open
1972 December 23         Nicaragua                    6.2           Phoenix APIN site November 22
1974 December 28         Pakistan                       6.2           Phoenix APIN site November 24
1975 September 6          Turkey                         6.7           Phoenix APIN site August 12
1976 February 4             Guatemala                   7.5           Serpent APIN activation
1976 May 6                    Italy                             6.5           Dragon-Serpent land dispute
1976 July 27                   Tangshan, China         8.0           Dove APIN site SG-8 activation
1976 August 16              Philippines                  7.9           Serpent-Phoenix APIN dispute
(more between 1976-1983 Iran, Italy)
 1983 October 30             Turkey                        6.9          Falcon-Eagle vs Dragon dispute
 1985 September 19         Mexico                       8.1          Serpent APIN site amplification
 (more between 1985- 1992 India, Turkey, Iran)
 1993 September 29         S.India                       6.3           Falcon-Eagle fight Phi-Ex cap
 1998 February 4              Afghanistan               6.1           Phoenix-Dragon APIN site dispute
 1998 May 30                   Afghanistan               6.9           Phoenix-Dragon APIN site dispute
 2001 January 26              India                          7.7           United Resistance raid GA APIN
 
 Sample of Related Hurricanes (many more too numerous to mention, various regions)
    Related to Fallen Angelic/Intruder ET/Illuminati Sonic Pulse and Falcon/Phi-Ex/Phoenix activity  H=Hurricanes
1919  FL, TX –H Falcon wormhole open cycle.     1958  Japan – Typhoon “Vera” Phi-Ex
1935 FL Keys – H Falcon Sonic Pulse                   1960  FL, East US- H “Donna” Phi-Ex
1944  Northeast US – H Phi-Ex                               1965  FL, LA – H “Betsy”  Phi-Ex
1955  Northeast US – H “Diane” Phi-Ex                           1972 Northeast US- H Agnes Phi-Ex amp
1992 August 24, - H Andrew, FL- 215-350mph winds –Zetas ﬁght Aug.12 Falcon Cap
                                                      
                                                   
                                       ©2002 Ashayana Deane  
522
         

                                                                                                                                                                                                                                   
2001 Update Summary Charts
                       
                                     24 United Intruder Resistance Nibiruian Crystal Temple Bases
                                                    (Underground or Underwater Illuminati Main Templar Control Bases)
CB =  Central Control Bases that direct operations of other Bases. MIB=  “Men In Black” Necromiton-human hybrid
1,  Kauai Hawaii, Cue Site-12- Necromiton-Andromie-Nephilim, Zephelium-Rigelian Zeta, Alpha-Omega Centaurians
2.  Vale of Pewsey S. England, SG-11: Pleiadian Samjase-Luciferian Anunnaki
3.   Abadan Iran SG-10- Odedicron-Reptilian Orion
4.  Pakistan CB: Omicron-Drakonian, Marduke-Dramin-Anunnaki and Necromiton-Andromie Nephilim
5.  Bermuda Island SG-3- Omicron-Drakonian and Zephelium-Rigelian-Zeta
6.  Sarasota Florida SG-2 Gru-AL- Thoth-Enki-Zephelium Anunnaki and Necromiton-Andromie Nibiruian Nephilim
7.  Machu Picchu Peru SG-5-  Pleiadian Samjase-Luciferian-Anunnaki
8.  Portugal CB-  Omicron-Drakonian, Necromiton-Andromie MIB and Odedicron-Reptilian
9.  Lake Titicaca Peru SG-7-  Omicron-Drakonian, Rigelian-Zeta and Pleiadian Samjase-Luciferian Anunnaki
10.Giza Egypt SG-4-  Omicron-Drakonian
11. Halley South Pole SG-1- Necromiton-Andromie MIB, Drakonian Dracos, Omicron-Drakonian, Rigelian-Zeta
12. Mauritania W.  Africa CB-  Omicron-Drakonian, Necromiton-Andromie MIB, Zeta Rigelian, Thoth-Enki-Zephelium     
Anunnaki
13. Paxos Island Greece Cue Site-7- Necromiton-Andromie MIB, Alpha-Omega Centaurians, Pleiadian Samjase-    
Luciferian Anunnaki.
14. Aguascalientes Mexico Cue Site-4-  Thoth-Enki-Zephelium Anunnaki, Rigelian-Zeta and Jehovian-Anunnaki
15. Cyprus Island Cue Site-1-  Omicron-Drakonian, Necromiton-Andromie MIB
16. Easter Island Cue Site-2-  Pleiadian Samjase-Luciferian-Anunnaki and Nibiruian Thoth-Enki-Zephelium Anunnaki,     
Enlil-Odedicron-Anunnaki.
17. Vatican City Rome Italy Cue Site-5-  Drakonian-Drakos, Omicron-Drakonian
18. Johannesburg S.  Africa Cue Site-3 – Omicron-Drakonian, Marduke-Dramin-Anunnaki
19. Brazil CB-  Marduke-Luciferian-Anunnaki Alpha Centauri, Enlil-Odedicron-Anunnaki Nibiru, Pleiadian Samjse-    
Luciferian-Anunnaki
20. Lop Nor Tibet Cue Site-8-  Jehovian-Anunnaki, Galactic Federation, Ashtar Command and Necromiton-Andromie     
Nephilim (Dove APIN central broadcast control)
21. Xian China SG-8- Omicron-Drakonian, Necromiton-Andromie MIB
22. Hamandan Iran CB-  Odedicron-Reptilian 
23. Al Basrah Iraq Cue Site-10- Drakonian-Dracos, Omicron-Drakonian, Necromiton-Andromie MIB
24. Bosnia CB-  Drakonian-Dracos, Necromiton-Andromie MIB and Nephilim , Marduke-Dramin-Anunnaki, Alpha-     
Omega Centaurians. (“Archangel Michael” broadcast central headquarters). 
There are many thousands of other UIR hidden bases positioned throughout the globe;     
the above 24 are the Primary Bases, located at the ancient Nibiruian Crystal Temple     
Pylon Crystal sites, through which the Planetary Templar and other bases are     
 controlled. Both UIR and Guardian subterranean bases are protected by UHF Cloaking    
                 Fields that are impermeable to present means of Earthly technological detection.
                                                                      
                                                                       © 2002 Ashayana   Deane  
                          
                            
                            525

                                                                                     2001 Update Summary Charts
          
     Angelic Human 12-Tribes and Indigo Maji Grail Lines Summary Chart
The ORIGINAL HUMAN 12-TRIBES Race Names that were edited from Essene CDT-Plate Biblical Translations 
TRIBE-1: Isutu-Esheau (Pronounced: I sU’ too-  E’ shoo). 
Star Gate DNA Signet Codes, Seed Locations and Races: SG-1. Arizona USA V ortex-1 Native American, Cue Site-1 Cyprus Island in      
Mediterranean Sea, Australia, Turkey and Greece and Antarctic SG-1 in Atlantian periods. Maji Indigo Grail Line : Original blue and      
green-eyed Australian Aborigine; often red haired.
TRIBE-2: Maahali-Bruea (Pronounced: Ma a ha’ LE- BrU’ A) 
Star Gate DNA Signet Codes, Seed Locations and Races: SG-2. Florida Seminol Native Americans SG-2 Sarasota Florida, and        
Breanoua black and brown skinned Haitian-Bimini Island races. Easter Island Cue Site-2 Muavaharivi and Jerusalem Israel V ortex-2      
Hebrew races. Maji Indigo Grail Line : Mu’A of Lemuria (Hawaii), Easter Island and Southwestern Native American descendant        
tribes. Original Hebrew (Hibiru Cloister and Melchizedek Cloister hybrid) races of Jerusalem and Jordan. 
TRIBE-3: Amekasan-Etur (Pronounced: a ME’ ka sun – e too’r). 
Star Gate DNA Signet Codes, Seed Locations and Races: SG-3. Nohassa Atlantis Bermuda Islands SG-3, Johannesburg South       
Africa black, brown and white skinned races and Nepal V ortex-3 Himalayas. Maji Indigo Grail Line : White-skinned Druedeks of      
Nohassa Atlantis.
TRIBE-4: Nuagu Hali (Pronounced: Noo ah’ goo- ha’ LE). 
Star Gate DNA Signet Codes, Seed Locations and Races: SG-4. Giza Egypt SG-4 and Sumerian UR, Aguascalientes Mexico Cue       
Site-4 and Central America. Maji Indigo Grail Line : Serres-Egyptians, original pre-Anunnaki Maya-Toltec and Mexicali Indians.
TRIBE-5: Ionatu-Etillah (Pronounced: I  O’ Na too- et il’ a) 
Star Gate DNA Signet Codes, Seed Locations and Races: SG-5. Machu Picchu Peru Incas SG-5, original Ionian Italic (Italian) races.  
Maji Indigo Grail Line : Mu’A-Incas of Machu Picchu Peru and light skinned-often fair or red-haired Celtic-Druedek Mu’A Ionians      
(combined Maji Grail Line of  Nohassa Atlantis Tribe-3 Maji Druedeks and  Lohas Atlantis Tribe-11 Maji Celteks exiled to Ionia as       
Anunnaki Leviathan raiding progressed.) 
TRIBE-6: Ramyana-Shridveta (Pronounced: Rah ma yah’ na- shrid vE’ Da). 
Star Gate DNA Signet Codes, Seed Locations and Races: SG-6. Russia Caucasus Mountains SG-6 and Scandinavian white skinned      
blond haired races, brown-skinned Rama races of India Thar Desert Cue Site-6. Maji Indigo Grail Line:  Rama-vita races of India      
and original blue-eyed blond Nordic races of Scandinavia and Russia. 
TRIBE-7: Mahata-Agrah (Pronounced: ME hah’ ta- a’g-ra) 
Star Gate DNA Signet Codes, Seed Location and Races: SG-7 Lake Titicaca Peru Incas and indigenous olive-skinned peoples of
Paxos Island Greece. Maji Indigo Grail Line : Original Mahata-Incas Lake Titicaca Peru ( ﬂed from Intruder raiders to Kauai Hawaii)      
and original olive-skinned green-eyed Ionians of Paxos Island.
TRIBE-8: Chia Zhun Zan La-Y ung (Pronounced:  ChE’ ah-Zoon – Y an LA-Y oong’). 
Star Gate DNA Signet Codes, Seed Locations and Races: SG-8. Xian China SG-8 original yellow-skinned races, and original brown-      
skinned races of Taklamakan Desert Tibet. Maji Indigo Grail Line:  Original YU-Melchizedek Tibetan light-brown-skinned, light-eyed       
races of Lop Nor Taklamakan Tibet region before Necromiton-Andromie Nephilim raiding and Yu-Chinese lineage.
TRIBE-9: Y un Zu-Xen (Pronounced: Y u-Un Zoo-Zen) 
Star Gate DNA Signet Codes, Seed Locations and Races: SG-9. North of Llasa Tibet SG-9 brown-skinned races and Westbury area      
Southern England white-skinned, dark-haired races Cue Site-9. Maji Indigo Grail Line:  YU-Mu’A Chinese and dark-haired, dark-      
eyed fair-skinned original English Mu’A Melchizedek races. 
TRIBE-10: Ma’ah-hu-ta (Pronounced: Ma-a hoo’ ta). 
Star Gate DNA Signet Codes, Seed Locations and Races: SG-10.  Sumerian UR, Persian Gulf Abadan Iran SG-10 area and Al       
Basrah Iraq Cue Site-10 area. Many family lines ﬂed to Sakkara Egypt and regions now called Afghanistan and Uzbekistan during        
early Sumerian raids; continue to live under persecution of Leviathan Illuminati races. Maji Indigo Grail Line: Light-brown-skinned      
light-eyed, dark-haired races and dark-eyed Essene-Melchizedek races of Persia, now most in Afghanistan, Uzbekistan and Russia. 
TRIBE-11: Zephar-Duun-Atur (Pronounced: Ze-far-Doon a-Tur). 
Star Gate DNA Signet Codes, Seed Locations and Races: SG-11. Southern Ireland Cue Site-11, Vale of Pewsey area Southern       
England SG-11, Scotland lowlands; white-skinned European races now in England, France, Russia, USA and Germany. Raided by      
Pleiadian-Samjase-Luciferian-Anunnaki Germanic “Sacheons”/Saxons. Maji Indigo Grail Line:  Celtek-Druedek hybrid Azurta-Arutus    
 “Celtic-Druids”, white-skinned, frequently red-haired. The true “King Arthur” Grail Line. 
TRIBE-12: A-reah-Azurta (Pronounced: a-RI’-a  Zoor’-ta). 
Star Gate DNA Signet Codes, Seed Locations and Races: SG-12. Monsegur Southern France SG-12 white-skinned and original       
MU’a Lemurian Kauai Hawaiian brown-skinned, dark-eyed races; exiled to Easter Island and Machu Picchu Peru (builders). 
Maji Indigo Grail Line : Original Mu’A Kauai Hawaiian brown-skinned and KatharA-Cathari white-skinned races of Southern France. 
                                                   © 2002 Ashayana Deane   
 
531                                    

                          
                        2001 Update Summary Charts
                            Intruder  ET and Illuminati Races of the 2001 UIR OWO Team Summary Chart Introduction.
                                                   Illuminati Hybrid Humans, Unity-Through-Diversity and Reclaiming Christos Potentials
  ''Primary Leviathan Illuminati Races ''/'' Human Tribe Infiltration '' refer to Illuminati hybrid race imposters         
within a given HumanTribe, and select family lines within a given Human Tribe that have been genetically    
compromised by Illuminati-hybrid interbreeding. These categories do not imply that named ethnic af ﬁliations    
are dominated by Intruder race genetic distortion; Illuminati ( non-human Intruder race souls) and In ﬁltrated     
family lines (Human souls, Intruder DNA attachments) make up the minority  in each Human ethnic group.    
Understanding the common problem  of Intruder race in ﬁltration now shared by all human cultures  should     
 allow for the advancement of a common ground problem-solving Human Unity Through Recognized      
Diversity , built upon inter-racial equality, respect, love and compassion. This knowledge IS NOT an    
excuse  to apply the Anti-Christos hatred creeds  of bigotry, race supremacy or prejudice against any      
lineage.  If successful in their “First Contact” invasion plan, the UIR intend to use “contrived historical and    
distorted genealogical” falsiﬁed “evidence ” to indicate that all Human races are a “common genetic lineage”    
derived from their combined Anunnaki-Sirian and Drakonian-Reptilian “stock”. This False Human Unity     
promotion  is intended to vanquish true Angelic Human Race identity  and obscure Illuminati-hybrid    
presence  to prepare us all for a “common uni ﬁed takeover” under a false UIR  “Creator God” platform. TRUE    
Human Unity  will be gained through loving identi ﬁcation of the Species Diversity  that exists within the     
“Common Chemical Clothing” of the “contemporary Human form”. Il luminati and in ﬁltrated Human family lines      
can make the choice to refuse Intruder association and opt for Emerald Covenant DNA Template Bio-           
Regenesis to continue their evolutionary path toward Christed Mastery, if they are aware of the evolutionary     
challenges and required solutions posed by Intruder race genetic connection.  Angelic Human/Indigo,       
Illuminati and In ﬁltrated races can all evolve to genuine “Christed Race” status and freedom . Due to                                                                
inherent genetic and Core Template differences, each group requires a different evolutionary path  by which     
the DNA Template, bio-energetic ﬁeld and consciousness template can reclaim the Base-12/D-12 Pre -matter    
“Divine Blueprint ” template coding required to attain genuine biologically based “ Christed Avatar     
Consciousness ”/ minimum 12-Strand DNA Template  potential. If the diversity within the illusion of the      
“Common Human Genome” is not recognized, all races will remain trapped within the present state       
of Common Race De-Evolution  through which the Christiac genetic potentials within each di versiﬁed race will     
become lost in progressive degeneration to race extinction.                
Most Human beings of Illuminati and In ﬁltrated Human race descent have no consciousness knowledge of      
their connection to Fallen Angelic Intruder ET races; nor are they aware that their genetic signature pre-      
disposes them to Intruder manipulation. This physical/emotional/mental/spiritual vulnerability to Intruder     
manipulation can be overcome if the individual comprehends the importance of utilizing genuine Founders     
Inner Christos Spiritual-Science teachings and technologies. Inner Christos D-12 Divine Blueprint sciences     
and Maharic Bio-Regenesis Technologies are the only methods by which regeneration of the DNA Strand      
Template–12 personal D-12 Pre-matter Divine Blueprint can occur to restore the individual’s direction      
connection to its D-12 Christos Avatar Identity. The Founder’s Bio-Spiritual Technologies allow the original    
connection to the Primal Light/Sound Fields to be restored  via reactivation of the 9-dimensional      
Antahkarana-Kundalini Cord  and 12-Dimensional Maharata Cord  Primal Life Force Currents.  Genetically    
vulnerable humans and Illuminati hybrids are loved by God/Source just as much as any other race  and can    
regain their freedom, free will, Bio-Spiritual Integrity and genuine Christos potential  through entering a    
chosen path of conscious evolution  built upon the genuine Founders Inner Christos spiritual/science     
teachings . Illuminati and in ﬁltrated races are victims to Intruder exploitation just as are Angelic Human and     
Indigo race lines. Like numerous Fallen Angelic races, Illuminati human-hybrid races can evolve beyond    
exploiting, abusive behaviors ; they need Love  (Tough Love  usually works better than Soft Love, which     
fallen races tend to exploit), Healing  and Inner Christos Spiritual  education , not judgment, condemnation     
and destruction, to reset and develop the Christos Potentials within themselves.   
                                                     © 2002 Ashayana Deane     
               
             532    
           
                                                                                                                                       

              
                                                                                                         2001 Update Summary Charts
     
                    Intruder ET a nd Illuminati Races of the 2001 UIR OWO Team Summary Chart (5 pages)
                              Phantom Matrix Andromeda and Centaur Intruder Races       •       
     Necromiton-Andromie : (Fallen Anu-Seraphim hybrid Andromeda) . Phantom Andromeda Planets, Alpha/Omega                               
       Centauri, Inner Earth. APIN System: “White Eagle” ('hi-jacked” GA “Gold Eagle” APIN). Falcon and Phoenix         
        Wormholes. Primary Races: Raelian “Elohim” Necromiton-Andromie insectoid-Beetle-People. Jehovian-Anunnaki-       
        Andromie-Human Nephilim dark-haired aquatic humanoid. /Annu-Melchizedek-Amealian-Nephilim. Hybornean-       
        Jehovian-Nephilim. Men-in-Black Human-insectoid hybrid Earth/Inner Earth. Marduke-Luciferian-Andromie-        
        Anunnaki insect-hominid hybrid. Omicron-Drakonian-Andromie “Vampire” serpent-dino-humanoid hybrid. Noors            
        Red Haired Humans (Omicron-Drakonian-Necromiton-Andromie-Pleiadian Human hybrid) Phantom Lyra        
        Vega/Pleiades/Alnitak (Orion-Necromiton Black League). Adalphi Blue Zeta (Necromiton-Andromie-Zeta Rigelian                   
        hybrid) Phantom Alpheratz, Andromea. Core Agendas : Andromie-Drakonian Drakonian-Orion Confederation    ,     
        Andromie-Anunnaki-Luciferian Pleiadian-Nibiruian Coalition,  Andromie-Anunnaki-Jehovian, United Federation of                  
        Planets , Andromie-Centaruian Alpha-Omega Order ;  Andromie-Supremacists Orion-Necromiton Black League .      
        Primary Leviathan Illuminati Races : Taozan King Atlantian Leviathan Illuminati lines, Asian Scarab and        
        Sadducees-Semetic Dragon Kings Leviathan Illuminati lines. Human Tribe in ﬁltration: Mongolian, China/ Japan/                  
        Tibet (Yu), Brazil, Chile, Turkey, Anastazi Native American, Hebrew. Associations: Buddhaic/ Tibetan/ Eastern/                
        Christian spiritual text distortions, the “Necromancy” Luciferian-Satanic Bible, Luciferian Egyptian/Tibetan/Mayan       
        mystical teachings, Alpha-Omega Templar Melchizedeks, “Lord Melchizedek”/“Archangel Michael”/”Angelic        
        Hierarchy”/ ''Kryon”/ ''Corteum '' Nephilim Anunnaki-Andromie hybrids.  False “Sananda-Jesus” contacts, Fallen                
        “Vairagi” false ''ascended masters, '' “Thule Society”, “Andromie” ET contact/channeling. ''Friendly Enemy'' allies       
        Marduke-Luciferian/ Marduke-Dramin(Omicron) Anunnaki /Jehovian-Anunnaki Nephite-Nephilim collectives.  Began       
        UIR 2000  / War Edict. UIR head.
•	Centaur-Luciferians and Blue Centaurs : (Fallen Anu-Seraphim hybrid Omega Centauri). Phantom Alpha and        
Omega Centauri. APIN System: “The OX” (Hi-jacked Maharajhi “Blue Oxen” APIN). Primary Races: Blue Centaurs      
Phantom Omega Centauri, Centaur-Luciferian Hominid-Centaurs (Marduke-Luciferian-Anunnaki-Centaur hybrid)       
Phantom Alpha Centaur/ Phantom Sirius B. Core Agenda : Centaurian-Necromiton-Andromie Centaurian Nation        
and Alpha-Omega Order . Primary Leviathan Illuminati Races:  Taozan King (Andromie-Anunnaki-Atalan King       
hybrid)/ Bhud-Rama King (Fallen Rama-Anunnaki-Andromie hybrid) Atlantian Leviathan Illuminati lines. Human       
Tribe Inﬁltration: India, Middle East, Pakistan, Turkey, the “Stans”, various Islands. Associations: Hindu/ Sanskrit      
Islamic text distortions, various Shamanic, Pagan, Druid, and WICCAN tradition distortions. Work with Andromie-           
Necromiton, some with Rebel Omicron-Drakonians. Joined UIR 2000  with Andromies. 
                                                                              
                                                                            Phantom Matrix  Zeta Intruder Races
•	Zeta-Rigelian/Zeta-Reticuli Zephelium : (Fallen Seraphim Lyra Vega/Apexian-Lau) Phantom Rigel Orion, Zeta-       
Reticuli, Bellatrix, Nibiru, Andromeda, Phantom Earth and various other locations. Primary Races:  All Zeta emerge       
from Zephelium  (tall bipedal blue-skinned Insectoid-Reptilian-Serpent  seed race) ; many strains . Azazael ( Blue-        
   Human-Reptile Omicron-Zephelium hybrid) Bellatrix. Aggressive Zeta-Rigelian  Omicron-hybrid “Tall Greys” Rigel       
Orion, Rutilia  (E.B.E.) Zeta-Dracos hybrid. Zeta-Reticuli   “Short Greys”, several insectoid forms, various        
systems/Phantom Earth.  Thoth-Enki-Zephelium (Zeta-Reticuli-Amealian-Anunnaki) hominid hybrid Nibiru                
Kurrendara  Orange Zeta (Dracos-Anunnaki-Zeta Rigelian hybrid) Nibiru. Adalphi Blue Zeta (Andromie-Necromiton-        
Zeta-Rigelian hybrid) Alpheratz Andromeda. Core Agenda:  Zeta Reticuli  Zeta-Pleiadian-Nibiruian-Anunnaki       
Pleiadian-Nibiruian Coalition  or Emerald Covenant (refugee) GA. Zeta-Rigelian  Zeta-Drakonian Drakonian-Orion      
Confederation . APIN System: Zeta-Rigelian  “The Falcon” APIN/Falcon Wormhole. Zeta-Reticuli: Pleiadian-Nibiruian       
Phoenix/Serpent.  Primary Leviathan Illuminati Races: Zeta-Reticuli / Ezeural/Beli-Kadmon/ Atalan King (Thoth-       
Enki-Zephelium-Anunnaki Nibiruian) Atlantian Leviathan Illuminati lines.  Larsa King  Sumerian/Osirius King Egyptian       
 (Nibiruian Anunnaki-hybrid) Leviathan Illuminati Lines. Zeta-Rigelian/  Dragon King (Germanic) Atlantian Leviathan       
Illuminati Lines. Human Tribe In ﬁltration: Both groups have small ancestral lines in most human 12-Tribes and      
contemporary abduction hybrids and clones of “body-snatched” human bodies.  Associations: Zeta Reticuli-        
Opened Phantom Earth Falcon Wormhole 1903-1916 raided by Zeta-Rigelians.  Pleiadian-Nibiruian Samjase-       
Luciferian/Thoth-Enki-Zephelium allies. Most accepted 1983-1984 Emerald Covenant Amnesty/Redemption       
Contracts, some joined Pleiadian-Nibiruian Anunnaki, to escape Zeta-Rigelians. Zeta Rigelians-  Drakonian-Orion      
Confederation administration, MJ-12 and Nazi Zeta Treaties, enslaved Zeta-Reticuli,  “Zeta-Talk”, Thule Society,       
Allister Crowley/ “Black Sun”/ “Golden Dawn”/ “Enochian Watchtowers” metaphysical cults, Pagan teaching       
distortions, Philadelphia Experiment/Montauk Project, 1983 Rigelian-Andromie Alliance. Work with Drakonian      
Necromiton-Andromies, some Omicron-Drakonian/Odedicron-Reptilian factions, “Big Brother Drac” World      
Management Team Illuminati/ “Montauk Boys”. Joined UIR 2000  with Necromiton-Andromies. 
                                                                                           © 2002 Ashayana Deane  
                      533      
                                                                                                                                                              

                
                  
              2001 Update Summary Charts
                                       Phantom Matrix Drakonian and Reptilian Intruder Races
•	Omicron-Drakonian:  (Fallen Seraphim line of Lyra-Vega) Alnitak,-Alnilam Orion, Alpha Draconis, Bellatrix.  APIN      
System: “The Dragon”. Primary Races: Omicron Bipedal Dragon-Moth-insectoid-dino-reptiles Orion.  Dracos        
human-hybrid (Lizard-hominid, some “morph” to human-like) Earth/Inner Earth, Phalzants  (Chupacabras) Omicron-      
Odedicron-mammal-hybrids, Kurrendara Anunnaki-Omicron-Zeta hybrid (Orange Zeta hybrid) Nibiru, Azazael ( Blue-      
Human-Reptile Omicron-Zephelium hybrid) Bellatrix. Marduke-Dramin-Anunnaki insect hominid (Omicron-Anunnaki       
hybrid) Core Agenda:  Omicron-Drakonian , Drakonian-Orion Confederation . Primary Leviathan Illuminati Races:      
Nephedem-Omicron human-hybrids. Etruan King/ Etalian King (Atlas-Etruan King hybrid)/ Roman Remus King       
(Etalian-Lathin  King hybrid)/ Pharisees-Semetic Dragon King (Hibiru) and Hallah King (Hibiru) Atlantian Leviathan       
Illuminati lines. Dragon King (Sumerian/ Egyptian-Tuthmosis-Ramses/Chinese/Japanese/Germanic) Leviathan       
Illuminati lines. Human Tribe In ﬁltration: Middle East/Persian (Ur/Hibiru/Hebrew/Akkadian), Taliban, Sumeria,        
Ionian (Etruscan and Roman), German/Russian, Anglo-Saxon, Asian/China (Yu), African, Aztecs, Incas, Native       
American. Associations: Knights Malta Catholic  Templar Knights , Roman “Mof ﬁa”, Scots “McDonald” raider line,       
Nazi creeds, “Black Sun” mystical schools, Curendara/ “Dramin Dragon Queen” Shamanism (Native American/       
Peru/ Africa), Haitian/African “Voo-Doo”, Roman Catholic control creeds, Toltec-Aztec , Inca,  Islamic,        
WICCAN/Pagan, Reiki text distortions, false GA claims “Omicron” group. Zeta-Rigelian/ some Odedicron-Reptilian/      
Marduke-Dramin-Anunnaki allies. Most join UIR 2000 ; rebels refuse UIR for Omicron-Drakonian OWO agenda.      
•	Dracos:  (Fallen Seraphim-Human hybrid) Earth, Inner Earth, Alcyone/ Tara. APIN System: Access to Omicron-       
Drakonian “Dragon”, Zeta-Rigelian “Falcon” and Pleiadian-Nibiruian “Phoenix” APINs. Primary Races: Hominid-      
Reptile created 1 million years ago Earth via Omicron-Drakonian forced Human interbreeding. Core Agenda:       
Reptilian-Drakonian Drakonian-Orion Confederation . Primary Leviathan Illuminati Races: “Human-Lizard Shape-      
shifters” Nephedem-Dracos hybrids Earth/ Inner Earth. Human Tribe In ﬁltration: North-South American/ Brazilian/      
African/various island Tribal cultures, Middle Eastern, Egyptian, South/South-Mid Western USA, Cuba, Australia,      
England, Spain, Portugal. Associations: Various Shamanic tradition distortions, promote false “Environmental       
causes  /  Drak “technologies”/ “ET Contact demos”, utilize astral projection to initiate “astral-body sex” with Humans       
for D-4 astral-body bio- ﬁeld/DNA Template implanting, use sound-tones for D-4/Chakra-4 astral cording/ bio- ﬁeld      
Tagging in unsuspecting humans via public events. Work with Zeta-Rigelian/ Omicron-Drakonian/ Odedicron-       
Reptilian UIR groups, Nibiruian Kurrendara (Dracos-Anunnaki hybrids) and Marduke-Dramin-Anunnaki  (Omicron-      
Anunnaki hybrids). Most joined UIR 2000  with Zeta-Rigelians; some refuse UIR for Rebel Omicron-Drakonians. 
•	Odedicron-Reptilian:  (Fallen Seraphim line of Lyra-Vega) Alnilam Orion, Lyra-Vega, Inner Earth.  APIN System:      
 “The Falcon”. Primary Races: Odedicron Avian-Reptile “Gargoyle” winged reptile-hominid hybrids. Enlil Enlil-       
Odedicron-Amealian-Anunnaki hybrid Nibiru, Beli-Kudyem Odedicron-Anunnaki-Turaneusiam-Human hybrids       
Alcyone/Tara.  Core Agenda: Reptilian-Drakonian, Drakonian-Orion Confederation  or Reptilian-Anunnaki Pleiadian-      
Nibiruian Coalition .  Primary Leviathan Illuminati Races: Nephedem-Odedicron human-hybrids Earth/Inner Earth,      
Lathin King Atlantian-Greek and Arcadian King Illuminati line, Roman Romulous King (Etalian-Lathin King Atlantian      
hybrid) Illuminati line, Atlas King, Sumerian-Egyptian Horus King (Enlil-Odedicron-Anunnaki-hybrid) Leviathan       
Illuminati line. Human Tribe In ﬁltration: Egypt , Central America, Native American, Mexico, Hawaii, Polynesian       
Island, South America, South Africa, Ionia (Italy/Greece), England, Germany. Associations:       
Egyptian/Pagan/Shamanic/Kahuna mystical teaching distortions, Egyptian “Crocodile Cults” and “Falcon Cults”,       
Malaysian “Voo-Doo”, “Lord Maitreya”, Christian texts distortions. Some work with Odedicron-Drakonian Dragon-      
Moths, others with Zeta-Reticuli Greys and Pleiadian-Samjase-Luciferian-Anunnaki; most joined UIR 2000 , a few      
factions joined Rebel Omicron-Drakonians. Several factions in Emerald Covenant Redemption Contracts. 
                                                                                  © 2002 Ashayana Deane
               
               
              534    
          

                                                                                                                                          
                                                                                                                       2001 Update Summary charts         
                                    
                                                       Phantom Matrix  Anunnaki Intruder Races
• Marduke-Luciferian-Anunnaki:  (Fallen Anu-Seraphim hybrid, Lyra Aveyon) Phantom Alpha/Omega Centauri,                          
Nibiru, Tiamat. APIN System: NDC-Grid/NCT-Bases/NET, Phoenix, Serpent Nibiruian APINs. Primary Races : -    
Vichoritz insectoid-serpent-hominid (Thoth-Enki Lulitan family-Amealian-Anunnaki/Marduke Satain family-Amealian        
-Anunnaki/Necromiton- Andromie hybrid) and Vichor  Light-haired Humanoid (Pleiadian-Amealian-Anunnaki/Vichoritz     
hybrid) Nibiru, Tiamat, Alpha Centauri. Centaur-Luciferians Hominid-Centaur hybrids (Vichoritz-Centaur) Alpha          
Centaur. Core Agenda : Luciferian-Anunnaki Pleiadian-Nibiruian Coalition  and/or Necromiton-Andromie Orion-     
Necromiton Black League . Primary Leviathan Illuminati Races: Elucum King/ Beli-Kadmon Atalan King Atlantian     
Leviathan Illuminati lines. Babylonian-Sumerian Vicherous King (Elucum King-Druedic Maji hybrid) “Scandinavian     
Vi-Kings”, Hyksos King Knights Templar/Freemason Master Race  Leviathan Illuminati lines. Human Tribe     
Inﬁltration: Raided Tribe-3 Druedic Maji lines Nohasa Atlantis/ Scandinavia/ England/Ireland/Scotland, Scots     
“McGregor” raider lines, Knights Templar Freemasons. Associations: 9560BC Luciferian Covenant. Work with     
Pleiadian-Samjase-Luciferian-Anunnaki/ Nibiruian Thoth-Enki-Zephelium-Anunnaki and/or Centaur Luciferian/     
Necromiton-Andromie Orion-Necromiton Black League .  Druid, Celtic, Pagan and Protestant Christian text     
distortions. Most joined UIR 2000  with Necromiton-Andromies. 
• Marduke-Dramin/Satain-Anunnaki:  (Fallen Anu-Seraphim hybrid, Lyra Aveyon) Phantom Alpha Centauri, Sirius B,     
Alnilam Orion, Alpha Draconis, Nibiru. APIN System: NDC-Grid/NCT-Bases/NET, Dragon, “Crocodile”(now dis-     
mantled) and Falcon Drakonian APINs Primary Races : Dramin-Dragon-Queen  dino-insect-hominid Anunnaki hybrid    
(Amealian-Anunnaki-Aquatic-Ape Marduke-Satain family line-Omicron-Drakonian-Dragon Moth hybrid). Sathosah      
Dark-haired “Hook Nose”, olive-skinned Humanoid Sirian Anunnaki (Jehovian-Satain-Nephilim-Omicron-Nephite-     
Human). Core Agenda : Satanic-Drakonian Orion-Necromiton Black League . Primary Leviathan Illuminati Races:     
Sathian King (Etruan King-Marduke Sathosah hybrid) Atlantean Leviathan Illuminati line. Babylonian-Chaldean-     
Akkadian King (Jehovian Anunnaki Nohassim-Hassah King-Sathian King hybrid) Atlantian Leviathan Illuminati line.      
Set King Egyptian (Sathian King-Babylonian King-Horus King hybrid) Leviathan Illuminati line.  Human Tribe     
Inﬁltration: Middle Eastern Hibiru, Sumeria, Akkadian-Chaldean, Babylonian, Egyptian, Native American “Kota”     
tribes, Angolan-Portuguese-W. African, Russian. Associations: “Dramin the Dragon Queen”, Egyptian “Set”     
schools, Biblical “Seth” lineage, “Necromancy” Satanic Bible, “Satanism”, Islamic and Hebrew text distortions,     
 “KKK”, Russian Psychic “Rasputin” and related “channels”. Work with Omicron-Drakonians, Dracos and Orion-     
Necromiton Black League Pro-Drac Necromiton-Andromies. Most joined UIR 2000;  some factions refused UIR for     
Rebel Omicron-Drakonians.
• Enlil-Odedicron-Anunnaki:  (Fallen Annu-Seraphim hybrid, Aveyon Lyra) Nibiru, Phantom Tiamat, Lyra-Avalon     
APIN System: “The Phoenix”. Primary Races: Enlil Amealian-Anunnaki-Aquatic-Ape/Odedicron-Avian-Reptile     
scaled reptile-hominid hybrid. Beli-Kudyem  Odedicron-Anunnaki-Turaneusiam-Human human-reptile hybrids     
Alcyone/Tara  Core Agenda:  Reptilian-Anunnaki Pleiadian-Nibiruian Coalition  or Reptilian-Drakonian Drakonian-     
Orion Confederation.   Primary Leviathan Illuminati Races: Ediruan King Atlantian/Sumerian/African Leviathan                    
Illuminati lines. Beli-Kadmon/ Atalan/Arcadia-Greek King (Nibiruian Anunnaki hybrid) Atlantian Leviathan Illuminati     
lines. Atlas King Atlantian-Sumerian and Horus-Scarab King Egyptian Leviathan Illuminati lines. Hyksos Knights     
Templar King  Anunnaki and Drakonian Anti-Christos Master Race line. Roman Romulous King and Sacheon-Gual     
King (Pleiadian-Samjase-Luciferian-Anunnaki Sacheon/Saxon- Germanic-Hyksos-Omicron Drakonian) Dragon King     
lines. Human Tribe In ﬁltration: Egyptian, African, Arcadian-Greek, South American, Inca, NW Native American,     
NW French, S. English. Associations: With Enki-Zephelium/Marduke-Luciferian Anunnaki created Nibiruian     
Primate-hominid Lulcus-Neanderthal slave race for African gold mines and Middle East labor, 250,000BC. Enlil-     
Anunnaki Raider Race of 148,000BC-75,000BC Anu Occupation, 25,000BC Lucifer Rebellion, 10,500 BC Luciferian     
Conquest, 9560BC Luciferian Covenant Atlantian Human Tribe Invasions Atlantian-Egyptian  “Phoenix” and Falcon     
mystical schools, Falcon Shamanic traditions, Nubian/ Mayan/Toltec/Olmec/ Native American “Falcon Cults” and     
“Crocodile Cults”, Gaul raider races of France, Britain, Europe, Knights Templar Free Masons Anunnaki and     
Drakonian factions. Most are members of Nibiruian Councils 9 and 12, Pleiadian-Nibiruian Coalition, Galactic     
Federation and Ashtar Command. Defected from Pleiadian-Sirian Agreements/Treaty of Altair to join UIR 2000 with     
GF, Ashtar Command and Nibiruian Council Anunnaki.                         
                                                                                               
                                                               © 2002 Ashayana Deane    
               535                                                     
                                                                                                                                       

                                                                                                                      
                   2001 Update Summary Charts
                                                                   Phan tom Matrix  Anunnaki Intruder Races (continued)
•	Jehovian Anunnaki : (Fallen Annu-Elohim Jehovani D-11 “dark avatar” collective) Phantom Lyra Aveyon, Sirius A,         
Arcturus, Alpha Centauri, Andromeda, Trapezium (Theta) Orion. APIN System: Jehovian-Nephite: “Dove and Olive      
Branch” HD-C/APIN, Jehovian 7-Seals, Arcturian Trumpet technologies and Phoenix Wormhole access. Jehovian-      
Nephilim-Morantian: Dove, Dragon and Falcon APINs. Jehovian-Nephilim-Nephite-Drakonian: Dragon and Falcon      
APINs. Primary Races:  Jehovanians Fallen Annu-Elohim. Fallen Ophanium  “Overlords”  (Oraphim Maji-Nephite      
Anunnaki hybrid) Arcturus, Trapezium Orion. Bipedal Dolphin People Anunnaki cetacean-hominid Sirius A (original           
Anunnaki pure strain), Schriki-EL  aquatic dolphins Earth. Nephite “Hook Nose”, dark haired Humanoids (Dolphin      
People Anunnaki-Hebrew/Hibiru-Melchizedek-Cloister-Human hybrids) Phantom Sirius A (“Etheric Sirians”), Orion,      
 Anteres, Pleiades, Arcturus and Lyra Aveyon (Humanoid “Arcturians” and “Lyrans”). Morantians  Jehovian-Nephilim      
Humanoid (Necromiton-Andromie-Jehovian-Anunnaki-human hybrid) Sirius A, Arcturus, Alpha Centauri,      
Andromeda. Core Agenda: Jehovian-Nephilim-Morantians : Annu-Elohim Federation of Planets. Jehovian-Nephite-     
Nohassim(Zadok): Orion-Necromiton Black League. Jehovian-Nephite-Drakonian (Baal) : Drakonian Orion      
Confederation. Jehovian-Nephite-Adam Kadmon (Belil-Davidic):  Pleiadian-Nibiruian Coalition.  Primary Leviathan      
Illuminati Races:  Jehovian-Nephilim-Morantians: Admian-Nephilim Urantia King (Morantian-Necromiton-Andromie-      
Jehovian-Anunnaki-Ur-Antrian-Cloister-Human hybrid) and Annu-Melchizedek Adamian-Nephite King Lemurian      
Leviathan Illuminati lines. Jehovian-Nephite-Nohassim “Sirian Sons of Zadok” : Zadokhim-Hassim King (Enochian       
Adamian-Nephite), Hassa King (Zadokhim-Hassim) and YHWH Hibiru King Atlantian Leviathan Illuminati Lines.      
Jehovian-Nephite-Adam Kadmon “Nibiruian Sons of Belil”: Nohassim-Adam-Kadmon King (Enochian Zadokhim /      
Thoth-Enki-Zephelium Ezeural  Beli-Kadmon Nibiruian hybrid), Larsa King (Enochian Nohassim-Adam-Kadmon/      
Thoth-Enki Ezeural and Samjase-Luciferian Sacheon-Atalan) and Davidic King (Knights Templar Enochian-      
Thothian-Hyksos Adam-Kadmon, the Abraham-David-Moses-Akhenaton-Jeshewua-9 lineage) Atlantian Adam      
Kadmon-Nephite Leviathan Illuminati lines. Jehovian-Nephite-Drakonian “ Orion Sons of Baal ”:  Taozan-Sadducees     
(Necromiton-Andromie-Jehovian Anunnaki hybrid) and Hassad-Pharisees (Omicron-Drakonian-Jehovian-Anunnaki      
 hybrid) Semetic Jehovian Dragon King lines.  Hallah King (Zadokhim-Hassim-Necromiton-Andromie-Omicron-     
Drakonian) Atlantian Nephilim-Nephite-Drakonian Leviathan Illuminati line . Human Tribe In ﬁltration: Extensive      
raiding of Angelic Human Hibiru, Hebrew (Hibiru-Melchizedek Cloister) and Essene (Melchizedek Cloister) Indigo      
Maji Grail Lines, and moderate in ﬁltration of Yu (Chinese/Tibetan), Sumerian/ Egyptian/Middle Eastern, all      
European/ American cultures. Associations: Jehovian-Nephilim-Morantians:  Major distortions of original      
Lemurian/Atlantian/Essene Emerald Covenant CDT-Plate Christos teachings, Christian Protestant text distortions,      
Urantia Book, Templar Melchizedek Mormon texts.  Jehovian-Nephite-Nohassim : Created “YHWY”/ “Jehovah” God      
 stories/ false 12-Tribe History in Hebrew/Christian texts. Jehovian-Nephite-Adam Kadmon : Promote Jehovah/      
YHWH/ Metatron/ Ophanium/ Enoch/ Archangel Michael and Tibetan creeds. Jehovian-Nephite-Drakonian: Kaballah      
Hebrew text distortions, inverted-reversed 10-Sephiroth “Tree of Life”, removed 6 letters from Hebrew alphabet.      
Traditional and Hassidic Hebrew texts distortions. Jehovian renegades in Galactic Federation/ Ashtar Command/      
Nibiruian Councils. Course in Miracles channeling and Thoth-Isis-Merlin-Archangel Michael teachings are Jehovian/      
GF/ Necromiton-Andromie Nephilim Anunnaki Co-op. Most join UIR 2000  with GF, Ashtar Command and Nibiruian      
Council. Some Jehovian-Nephite-Drakonian groups joined Rebel Omicron-Drakonian OWO agenda.
•	Pleiadian-Samjase-Luciferian-Anunnaki: (Fallen Annu-Seraphim hybrid, Aveyon Lyra) APIN System: The NDC-       
Grid, NET, “Phoenix” APIN, Phoenix wormhole, “White Eagle” APIN  Primary Races: Beli-Kudyem Reptilian-           
Anunnaki-human hybrid “Blonds” (Marduke-Luciferian-Anunnaki line of Sirius A raided Procyon Serres Maji races)       
Tara, Alcyone, Procyon and Nibiru.  Borjha “little blue hominids” of Pleiadian Alcyone, Nibiru, Tiamat, Tara. Beli-       
Kudyem human-reptile hybrids Alcyone and Inner Earth. Beli-Mahatma Pleiadian-Jehovian Anunnaki-Human       
reptilian-aquatic-human hybrids, look like “pretty perfect humans” of various heights with blond or dark hair and                
bright blue eyes, usually wear white robes and falsely claim ascended mastery, Alcyone, Inner Earth, Parallel Earth       
and Sirius A (majority race of GF and Ashtar Command). Core Agenda : Pleiadian-Nibiruian Coalition- Luciferian       
Covenant “Anunnaki Resistance” agenda.  Primary Leviathan Illuminati Races: Bruah Atlantis Atalan Kings, Lohas      
Atlantis Sacheons-Saxons Kings (Celtec-Dreudic Maji Tribe raids),  Atlantian-Sumerian  Larsa Kings, Isis Queen-       
Egyptian line, Hyksos Knights Templar-Freemason Master Race, Cathari (raid of Maji KatharA Indigo Tribe of S.       
France). Human Tribe In ﬁltration: Russia-Germany, England, France, Scotland, North and South America.       
Afﬁliations: Protestant Christian text distortions, “Isis” mystical schools, Pleiadian channels and UFO contacts,                                            
work closely with Nibiruian Anunnaki Thoth-Enki-Zeta, Enlil-Odedicron and Marduke-Luciferian lines. “Mahatma” and      
Rosecrution spiritual teachings, ancient “Olympian Gods” of Rome and Greece, Galactic Federation, Ashtar       
Command and Pleiadian-Nibiruian Council. Anunnaki portions of World Management Team Illuminati, Alpha-Omega     
Melchizedek schools, false “Mother Mary” contacts. Work with Nibiruian Thoth-Enki and Enlil-Odedicron-Anunnaki,       
Zeta-Reticuli, Necromiton-Andromie-Nephilim hybrids, Centaur-Luciferian-Anunnaki. Defected from 1992 Pleiadian-      
Sirian Agreements; all joined UIR 2000  with Galactic Federation, Ashtar Command and Nibiruian Council.                                                                                                                 
                                                                                         © 2002 Ashayana Deane   
             536                                                                                                        
             
  

                                                                                                                     2001 Update Summary Charts
                                                           Phantom Matrix  Anunnaki Intruder Races (continued)
•	Thoth-Enki-Zephelium Anunnaki : (Fallen Anu-Seraphim hybrid Lyra Aveyon). Nibiru, Tiamat, Lyra-Aveyon. APIN       
System : NDC-Grid/Battlestar Wormwood/ NET, “Serpent”, “Phoenix” and “Falcon” APINs. Primary Races :      
Amealians Anunnaki-aquatic ape-hominid Lyra-Aveyon. Enki-Zephelium-Anunnaki black-haired, tan-skinned, “Hook                 
Nose” tall humanoid-insectoid-reptilian-serpent (Amealian-Anunnaki-Zeta-Reticuli-Zephelium hybrid) Nibiru. Thoth-                   
Enki-Zephelium-Anunnaki (the Enki-Zephelium-Anunnaki Lulitan family line of Thoth), seed of the earthly E-Luhli      
Levi, Juda, Nephi and Annu-Melchizedek human-hybrid Leviathan races. Essesani, Luciferian-Anunnaki similar to      
Enki-Zephelium-Anunnaki but shorter, stockier build (Nibiruian Thoth-Enki-Zephelium Lulitan family line plus      
Marduke-Dramin/Omicron-Anunnaki Satain family line combined to form the original “Luciferian” Amealian-Anunnaki      
seed race.)   Core Agenda : Pleiadian-Nibiruian Coalition- Luciferian Covenant “Anunnaki Resistance” agenda.       
Primary Leviathan Illuminati Races : Belil-Annu-Melchizedek (Paracletes) Atalan King Atlantian Leviathan      
Illuminati line Bruah Atlantis, Larsa Kings raiders of Lohas Atlantis and Sumeria (Thoth-Belil/Samjase-Luciferian      
Sacheon/ Jehovian-Nephite-Adam Kadmon Leviathan hybrids). Osirius and Thoth Egyptian King lines, Greek-      
Roman Amulius King (Hermes-Tris-me-gis-tus lineage) and Hyksos Kings Anunnaki Master Raider Race (Knights      
Templar Freemasons) and Mayan-Hyksos King Leviathan Illuminati lines. Human Tribe Infiltration : Raiding of       
Bruah (Florida Seminal Native American Maji Tribes), Nohassa (Bermuda Island Maji tribes), Lohas (Druedic and      
Celtec Maji Tribes) Atlantis, Sumerian Ur, Egypt Giza and Sakkara (Serres Maji Tribes), Mayan, African, Central      
American, Peruvian-Inca (Maji Tribes) and various Native American tribes. Associations : Initiators of the 9560BC      
Luciferian Covenant OWO Nibiruian-Atlantian Dominion Master Plan. Dominant force of the Anunnaki portions of      
World Management Team Illuminati. Greek Hermes Tris-me-gis-tus, Greek-Roman Amulius and Julius Caesar       
Nibiruian King lines, some Roman and Greek “Olympian Gods” legends. Mayan-Quetzalcoatl, forced Human tribes      
to adopt Nibiruian-distorted Mayan Calendar and Nibiruian-created Julian Calendar in Rome. Egyptian Osirius-Isis      
mystical schools, the Atlantian Emerald Tablets (Written translations of part of data stored on Emerald Covenant       
CDT-Plate-11 stolen by Thoth in 22,340BC.) and “Brotherhood of the Snak e” Atlantian mystical schools. Led      
Nibiruian Anunnaki invader races in the Eieyani Indigo Massacre of 22,326BC Lemurian Islands (Kauai Hawaii).       
“Thoth” Alpha-Omega Melchizedek mystical schools, “Lord Melchizedek” and related channel contacts, Christian-      
Protestant text distortions, Osirius-Isis-Horus Egyptian schools. Most groups were Emerald Covenant loyal until      
Thoth defected from Emerald Covenant just prior to the SAC and Eieyani Massacre of 22,326BC. Coerced Enoch      
and his Kodazhim hybrid races to defect from Emerald Covenant to enter the Luciferian Covenant in 10,500BC to      
launch “Hyksos-Knights Templar Master Race Plan”.  Works closely with Nibiruian Enlil-Odedicron-Anunnaki,      
Pleiadian-Samjase-Luciferian-Anunnaki (primary allies), Zeta-Reticuli Zephelium, Necromiton-Andromie-      
Drakonian/Jehovian-Nephilim (primary allies) hybrids and Centaur-Luciferian-Anunnaki.  Defected from 1992       
Pleiadian-Sirian Agreements /2000 Treaty of Altair for UIR 2000. A driving force within the contemporary  New Age      
Movement Indigo  Hi-jack Plan  (body-snatching of as-yet-unawakened Indigo Maji Types 1-2-3 via Astral Implant      
Tagging, Astral Over-shadowing and eventual full body possession.) 
                                           
(Afﬁliations also include ‘’Merlin and Thoth’’ channels and contacts)
                                   
 
                                                            © 2002 Ashayana Deane           
537
                                                                                                                                                                                                                                                                                                            
                                                                                                             

                                                                               Appendix VI
                                                        
                          
                      
                       Crisis Intervention Expedited                                    
                         Amenti Opening Schedule            
      Due to the Sept 12, 2000 Fallen Angelic /Intruder ET United Resistance Illuminati     
  Edict of War and United Resistance’s intention of orchestrating Earth Templar takeover    
  and pole shift by 2008, Guardian nations issued an Imminent Crisis Order in October    
  2000, setting in motion the Emerald Covenant Masters Planetary Stewardship Initiative.    
  As per this Crisis Intervention Program, Sirius B Star Gate-6 and the D-12 Halls of    
  Amorea Passage were activated seven years early in May 2001. Advanced Planetary Tem-    
  plar RRTs are now being conducted, in effort to achieve Planetary D-12 Maharic Seal    
  Protection of Earth’s Templar and populations before Aug12, 2003. Early activation of D-    
  6 Sirius B Star Gate-6 and continued United Resistance Templar Quest sonic pulse activ-    
  ity has greatly accelerated the rate of frequency infusion into Earth’s Planetary Shields,    
  causing time acceleration and expedition of the natural SAC cycle. The accelerated    
  schedule of Amenti Opening and Ascension Cycle events is as follows. 
 Abbreviations Key: 
• APIN = Atlantian Pylon Implant Network global “microchip” grid.
• GA = Guardian Alliance.  
•  J-DNA Seals  = 7 unnatural Jehovian implants that manifest in the DNA 
       with J-Seal release. 
• J-Seals = Seven unnatural Planetary Jehovian Seal Implants. 
• LPIN =Lemurian Pylon Implant Network global “microchip” grid.  
• NCT-Bases = Nibiruian Crystal Temple Bases.   
• NDC-Grid = Nibiruian Diodic Crystal Grid.  
• OWO= One World Order
• PSC Seals = Planetary Star Crystal Seals. 
• RIT= Remote Interactive Team
• RRT = “Rainbow Roundtable” Masters Planetary Templar Merkaba Mechanics.
• SAC = Stellar Activations Cycle.                                                                                              
• UIR= United Intruder Resistance.                             
                                                      EVENTS LEADING TO GA CRISIS INTERVENTION 
                                                              AND EXPEDITED AMENTI OPENING
1.	 1992 Nov : Anunnaki reluctantly enter Pleiadian-Sirian Agreements, give up OWO       
 agenda fearing Drakonian OWO defeat, enter Emerald Covenant, promise to assist                     
 Founders Christos Realignment Mission; Founders postpone Christos Realignment                
 fulfillment date from 2012 to end of continuum cycle 4230 to give Anunnaki races                                   
 time for more Bio-Regenesis.         
                         
                           538        
                     


               
                        Events Leading to GA Crisis Intervention and Expedited Amenti Opening
     2.   2000 Jan 1 : Florida Shields Clinics,  Transcendence Day successful, Stellar Bridge
 Grounds on a 12-Code-Pulse for first time since 208,216 BC failed  SAC. 1998-2000 
 Anunnaki fully negate 1992 Emerald Covenant Pleiadian-Sirian Agreements and 
 revert to their original 9560 BC Atlantian Conspiracy/Luciferian Covenant OWO 
 Halls of Amenti Quest dominion/invasion agenda. 
         3.   2000 March:  Egypt Shields Clinic , GA/Indigos release D-8 Seal of Orion Templar
   Security Seal at Giza, Egypt. Emerald Covenant Founders and GA continue negotia-
   tions with Anunnaki in hope of reactivating Pleiadian-Sirian Agreements peace trea-
   ties so Final Con ﬂict War drama can be prevented during the SAC.
         4.   2000 May 5:  Florida Shields Clinic , Solar Spiral Alignment successful, Earth enters
  Solar Activation, Planetary Templar begins 12-Code-Pulse “Christos Activation” via 
  anchoring the “D-12 Hydroplasmic Beam” Solar Star Gate-4  (SG-4) link, “Templar 
  Re-Birthday Party”. 12-Code-Pulse activation makes D-12 Pre-matter “Divine Blue-
  print” Maharata Current frequency available on Earth for first  time since 208,216 BC 
  SAC “Fall of Brenaui” Invasion. Availability of D-12 Maharata Current  allows 
  potential to clear Earth’s Planetary Shields of NDC-Grid /Nibiru/Wormwood
  ''Checkerboard Matrix '' Templar distortions and to clear corresponding '' Checker-
  board Mutation ” from Earth-life DNA Template. Allows provides opportunity to 
  place Earth under full D-12 Planetary Maharic Seal protection and to fulfill Christos                                                                                                           
      Realignment Mission during this SAC to prevent Anunnaki, Drakonian and
  Andromie OWO invasion plans. 
         5.   2000 July 5:  Anunnaki reluctantly reenter Emerald Covenant Founders/GA Treaty 
  of Altair  Pleiadian-Sirian Agreements extension, fearing Drakonian advancement
  and potential failure of their OWO agenda due to GA Templar successes. Anunnaki 
  again agree to assist Founders in Christos Realignment Mission, disengage the
  ''Checkerboard Matrix'' Templar Control/DNA Mutation program, to turn Solar SG-
  4 and Alcyone SG-5, NDC-Grid and Primary 24 NCT-Bases  over to Emerald Cov-
  enant/GA protection to prevent SAC pole shift. 
       6.   2000 Aug: Macchu Picchu , Peru , Shields Clinic , Anunnaki reluctantly begin 
  agreed-upon Solar SG-4 transfer to Eieyani-GA as per Treaty of Altair. Emerald Cov-
  enant Eieyani High Council of Inner Earth make contact with Indigo Team in Peru to
  begin Masters Templar Training. GA clear NDC-Grid D3/D4 blockage in Earth-to-
  Sun/Earth-to-Mars/Earth-to-Tara  “Emerald Caverns ” SG-4 passages and Blue, Gold 
  and Violet Primal Light Pillars activated in SG-5 Machu Picchu, Peru.  
        7.    2000 Sep 12:  Stonehenge , England , Shields Clinic , Anunnaki to disengage  
           “Wormwood Battlestar”/ NDC-Grid Stonehenge link and turn NDC-Grid over to
     Emerald Covenant 12-Code-Pulse protection, as per Treaty of Altair. Anunnaki
     instead defect from Treaty of Altair  via Necromiton-Andromie persuasion, to join 
     UIR OWO War Edict  against Founders and Emerald Covenant nations with Necro-
     miton-Andromies/Drakonians. Anunnaki sabotage promised NDC-Grid GA transfer
     at Stonehenge England and assisted Drakonians and Necromiton-Andromies to use 
     NDC-Grid and Nibiruian controlled Ley Lines to launch Psycho-tronic attack on
     Indigo Templar Security Team in Manchester England. UIR attempt to '' blackmail '' 
     Founders  via Ultimatum  that 50,000 Eieyani High Council IndigoType-1 (out of
     550,000 Types-1, 2 and 3 presently on planet) could be freed and evacuated from Earth
     by UIR Galactic Federation, leaving all of Humanity and remaining Indigos to UIR
       takeover and 2008 pole shift demise. If Emerald Covenant Founders refused UIR              
          Ultimatum, UIR would issue immediate Edict of War against Founders and Emerald Cov-                                       
            enant/Human nations. Emerald Covenant nations collectively refuse UIR 
    blackmail Ultimatum intimidation ; UIR issue ''fight to the death'' Official Edict of 
    War.  
         8.     2000 Sept-2001April:  GA issues War Crisis Order , begin expedited revelation of 
    Atlantian Conspiracy Invasion Agenda,  institute early Masters Templar Planetary 
    Stewardship Initiative RRT plan,  and return full “Christos Realignment Mission”   
      
      539
 

                   Crisis Intervention Expedited Amenti opening Schedule                                        
                              schedule to original Dec 21, 2012, deadline. Begin Indigo  Emergency Intervention/        
                                   Expedited Amenti Opening schedule to prevent pending UIR pole shift/genocide                      
              agenda.                        
                                                              EXPEDITED AMENTI OPENING
                                                   CRISIS INTERVENTION PROGRAM BEGINS
 9.   2001 May:  RRT Kauai , Hawaii , GA Crisis Intervention. SG-6 Sirius B  activated    
(originally due 2008) and Halls of Amorea D-12 Passage opened beginning Planetary     
Maharic Seal/D-12 Christos Merkaba initiative  to prevent pending 2008 pole shift,       
2003 UIR First Contact invasion agenda and initiate full 2012 Christos Realignment     
Mission . Planetary and DNA Star Crystal Seals , and unnatural Jehovian-Anunnaki     
Fire-Letter-Reversal Implants , the 7 Planetary and DNA Jehovian Seals  begin auto-     
matic expedited activation in response expedited frequency acceleration in Earth’s     
Planetary Shields. RRTs  stabilize and progressively realign Seal-released frequencies      
to natural 12-Code-Pulse, to prevent progressive Earth Changes and biological deteri-    
oration from Jehovian Seals. NCT-Base  Kauai Hawaii  realigned to 12-Code-Pulse.         
PSC-Seals   #1 and #2, and J-Seals  #1 “White Horseman” and #2 “Red Horseman”     
release. Mass DNA Seals #1 and #2 and J-DNA Seals  #1 and #2 Initiate; Seals begin        
Consummation/Activation in Aug 2001. 
 10.  July 2001:  RRT Ireland  Cue Site-11. Guardians draw D-12 frequency from Halls of    
Amorea passage Kauai to realign Cue-Site-11 Eye Island Ireland in preparation for 
11:11 (Axiatonal Line-11/Ley Line-11) 12-Code realignment to sever. Remote acti-
vation of “Arc of the Covenant” Gold Box  “Rod and Staff” SG tools buried in Irish     
Sea to trigger 12-Code activation of SG-11. July 24-27, GA code SG-11site at “Milk     
Hill White Horse”, Vale of Pewsey England with NDC-Grid 12-Code release pro-      
gram , the first fully-GA-created “Crop Circle”  (mathematical Planetary Shields         
encryption) called the “Aveyon Spiral”.   RRT England  GA/Indigos draw 12-Code fre-    
quency from Ireland Cue Site-11 to realign 11:11 grid line to 12-Code. NDC-Grid/           
Nibiru/Wormwood Battle Star link at Stonehenge, the ''Checkerboard Matrix"
  Nibiruian remote scalar transmission point, successfully severed and realigned to nat-
  ural 12-Code at SG-11. NCT-Bases England, Iran  and Pakistan  realigned to 12-
  Code-Pulse. PSC- Seal #3, and J-Seal #3 “Black Horseman” release, Mass DNA Seal
  #3 and J-DNA Seal #3 Initiate; Seals begin Consummation/Activation October 2001. 
11.   2001 Aug:  UIR expedites OWO agenda  and early Frequency Fence  transmissions. 
Eieyani Reserve Intervention Program initiated;  720,000 Eieyani Ascended Masters     
Indigo-Type-1’s prepare to consummate Walk-In Soul Agreements  (most adult) to      
join the 550,000 adult Indigo Children already on Earth.  The 720,000 Eieyani     
Reserve Walk-In Crisis Intervention Team will enter Earth in “waves” as 60 Teams of     
12,000;  they will fulfill their pre-birth Walk-In contingency contracts by Dec 2002       
end, one  Team of 12,000  entering each week between Sept 1, 2001-December 31, 2002.     
The   150,000 Palaidorian Birthing Contract Indigo Children infants due to incarnate          
by 2017, and all of the “6 Silent Avatars”, will be on planet by 2007. PSC Seal # 1 and          
#2, Mass DNA Seals #1 and #2 and J-Seals/J-DNA Seals  #1 and #2 begin Consumma-      
tion/Activation. Indigo/Human Mass DNA 12-Code Awakening  begins. Aug 12    
(originally due 2012 May 5),  UIR expedites OWO agenda  to prevent Mass DNA     
12-Code from reaching critical mass in Earth’s grids; would naturally prevent UIR      
intended 2003 Dimensional Blend Experiment by amplifying 12-Code in Planetary      
Templar. UIR sends two “ ULF Slow Pulse”  sonic transmissions from Chihuahua,           
Mexico  and Lake Titicaca Peru NCT-Bases to fully activate Montauk-Phi-Ex               
APIN and connect Anunnaki APINs to Falcon Wormhole.
12.  2001 Sept 1 : First Team of Indigo Eieyani Reserve Walk-Ins enter Earth via Halls of    
       Amorea and SG-6 Sirius B.
                        13.  2001 Sept 3 : RRT Sarasota FL.  GA initiates Trion/Meajhé Field  “Planetary Buffer        
                               Blanket” with Bi-Veca and Tri-Veca Master Code transmissions, despite United Resis-     
                                tance Psycho-tronic attack on Indigos via Chihuahua/Titicaca ULF Slow Pulse. GA
                            
                             540
                             
                                             

                                 Expedited Amenti Opening Crisis Intervention Program Begins
      completes Giza/ Pleiadian-Alcyone Spiral alignment (originally due 2001 Sept 17).      
     Blue Wave Infusion  of D5/D6 frequency activates in Earth’s Core (originally due      
     2002 June), will reach critical mass to Activate in grids mid Nov-early Dec 2001 .                       
     NCT-Bases Sarasota, FL,  and Bermuda  partially realigned to 12-Code; UIR Psycho-       
     tronic pulses disrupt full 12-Code realignment, will be completed Nov 2001. PSC-                                                                     
     Seal #4 releases, Mass DNA Seal #4 Initiates; Seals begin Consummation/ Activation             
     Dec 2001.             
         
                         14.  2001 Sept 11:  UIR staged WTC/Pentagon Disaster Trigger Event  begins UIR/Ill-     
                    uminati WW3 agenda. UIR “Trumpet” Phantom Pulse amplified by Chihuahua/Titi-     
                              caca ULF Slow Pulse sent from Bermuda NCT-Base to WTC/Pentagon APIN “Spike”     
                    sites; Anunnaki Dove/Phoenix/Serpent APINs phase-1  “on line” with Zeta/ Drako-     
                    nian Falcon Wormhole. UIR/Illuminati Terrorist Event used to cloak potential Trum-     
                   pet Pulse damage to APIN “Spike” site buildings. UIR expedited Frequency Fence     
        and Psycho-tronic Pulse Program begins in Earth’s grids on Sept 12, 2001 , commem-     
                   orating the first anniversary  of the Sept 12, 2000 UIR declared War Edict.  Expedited     
                   UIR Frequency Fence, now progressively accelerating, is slowing 12-Code Mass DNA    
                   Template activation. If UIR 2003 Dimensional Blend Experiment did not have      
                   chance to succeed, UIR would give up their Halls of Amenti dominion Master Plan     
        and settle for Earth dominion/Human extinction until next potential SAC. In this      
                   case, UIR would stage direct, physical, Mothersship Invasion  as early as end of
                    2001 . To prevent early physical UIR invasion, GA will carefully modulate Planetary     
        Shields frequencies, creating progressive planetary protection while allowing the     
        potentiality for UIR Dimensional Blend Experiment success  until the GA/UIR     
        Show Down  of Aug 2003.  
      
                      15.  2001 October:  RRT Allentown , PA, temporarily blocks/postpones UIR attempt       
                                to remote-activate Philadelphia  APIN Spike site. UIR amplifies Frequency Fence and      
                                Psycho-tronic Indigo Assault program. GA initiates Level-1 “4 Faces of Man” LPIN       
                                activation with Khu-Veca Code transmission, begins Jehovian Seal Override Pro-      
                                gram  and amplifies Trion/Meajhé Field “Planetary Buffer Blanket”.
        
                        16.   2001 October end:  GA initiate Level-2 ''4 Faces of Man '' LPIN  activation  via       
                                Dha-Veca Code transmission. PSC Seal # 3, Mass DNA Seal #3 and J-Seal/J-DNA                                                  
                                Seal #3 begin Consummation/Activation.
       
                     17.   2001 Nov  : Blue Wave Infusions begin Planetary Shields D5/D6 accelerations. RRT
                                 Sarasota FL , GA initiates Level-3 ''4 Faces of  Man '' LPIN Blue Wave activation, 
                                 and amplify Planetary Trion/Meajhé Field protection with Rha-Veca Code transmission. 
                                 NCT-Bases Sarasota, FL,  and Bermuda  realignment completed. 
                     18.   2001 Dec : Pleiadian-Alcyone Spiral aligns with Earth, Pleiadian Activation  begins,         
                              Vortex/Star Gate-5  Macchu Picchu begins 12-Code opening cycle (originally due     
                     2004 June). Dec 1, GA engage NYC Trion Field Link Indigo Protection/Outreach     
                              Program. RRTs Macchu Picchu , Peru , GA anchor Trion/Meajhé Field to V ortex/SG-     
                              5 and initiates Level-4 “4 Faces of Man” LPIN  activation. NCT-Bases Machu Pic-      
                              chu Peru , and Portugal  realigned to 12-Code. PSC Seal # 4 and Mass DNA Seal #4      
                              begin Consummation/Activation. PSC- Seals #5, #6 and #7, Mass DNA Seals #5, #6      
                              and #7 Initiate; begin Consummation/Activation April 2002. 
                       19.   2002 Jan : Blue Wave Infusion completes and Violet Wave Infusion  of D6/D7 fre-     
                     quency activates in Earth Core ( originally due  2006 June ), critical mass and release     
                             through Earth grids early April 2002 . RRTs Lake Titicaca Peru,  GA anchor Trion/      
                             meajhé Field to V ortex/SG-7, initiate Level-5 “4 Faces of Man” LPIN  activation      
                             and intercept/12-Code override UIR’s intended Trumpet Pulse transmission to pre-      
                             vent Falcon-Phoenix Wormhole merger. PSC Seals #8 and #9, J-Seals #4 “Pale Horse-      
                             man” and #5 release; Mass DNA Seals #8 and #9, J-DNA Seals #4 and #5 Initiate;      
                             begin Consummation/Activation mid April 2002. NCT-Bases Lake Titicaca-Peru,      
                             Giza-Egypt, South Pole  and Mauritania , West Africa  realigned to 12-Code. UIR      
                             will attempt Trumpet Pulse Falcon-Phoenix Wormhole  merger , to activate/ intercon-      
                             nect all Intruder APINs. If GA Trumpet Pulse interception is successful in Peru, GA      
                             will continue with Plan A Templar Protection Mission. If GA unsuccessful, and
                        541
                                                                                                                                                                       
                                                                                                                                                           

 
                       
                        Crisis Intervention Expedited Amenti Opening Schedule
   Wormholes merge, cataclysmic East Coast USA storms by Feb-July 2002 and pole                                
   shift b y 2008 cannot be prevented; GA will then initiate Plan B Evacuations sched-      
   ule. If GA prevents Jan 2002 UIR Wormhole merger, UIR will accelerate WW3 sce-           
   nario in external political arena to prepare for expedited 2003  end Physical Invasion           
   ''First Contact '' drama. Cue Site-10 Iraq  territories presently rebel Omicron-Drako-      
   nian controlled, is one of various targets for UIR Illuminati acquisition. If GA shifts to           
   Evac agenda, UIR will continue their Illuminati OWO Master Plan, slow WW3      
       advancement toward later 2005 “First Contact” agenda.         
  
20.  2002 April:  Violet Wave Infusions begin Planetary  Shields D6/D7 accelerations.               
       RRT Sarasota, FL,  GA initiates Level-6 “4 Faces of Man” LPIN  Violet Wave acti-      
       vation  and amplify Planetary Trion/Meajhé Field protection. PSC Seals # 5,  #6 and              
       #7 and Mass DNA Seals #5, #6 and #7 Consummation/Activation early April. PSC      
       Seals #8 and #9, Mass DNA Seals #8 and #9, J-Seals #4 “Pale Horseman” and #5, J-      
       DNA Seals #4 and #5 Consummation/Activation mid April.        
  
      21.  2002 May-June:  Sirian Spiral aligns with Earth, Sirian Activation  begins, Vortex/      
            Star Gate-6 Russia  begins opening cycle (originally due 2008 June). RRTs Paxos,      
           Greece,  GA initiate Level-7 ''4 Faces of Ma '' LPIN  activation , linking Earth’s ''4      
            Faces of Man'' LPIN to its 2 companion ''4 Faces'' LPINs on Parallel Earth and Inner      
           Earth to  activate  ''Guardians of the 12 Pillars '' Trion Field  in Earth’s Core. Begins      
            merger of Earth’s Planetary Shields to those of Inner Earth Bridge Zone  and Trans-      
            Harmonic Meajhé Time Cycle.   NCT-Bases Paxos-Greece, Central Mexico, Cyprus,     
           Easter Island, Rome-Italy, Johannesburg-South Africa and Brazil  realigned to 12-     
            Code. GA realign and begin 12-Code Cue Sites activation¹ . Inner Earth to Earth      
            portals begin 12-Code-Pulse opening cycle; will fully open by Dec 2003. Trans-Har-                  
            monic Time Cycle Meajhé Zone sites (interface points to neighboring Trans-Har-      
            monic Meajhé Time Matrix) begin opening cycle; fully open Jan 2003.        
 
          22.   2002 July: RRTs Bermuda and Sarasota , FL, GA begins forming permanent  CAP      
                 on Falcon and Phoenix Wormholes  and begin 12-Code-Pulse realignment of all      
                 Intruder APIN systems to prevent UIR 2003 Physical Invasion drama. GA initiates      
                 Level-8 '' 4 Faces of Man '' LPIN activation and 12-Code-Pulse sonic transmissions      
                 to amplify Trion/Meajhé Field “Buffer Blanket” around Earth’s magnetosphere. Pro-      
           gressive Sub-space sonic scalar  ''Phantom Pulse '' assaults from UIR expected dur-      
           ing and after this period in attempt to prevent Wormhole Capping; may cause       
                 excessive storm activity in Atlantic Ocean and Gulf of Mexico  at various periods if      
                 GA cannot successfully intercept and neutralize UIR attack pulses.  Brief GA ''fly     
                 bys '' will be conducted whenever possible to warn of local Earth Changes, but suffi-      
                 cient “ ﬂy-bys” may be prevented as UIR will stage rapid physical invasion if GA       
                overtly reveals their presence to the masses.
       23 .  2002 Aug-Sept : Violet Wave Infusion completes and Gold Wave Infusion  of D7/D8      
          frequency activates in Earth’s Core ( originally due 2010 June) , will reach critical      
          mass and release through grids December 2002. RRTs Tibet and Sarasota , FL, GA initiate     
          Level-9 “4 Faces of Man” LPIN activation , continue Wormhole Capping, Intruder      
          APIN system 12-Code realignment and strengthening Trion/Meajhe Field to stabilize      
          Seal release, realign J-Seal transmissions to 12-Code-Pulse and begin jamming UIR      
          Frequency Fence. NCT-Bases Lhasa-Tibet , Xian-China and Hamandan-Iran       
          realigned to 12-Code-Pulse. UIR intends to increase Frequency Fence transmission to     
          begin reversed Pineal Seal activation keyed to Phantom Arcturus on Jehovian “Cho-      
          sen Ones” genetic harvest. PSC Seals #10, #11 and # 12 and J- Seals #6 “great earth-      
          quake” and #7 “Golden Censer/7Angels/7 Trumpets” release; Mass DNA Seals                       
          #10, #11 and #12 and J- DNA Seals #6 and #7 Initiate; begin Consummation/Activa-
                              ___________________________________________________
                                                                                                        1.     Earth’s 12 Cue Sites  are Earth SG Activation sites/ Inner Earth SG sites that hold Halls of                                              
                                             Amenti Crystal Pylon Temple control systems
                             542
 
                     
                               

                                                Expedited Amenti Opening Crisis Intervention Program Begins
tion Dec 2002. J-Seal #6 transmissions may cause cycles of earthquake activity in      
regions around Peru/Chile border during and after this time, and may trigger intensive     
storms and volcanic activity in various areas.           
  
               24.  2002 Nov -Dec:  Earth’s Vortex/Star Gate-7 begins 12-Code-Pulse opening cycle     
(originally due 2012 Jan).  Gold Wave Infusions begin Planetary Shields D7/D8      
accelerations;  will continue until 2012. RRTs France and Sarasota FL , GA initiate      
Level-10 “4 Faces of Man” LPIN activation , realign UIR ''Golden Censer Pulse''      
to 12-Code-Pulse, SG12 France begins 12-Code opening cycle to initiate activation of      
D-12 Planetary Maharic Shield  to prevent further UIR invasion and use of  “Trum-      
pet” technologies. NCT-Bases Iraq  and Bosnia,  the last of 24 NCT-Bases, realigned to      
12-Code. Galactic SC Seal  #13 releases; Mass Indigo DNA Seal #13 Initiates; begin      
Consummation/Activation March 2003. PSC Seals # 10, #11 and #12, Mass DNA      
Seals #10, #11 and #12, J-Seals and J-DNA Seals # 6 and #7 Consummation/Activa-      
tion begins. UIR intends to release reversed-current D-8 (gold light spectra) Photo-      
sonic bursts from Phantom Trapezium Orion into Earth’s core via D-4 Beam Ship/sat-      
ellite/HAARP link, in attempt to destroy Planetary SG-12 France; the “Golden      
Censer” Revelation  prophecy. If UIR is successful, several earthquakes will be trig-      
gered in various regions within 4-7 months. GA will shift to Plan B Evacuations and      
UIR will prepare for Jan 2003 ''Trumpet-1" (of 7) remote sonic pulse blast to acceler-     
ate Nibiruian Battlestar Wormwood  passage into Asteroid Belt for UIR-intended      
                     2004  forced descent to Earth. If UIR unsuccessful in destroying SG-12, UIR will      
increase sonic pulse and Psycho-tronic attacks, strengthen Frequency Fence transmis-      
sions, further advance WW3 drama, continue Templar Quest and instigate progressive         
financial “crash” and  “Martial Law” drama in ''last-ditch attem pt'' to achieve domin-      
ion of Earth’s Templar by Aug 12, 2003. GA Photo-sonic transmissions will reduce      
Wormwood to small pieces; Wormwood fragments will enter Asteroid Belt on erratic      
orbits in 2011 , causing manageable meteor showers and gravitational ﬂuctuations      
while Earth is protected in Trion/Meajhé Field Buffer Blanket. 
25.  2003 Jan : Trans-Harmonic Time Cycle Meajhé Zone  sites fully open, GA begins      
           g reater subtle communication with trusted Indigo and human groups. As Plan A Tem-      
          plar Protection progresses, GA continues strengthening Trion/Meajhe Field, Earth’s      
          Bridge Zone link and Planetary Maharic Seal. GA educational programs shift to pre-      
          paring Indigo teachers/MC Regent Consulate Team for early three-day Particle Con-      
          version Period under Trion/Meajhé Field ''Buffer Blanket'' protection. Indigo Crisis      
          Intervention Teams offer education on Trion/Meajhé Field ''Safe Zones,'' DNA Tem-      
          plate rapid activation/ Kathara Healing and intensive RRT Planetary Protection Pro-      
          grams to those who will listen, as UIR advances escalation of Frequency Fence, WW3      
          drama and population reduction via ''Un-natural Disasters'' sonic pulses, bio-terrorism      
          and regional warfare. Rebel Omicron-Drakonian groups expected to pit their Illumi-      
          nati races against those of UIR as external political warfare  escalates  in areas not suf-      
          ficiently protected by Trion/Meajhe Field Safe Zones. 
                    26.  2003 March : Galactic SC Seal  #13 and Mass Indigo DNA Seal #13 Consummation/                                                       
                             Activation.
                    27.  2003 April: RRTs  in various areas, GA initiates Level-11 ''4 Faces of Man '' LPIN                                
                             activation , begins '' Great White  Lion ''APIN   (“Guardian of the Axiatonal Line Ver-                                     
                             ticals”) activation on 12-Code-Pulse, Trion/Meajhé Field efforts to balance grids to                                    
                 lessen storm, quake and volcanic potentials, and GA World Peace Efforts. 
                     28.  2003 May-July:  UIR ''UFO activity'' increases UIR prepares for expedited Nov-Dec      
                            2003 ''First Contact'' Invasion drama; UIR intends to increase use of sonic pulses for      
                            Frequency Fence amplification, Psych o-tronic attack on select groups and ''Un-nat-                                   
                            ural Disaster'' population reduction. Increased potential for Nuclear War issues                                   
                            involving India , as UIR attempts to block GA from releasing Universal SC Seal-14      
                 site in India during Aug 2003 GA/UIR “Show Down”. UIR accelerates physical con-      
                 tact with their “Human Greeting Teams”  and begins placing more small groups of 
                     543
                                                                                                                            
                                                                                                                                                       
                                                                                                                       

                   
                  Crisis Intervention Expedited Amenti Opening Schedule
their "ET infiltrates" physically on Earth to move invasion agenda along. GA contin-
ues Great White Lion APIN activation and initiates final preparations for August 8-20, 
2003 GA/UIR Show Down.                                                                                                                                                                                                                                                                                                  
29.  2003 Aug 8-20:  Earth’s magnetic Merkaba Field reaches its fastest spin rate, the 100-
year Magnetic Peak climax  on Aug 12, 2003. RRTs India and Sarasota FL  (and 
other undisclosed locations), GA initiates full Level-12 “4 Faces of Man” LPIN 
activation to link the "4 Faces" LPINs of Earth, Parallel Earth and Inner Earth 
("Guardians of the 12 Pillars") to Trans-Harmonic Meajhé Time Cycle via Primal
 Light-Sound Field " Rainbow Ray " Pillars . GA will use 12-Code realigned NDC-
Grid  and 24 NCT-Bases  to amplify D-12 frequency in Earth’s grids; Earth’s Planetary 
Shields draw into phase-lock with the Inner Earth Bridge Zone time cycle . The 
Trion/Meajhé Field “Buffer Blanket” in Earth’s magnetosphere and core will draw
Earth’s particle base into D-3 Nethra Phase Merkaba Vehicle  hyper-dimensional sus-
pension to create a protection field for biological Earth life. Earth enters  Level-3 Tem-
porary D-12 Planetary Maharic Seal  (dimensions 1z-3 of Earth Sealed to D-12 sub-
frequency bands) sustained by 12-Code activation of Inner Earth Crystal Pylon
Temples/Earth Cue Sites #1, #2 and #3 , fortifying the temporary Level-3 D-12 Cap  
on the Falcon-Phoenix Wormhole. Earth’s SGs and Ley Lines #1, #2 and #3 will 
be protected under D-12 Seal. Intended UIR 2003 end ''First Contact '' invasion drama  
prevented  as UIR Mother Ships will be blocked from entering D-3 airspace by Level-
3 Planetary Maharic Seal. Universal SC Seals #14 India and #15 Sarasota FL release 
in Earth’s Planetary Shields; Mass Indigo DNA Seals #14 and #15 Initiate; Seals begin 
Consummation/Activation November 2003.  
        GA/UIR “Show Down”  for Planetary Templar frequency control Aug 8-20,
2003.  UIR will attempt to "un-Cap" the Falcon-Phoenix Wormholes to orchestrate 
their Dimensional Blend "Experiment " in attempt to draw Earth’s Planetary Shields
into phase-lock with Phantom Matrix; UIR attempt to use all available “Trumpet”
pulse and APIN facilities to prevent success of GA Planetary Protection Plan and 
Freedom Agenda. GA will use Trion/Meajhé Field Buffer Blanket and Inner Earth 
Crystal Pylon Temples/Cue sites to keep grids stable to avoid cataclysm. The Mag-
netic Peak Climax  of Aug 12 will amplify the dominant frequencies in Earth’s grids, 
causing Earth’s Planetary Shields to phase-lock with either the Inner Earth Bridge 
Zone time cycle  or the Phantom Matrix time cycle . If UIR Dimensional Blend
 Experiment succeeds, GA will shift to Plan B Evacuations and UIR will advance 
intended Nov-Dec 2003 “First Contact” invasion drama Phase-1 , mass sighting dem-
onstration and selective Illuminati and Exterior Government administrative con-
tact. UIR forces stationed off planet in our Time Matrix will attempt to use their 
remaining scalar pulse technologies to erode Level-3 Planetary Maharic Seal before it
reaches full critical mass in Earth’s grids and is amplified to a Level-6 Maharic Seal by
GA target date of 2006 . UIR will motivate Illuminati races to use earthly scalar pulse 
and nuclear technologies to further compromise Level-3 Planetary Maharic Seal and 
Trion/Meajhe Field “Buffer Blanket” integrity and to assist UIR in removing Level-3 
D-12 Cap on Falcon-Phoenix Wormholes to reinstate open D-3 Phantom Matrix 
access. UIR "First Contact" invasion date will be expedited to Nov-Dec 2003
 in order to bring cloaked Beam Ships to Earth to take over GA APINs and to sever Plan-
etary Trion/Meajhé Field ''Buffer Blanket" link. The group having critical mass fre-
quency control of Earth’s Templar on Aug 12, 2003  will retain governing control 
over Earth’s Templar during the remainder of the SAC.
 30.  2003 Nov:  Planetary Shields of Earth and Tara will begin to merge via Inner Earth 
 Bridge Zone time cycle, GA activates Hall of Records  in Egypt, Mass Awakening /
 DNA 12-Code Activation cycle re-commences following Sept 11, 2001 UIR Fre-
 quency Fence block  (originally due 2012 May 5).
 31.  2003 Dec:  Inner Earth portals fully open, Halls of Amenti Star Gates  opening cycle
  begins (originally due 2012 May 5 ) and Earth’s Temporary Level-3 Planetary Mah-
  aric Seal begins amplification toward GA intended 2006 acceleration. Earth begins
  entry into Holographic Beam/Photon Belt,  particle base begins polarity reversal and 
544
                 

                                                         
                                                  Expedited Amenti Opening Crisis Intervention Program Begins
Hall of Records begins transmitting through Earth’s grids Dec 21-22, 2003 ( originally      
due 2012 Dec 21 ). GA initiate 12-Code-Pulse realignment/ activation of " Golden       
Eagle " APIN  (“Guardian of the Ley Line Horizontals”), connecting it to fully act-       
ivated “ Great White Lion” APIN  ("Guardian of the Axiatonal Line Verticals") and
"4 Faces of Man "(“Guardian of the Four Corners”)/" Guardians of the 12 Pillars "
 LPIN systems. 12-Code Activation of the Golden Eagle APIN will permanently dis-
abling Necromiton-Andromies’ “White Eagle” APIN Templar Control/Broadcast-      
 ing Grid. GA will attempt to slow organic progressive acceleration of Earth core 
oscillation speed to prevent Earth from entering the Three-Day Particle Conversion  
Period in 2003 , which will create some degree of cataclysmic Earth Changes  if  it
 occurs before the Trion/Meajhé Field  “Buffer Blanket” is sufficiently strengthened. 
The Trion/Meajhé Field will be progressively amplified and the Level-3 Temporary      
Planetary Maharic Seal will be amplified to a Level-6 Temporary Planetary Maharic  
Seal between Dec 2003-June 2006. UIR in this Time Matrix, with limited resources      
and Phantom Matrix “back up” due to Level-3 Wormhole Cap, will continue efforts 
to disengage GA LPIN/APINs and to erode Temporary Level-3 Maharic Seal. If all 
goes well, the Three-Day Particle Conversion Period can be held off until June, poss-
ibly Dec 2006 , giving time for intensive GA RRT  efforts to strengthen the Trion/       
Meajhe Field Buffer Blanket. 
        A greater quantity of Earth’s Planetary Shields, geographical territories and      
populations will progress into Trion/Meajhé Field Buffer Blanket protection if the      
Three-Day Particle Conversion Period can be postponed for as long as possible. 
Emerald Covenant Founders and GA can slow Earth’s accelerated frequency acc-
retion progression to hold off the Three-Day Particle Conversion Period only until     
2006. This can be achieved  only if humanity is willing to assist in Emerald Cove-      
nant RRTs through which the integrity of the Temporary Level-3/Level-6 Plane-      
tary Maharic Seal and Buffer Blanket can be maintained.   With success of the GA      
2003 Temporary Level-3 Planetary Maharic Seal, UIR in this Time Matrix, unable to      
secure ample Phantom Matrix reinforcements due to the Wormhole Cap, will likely      
continue their Templar Conquest efforts via manipulation of Illuminati  forces. Tem-      
porary Level-3 Planetary Maharic Seal will continue to prevent the UIR 2003 “First      
Contact” invasion drama. UIR will likely revert to their original 2005 First Contact      
invasion schedule , or motivate their Illuminati forces to create a  hoax “Fake Land-      
ing”,  if they deem such an event useful to their continuing invasion strategy. After       
2003, UIR efforts will focus upon eroding Earth’s Temporary Level-3/Level-6 Plane-      
tary Maharic Seal and un-Capping the Wormholes to initiate their “First Contact”       
drama by  2005 , for orchestrated pole shift and final invasion between 2008-2011.       
UIR is also expected to intensify their efforts of waging a vicious “ideological war”       
against Emerald Covenant nations via further manipulation of Illuminati and of peo-      
ples within the UFO and New Age Movements and traditional religious dogmas. 
        If UIR compromises the Temporary Level-3/ Level-6 Planetary Maharic Seal 
any time between 2003-2006 , GA will be forced to allow Earth’s core time rhythm
to accelerate on its natural cycle. This will initiate rapid entry into the Three-Day 
Particle Conversion Period  and full Permanent Level-12 Planetary Maharic Seal  
(dimensions 1 through 12 Sealed to D-12 sub-frequency bands) before the Trion/
Meajhé Field Buffer Blanket accretes to global coverage . Areas of Earth not under suf-
ficient Trion/Meajhé Field protection will be unable to hold Permanent Level-12 
Maharic Seal; the intensive frequency infusions characteristic to the Three-Day Part-
icle Conversion Period will cause Earth Changes in unprotected areas. In this event, 
GA will initiate rapid acceleration of D-3 Nethra Phase Merkaba/Level-3 Temporary
Planetary Maharic Seal Safe Zones to D-9 Quatra Phase Merkaba/ Level-9 Temporary 
Planetary Maharic Seal protection. Portions of Earth’s Planetary Shields under Quatra
Phase Merkaba protection will then be shifted into merger with the Trans-Harmonic
Meajhé Zone Time Cycle . The neighboring Time Matrix of the Trans-harmonic 
Meajhé Zone Time Cycle will serve as a frequency buffer and “electromagnetic 
anchoring field” through which Safe Zone areas of the planet can be “hosted” into the 
Inner Earth Bridge Zone Time Continuum by 2012 .     
545                                              
 
                                                                                                                                                                 
                                                                                                                                                      

                       
                  Crisis Intervention Expedited Amenti Opening Schedule
          This is not the most desired scenario , but rather the final "Emergency Contin-
 gency Plan " that will be employed if events in this SAC proceed in a manner any 
 worse than they already have . If unfolding events dictate the necessity of invoking
 the Emergency Contingency Plan, GA will mobilize their earthly Indigo Children 
 Planetary Security Teams to offer regional Meajhé Zone  Evacuation  options, to get as      
 many people as possible into Quatra Phase Merkaba/Meajhé "Safe Zones." If the 
Three-Day Particle Conversion Period is triggered into activation before 2006, the        
Temporary Cap on the Falcon-Phoenix Wormholes will be partially compromised;  
areas with insufficient Trion/Meajhé Field Buffer Blanket protection will be left to       
progressive UIR infiltration and transfer into the Phantom Matrix Sub-T ime Distor-
tion Cycle. If a sufficient number of GA RRTs are conducted to maintain Trion/
Meajhé Field Buffer Blanket integrity, UIR forces will be unable to un-Cap the 
Wormholes, bring in “Mother Ships” for the “First Contact” drama or compromise the      
Temporary Level-3/Level-6 Planetary Maharic Seal in Merkaba “Safe Zone” areas. 
 32.   2003 Dec-2006 June:  GA continues to strengthen Trion/Meajhe Field Buffer Blan-      
        ket. Between Dec 2003-June 2006, Earth enters Level-6 Temporary Planetary Maha-      
        ric Seal  (dimensions 1-2-3-4-5-6 of Earth Sealed to D-12 sub-frequency bands)       
     sustained by 12-Code activation of Inner Earth Crystal Pylon Temples/Earth Cue      
     Sites #1, #2, #3, #4, #5 and #6 . Earth’s SGs and Ley Lines  #1, #2, #3, #4, #5 and       
        #6  will be protected under D-12 Maharic Seal. Temporary Level-6 Planetary Maharic       
     Seal will progressively move Earth and Tara into temporary hyper-dimensional sus-      
        pension of D-6 Planetary Hallah Phase Merkaba Vehicle , creating a temporary                   
        Level-6 D-12 Cap on the Falcon-Phoenix Wormhole. In June 2006, GA will acceler-      
     ate Level-6 Temporary Planetary Maharic Seal/D-6 Planetary Hallah Phase Merkaba      
     to Level-9 Temporary Planetary Maharic Seal/D-9 Planetary Quatra Phase Merkaba.      
     Regions of Earth capable of progressing into 2006 Quatra Phase Merkaba will be       
     fully protected from the physics realities of the 2006 Three-Day Particle Conver-      
     sion Period . If Three-Day Particle Conversion Period occurs before 2006, or if regions      
     cannot hold a Level-9 Temporary Planetary Maharic Seal by 2006, only areas with       
        critical mass Trion/Meajhé Field Buffer Blanket will retain Hallah Phase Merkaba/       
        Level-6 Maharic Seal sufficient to accelerate to Level-9 Temporary Planetary Maharic      
     Seal/ D-9 Planetary Quatra Phase Merkaba. Areas holding D-9 Planetary Quatra       
        Phase Merkaba will fully enter Trion/ Meajhé Field Buffer Blanket protection for       
        Three-Day Particle Conversion Period.
 33.  2006 June : Expedited Three-Day Particle Conversion Period and the 4.25 Trion      
     Buffer Bubble . Sometime between June and Dec 2006, Earth will encounter the       
        Three-Day Particle Conversion Period  (See page 223); fulfillment of the " Night of      
        the Two Moons"  prophecy. Earth will come into full alignment with the Holographic      
     Beam/Photon Belt ( originally due 2017, May 5-June 30 ), while protected within       
        the Trion/Meajhé Field Buffer Blanket. If the Three-Day Particle Conversion Period      
        is successfully postponed until 2006, GA will continue strengthening the Trion/       
        Meajhé Field Buffer Blanket in attempt to pull all of Earth  into D-9 Planetary Qua-      
     tra Phase/Merkaba Vehicle  hyper-dimensional suspension. In June 2006, Earth enters      
      Level-9 Temporary Planetary Maharic Seal  (dimensions 1-9 of Earth Sealed to D-12      
     sub-frequency bands) sustained by 12-Code activation of Inner Earth Crystal Pylon      
        Temples/Earth Cue Sites #1 through #9. Earth’s SGs  and Ley Lines  #1 through #9      
     will be protected under D-12 Maharic Seal, creating a temporary Level-9 D-12 Cap      
     on the Falcon-Phoenix Wormhole.  The Trion/Meajhé Field Buffer Blanket will       
     absorb and collect the frequencies that will release through the final three Stellar                 
        Activations/Stellar Wave Infusions , holding these frequencies in suspension until       
        2012 , when they will be released into Earth’s Planetary Shields in completion of the      
        Arcturian, Orion and Andromeda Activations. As the Three-Day Particle Conver-       
        sion Period approaches, the GA will create a temporary 4.25-dimensional  magnetic      
        field  within the Trion/Meajhe Field Buffer Blanket. The natural Planetary Shields of      
        Earth’s counterpart planet in the neighboring Trans-harmonic Meajhé Time Matrix 
546
                    
                 

                                       
                           Expedited Amenti Opening Crisis Intervention Program Begins
(not the planetary counterparts in THIS or the Inner Earth Time Matrix) will be used        
to accrete and sustain this 4.25-dimensional magnetic field in the Trion/Meahjé Field       
Buffer Blanket. 
        For the Three-Day Particle Conversion Period, during which time Earth’s natu-        
 ral magnetic fields normally collapse, the portions of Earth’s Planetary Shields and        
corresponding geographical regions in Safe Zones will be drawn into full vibrational         
co-resonance with the 4.25-dimensional magnetic fields sustained  in the Buffer Blan-        
 ket. This will allow regions of Earth, and populations, that are able to achieve tempo-        
 rary Quatra Phase Merkaba , to enter the Safe Zone of the 4.25 magnetic field region       
of the Buffer Blanket. The 4.25 magnetic field will create a stable D-4.25 “Energy        
Bubble”  within which the 3-dimensional particle base of Earth and its inhabitants             
 will be protected from the Three-Day Particle Conversion Period frequencies that set         
atomic transmutation in motion. Though the Three-Day Particle Conversion Period       
will commence in 2006, its manifest effects  will be temporarily delayed until 2012  due              
to the “4.25 Trion Buffer Bubble”.  In the original Amenti Ascension schedule, the         
Three-Day Particle Conversion Period was due to take place in 2017, at which time         
regions of Earth that could sustain 4.5 accretion  level would fully transfer into the        
 Inner Earth Bridge Zone Time Continuum. Areas and populations that could not sus-        
 tain 4.5 accretion  (all of 4th DNA Strand and one-half of 5th Strand activation)         
would separate and be drawn into the Phantom Earth/Phantom Matrix Sub-time Dis-         
tortion Cycle. Elements of the “manifest hologram” that “fell to Phantom Earth”             
would literally appear to have “disappeared” from the face of the Earth , to the per-      
ceptions of populations successfully achieving the Bridge Zone Time Cycle Shift. Pres-       
 ently, though posing more inherent risk of failure , the Emergency Crisis        
 Intervention program of the Trion/Meajhé Field Buffer Blanket provides for greater        
opportunities of population protection  not originally possible within the dynamics of        
physics of the Bridge Zone Project. 
         The “4.25 Trion Buffer Bubble” and the Trion/Meajhé Field Buffer Blanket sur-        
rounding it, will allow Earth to pass through the Three-Day Particle Conversion         
Period, through which progressive bi-polarization and separation of the global particle         
field and populations into the Bridge Zone and Phantom Matrix Time Continua will        
 occur.  By the end of 2006  this separation of Time Lines within Earth’s Planetary         
Shields will be permanent . However, the Trion/Meajhé Field Buffer Blanket will oper-          
ate as a " carrier wave field " that will temporarily hold the bi-polarized particle base of       
Earth’s Planetary Shields, time lines and populations together, in a state of slow-mov-       
ing particle suspension  during and for a time after, the Three-Day Particle Conver-       
sion Period. This process of SAC physics is distinctly different from the complete,        
 rapid separation of particle base, time lines and populations  that would have         
occurred during the later 2017 Three-Day Particle Conversion Period. All of Earth’s        
particle base and populations can be protected from falling into Phantom Matrix         
merger, if full Planetary Quatra Phase Merkaba  can be achieved in 2006 .  Popula-         
tions would no longer separate into the Phantom Earth and Bridge Zone Time Con-         
tinua as originally anticipated; all would  "make it to the Bridge Zone " continuum         
out of harms way . This ideal scenario is not likely to occur  due to the continuing         
counter-activities of the UIR; GA will none-the-less strive to achieve this ideal . If         
full Planetary Quatra Phase Merkaba can be achieved in 2006, the UIR invasion plans        
would be brought to a screeching halt as they would have insufficient time, before        
 2011, to compromise a 12-Code seal on nine dimensional levels of Earth-Tara-Gaia         
and their corresponding Time Continua.
       Unfortunately, the GA have insufficient time before 2006, to strengthen the              
Planetary Trion/Meajhé Field Buffer Blanket on a global level and to completely clear       
distortions in Earth’s grids to the degree required, to initiate full D-9 Planetary Quatra        
Phase Merkaba in 2006. Forcing a D-9 Quatra Merkaba on the entire planet in 2006,        
before Planetary Shields distortions were fully aligned with the D-12 Planetary Divine       
Blueprint, would cause pole shift and cataclysm for all.  GA will attempt to prepare         
the entire planet for 2006 D-9 Quatra Merkaba Conversion, but full success in         
this objective is not likely to occur.  Areas of Earth that do not have sufficient critical
547 
 
                                                                                                                                       
                                                                                                                                                                                                                  

                   Crisis Intervention Expedited Amenti Opening Schedule
mass of Trion/Meajhe Field frequency will be unable to hold a Level-9 Temporary       
Planetary Maharic Seal/ D-9 Quatra Merkaba. Such areas will endure progressive      
escalation of UIR/Illuminati OWO advancement, storms, famine, loss of life, quake      
and volcanic activity and political warring, and progressive deterioration of the Level-      
6 Temporary Planetary Maharic Seal. 
       “Safe Zone”  areas under sufficient Trion/Meajhé Field Buffer Blanket and Tem-      
porary Level-9 Temporary Planetary Maharic Seal protection will remain more stable,     
environmentally, politically and economically.  Conditions in unsafe zones will pro-      
gressively deteriorate as the UIR attempts to un-Cap the Falcon-Phoenix Wormholes,      
while advancing their invasion agenda in unprotected regions toward the 2011 Final      
Conﬂict. The 2006 Three-Day Particle Conversion Period will be the determining      
factor in what portions of Earth’s geography will undergo final cataclysmic shift      
into the Phantom Matrix in 2012 . Regions co-resonant with the Phantom Matrix       
time line will undergo some degree of geophysical changes , such as severe quaking or     
submergence beneath the waters, between 2006-2017 . But the populations  in these      
regions will still have some time left to develop biological co-resonance with Safe       
Zones, after Particle Conversion occurs. The 4.25 Trion Buffer Bubble will create sta-      
ble areas of land mass and culture that are held secure within D-9 Quatra Phase Merk-      
aba Field protection, and which will sustain a constant D-4.25  magnetic field.  The D-      
4.25 magnetic field will allow any life forms with 4.25 DNA Strand Template activa-      
tion²   to move into Safe Zone territories for final 2012  transition into the Inner Earth      
Bridge Zone Time Continuum.  Originally a 4.5 DNA Strand Template activation       
level was needed for passage into the Bridge Zone continuum. 
        Now, populations with a lower 4.25-DNA Strand Template activation  will       
have greater opportunity to “make it to the Bridge Zone” in 2012. The general Trion/      
Meajhe Field Buffer Blanket in Earth’s magnetosphere will provide non-Safe Zone      
regions with some degree of protection  during the 3-Day Particle Conversion       
period, preventing full planetary magnetic field collapse. These areas will be less stable      
and more prone to anomalous geological, climatic, atmospheric and electromagnetic      
phenomena than Safe Zone areas under the 4.25 Trion Buffer Bubble protection. Fol-      
lowing the 2006 Three-Day Particle Conversion Period, and until 2012 , regions and      
populations co-resonant with the Phantom Matrix time line will have greater protec-      
tion from succumbing to immediate Phantom Matrix descent. These regions of Earth      
will experience a " slow fall " to the Phantom Matrix, with less severe Earth Changes,      
spread out over a longer period of time, than would have occurred with the “fast fall”      
2017 Particle Conversion Period. The ''slow fall" allows for the potential of retrieving      
greater population numbers from Phantom Matrix demise. The 4.25 Trion Buffer Bub-      
ble plan was not originally considered viable,  as it required that Earth’s grid speed be      
rapidly accelerated by 2006 to a minimum of D-9 oscillation/ Planetary Quatra Phase      
Merkaba/ Level-9 Temporary Planetary Maharic Seal. This rapid grid speed accelera-      
tion increases the potentialities of greater Earth Changes and possibilities of pole      
shift  before 2012 arrives, which is a risk to all populations that Emerald Covenant       
nations were not originally willing to take.    
      As circumstances have evolved, the Anunnaki races  defecting from the 2000      
Treaty of Altair and 1992 Pleiadian-Sirian Agreements have made the decision for      
everyone . Due to their support of the UIR OWO dominion campaign, pole shift       
and destruction of the Human race  by 2008 would be a certainty, if the Trion/Meajhé      
Field Buffer Blanket and 4.25 Trion Buffer Bubble option was not immediately called      
into play. The Trion/Meajhé Field Buffer Blanket/4.25 Buffer Bubble plan will create a      
condition of progressively extreme bi-polarity  among global Human nations and Illu-      
minati collectives. “Very Safe” GA Safe Zone areas will be interspersed among “very      
unsafe” UIR dominated areas. Extreme differences in polarity between DNA Tem-       
plate activation levels, and thus maturity and stability of consciousness and fortitude      
of biological constitution among world populations, along with resultant confronta-
                          _____________________________
                            2.   All of Strand-4 and one-quarter of Strand-5
                            548       
 

                                
                                   Expedited Amenti Opening Crisis Intervention Program Begins
                            tions and con ﬂict between these polarity extremes, will progressively escalate while      
                        Earth is sustained within the Trion/Meajhé Field Buffer Blanket between 2006-2012.       
                        It will seem as if the world has “divided itself into “good vs. evil”, with little space      
                        between the two opposing consciousness factions; sadly, each “side” of the polarity      
                        drama will perceive themselves as the “victims” and “good guys”, viewing the “other      
                        side” as the “evil, victimizing enemy”. During these coming difficult times, GA  will      
                        promote the necessity of Healing through recognition of our Common Divine Source.      
                        They will also teach of the Law of One Christos realities of the D-12 Pre-matter      
                        Divine Blueprint, through which all polarities and separations can be mended, and by      
                        which beings of every species, race and creed can tangibly integrate the One-Spirit      
                        through which all life is created and sustained. People are free to choose whatever per-      
                        spectives they desire; our choices and beliefs will create the experiential reality we will      
                 perceive within this mass drama. 
____________________________________________________________________________
If we choose to believe the drama is not real, it will simply engulf and consume        
us; if we acknowledge the challenges presented and believe only in their effec-                               
     tive, loving resolution, we will know the mastery of co-creative victory. 
____________________________________________________________________
 
    34.  2006-2012:  Meajhé and Trion Zones- Polarized Earth in Trion/Meajhé Field Sus-      
 pension to 2012 . Following the 2006 Three-Day Particle Conversion Period, por-       
 tions o f Earth and its populations co-resonant to the Inner Earth Bridge Zone Time           
 Continuum will remain in the stable areas of the 4.25 Trion Buffer Bubble Safe Zone,      
 which is referred to as the Meajhé Field,  until 2012 . Until 2012, the Meajhé Field         
 will be sustained by Level-9 Temporary Planetary Maharic Seal/D-9 Quatra Phase      
 Merkaba Vehicle , when final transition into the Bridge Zone time continuum will      
 take place.  Meajhé Field Safe Zones, or “ Meajhé Zones ” will provide a natural fre-      
 quency buffer to the Three-Day Particle Conversion Period frequency infusions and          
 will be the most environmentally and culturally stable areas of the globe during the            
 remainder of the SAC. Meajhé Zones will also provide environmental support to the                         
 progressive 12-Code DNA Template activation of Human and Indigo populations.          
 Portions of Earth and its populations co-resonant to the Phantom Matrix Sub-time         
 Distortion Cycle will remain temporarily protected within the less stable Trion Field       
 of the Trion/Meajhé Field Buffer Blanket, the portion of the Buffer Blanket that sur-     
 rounds  the more stable 4.25 Trion Buffer Bubble Meajhé Zone.  
          The Planetary Trion Field will provide temporary protection from the 2006       
       Three-Day Particle Conversion Period, and will to some degree buffer the transmuta-      
    tive frequencies characteristic to this event; it will protect these areas from Phantom            
       Matrix descent until 2012. Ideally, the Planetary Trion Field will be sustained by       
       Level-6 Temporary Planetary Maharic Seal/D-6 Hallah Phase Merkaba Vehicle       
       until 2012, when final transition into the Phantom Matrix time continuum will take      
       place via apparent regional Earth Changes.  Areas of Earth under Trion Field Hallah      
       Phase Merkaba protect are called “Trion Zones”. Earth’s SGs and portals in Trion             
       Zones, protected by the Trion Field Hallah Phase Merkaba, will have only a 6-dimen-      
       sional protective seal . Despite GA efforts to retain this protection, UIR forces may             
       compromise this Level-6 Temporary Planetary Maharic Seal to partially un-Cap the          
       Wormholes as early as 2005, which will intensify Earth Changes potentials in these               
       regions in 2005 and during the 2006 Three-Day Particle Conversion Period. Follow-                
       ing Earth’s 2006 passage through the Three-Day Particle Conversion Period, areas              
        under Quatra Phase Merkaba/Meajhé Zone protection cannot be intrinsically com-            
       promised by UIR activities. Meajhe Zones may suffer a small degree of temporary               
       instability if UIR infiltration of Trion Zones is extensive, but Meajhé Zones will re-              
       stabilize to complete the Bridge Zone time continuum shift in 2012.
           If UIR is successful in eroding the Level-6 Temporary Planetary Maharic Seal in            
    Trion Field areas, they will move forth with their intended Illuminati OWO agenda,      
    Frequency Fence and "First Contact" drama. In this case, populations within Meajhé      
    Zones  will be most protected from the effects of OWO progression. Beginning in            
    2002-2003, GA will provide the Indigo Planetary Security Team with information for
         
         549                                                                                                                    
                                                                                                                                                                                                                                                 
 

         Crisis Intervention Expedited Amenti Opening Schedule
public release, and eventually Safe Zone Progression Maps , pertaining to the geo-
graphical development of Meajhé and Trion Zone areas. The regional Quatra Phase
Merkaba Vehicles surrounding "Meajhé Safe Zones" will operate like '' invisible envi-
ronmental force-fields ." Populations can come and go through these areas unabated. 
With a bit of a practice, individuals with DNA Strand Template-4 12-Code activation 
or higher will be able to sense the electro-static boundaries  of Meajhé Zones. Those    
with lesser strand level, or less than 12-Code3), DNA Template activation will be 
unable to detect Meajhé Zone perimeters. Under most conditions, conventional sci-
entific instruments are not sensitive enough to multi-spectrum electromagnetic sub-
tleties to detect Meajhe Zones. The Quatra Phase Merkaba Vehicles of Meajhé Zone
regions will hold the natural "Divine Blueprint '' integrity of nine out of 12 dimen-
sional levels of the land, atmosphere and magnetic fields in these regions, creating
enhanced biological protection from UIR Frequency Fence, RIT, Psycho-tronic and 
Bio-warfare technologies. 
       The Planetary Shields in Meajhé Zone areas will hold higher frequency and
have a faster particle pulsation rhythm, which will make these areas seem " almost 
invisible " to Illuminati and UIR attentions. People with 12-Code activating DNA4 
will be instinctually drawn to Meajhé Zone areas via vibrational co-resonance  of the
biological/mental/emotional/spiritual bodies. Individuals carrying excessive DNA     
Template and consciousness distortions, such as Illuminati and Fallen Angelic races, 
or people carrying Fallen Angelic astral Tagging or possession, will experience varying 
degrees of biological disharmony and mental/emotional fatigue or agitation in     
response to Meajhé Zone frequencies.5
       Meajhé Zone and Trion Zone regions and the populations within them will 
exist “side by side”, each experiencing a different set of events and frequencies,
until their final separation in 2012 . GA general education programs will continue to
focus upon assisting people to regenerate the DNA Template, Bio-energetic Field and 
Spiritual Consciousness integrity that is needed to sustain the body within Meajhé
Zone areas. Meajhé Zone Indigo education programs will focus upon Crisis Interven-
tion “Trouble Shooting”, the advanced Planetary Templar Mechanics needed to sus-
tain the integrity of the Meajhé/Trion Field Buffer Blanket, coping skills for 
accelerated DNA Template activation, outreach programs to assist those in Trion 
Zones and preparation for physical GA contact. After the 2006 Three-Day Particle
Conversion Period, the GA, via the Indigo Team, will "put out the last call" for Emer-
ald Covenant Amnesty and Redemption Contracts . All Illuminati races  and 
Humans desiring to become free of Fallen Angelic manipulation and Phantom Matrix 
descent will have a final opportunity to "make it to the Bridge Zone." These efforts 
will continue until  2011 , when the last round of the "Final Con ﬂict" drama is due to 
unfold. 
35. 2011:  The Final Conflict Drama Begins –Invasion Attempt, “Wingmakers”, the
BeaST and the Shield.  Nibiruian Battlestar Wormwood,  if left untouched in its usual 
3657.8  year orbit, was is due to pass through the Asteroid Belt between 2008-2024; GA 
will slow Wormwood's passage and reduce it to fragments before Asteroid Belt inter-
section, producing likely cycles of intense but manageable meteor showers 2011-2015. 
Between 2008-2012 Planet Nibiru,  presently in Phantom Matrix Sirius A orbit on 
the "other end" of Wormwood’s reverse, "tilted" elliptical orbit plane, will undergo
pole shift and realignment of its natural orbit, returning to its organic position beyond
Pluto’s orbit in our galactic system. Return of Nibiru to its natural orbit will take place 
                          _____________________________________________
3.   12th of 12 sub-frequency bands in each Strand Template activated.
4.   Christos Divine Blueprint activation, with the full spectrum of 12 sub-frequency bands in 
      each DNA Strand Template activating.
5    Resetting and progressive activation of the natural personal D-12 Divine Blueprint in the                                                        
      DNA Template, via consistently applied Bio-Regenesis technologies and Temporary Per-     
      sonal Maharic Seal can allow anyone opportunity to partake of the benefits of Meajhé
      Zone areas and the Bridge Zone time continuum shift.
550 
 
                 
               
         

     
                                 Expedited Amenti Opening Crisis Intervention Program Begins
  after Earth’s successful passage into, and stabilization within, the Bridge Zone time 
   cycle. On Earth, the UIR is likely to succeed in at least partially fulfilling its  2005 
  First Contact '' invasion  attempt within the Trion Zones.  If the GA is successful in 
  creating the 2003 Level-3 Temporary Planetary Maharic Seal, the 2003 UIR invasion 
  schedule will be effectively postponed, but not permanently prevented. In 2005 , it is
  unlikely that UIR will be able to utilize their massive Mother -ship ﬂeet, due to the 
  Cap on the Falcon-Phoenix Wormholes. The use of smaller craft and a less dramatic
  public debut are the more likely UIR strategies. (If UIR erodes the Level-3 D-12 Cap 
  on the Wormholes, the UIR "Mother ship" agenda may unfold in 2005 as they had 
  originally planned.) The GA’s successful activation of the "4 Faces of Man"/"Guard-
  ians of the 12 Pillars" LPIN and "Great White Lion" and "Golden Eagle" APINs will 
  thwart the UIR “real estate clearing through 2008 pole shift” agenda. The GA LPIN/
  APIN systems, coupled with the Trion/Meajhé Field Planetary Buffer Blanket, will 
  hold the core of Earth’s Planetary Shields stable throughout the SAC until 2011, 
  when the only remaining “ window of opportunity ” to create planetary pole shift             
         arises.   
    
    Whether the UIR has succeeded or not in progressing to on-planet physical pre-
sence, they will launch their last invasion attempt in 2011.  This will be their last chance
to prevent the Emerald Covenant nations from permanently  severing the links between 
our living Time Matrix and the Phantom Matrix  via fulfillment of the Emerald Cove-
nant Founders’ Christos Realignment Mission.   It will be the UIR’s last opportunity ever
to gain access to the Halls of Amenti Star Gates and Inner Earth Time Cycle territories.  
   If the GA is successful in 2012, the scalar-field templates of our Universal Time 
Matrix and those of the Phantom Matrix will be permanently severed , effectively closing
all Wormhole links to the Phantom Matrix in our 15-Dimensional Time Matrix. Our 
Time Matrix will be prevented from being consumed by the Black Hole Sub-time Distor-
tion system Phantom Matrix anomaly and finally, after literally 250 billion years of 
intergalactic warring,  Phantom Matrix races will no longer be able to enter our Time 
Matrix for feeding and invasion.  Phantom Matrix races remaining in our Time Matrix 
will require DNA Template 12-Code Bio-regenesis  to biologically survive in this system,
and their advanced weapons systems and technologies will no longer function without 
access to the reversed-polarity  electromagnetic currents  of Phantom Matrix.  
                 If the UIR’s intended 2011 final invasion attempt fails, as it is likely to do  if the GA
Crisis Intervention Plan succeeds to this point, Fallen Angelic races will have one final 
opportunity to enter Emerald Covenant Redemption Contracts for DNA Bio-Regenesis 
under galactic quarantine in the Sirius star system . If they refuse this opportunity, their 
only remaining options will be to return to Phantom Matrix before it is closed, or to 
live out a finite destiny of rapid biological and technological deterioration, within galax-
ies of this Time Matrix that have not yet been placed under full Level-12 Maharic Seal. If 
the Planetary Christos Realignment Mission, which was originally scheduled for comple-
tion during the 22,326 BC SAC , is not completed during this SAC, the Halls of Amenti 
will progressively fall to Phantom Matrix particle fusion.   
             The Phantom Matrix is an unnatural Black Hole system  that continually accretes 
 energy and consciousness  from the living “host” Time Matrix to which it is attached.  In          
           22,326BC, the Founders recognized that the Phantom Matrix, created during the Lyran-    
              Elohim Founders Wars 250 billion years ago,6 had almost reached critical mass accretion. 
The Black Hole system had pulled into itself nearly as much energy mass and conscious-
ness than that organically held within our natural living Time Matrix. If the Phantom 
Matrix reaches critical mass accretion , its draw upon the living Time Matrix will progres-
                             sively accelerate and our living Time Matrix will be permanently “pulled off  the grids” of                                 
                  the Density-5 Primal Light Fields and into the chaotically organized, finite Phantom 
                              Matrix. If the Christos Realignment Mission  is not successful during the current SAC,    
                     this entire Time Matrix, not only the Earth, will be pulled into the Phantom Matrix  
                             Black Hole via the Halls of Amenti Star Gates. Many innocent inter-galactic civilizations   
                           
                             ________________
                            6.    Earth time translation    
                               
    
                            551                                                                                                         
                                                                                                                                                        
                                                                                                                                        
                                                                                                                               

                      Crisis Intervention Expedited Amenti Opening Schedule
would be trapped in Phantom Time, denied their birth right of organic Ascension, Mas-      
tery and Eternal life. The Emerald Covenant Founders have allowed the Phantom Matrix      
to remain attached to our Time Matrix for over 250 billion years,  in hope of lovingly re-      
evolving the Fallen Angelic races r esiding there within. The Founders and the Fallen      
Angelics knew in 22,326BC that the “ time was up ” for giving the Fallen Angelic races      
further evolutionary opportunity; the " host" Time Matrix was due to collapse  due to the       
continuing competitive choices of exploitation repeatedly made by the Fallen Angelic      
races. No one is treating the Fallen Angelic races unfairly; since 22,326 BC they have      
been faced with the product of their own unloving, exploitative choices .              
       Since the issue of severing the ties between the Living and Phantom Matrices came                     
 to a head in 22,326 BC, the Fallen Angelics have planned to achieve forced dominion of      
this Time Matrix, with intention of drawing it into Phantom Matrix as an energetic “food           
supply”. They continue to make this unfortunate choice, rather than accepting the             
Founders continually loving invitation into peaceful Emerald Covenant Co-evolution           
Freedom Treaties. Through cooperation with the Founders races, the Fallen Angelic races     
could progressively heal to re-enter At-One-ment with the Cosmic design, through              
which the Phantom Matrix could be healed.  If the Anunnaki had been true to the 1992        
Pleiadian-Sirian Agreements, the time of  Fallen Angelic accountability would have      
been postponed until the 4230 time continuum end. Due to the Anunnaki, Drakonian      
and Necromiton-Andromie races continual and contemporary choices of War over peace,      
hatred over love and dominion over freedom, they have brought their own “Day of Judg-      
ement”  down upon themselves. The Emerald Covenant nations wish the Fallen Angelics’     
no harm, and are not judging them as “unworthy”, but neither can they further permit the     
self-serving Fallen Angelic nations to bring death, sorrow, pain and destruction to the      
peace-loving races of this Time Matrix. The Planetary Christos Realignment Mission  will        
be fulfilled in 2012 , as part of the Universal Christos Realignment Mission  now taking      
place in this Time Matrix. It is the time for the Fallen Angelics themselves to judge      
“which side of  the fence” they will end up on as the Christos R ealignment Mission is fulfilled . 
                 2011 MEAJHÉ FIELD WEAKNESS, UIR JEHOVIAN SEALS  
                                                           AND TRUMPET PULSE    
        
     In 2011 the UIR will attempt to take advantage of a temporary weakness  in the 
Planetary Meajhé Zone Field. This Meajhé Zone weakness will naturally occur as Earth’s 
Planetary Shields transition from D-9 Quatra Phase Merkaba into D-12 Mahunta Phase
Merkaba  to make the final 2012 link with the Inner Earth Bridge Zone time continuum.
As Earth’s Planetary Shields are prepared to fulfill the 2012 shift in Angular Rotation of 
Particle Spin from the 4.25 Trion Buffer Blanket, the natural spin ratios of the planetary 
Quatra Phase Merkaba will temporarily slow. This temporary 3-4 month Quatra Phase 
Merkaba slowing  will cause the Level-9 Planetary Maharic Seal to temporarily dip to a
Level-7 (7-dimensional) Maharic Seal . During this period there is a remote chance that 
the UIR could utilize the " Seven Trumpets"  sub-space sonic pulse technology on D-7
Phantom Arcturus  to re-activate the Seven Jehovian Seal sites on Earth, to blast 
through the temporary Cap on the Wormholes before the Cap becomes permanent in 
2012.  
                        If  this endeavor were to be successful, and the Falcon-Phoenix Wormholes were to 
                 be reactivated as the Meajhé Zones of Earth were transitioning into the Bridge Zone con- 
                 tinuum, cataclysm would result. The Quatra Phase Merkaba needed for the Bridge Zone 
                 link would be slowed in speed, via “Trumpet” pulse, to that of a D-6 Hallah Phase Mer-
                    kaba Vehicle. Once Meajhé Fields were reduced to D-6 vibration, the “Trumpet Pulses” of 
                 D -7 Phantom Arcturus could be used to force Earth’s D-6 Hallah Phase Merkaba into the 
                 re verse-rotation characteristic to Phantom Matrix. The Trion/Meajhé Field Buffer Blan-
                 ket would prevent Meajhé areas of Earth from being pulled into Phantom Matrix, but 
                 would not sustain grid speed acceleration sufficient to make the Bridge Zone link. Cata-              
                 clysmic Earth changes would begin followed by pole shift by 2012 . If this diabolical UIR 
                 strategy   were    to     succeed,  little  of      Earth’ s     populations would   survive. GA    Maharajhi      fleets  
                  from Sirius B would descend through the Halls of Amorea passage in attempt to launch
                  
                                 552                                
                         
                       
   

                                       
                             UIR, “Wingmakers”, the Labyrinth Weapon and 2011
evacuations and to protect the 12 Primary Cue Site entrances to the Inner Earth Halls of 
Amenti control temples. Intensive “Star Wars”  would break out in Earth’s skies and
regional galaxies, with earthly nations caught in the crossfire, as UIR and competing rebel 
Omicron-Drakonian ﬂeets from Phantom Matrix poured into Earth’s local galaxies.
Though Emerald Covenant ﬂeets would succeed in preventing UIR takeover of the Inner 
Earth Halls of Amenti control sites, the Planetary Christos Realignment Mission and 
Level-12 Planetary Maharic Seal could not be fulfilled due to further damage to Earth’s 
Planetary Shields. Human civilization on Earth would again be decimated, as it has been 
several times in the past, and major intergalactic wars would again break out as they did 
550 million, 30 million, 5.5 million and 4.5 million years ago. The 2011 period of weak-
ness in Earth’s Meajhé Zones is anticipated to begin between April-July 2011 , and will 
last for a 3 to 4 month  period, into August or latest Nov of  2011. UIR has their  final con-
quest invasion strategy underway, but so too do Emerald Covenant nations have their
counter-strategy in place.  
                  
                                        UIR, “WINGMAKERS” THE LABYRINTH WEAPON AND 2011                   
                                         A collective of renegade Necromiton-Andromie/Jehovian Anunnaki hybrid
 Nephilim races , now members of the UIR, have been initiating progressive covert con-
tact with a group of Humans known as the Labyrinth Group ”. The Labyrinth Group is a 
covert collective of humans directly involved with the 1972-1973 archaeological discover-
ies known as the " Ancient Arrow Wingmakers Site " in New Mexico . Using their usual 
talents of truth-twisting, dispensation of partial knowledge and embellished disinforma-
tion, this Nephilim group, which is code named the “ Corteum ”, have deceived the Laby-
rinth Group into assisting them to create a  crystalline-scalar-mechanics based weapons
technology . In order for the UIR to take advantage of this final 2011 invasion opportu-
nity, they must re-activate the Seven Jehovian Seal sites on Earth in order to use the
"Seven Trumpets" technologies of D-7 Phantom Arcturus to upcap the Falcon-Phoenix 
Wormholes. The Seven Jehovian Seal sites will have been re-calibrated to a Level 9 12-
Code Pulse7 by 2011. The technology the Corteum has inspired the Labyrinth Group to 
create is intended to assist the UIR in re-activating the seven Jehovian Seals on a Phan-
tom Matrix electromagnetic pulse, to allow for fulfillment of the UIR’s OWO final vic-
tory.  
   The Corteum technology utilizes inter-time manipulations  intended to create
"minute time rips " into the Phantom Matrix in regions connecting to the Seven 
Jehovian Seal sites. Through these "minute time rips." which represent a type of worm-
hole bridge, the UIR intends to build up sufficient sub-space photo-sonic "charge" within
the Axiatonal Line system of Parallel Earth.  The photo-sonic charge is intended to be
progressively stored and amplified in the Parallel Earth Planetary Shields until  2008,  
at which time the charge is intended to be split into two " Phantom Electrostatic ionic 
pulses. " One pulse is to be sent back in time to the original 10,500 BC creation of the 
Falcon-Phoenix Wormholes, the other into " future time " in the Phantom Earth time 
cycle.  The "past" pulse will connect the 10,500 BC  Atlantian period  of Phantom Earth,  
in which the Luciferian Rebellion takeover attempt succeeded, to our present time con-
tinuum line. The "future" pulse will connect the "future" of Phantom Earth, which 
evolved from the successful Phantom Earth Luciferian Conquest “past”, to our present
time continuum. Through the mechanics of the Labyrinth Group’s Corteum technology,
which the group has code-named the " Blank Slate Technology " or " BST " (Founders
think of it as " the BeaST "), the UIR intends to accumulate photo-sonic charge in the 
Phantom Earth future location and the 10,500 BC Luciferian Conquest period of Phan-
tom Earth Atlantis. When the 2011  "window of opportunity" opens, the UIR intends to
use the contemporary "BeaST" to direct the amplified photo-sonic charge simultaneously 
into the Seven Jehovian Seal sites of Earth’s Planetary Shields, in the contemporary time,
past Atlantian and future Phantom Earth periods.   
         
         ____________________________  
          7.   9th dimension sealed to the 12th sub-frequency band.  
          553  
                                                                                                                            
                                                                                                                                                                                                                                                                     

         Crisis Intervention Expedited Amenti Opening Schedule  
       Release of the “ BeaST Pulse ” is intended to accomplish several invasion objec-
 tives, the first of which is to re-activate the Seven Jehovian Seal sites in each time period. 
 The second objective of the BeaST Pulse is to tear Earth’s Shields apart via bonding 
 Earth’s grids to the compromised grids of Parallel Earth, which are presently linked to 
     Phantom Earth. Completion of the second objective, which would culminate in the       
      North American continent begin vertically ripped into two sub-continents along the               
       Mississippi River vertical,  is intended to set the stage for fulfillment of objective three .
 Objective three constitutes the intentional shattering of the dimension 8 through 12 por-
 tions of Earth’ s Planetary Shields and reversal of the natural “Fire Letter Sequences”8 
 in the D-1 through D-7 portions of Earth’s Planetary Shields. This despicable plan would 
 seemingly serve to " erase history ," creating a " Blank Slate " of Earth history within which 
   to inset the history of Phantom Earth (thus the “BS-T” code name). Once the BeaST         
    Pulse was used to link past and future Earth to Phantom Earth, the “ Seven Trumpets ”           
   sub-space sonic pulse technologies of Phantom Arcturus would then be used to un-Cap,
  then merge, the Falcon-Phoenix W ormholes in present time. Portions of Earth’ s Plane-
  tary Shields under Trion Zone  suspension would be torn away and drawn into merger 
  with Phantom Earth. Corresponding portions of our present time line would be drawn 
  into merger with a corresponding present point in the Phantom Earth time line, and 
  these  portions of our present time line would be "spliced " into a position between the 
  10,500 BC Atlantis and future Atlantis in Phantom Earth’s time line .  
       It would be as if our true history was “erased” and a  portion of our present literally
 inserted into the Phantom Earth time line.  Portions of Earth’s Planetary Shields under 
 Meajhé Zone  protection would be destabilized under a D-6 Planetary Hallah Phase Merk-
   aba Vehicle, and what remained of Earth would be heading for rapid pole shift  in 2012.          
  The Labyrinth Group of the Ancient Arrow Wingmakers project have no idea that
they are being deceived into creating the very technology that could lead to the 
destruction of Human civilization in 2011 . (Wake up guys—you’ve been taken for  a 
ride!).The people involved with the Labyrinth Group and associated organizations have   
been convinced  by the Nephilim “Corteum,” (they don’t even know they are Nephilim)     
that   only by developing the Corteum’s “BeaST” can Earth be protected from ET invasion.                             
The Labyrinth Group was told that a “big, bad invader race”9 is planning to invade Earth        
in 2011 and that the Corteum “BST weapon” is the only way to prevent this invasion.
 The UIR Corteum need the Labyrinth Group to create this technology for them,  as the
 Corteum cannot access the earthly scientific facilities, resources or geographical positions 
 needed to assemble the tactile components of the BeaST weapon. It is the Corteum
 themselves, and their recent allies of the UIR, that are intending to invade in 2011 ; 
 their rebel Omicron-Drakonian adversaries are intending a counter-invasion in hope of 
 preve nting UIR/Corteum victory.    
             The “Wingmakers Ancient Arrow” archeological site does not belong to the Lab-
 yrinth Group, or to the Corteum.   It belongs to a group of Emerald Covenant Angelic
  Human Races  from the Interdimensional Association of Free Worlds  in the 6520 AD 
 time period and to the Elohei-Elohim Founders , who long ago buried “time capsule trea-
 sures”  in this region specifically for discovery in this time.10 The Elohei-Elohim have 
 approached the Labyrinth Group with invitation to the Emerald Covenant, but the Laby-
 rinth Group refused when the Elohei-Elohim explained the non-violent solution  to the 
 pending UIR invasion. The Labyrinth Group also knows that the “Central Race” Elohei 
 and Angelic Humans will not support their efforts of creating the BeaST weapon , but the
 Corteum have convinced the Labyrinth Group that the invasion cannot be prevented using 
 peaceful methods. The Corteum and UIR are very interested in the Ancient Arrow site, as 
 hidden within this area is the very tool by which Emerald Covenant nations can prevent
 the 2011 UIR/Corteum Invasion.   
          
            _________________________________   
  8.     scalar-wave sequences.  
  9.     AKA the UIR’s rebel Omicron-Drakonian adversaries.  
  10.   The labyrinth Group refer to these races, whose identity is actually unknown to them, as 
          the “ Wingmakers”  or “Central Race ”. 
  554  
          
         

UIR,  “Wingmakers,” the Labyrinth Weapon and 2011
An ancient device called a “Signet Shield” is buried in the area of the Wingmakers  
Ancient Arrow site, under GA Eieyani sonic-force field protection. The Signet (“Star  
Gate”) Shield disc is one of a set of 12 Signet Shields given to the Human Cloister Race  
Guardians of Earth over 200,000 years ago, by the Maharajhi of Sirius B, on behalf of the  
Elohei-Elohim Emerald Covenant Founders. The 12 Shields are manual activation/control  
devices for Earth’s 12 Star Gates, which can be put into use by combining them with their  
12 corresponding Emerald Covenant CDT-Plate disc activators.11 The Wingmakers site in  
New Mexico has been the storage place for Signet Shield-6, since the device was removed  
from Cue Site-6 in India in 5,900 BC, when the Rama races endured direct aerial assault  
from the Marduke-Dramin-Anunnaki and Centaur group during the Centuarian Invasion  
period. Signet Shield-6, and its corresponding SG/Cue-Site-6, is the Emerald Covenant  
“Trump Card” in this Final Con ﬂict drama. Signet Shield-6, SG/Cue Site-6 and the D-12  
Halls of Amoera Passage, in conjunction with three other Signet Shields/SGs/Cue Sites and  
Masters Planetary Templar Mechanics, will be used in 2011 to protect Earth and the Bridge  
Zone Project from UIR invasion during the Meajhe Zone weak period. GA anticipates a  
successful passage through the potential UIR invasion of 2011.
_________________________________________________________________________
If we make it this far in Plan A and "fix the problem," the forces of peace , love
and genuine Christos enlightenment are likely to achieve final 2012 victory on
Earth and in this Time Matrix.________________________________________________________________________
    The Wingmakers “Music discs,” CD translations of which are presently promoted  
via mainstream distribution networks, were not originally part of the GA/Emerald Cov-  
enant Founders “time capsule.” These musical subliminal-command encryption pro-  
grams were provided by the Corteum and added to the Ancient Arrow site “finds,” as 
were certain pieces of Corteum artwork containing bio-stimulus mathematical codes,  
and a set of history recorder discs that have yet to be unearthed containing falsified  
Nephilim/Human history.
The real Wingmakers history and musical recorder-discs, smaller versions of the  
CDT-Plates, were placed in 5,900 BC, and are still in various protected regions of the  
GA Wingmakers site. Discovery of these true Human Race history Records, along with  
other such “GA Time Capsules” placed around the globe, will be permitted by the  
Founders between 2013-2017, as part of GA identity validation just prior to Emerald  
Covenant nation mass contact. The Corteum music and art selections are ‘Trojan  
Horse” technologies intended to affect the function of the DNA Template, creating the 
emotional experience of “calm, bliss and spontaneous cognition” via subtle biochemical/  
neurotransmitter/brainwave direction, while simultaneously blocking natural Pineal  
Gland and DNA Template 12-Code activation. These technologies can, however, be  
enjoyed without detrimental effect, if the Temporary Personal D-12 Maharic Seal Tech-  
nique (see page 499) is used prior to listening or viewing. The D-12 sub-harmonics of the  
natural Maharic Seal will block detrimental portions of the subliminal sound/light pro-  
grams from activating in the DNA Template. The Wingmakers Art Work is a combina-  
tion of Angelic Human visual/bio-stimulus images, with select pieces of Corteum  
control-program images mixed in among the Angelic Human artwork. One can detect  
the subtle difference in frequency between “healthful” Angelic Human images and  
“repressive” Nephilim/Corteum Intruder ET images by using the Maharic Seal Tech-  
nique, then sensing the energy signature behind the image. A deep, low, rumbling “ULF  
background cyclic vibration pulse” can be easily sensed in the Corteum images. Angelic  
Human images will not have this ULF “Phantom under-pulse,” but rather, each image  
will carry a set of three subtle UHF “inner sound tones” that are “frequency keyed” to  
12th-sub-frequency band of D-6 and the 6th-DNA Strand Template. Angelic Human  
Wingmaker images were designed to frequency-trigger progressive activation of Human  
and Indigo DNA Strand Templates 4-5-6, to accelerate Pineal Gland and DNA Tem-  
plate 12-Code activation.
_____________________________        
11.CDT-Plates are all under GA protection as of 1999.      
 
555

  Crisis Intervention Expedited Amenti Opening Schedule
    36.  2012 Dec:  Meajhe-Trion Separation, Christos Realignment and Emerald Covenant
Mass Contact . The Final Con ﬂict drama of the 2000-2017 SAC will reach its conclu-
sion in 2012. The two bi-polarized segments of Earth’s particle base, the Trion Zones  
and the Meajhé Zones , that were held in suspension within the Trion/Meajhé Field
Buffer Blanket begin their final separation . Through the Indigo Children Planetary
Templar Security Team, the GA will release specific information on Meajhé Zone safe 
areas, urging populations to remove into these areas before Dec 2012. Trion Zone
areas will undergo regional Earth Changes  during 2012, as the final phase of the
Christos Realignment Mission completes in 2012. In early Dec 2012 , the frequencies
of the final Stellar Activations /Stellar Wave Infusions will begin. Meajhé Zones  of 
Earth will remain in the 4.25 Trion Buffer Bubble, as the suspended frequencies of the 
D7/D8 Gold Wave Infusion/ Arcturian Activation  that began in Aug-Sept 2002,
complete  activation in Earth’s grids. Completion of the Arcturian Activation will be 
rapidly followed by release of the suspended frequencies of the D8/D9 Silver Wave 
Infusion  and Orion Activation , and the D9/D10 Blue-Black Liquid Light Wave
Infusion and Andromeda Activation (original schedule 2017) . As the Arcturian, 
Orion and Andromeda Activations complete, the Trion Zone  areas will begin their 
cycle of localized Earth Changes that will mark the passage of unsecured areas of
Earth’s Planetary Shields into merger with the Phantom Matrix time line.  Portions of 
Earth territories under Meajhé Zone / Quatra Phase Merkaba protection will begin
their shift into full merger with the Inner Earth Bridge Zone time continuum.  In the
original Amenti Ascension Schedule, due to terms of the 1992 Pleiadian-Sirian 
Agreements, the final phase of the Founders’ Christos Realignment Mission was not 
due for completion until the 4230  end of our present continuum cycle. Due to the 
Anunnaki/Anu-Elohim defection and nullification of the Pleiadian-Sirian Agree-
ments and UIR War Edict, the Emerald Covenant Founders will now complete the 
   Christos Realignment Mission , as they had attempted to do during the failed SAC of 
22,326 BC.  The Founders intended to complete the Christos Realignment Mission 
since that time long ago, until compromising their agenda to accommodate the
potentialities of peace  held within the 1992 Pleiadian-Sirian Agreements.
    37.  Dec 21, 2012 : This is the date the Founders have chosen for fulfillment of the Chris-
         tos Realignment Mission .  This date now translated into our contemporary calendar 
    from the ancient Lemurian/Mu’a Founders calendar system, was  not recently chosen.  
    This date was chosen for completion of the Christos Realignment Mission in 22,326 
    BC , by the Emerald Covenant Elohei-Elohim Founders, Eieyani, Azurite, Maharajhi 
      and Angelic Human races, when the SAC of that Lemurian/Atlantian time period
         failed due to Anunnaki invasion.  The date was chosen through mechanics of inter-
           time physics; the point in “future time” that we now identify as Dec 21, 2012, marked 
            a point   within   the 2000-2017 SAC in which planetary positions would be in  the  most 
                                appropriate alignment to complete full , Permanent Level-12 Planetary Maharic
         Seal.  Throughout our recorded history this date was known by various ancient cul-
         tures as the time of the “ Great Cleansing”  or “The End of Time”, as illustrated for us 
           today in the ancient Mayan Calendar .            ________________________________________________________________________                          
                        On Dec 21, 2012, the GA will finally be able to fulfill their originally
                                    intended mission of setting Earth, and this Time Matrix, 
                                                        free from Fallen Angelic terrorism.           _________________________________________________________________       
     
     On this date, the Emerald Covenant Founders races will release the Universal SC 
Seals on Universal SG-12 in our Time Matrix, the Inner Earth Time Matrix and the 
Trans-Harmonic Meajhé Time Matrix, fully linking the three Time Matrixes, the " Divine 
Cosmic Trinity ," together. While remaining in the Bridge Zone time continuum and 
Trion/Meajhé Field Buffer Blanket, Earth will receive three additional Stellar Wave 
Infusions/ Transmutative Stellar Activations on this day . The D10/D11 Silver-Black 
Liquid Light Infusion  and D- 10 Lyra-Vega Activation , the D11/D12 Pale Silver Mah-
arata “Christos”  Liquid Light Infusion  and D-11 Lyra-Aveyon Activation , and the long-
awaited D-12/Primal Light Field “Rainbow Ray”  Infusion  and D-12 Lyra- Aramatena  
Activation.  D-12 Lyra-Aramatena, home of Universal SG-12 in our Time Matrix, is the
556 
                                                                  

                                 
                                     
                                        UIR, “Wingmakers”, the Labyrinth Weapon and 2011
          Density-4, D-12 Pre-matter Hydroplasmic Liquid Light " Christos Divine Blueprint " of 
           the Earth-Tara-Gaia System. The "Shield of Aramatena," as this scalar template is called,
          is also the D-12 Pre-matter Universal Divine Blueprint,  or “Universal Christos”, for all
         intergalactic systems in the 12 dimensions of Densities-1 through 4 in our Time Matrix. 
    
                     Earth    will enter  the "Christed" state of   D-12 Mahunta Merkaba  on Dec 21, 2012;
          the Halls of Amenti    Star Gates and 12 Star Gates  of Earth’s Templar will remain per-
         petually open  after this point, and Emerald Covenant races will begin preparation for a 
         long overdue re-introduction. Earth’s SGs and Seven Primary V ortices will not enter a 
           closing cycle, as they would have done in the original Amenti Ascension program. As the
            Permanent Level-12 D-12 Planetary Maharic Seal  activates in the Planetary Shields of 
        Earth-T ara-Gaia, the scalar-wave templates of our Time Matrix and those of Phantom 
           Matrix will naturally and permanently separate.  
          ________________________________________________________________            
                    The Universes in our Time Matrix will begin the victory celebration  they have  
                    awaited 250 billion years,  since formation of the Phantom Matrix during  the  
                                                        Founders Lyran-Elohim WarS.               _______________________________________________________________           
                                     Earth races will soon afterward be prepared for a visit from the Inner Earth Eieyani , 
         Sirius B Maharaji, Azurite, Aethien and Serres Emerald Covenant races , who will
           make contact on behalf of the Founders, to invite Earth’s peoples into the Emerald Cove-
         nant. Physical Mass Contact with Emerald Covenant nations is scheduled for 2017
            The UIR will be unable to use their weapons technologies, or infiltrate Earth’s Halls of 
           Amenti SG system once Earth is under full Permanent Level-12 Planetary Maharic Seal/
        D-12 Mahunta Phase Merkaba. Fallen Angelic and Illuminati races that do not engage 
        DNA Bio-Regenesis will be unable to biologically withstand Earth’s environment. 
        The GA  will of fer escorted evacuation to quarantined healing facilities in the Sirius star sys-
        tem in this Time Matrix to Fallen Angelic/Illuminati races that remain in this Time 
          Matrix. Remaining Human and Indigo populations will progress in DNA reverse-muta-
         tion and 12-Code activation while under the protective Planetary Buffer Blanket of the
           Trion/Meajhé Field.  
                              _________________________________________________________________                                 
                                 A new age of enlightenment will most definitely begin if we successfully make it to 
                                                             this December 21, 2012 Universal Day of Renewal.                            ____________________________________________________________
                                                                                                                                     
                         557  
                                                        

                                                                    
                                  
                                   *This is the book as in publication.       
           ARhAyas Productions has found page number discrepancies
         between the earlier and later editions.
                          We have included both.
         558

Numerics
1,000 000 years ago (YA), from 2000 AD 6,
                  123
1,275,000YA 29 
1,353 BC 330
1,458 BC 330 
1,459 BC 330
1,476 BC 330 
1,500,000YA 29
1,670-1,550 BC 330 
10 AD 244
10 AD-27 AD 315
10,000
     -3,500YA 32 
10,000YA 31, 33, 98
10, 500 BC 244, 311, 320, 330, 371, 390,
                  391,396,417,428
11,000 YA 61 
11,048 YA 74 11.500YA 69
11,540YA 75, 76, 80, 90, 134, 142, 187, 
                  203
11,558YA 72, 73, 74, 134 
     -10,000 YA 71
11:11/12:12 133-136, 143, 187-190,328 
12 BC-27 AD 314
12,00000YA 18 
12.500YA 64, 69 
12,550 YA 61
1244 325
1244AD 316,330 
12-Code Pulse 369
12-strand DNA 2, 3, 4, 7, 8, 9, 11, 12, 17,
                   43, 84, 94, 99, 102, 104, 148,
                   186, 189,291,482
      relationship to consciousness 108
12-Tribes and Roundtables 295
13,000 BC 321
1340-1331YA 96 
1353 BC 323 
1370-1353YA 96
144,000 persons 145, 160, 179, 194—195
144,500 Indigo Children 196, 203
1458 BC 323
1459 BC 322 
147,900 BC
     -75,877 BC 244 
1476 BC 321,322
148,000 BC 244,329
     -75,000 BC 329
150,000,000YA 18
150,000
     couples 195
     Indigo Children 186
150,000 BC 329 
1500  325
1500 AD 330
151,000 BC 329
152,000 BC 329 
559155,000 BC 329, 356, 390 
1550 BC 322
15-Dimensional Physics 241
1600 124
1670 BC 321,322
1670 BC-1550 BC 322
1748 124, 134, 135, 142, 206
1750 32, 124, 326
1750 AD 317,  330
1800s 361
18-23 103
1900s 361
1902  125
1902-1986  206
1903 139
1906 122
1916 317, 326, 330
1920s-1930s 399 
1926 125 
1930 426
    -1943 360 
1930-1940 330
1930s 126, 246, 257, 317, 361, 378
1939 361
1940s 126, 134, 317 
1941
    December 7 362
1943 130, 139, 142, 143, 144, 172, 188, 210,
                     350, 353, 361, 378, 387, 399
     -1951  366
     August 12 359, 362 
1945
     August 12 362, 363        
     August 9 363
1949-1972 131
1950 132 
1950s 366, 379
     -1960s 377
1951 366
1951-1983 374
1952-1968 132 
1961 115
1970s-1980s 375
1972 133, 134, 143, 185, 374 
       -1974 122, 132
       -1980 375
       -2012 136
        February 375 
1973-1980 136 
1974 133 
1980-2001 376
1980s 376
1982 122, 136     - 1984 137
1983 137, 139, 172, 210, 244, 245, 317, 326,
          330, 375, 376, 378, 379, 388, 418
    -1984 379
    -1992 379
1984 133, 140, 141, 142, 144, 187
1986 125, 135, 136, 142, 185
         -1998 187-193                                          Index, Volume ll  


                  401, 415, 417, 420, 426, 427, 465 
     One World Order dominion campaign 245 
     Stellar Activations Cycle 242, 243, 245,339
2001 178, 209
   -2003 178 
   -2005 251 
   -2012 293 
   August 429
   August 12 404, 406, 408 
   February 330  
   May 429 
   November 430
   October 430
   September 11 335-337, 344, 353, 373,
           377, 389, 408, 429, 432
                   9 warning telephone calls
                        ignored 409
                  What Really Happened 403-413 
   September 17, Giza alignment 206, 208
   September 3 406, 409, 429 
   September 7  409
2001-2008 365
2002 209, 210, 345 
        -2003 343 
        August 431
        August-September 415 
        May 429, 430
        September 431
2003 139, 140, 143, 162, 167, 172, 173,174,
                178, 257, 330, 338, 340, 386 
    -2004 252, 327
    -2008 245, 250 
    August 256
    August 12, Zeta Experiment 210 
    Dimensional Blend Experiment 344 
    Mass Mind Control experiment 327 
2003-2008 318, 319
2004 138, 139, 142, 162,173, 174, 209, 210,
                212, 330, 340, 384 
   Frequency Fence 344 
   September 9, birth of Avatar 4 209, 212
2005
     -2017 196, 213
   January 1, Stellar activations 213
2006  138, 173, 214
2006-2007 412
2007  214
2007  YA 100
2008 330, 340, 412, 426
      -2012 318
       July 22, birth ofAvatar 5 215
2009 216 
         -2017 181
2010 216 
2011-2016 196
2012 37,66, 123, 125, 131, 136, 137, 140, 
             141, 142, 156, 160, 169, 181, 185, 
             186, 191, 252, 330
   -2017 123, 126, 130, 134, 143, 161, 162,
        166, 174, 181, 185, 196, 482
   -2022 37, 41,185
   critical mass needed by 168, 176 
   December 21, Earth Enters Photon Belt 220 
   January 1, Earth’s 7th V ortex opens 216
   May 5, birth of Avatar 6 218
   May 5, opening of the Halls of Amenti  135,
                                                                               Index, Volume II
1987
      August 16, Harmonic Convergence 187 
1988   142, 185, 186, 192
1989   188
1992 136, 186, 189, 244, 245, 326, 330, 350, 
                  353, 354, 380, 383, 384
     -2012 193 
     August 12 381 
     January 11,11:11 188 
     July 26, birth ofAvatar 1 189, 193   
     June 6, Second Seal opens 189 
     November 241, 243, 318, 354, 381
1994   143, 192,382,383
      -1998 382
     December 12, 12:12 189
 1994-1998 382
 1995  191
 1996  143
       June 24, birth of Avatar 2 191,193
     1997  176,383
October 25, Ashayana Deanes’ 
         encounter 234
1997- 98  253
1998, 142, 176, 193, 197, 350, 384, 410 
      -2004 209
      -2012 179
     June 384
     June 26, birth of Avatar 3 194, 197, 201                   
     June 26, Sparking of the Arc of the 
              Covenant 235
1998- 1999 385
1999 186, 326, 347
      -2000 196 
      -2004 203 
      August 11 346 
      December 12 346 
      June-July 346 
      March 345 
      November 330
      November 18 346
      October 344
 2,024 BC 330 
 2,500,000YA 29 
 2,668 BC 322, 330 
 20,000 BC 311,320,330
 2000  140, 142, 143, 185, 186, 318, 347, 360             
      -2017 199
      August 247, 318
      January 245, 253, 318, 327, 330
      January 1 326, 346, 369
               Day of Transcendence 186
      January 1, Earth’s 4th vortex opens 201, 203      
                July 247
      July 5 246, 327, 330, 385 
      July 5th 318
      May 5 Earth frequency raised 181 
      October 338
         September 241,247,250
                       Anunnaki Sabotage 247 
      September 12 247, 249, 250, 257, 318, 
               326, 327, 330, 374 
      September 7-12 344
2000-2017 246, 253, 255,286, 288, 293,
                 303, 305, 311,314, 318, 323, 324,
                 326, 328, 354, 355, 360, 371, 372, 
                 379,383, 388, 393, 394, 397, 398,
560                                  

                 
Index, Volume II               
                             
          194 , 208
 2012 YA  98, 136
 2017 65, 66, 67, 85, 96, 97, 104, 122, 125,
                130, 142, 143,145, l55, 162,167,
                172, 176, 179, 181, 183,186, 187,
                196, 224, 227, 231, 239, 461, 470
     -2029 196
      January 1, Gaia’s Violet Flame 213
      June 30, Stellar activations 210
       May 5, Stellar activations 210
2022 175, 187
     January 1, Earth’s 7th vortex closes 228-229
     V oyagers deadline 169
2024 BC 244, 313, 322
2025 194
2047 229
206,000 BC 284
2072-2084 37
208,100 BC 328
208,216 BC 285, 293, 328, 369, 422
21 AD 100
21,900 BC 311, 320, 330, 393
21,900 BC-14,000 BC 311
2196 YA 66, 97, 98, 135, 202
22,326 B 372
22,326 BC 243, 253, 254, 311, 319, 330,
               354, 372, 387, 396, 417
22,340 BC 244
22,500 BC 372
2250 BC 244
23 AD 316, 323, 330
23 BC 315
24 Elders 414
24 Elders before the Throne 416, 417
24,324YA 65
24,326YA 67, 69
246,000 BC 244
246,000 BC- 328
25AD 101
25,000,000YA 11, 13, 14, 15,328
     -15,000,000YA 17
     -20,000,000YA 10
     -5,500,000YA 17, 240, 462
     -5,500,555YA 18
25,500 BC 245, 254, 259, 311, 313, 316,
                319, 328, 330, 349, 367, 369, 370,
                380, 391, 394, 405, 415, 426
 250 billion YA 242
 250 billion-570,000,000YA 264
 250,000 BC 244, 328
 250,000,000YA 328
     -25,000,000YA 268
     -25,000,000YA 9, 10, 240, 462
     -550,000,000YA 9
26 BC 323, 330
2668 BC 313
27AD 104, 136
2700YA 97
28,000 BC 271, 319, 330, 389
2946 168
2976 140, 144, 167, 168, 176, 379, 467, 472
3,000YA 32
3,000,000YA 29
3,470 BC 322, 330
3,500 YA 32
3,650 BC 312, 322, 330
5613,700,000YA 29, 328
    -l,000,000 YA 44
    -2000 240, 462
    -848,000 YA 28, 43
    -848,800 YA 43
3,995,750 YA 29
30,000 YA 65, 66
    -11,500 YA 32
    -12,000 YA 63
    -12,500 YA 64
3l50 YA 97
32,000 YA 33
3240 YA 97
    -2012YA 96
325 AD 324, 330
33,000 BC 329
3309 YA 95, 96
3324 YA 95
3331YA 95, 96
3340YA 95
    -l33l YA 95
3344YA 95
3348YA 95
3353YA 94
3361YA 94
3362YA 91, 92
   -3309YA 90
3363YA 92
   -3362YA 91
3366YA 89
3367YA 89,90
   -3362 YA 90
3374 YA 85, 89, 90
3385 YA 89
3386 YA 89
3398 YA 88
3470 BC 312, 404
35,000 YA 32,63
3500 YA 88
375,000,000 YA 44
3979 YA 98
3982 YA 98
4,000,000YA 27
4230 37, 66, 123, 144, 149, 225, 467
     -6443 123
4409YA 87
   —3362YA 87
46,459 BC 86
47 103
48,459YA 61
    -30,000YA 62
48,500 YA 60
5,498,000 BC 271
5,500 Indigo Children 196
5,500,000YA 21, 22, 26, 205, 251, 328, 387
5,504,000YA 22
5,508,l00YA 19, 205
    -5,504,000YA 22
5,509,000YA
    -5,508,100YA 18
5,900 BC 312, 321,330
5.5 million YA 368, 391
50,000 BC 271, 319, 330
5466 BC 86
549,998,000 BC 269, 271, 282
55,000 YA  57, 58

      -51,750 YA 58
550,000,000YA 3, 5, 6, 7, 9, 12, 27, 33, 63,
              115, 119, 190, 230, 266
550,750,000-550,000,000 YA 3, 4
551,000,000 YA 2
552,000,000 YA 2 
559 324
    -608 315, 316
560,000,000 YA 1, 268
    -550,000,000YA 10
    -550,750,00YA 240, 462                         
    -550,750,000 YA 2
568,000,000 YA 243, 266
570,000,000 YA 265
6,622 YA 87
608 316, 324 
608 AD 316,330
6443 123 
65,000YA 32, 56
66,000 BC 329 
666 36, 45, 49, 218
669,000 BC-250,000 BC 328
68,000 BC 329 
68,000YA 56
7,500 BC 312, 321, 330 
70,000YA 56
71,000 BC 285, 329
72,000 BC 329 
72.000YA 56
73,000 BC 285,329 
73,000YA 56
75,000 BC 329
75.000YA 56
75,500 BC 377
750,000 BC-500,000 BC 284
750,000-75,000 YA 56
798,000 BC 268, 269, 275, 276, 295, 328
798,000 BC - 33,000 BC 328
798,000 BC-500,000 BC 277 
8 AD 100
  -21 AD 101
8% of the races 44, 52, 88, 117, 123,125, 
                  130, 134, 144, 160, 179, 209 
8,400 BC 312, 321, 330
8,900 BC 312, 321, 330
800,000YA 55, 56 
     -55,000YA 55 
8-21 102
840,000YA 51, 55, 63
846,800 BC 271,272 
848,000 YA 100 
848.800YA 48, 50, 328 
849,000YA 50, 51
      -800,000YA 50 
850,000 YA 45, 48, 50 
      -848,800YA 48 
8835 YA 74, 75 
8-strand DNA 10,
9540 BC 320 
9,558 BC 320, 330 
9,560 BC 320, 330 
900,000YA 50 
906 BC 323 
950,000 YA 45,46
9,540 BC 86
9558 BC 244, 271, 312, 313, 318, 349, 355
562                
  389,393, 394,396,398,403,422,
             426,
9558 YA 74 
9560 BC 312, 314, 325, 338 352, 354, 355, 
             365, 378, 390, 392,
9560 BC-9558 BC 353 
9560-9558 BC 394
A
Abadan, Iran 370, 376 
abduction 131, 139, 178 
    consensual 134
    for hybridization experimentation 131              
    missing fetus pregnancy 235
Abraham 324 accretion level 149-183 
Activation 157
    Codes 16 
Adam and Eve 6
    see also Biblical stories 
Aegean 366 
Aeiran, see Root Races 
Aethien 264 
Aethien-Mantis 368 
Afghanistan 377
    UIR plans to rule 377 
Africa 56, 377 
Agartha 271 
Agartha, see Inner Earth
agendas
    Anti-Christiac 243 
    Anti-Christian 312 
    Anti-Christos 313
    Anunnakis to destroy the Human race 243  
    Anu-Seraphim Anunnaki Race Supremacy
         world dominion 244
    Atlantian Conspiracy 318
    Drakonian 246, 317
    Drakonian-Centaur-Necromiton-Andromie     
             Anunnaki-hybrid dominion 244
    Drakonian-Zeta 257
    Emerald Covenant peace treaty and
             freedom 250
    fear-based 179
    Founders’ Emerald Covenant freedom 243      
    Guardian 134
    invasion 257
    Jehovian 317
    Jehovian One World Order dominion 245     
    Luciferian 317
    new Dracos-Zeta 141
    old Zeta 123, 130, 234
    One World Order 317, 319
    One World Order Earth dominion 250
    United Resistance 250
Agratath, see Inner Earth
AIDS 252
Akashic Record 206
Akhenaton, see Pharaoh
Alanians 21,45
Alaska 359, 366, 404
Albigensian Crusade 316, 325, 330
Alcyone 35, 65, 69, 71, 72, 83, 88, 98, 99,
              100, 115, 127, 128, 142, 143, 187,
              203, 206, 233, 244
     as the primary sun of our solar system 115
                                         Index, Volume II

Index, Volume ll   
      see also Pleiades
Algeria 375
ALL 428
Alnitak-Orion 360
Alpha Centauri 245
Alpha-Centauri Marduke-Necromiton-
                Anunnaki 320
Alpha-Omega
    Centauri 242
     Templar Melchizedek Anunnaki 256, 258,
         260
Alpha-Omega-Centauri 327
Altair 266, 371
Ameka Crusade 325, 330
Amenophis, see Pharaoh
Amenti 52
       Activation Cycle 188
       Ascension Program Schedule 201-229, 343
       Halls of  9,11, 50, 54, 65, 66, 70, 105,
                  110-119, 142-143 162-184, 235
                      Sealing of 19-24
       Rescue Mission 6
       Seal of 28, 30, 33, 50,52, 105, 134, 205
       Secrets of 1, 105
       Sphere of 7-26, 27-29, 50-55, 105, 107-
                110, 117-120, 124-125, 130, 135-
                140, 142-143, 168-180, 185-229
                    distortions in 94
                    merging with 16
                    security seal of 72
      Staff of, see Blue Flame
      Temple-Generator Complexes 253
      Transmission of 1998 1
America
    real founding of 393-397
American Revolution 317
Amnesty Contracts 379
Amonites 7
Amorea, Hall of 28
Andes Mountains 56, 217, 228
Andromeda 36, 50, 51, 53, 61, 72, 74, 222,
                  223, 242, 244, 250, 317, 360, 379,
                  471
      Association of Planets in 51
      Council 191
      Federation of Planets 97, 141
Andromie
    -Necromiton 392
Andromies 177, 191, 250, 318, 366
     -Rigelian Coalition 374, 376
Angelic
     Kingdom 197
Angelic Human 292, 304, 308, 318, 320, 321,
                 322, 327
    1728 selves 297
    Christos Divine Blueprint 290
    Heritage 289
    Race 289
    reincarnational heritage 297
    Sacred Mission 292
Angelic Human evolution, Fourth Round 285
Angels 252
Angular-Rotation-of-Particle-Spin, see ARPS
Ankhesenamon 95
Ankhesenpaaton 95
Ankhi 91, 93, 94
563    assassination of 94
ankhs 62, 64, 72, 73, 74
Annu, see also hybrids, human-Anunnaki
Annu-Elohim 242, 265
    Anunnaki 242
    Anyu 265
Annu-Melchizedek 311, 312, 319, 320, 321,
                 323, 324, 390
Anunnaki Nephilim 360
Leviathan 390
Midianite-Hyksos Kings 321
see hybrids
Urantia 319
Annunaki 411
Antahkarana Primal Life Force Current 301
Antarctica 366
Anteres 371
anti-particle 453, 458
       double 108
       universe 10
Anti-Particle Universe 296
Anuhazi 262, 264
Anu-Melchizedek
      Leviathans 390
Anunnaki 312, 318, 321, 325, 327, 339, 345
                  350, 357, 370, 380, 384, 393, 396
      Defection 384
      Luciferian Covenant 352
      Mind Control 395
      peaceful co-evolution with humans 243
      see also Sirian
Anu-Seraphim 242
      Alpha-Omega Templar Melchizedeks 244
      Anunnaki 252
      Pleiadian Samjase Anunnaki 244
Anyu 265
APIN 366, 367-385, 388, 392, 394, 395,
                 397,  404, 405, 408, 414, 417, 418
                 420, 421, 431
       Falcon 380
       Phoenix 375
       Serpent 376
Aramatena 308, 368
    -Lyra 279, 372
Arc of the Covenant 43, 50-67, 71-74, 82-
105, 120-121, 142-143, 185-202,
313, 314, 320, 321, 322
announcement 193
Guardians of 57
seal on 135
sparking of 235
transfer of guardianship from Egyptians to
                      Hibiru Cloister 96
Archangel Michael 244, 258, 360, 370
    Nephilim-Nephite collective 256
Arcturian 36, 51, 223
     Federation 97
     mother-craft Ashalum 234
Arcturus 242, 244, 245, 379, 417
Arihabi, see Christs, Three
Arizona 188
Armageddon 325, 345, 378
ARPS 428, 429
Ar-Ratoth, see Agartha
Arthurian Grail Quest 330
artificial Christ Consciousness Grid 135

Aryan 21, 22, 24, 28, 31
Ascension 395
real 424
ascension 8-14, 18, 24, 30-44, 52, 62, 98,
           100, 105, 106-121, 137,138, 188, 
           189, 213, 239, 461 
    and DNA mutations 482
    codes 265 
    cycle 66, 70, 111 
              closes 228
              dynamics 463-492 
              of 196 BC-4230 AD 67 
     do it while it’s easy 229  
     false 421 
     mass 104
     of groups and couples 170 
     process of 39 
     schedule 199-229 
     science of 67 
     self-directed 258 
     stopped by suicide 42
     to Heaven 42 
     transport route 171 
     waves 40
Ashalum 234 
Asheville,NC 359
Ashtar Command 244, 256, 258, 327, 376,
                  379, 380, 419 
Asia 368, 377 
asteroids
     near-misses 122
Astral
    identity 37
    projection 79
Atlania 28, 33 
Atlanians, see Second Seeding
Atlanta, GA 359, 409 
Atlanteans, see Third Seeding 
Atlantian 261
    Conspiracy 320, 327, 356
             and Roundtables 310-320 
             Progression of Major Events 319 
     ﬂood 244
     Holocaust 319, 330
Atlantian Pylon Implant Network, see AP1N 
Atlantian Spikes 394 
Atlantic 56, 359, 366, 377, 430, 431 
     marine disturbances in 381 
Atlantis 28, 33, 56-67, 71-73, 83, 86, 87,
                  311, 314, 315, 316, 317, 320, 353,
                  367, 380, 389 
     Islands of 64, 71, 72 
     Nohassa 396 
     Rising 113
     sinking of 32,63,73, 134, 142 
     three Primary nations 389 
Atlas Mountains 375 
Atomic Transmutation 258 
Aton 89
     Aton-a, see Ra
     Atonist movement 89 
auric field 24 
Australia 366, 368
authority 67
avatar 88, 88-109
564                        Index, Volume ll   
birth of #1 189, 193 
birth of #2 191, 193 
birth of #3 194, 197
birth of #4 209, 212 
birth of #5 215 
birth of #6 218 
birth of 7th-level 189 
false public claims to be 194 
Sananda 99 
see also Christs, Three
six silent 186, 193-197, 478 
when soul enters the infant body 193 
Aveyon-Lyra 279 
awakening 249
Axiatonal and Ley Lines, see ALL 
Axiatonal Lines 342, 348, 357, 367 
Axious 34
axis tilt 86 
Aya 95
Ayrians, see Root Races 
Azar-Azara 7, 233
Azurite 264
   48-Strand DNA Template Angelic    
            Hominid 262
 -Amenti Galactic-Planetary Templar  Security     
            Team 276
    Council 98, 99, 104, 122, 233 
   see Ra
   Universal Templar Security Team 256, 275,  
 302
B
Babble-On Massacre 312.322,330 
Babylon 312 
Babylonia 322 
Bahamas 390, 431
Battlestar 245, 247, 251, 253, 254, 314, 327,    
                 375, 387, 415 
        see also Nibiru 
beam ships 136, 139 
Beast 422
Bermuda Islands 390, 396, 409, 429 
Bermuda Triangle 354 
Bethlehem 99 
Bhrama 272
Bible 245, 315, 322, 324, 369, 407 
Biblical stories 6, 26, 42, 51, 103, 239,461 
Big Brother 361,364 
bi-location 235 
bin Laden, Osama 376, 408 
    Falcon agenda 377 
    UIR affiliation 377
bio-neurological perceptual block 211 
Black Budget 361 
black hole 388, 397 
black holes 5, 167, 359, 420 
Black Sea 56 
Blow-Up Charts 434-?? 
Blue Centaurs 360
Blue Flame 13, 14, 15,17, 20, 30, 31, 33, 34,     
                    53,57,61,72, 74, 86, 96, 100, 
                    117-120, 134, 142, 143, 170, 185,
                    194, 200, 238
     Melchizedeks 98
     Speakers of the 32, 33
                                          

Index Volume II
Blue Oxen 371, 414
Blue Wave
   Infusion 207, 210
body
   emotional 21
   immortal 42
Body-Snatching 385
Bolivia 430
bonding
   contract 196
Bosnia 251, 346
Boston, MA 359
Boulder, CO 409
Bra-ha-Rama Maji 274
brainwashing 125
Branch Davidians 413
Breanoua 263, 276
Breanoua 271, 272
   see also Cloistered Races
Breatherian 266
Brenaui 422
Breneau 19, 34, 48, 50, 233, 262, 265, 275,
               303
    Rishi 7
Bridge Zone Project 142-179 187 199 225
                  234 239, 240, 305, 339, 379, 388,
                                    461, 462, 467, 483
conditions for success 179
how you can help it succeed 168
mechanics of 145, 160-168
use of to avoid less favorable futures 176
Brigijhidett 7
Bruah 311, 319, 320
Bruah-Atlantis 317
    Annu-Melchizedeks 321
Buddha 251
C
cancer 252
Carpathian Mountains 56
Caspian Sea 366
Castle Rock V ortex 346
Cathars 316
Catheri 325, 328
Caucasus Mountains 215, 217, 320, 321,
Cave of Creation 8
CDT-Plate Translations 398
CDT-Plate translations 241, 325 414
cellular
    memory 149, 156
    transmutation 457, 477
Celtec 315, 321
Celtics 320
Centaur 245, 392
Centauri 370
Centaurian 360
Centaurian-Necromiton Intrusion 326, 330
Centaurians 371
Central America 366
Central Creative Source 12,42, 69, 80, 107
                      451
Ceres 3, 6
Cerez 264
Cerez-Seraphei-Seraphim 368
Cetaceans 264 
chakra 21, 458, 476
565 
     base (1st) 19, 35
     Earth’s, see vortices
     heart (4th) 21, 35
            blockage of 124
     higher centers to activate 184
     sacral (2nd) 35
     solar plexus (3rd) 35, 77
Changing of the Guard 189, 190
Channeling 317
channeling 312, 336
     use by Anunnakis 380
Charleamea 235-236
Charts
AmentiAscension Program 436
Recent History and Current Events 435
The Seven Seals 438
The Six Silent Ascension Avatars 438
Time Continuum Progression 440
Time Mechanics 439
Time Shift Continuum Progression
            I Phantom Earth 411
Checkerboard DNA Mutation 401
Checkerboard DNA Reversal 405
Checkerboard Mutation 259
Chemtrails 252
Chental 234
Chihuahua, Mexico 408, 429
Chile 430
China 103, 251, 346, 377
Choosing Your Future 450
Chosen Ones; 97, 98, 252, 314, 317, 318, 322
                   326
Christ Consciousness 187, 188, 259, 304
Christiac Freedom Agenda 371
Christianity 31
      distorted teachings of 103
      inﬂuence from Templar-Melchizedeks 98
Christos Avatar 302
       Integration 302
Christos Current, see Universal Maharata
               Current
Christos Identity Integration 301
Christos Realignment 278, 280, 281-284,
               286, 288, 292, 293, 303, 304, 305
               308, 314, 316, 318, 328
Christos Reclamation 328
Christs
     Jesus 84, 99, 100
               see also Christs, Three, Jeshewua
     Three 96-04, 251
               Arihabi 101-102
cruci fied 102
in India 102
not avatar 100
resurrection of 102
               descending lines from 102
African 103
Celtic 103
Egyptian 103
French 103
United States 103
              Jesheua-Melchizedek (Jesheua-
                               12) 99, 136, 314, 323
                             as true savior of the                                         
                                           Hebrews 102
              ascension of 104

                                                                                                             
 
in India 100-101
in Persia and Egypt 101
sacred procreative rites of 103
Jeshewua-9 (Jesus) 100, 102-104
birth not Immaculate 100
in Egypt 101
in France 101
in Nepal, Greece, Syria, Persia
           and Tibet 101
Church of Rome 323, 325
     in filtrated by Drakonians 315
civilization
     sudden appearance of new structures 183
Classi fied Document 344
cleansing 240, 462
climate 22
     change 45, 51
Climatic Disturbances 429
Cloaking Protection Field 362
Cloaking Shields 352
Cloistered Races 9-19, 50, 69, 75
       Breanoua 10, 17, 21, 28, 29, 44, 56, 78,
             82, 84
                  Second infusion 18
       Five 10, 17, 56
       formation of 15
       Hibiru 10, 17, 24, 28-31, 43, 44, 47, 56,
                 78, 82, 84, 274
                       evolutionary advantage of 76
      Melchizedeks 10, 17, 29, 30-34, 47-48,
              52, 56, 57, 62, 63, 64, 82-108, 195,
              266
                  25 families 31, 97
                  birthing wave 88
                  Essenes 31, 96-105
                  Templar 31, 35
      Palaidorian refers to the Five Cloistered Races
      Ur-Antrians 10, 17, 21, 28-30, 44, 55-57,
                   82, 84
      Yunaseti 10, 17, 84, 195
clones 170
Code of the Blue Nile 272
common control elements 400
consciousness 25, 35, 39, 79, 80, 452
and frequency patterns 149
evolution of  76, 148
merging with anti-particle double 93
moving through time matrix 148
now-moment stream of 151
polarization of 412
rapidly restructuring 155
Contract Bond, see bonding, contract
Copiapo, Chile 431
Core Manifestation Template 296
Core Scalar Template Dynamics 351
Co-resonant Continuum Alignment 288
Council of 12 417
Council of 24 Elders 417
Council of 9 417
Council of Nicaea 315, 324, 330
Covenant of Palaidor 6, 51, 105, 271
CPNs 367
Creation Physics 351
Crisis Intervention 255
Crisis Intervention Program 256, 335, 346
Cro-Magnon
                                                                                                                          566      
      
                   Index, V olume II
  
    -l  390
     -2 390
     -3 390
     -4 390
cruci fixion 102
Crying Statues 251
crystal 62
     Body 456
     Earth’s D-1 Iron Core 126
     generator 63, 65, 72, 73
               explosion like atomic bomb 63
     gold core
               of Sun 132, 143
               of Tara-Earth 128
     seals 477
     Seed 473
star 473
Crystal Pylon Networks, see CPNs
Crystal Pylon Selenite Rods 418
Crystal Pylon Temples 269, 271, 278
Crystal Temple Networks 348
Cuba 390, 431
Cue Sites
    12 Templar 251, 269
Cycle of the Rounds 281-284, 290, 291, 292,
                  296
    3 key elements 303
D
Dagos, see hybrids
Data
     Summaries 446-450
                 Six Silent Ascension Avatars 446
                  Time Track 1—V oyager Ascension-
                            Tara D-4 Time Cycle 447
                 Time Track 2—Phantom Earth De-
                                    scending Planet-—D-3
                                    Time Cycle 448
                  Time Track 3—Night of the Two
                                    Moons— Bridge Zone
                                    Earth—Agartha—D-3.5
                                    Time Cycle 449
Day of Transcendence, see 2000, January 1
Days of Innocence 423, 424
Dead Sea 313, 322
     Conquest 322, 330
Deane, Ashayana xi, 238, 432
      Closing Statement 1998 234
Death Seal, see Amenti, Seal of
denial 248
Denver, CO 409
Destiny of Sorrow 395
dimensional
      bands 11
      blending periods 110
      Magnetic Peaks 138
Dimensional Blend Experiment 386-396, 
                 405, 408
Dino 265
dinosaurs 44
discrimination
       groundless 84, 85
disinformation 357
distortions 69, 83
        
                                  
                                                
           

Index, Volume II
Divine Blueprint 369, 372
Divine Christiac Blueprint 307
Divine Physics 298
Djoser Invasion 313, 322, 330
DNA 2-26, 28, 38, 50, 62, 78, 83, 87, 123,
                 149-159, 162, 215, 254, 255, 258,
                 270, 272, 296, 466-483
12 dormant codes 477
12-Strand Template 300
3 to 3.5 strand template 257
37-42 Strand 273
4.25-strand sustainable 257
and the personal morphogenetic field 150
Consummation 157
creation of 77
distortion 124
evolution of 109
fastest means of activating Personal 12-Strand
         Template 301
Initiation 157
junk 25
mutations 351
secret about its true nature 158
Signet Codes 289
Spontaneous Mass Activation cycle 404
template 307
Template Bio-Regenesis 243, 257
Template Core 291
Template-Star Gate Correlation 278
transmutation of 93
dogmas 257
     New Age religious 252
     Traditional religious 252
Dolphin People 265
Dominican Republic 390
Dora-Teura
    Matrix 206
Doreadeshi 119, 144, 145
double moon 114
Dove 366, 366-384, 409, 417, 418, 421, 431
Down-grading 27
Dracos 252, 319
Dracos-Zeta Resistance 137, 144, 162, 167,
172, 175, 186, 191, 192, 208, 214,
232, 234, 467
      to appear to be Guardians 178
Dragon 374, 376, 377
Dragon-Moth 244, 317
dragons 255
Drakon 6, 44, 47, 58, 71
Drakonian 250, 252, 317, 321, 322, 325, 327,
                 383
    -Reptilian
               -Insectoid races 243
Dralov 234
dream 151
       distortion of recall 78
       lucid 78
       mass 152
       repression of recall 206
       simultaneous 78
Drueidec 315, 320, 321
Druids 320
dualistic
   perception 79              
duality 25 
567
             dweller on the threshold 35
E
Eagle 367-385, 432
     Golden 370
     White 370
Earth 34, 360
1998 passage into D-4 time cycle 194
as future nuclear waste depository 140
axis tilt 62, 63, 73, 113
chakras, see vortices
changes 140, 143, 166, 168, 173, 181,
        182, 374, 427, 428
              in the USA 173
civilizations lost 73
Current State of Affairs 234
division of populations 176, 181, 187
emergence of new land forms 166, 183
evolution stunted 120
evolves to become Tara 123
future 71
gold for Anunnakis 47
illusion of solidity 147
Inner, see Inner Earth
Phantom 166, 240, 462, 470, 473
possession of 18, 48, 58, 64, 123, 137, 144
quarantine 71, 76, 82, 87, 90, 96, 105
saved by Guardians 1972-1974, 132
Sirian Activation 215
Solar Activation 204
       Heart Star 237
Star Activation 215
vortices 177
Earthlings, see human and Dracos
earthquakes 22, 73, 379
East Asia 56
Easter Island 371-372
Easter Island Heads 371
EBE 173, 178
Eckatic Codes 272
E-Den 2
Eden, Garden of 6
education 37
ego 79-81
   origins of 81
Egypt 36, 56, 60, 62, 71, 88, 103, 313, 320,
                   322
     as resettlement for Atlantis survivors 63
Egyptian 28, 46, 74, 239, 461
     Invasion 330
     mystery schools 15
     Pharaonic line 47
              see also Pharaoh
Egyptian Invasion 321
Eieyani 270, 319, 372
   Massacre 311, 319, 330, 372
Electric Wars 18, 22, 45, 51, 251
      end of 19
electrical
      disruption 182
Elohei-Elohim 242, 369
      Human Guardian race 243
      Oraphim 267
 Elohim 2, 3, 4, 6, 18-27, 34, 43, 46, 50, 55,
57, 59, 62, 66, 69, 75, 76, 83, 87,
91-104, 122, 193,194

                                                                                
 
    
         Eye of 34
EM pulse technology 211
Emerald Covenant 244, 245, 246, 247, 250,
                   252, 254, 257, 265, 271, 275, 315.                                          
                   318, 319, 323, 327, 351
    Christiac Co-evolution peace treaty 241
    Co-Evolution Peace Treaty 368
    Co-evolution Peace Treaty 339, 356
    Co-evolution treaty 242
    Crisis Intervention Plan 257
    Masters Planetary Stewardship Initiative 388
    Peace Treaty 358
    Redemption Contract 346
    Redemption Contracts 375
    teachings 424
 Emerald Order Melchizedek Cloister 371
 emergencies 411
 Emergency Release 241—??
 Encryption Key Codes 275, 278
 End Times 378
      beginning 396
 end times 461
     prophecies avoided 462
enemy 257
energy
    new fuel sources 183
energy vampires 369
Energy/Spiritual Healing Systems 384
England 247, 312, 314, 315, 316, 319, 321,
                324, 367, 429
       Stonehenge 251
Enlil-Odedicron 244
Enoch 245, 246
    Jehovian-Anunnaki collective 244, 245, 256
entity gestalt 7, 197
environmental cleanup 252
equality 85
Essene Divide 314,315,316,323,330
Essenes 323,461
Brotherhood teachings 97
see Cloistered Races
see hybrids, Melchizedek-Hibiru (Hebrew)
ET 18, 22, 43, 45, 62, 68, 233
   visitation to Earth limited to emergency
         intervention 76
Eternal Christos Avatar Identity 297
eternal life
    false 395
etheric
    implant 206
    overtone structures 113
Ethics 351
Ethnic Virus 374
Euiago 146, 148, 155, 161, 199, 461, 465,
                467
Euphrates River 86, 89
Euries 29
Europe 56, 103, 359, 377
Europherites 29
evil
    twin 35
evolution
multidimensional 106
program of human 96
Evolutionary Rounds 291, 295
Excalibur 315
568                            Index, Volume II 
exercises 493-504
    Release Crystallized Thought Patterns 493
Exodus 321, 322
external reality
    as a dream-scape 152
    field 158
F
Faces of Man 371-373
Falcon 366-385, 386-399, 408, 417
Falcon Matrix 354
Fall of Akhenaton 906 BC 330
fall of man, see Tara cataclysm
Fall of Solomon's Temple 330
Fallen Angelic
    Invader Force 401
Fallen Angelic races
    ET 242
    Master 356
Fallen Annu-Elohim collective 253
Fallen Dark Avatar collective 253
Fallen Jehovian-Annu-Elohim collective 245
Fallen Seraphim collective 253
Federation of Planets 252
FEMA 413
fence 342
Field Techniques
    The Maharic Quick Seal 502
     The Maharic Seal 496
Final Con ﬂict 247, 253, 314, 318, 325, 364,
                   365,366-383, 388,401
Fire Codes 477
Fire Letter Sequences 274, 291, 292, 293.
                  297, 299, 302, 303, 307, 312, 319
First Contact 384, 411
Five Cloistered Races, see Cloistered Races
ﬂame
     bearer 54
     blue, see Blue Flame
     double 14
     gold 14
     holder 54, 207
     Keepers 200, 270
                 message to 200
     orange-gold 74, 475
     violet 14, 200, 238, 475
     white-gold 14
Flame Code 299
ﬂood 6,45,51,73.86
     Atlantian 244, 312, 318. 320, 330, 355
     first (5,500,000 YA) 26
     second (849,000 YA) 26
Florida 359, 390, 431
     Dade County 381
     Sarasota 247, 378
     St. Augustine 375
ﬂy-by 178
Forbidden history 241, 261
      motivation for 311
Founders 233, 250, 275
Four Beasts before the Altar/Throne 414
Four Faces of Man 414, 432
Four Horsemen of the Apocalypse 414, 416
France 103, 325
Free Masons 325, 370
Freedom Teachings 424

               
Index Volume II
frequency 342
   bands 8, 22, 41
   fence 75, 80, 88, 123-126, 130-131, 134-
         140, 187, 206, 210, 256
             protection from 174
             quarantine 25, 134, 142, 203
             Zeta 124, 142, 162, 177
   field 92
   patterns 11 
   Seal 349
   transducers 292
Frequency Fence 350, 384, 394, 404, 405
future, how to prepare for 184
G
GA 1, 159, 187, 233, 234, 238
      Final Comments 230
      program for Ascension Cycle Adaptation 470
Gaia 5, 8, 11, 13, 43, 227, 266, 379, 474
    root races
       Hyperborneans 10, 84
       Polarians 10, 84
Gakona, Alaska 404
Galactic
    Core 34
       Federation 28, 62, 137, 187
Galactic Federation 244, 252, 256, 258, 312,
313, 316, 317, 318, 320, 322, 323.
324, 325, 326. 327, 376, 379, 380,
384, 419
Garden of Eden 42
gates of ivory, see pearly gates
genetic 44
     ascendancy of angelic human lineage 262-
            263
     distortions 83
     time codes 11
Genocide Crusades 316
Giza 320
Giza, Egypt 370
Giza, Egypt 374, 376, 396
God
    false 424
    reality of 424
gods
     Aton 89
Jehovah 100
     worlds 43
Golden Eagle 370
government
Allied 125, 130
Interior 131, 172, 209
cover-up tactics 177
message to 172
treaties with Zetas 131, 137
Grail Line 264-269
   Indigo Children 250
Grail Quest 313, 324
gravitation
   reversing 61
Great Cleansing 252
Great Pyramid 320
Greece 101
Grid Spiking Campaign 330
Grim Reaper 422
569grounding codes 30
Gru-AL 378,429
Gru-AL Point 294, 303, 317, 325
Guardian Alliance 241
Guardian commission of human race 31 1
Guardians 2. 9, 22, 46, 51, 56, 57, 66, 73, 75.
76, 105, 121,122, 125, 130, 132,
133,142-145,163-184, 185, 187,
194, 197, 235, 237
appearance of being uncaring 187
intervention 467
of the 12 Pillars 233, 372
treaties of 1982-1984, 137
Guinevere 315, 316
Gulf of Guinea 373
Gulf of Mexico 366, 431
H
HAARP 252, 256, 403-407
Hades 359
Haiti 390
Hall of Records 186, 206-208, 218-221,
             227-229
    closure of 229
Halley, Antarctica 368
Halls of Amenti 245, 253, 254, 271, 313, 352,
360, 395
Halls of Amorea 340
     Passage 372
Haremhab, General 90-95
Harmonic 129
Convergence 187
Magnetic Peaks 138
Merkaba Spin 260
Quadrant 146
Resonance Chamber 62
           see also pyramid
   Resonant Tone 112
harvest 421
Harvesting 375
Hassa Kings 314, 321, 364
Hatshepsut Invasion 323, 330
Hawaii 311,319, 362, 372
    Pearl Harbor 362
Hayes, Anna. see Deane, Ashayana
HD-C 417
HD-Cs 417, 419, 421
heaven 388
Hebrew-Annu-Melchizedek, see Jeshewua-9
Hebrews, see hybrids. Melchizedek-Hibiru
Hell 359
HF 176
Hibiru 364
Hibiru, see Cloistered Races
Hidden Game-board 366
hidden reality mechanics 165
higher self 79, 124
    origins of 81
Hiroshima 362. 363
history
        hidden forbidden 250
        manipulation by Annunaki 312
Hitler 326
Hitler, Adolf 361-??, 361, 364, ??-364
Holographic 
   beam 114-120, 185, 223, 227
   illusions 129

                                                                                           Index Volume II
    inserts 123, 125, 136, 211, 251
                 and the body of Christ 102
Holographic Beam, see Universal Maharata
                   Current
Holy Figure 251
Holy Grail 311
        Quest 362
        Quest for 311, 315
Holy Wars 68
Homo-sapiens-l 390
Horsemen 415, 420, 429
Horus 27
       Third Eye of 24, 27, 28, 51, 65, 93, 102
Hourglass Nebula 418
Hova Body 300
Howland Island 373
HU 129, 146
HU-1 3, 5, 6, 7, 8, 9, 12, 13, 14, 18, 19, 20,
             28, 43, 45
HU-2 1, 2, 5, 7, 8, 12, 17, 18, 20, 27, 28, 34,
             41, 45
HU-3 2, 3, 5, 10, l2, 13, 14, 18, 22, 43
HU-4 2, 12
HU-5 2, 19
human
becoming Guardian species 191
biology 54
carry the Zeta Seal genetic mutation 124
celestial lineage 101
clones 139
dominated by Nephilim 46
early man 45
evolutionary blueprint of 12
extinction 77
extraterrestrial 55
genocide, program of 345, 386
history, re-writing of 312
life span, shortened 312
mortality 205
natural birthrights of 107
responsibility for personal evolution 175
Human Amnesiacs Force 406
Human Greeting Teams 411
Hurricane Andrew 380
     affected by wormhole 381
hurricanes 379
hybrids 139
   Annu-Melchizedeks 55-56, 61-64, 72, 74,
              82-85, 88-91
   Dagos 29
   human-Anunnaki (Annu) 36, 49, 52, 56, 58
             85, 88-99
   human-Atlanian-Anunnaki (Nephilim) 46,
             48, 55, 98
   human-Drakon (Dracos) 44, 49, 55, 58,
             122-123, 131, 137-141, 142-183
                to be banned from Earth 174
  human-ET 21
  human-Sirian (Dagos) 43
  human-Sirian (Kantarian) 27-29, 48, 51, 57
        Federation 28
human-Zeta 123, 125
Marduke-Dramin-Anunnaki-Omicron 245
Melchizedek-Hibiru (Hebrew) 31, 55, 82,
         83, 85, 96-105
Men in Black 245
  570                                                                                                       Nephilim, see human-Atlanian-Anunnaki
Serres-Egyptians 47, 55, 64
Sirian-Anunnaki-Nephilim 47
Urtites 56
women as breeders of 46
Zeta-Dracos (Rutilia) 122, 137, 167, 171,
                            173, 177
           Zeta-human-Aethien (Zionites) 101
Hyksos 322, 324, 356
-Annu-Melchizedek page 323
-Egyptian kings 323
Exodus 330
Invasion 322, 330
Kings 314, 322
Hyperborneans, see Gaia
 Hyperdimensional Cones, see HD-Cs
 hyper-space 111
I
IAFW 51, 60, 69, 104, 233, 256, 264
Ice Age 22, 45
Ihopetohetep 95
Illuminati 252, 312, 324, 339, 354-365, 378,
                400, 408
       Master Plan 2003 386-400
       Sleeper groups 347
       World Management Team 376
        Zeta Treaty agreements 246
illusion 251
imagination 151
Immaculate Conception 99, 100
Imminent Crisis Order 339
incarnation 16
     12 simultaneous 148, 296
     1728 simultaneous 296
     24 transmutations in one body 17
     patterns through races and families 16
Incubation Rite, see Palaidorian birthing
                   contracts
Independence Day 189, 191
Indian Ocean 366
Indigo Children 186, 194-197, 201-203, 213,
250, 264, 269, 272, 273, 276, 297,
318, 327, 368, 372, 378, 385, 386,
393, 431
    birth schedule of 196
    hunting of 384
    Place Holders 196
    rescue missions 388
Indonesia 103
infiltrates 139, 178
Infusion
    Gold Wave 216
    Silver Wave 216
Inner Christos Connection 259
Inner Earth 32, 45, 46, 48, 53, 55,56, 60,61,
65, 72-74, 82, 86, 89-91, 96, 128,
144, 163,166,182, 195,197,225,
252, 269, 271, 324, 330
new passages into 183
Star Gates 278
Time Cycle 388
intelligence 39
Intended Dimensional Blend Time Rip 330
Intended Frequency Fence 330
interbreeding 4, 34, 35, 43, 45, 55, 85, 97

Index Volume II
interdimensional
cloaking 255
transport 73
Interdimensional Association of Free Worlds, see
                 IAFW
Internal Merkaba Mechanics 258
interstellar political drama 241
intervention, when it is permitted 145
Intruders 199, 234
intuition, suppressing of 124
Inyu 264
Iran 56, 378
Iraq 378, 409
Ireland 320
Islamic extremists 377
Israel 322, 346, 378
        Crusade 322, 330
J
Japan 359, 362, 377
Jehovah 100, 369
Jehovian
-Annu-Melchizedeks 322
-Anunnaki 313, 318, 321, 322
Anunnaki 319
Hassa Kings 323
HD-C Seals 420
-Sirius-A  317
         Anunna 244
     -Urantia 320
Jericho 406
Jerusalem 86, 89, 98, 101, 102, 346, 378
Jesheua-12, see Christs, Three
Jesheua-Melchizedek, see Christs, Three
Jeshewua-9, see Christs, Three
Jesus 251
Jesus Christ, see Christs, Three
Jeudi 99
Jewish religion
founding of 98
Kabbalah 98
Joehius 99
John the Baptist 314, 323
Jordan 322
Joseph, father of Jesus 99-100
see also Joehius
Judaism 31
judgment day 36
K
Kabbalah 98
Kantarians, see human-Sirian hybrids
karmic
     debt 153
immunity 153
imprint 153
clearing your 154
how to change your 154
Kathara
     Bio-Spiritual Healing System 257
     Grid 281
Kauai 311, 319
Kauai, Hawaii 372
Keepers
of Records for Earth 26
of the Blue Flame 91-95, 195, 217, 237
571of the Flame 54, 89, 91, 92
of the Keys 304
of the Orange-Gold Flame 195
of the Violet Flame 195, 200, 203
Kee-Ra-ShA Light Currents 299, 306
Keylon 452-461
    Codes 455-461
     Crystal Body 458, 460
Keylonta 451-459
   Codes
                 downloaded into Anna Hayes 236
    science 7, 66, 183, 231, 232, 451-459
                6 Primary Elements 453-458
    technology 122
     Time Codes 7
Khundaray 272, 310
     Primal Sound Fields 299
     Sound Currents 306
Khundaray/Kee-Ra-ShA Primal Life Force
                 Currents 373
King Arthur 324
      and the Knights of the Roundtable 315-317
King Arthurus, see King Arthur
King David 323
King Solomon 323
Knights Templar 317, 370
    Free Masons 356
    Invasion 312, 321, 330
Kundalini 306
     -Maharata Life Force Currents 351
Kuntureaz 27
L
Lake Titicaca, Peru 392, 409
Lamanians, see Second Seeding
Lamb 367-369, 416
landing 327
languages
    five Christos 303
    Mu'a/Anuhazi 303
Larsa Kings 312, 320, 321
Las Vegas, NV 409
Law of One 3, 4, 25, 33, 34, 35, 36, 45, 57-
                64, 67-69, 89, 93, 95, 97-104,
                137, 170, 398, 496
  materialistic distortion of 45
Laws
  of Creation Physics 389
laws
  spiritual 4
Lemuria 261, 317, 353
   continent of Muarivhi 58
   Holocaust 319, 330
Lemurians, see Third Seeding
Leonines 60, 86
  see also Sphinx
Leviathan 398, 401
     Anti-Christiac King 313
     Force 328
Leviathan Force   353                                                                       
Ley Lines 247, 342, 348, 357, 367,
light
   -Symbol Codes 457, 460
                program 461
   workers 177, 186, 203
Lion 367-382, 414, 432

                                                                                                          Index Volume II
Little Grey 317
Lohas 314, 315, 316, 319, 320, 321
  -Celtec-Drueidec Freeze Out 31
   firmament collapse 311
Lohas-Celtec-Drueidec Freeze Out 320, 330
London, England 409
Long Island, NY 346
LPIN 372, 386, 392, 405, 432
Lucifer 330
Luciferian
-Anunnaki 320, 321, 322
Anunnaki 313
Centaur-Omega Centauri 317
Conquest 311, 320, 330, 391, 417
Covenant 245, 312, 313, 318, 320, 321,
         325
Hyksos Kings 323
Knights Templar 316
-Pleiadian 322
-Pleiadian-Nibiruian 317
Pleiadian-Nibiruian Anunnaki 318
Rebellion 244, 245, 311, 319, 330
Luciferian Rebellion 367, 370
Lulcus 390
Lumeria 372
Lumerian-Pylon-Implant-Network, see LPIN
Lyran 2, 6
High Council 250
-Sirian Anuhazi 318
-Sirian Elohie-Elohim 303
-Sirius A Anuhazi 266
M
Machu Picchu 212
   see also vortices
magnetic
   field collapse 113
   repulsion zone 130
Magnetic Peak 362, 408
Mahabharata 312
Maharaji 250, 312, 318, 320, 371, 379
Maharata 260, 302, 424
Maharic Seal 352, 419
   bene fits of using 498
Maharic Shield 258, 304, 497
   Manifestation 298
Majestic-12 126, 317, 326
Majestic-12, see MJ-12,
Maji 262, 281
    Grail Kings 321
Manhattan V ortex 408
Manhattan, NY 346
Manifestation 423
manifestation 152
   how to gain control over 159
   learning to de-manifest 159
Manifestation Template 291, 299
Marduke
     -Anunnaki 319      
    Dramin-Anunnaki-Omicron 245
      Necromiton Nibiruian 244
     -Necromiton-Luciferian-Alpha Centauri 317
Marduke-Luciferian Anunnaki 370
Marduke-Luciferian-Anunnaki 370
Mars 64, 123
Martial Law 411
572                                                                                                                                
Mary 251
Mary Magdalene 101
Mary, mother of Jesus 99-100
     see also Jeudi
mass
     dreams 152
     landing, staged 178, 208
Mass Awakening 405
Mass Landing 252
Master Key Codes 278
Masters Inter-Galactic Templar Mechanics 339
Masters Planetary Merkaba Mechanics 427
Masters Planetary Templar Mechanics 402, 413
matrix
15-dimensional 452, 458, 474
cosmic 459
host 30, 190
oversoul 457
silicate 101, 195, 477-478
soul 457
time 8
transplants 46, 168, 482
matter, as an illusion 129
Mayan
    calendar 239, 461
    Raids 312, 322, 330
Meajhé Field 342, 343, 372, 386, 405
Medianite-Hyksos 322
Mediterranean 366
Melchazedek 32
     see also Turaneusiam
Melchizedek
    Deception 370-384
    false ordinations 375
Melchizedek, King of Salem 98, 100, 101
Melchizedeks
   Alpha-Omega Order 370
Melchizedeks, see Cloistered Races
memory
      and dimensional bands 151
      erasing 92
      repression 134
Memphis 95
Men In Black 245, 317, 318
Men in Black 360, 392
mental
    bilocation 79
Meridan 315
Merkaba 248, 432, 499
External Reversed 257, 258
Group 258
Mayhem 259
Mechanics 258
natural Christiac spin ratio 259
reversed spin ratios 258
tailbone mark of reversal 260
Vehicles 418
Merkaba Fields 126-141, 188, 259, 456, 458,   
                  464, 466, 482
Harmonic Universe 127
Mechanics 126
Meta-galactic 127
Of Earth 127, 136, 140, 142, 144, 472
of Tara’ s gold core crystal 165
of Tara-Earth 136
of the Sun 133, 136, 143, 171
                                                       
             

 Index Volume II
     three levels of 150
Merkaba Vehicle
      Hallah Phase 301
Merlin 316
Messiah 102
Metagalactic Core 13, 34
Mexico 366, 391, 408
Miami, FL 409
miasms 22, 24
microchips
    crystalline 367
    silicon-based 367
Middle East 103, 251, 366, 377
Midianite-Hyksos Kings 321
Milky Way Galaxy 470
mind control 348, 351
Mintaka 368
Mintaka-Orion 279
Mion Field 407, 416
Miracle Cures 411
Miriam 314, 323
missing
    fetuses 235
MJ-12 354, 357, 361
Montauk 388, 409
Montauk Project 136-139, 172, 210, 339-
            346, 350, 352, 378-385, 388, 399
            408, 409, 429
Montauk, NY 359
Montsegur, France 367
Mormon faith, see religion
morphogenetic
Crystal Seals 473-477
Keylons 458
PartikiGrids 458
Partiki Strands 458
Partiki Units 458
wave 110-112, 123
                  backﬂow from 112
                  importance of 121
                  of 2017 67
Morphogenetic Field 5-25, 27, 30, 35, 40, 53
                  88, 124-130, 133-135, 300
Amenti 46, 124, 140
of a person 41, 150
of Earth 150, 228
of Sphere of Amenti 168
race 15, 79, 96
Moses 251, 324
most important thing you can do 231
movement
    as an illusion 129
MT 2, 12, 181, 233
Mt. Mitchell, NC 359
Mu 3, 4, 7, 54
 Council of 3
 Lumians of 3
 Lumiar Ceres of 4, 6
     Priests of 3, 4
Mu‘a
     Urtite 263
Mu’a 272, 274, 276, 278
     Lemuria 317
Muarivhi, see Lemuria
Muarivhia, see Mu’a
multidimensional
 573    physics 130 
    reality, lost memory of 53
multidimensional space-time
     mathematical structure of 226
multiple reality fields 147
mystery schools 67, 101
N
N. Ireland 359
Nadial
   substance 458
Nadis 35, 456, 457
Nagasaki 362, 363
Native Americans 29, 239, 325, 328, 461
natural healing 241
Nazis 363
NDC grid
    see Nibiruian Diodic Crystal Grid
NDC-Grid 380, 382, 387, 388, 392, 400, 415
NDE 493
     light at the end of the tunnel 493
Neanderthal 390
Necromiton 250, 317, 318, 360
   -Andromie 244, 250, 317, 327, 338, 359,
             362, 376, 378, 383
    -Andromie-Anunnaki 370, 371
Nefertiti 93-94
Nepal l0l 
Nephedem Annu-Melchizedek 323, 324, 325
Nephilim 370
Nephilim, see hybrids
Nephite-Nephilim-Necromiton Anunnaki-hybrid
              collective 244
NET 349, 355, 357, 380, 382, 384, 387, 388,
                 394, 397, 400, 403, 406, 416
New Age 248, 317, 336, 400
New Angelic World Government 252
new dawn 240, 462
New World Order 173
New York, NY
Nibiru 98, 242, 244, 246, 256, 314, 319, 327,
                  339, 379, 387, 391, 392
      Battlestar, see Battlestar 245
      Checkerboard Mutation 259
      more suitable to Necromiton-Andromies 380
Nibiruian 319, 326
     -Anunnaki 322
     Crystal Temple Network 340, 343, 345, 349
     Diodic Crystal Grid 311, 319, 324, 327,
               328, 355
Diodic-Crystal Grid 313, 321
Electrostatic Transduction, see NET
-Enlil-Odedicron 384
Enlil-Odedicron-Reptilian Anunnaki 374
Luciferian-Anunnaki 374
Marduke-Anunnaki 319
Re-acquaintance 330
     -Thoth-Enki 380
Noah 6, 324
Nohasa 311, 315, 319, 320
Noors 360
North America 56
Nubia 86, 102
numbness 249

 
O
observational outpost 60
Odedicron 313, 317
    -Avian-Reptilian 244
    -Reptilian 246
Odedicron-Avian-Reptiles 377
Odedicron-Lizard 265
Official Disclosure 383
Omega Centauri 245, 366
Omicron-Drakonian 244, 246, 247, 252, 265,
                313, 317, 323, 324
Omicron-Odedicron 377
One World Order 253, 254, 255, 320, 324,
336, 354-365, 366, 378, 379, 386,
390, 400, 403, 405, 410, 417, 426
   Master Plans 337
Oraphim 262, 264, 266
Bra-ha-Rama 267
Cetaceans 267
magnetic field 267
procreation 268
Oraphim-Turaneusiam 266
ordered energy 155
Origins 2
Orion 45, 123, 223, 242, 244, 246, 247, 253,
                317, 323, 379, 392
Black League 360 
-Drakonian 320
Intrusion 326, 330
-Mintaka 266    
Wars 246
Orion’s Sword 366
Osirius Kings 321
out-of-body travel
    dif ficulty in remembering 124
Over-Soul Integration 301
overtone 16, 17, 19, 20, 21, 24, 30, 35, 72,
75, 80, 83, 92, 111, 119, l26, 134,
135, 143, 161
OWO, see One World Order
Ox 414
P
Pacific 359, 366, 373
Pacific Ocean 56
Painted Desert 188
Pakistan 378
Palaidia 263, 269, 270, 275, 276, 278, 280,
                    284
   Urtite-Cloister 282, 293, 295, 308, 310
Palaidor 7
   Council of 33
   Covenant of 7, 8, 18, 33, 36, 69, 97, 107,
           121
Resistance Entity Wars of 18
Seal of 22-26, 28, 33, 43, 50-52, 105,
          134, 205
Palaidorian 271
/Amenti morphogenetic field 23
birthing contracts 194-198, 201
and rights of the incarnate 196
finalization of 196
Incubation Rite 197
protection of couples 197
    collective
574                                                                                                                                                                   
                          Index V olume II
            
           see Cloistered Races, five 17
  see Cloistered Races
Palestine 409
Paradisians 195
   see also Cloistered Race Yunaseti
   see also Seventh Root Race Euanjhechi
parallel
    Earth 9, 93, 110, 164, 296, 372
Pardo 146
particle 453, 458
   conversion period 223-225
   pulsation speeds 150
Particum 453-454
Partika 453-454
Partiki 452-461
   Grids 454, 459-461
   strands 454
past, illusion of the 148
Path of the Night of the Two Moons 183
Peace 252
pearly gates 15
Pearly Gates of Heaven
   see pearl ates
Pegasai 264
Pentagon 335
   see 2001-September ll
people, disappearance of 182
perception
   five-sensory 79
perceptual
   stations
           Bridge Zone 183-184
           descending planet 182-183
Persia 101
Persian Gulf 366
Personal Christos 296, 297
Personal Divine Blueprint 304
Peru 212, 430
   Machu Picchu 247
Phaelopea 91
Phantom Arcturus 418
Phantom Arcturus Matrix 418
Phantom Earth 392, 397
Phantom Earth, see Earth, Phantom
Phantom Matrix 369, 371, 372, 378, 387, 388,
                 394, 395, 396, 397, 420, 421, 431
Phantom Planet system 282
Phantom Pulse 345, 346, 406
Pharaoh
     Ahmose 322
Akhenaton 88-110, 323
Amenophis III 88, 89, 94
Amenophis IV 88
Djoser 322
Queen Hatshepsut 323
Rameses I  95                                             
Tutankhamon 90, 95-96
Tutankhaton 95
Tuthmosis III 321, 322                                  
                                             
Phi-Ex Wormhole 354-363
Philadelphia Experiment 130-131, 133. 137,
139,143,172. 188. 210, 350. 359
362, 387, 399
Philadelphia, PA 359, 408, 409
Phoenix 386-??, 388, 389, 391, 392, 393,

          
Index V olume II
              396.?? 399, 408, 417
Spiking Matrix 398
Phoenix Project 374-384
Phoenix Spike Matrix 394
Phoenix Spike sites 409
Photon Belt 114-116, 142
    discovery of 115
Photon Belt, see Universal Maharata Curren-
physical evacuation 340
PIN 359, 366, 388, 389
Place Holders 203
Planetary
12-Cycle 296
Merkaba Reversal 259
Security Seal 255
Shields 254, 258
Shields Clinics 247, 255-257
Signet Key Codes 277
Star Gate Security Codes 255
Templar Complex 245
          Star Gate system 241
Time Continuum 287
Time Cycles 296
Planetary Shields 294, 314, 343, 348, 368,
                    427
      Clinics 335, 346
      Reversal 401
Planetary Shields Clinics
      methodologies 383
Planetary Shields Crisis 426
Planetary Trion Field 342
planets
and holographic beam 115
ascension 8, 167
descending 167, 168, 174, 482
Earth 6, 7
      connection to Tara 40
Jupiter 6
Maldak 6
Mars 6, 45, 60
Mercury 6
Neptune 6
Nibiru 6, 64
Pluto 6
Saturn 6
twelve 5
Uranus 6
Venus 6
Pleiades 114, 127, 143, 242, 360
      -Alcyone 379
Pleiadian 6, 28, 29, 34, 35, 36, 51, 55, 57, 65
         69, 128, 374
-Alcyone 266
-Nibiruian 312
-Nibiruian Anunnaki 252, 254, 316, 324,
             325. 326
-Nibiruian Council 256
-Nibiruian Luciferian Anunnaki 317, 319,
       320
-Nibiruian Samjase-Luciferian-
                 Anunnaki 320
-Nibiruian-Luciferian-Anunnaki 320
-Samjase-Luciferian 380. 384
Samjase-Luciferian-Anunnaki 374
Serres 266
-Sirian Agreements 354
575    Star League 97.133. 141, 191. 233
Pleiadian-Sirian Agreements 241.242 243
246, 253, 256, 258, 318, 326, 330
350, 353
     Anunnaki defection from 245
Polarians. see Gaia
Polaric Codes 273
pole shift 22, 122. 131—134, 245. 250. 251,
253, 254, 255, 256, 257, 293, 314
318, 319, 321, 330, 340, 383, 412
     preventing 302
Pope 252
Port Interface Network, see PIN
portal 11, 12, 31, 33, 38, 45, 60, 61, 74, 76,
                89, 125, 128, 206, 227
bridge 27, 28, 51, 52, 64
control of 191
Hawaiian 235
Link  7
mechanics 4
project 177. 191
Portland,ME 359
power
     -generator crystals 5
     generators 57
Priests
of Amon 89
of Melchizedek 31-33
            balanced 33
            founding of 98
            unbalanced 33
of Mu 3,11,12, 32, 46
of Serres 95
of UR 264
of Ur 4, 11, 12, 32, 33, 56, 85, 89, 91-104,
         194, 197
Primal Creation Mechanics 422
Primal Order 281, 296, 297, 298
Primary Conjunction Points, see time cycles
Prime Initiative 352
Procyon 266
prolonged darkness and daylight 114
propaganda 178, 179
Protestant & Catholic Invasion 325
Psonns
     Master 303
     sacred 303
psychotronics 247, 251, 257, 344, 347, 356,
                       377, 385
public landing, to be staged 173
Pylon Implant Network, see PIN
pyramid 60. 61
   Cheops 61
   of Giza 61, 62, 63, 71, 86, 89-95, 100-
           102, 143, 187, 207
              alignment with Alcyone 65
              King’s Chamber 207
              rebuilt 86
Q
quarantine 70, 187
Quebec, Canada 430      
Queen Tiy 88-89

R
Ra 7, 22, 24, 34, 36, 46, 47, 50, 55, 56, 57,
               59, 66, 69, 96-100, 122, 233
Amonites 7, 34
Aton-a 7, 47
Azurites 7, 34, 97, 99, 100
Brigijhidett 7
Ra Confederacy, see Ra
race
      amnesia 255
      memory 25, 53, 76
radio
       as carrier for human programming 211
Rainbow Ray 302, 310
Rainbow Roundtable 303, 310, 315, 319, 324
      Regents of 302
      Rite of 306
      Tri-Veca 373
Rainbow Wearers 302, 306
Rama 263, 276
Rashayana 371
Real Ratios 259
reality fields 452
recent history 122-126
Red Pulse 133-134, 188
Redemption Contacts 380
Redemption Contracts 370, 379
Reiago 146
reincarnation 20, 148
Anna remembers her 236
ending the cycle 108
two 12-cycles 16
religion 411, 422
12 Global Freedom Religions 400
deception by 423
distortions in 67
Mormon 31
new 173
see also Jewish religion
used as disinformation source 178
Remote Interactive Teams (RITs) 348
remote viewing 347, 348
Reptile-Insectoid Rigelian-Zeta-Zephelium 244
Reptilian 383
Repulsion Zone 165
Rescue Mission
Stage 1 9
Stage2 10
Stage 3 1 1
Stage4 15
Resonant Tone 186, 202
responsibility
     personal 108
resurrection
     see Christs, Three
Revelations 239, 407, 416, 421, 426, 431,
                 461
     Decoding 414
Rigelian Zeta 252, 253
Rigelian-Zeta 383
Rishi 270
RITs, see Remote Interactive Teams
rod 55, 74, 92
and staff, see Blue Flame
Holder 55
Rod and Staff 312, 314, 320, 322
Roman
576                                                                                                                     
                   Index, V olume II
     Empire 324
     lnvasion 323, 330
Root Races 277
Fifth (Aeiran) 20, 22, 23, 24, 28-29
Fifth (Aryan) 56, 78, 82, 84, 85, 98
Fifth (Ayrian) 29, 43-44, 46, 56, 78
Fourth (Alanians) 18, 29
Seventh (Euanjhechi) 43, 84, 195
Seventh (Yunaseti) 38-43
Sixth(Muvarians) 30, 52, 84, 123, 124, 195
Third (Lumarians) 17, 29, 30
Roswell, NM 346
Roundtable 278-289, 325
and King Arthur 310
Rainbow 302
reality of 302
RRT, see Rainbow Roundtable Rite
RRTs 389, 402, 405, 427, 428, 430, 432
Russia 215, 251, 320, 321, 377
S
Sabatoth 91-95
SAC Rebellion 327, 330
SAC, see Stellar Activations Cycle
Sacheon Annu-Melchizedek 320
Sacred Cow 371-372
Sacred Mission of Planetary Guardianship 291
Sacred Planetary Templar Merkaba
                  Mechanics 351
sacri fice 257
safe spaces 179
Saint John the Divine 416
Sakkara 322
Saleane 315
Salem, see Jerusalem
Sananda 99
Satan/Lucifer 422
savior 100
    see also Jesheua-12
Savior Space Brothers 355
Scalar Pulse 359
scalar pulses 375
Scalar Shield 300
Scarab Kings 312, 321
science
     of Creation Mechanics 241
     of Vibrational Mechanics 451
     sacred 245, 255, 298
Sea of Japan 366
Seals
    12 Planetary Star Crystal 426
Jehovian opening schedule 429
Morphogenetic Seed Crystal 463
Security 254, 256, 34
see also Amenti
see also Amenti, Sphere of
see also Palaidor
see also Templar
see also Templar -Axion
     see also Zeta                                                       
     Seven Jehovian 426
     seven natural 142
Sedona, AZ 188, 346
see also Interdimensional Association of Free
                Worlds
Seed Codes 477
                                                             

Index, Volume II
Seed Implants 394
Seedings 328
      First 17, 78, 244, 251
     Second 21, 25, 26, 27-31, 43-51, 55, 63,
          271
               Atlanians 21, 22, 28-29, 45, 46,
                               123
               Lamanians 21 , 22, 28-30, 44, 45,
                                46, 55-56
     Third 21, 26, 28, 32, 36, 47, 51, 52, 55-
             70, 261, 269, 311
              Atlanteans 21, 22, 28, 32-33, 56-
                                59, 63-74, 78, 82, 84, 86,
                                87, 123
                   -Egyptian sub-race 48
                Lemurians 21, 22, 28, 56-59, 78,
                                 82, 84
Selenite Crystal Temple Network 339
selves
       1728 simultaneous 299
       3456 simultaneous 297
Seraphei-Seraphim 369
Seres 46, 50
Serpent 374
Serres 46, 91, 368
       -Egyptian father of Akhenaton 88
        -Egyptians 82, 85, 89, 91, 93, 94, 97, 323
                       evolutionary advantage of 76
   -Pleiadian 318
Serres-Egyptians 323
Set Kings 321
Seven Angels 417, 418, 431
Seven Angels with Seven Trumpets 416
Seven Angels with their Seven Trumpets 414
Seven Candlesticks 418
Seven Churches 417, 418
Seven Seals 414, 416, 420, 426,431
Seven Stars 418
Seven Trumpets 431
sexism 46
shadow self 35
Shambali, Bhrama and Annu-Melchizedek
                 Races of Inner Earth 271-272
Shambali-lonian Islands 271
Shamballah 271
Shield
     of Aramatena 281, 283, 291, 310
     of the Arc 52
Siberia 377
Signet
Ancestral Ascendancy 304
Codes 319
Council 304, 315
Councils 315, 319
maps and keys 305
Master Key Codes 273, 275
Rainbow Roundtables 340
Sites, 12 Primary Star Gates 251
Star Gates 294, 311
Silicate Matrix 300
Sir Lancelot 315
Sirian 2, 6, 65, 223
    -Arcturian Coalition for Interplanetary
             Defense 50, 51, 60, 71, 133, 141,
             233, 234
577Council 2, 3, 4, 7, 27, 28, 34, 36, 50, 60-
            69, 71-75, 83, 88, 93, 96, 97, 122,
            133, 137, 141, 177, 187, 188, 191,
            233, 250
                    intervention in 1972 133
Rebellion 3, 4, 45
root races
        Anunnaki 4, 18, 33, 45, 47, 50-69
                        86, 186, 191, 242, 245
        and Jehovah 100
        as Gods of humans 46
        Rebellion 58
        Resistance 142, 50-69, 71, 72
                           176
        see also 666
        see also Akhenaton
         blues 4, 47, 57, 73
Sirius 26, 244
     A 47, 48, 55, 102,242,379, 418
              Jehovian Anunnaki 320
              Jehovian-Nibiruian Anunnaki 319
    B 27-29, 48, 51, 55, 57, 62-65, 73, 93,
      94, 99, 100, 102, 250, 317, 379
            Azurite Yani 266
            Maharaji 271
            Marduke-Anunnaki 320
Sirius A 379
slaves 352
sleep 77-78
sleepers 347, 354, 355, 363, 365, 377, 380,
               399, 406
      Angelic 356
Smenkhkaré 94-95
Snake Brotherhood Kings 321
Sodom and Gomorrah 513, 322
Sodom and Gomorrah. 406
Solar
      Star Gate-4, see Universal Star Gate
solar
      activation 204
      eclipse 182
      ﬂares 133
      storms 182
solid matter
      illusion of 149
Solomon 99
Sonic Pillars 394
Sonic Pulse 374, 378, 385
soul
     agreements 172
          Anna remembers her 236
     fragmentation 16, 93
     harvesting 36
     mate 148
Soul Integration 301
sound
     -Symbol Program 303
     -tone Programs 303 
     Tones 108
Sound Pillars 372
South America 368, 377
space
     as an illusion 129
     distance as magnetic repulsion 129
Sphinx 59-64, 73, 82, 86, 207, 367-368

      hidden passages below 207
      rebuilt 64
Spiking Campaign 394
spiritual development 241
Spiritual Integration 298
Spiritual Manipulation 399
Spokane, WA 409
St. John the Divine 416
St. Louis, MO 409
Staff 74, 92, 120
     Holder 54
     see also rod and staff
standing wave pattern 14
star
     gate 245, 272, 276-285, 288, 299, 319,
            321
                -10 378
                -3 391
                -4 391, 396
                -4 see Universal Star Gate<$no
                                  Page> 340
                 -5 Alcyone 340
-6 339
-7 392, 417
-9 378
D-6 Sirius B 339
internal 297, 298, 301, 308
locations 317
planned destruction of 313
   gates 367
   tetrahedron 126
   wars 175, 257
states of being 456, 458
Stellar
   Activations 155, 180, 186, 195, 292, 302,
        463-466, 482
Arcturian 200
Orion 200
Pleiadian 200
see also SAC Rebellion
Sirian 200
Solar 200
Transmutative 471
             mechanics of 199
             six 199-200, 466, 471-472
                                  476
Bridge 470-473
Spiral Alignments 475
Spirals 127, 142, 186, 471
         Alignments 199, 482
         what you must know 484
Wave Infusions 186, 466-470, 472, 482
Blue 200, 237, 466
Blue-Black 200, 466
Gold 200, 466
mechanics of 199
          Silver 200, 466
          Silver-Black 200
         symptoms of 469
         Violet 200, 466
Stellar Activations Cycle 281, 286, 288, 313,  
578Index, V olume II
                   354
Stellar Activations Cycles 413
Stellar Wave Infusions 339, 404
Stonehenge 247, 251, 312, 316, 319, 321,
                    340
stress 469
suicide 42
Sumer 321
Sumeria 28, 86, 322
Sumerian Invasion 312, 321, 330
Sun 6, 126-140
abnormal activity on 131
affected by Zeta electromagnetic pulses 132
as eighth Pleiadian star 115, 128
as iron core crystal D-1 Merkaba Fields 128
illusion of distance 164
manipulation of energy field of 131
Superconscious Mind 81
Syria 101
T
Tags 349, 351, 375, 384, 416
Taliban 377
    Dragon agenda 377
Tara 1-20, 27, 30, 33-36, 41, 43, 50-72,87-
94, 99-121, 123-141, 143-
144,148,161,161-183,185-186,
190-192, 195-229, 266, 379, 483
cataclysm 282
cataclysm of 3, 4, 7, 45
future 71
Ivory Gates of 13
Palaidorians of 6, 190
Taran
     Ceres 27
     -Turaneusiam 67
     Wars 4
Target Sites
      24 Primary 251
teachings, mystical 28
Tel el-Amarna 89, 89-90, 95
teleportation 54, 57, 62, 64, 69, 71, 72, 86
television, programming humans 211
Templar
-Annu 58-68, 72, 82, 84, 89
-Axion Seal 33-36, 94, 97, 105, 134, 218
-Axions 34
Complex Star Gate System 289
Creed and chosen ones 97
Cue Sites 275, 278, 305
-Melchizedeks 98, 101
             see also Cloistered Races
original teachings  68
Seal 83, 85, 88, 98-99, 105, 216
              released from the Annu 87
Signet Site star gates 278
Solar Initiates 3, 4, 33, 45, 58, 59, 67
teachings distorted 68
technology 258
use of torture 65
   Template acceleration 281
    terrorist activity 409
    terrorists 347
    Teura 474
    The Four Horsemen Of The Apocalypse 420    
    Thebes 86, 88, 89, 95                        
  
                        
                                                        

        Index, V olume II
Third Eye of Horus 24
Thoth 260
     -Enki-Zephelium 384
     -Enki-Zephelium-(Zeta) Anunnaki
           collective 244, 258-260
    -Enki-Zeta 376
Thoth-Enki
      Annu-Melchizedek 320
      -Zephelium 256, 320
Thoth-Enki-Zephelium-Anunnaki 321
Thoth-Enki-Zeta Anunnaki 370
thought-forms 153-159
threat 251
Three-Day Particle Conversion Period 343, 388
three-dimensional perception
      illusion of 150
Tiamat 391, 394
Tibet 101, 103, 378
time
acceleration 343
as an illusion 129
continua 118, 146, 288
cycles 110-114, 120, 123, 286, 291
           26,556-year Harmonic 114, 120.
                       131, 199, 202, 239, 461, 471
               4,426-year subcycles 110, 146
ascension 111
mechanics 146-148
Primary Conjunction Points 110
Primary Coordinate Points 1 10
fields 11
illusion of movement 147, 152, 158
-Leap Mechanics 225-229
simultaneous 147
three tracks of 169-184
Track One 169-172
Track Three 176-177
Track Two 172-176
travel 7, 43, 54, 62, 71, 123, 138, 170
vectors 288, 296, 308
wall in 26, 386-397
warp 12           
Tower of Babel 312, 322, 406
Transcendence Day Stand 346
transmutation 170, 205
   of the human body 473
Transmutative Activations 464-466
Trapezium Orion 418
Treaty
of Altair 246-247, 318, 327, 371, 385
of El-Annu 48-51, 57, 58, 100
see also government, Interior
see also Guardians
see also Zeta
treaty
    Pleiadian
                  -Sirian Agreements 380
     Pleiadian-Sirian Agreements 381, 382
Treaty ofA1tair 318, 330. 345
Triadic Codes 274
Tribal Shield 297, 299, 302, 303
    Dynamics 307
Tribulation 252
Trigger Events 336, 337, 377
Trion Field 372
579Trion Pillars 343
Tri-Veca Time Continuum 372
Trumpets 406-419
truth 250
    inner 69
tunnel vision 26
Turaneusiam 1, 2, 4, 7, 8, 9, 10, 12, 18, 27,
                  30, 43, 46, 83, 84, 262. 265, 268
    see also Templar Solar Initiates
    sub-races
 Adami-Kudmon 2
Addami 2
Alania 5
Alanians 2-6, 18
Atoni 2
Azurtan 2
Beli-Kudyem 2
Bra-ha-man 2
Celtos 2
Ceres 3
Ceres-Lumian-Alanian 4
Cerrasz 2
Dhr-ah-me 2
Lumians 2, 3, 6
Luri 2
Melchazedakz 32, 233
Melchizedakz 2
Nezack-tai 2
Trin-i-ten 2
Ur-Tarranates 4-9
Yutaran Turaneusiam 4
Yutarans 2
Tutankhamon, see Pharaoh
Tutankhaton,see Pharaoh
Twelve Tribes 18
   names 303
twin ﬂames 148
U
U.S.S. Eldridge 131
UFO 231, 248, 326
    investigation 336
UHF 61, 62, 72, 74, 88, 92, 96, 100, 104,
109,115,125,133,135,181,193,
207, 495
U1R 250-259, 271, 318, 319. 326. 327, 330,
               335-353, 365, 371. 373-374. 377,
               385, 386, 388-389, 399, 400, 404-
               406, 408-414, 427, 429-430, 432
    Edict of Wa r 335, 337. 338, 339. 371. 433
    only way to stop 328
    Plan 253
    Silent Invasion 410
ULF 133. 162
     phantom electrical pulse 210
Ultraterrestrials (UT) 233
underground bases 251
underground civilizations 5, 32, 44, 45, 55, 56
Underworld 92
Unholy Alliance 359
Unified Field Physics 281
unified fields 16, 24, 40, 112, 128, 147, 149,

           
              
              
                      156, 454
      15-dimensional 464
      of Energy and Consciousness 459
      of the 15-dimensional Universal system 474
United Federation of Planets 412
United Intruder Resistance, see UIR
United Nations 252
Unity Consciousness 69
Unity through Tolerance 411
Universal Christos Divine Blueprint 291
Universal Encryption Key Codes 272, 276, 279
Universal Maharata Current 283, 299
Universal Signet Key 279
Universal Star Gate 245, 246, 247, 254, 256,
                264, 374, 382, 383
Universal Templar Complex 294, 311,
universe
    energy mechanics of 128
    Harmonic 129
              see also HU
Unnatural Disasters 409
unnatural disasters 412
UR 321
Ur 86, 89, 275
   -Antrians, see Cloistered Races
   -Tarranates 6-8, 27, 190
               turn over custody of Earth 191
   Urtite 263
Ur-Tarranates 266
Urtite 263, 269, 280
Urtite-Bi-Cloister Maji 276-277
   Rama 276
Urtite-Tri-Cloister Maji 271, 272
USA 251, 377, 431
    Constitution 361
V
Vale of Pewsey 314, 315, 324
Veca-Code Mechanics 339
Vector Codes 307
Vega-Lyra 279, 360
Vicherus Annu-Melchizedek 320
Vicherus-Sacheon Invasion 311, 320, 330
Victorous, see Merlin
Vietnam 359
Viragi 7
   see also Brigijhidett
viruses 252
   AIDS 252
Visitor Contact, reality of 382
Visitors 25, 43, 45, 85, 199
vortices 62, 73
Earth’s lst (Sedona, AZ) 188
Earth’s 2nd (Jerusalem, Israel) 189
Earth's 3rd (Himalayan Mountains) I91
Earth’s 4th (Giza, Egypt) 62, 73, 142, 203
Earth’s 5th (Machu Picchu, Peru) 212
Earth’s 6th (Caucasus Mountains,
            Russia) 215
Earth’s 7th (Andes Mountains, South
           America) 216
Earth’s smaller, secondary 191
seven primary 227
            closing of 229
V oyagers 43, 169-172
       companion 171
 580Index, V olume II
W
Waco, TX, 413
wars
American Civil War 361
Angelic 264
Centaurian 312, 321, 330
covert global 250
edict of 318, 327
Electric 251, 368
Frequency 347, 379
Grail Quest 311
instigation of 386
instigation of regional 251
Official Edict of 250
on Terrorism 376
on terrorism 410, 416
Orion 246
see also Thousand Years' War
see Electric Wars
see Holy Wars
see Palaidor Resistance
see star wars
see World War
Thousand Years’ 43-49, 50, 60, 271
World War 125, 362
World War II 125, 326. 354, 357, 361, 381
         432
World War III 345. 432
          and bin Laden 377
Washington, DC 359
water
      system contamination 211
Wave Infusion 463
     Blue 209, 213
Blue-black Liquid Light 218, 222
Gold 214, 222
Silver 222
Silver-black Liquid Light 223
six 472
Violet 209, 214, 238
waves 40
       morphogenetic 41
       of Solar Flame 188
weather
    anomalies 114
    modulation 61
    patterns 22, 74
White Eagle 370-385,409
White House 408
Wingmakers 550, 553-555
women
    as breeders of hybrids 46
    subservient to men 46
World
    Fifth 42,, 461
             transition into 462
    First 2, 10. 462
    Fourth 28-29, 462
    Second 10, 462
    Third 17, 18, 462
World Trade Center Disaster, see 2001-                    September 11
World Trade Towers, see WTC
World War III 347
worm holes 7            
wormholes 375, 393, 398, 417             
                                                   
                                     

Index, Volume II                                                                       
A7/L3 Falcon 362
Falcon 375, 409, 427
Falcon partial cap 382
Falcon uncapped 385
into other Time Matrices 395
locations of 357
Phi-Ex 359, 378, 380
Phi-Ex Cap 381, 382
Phoenix 418, 421
Wormwood 245, 327, 375, 387, 415
WTC 408
see also 2001-September 11
Y
Yanas 265, 270, 275
Yani 264
Yu 274, 276
      -Urtite 263
Yucatan 322
Yunasai 453
       Order 371
       see also Central Creative Source
Yunaseti 272 
      see Cloistered Races
      see Root Races, seventh
   Z
Zephelium 83, 123, 317
Zephelium-Zeta 313, 317
Zeta 123, 142-145, 162-183, 253, 317
collective mind 124, 130, 137
-Dracos alliance 123
-Dracos-Anunnaki 347
Frequency Fence 124
Grey-Rigelian (Futczhi) 137, 144
Legion treaties with Guardians 137
most dangerous to humans 137
old agenda 122
      see also agendas
Reticuli, reasons for seeking human DNA 83
Rigelians 257
-Ruled Society 253
Seal 124, 130, 134, 137, 142, 143, 206
Surveillance 326, 330
time travel back to Earth’s present 123
Treaties 317, 354, 378, 426
       and MJ-12 330
Zeta/Illuminati
    sonic scalar pulse testing locations 366
Zeta-Rigelian-Drakonian 366
Zhar Confederacy 7, 233
_____________________________________
Ordering information
V oyagers I, second edition, ISBN 1-893183-24-6, 272 PP
V oyagers II, second edition (paperback)  ISBN- 1-893183-25-4, 592 PP
V oyagers II, second edition (digital)  ISBN- 978-0-692-84552-3, 595 PP
For further information please contact:
ARhAyas Productions LLC
5020 Clark Rd #307
Sarasota
FL 34233
Email: office@arhayas.com
Phone: 941-924-8109
Or visit our website
www.arhayas.com
                   581