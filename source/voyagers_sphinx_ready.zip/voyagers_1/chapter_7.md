Chapter 7: Levels of Identity and Components of
Mind In this section we will provide two exercises that can, with
practice, assist you to begin the process of awakening the multi-
dimensional aspects of your identity. In Exercise 1, (Error: Reference
source not found) the Monitor Technique is geared toward developing
mental focusing ability while in the dream state and to train the mind
and body to begin organizing dream experience into sequences that are
recognizable to the personality. As these skills develop the dream state
can be used to access guidance and information pertinent to the
personality in the waking state of consciousness. This exercise is
particularly useful when attempting to discover whether you have had
contact or abduction experiences with ET or other-dimensional beings in
this life time and to access more information and memory pertaining to
such contact experiences. The exercise is also useful in applications of
memory and data retrieval not related to the Contact/Abduction
Phenomena. Exercise 2 (Error: Reference source not found) the Induction
Technique is intended to assist the body and mind of the 3-dimensional
personality to come into greater alignment and harmony with the personal
Soul Matrix (identity levels stationed in dimensions 4--6). This
exercise utilizes rudimentary functions of Keylontic Morphogenetic
Science, whereby Keylontic Symbol Codes are used to restructure the
organization of the personal Keylon Crystal Body (the crystalline
latticework blueprint for the body and consciousness that is composed of
ultra-micro particle units called Partiki). The existing arrangement of
Keylon Codes within the crystalline morphogenetic body will be subtly
rearranged to produce greater conductivity of energy and awareness
between the physical body, 3-dimensional personality and the Soul
Matrix. This realignment of existing Keylon Codes prepares the body for
dormant DNA code activations that can be initiated through Keylontic
Science DNA Activations Exercises. This exercise does not activate
dormant DNA codes, but prepares the body to better synthesize later DNA
activations, thus it is considered to be a Keylon Code Pre- activation
Exercise. In using any form of hypnotic or consciousness-expansion
technique it is important to first have a rudimentary understanding of
the multi-dimensional mental processes involved in such manipulations of
consciousness. You do not have to understand the complex workings of the
brain and neurological structure to create a working comprehension of
the mind and the attributes of consciousness associated with that
facility. It is however useful to have a basic model of the structure of
multi-dimensional identity in order to gain sovereignty over the
processes associated with the multi-dimensional mind. For this reason we
will provide the following model of multi-dimensional identity and a
brief introduction to the Components of Mind associated with these
identity levels. Using this framework you will be able to begin learning
to direct multi-dimensional energy into effective transformational
patterns on a conscious level. At your present stage of evolution much
of these energy-directing functions take place on levels of awareness
that are beyond your conscious view. As your consciousness evolves these
functions will progressively come under your conscious direction.

The Six Primary Levels of Identity and the Four Components of Mind. The
"mind" is an attribute of consciousness. The mind does not produce
consciousness, consciousness is not a product of mind, but rather the
mind is a structure of energy that consciousness creates and uses in
order to participate within realities that have their basis in
differentiated perception. Perception itself is an attribute of
consciousness and mind, it is the product of consciousness using the
facilities and structures of mind. The mind is the portion of your
identity that allows you to experience individuality. The mind exists as
a large conglomerate of electromagnetic energy units called Partiki,
which span multiple dimensional fields. Consciousness itself does not
possess form other than the units of electrotonal energy of which it is
composed (Partiki), but consciousness uses form constructions such as
the mind to create the experience of differentiated perception. The form
construction of the mind is created through organized groupings of
Partiki units or "electrotonal units of consciousness." The form
construction of the mind has multiple levels that correspond directly to
the form construction of the 15-dimensional universe. Dimensions exist
as smaller Unified Fields of energy within the larger structures of the
Universal and Cosmic Unified Fields. Like the structure of the mind, the
cosmos is also composed of organizations of Partiki units that form a
crystalline matrix upon and within which all differentiated forms and
identities are created. Dimensions are smaller organizations of
crystalline Partiki structure that form distinct bands of
frequency---patterns of electromagnetic, light, sound and scalar waves
---that serve to arrange consciousness in ways through which perception
and dimensionalized creation can take place. The structure of the mind
is interwoven with the greater structures of the Cosmic Unified Field.
Both the structures of the cosmos and the structures of the individual
mind are composed of the electrotonal energy substance of Partiki units
---units of electrotonal consciousness---and thus the structures of the
cosmos and its inherent universes can be viewed in terms of the
Universal and Cosmic Mind. The individual mind exists and takes place
within the dimensionalized construction of the Cosmic Mind. In simple
terms the individual mind is composed of consciousness that manifests as
electromagnetic micro-particles that travel in dimensionalized bands of
frequency and which create the contours of manifest form and identity.
The bands of frequency that form the mind structure are composed of
Partiki units that group to form "interwoven fibers or strings of
Partiki" called Partiki Grids. Partiki Grids further group to form
Keylons, the crystalline structures that form the blueprints for
identity and matter manifestation. The Keylon blueprint is the
Morphogenetic Field (form-holding template) upon which the structures of
the mind and body are built. Within the greater construction of a 15-
dimensional Universal Matrix the personal identity possess a 15-
dimensional Morphogenetic Field (a "Keylon Body") that energetically
connects the individual identity to the universe and to the cosmos. In
universal structure the 15 dimensions are grouped into triads of 3
dimensions each, forming 5 interwoven, over-laid reality fields that are
called Harmonic Universes (HU). Each individual mind has a level of
Triadic Identity (or 3-dimensional identity) stationed within the
frequency bands of the 5 Harmonic Universes. The portion of mind that is
known as the "Earthly identity" represents the portion of the mind that
exists within Harmonic Universe-1, the portion of personal consciousness
that is stationed within the frequency bands of dimensions 1, 2 and 3.
This HU-1 Triadic Identity is one of 6 primary identity levels that
exist within the Cosmic Unified Field. The 6 Primary Levels of
Multi-dimensional Identity are as follows: Triadic Identity 1: the
Tauren (the Incarnate Matrix)-- HU-1, composed of frequency bands from
dimensions 1, 2 and 3. Includes the Subconscious, Instinctual and
Reasoning Mind. Represents the Individual Mind Matrix (or "Personal
Logos"). Triadic Identity---the Dora (the Soul Matrix)---HU-2, composed
of frequency bands from dimensions 4, 5, and 6. Includes the Astral
Mind, the Archetypal Mind and the Angelic (or "Celestial") Mind.
Collectively called the Superconscious Mind. Represents the Race Mind
Matrix. (or "Collective Logos"). Triadic Identity---the Teura (the
Oversoul Matrix)---HU-3, composed of frequency bands from dimensions 7,
8 and 9. Includes the Ketheric Mind, the Monadic Mind and the Keriatric
Mind. Collectively called the Causal Mind. Represents the Planetary Mind
Matrix (or "Planetary Logos"). Triadic Identity---the Avatar (the Dolar
Matrix)---HU-4, composed of frequency bands from dimensions 10, 11 and
12. Includes the Christiac Mind, the Buddhiac Mind and the Nirvanic
Mind. Collectively called the Metaconscious Mind. Represents the
Galactic Mind Matrix (or "Solar Logos"). Triadic Identity---the Rishi
(the Solar Matrix)---HU-5, composed of frequency bands from dimensions
13, 14 and 15. Includes the Particum Mind, the Partiki Mind and the
Partika Mind. Collectively called the Universal Conscious Mind.
Represents the Universal Mind Matrix (or "Universal Logos"). Identity
Level---the Geomancy (the Yunasai Matrix) The 6th Primary level of
Multi-dimensional Identity exists beyond the structure of 15-dimensional
construction. Collectively called the Cosmic Conscious Mind. Represents
the Cosmic Mind Matrix (or the "Cosmic Logos"). It represents an eternal
gestalt of identity that is non- dimensionalized and free from
space-time-matter orientation, a level of mind that exists as part of
the One Mind---or the Source Mind of the Core Creative Force. This
identity level is called the Geomantic Entity ---or Geomancy. All other
levels of identity and mind and the structures of all dimensional
systems exist within the crystalline latticework morphogenetic blueprint
of the Geomantic Entity Gestalt identity. Through the Geomancy all
things, beings and consciousness are connected to and contained within
the Central Creative Gestalt Identity of Source Mind. The structure of
the 6 Primary Levels of Multi-dimensional Identity represent a literal
Family Tree of Consciousness through which all humans are connected to
each other, all other life forms, the Universes, the Cosmos and Source
Mind---one Mind ("God"). From the perspective of the HU-1 incarnate
identity the process of evolution is the process of incorporating all
six levels of multi-dimensional identity into the conscious cognition of
"I am...." The first step in awakening multi- dimensional identity is to
bring the Superconscious Mind of the HU-2 Soul Matrix into conscious
recognition within the biologically focused personality. This process is
called Soul Integration. Within the process of Soul Integration you are
primarily dealing with 4 Components of Mind---the Subconscious Mind of
D-1 frequency bands, the Instinctual Mind of D-2 frequency bands, the
Reasoning Mind of D-3 frequency bands and the Superconscious Mind of the
D-4 through D-6 Soul Matrix gestalt. Soul Integration comes with
conscious assimilation of these 4 Components of Mind.

The Four Components of Mind

I. The Subconscious Mind/Body Consciousness/ Cellular Memory Facility
Key Functions: Data Storage. Stores perceptual imprints from various
Components of Mind and stores directional impulses from the
Superconscious Mind, through which the body receives its operational
"orders" from the Soul Matrix. The Subconscious Mind is composed of
Partiki units and Keylons, it exists as a minute crystalline blueprint
within the cellular structure of the body and serves as a memory storage
facility and regulator of the body's autonomic processes. Memory is
stored within the cells and Keylon Codes of the entire body, not just
within the brain. The biological memory of the Subconscious Mind is
called Cellular Memory. The Subconscious Mind is the portion of your
personal identity that manifests as the physical body form and the
crystalline blueprint within the molecular structure. It represents the
"Body Consciousness." It is this portion of identity that is accessed
when using techniques such as hypnosis. The Subconscious Mind translates
energy signatures from the dimensional Unified Fields of energy into
perceptual data such as light, sound, taste, smell, touch, temperature,
objectified form and linear passage through time. Working co-creatively
with the other Components of Mind the Subconscious Mind creates the
holographic illusion of 3-dimensional matter, objectified space and
linear passage through time. Keylontic Symbol Codes are the languages of
the Subconscious Mind. The Subconscious Mind translates thoughts, ideas
and beliefs into Keylontic Symbol Codes of light, sound and
electromagnetic standing wave patterns that direct the morphogenetic
Keylon structure of the body. Thoughts will thus affect the health or
disease of the body, as their biological Keylontic translations will
either assist or impede the flow of energy between the body, the
personality and the Soul Matrix. The Reasoning Mind can use Keylontic
Symbol Codes to direct the processes of the Subconscious Mind and body
and to access information stored within Cellular Memory. The
Subconscious Mind is primarily associated with frequency bands of D-1,
the physical body, the 1st DNA strand, the Base Chakra and the Etheric
Body (1st level out from the physical body) level of the bio-energetic
field.

II. The Instinctual Mind: the Emotional/Intuitive facility. Key
    Function: Data Relay. To relay directional electrical impulse and
    information from the Soul Matrix/Superconscious Mind into Cellular
    Memory storage within the body/Subconscious Mind. The Instinctual
    Mind is also composed of Partiki and Keylons, it exists as a minute
    crystalline blueprint within and surrounding the body and serves to
    draw information in the form of electrical impulse from the Soul
    Matrix into the Subconscious Mind/Cellular Memory. Emotion and
    Intuition represent translations of information from the Soul
    Matrix/Superconscious Mind as they are relayed to the Subconscious
    Mind via the Instinctual Mind. The instinctual behavior of animals
    occurs through a similar process of information "downloading" from
    the collective species Soul Matrix into the Cellular Memory.
    Originally the human Instinctual Mind was intended to hold the
    individuated identity in place while keeping the identity intimately
    connected to the Soul Matrix and to the guiding impulses of the
    Superconscious Mind. Due to ancient DNA manipulations of the human
    gene code the electrical impulses from the Soul Matrix are unable to
    fully process into the Cellular Memory of the body. The impulses
    "pool" within the bio-energetic field creating an area of
    disorganized, chaotic energy between the body, personality and Soul
    Identity. This area of chaotic energy represents the first level of
    dream reality that the consciousness will encounter as it
    disassociates from the Body Consciousness during sleep. The
    Instinctual Mind sets the organizational sequence of memory as it
    will be programmed into the body. Due to the present DNA distortion
    within the Instinctual Mind memory of multi- dimensional experience,
    dream reality and cognition of the Superconscious Mind is jumbled
    within Cellular Memory and appears fragmented to the Reasoning Mind.
    Repression of emotion and intuition contribute to the distortion of
    the Instinctual Mind and can create exaggerated physical, emotional,
    psychological and memory distortions within the identity. Keylontic
    Science techniques can be used to "side step" the area of chaotic
    energies within the Instinctual Mind to create clearer memory
    retrieval, dream recall and communication between the
    body/Subconscious Mind, Reasoning Mind and the Superconscious Mind.
    Keylontic DNA realignments and activations can be used to correct
    the genetic distortion of the Instinctual Mind. The Instinctual Mind
    is primarily associated with frequency bands of D-2, the
    emotional-intuitive awareness, the second DNA strand, the second
    Sacral Chakra and the Emotional Body (second level out from the
    physical body) level of the auric field.

III. The Reasoning Mind: the Logical/Rational facility Key Function:
     Data assimilation, translation and manifestation. Assimilates
     electrical impulse data from other Components of Mind, translates
     these impulses into patterns recognizable to the waking personality
     and assists in the holographic projection/manifestation of
     electrotonal Keylon Codes from the Cellular Memory into externally
     perceivable reality.  The Reasoning Mind is composed of Partiki
     units and Keylons, it exists as a minute crystalline blueprint
     within and surrounding the body and serves to synthesize and
     translate data from other Components of Mind into a holographic
     representation of external, 3-dimensionally perceivable reality. It
     is intended to allow the identity to observe and experience the
     illusion of matter-density and to perceive and interact with
     objectified space, time and form. The Reasoning Mind also assists
     the Superconscious Mind/Soul Matrix in the manifestation of the
     biological organism and serves to direct many functions within the
     Subconscious Mind/body and the Instinctual Mind/emotions and
     intuition. The Reasoning Mind was designed to assimilate electrical
     impulses from all fields of perception into a solidified and
     coherent picture that allows for the experience of individuated
     biological identity within the framework of space-time- matter. It
     is a synthesizer of energy, translator of Keylontic Codes and
     projector of holographic imagery. Part of the Reasoning Mind
     utilizes the physical brain and neurological structure. Portions of
     the Reasoning Mind exist within the structures of the Body
     Consciousness and work co-creatively with the Subconscious Mind.
     Other portions of the Reasoning Mind exist within the Instinctual
     Mind and the Superconscious Mind of the Soul Matrix. The Reasoning
     Mind is multi- dimensional and it is simultaneously focused within
     the Four Components of Mind. It represents the organizational
     aspect of mind through which perceptual data from all Components of
     Mind can be brought together into a cohesive reality picture. The
     "ego/conscious personality" represents the portion of the Reasoning
     Mind that is primarily focused within the frequency bands of the
     third dimension, which "looks out upon the illusion of
     matter-space- time." The "Dream self/higher self" and the "Astral
     self" represent the portions of the Reasoning Mind that are
     interwoven with the Superconscious Mind within the Soul Matrix.
     They serve to assimilate higher dimensional experience and
     information into terms comprehensible to the ego identity. Due to
     genetic distortions and the present level of genetic evolution,
     humans must disassociate the consciousness from the ego and the
     body during sleep, in order to have full conscious focus within the
     body of the Dream self, Astral self or Soul Matrix. The
     Intuitive-self represents the portion of the Reasoning Mind that is
     intertwined with the Instinctual Mind and emotional body, which
     serves to unite the physical body/Cellular Memory/Subconscious Mind
     with the higher dimensional levels of identity. The Dream
     self/higher self, the Astral self and the Intuitive-self represent
     portions of the Reasoning Mind that operate, experience and
     perceive simultaneously with the Ego self, whether or not the ego
     is consciously aware of these perceptions. Information gained
     through the various portions of the Reasoning Mind can become
     available to the ego/personality if the ego accepts its
     responsibility for being the conscious director of energy that it
     was intended to be. The ego can build a bridge between the Dream
     self/higher-self, the Intuitive-self and the Astral self through
     learning to expand its attention and by working with Keylontic
     Science. As the ego begins to assimilate the other portions of the
     Reasoning Mind, the seeming barriers between the Dream self, Astral
     self, Soul Matrix and Body Consciousness will begin to dissolve.
     When fully assimilated the Reasoning Mind will have conscious
     multi-dimensional perception and the ability to direct the
     Subconscious and Instinctual Minds (and the physical body, emotions
     and intuition that manifest through the "lower minds") through
     conscious interaction with the Superconscious Mind of the Soul
     Matrix. The Reasoning Mind is primarily associated with the
     frequency bands of D-3, the logical-rational mental awareness, the
     third DNA strand, the third Solar Plexus Chakra and the Mental Body
     (third level out from the physical body) level of the bio-energetic
     field.

IV. The Superconscious Mind: The Group Soul Matrix (Note: the second
    triadic identity of the multi-dimensional identity structure, exists
    within the D-4 through D-6 frequency bands of HU-2). Key Function:
    Creation of experiential templates and individual identities in
    HU-1. Serves as the creative intelligence behind the manifestation
    of individuated identities and experiential events in HU-1. The
    superconscious Mind/Soul Matrix is composed of Partiki units and
    Keylons. It exists as a minute crystalline blueprint within and
    surrounding the matter body in HU-1 and HU-2 and serves as the
    creative intelligence behind and within sets of 12 physical
    bodies/identities/incarnates that exist in different space-time
    locations within HU-1. The Soul Matrix is composed of dimensional
    frequency bands 4-6 and it holds the templates for biological
    manifestation, life purpose and experiential dramas within the lower
    dimensional fields of HU-1. The Superconscious Mind of the Soul
    Matrix replicates itself through electromagnetic fission then
    fragments the replica of its consciousness into sets of 12
    individuated identities that become singular biological
    incarnational identities, which are simultaneously placed within the
    space-time fields of HU-1. Each of the 12 identities in an HU-1 set
    or "soul family" are directly connected to each other and to the
    original Superconscious Mind through the Morphogenetic Keylontic
    structure of the Soul Matrix. The Soul Matrix holds the
    developmental evolutionary blueprint and memory for each of its HU-1
    incarnates and serves to guide the HU-1 incarnational personalities
    to their highest evolution through information communicated via
    electrical impulses sent into the HU-1 body through the Instinctual
    Mind. Within the Soul Matrix the memory of the purposes and
    intentions for each individual HU-1 life is stored as well as the
    memory of the greater purposes and intentions for the set of 12
    simultaneous incarnations. Each HU-1 incarnate has free will and can
    choose to override the impulses sent to it by the Soul Matrix, but
    the highest evolution and greatest fulfillment of the incarnate
    comes from following the directives of the Superconscious Mind. The
    Superconscious Mind represents the creative and organizational
    component of mind through which the individuated identity is imbued
    with purpose, intention, motivation and the literal life-force
    energy through which the HU-1 body is sustained. Embodiment of the
    Soul Matrix through the evolutionary process of Soul Integration
    allows the lower dimensional components of mind to fully assimilate
    into an advanced state of consciousness through which the identity
    recognizes the plural nature of its simultaneous existence in
    various dimensions and space-time locations. The Soul Matrix
    identity manifests as a singular, less-dense matter body within the
    frequency fields of HU-2 and experiences its HU-1 incarnates as
    Cellular Memory of its smaller, simultaneous manifestations that
    exist in HU-1. The incarnate identity was designed to expand back
    into the Soul Matrix identity following death or transmutation of
    the HU-1 physical body. The Soul Matrix and Superconscious Mind
    connect the HU-1 incarnates and the HU-2 Soul Body to the higher
    dimensional levels of identity and to the original Geomantic Entity
    Gestalt that exists eternally beyond dimensionalization. The Soul
    Matrix---Superconscious Mind connects directly to the Over-soul
    Matrix Causal Mind of HU-3 (dimensions 7, 8 and 9). The
    Superconscious Mind represents the portion of your personal identity
    that holds the awareness of "who I was before I came here" and why
    you, as a consciousness, chose your particular incarnation. It is
    connected to the astral identity, the group Incarnational Soul and
    also to the race mind, species mind and planetary consciousness, as
    well as to the mind networks of you and your incarnational selves
    that exist within parallel universe systems. It represents the
    collective consciousness of your Archetypal identity that knows
    itself as a singular-being-composed-of-many within the less- dense
    matter fields of Harmonic Universe--2. The Superconscious Mind
    contains the D-4 Astral Mind, the D-5 Archetypal Mind and the D-6
    Angelic (Celestial) Mind. The Superconscious Mind of the Soul Matrix
    is primarily associated with the frequency bands of D-4, D-5 and
    D-6, the Astral, the Archetypal and the Angelic awareness, DNA
    strands 4, 5 and 6, Chakras 4, 5 and 6 and the Astral (fourth level
    out from the physical body), Archetypal (fifth level out) and the
    Angelic (6th level out) levels of the bio-energetic field. Speaker:
    Valdmyrun Rhanthunkeana Matrix, Ranthia Transmittance Pattern
    2/26/1997 (update: 1/15/1999)

The Dream-time Self-Hypnosis Exercise

The Monitor Technique The following exercise is formatted for retrieval
of memory and information pertaining to phenomena related to experiences
of contact and/or abduction by ET or Other-dimensional (OD) Visitors.
The format can be adjusted to reflect other areas of interest by
substituting the desired area of exploration for the "target" questions
during the exercise. Choosing a Target Prior to using this exercise you
are to decide upon a "target" that will organize the mental focus and
memory retrieval processes within the dream state. The target can be a
direct question (such as "Have I been involved with ET or OD Visitor
activity in this lifetime?" or "Are there any unusual events related to
UFOs in the past during this lifetime of which I should now be aware?").
If using a question as the target, it is best to use your own wording
and to be specific in what information you are asking to receive. (If
you are bilingual, phrase the question in the language that is native to
your childhood). Write the question down in a notebook and keep this,
with a writing instrument, next to your bed. You may use other targets,
such as feelings or event targets, either singly, or in combination with
the target question. If there is a period of time in your life from
which memory seems noticeably vague, periods in which you feel you may
have experienced "missing time" or events in which you remember having a
strange encounter or sighting, these also make good target events. (For
non-Visitor related format past areas of trauma, uneasiness or confusion
can be used as target events.) You will simply call the event or time
period to mind, becoming aware of the feelings or imagery associated
with it, then Lasso the image or sensation using mentally directed
imagery. In your "mind's eye" draw a circle of energy around the inner
image or sensation, leaving a "tail" of energy dangling from the
visualized circle. You may draw the image and the "Lasso" in your
notebook if you wish. A third way to decide upon a target is to ask your
body consciousness/Subconscious Mind directly for a body target within
the Cellular Memory. Recline in a relaxed position and take several
slow, deep breaths until you notice that your heart and breathing rates
are slowing slightly. Clear and still the mind. Mentally direct a
question to the body consciousness, realizing that you are literally
communicating with a portion of your identity that is aware within the
body cells. Ask the body if there is a particular area of memory being
held in Cellular Memory that would help you to locate the information
you seek. Ask it to direct your attention to a specific area of the body
in which that memory is stored, then still the mind again. Next place
your attention within the body and imagine that you are scanning its
energy signature from the inside out. Begin at the feet and slowly sweep
your attention upward through the body, becoming aware of the inner
structures of bone, tissue, organs etc. As you scan, notice any area
that gives you a different impression, sensation, image or feeling than
other areas. You may feel a slight tingling in the body target area, a
sense of heat or cold, or you may get mental imagery of color change or
a mental picture of the body area to which the Subconscious Mind is
guiding you for memory retrieval. Some people may receive a direct
language translation from the Subconscious Mind, in which a thought such
as "the left knee" may come to your awareness. If you focus your
attention clearly and keep your mind still you will receive some
indication from the Body Consciousness as to what area of the body holds
the memory in question. •Once you have the target body area, mentally
"Lasso" this area with a circle of energy within your mind's eye,
keeping the clear intention that you will retrieve the pertinent memory
within the dream state. You may also want to make a note of the body
target in your notebook.

Prior to Sleep You may choose your target at any time then keep your
notebook handy as you prepare for sleep. It is suggested to use this
exercise when you plan to get at least 4 full hours of sleep rather than
in shorter sleep periods. As you recline review the pre-selected target
notes in your notebook and focus your attention on the target. Holding
the target in mind begin to relax the body. Starting at the feet
visualize a white mist surrounding the feet. Imagine the mist moving
down and through the feet, touching all parts, both internally and
externally. Imagine a feeling of lightness spreading through the feet as
the mist gently flows over, through and into the cells of the feet. Move
your attention and the mist slowly up the legs, stopping over and
concentrating the mist in areas until the sensation of lightness is
felt.  As you move past an area on the body imagine that this area of
the body has become invisible as the mist moves away from it, as if you
are "rolling the body up" from the feet upward---as you might do with a
sleeping bag. Continue to move the mist upward until you reach the head
area, creating the feeling of lightness or "not-there-ness" in all body
parts. (If you fall asleep before finishing this visualization, simply
practice again during the next sleep period, telling your body and
Subconscious Mind that you will remain consciously aware throughout the
exercise and once you have entered the dream state. With practice of
these self-hypnotic commands, you will train your consciousness to
follow these instructions.) Once the visualized mist has reached your
head imagine that it is pulling together, concentrating into a small
pin-point of light directly over your forehead near the brow area (6th
Chakra). Hold the image of the pin-point of light in your mind's eye for
a few moments until you can see it clearly. You will now mentally "name"
the pin-point of white light, it will be called "Monitor." Monitor
represents the concentrated focus of your awareness and you will take it
with you into the dream state. (It may take several attempts before you
are able to remain awake this far into the exercise, but do not become
discouraged. Continue to use the visualization until you have trained
your consciousness to hold the focus. Success will come with consistent
repetition. Three days "on"--- two days "off" is a good format to use in
training your consciousness to hold such a focus.) Give yourself the
mental command of "Monitor On." This will send a subliminal message to
the 4 Components of Mind that you are intending to be consciously aware
and operable within the dream state. After giving the "Monitor On"
command you will next visualize a circle of blue light surrounding the
pin-point of white light. This step is important as it is programming
your consciousness to align with the Soul Matrix in the sleep state. The
"circle" represents a Keylontic Symbol Code that will allow your
consciousness to pass through the chaotic confusion of the Instinctual
Mind and into the Soul Matrix via the Dream self. (The color of blue
represents a frequency of light that translates into sound patterns of
the fifth dimension, where the center of the Soul Matrix is stationed.
Using this frequency in visualization will harmonically align your
consciousness with the consciousness of your Archetypal Mind.) This
Symbol Code will assist the Reasoning Mind of your Dream self and the
Reasoning Mind of your waking focus that you are bringing into the
dream, to merge successfully in the dream state. It will further direct
the unified Reasoning Mind into the Supraconscious Mind of the Soul
Matrix. As you relax with the image of the white pin-point of light
"Monitor" within the blue circle Symbol Code, call to mind the target
you have previously "lassoed." Imagine the contents of the lasso, the
target you have previously placed within its boundaries and try to sense
the energy signature of the contents. There will be a "feel" to the
contents of the lasso, which represents the Keylon Code morphogenetic
energy identity of the thoughts, images, emotions and sensations
contained within the lasso. Next, color the "Lasso" Symbol Code yellow
gold. This will program the subliminal suggestion that the
intellectual/Reasoning Mind will be operable within the dream and will
serve to organize the dream information for retrieval by the waking
consciousness. Mentally take the dangling "tail" of the golden lasso and
connect it to the Monitor pin-point of white light. Visualize the
Monitor pulling the Lasso into its center until all that remains is a
tiny golden speck of light at the center of the white pin-point of
light. Now give the mental command "Monitor Retrieve." Continue to
visualize the blue circle surrounding the white point of light with the
gold speck of light at its center, as you fall asleep. Become aware of
your breathing rhythm and with each inhale begin to move the Symbol Code
inward toward the center of your brain (the pineal gland specifically).
With each exhale imagine the Symbol Code expanding outward to encompass
your head (and body if you still find yourself being aware of the body's
position). Contract the Symbol Code into your brain with each inhale and
expand it outward to encompass your head and body with each exhale,
synchronizing this visualization with your breathing rhythm. (This
allows the subliminal Symbol Code to become programmed into the Cellular
Memory.) Take 4 to 6 breaths then stop at the final inhale, positioning
the symbol at the center of your brain.  Next, visualize a small version
of yourself "riding" at the center of the Symbol Code, as if you are
driving the Symbol as a vehicle that will carry you into the dream state
(you are and it will...). As the driver, give the mental command
"Monitor Retrieve." Keeping the image of the Symbol Code in mind and
simultaneously feeling yourself within it, begin spinning the Symbol
Code counter- clockwise. (Imagine the front of your body as the face of
a clock with the digit-12 position at the top of the head and the
digit-3 position to the left---to spin the Symbol counter-clockwise spin
it toward the right where the digit-9 position would be). Trace the spin
in your mind while visualizing the Symbol image and repeating the mental
command "Monitor Retrieve," as you fall off to sleep.

As You Awaken As you awaken you will train your mind to remember the
Symbol Code as you come into the consciously "awake" state. First try to
recall the Symbol, even before focusing your attention on any dream
material that may be present. The Symbol will serve to organize recall
into patterns pertinent to information that you seek. Keep your eyes
closed and allow yourself to awaken slowly and try to observe the levels
of consciousness that you pass through as you slowly emerge from the
sleep state. Bring the Symbol into focus in your mind as soon as you are
able. Once you see the Symbol, clearly give the command "Monitor
Retrieve." Repeat the command several times in your mind then focus your
attention on your breathing rhythm. With each inhale imagine that you
can feel the energy of the dream material pulling up from the depths of
the dream world, collecting within the center of the Symbol. Continue to
"breathe" the energy up into the Symbol for as long as you feel the
stream of energy flowing. You will reach a point when you feel this
stream of energy depleting, growing fainter, until you can no longer
feel the movement of this stream of energy. (It may take a few sessions
before you can sense the beginning of this stream of energy, but it will
be there.) When you sense the end of the energy stream take 3 more
natural breaths as the energy "settles" into the Symbol Code. Your
Symbol Code is now "loaded" with electrically encoded data from the
other Components of Mind as derived through the dream state.  Moving
your body slowly, pick up your notebook and writing instrument, then
recline with these in hand and close your eyes again. Focus on your
breathing again and give the command "Monitor Retrieve." Allow the
energy contained within the Symbol to expand into your body and
awareness with your breathing rhythm, expanding the energy with each
exhale. This process "downloads" the digital data from the Symbol Code
into the Cellular Memory, following the organizational instructions of
the Symbol Code. Keeping your mind calm and focused on the exercise will
allow images, thoughts and emotional impressions from your dream
experience to emerge within your mind. (With practice they will). Give
yourself the mental command to "Record" as the dream impressions emerge
from the Symbol into your mind and allow the images or feelings to flow
without being interrupted by other thoughts or body movement. At times
the emotional imprint will come first and if you will allow it to flow
it will lead to dream imagery. At some point the flow of sensations and
images will stop and you will sense a "settling" of the energy. This
indicates that you have processed the body of dream material that you
retrieved from the sleep state. Moving slowly and remaining focused and
relaxed, open your eyes and write down the dream impressions and any
commentary that comes to mind. Do not worry about sequence or content in
the early weeks of using this exercise, but rather focus upon training
your consciousness to use this memory retrieval format. The sequence,
content and meaning of the dream impressions will become clearer as your
Subconscious Mind internalizes the new Keylonta Code program.

Applications and Indications The "Monitor Technique" is a good place to
begin in exploring and utilizing the inner contours of your
consciousness. It will take practice to remember the steps of this
exercise and practice is needed for the subliminal Keylonta Symbol Code
organizational program to "take" within the Keylontic crystalline
blueprint of the Subconscious Mind. After 3 days of practicing the
entire exercise use only the Symbol Code image and the command "Monitor
Retrieve" prior to sleep for the next 2 days. Begin the entire exercise
again on the third day and continue the "3-day long version---2-day
short version" format for 4--6 weeks. Following 6--8 weeks of
consecutive training, you should be able to use only the
target/mist/"Monitor Retrieve" command/Symbol Code image portions of the
exercise to create the same results as the entire long version of the
exercise, as the program will then operate on a subconscious level.
After this time you should observe a noticeable difference in your dream
content and recall, and you should be able to easily elicit from the
dream state answers to pre-set questions. When using this exercise to
discover whether or not you have Visitor contact or abduction related
memories it is best to phrase the target question in a way that can be
answered in a "yes-or-no" format. The first target question could be "Is
there Visitor contact related material stored within the Cellular Memory
of this lifetime?" Using such a simplified target it should take no
longer than 3 to 4 days to retrieve an answer as to whether Visitor
involvement should be a subject for further exercises. Once you become
familiar with the technique you should be able to retrieve specific and
detailed information regarding your target question. This technique can
be used for problem solving and to generate new creative material, as
well as to retrieve memories. Individuals who are not generally prone to
dream recall should find more dream memory surfacing into consciousness
with practice of this exercise. At first the recall may appear
fragmented. In using this exercise with a positive attitude you should
see results similar to those experienced by people with avid dream
recall, but it may just take more practice. We might add that people who
believe they "do not dream" or who have no dream recall, may harbor
hidden beliefs about dreaming that operate as subliminal suggestions
serving to block the recollection of dreams. Dreaming is a natural and
intrinsic part of human consciousness at your present stage of evolution
and some recall should be apparent, even if it is sporadic. If no dream
recall is experienced you may be holding the hidden idea that dreams are
insignificant and thus not worthy of attention. Or you may feel that
dreams represent a frightening and chaotic portion of your psyche and
you may avoid recall because it threatens your sense of personal
control. In either case such ideas will suppress your memory of natural
dream activity. You do dream, so it is not a matter of having no dreams,
but rather that you inadvertently block them by ideas that you hold. In
such cases it is helpful to examine your ideas about dreaming and
perhaps change your ideas to reflect the new understanding that dreams
are a safe and natural way to gain practical and pertinent information.
Dreams are not chaotic and they do possess a natural associative
organization. Dreams will appear disorganized to the consciousness that
is not yet skilled in sequential retrieval. As with any other learned
activity, skill level improves with education and practice. People
inclined to dream recall may see rapid results from this exercise.
Frequent episodes of Lucid Dreaming or Projection of Consciousness from
the dream state may begin to occur. You may gain more clarity and
sequential consistency in dream recall and you may find yourself aware
of Simultaneous Dreaming, in which you "catch yourself" participating in
several dream dramas at the same time. As the Keylonta Symbol Code
organizational program is established within the Subconscious Mind you
may awaken with the answers to your target question simply "appearing
within your mind" in a form of direct cognition. You may also find
yourself experiencing "reading dream" or "movie dream" recall. In these
experiences the data that has been subconsciously programmed into the
Symbol Code reveals itself to you as you begin to awaken, appearing
within the inner vision as "text written upon a page," which you can
literally read for content. For more visually orientated individuals
images, still pictures or "running movies" may appear, rather than
written text. The "text" or "movie" dream impressions indicate that the
Symbol Code program has effectively "taken" within the Subconscious
Mind, the "Monitor Retrieve" command works on a subliminal level
automatically and the dreams are translated into a format most familiar
to your waking consciousness. When you reach this level of dream
retrieval, do not worry about focusing upon the Symbol Code as you
awaken. Keep your eyes closed, your body still and allow the text or
imagery to flow through your mind. Concentrate on the material as it
runs through your mind, intending to remember the content as clearly as
possible. When the data stops running, slowly open your eyes and record
what you remember in your notebook. If you open your eyes or move the
body too quickly you may "lose" the flow of data. Data retrieval from
the Subconscious Mind and dream state is most clear when consciousness
makes a slow, subtle transition from the Subconscious Mind into waking
awareness. With practice you can become accustomed to being awake and
aware while your consciousness is stationed within the frequency bands
of the Subconscious Mind. You can then train your consciousness to make
a slow "climb" into waking awareness. Mastery of this skill will imprint
the Reasoning Mind with new neuro-passageways that will allow you to
enter into the Cellular Memory at will for conscious retrieval of data.
Such advanced skills require practice in becoming aware of and directing
the focus of your consciousness. Exercises such as the Monitor
Technique, as well as various forms of meditation, creative
visualization and projection of consciousness can help you to develop
skill in consciously directing your consciousness through the various
Components of Mind. These skills are the beginning stages of mastery of
the conscious focus within the dream state and the entry point to a
"whole new world" of multi-dimensional frontiers to explore. Dream
realities will eventually lead you to multi-dimensional cognition and
mobility. Developing skill in maneuvering the contours of dream reality
will accelerate the process of unifying the Components of Mind and
Levels of Identity and expedite the process of Soul Integration.

The Keylonta Code Pre-Activation Exercise

The Induction Technique This exercise utilizes the direct induction of
primary Keylonta Symbol Codes into areas of the body and bio-energetic
field. Induction of these organic Keylon Codes will serve to reorganize
the existing crystalline blueprint Keylon Code structures within the
body cells and bio-energetic field into arrangements more conducive to
mental, emotional and physical balance and frequency harmonization and
integration between the various Components of Mind and Levels of
Identity. The Keylon Codes work subliminally to affect the Components of
Mind by creating harmony of vibratory oscillation rates between the
energy units and particles that compose the various levels of multi-
dimensional identity. The Pre-activation Keylonta Symbol Codes do not
add or delete from the existing Keylon Code organizations of the
morphogenetic body---they simply arrange existing codes into more
effective patterns. In using this exercise as indicated an overall
improvement of mental, emotional, physical and spiritual balance should
become apparent, as well as improvement in centering and directing
personal energy. Balancing of the existing Keylontic structure of the
body prepares the physical body and the embodied consciousness to
receive more higher frequency energy/identity/awareness/information from
the Soul Matrix and accelerates the process of Soul Integration. The
Induction Technique is to be done from a waking state of consciousness,
not in association with sleep. Following the completion of the exercise
it is useful to relax for 10-15 minutes and if you fall asleep during
this period it will not detract from the effectiveness of the exercise.

Things You Will Need A. The Keylonta Symbol Code Placement Chart. B.
Four Keylontic Symbol Codes, pre-selected from the Keylontic Symbol Code
Placement Chart. C. A small bottle of fragrant "essence oil", such as
the kind used in Aroma-Therapy. If you do not have essence oil you may
use any type of baby oil or body lotion, but we recommend essence oil as
the fragrance is concentrated and more easily affects the mind and body
on subliminal levels. D. A private, quiet setting in which you can
comfortably recline undisturbed for 20-30 minutes. Subdued lighting is
recommended but not required. A soothing musical "relaxation type"
recording with a slow tempo and no words can assist if outside noise is
a problem, but natural silence is preferable whenever possible. The
Exercise Begin the exercise by removing any tight clothing. (For greater
comfort we recommend removing all clothing during the exercise.) Place
the Keylonta Symbol Code Placement Chart and the essence oil within easy
reach then recline on your back on a comfortable surface. Calm your mind
and let all thoughts drift away from your attention. Focus on the rhythm
of your breathing for a few moments and consciously slow the breathing
rate until the body is relaxed. Give the command "Body relaxed and
receptive now" to the body consciousness/ Subconscious Mind. This can be
done mentally, but it is more effective if it is audibly whispered so
that you can hear the command objectively as well as internally. Repeat
the command slowly 3 times without interruption. Using the essence oil
place a small "dot" of oil from your finger tip onto each of the body
areas marked 1--5 on the Keylonta Symbol Code Placement Chart. Then,
with the Symbol Code Chart in view, trace 1 of the 4 selected Symbol
Codes over each body area marked 6-- 9, using a small amount of essence
oil on your finger tip. (Chart positions 6--9 correspond with Chakra
centers 2, 3, 4 and 6.)When you have finished tracing the Symbol Codes
onto the body recline and close your eyes, allowing the aroma of the oil
to expand around you. (If you are breathing too fast and are not fully
relaxed it will be more difficult to feel the sensation of the aroma
"spreading." By slowing your breathing and concentrating on the aroma
you will deepen your state of relaxation.) Focus again on your breathing
rhythm and glance at the image of the first Symbol Code that you traced
on position #6. Focus your attention on this position on the body and
begin to visualize the Symbol Code spinning clockwise, in a circular
motion over the body area (imagine the front of your body as the face of
a clock with the digit-12 at the head, the digit-3 at the left, etc.
Spin the Symbol Code toward the left for clockwise rotation.) As you
mentally spin the Symbol Code imagine that it is slowly moving inward,
through the skin and into an imagined center line of energy that runs
vertically through the center of your body matter. (This energy current
exists, it can be viewed with higher sensory perception and is
frequently called the "Main Vertical Current.") Move the spinning Symbol
Code into this center-line of energy in synchronization with your
breathing rhythm. Move the Symbol Code inward as you inhale, then as you
exhale, stop the Symbol Code movement at whatever level you sense it to
be, and resume moving the Symbol Code with the next inhale. Repeat the
inhale-movement/exhale- stop sequence until you sense that the Symbol
Code is positioned within your body directly in the middle of the
internal center line, beneath the Chakra on which you traced the Symbol
Code. Once the Symbol Code is positioned within the internal center-
line, breathe 4-6 breaths, feeling the energy of the Symbol Code expand
until it feels about the size of a grapefruit, still within the same
area of the body/Chakra center upon which the Symbol Code was traced. If
you are sensitive to subtle energies you will feel a "stopping
sensation" as the Symbol Code has reached full expansion within the
Chakra. Continue to pay attention to your breathing and as you inhale
imagine that you are collecting energy into your body. At full inhale
pause for 5- 7 seconds, then exhale in one smooth flow of air. As you
exhale, imagine that the Symbol Code within the internal center-line is
expanding as you "fill it with air and energy" by imagining the breath
of your exhale moving into and filling the Symbol Code. Stop the
expansion movement at the end of the exhale, pause, inhale, then again
exhale and expand the Symbol Code. Repeat this exhale-Symbol Code
expansion sequence until you have expanded the Symbol Code outward
beyond the perimeters of your body. Feel the energy of the expanded
Symbol Code surrounding you like a large "bubble." Sensitives will
notice a stopping sensation as the Symbol Code "bubble" reaches its
natural point of expansion within the level of the bio- energetic field
that corresponds to the Chakra into which the Symbol Code was induced.
This sensation indicates that the Symbol Code has been successfully
programmed into the Keylontic crystalline blueprint for that Chakra and
the DNA strand, body systems, level of consciousness and bio- energetic
field level that correspond to that Chakra. Complete the Symbol Code
induction process, as described above, for the 3 remaining Symbol Codes,
over placement positions numbers 7,8, and 9 on the Keylonta Symbol Code
Placement chart. When the last Symbol Code has been successfully
induced, take several slow, deep breaths and clear your mind as
completely as possible. Now imagine a current of gold colored energy
running from the top of your head through the internal center-line of
the body, out the soles of both feet and into the ground. Breathe the
current of energy upward with each inhale and downward with each exhale
for several minutes while holding this visualization in mind. Complete
the exercise by giving the command "Body at rest, program completed",
repeating the command 3 times. The Induction Technique exercise need
only be implemented once for the Keylontic Symbol Code realignments to
begin within the crystalline blueprint of the morphogenetic Keylon body.
However, the exercise must be completed in one sequence with no
interruption, for the program to work effectively. If you are disturbed
or fall asleep during the exercise, start from the beginning again at
another time. Following the successful completion of the exercise it is
helpful to allow 10--15 minutes of rest or sleep before becoming active.
It is also helpful to drink several glasses of pure water during the 2
days that follow completion of this exercise. The process of Keylontic
Symbol Code Induction is an application of Keylontic Science. The
exercise provided is a rudimentary demonstration of this technology in
motion. Once you become familiar with the process of Bio-energetic
Keylontic Symbol Code Induction you can learn more advanced levels of
application through which the DNA and various levels of the body and
consciousness can be literally programmed for higher performance. In
other books we will explore the construction of the 12-strand DNA
package---the Silicate Matrix gene code. Once the overlay structure of
the DNA is understood, Keylontic Symbol Code Induction can be used to
activate dormant Keylonta Codes and repair and replace missing Codes
within the DNA in order to expedite healing and accelerate personal
evolution through the process of Soul Integration. Many of you already
understand the validity of mental energy dynamics and realize that your
waking mind is the literal director of energetic substances on numerous
levels of experience. For you these exercises will be easy and you will
sense the significance of their processes. More of your populations,
however, possess little or no comprehension of the validity of mental
energy dynamics. Exercises such as those presented in this book may
appear "silly" or irrelevant to a consciousness unfamiliar with the
inner workings and structures of mind/ matter/space/time. Let us remind
you that in using these techniques you are employing advanced energy
programming modalities that represent operational applications of
Keylontic Morphogenetic Science. Keylontic Science is the most advanced
school of scientific thought presently available on Earth. Keylonta is
the only contemporary science that takes into account the natural
structures of 15-dimensional physics and addresses the mechanics of the
Morphogenetic Fields that exist beneath and within all observable
creations. Using applications of Keylontic Science may seem foreign to
you because you have had little experience in dealing consciously and
directly within a multi-dimensional framework. Like all humans, the
skeptics among you also possess a crystalline Keylontic Body upon which
the manifest biology and identity are built and a Dream self that
represents a more conscious aspect of the Reasoning Mind. Your Dream
self is a portion of your consciousness that has access to the Keylontic
Morphogenetic Body and to greater amounts of information, and it can
synthesize much more complex data at a faster rate than your Reasoning
Mind is able to do from the "waking" perspective. Your Dream self knows
well the Science of Keylonta and the language of the Keylontic Symbol
Codes and it is a master of mental energy dynamics and projection of
consciousness. To the skeptics, who might laugh at and dismiss mind
technologies such as those demonstrated within these Keylontic
exercises, might we suggest that you consider that there is a portion of
your own awareness with which you are unfamiliar, which holds
information that you need to function more effectively within your
waking state of consciousness. That information waits within the domain
of the Keylontic Body and the Dream self, but only you can command it to
appear. Your Dream self will be your best ally if you apply yourself to
developing this relationship, and Keylontic Morphogenetic Science will
be your greatest tool in directing and accelerating the process of your
evolution. If these exercises are approached with a negative or
skeptical attitude such as "prove it to me," you are operating out of a
belief that the dynamics of the exercises are false. Just as in the case
of dream recall, your ideas about the subject will serve to enable or
block the process. A skeptical attitude will translate on a subconscious
level into a subliminal command that orders the biological suppression
of the experiences and memory that would reveal to you the true validity
of these dynamics. For this reason we suggest using these exercises only
after you have cultivated an open attitude and sincere curiosity, for
with an open attitude you are far more likely to achieve the results
that will allow you to prove to yourself the realities of which we
speak. The coming period of 2012-2017 marks a time of physical and
bio-energetic changes on Earth that are unprecedented in recorded human
history. Developing skills in technologies of mind and applied Keylontic
Morphogenetic Science will assist you to create adaptability of body and
consciousness. We hope that you will enjoy the exercises we have
provided in this book and that you will use them to your own advantage,
to further accelerate your Soul Integration process. Through Soul
Integration your race will take its next evolutionary step toward
biological and spiritual maturity, to one day emerge within the realms
of pure knowing and At-one-ment with the eternal creative Source. 
Speaker: Valdmyrun Rhanthunkeana Matrix Ranthia Transmittance Pattern
2/26/1997 (update: 1/15/1999)