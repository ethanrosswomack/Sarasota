What Others Are Saying About Voyagers I...

           “The X Files is nothing compared to this book. It fell into my

lap at the perfect moment, when I was discovering a subconscious part of
me that had experienced alien abductions since a young child. Up until
the year 2000 I had denied such things were possible. "Now my life,
especially my nights, were filled with a penetrating fear, not knowing
if tonight would involve another unwelcome visit. "This book brought
back the light into these night terrors, where I now understand the
mystery and know how to deal with frequency fences (illusions of
reality) that are projected into my mind. "If you believe/know you are
part of this mysterious adventure, this is the survival book to claim
back your power and face your fears!" --- A transfixed reader  Voyagers

                  The Sleeping Abductees

                        Volume I
             of the Emerald Covenant CDT-Plate
                        Translations

                              Ashayana Deane,
                     (formerly published as Anna Hayes)

                Published by Wild Flower Press, an imprint of
                 Granite Publishing L.L.C., at Smashwords

                           First Smashwords Edition

             Information Transcribed from the Guardian Alliance
           regarding Extraterrestrial Visitation, the Extraterrestrial
                               Agendas,
                     Keylontic Morphogenetic Science,
                 and the Mechanics of Alien Contact.
         These transcriptions are not derived from channeled sources.

                             Wild Flower Press
                     Copyright 2011 by Ashayana Deane
                            All rights reserved.

                    First Smashwords Edition License Notes
         This ebook is licensed for your personal enjoyment only. This

ebook may not be re-sold or given away to other people. If you would
like to share this book with another person, please purchase an
additional copy for each person you share it with. If you're reading
this book and did not purchase it, or it was not purchased for your use
only, then you should return to Smashwords.com and purchase your own
copy. Thank you for respecting the author's work.

                          The Voyagers series
                 Volume I, first Smashwords edition
                        Deane, Ashayana 1964
        Voyagers : the sleeping abductees / by Ashayana Deane
                         ISBN 0-926524-75-5
                       ISBN 978-0-926524-75-0

           Discover additional titles by Ashayana Deane at
                       Smashwords.com.
         This book is available in print at most online retailers.

      Cover Artwork and internal illustrations: Ashayana Deane
                     Cover design: Pamela Meyer
     Manuscript editors: Brian Crissey, Pamela Meyer, Julie Sherar
                      and Susan Westhoff

                        Address all inquiries to:
                    Wild Flower Press, an imprint of
                      Granite Publishing, L.L.C.
                        Post Office Box 1429,
                     Columbus, NC 28722 U.S.A.
                            828/894-8444

               Granite Publishing, L.L.C., is committed
                    to living lightly on the Earth.

                               Dedicated to
                              The Guardians
                        of all Races and Realities

                                  And to
                         The Guardian Alliance
                     for their patience and wisdom
                    and for the creation of this book.

In Recognition of the Eiyani Indigo Children, Past, Present and Future 
Table of Contents

Introduction All Things Considered---Otherworlds, Origins and Evidence
The Ordinary Extraordinary Otherworlds - Reevaluating the Past Blinded
by Scientific Interpretation Gods and Visitors Visitors and Human
Origins Origins, Science, Evidence and Interpretations Mysteries Missing
Evidence, Particle Transition and Time Hypothesis

Contact Intruders Guardians

The Azurite Temple of the Melchizedek Cloister, Inc.

About the Author

CDT-Plates, Emerald Covenant and the Mass Drama

Administrative Levels of the Emerald Order Melchizedek Cloister The
Yunasai Yanas Breneau Order Founders Races IAFW---Interdimensional
Association of Free Worlds Density-5 MC Eieyani Master Council  Azurite
Universal Templar Security Team GA-Guardian Alliance The Intruders The
Guardians