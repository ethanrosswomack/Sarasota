22 
 

                                                                                                           
                                                                                                           
                            The Electric Wars
 morphogenetic field, they would incarnate into elemental consciousness and
 evolve as second-dimensional life forms. They would be trapped in the ele-
 mental incarnations until the fourth-dimensional Seal of Palaidor was lifted
from the morphogenetic field. 
  The Palaidorian/Amenti morphogenetic field within the Sphere of
 Amenti represented the collective Soul Matrix for the human lineage on
Earth. Because of the Seal of Palaidor the races would emerge into Earth from
the morphogenetic field from D-4 instead of through Earth's D-2 core, they
would experience one incarnation, die and become part of the consciousness
         of Earth, losing their sentient identity. Meanwhile, the portion of their
 essence that had picked up the fourth-dimensional base tone frequencies
while passing through D-4 in birthing, would rise back into the lower fre-
quency bands of  D-4 at death. These fragments of identity became disembod-
ied astral consciousness without a body form or organizational identity
imprint. The Fifth Root Race Aeirans were able to retain form in the astral
identity as the D-4 frequencies were already contained within their fourth
DNA strand. Though the Aeirans could not plug the second, third and
fourth DNA strands into each other until the fourth strand had been fully
assembled, the identity pattern manifested itself within the second, third and
fourth dimensions, creating an emotional/elemental body in D-2, a mental
body in D-3 and an astral body in D-4. As the Aeiran race progressively
assembled its fourth DNA strand, unity between D-2 emotional awareness,
D-3 mental awareness and D-4 astral awareness would result, allowing the
consciousness to separate from the physical body and travel through the D-4
astral planes. Once all of the fourth strand was assembled and the ancestral
soul fragments integrated, the Seal of Palaidor would release in the Aeiran
genetic code, the emotional, mental and astral identities would merge, the
activation code overtones of the Fifth Cloister (the Hibiru) would plug in
and release the Seal of Amenti, allowing ascension through the Blue Flame
in the Sphere of Amenti to occur.  
   The Third and Fourth Root Races did not have an astral body as their
genetic imprint did not include the fourth/D-4 strand of DNA. Only mem-
bers of Races three and four who participated in inter-stellar breeding were
able to create the organizational form of an astral body in D-4 and splice in
the imprint for the fourth DNA strand. Members of these earlier races from
the Second and Third Seedings could not pass into their race's morphoge-
netic field at death, and thus they could not reincarnate into the Fifth Root
Race. At death their soul essence fragmented into the Uni fied Fields of