6           
                    
                    
                                                                                                                                                                                                                                                                                                            
                                                                                     

  
                     
                        Amenti Rescue Mission
Palaidorians.  W orking through the Breneau Rishi (beings of pure conscious-
ness) from HU-5, the Palaidorians petitioned further assistance from an entity 
gestalt within the Metagalactic Core; this entity is known as Ra, or the Ra
Confederacy.  Of the 12 primary identity gestalts within the Ra Confederacy ,
members of its four largest gestalts became involved and allowed for the rescue 
mission to take place. The four primary members of the Ra Confederacy 
involved within the Covenant of Palaidor are the Azurites, Aton-a, Amonites
and the Brigijhidett  (a sub-group of the Brigijhidett are presently incarnating 
in your Earth system as members of the ascended masters family of Viragi . Sev-
eral other groups associated with these three gestalts are also involved with 
Earth at this time, including the consciousness gestalt Azar-Azara  and a HU-2  
ET race known as the Zhar Confederacy ).                                                               
           Time Travel and the Sphere of Amenti
                                                                                  550,000,000 YA    pre-cataclysmic Tara
            Using lnterdimensional portal mechanics, the Ur-Tarranates of the Cov-  
           enant of Palaidor time-traveled into HU-1 to a time/space coordinate posi-    
       tioned just after the cataclysm of Tara and the fall of man. Once on Earth,      
          with the help of the Sirian Council, this group of Ur-T arranates transmuted
    their body forms into pure energy (Keylontic science) and merged into a     
   gestalt energy field of consciousness, which served as a morphogenetic field   
         or the 12-strand DNA Turaneusiam race prototype. Also contained within       
    this morphogenetic field were the Keylontic Time Codes (electrotonal fre- 
           quency patterns) of the pre-cataclysmic time/space coordinates of Tara,       
   which would allow T ara to re-assemble the lost portions of its grid into the   
  fabric of time. With the assistance of the Ra Confederacy this gestalt of con-
   sciousness/genetic and planetary morphogenetic field was entered into the 
       remaining morphogenetic field of Earth through the 11th and 14th dimen-   
      sions. This morphogenetic field of consciousness energetically took on the    
  shape of a sphere, and was called the Sphere of Amenti , named after the por-
  tion of T ara’ s morphogenetic field that contained the imprint for Mu and its
   inhabitants. Amenti was the part of Tara’s planetary core that connected 
                energetically to the portals upon the continent of Mu.   
            By placing the Sphere of Amenti within the Earth core, a “worm hole” or 
  portal link was established between Earth’ s core in dimension two and T ara's 
   core in dimension 5. Though numerous other portals between Earth and T ara 
    existed, these had become unstable and their operations unpredictable fol- 
     lowing the fall. The Sphere of Amenti would create a stable portal structure    
      that, once operational, would stabilize the other portals and allow open tran-              
       sit between Earth and T ara for beings possessing genetic codes that could