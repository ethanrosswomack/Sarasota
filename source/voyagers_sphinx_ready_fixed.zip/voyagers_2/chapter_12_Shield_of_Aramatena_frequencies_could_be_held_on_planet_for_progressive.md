12 Shield of Aramatena frequencies  could be held on planet  for progressive 
planetary grid repair , until Earth’s grids were repaired sufficiently to hold 
the natural, permanent D-12 Christos Realignment . Originally , all species 
on Earth  were seeded to serve as conduits of frequency  through which the 
Founders  D-12 Christos Realignment could be progressively fulfilled in the 
Earth-Tara-Gaia system.  The damage Earth’s grids incurred through the 
Taran cataclysm made Earth’s Templar Complex  unable to naturally with-
stand participation in a SAC . The Earth-Tara-Gaia system would have 
been a Phantom Planet system  (see page 166), if it had not been for the
Founders’ inplementation of the Angelic Human mission .  Humanity, and 
other species, were seeded on Earth to form a sustaining energetic template  
through  which progressive D-12 Christos Realignment and repair of
Earth’s Planetary Shields  could be rendered over several cycles  of the
 planet’s evolution within the Density-1 Time Cycle .  
     The design of the Cycle of the Rounds began with seeding of the Palaidia 
Urtite-Cloister Maji Races  and was then to continue with progressive 
emergence of races  that carried smaller portions  of the Maji’ s DNA  T em-
plate.  Each race with less sophisticated DNA Templates  served to bring in 
and hold in Earth’s Planetary Shields, specific cycles of  sub-frequency from 
the Shield of Aramatena, during points in the planetary Time Cycle when 
those specific sub-frequencies were needed to amplify and  “fill out the fre-
quencies”, in Earth’s Manifestation Template. In the Cycle of the Rounds 
design, races with greater  genetic sophistication serve to hold in Earth’s Plan-
etary Shields, the 12 Primary  Dimensional Templates of the Shield of Ara-
matena Christos Divine Blueprint.  Races with less genetic  sophistication 
serve to hold additional sub-harmonics of the 144 Secondary Dimensional
Sub-frequency Templates of the Christos Blueprint.  Once they were fully 
seeded and in position within various interrelated Time Cycles of Earth, Tara
and Gaia, the Angelic Human races were intended to hold and direct, within     
the Earth-Tara-Gaia Template, the greatest portions of the D-12 Shield of 
Aramatena Christos Blueprint frequency spectra.   
     The animal, plant,  insect and mineral kingdoms of Earth-Tara-Gaia were
 intended to hold the subharmonics of  the Christos Blueprint. Together , the 
 Angelic  Human  Races and   the  natural  kingdoms of  Earth-Tara-Gaia would
282 

                                                                                            
                                                                                         The Riddle of the “Roundtable’’
bring in and sustain the D-12 Christos Blueprint , progressively healing dis-
tortions in the Earth-Tara-Gaia Planetary Shields to fulfill the natural Chris-
tos Realignment of the Earth-Tara-Gaia systems. As each cycle of human 
race evolution entered  manifestation on Earth, more of the Christos Tem-
plate would be progressively anchored and  integrated into Earth’s Manifesta-
tion Template. When the Cycle of the Rounds was completed, and all 
portions of the 12-Tribes Angelic Human races were in position on planet, a 
final Stellar Activations Cycle  would allow the Angelic Human races to fully 
anchor the D -12 Planetary Christos  Blueprint in Earth’s Template. In com-
pletion of the Angelic Human Mission, the D-12  Maharic Shield of Aramat-
ena Planetary Christos Blueprint would be simultaneously  anchored in 
various interrelated Time Vectors and Time Cycles of Earth-Tara-Gaia. At 
this time, the Planetary Shields would fully realign to their natural D-12 
order, allowing the planet to self-sustain a permanent, natural D-12 Christos 
Alignment.   
    When the full frequency spectrum of the D-12 Shield of Aramatena  
Template Christos Blueprint  is anchored in Earth’s Template “at one time”, 
during a Stellar Activation Cycle when the natural planetary, galactic and 
universal Star Gates open, the Earth-Tara-Gaia Planetary Shields can hold 
the full D-12 Maharata Creation Current. Anchoring of the full D-12 spec-
trum of the Universal Maharata Current, or Pre-matter “Christos Current” 
(also sometimes referred to as the “Photon Belt” or “Holographic Beam”), 
would place the planet within its naturally intended Planetary Maharic Seal. 
    Manual stimulation  of the natural  Planetary Maharic  Seal in numerous 
 concurrent Time Cycles  will allow the planet to  regenerate  its natural ability
 to self-sustain a permanent D-12 Planetary Christos  Alignment.  Restoration 
of the planet’s natural Christos Alignment will  re-establish  the “Divine Right  
Order” of the planet’s original galactic position and Universal Time Cycle 
Alignment.  Under a planetary D-12 Maharic Seal, the four Densities of the 
Earth-Tara-Gaia system can fully re-connect to the Universal Manifestation
Template of our Time Matrix. Rehabilitation of the Earth-Tara-Gaia Plane-
tary Shields through the Christos Realignment will allow the four Densities 
    of the planetary system to re-connect to the Density-5 Kee-Ra-ShA  Primal 
    Light Fields and the Khundaray Primal Sound Fields beyond the Time  
    Matrix. Through this “Divine Connection”, the Planetary Shields of Earth- 
    T ara-Gaia can receive perpetual circulation  of the “Rainbow Ray” Primal 
                Creation Currents from Source. Once the natural Density-4, D-12 Planetary 
                Maharic Shield is restored on Earth, Density-3 Gaia, Density-2 Tara and 
   Density-1 Earth will be restored to the status of Ascension Planets  (see 
   Page 167), their inherent life-fields capable of attaining full Ascension  out of 
    the Time Matrix.   
       Until the Christos Realignment of Earth is completed, most of Earth’ s 
life-field is trapped in time within the finite experience of Density manifesta-
tion, unable to enjoy the Divinely Given Gift of self-motivated  Ascension
283 
                                                                                                                                                                                  

The Angelic Human Heritage and Rainbow Roundtables                            
 and its inherent perpetual renewal of Eternal Life and co-creative life experi-
ence. The Angelic Human lineage of Earth was seeded as an intrinsic part of 
a Divinely Intended  Mission of Planetary, Galactic and Universal Rehabilita-
tion.  This mission was highly organized, beautifully choreographed and 
intrinsically synchronized through the natural cycles of Time in our Time 
Matrix. Time  Cycles are repeating cycles of vibrational  variance inherent to 
the Primal Order of the Unified Field of consciousness and energy that IS our 
Time Matrix. Time Cycles govern the Primal Creation Mechanics, or the 
organic physics of manifestation, by which consciousness experiences the 
worlds of space-time-matter. The design of the Cycle of the Rounds, by
which humanity’s evolution on Earth serves the higher purpose of Universal 
Rehabilitation, is built upon the natural contours of Cycles of Universal 
Time. Each phase of humanity’s evolution on Earth, including contemporary 
human civilization,  is an  intrinsic and necessary part  of this greater Univer-
sal Rehabilitation and Restoration plan.   
FOUR EVOLUTIONARY ROUNDS, CO-RESONANT CONTINUUM 
ALIGNMENT, TRANS-TIME CONNECTION, AND THE CHRISTOS 
                                      REALIGNMENT MISSION  
     The five Urtite-Cloister Maji races that first seeded the Palaidia Empires
of 798,000 BC began the current Cycle of the Rounds  on Earth. The Urtite-
Cloister Mu’a, Yu, Ur, Breanoua and Rama races, each with their respective 
DNA Template Star Gate Correlations, are the seed races from which con-
temporary humanity emerged. Through this ancestral genetic affiliation , the 
humans of contemporary Earth  also hold the DNA  T emplate Star Gate
Correlations inherited through the particular Palaidia Empire race  from 
which their original genetic ancestry emerged. Though we have presently 
lost memory of our greater purpose  within the Planetary Christos Realign-
ment Mission , our current human races are as important as the Palaidia 
Empire races, in fulfillment of the Founders’ Planetary, Galactic and Univer-
sal Rehabilitation plan.   
  The Cycle of the Rounds , through which human evolution was
intended to bring about the Christos Realignment on Earth within a specific 
quadrant of time, is designed to occur in four phases, or four Rounds . The 
First Round  of Seeding-3  Human evolution took place with seeding of the
five 25-48 Strand DNA Template  Palaidia Urtite-Cloister Maji races  of 
the subterranean Palaidia Empires in 798,000 BC , and their subsequent 
emergence onto Earth’s surface between 750,000 BC and 500,000 BC . 
    The Second Round  took place as the five 12-24 Strand DNA Template
Urtite-Cloister Races  emerged in 206,000 BC  from the five Palaidia Urtite-
Cloister Maji races into the 12 Urtite-Cloister Palaidia Empires, and spread 
across Earth’s surface  into areas to which their DNA  T emplates corre-
sponded. The races of Human Evolution Rounds 1 and 2  carried the 12      
284                                                                                                                  
    

                                                                                                  
                                                         Four Evolutionary Rounds, Co-Resonant Continuum...
Universal Master Key Codes  and 144 Universal Encryption Key Codes
of the 12 Universal Star Gates within their DNA Templates ; they anchored
the 12 Primary Dimensional Templates of the D-12 Shield of Aramatena  
within Earth’s Planetary Shields. The Second Round was delayed from its 
originally intended schedule due to warring with Fallen Angelic races  and a 
resulting planetary cataclysm in 208,216 BC . The Third Round  of Angelic
Human evolution took place in 73,000 BC  as the five 7-12 + 1 Strand 
DNA Template  Cloister Races  emerged through the five Urtite-Cloister 
races, carrying sub-harmonics of the specific DNA Template Star Gate Cor-
relations characteristic to the specific Urtite-Cloister Race from which they 
emerged. The Fourth Round  of Angelic Human evolution began shortly        
thereafter, as the five Root Races  with  2-6 Strand + dormant 12-Strand          
DNA Templates  began their progressive emergence into human incarnation in 
71,000 BC , through their corresponding Cloister  race of the five Cloister    
Races  (see page 15).         
    Each of the four Rounds of the Human Evolutionary Blueprint is  
designed to bring into Earth’s Planetary Shields during specific Time Vectors 
a designated portion of the D-12 Shield of Aramatena Christos Template. If 
the Cycle of the Rounds had proceeded without progressive Fallen Angelic
interference, the four Rounds of the Angelic Human lineage would have fully
anchored the D-12 Shield of Aramatena and completed the Christos 
Realignment Mission on Earth long ago. The Fourth Round  of Angelic  
Human evolution is still in progress  from a present-day earthly stand-point , 
as two of the five Root Races  and one of the five Cloister Races  have not
yet entered their birthing cycles on contemporary Earth. In truth, these  
“not yet manifested” Fourth-Round Angelic Human race strains already
exist and are evolving  within higher frequency Density-2 Time Vectors  of 
Earth, that represent a “ future time ” Time Cycle of Density-2  Tara  in rela-
tion to the position of races in contemporary 21st Century Density-1  Earth.   
In the same fashion, the evolutionary Rounds of the Palaidia Urtite-Clois-
ter, Urtite-Cloister, Cloister  and “ earlier ” Root Races  are also occurring
concurrently  with contemporary human evolution, in both higher and 
   lower-frequency Density-1 Time Vectors  of Earth.   
       The design of the Cycle of the Rounds Angelic Human  Evolutionary 
Blueprint re ﬂects the reality of physics  upon which space-time-matter mani-
festation is built ; time is simultaneous . Time Cycles  represent repeating 
cycles of vibrational variance ensconced  within the energetic platform of 
the Unified Field  of consciousness and energy that is the medium within 
which all manifest creation takes place. The repeating cycles of vibrational
variance that form Time Cycles and their inherent smaller Time Vector
cycles , provide coherent sequences of linear vibrational rhythms for con-
sciousness to follow  in order to engage the manifest experience of linear pas-
sage and evolution through time.    
285 
                                                                                                                    
                                                                                                        

 
      The Angelic Human Heritage and Rainbow Roundtables                            
       The Cycle of the Rounds Human Evolution- Christos Realignment Mis-
sion is being fulfilled through the Four Rounds  of Angelic Human Races,
the collective carriers  of the  D-12 Shield of Aramatena  Christos Divine 
Blueprint, being simultaneously seeded in various Time Vectors  of the Earth-
Tara-Gaia Universal Time Cycle .  Through this concurrent, simultaneous
seeding of the Four Rounds, portions of the Christos Blueprint  are simulta-
neously entered  by their designated races , into the four Densities  of the 
Planetary Shields , in their appropriate Time Cycle and energetic coordinate
 of corresponding vibrational co-resonance .  
     The seemingly complex inter-dimensional, inter-time reality of human 
evolutionary design  can be simply understood by viewing each of the four 
Rounds of Angelic Human Seeding-3 as taking place right now , in space-
time vectors connected to but different from  our Earth’s contemporary Time 
Vector. In our Time Vector, Earth has begun the 2000-2017 Stellar Activa-
tions Cycle (SAC) , through which the Earth’s Templar and Star Gates will 
activate.  Activation of Earth’s Templar in the present SAC is progressively
creating a temporary blending of Time Vectors  between the past, present 
and future Time Vectors in which the other Rounds  of the Christos Realign-
ment are concurrently taking place.   
     If contemporary humanity fulfills its intended role as part of the
 Christos Realignment Mission T eam,  by consciously anchoring our portion
of the D-12 Shield of Aramatena Christos Field in our Time Vector, the suc-
cess of the Christos Realignment can be finally achieved. If we do our part, 
we will create a link through time , energetically connecting our present 
Time Vector  to the past and future Time Vectors  in which the other evolu-
tionary Rounds are being successfully orchestrated .  
     Through this Trans-time Connection , our  present Time Vector  will 
“phase-lock”, or lock into alignment with, the probable future Time Vector  
and its corresponding past Time Vectors , in which the Christos Realign-
ment, the Emerald Covenant Lyran-Sirian cultural model and humanity’s 
successful evolution into 12-Strand Angelic Human freedom  are already
manifest . Through doing our part now, we will choose from the present , the 
desired probable future  (from our present standpoint) our race will see man-
ifest. In choosing from the present, the path of an enlightened future and 
“Destiny of Joy” , we will simultaneously re-align our present Time Vector 
with a  more desirable set of past Time Vectors , in which undesirable past 
events will lose their power and in ﬂuence within our experientially manifest 
present and future.  
    In the realities of the Mechanics of Manifestation , the “ point of power 
is always in the present ”. Past and future Time Vectors extend out from 
every present moment point  as a series of electromagnetic “rays”, or inter-
connected, cyclic patterns of linear progression with varying rhythms of 
vibrational oscillation .  A Time Cycle, and its inherent Time Continua and
smaller Time Vectors are all fixed, repeating cycles of frequency character-
286 
                                                                         
 
 
                                                                                                                            

                                                                  
                                  Four Evolutionary Rounds, Co-Resonant Continuum
  ized  by vibrational variance , that cross through each other  at fixed points 
when the frequency rhythms that define each cycle reach a temporary state of 
vibrational co-resonance  (hold the same vibration). Our present moment 
point  emerges as one small point  of vibration-oscillation rhythm within the
greater rhythm  of the Time V ector, Continuum and Cycle within which it is
placed. When our planet enters a point in its fixed linear Time Vector at 
which other Time Vectors cross through our Time Vector, via temporary 
vibrational co-resonance , we have the  power to literally shift our present 
Time Vector  alignment into an alternate linear Time Vecto r with a different
future “ event horizon ”.  
     If our present moment point exists as part of a linear Time Vector cycle in
which undesirable “past” events , serving as the “cause”, have their recipro-
cal “effect” manifestation in an undesirable “future” event horizon , we can 
change our direction from the present by changing our present vibrational 
rhythm.  The present moment  is the “ Cause ”; the past  (lower frequency 
projection) and future  (higher  frequency projection) are the “ effects”  that 
extend backward and forward in time (simultaneously  emerge into lower 
and higher frequency projection) from the frequency pattern and vibrational
 rhythm that defines the present moment point.   
    From the present moment we CAN change the influence of the past , as
well as re-define the future. The past is not changed by negating memory  of 
its reality or by invalidating its apparent manifest existence . The “past”, pro-
jected from one present frequency pattern, must be acknowledged and incor-
porated as part of the present frequency pattern (“past” brought into the
present moment of power). Once the remembered and evidential past  is 
incorporated into the present moment , the entire frequency pattern in the
present  needs to be altered into vibrational co-resonance  with the frequency 
pattern of the desired future manifestation.   
    There are many complex elements to mastering the skill of projecting
desired outcomes into our personal experiential future. Though each individ-
ual does possess the inherent power to create desired manifest experience , 
this personal power  is always tempered and directly influenced  by the larger 
frequency-field  of  the Collective Consciousness. In like fashion, the mani-
festation powers  of both the personal and collective consciousness  are 
directly regulated and influenced by the frequency-field of the Planetary 
Time Continuum  within which personal and collective reality take place.
The frequency field that constitutes the Planetary Time Continuum  is cre-
ated by numerous concurrent Time Vectors and the collective consciousness  
of all manifest kingdoms, from the elemental, plant and animal  kingdoms , to
the human evolutionary collectives , that exist within each Time Vector.  It is 
due to these greater hidden influences  of  the Planetary Time Continuum , 
which operate through the collective sub-conscious  and DNA Templates  of 
incarnate species, that our individual efforts  to achieve precise results in 
287 
                                                                                                              
 
                                                                                                             

The Angelic Human Heritage and Rainbow Roundtables                            
direct manifestation  of desired events often fall short  of our conscious 
expectations.  
    Shifting a present-moment  Time Vector  into a different Time Contin-
uum  that has a more desirable future outcome  than that of the Time Con-
tinuum of which our present Time Vector is a part,  can be achieved from the 
present. But such a Time Continuum shift  can be accomplished only within 
the natural mechanics of physics  that govern the interdependant dynamics
of race, planetary, galactic and universal Time Cycles . One cannot simply 
choose to shift to a different Time Continuum at any moment-point in time ; 
Time Continuum shifts can be made only in present-moment points within
 which other Time Continua interface  with the present-moment Time V ec-
tor through vibrational co-resonance . 
    This principle of “ Co-resonant Continuum Alignment”  applies to the 
smaller time cycles that govern evolution of an individual through one life-
time, and also to the larger Planetary Time Cycles  that govern a planet’ s 
evolution through the Density Levels of our 15-Dimensional Time Matrix. 
Stellar Activations Cycles  (SACs) are points of planetary , galactic and uni-
versal “ Co-resonant Continuum Alignment ” during  which the divergent 
frequency rhythms characteristic to various planetary, galactic and universal 
Time Continua temporarily come into a state of vibrational co-resonance 
(simultaneously reach the same vibration-oscillation rhythm).  
    Points of temporary vibrational co-resonance that naturally occur 
between various Time Continua allow the usually separated Time Continua  
of various systems to cross through and open into each other . Star Gates
represent the geographical and spatial coordinates  at which the vibrational 
co-resonance of multiple Time Continua regularly occurs in fixed, repeating 
cycles  of Co-resonant Continuum Alignment.  At points in a Time Contin-
uum where Co-resonant Vibrational Alignments occur, natural  Star Gates 
open  in the spatial coordinates  that mark the points of vibrational co-reso-
nance  or continuum cross-through.  Star Gates remain open until the vibra-
tional rhythms of the various interfacing Time Continua at the Star Gate
points begin to cycle out of vibrational co-resonance , shifting  the various 
Time Continua out of Co-resonant Continuum Alignment.  Star Gate 
close  as the various Time Continua  move past their vibrationally co-reso-
nant “cross-over” points , and return to their respective fixed, repeating
cycles of vibrational variance. SACs are the periods in linear time when
planetary, galactic and universal Time Continua enter temporary Co-reso-
nant Continuum Alignment; only during SACs can a planetary body be 
shifted from its present Time Vector into a Time Continuum that holds a
 more desirable future outcome.  
    If contemporary humanity can fulfill its intended Fourth Round role  
within the Christos Realignment Mission  during the 2000-2017 SAC , we 
will be able to establish a literal, inter-dimensional electromagnetic Trans-
Time Connection  from our present period, to the SACs taking place in 
288 
                                                                                                                                                       

                          Four Evolutionary Rounds, Co-Resonant Continuum ...
other periods of past and future. In fulfilling our Divinely Intended Mission 
in the present, we will  link Earth’s present Time Vector  to those of SAC’s 
past and future during which the Angelic Human races of the other three 
Evolutionary Rounds  are also fulfilling their Divine Mission of anchoring 
the D-12 Shield of Aramatena Christos Blueprint.  In this way we will put 
Earth’s present Time Vector “on line”  with the probable (to us) future  in 
which the Christos Realignment has successfully occurred.  
    Through aligning Earth’ s present Time V ector with future Time Contin-
uum cycles in which the Christos Realignment is successful, we can shift 
our present planetary Time Vector out of its current probable future of Fallen 
Angelic- Illuminati Human dominion. We can literally realign the event
horizon  upon which our present is moving into the future with the Time Continuum 
event horizon in which our probable future of Freedom and Joy is manifest. The 
concept of Time Shift is simple, but the dynamics of interdimensional physics by 
which a Planetary Time Continuum Shift can tangibly occur are extremely complex ; far 
beyond the sophistication of present earthly science. Though the physics of Planetary 
Time Shift are complex, the methods by which humanity can fulfill its intended 
Fourth Round role in anchoring the frequencies of the D-12 Shield of Aramatena 
Christos Divine Blueprint are, thankfully, relatively simple . The methods by which 
humanity can fulfill its intended Sacred Mission can be found within the Secrets of the
Tribal Shield Rainbow Roundtables.     
        
                            
                                                                 Key   to   Following    Diagram:
The Angelic Human Race was created as the Security Team  for the
Templar Complex Star Gate System  in our Time Matrix. The DNA  
Templates of each Race Line carry portions of the DNA Signet
Codes , or Fire Letter Sequences,  that correspond to the 12 Primary 
Star Gates  on the Regional, Planetary, Galactic  and Universal  Lev-
els. The DNA Signet Codes are “ Flame Codes ,” denoting the spe-
cific primary frequency spectra  of the three Primal Creation  
Currents (Blue-Eckatic, Gold-Polaric, Violet-Triadic) carried in 
the DNA Template.     
       
289

                                                   
                                            
                                                                       The “Cycle of the Rounds”
                                    THE “CYCLE OF THE ROUNDS”           
     The four Interrelated Evolutionary Cycles of 12-Tribes Seeding-3
                                       EVOLUTIONARY ROUNDS  
    • The Seeding-3 12-Tribes Angelic Human Races were seeded on Earth in
         four different interconnected Time Cycles . Each of the four Time Cycle s
        in which the Angelic Human races were seeded represents an evolution-
        ary Race Cycle  or an “Evolutionary Round”  in the “Cycle of the 
            Rounds” Angelic Human  Evolutionary Blueprint.  
  • Each of the four Rounds  in the Angelic Human “Cycle of the Rounds” is
          commissioned to “Anchor” a specific set of interdimensional frequencies
         into Earth’ s scalar-standing-wave Manifestation T emplate, Earth’ s Plane-
          tary Shields , within each of the specific Time Cycles  in which the Angelic
               Human Evolutionary “Round Cycles” are placed. Each Evolutionary
         Round is intended to serve a part in fulfilling humanity’s Divine Commis-
          sion, the Sacred Mission of Planetary Guardianship  for which Angelic
            Humans were seeded on Earth.                                                                                FIRE LETTER SEQUENCES  
  • The Angelic Human and Maji Cloister Races of each Evolutionary Round
      anchor frequency into Earth’ s Planetary Shields through the scalar-stand-
      ing-wave structures that are an inherent part of the personal DNA Tem-
       plate Core. The DNA Templates of the Angelic Human Races within
       each Evolutionary Round Cycle are built upon specific  scalar-standing
         wave Light-Sound patterns called Fire Letter Sequences.   
    • The Manifestation Templates  of all things and systems are built upon spe-
      cific, fixed organizations of dimensionalized frequency bands . Each di-
        mensional band has 12 Fire Letters, or fixed points of consolidated
       frequency; each dimensional band  represents 1 Fire Letter Sequence or