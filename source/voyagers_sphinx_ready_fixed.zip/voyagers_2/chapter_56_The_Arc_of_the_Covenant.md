56 
 
 

                                                                                   
                                                                              The Arc of the Covenant
of life. The Anunnaki who had joined the Sirian Council through the Treaty
of El-Annu, and the Sirian-Kantarians and Sirian-Blue races of Sirius B,
became a primary motivating force within Atlantean culture, and the Pleia-
dian races of HU-1 assisted in the development of Ur-Antrian and Lemurian
culture. These cultures thrived under the influence of the advanced stellar
races. The Annu-Melchizedeks organized their cultures around the spiritual
and scientific teachings of the Law of One. Members of the Hibiru Cloister
and the hybrid Hebrew peoples migrated from other regions to both Atlantis
and Lemuria, each bringing with them the teachings of the Law of One char-
acteristic of the Melchizedek Host Matrix.  
    As civilization on Earth prospered, the Sirian Council allowed the
Atlantean and Lemurian cultures to receive gifts from the advanced stellar
races, which rapidly developed the technological aspects of society to heights
far exceeding present earthly cultures. The Sirian-Blues of Sirius B brought
large crystalline power generators to Earth as a gift to the Atlantean and
Lemurian cultures. They taught the Ur-Antrians, Lemurians, Annu and
Atlanteans how to draw energy directly from the D-2 Earth core, and store
this energy within the crystal generators. Permission was granted by the Elo-
him and Ra Confederacy to allow power to be drawn from the Blue Flame of
Amenti through the passageway of the Arc of the Covenant. The power of the
Blue Flame allowed Atlantean civilization to access multidimensional frequency,
through which the morphogenetic ﬁelds of Earth's matter particles could be directly
affected . Earth's gravitational pull could be neutralized, objects could be man-
ifested and de-manifested, objects could be teleported to desired locations,
bio-energetic healing became a way of life and genetic evolution was acceler-
ated. Using the power of ET technology the Atlantean and Lemurian cul-
tures thrived.  
    The Annu and Hebrew peoples of the Melchizedek Cloister Host Matrix
became the primary Earth guardians of the Arc of the Covenant. The original por-
tal passage to the Arc of the Covenant was located within the land mass of
the Atlantean continent, and through this interstellar passageway power was
fed through the Earth's grid to the Lemurian continent and various other
developing civilizations. Earth civilizations thrived following the Law of One
until about 55,000 years ago, when members of the Anunnaki Resistance
began to in filtrate Atlantean culture, creating genetic and social digression
that nearly brought Atlantis to an end.