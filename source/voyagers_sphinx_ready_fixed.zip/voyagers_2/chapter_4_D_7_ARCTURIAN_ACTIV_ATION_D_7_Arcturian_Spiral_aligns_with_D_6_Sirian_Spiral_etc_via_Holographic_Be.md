4  D-7 ARCTURIAN ACTIV ATION:  D-7 Arcturian Spiral aligns with D-6 Sirian Spiral etc via Holographic Beam
           DATE : 5/5/2017 - 6/30/2017 day 1 -2017 TARAN ACTIVATI ON
        EARTH VORTEX OPENS:  V ortex # 7 - Andes Mountains, South America - 1/2012 - 6/2017
         SILVER WAVE INFUSION:  day 1 -2017  D-8 BT & D-9 OT frequencies enter Earth's Core
    DNA:  strand # 7 assembles strands 5, 6 & 7 activate, Silver Sta r crystal activates for 3 days
    EARTH ACCRETION LEVEL : 5 to 6 HUMAN ACCRETION LEVEL : 6 to 7
    (Earth, Tara and Gala align with Holographic Beam Ascensions to Gaia)                              _________________________________________________________