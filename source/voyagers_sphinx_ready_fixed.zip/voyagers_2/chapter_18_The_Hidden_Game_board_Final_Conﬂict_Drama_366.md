18 The Hidden Game-board Final Conﬂict Drama .....................................366
             APIN Systems; The Falcon, the Andromies and the Dove 1943-1951 .......366
               The Lion, the “Lamb,” the Sphinx and the Eagle ...................................367
        The White Eagle and the Melchizedek Deception .................................. .370
         The Sacred Cow, Faces of Man, Easter Island Heads & Trion Field... .371
         The Falcon, Phoenix Project and
                the Andromie-Rigelian Coalition 1951-1983 .................................. .374
         Andromie-Rigelian Coalition, Dragon, bin Laden,
                and the “War on Terrorism” 1980-2001 ........................................... .376
        Montauk Project, “War in the Heavens,” Sonic Pulse
                and “Un-Natural Disasters” 1983 ............................. ......................... .378   
  vi                                                                                                                                                  
                                                                             
                     
          
                                                                                         
This PDF sold to Ethan Womack - dudeinwrens@gmail.com  Transaction: 7960

                                                                                         
                                                                                         
                                                                                                                               
                                                                                                  Table of Contents
            Guardian Intervention and the Bridge Zone Project 1983-1992 ........... .379
            The Pleiadian-Sirian Agreements and Hurricane Andrew 1992 ........... .380
            Temporary Cap on the Montauk Phi-Ex Wormhole 1994-1998 ............382
            Anunnaki Defection, Falcon Un-Capped, Indigo Hunting          
               and Edict of War 1998-2001 ....................................................................... .384
.