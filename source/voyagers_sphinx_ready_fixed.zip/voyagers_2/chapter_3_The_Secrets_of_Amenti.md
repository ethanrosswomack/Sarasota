3 
                                                                                                                      

                      
                                                                                                                        
                                                                                                                                                                                                                                                          
                        
                      
                    
                The Secrets of Amenti       
     tiates became sympathetic with the Sirian root race Anunnaki in their Sirian 
     rebellion against the Sirian Council and refused to follow dictates of the Sir-    
     ian Council and advisory Elohim (who based their decisions on the teachings     
     of the Sacred Law of One). Through the Templar Solar Initiates the power 
     struggle between Sirian Anunnaki and Elohim/Sirian Council-loyal Sirian    
     “blues” (another Sirian root race) was brought to Tara. This period in Ala-     
      nian history is known as the Sirian Rebellion, and through this power strug-   
        gle planet Tara was almost destroyed.  
                                                        Ur-Tarranates, Mu and the Priesthood of Ur
                                                                          550,750,000 - 550,000,000 YA
     Certain groups of Alanians became aware that the T emplar Solar Ini-                  
tiates were misusing power in a way that would result in the implosion of     
Tara’s planetary grid. This group of Alanians approached the Lumians and     
Ceres of Mu, asking for assistance and many of them defected to the territo-      
ries of Mu. The Ceres interbred with these Alanians, (primarily those carry-       
ing the Yutaran Turaneusiam sub-race genetic line) re-aligning their       
digressing genetic code, and these Alanians further interbred with the Lumi-      
ans. The original Turaneusiam 12-strand DNA gene code was rebuilt and   
purified through this Ceres-Lumian-Alanian blend. This re-vitalized Turane-    
usiam race became known as the Ur-Tarranates . The Ur-Tarranates created 
the Temple and Priesthood of Ur  upon the continent of Mu. The Priesthood   
of Ur shared most practices of the Priests of Mu, but developed interest in
more scientific applications of Spiritual Law (such as portal mechanics). Like
the Priesthood of Mu, the Priests of Ur exist on Tara to this day, and they  
serve as Guardians and gatekeepers of the time portal structures that link 
Earth to present day Tara.  
               During the Sirian Rebellion on T ara the Priesthood of Ur stood against
          the Templar Solar Initiates of Alania, eventually retreating underground 
             with the people of Mu, unable to stop the Templars from misusing the power  
           of the planetary core. Small wars within the local galactic sectors were fought
           during these times, which became known as the Taran Wars. Under direction     
              of the Sirian Council and Elohim, the Priests of Ur began to prepare for the   
           pending grid implosion. Many people were evacuated to other sympathetic   
               star systems, where they evolved, safely intermingling with other races.