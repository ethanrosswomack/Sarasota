45 
                                                                                                                                                                    

                 The Second Seeding
     
the cataclysm of Tara. The Anunnaki added their own sexist slant to these
teachings, so women would be viewed as subservient to men and therefore able
to be used as breeders of hybrid children. This teaching was a tactic used to
socially dis-empower women so they would have little support to reject the sex-
ual advances of the Anunnaki males. The Anunnaki created teachings that
made them appear to be the Gods of the human race, and through these teach-
ings were easily able to manipulate the Atlanian cultures into cooperative sub-
mission.  
     The Anunnaki proceeded to bring forth a race of human-Atlanian-
Anunnaki children who were called the Nephilim,  who entered the Earth
system about 950,000 years ago. Having more developed genetic codes via
their Anunnaki fathers, the Nephilim quickly dominated the less developed
humans, creating a highly advanced materialistic culture built upon exploita-
tion of less evolved life forms. Many genetic experiments were carried out,
creating varieties of animal-humans, terribly distorting the human genetic
imprint. Lamanian culture was not affected as greatly by the Anunnaki infil-
tration, as many members of this race retreated into the underground, becom-
ing involved with the Priests of Mu who guarded the portals of the Inner
Earth. (The Taran Priests of Mu commissioned many of their immortal mem-
bers as guardians of the Inner Earth since the beginning of the Turaneusiam-2
experiment). Around this time, 950,000 years ago, the Elohim and Ra Con-
federacy orchestrated massive Host Matrix Transplants, removing the dis-
torted Nephilim racial strains from their connection to the Amenti
morphogenetic field and “splicing them in” to the morphogenetic fields of
other entities from HU-3, HU-4 and HU-5.  
      The transplants were conducted in order to prevent the human morpho-
genetic field from becoming contaminated by the Anunnaki and Drakon
genetic lines, which would have taken human evolution in a completely dif-
ferent direction. In order to orchestrate the transplants certain frequency pat-
terns within the DNA were dismantled, but left within the cells
(contemporary “junk DNA”) so the souls involved could eventually “plug in”
the frequency codes and re-evolve into the Amenti morphogenetic field,
once their code distortions were corrected. The humans involved in the
transplants, who were already genetically altered by the Seals of Amenti and
Palaidor, now had even more genetic distortion to repair, but without the
transplants they would never have ful filled the human evolutionary imprint
to ascend.  
     During the Second Seeding the Elohim motivated the HU-2 Seres race
(descendants of the HU-2 Ceres) to assist in realigning the genetic imprint of
the earthly race strains, and the Seres energetically interbred with certain
members of the Atlanian and Ayrian races, creating a superior guardian race
called the Serres,  who later became known as the Egyptians.  The Egyptians
 were originally one of the seven sub-races within the Atlanian Root Race.