13  

   
    The Secrets of Amenti  
   each of those areas. Meanwhile, the other planets would process the dimen-
 sional frequency patterns that T ara could not synthesize. Once a HU-1 planet
 pulled in its portion of the higher dimensional frequencies, it would then
 undergo dimensional ascension back into T ara's grid, bringing with it its por-
 tion of the T aran morphogenetic field. Tara could not ascend to HU-3 and
 become Gaia until each of its HU-1 planets completed the manifestation of
 their portion of the morphogenetic field and ascended back into the Taran
 grid. (The time when this will occur is many millions of years in your future).
 But each planet in your solar system has its part to play in this program.
       Each planet received its portion of the T aran morphogenetic field. Earth
 received its portion 25 million years ago when the Halls of Amenti were con-
  structed.² The five Cloistered Races of the Sphere of Amenti retrieved their
  frequency pattern 25 million years ago. This pattern of energy/morphoge-
 netic field had the appearance of a standing wave pattern, composed of
 fourth- and fifth-dimensional frequencies, and thus appearing as blue in color.
 Visually , this standing wave pattern looks like an electric-blue ﬂame with a
 pale shade of green, several inches in height. The blue ﬂame, which consti-
 tutes Earth's portion of T ara's morphogenetic field, was brought into the
 Sphere of Amenti by the five Cloistered Races and the Priesthoods of Ur and
 Mu. The fifth-dimensional frequency patterns held in the blue ﬂame allowed
 for the Halls of Amenti to open so the seeding and evolution of the five
 remaining Root Races could begin on Earth. The ﬂame was stored within the
  Sphere of Amenti and as long as it was there the portals between Earth's
       dimensional time periods and T ara remained opened. The souls of Earth
  could ascend out of HU-1 incarnational cycles and continue their evolution
  through Tara.  
        The Blue Flame became known as the Staff of Amenti  which is the item
   referred to in your Bible as the Staff of God, of the “rod and the staff.” The rod
  represents the standing wave pattern within Earth's core in dimension 2,
  orange-gold in color, and composed of the frequency patterns of dimensions 1,
   2 and 3. The Blue Flame Staff of Amenti was composed of frequency patterns
   of dimensions 4, 5 and 6, and allowed T ara's morphogenetic field to link with
   the double ﬂame at Gaia's core, the violet and pale-gold ﬂames that would
         allow   Gaia   to    link  with   the   white-gold     ﬂame   of      the   Metagalactic   core. When     we
      speak of the colored ﬂames we are referring to multiple bands of frequency of which
                 morphogenetic ﬁelds are composed. Colors represent spectra of light and light repre-
                    
                      _________________________
                        2.    The other planets had undergone a similar Sphere and Halls creation at various other
                                      times, each set being named after the portion of the morphogenetic field it carried.