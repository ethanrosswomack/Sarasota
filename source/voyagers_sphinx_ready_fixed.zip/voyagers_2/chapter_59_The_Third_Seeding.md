59 
                                                                                                                                                                                                
   

The Third Seeding  
declined under their influence. Motivated by the Anunnaki Resistance, the
Templar-Annu began to dominate the races of Atlantean culture, and made
plans to conquer the lands of the Inner Earth. They planned to use the gener-
ator crystals to break through the electromagnetic barrier which protected
the portals of the Inner Earth.  
    Concerned for the welfare of the Inner Earth civilizations, and the high
concentration of Annu-Melchizedeks residing there, the Anunnaki of the
Sirian Council petitioned the Interdimensional Association of Free Worlds
for permission to make a show of strength on Earth, offering the races protec-
tion against increasing Anunnaki Resistance infiltration. Permission was
granted and the Sirian-Arcturian Coalition for Interplanetary Defense was
called in to assist in this protective mission. The primary target for Anunnaki
Resistance manipulation was the area in which the  Arc of the Covenant  was
located, so Egypt became the focus of Sirian Council activity. Anunnaki of the
Sirian Council were first sent to the planet Mars to recreate an observational
outpost that had been constructed there during the Thousand Years’ War,
which they hoped would intimidate the Anunnaki Resistance from further
interference with Earth. Undaunted by the presence of the Sirian Council,
the Anunnaki Resistance escalated their involvement with Atlantis and
began a resurgence of their in ﬂuence in Egypt, posing a greater threat to the
security of the Arc of the Covenant.  
    About 48,500 years ago the Sirian Council instructed their Anunnaki
members to make a direct show of power in Egypt and Atlantis. Anunnaki of
the Sirian Council visited these civilizations en masse , reasserting the inﬂu-
ence of the Law of One and driving many Templar-Annu out of Egypt and
back to Atlantis, where they would pose less threat to the Arc of the Cove-
nant. In Egypt, and in several other locations on the globe, the portals of the
Inner Earth were fortified as the Sirian Council Anunnaki built bases of oper-
ation on the Earth's surface, directly over the portal regions. The pyramid
structure was a trademark of Anunnaki architecture and scientific achieve-
ment, and several small pyramid structures were constructed above portal
passage areas throughout Egypt. The greatest of these operations bases was
constructed over the main Egyptian portal opening to the Inner Earth,
through which the Arc of the Covenant portal could be accessed. At the
same time another massive structure was constructed over the nearby portal
of the Arc of the Covenant.  
          The ﬁrst monument to be created was the original Sphinx. This building cov-
ered the portal to the Inner Earth and linked directly into the portal passage
that led to the Arc of the Covenant. The Sphinx was designed following
Anunnaki heritage, having the head of an Anunnaki warrior placed upon the
body of a lion-like sculpture. The lion's body of the Sphinx was a symbolic
tribute to a race of beings from HU-2 known as the Leonines, who were
instrumental in laying the early foundations of Anunnaki culture. The Leo-