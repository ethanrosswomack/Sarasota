28 
    
 
                         

                                                                                                                             
                                                                                                                          Melchizedek Races
members of this hybrid race, known as the Europherites (sometimes called the
Euries,) migrated from the HU-1 Pleiadian star system to Sirius B, interbred
with the Kantarian race to strengthen the human and Sirian imprint in their
genetic code, forming a smaller hybrid race called the Dagos.  Through the
Dagos, Kantarian and HU-1 Pleiadian lineage became intertwined with the
original Turaneusiam-2 imprint during the Second Seeding. The Dagos were a
dark brown skinned race whose genetic imprint would be carried as a recessive
gene within the human strain of the Second Seeding. The Dagos were brought
to Earth to set up small colonies in various locations about 3,995,750 years ago.
Reseeding of the Cloistered and Root Races of Amenti began, starting with the
Ur-Antrian Cloister 3,700,000 years ago, followed by Root Race 3, three mil-
lion years ago. Root Race 3, the Lumarians, became the Lamanians,  denoting
their passage through Sirius B. The Fourth Root Race and its Cloister entered
next, the Breanoua Cloister, about three million years ago, followed by the
Alanian Root Race 4 at 2,500,000 years ago. The Alanians became known as
the Atlanians. The Fifth Root Race Aeirans and their Cloister Hibiru then
entered, the Hibiru 1,500,000 and the Ayrians 1,275,000 years ago. The time
period beginning with the Second Seeding 3,700,000 years ago and extending
through the Third Seeding into the present time represents the Fourth World
of Native American legend.                                                                                                                                     MELCHIZEDEK RACES  
      
     DNA Strands and the Races, the Sixth Root Race, the Melchizedeks  
                    and Hibiru Cloister Mix, Agartha and the Essenes,  
                                          Hebrews, and Christians  
    The Fifth Root Race Aeirans, now known as the Ayrians, were responsible
for assembling the fourth DNA strand, which corresponded to the fourth-
dimensional frequencies, and through them the Earth grid would raise in vibra-
tional rate so the Sphere of Amenti could be returned to the Earth core. As
they ful filled the assembly of the fourth strand the Seal of Palaidor would be
lifted allowing the soul fragments from D-2 and D-4 to merge with fifth race
consciousness and evolve, and the soul essences of races 3 and 4, who waited
within the Sphere of Amenti to reincarnate into the fifth race could be set free.
The Ayrians contained within their DNA strands number 1, 2, 3 and the base
codes of 4, their Hibiru Cloister containing these plus the imprint for assembly
of strands 7-12. Both Ayrian and Hibiru races have two strands of DNA (dou-
ble helix) manifest within their bodies on Earth and two strands manifest
within their anti-particle doubles on parallel Earth. The Fourth Root Race
Alanians, now the Atlanians,  had three-strand DNA, strands one and two and
the base codes of 3, their Breanoua Cloister having these plus the imprint for
7-12. Atlanians and Breanoua would each manifest 1.5 strands within their