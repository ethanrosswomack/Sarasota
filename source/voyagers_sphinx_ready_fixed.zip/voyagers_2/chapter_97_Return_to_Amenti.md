97 
                                                                                                                             
                                                                                                                                                                                                                          
 

Return to Amenti  
Melchizedek families by combining the previous teachings of the
Melchizedek Priesthood with the evolving doctrines of the patriarchal and
purist Melchizedeks.  
    The original Melchizedek Priesthood, as it exists today , was founded on
surface-Earth in 1982 BC, prior to Akhenaton’s reign, within the Hibiru Clois-
ter race in the area of Salem, which became Jerusalem. An ET Nephilim (an
immortal Sirian-human hybrid from the Second Seeding period) was brought
to Earth from Nibiru in 1979 BC, carrying a patriarchal version of the Templar
Creed, which allowed knowledge of ascension and genetic protection to reach
the Hibiru and Aryan races. This individual became known as Melchizedek,
King of  Salem . The foundations for the modern day Jewish religion were laid at
this time with the establishment of the Priesthood of Melchizedek among the
Hebrew, Hibiru and Aryan races, through which the mystical studies of the
original Kabbalah were organized. In 196 BC some success was achieved in
consolidating the Templar teachings by combining the old Templar-
Melchizedek doctrine with those of the Blue Flame Melchizedek Essenes and
the Templar-Melchizedek Essenes. Despite this achievement, two primary,
covert divisions within the Essene brotherhood remained. The Melchizedeks
and Hebrew Essenes who were under the in ﬂuence of the patriarchal Elohim
were known as the Templar-Melchizedeks.  They were primarily descendants
of the Hebrew-Melchizedeks who had received the Templar Seal in 8,000 BC,
and whose morphogenetic field still remained in Alcyone, not yet reintegrated
into the Sphere of Amenti. This group emphasized the patriarchal slant of the
Templar creed within the Jewish faith and heavily in ﬂuenced the evolution of
the Christian faiths. The Templar-Melchizedek Essenes were taught by the
Elohim to believe that they were God’s chosen people and that they held the
key to ascension. The covert group of Cloister Melchizedeks within the Essene
brotherhood, who worked secretly with the Priests of Ur under the Azurite
Council, were primarily descendants of the Blue Flame Pure-Cloister Family
Melchizedeks. The Blue Flame Melchizedeks had not received the Templar
Seal in 8,000 BC, and their morphogenetic field remained in the Sphere of
Amenti. Protection of the Arc of the Covenant and the secrets of Amenti had
been placed with the Blue Flame Melchizedek Essenes by the Azurite Council.
The Blue Flame Melchizedeks taught the original, non-patriarchal, egalitarian
creed of the undistorted Templar Creed, including the sacred teachings of the
science of ascension, the reality of reincarnation and ET ancestry and the pre-
cepts of unity consciousness and the Sacred Law of One. The two groups co-
existed with each other within the Essene brotherhood until 12 BC, when the
Azurite Council orchestrated the next major event in preparing the races for
ascension.