61 
                                                                                                                         
                                                                                                                              

The Third Seeding
such.  The  primary purpose of the Great Pyramid of Giza was to fortify the portal of
the Arc of the Covenant and to serve as an interdimensional teleportation center.  
    The original pyramid was designed as a Harmonic Resonance Chamber,
through which multidimensional frequency bands could be pulled in from deep
space and from the planetary core of Sirius B, using a great ankh positioned
directly below a crystalline cap stone. Through the power of the ankh a tre-
mendous amount of UHF energy was pulled into focus within the cap stone of
the pyramid, then projected downward through the structure into the second-
dimensional frequency bands. The pyramid and Arc of the Covenant were situated
upon Earth's geographical center point, within the energy vortex that represented the
“Heart Chakra" within Earth's planetary bio-energetic system . This vortex allowed
energy exchange to take place between Earth and the fourth-dimensional fre-
quency bands. By creating a Harmonic Resonance Chamber within such an
interdimensional vortex, the D-2 overtones of HU-1 could be combined with
the base tones of D-4/HU-2, forming an interdimensional resonant tone
through which visiting craft traveling from Sirius B and other star systems
could enter and leap through time, making transit to Earth almost instanta-
neous. The Great Pyramid was created to allow immediate intervention of the
Sirian Council and Galactic Federation ﬂeets should the Arc of the Covenant
come under Anunnaki Resistance attack. While the pyramid was in operation
as an interstellar teleport station, it served as the greatest deterrent to an
Anunnaki Resistance invasion. The Great Pyramid was used as an active inter-
stellar teleport station from the time of its construction 48,459 years ago to
about 30,000 years ago (about 28,000 BC) when an explosion in Atlantis
caused Earth to tilt slightly on its axis, knocking the pyramid's D-4 vortex
(Earth's heart chakra) out of its previous alignment with the vortex systems of
Sirius B and several other planetary systems to which it had been originally
aligned. ET visitation was commonplace in Egypt prior to this mis-alignment of
the Earth's grid, but following this event, transit from other star systems
required more time and resources, so visitation became much less frequent.  
    Throughout the height of its operation (46,459 BC-28,000 BC) the
Great Pyramid of Giza was also used as an ascension chamber for the select
few who possessed the required DNA assembly and favor of the Elohim. Such
individuals were allowed passage through the Arc of the Covenant if the Elo-
him approved and opened the passageway, and some were able to ascend to
Tara. The pyramid was used as a training school for initiates to the
Melchizedek/Elohim ascension program, and also for healing, accelerating
genetic assembly and for passage into the Inner Earth portals beneath the
Sphinx. The pyramid was always kept under tight security by the resident
Anunnaki of the Sirian Council, and the Templar-Annu were banned from
entering the premises. This created much hostility between the Templar-
Annu and the Egyptian cultures operating under the protection of the Sirian