12 Maharic Shield for further sequential expedition of Strand T emplate
       Activation.  
5.Melchizedek Cloister Level-3 Regent Ordination: Transmission of the Kee-
      Ra-ShA  Primal Light and Khundaray Primal Sound Field “ Rainbow Ray
     Current ” directly into the personal  DNA  Template  via direct Chakra
      Induction . Sufficient Rainbow Ray frequencies to provide a level-3 Re-
         gent Ordination can be transmitted by a Melchizedek Cloister level-5  El-
          der Consummate or Level-6 Eckar  Indigo Child-Type-1 Maji Grail Line
      Angelic Humans, who have the frequencies of the Primal Creation Cur-
      rents integrated into their DNA  T emplate from birth. Expedites all of the
        above while  providing additional bio-energetic field support  for more
             stable cycles  of DNA Template activation.                           
                           
                                  CHRISTOS IDENTITY INTEGRATION  
Through progressive activation of the 12-Strand DNA Template  the DNA
      '' Internal Star Gate '' between the 1728 simultaneously incarnate selves
        of the Personal Eternal Christos Identity  progressively open . Opening of
          the Internal Star Gates of the DNA  T emplate allows the 12-dimensional
        frequency spectra  of the Soul , Over-Soul  and Christos Avatar Identity
      levels to sequentially and consciously embody within the Angelic Human
     form.  
Soul Integration:  Activation of DNA Strand Templates 4-6  opens DNA
       Star Gates between incarnates in Planetary Times Cycles 1-2-3  and 4-5-
       6 . The 6th-Strand Activated Being possesses 6-dimensional conscious-
      ness , is a fully embodied soul,  can pass through Universal Star Gates 1-
        6  of Densities 1 and 2 via formation of the 6-dimensional Hallah Phase
         Merkaba V ehicle  and building of dimensions 1-6 of the Antahkarana
           Primal Life Force Current.    
      Over-Soul Integration:  Activation of DNA Strand Templates 7-9 opens
      DNA  Gates between incarnates in Planetary Times Cycles 1-2-3,-4  
    301  
                                                                                                                  

       
    The Angelic Human Heritage and Rainbow Roundtables  
   
       5-6  and 7-8-9 . The 9th Strand Activated Being possesses 9-dimensional
       consciousness , is a fully embodied over-soul , can pass through Universal
       Star Gates 1-9  of Densities l, 2 and 3 via formation of the 9-dimensional
       Quatra Phase Merkaba Vehicle  and building of dimensions 1-9 of the
          complete Antahkarana Primal Life Force Current .  
 Christos A vatar Integration : Activation of DNA Strand Templates 10-12
       opens DNA  Star Gates between incarnates in Planetary Times Cycles 1-
       2-3, 4-5-6, 7-8-9  and 10-11-12 . The l2th-Strand Activated Being pos-
         sesses 12-dimensional consciousness , is a fully embodied Christos Ava-
       tar , can pass through Universal Star Gates 1-12  of Densities l, 2, 3 and
         4 via formation of the l2-dimensional Mahunta Phase Merkaba Vehicle
         and building of dimensions 10-12  of the Christos Maharata  Primal Life
       Force Current, capable of full Ascension  out of manifest matter density.  
                      
                             REALITY OF THE ROUNDTABLES  
 • The Planetary Christos Realignment Mission was  designed to take place as
         the members of the Angelic Human races in each of the four Evolution-
         ary Rounds  joined together during Stellar Activations Cycles (SACs)  in
        their respective Time Cycles, to run their DNA  T emplate Signet Code
        Fire Letters  from their Tribal Shield  into Earth’ s Planetary Shields.
 • The groups of Angelic Humans who gather during SACs to run the Rainbow
         Ray Primal Life Force Currents and Star Gate Signet Code Fire Letters
          into Earth’ s Planetary Shields to prevent pole shift  are called Signet
           Councils . The Angelic Human Signet Councils are incarnate members of
       the Azurite Universal Templar Security Team.  
 • The D-12 Shield of Aramatena Planetary Christos Divine Blueprint is re-
      ferred to as the '' Rainbow Roundtable '' Members of the Angelic Human
     Signet Councils  are called '' Rainbow Wearer '' and ''Regents of the
      Rainbow Roundtable. '' These titles indicate the capacity to hold at least
       temporary 12-Strand DNA Template activation,  which  permits the Re-
      gents to run sufficient amounts of the Rainbow Ray Primal Currents to re-
      set the Planetary Christos Divine Blueprint within Earth’ s Planetary
          Shields.  
      Running    of    the    Planetary   Sign et   Rainbow    Roundtables   to     prevent     pole    shift
       during SACs is done in the following manner:  
 l. Activation of the Personal D-12 Maharata Current and Tribal Shield  to
      run the Rainbow Ray Primal Currents  via temporary activation of the
         12-Strand DNA Template.  
                             2. Assembling of Signet Council Regents  at various geographical locations to
                conduct '' Roundtables ,'' using specific '' Signet Stand '' to collectively           
               run the Tribal Shield Fire Letters  into Earth’ s Planetary Shields at
                                  Earth’s 12  Star Gate  opening   points  and  12 Gate   Activation Sites.
   • If an individual Regent can determine which of the l2 Angelic Human
      Tribes represents their genetic lineage , they can direct their Rainbow Ray
      Current and Tribal Shield Fire Letters directly to the Star Gate and Ac-
          tivation Site  to which their DNA Template corresponds.  
    
    302