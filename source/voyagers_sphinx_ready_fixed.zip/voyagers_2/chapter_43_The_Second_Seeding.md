43 
 
                                                                                                                                                                                                                                                                                                                                                                                          

     
       The Second Seeding  
Sphere of Amenti could be returned to Earth's core and the Seal of Palaidor
lifted from all of the races of the Second Seeding. If 8% of the races could
assemble the fourth DNA strand and increase the vibration rate/particle pulsa-
tion rate of their personal bodies and bio-energetic fields, the particles of
Earth's grid would also accelerate to D-4 frequencies, high enough to hold the
Sphere of Amenti with its fourth-dimensional frequency coding. Once the
Sphere of Amenti was returned to Earth's core the souls of the Second Seeding
races could return to their morphogenetic fields upon death and would no
longer suffer the fragmentation of consciousness into the D-4 astral and D-2
elemental kingdoms. With the return of the Sphere morphogenetic field the
memory of the races would be re-entered into Earth's grid and the strand parti-
cles of DNA that brought that memory imprint into the personal cellular mem-
ory would reassemble within the operational DNA strands of the entire fifth
race, returning to the incarnates the memory of their place and purpose within
the evolutionary drama. Opening the Sphere of Amenti within the Earth's core
would automatically accelerate the process of building DNA strands and incar-
national evolution for all of the races, and for those who completed assembly of
the fourth strand the Seal of Amenti would be released, allowing for ascension
to Tara through the Halls of Amenti.  
      The Lamanians and Ur-Antrians and Breanoua, and the A yrians and
Hibiru of the Second Seeding evolved on Earth together 3.7 to one million
years ago. Approximately one million years ago a race called the  Drakon
from HU-1 Orion star system came to Earth and tampered with the genetic
code of the races. They created hybrids within the Root Races called Dracos,
contaminating the human genetic code and altering the evolutionary imprint
for numbers of the Amenti souls. The Drakon race is a sentient, intelligent
race of up-right standing, dragon/lizard-like beings with a tendency toward
aggression and warlike behavior. They represent a digressive strain of a supe-
rior reptile-like race from HU-3 and frequently had poor relations with the
HU-1 Galactic Council. They were expert geneticists and scientists, but
showed little regard for other life-forms and lacked spiritual development.
The Dracos hybrids were more lizard-like in appearance, with body structure
more closely resembling humans, but facial features and temperaments char-
acteristic to the Drakon. The Drakon also tampered with certain strains of
Earth dinosaurs (who were seeded on Earth about 375,000,000 years ago as an
experiment by other ET races), creating aggressive, carnivorous monitors for
their captive human populations. Many of the cultures of the Second Seed-
ing abandoned their advanced surface cultures and retreated underground to
escape the terror of the Drakon monitors. The Phalzants  (Chupacabras)
were also created at this time, combining certain animal strains from the Dra-
kon planets with various Earth animals. The Phalzants and descendants of the
Dracos are presently assisting Zeta Visitors with earthly agendas detrimental to the