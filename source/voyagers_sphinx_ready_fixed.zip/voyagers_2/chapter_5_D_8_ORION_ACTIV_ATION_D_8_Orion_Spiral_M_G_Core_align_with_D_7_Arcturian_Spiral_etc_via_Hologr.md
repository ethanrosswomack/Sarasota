5    D-8 ORION ACTIV ATION : D-8 Orion Spiral,. M .G. Core align with D-7 Arcturian Spiral, etc via Holographic Beam
 DATE : 5/5/2017 -6/30/2017  day 2  -2017 GAIAN ACTIVATION
 EARTH VORTEX OPENS:  Portals between Earth, Tara, Gaia and D-8 Meta-Galactic Core open.
 BLUE-BLACK LIQUID LIGHT WAVE INFUSION : day 2 -2017  D-9 BT & D-10 OT enter Earth's Core
 DNA:  strand # 8 assembles & activates, EARTH CORE Blue-Black Star  crystal activates for 24 -48 hours
 EARTH ACCRETION LEVEL : 6 to 7  HUMAN ACCRETION LEVEL : 7 to 8
 (Ascensions to Meta-galactic Core)                                                                                                                                                                      _________________________________________________________