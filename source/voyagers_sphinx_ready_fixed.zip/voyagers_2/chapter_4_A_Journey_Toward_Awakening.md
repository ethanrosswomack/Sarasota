4
                                                           
                                                               
                                                                    
                                    
                         A Journey Toward Awakening
                 
                                          SINKING ATLANTIS AND EARTH QUARANTINE
         
                           The Sinking of Atlantis, the Ending of Open ET Relations and the
                       Withdrawal of ET Technologies, Premature Opening of the Arc of the
                                          Covenant and Descent of the Sphere of Amenti,
                                                    Earth's Quarantine, DNA Mutation
                                          and the Creation of the Ego and the Higher Self.
                                                                     9,558 BC-8000 BC       
   Following the 28,000 BC explosion in Atlantis, which reduced the conti-
nent of Atlantis to a small land mass of three islands (in the area of what is
now called the Bermuda Islands), the guardian races continued open visita-
tion with the cultures of Earth, using the Alcyone interdimensional spiral
and the Great Pyramid teleport station for easy access to Earth. The ET Visi-
tors, and occasionally inter-time travelers from future Tara, and past and
future Earth, shared open commerce with human cultures, showing their
inﬂuence in various locations around the globe. As the primary teleport sta-
tion was located in Egypt, Egyptian culture was strongly affected and inﬂu-
enced by ET visitation. Many of their later depiction of Gods originated from
these early days of direct relationship with a wide variety of extraterrestrial
beings. The Sirian Council of HU-2, and the Galactic Federation and Sirian-
Arcturian Coalition for Inter-planetary Defense of HU-1, along with several
other guardian allies, held the Alcyone spiral and Egyptian teleport station
under high security.  
     The Anunnaki Resistance, the Drakon, their allies or any other groups
not authorized by the Sirian Council, were not permitted to access the Alcy-
one spiral for Earth visitation. Unauthorized groups could, however, “take the
long way in,” using other inter-galactic portals which connected to Earth's
portal system. Though these alternative routes of visitation demanded much
more time and resources, they were still frequently used by other stellar cul-