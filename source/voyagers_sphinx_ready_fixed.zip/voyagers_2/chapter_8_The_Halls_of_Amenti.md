8
                                 
          

                                                                                                                 The Halls of Amenti                                                                                                                               
                                                           
           Tarranates to enter incarnational cycles on Earth, pick up the fragments of                      
              consciousness from the lost souls by pulling their energetic particles from the 
 HU-1 Uni fied Fields into the DNA, merging the consciousness of the soul 
 fragments with the embodied Ur-Tarranate consciousness, thereby allowing 
 this composite identity to evolve through a sentient life form, back into its 
 original soul matrix (the Turaneusiam 12-strand prototype).                              
     This evolutionary plan was not immediately set in motion. Though the
 Sphere of Amenti was set within Earth’ s morphogenetic field nearly 550 mil-
 lion years ago, the Earth grid had to evolve and pick up grid speed before the 
 Sphere of Amenti could begin birthing its new races. Between 250 and 550
 million years ago various other species seeded by HU-1 ET Visitors evolved  
 on Earth, some of whom became members of your plant, animal and insect 
      kingdoms. Various groups of etheric beings (without matter density) also   
 spent time on your planet. The races of the Sphere of Amenti finally began to 
 appear on Earth about 250 million years ago. Before their appearance more 
 inter-galactic wars were fought by races who did not want the Covenant of 
 Palaidor to be ful filled. These wars were primarily fought on Tara, becoming 
   part of a long history of confrontations that were simply termed the Taran   
  W ars. Once the Earth territory was secured the Ur-T arranates of the Sphere   
 of Amenti began birthing on Earth. This began what came to be known as   
 the Turaneusiam-2  or T-2 experiment. This represented the seeding of the