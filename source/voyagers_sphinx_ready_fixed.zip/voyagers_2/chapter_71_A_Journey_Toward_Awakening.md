71 
                                                                                                                                     
          


                  A Journey Toward Awakening
tures, who also influenced the development of the races. The Anunnaki
Resistance still occasionally infiltrated the Sirian Council security systems,
and secretly worked with members of the Templar-Annu, primarily those in
the Atlantean Islands. The Atlantean culture digressed into a torturous, elit-
ist society run by the Templar-Annu operatives of the Anunnaki Resistance,
and due to their actions 11,558 years ago, Earth civilizations would be
changed forever. The first major stumbling block to the guardian races awak-
ening plan took place in 9,558 BC.    
         The Te mplar-Annu, motivated by the Anunnaki Resistance, devised a
plan to take control of the Great Pyramid teleport station so the Resistance
could have free access to the Alcyone spiral. Their plan also included the
destruction of the Sphere of Amenti, for without the race morphogenetic
field, the souls of the races would be trapped in HU-1, their evolutionary
imprint erased. The Resistance desired to use humanity as an experiment,
creating a worker race that could supply them with Earth resources, primarily
gold and several other mineral compounds. Using Ankh tools pirated from
the Annu-Melchizedeks of the Inner Earth, the Templar-Annu attempted to
direct UHF fifth-dimensional energy from the Ankhs, through the Great
Crystal Generators which still remained operational in the Atlantean
Islands, through the Earth's energetic grid and into the Arc of the Covenant
portal bridge. They intended to send this high-powered electromagnetic
pulse (EMP) through the Arc of the Covenant and into the Sphere of
Amenti that was held within a planetary core in the Andromeda Galaxy.
Their erroneous calculations indicated that if they sent precise EM pulse pat-
terns into the Arc of the Covenant, the Sphere of Amenti could be isolated
as a target for destruction, and the Blue Flame (morphogenetic field for Tara)
could be released and returned through the Arc of the Covenant, to be used
as an inexhaustible source of power. With the Blue Flame Staff of Amenti
under their control, the Anunnaki Resistance could easily orchestrate a mas-
sive Earth takeover. But the Templar-Annu failed to access the frequenc y 
      codes used by the guardians to protectively seal the Sphere of Amenti against  
       such attack, and that miscalculation became the downfall of Atlantis.  
    When the T emplar-Annu sent their destroyer beam EM pulse through
the Arc of the Covenant, the EM pulse intercepted the Sphere of Amenti
with its security seal. The security seal would not allow the EM pulse to travel
into the Amenti Sphere, but instead created a double overtone frequency
pattern that sent the EM pulse into a state of fission. The exploding energies
focused in the Andromeda Galaxy quickly refracted off of the security seal on
the Sphere, replicated and intensi fied, then projected back down through the
Arc of the Covenant, disseminated through the Earth grid, then refocused on
their point of origin, the Main Crystal Generator beneath the largest Island
of Atlantis. This process occurred almost instantaneously, causing a chain
reaction explosion within most of the operational Crystal Generators. The