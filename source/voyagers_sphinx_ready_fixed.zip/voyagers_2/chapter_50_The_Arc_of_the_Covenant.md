50 


                                                                                  
                                                                                 The Arc of the Covenant
vide security. Races from the Arcturus and some from the Pleiadian systems
offered assistance, as many humans had, during the course of their troubled
evolution, found exile within the Pleiadian and Arcturian cultures; coopera-
tion was given from both HU-1 and HU-2 members of these races. The Sir-
ian Council of HU-2 formed an organization with pro-human members of the
HU-1 Sirians and several cultures from Arcturus, called the Sirian-Arcturian
Coalition for Interplanetary Defense,  through which the hidden Sphere of
Amenti, Earth and its allies would be protected if need arose. This organiza-
tion was later invited to join a much larger interdimensional guardian group
known as the Interdimensional Association of Free Worlds , whose member-
ship extended well into the highest Harmonic Universes. Though many races
in the Andromeda galaxy were already members of this collective, the Asso-
ciation of Planets in Andromeda  would not agree to military involvement,
as they were not entirely supportive of the conditions of the Treaty of El-
Annu. They did, however, allow the Sphere of Amenti to remain hidden
within a secret location in their star system.  
    Following the removal of the Sphere of Amenti 849,000 years ago, the
Earth once again endured a series of climatic and geographical changes as
Earth's energetic grid re-balanced following the removal of the Sphere.
Again ﬂood waters rose, covering portions of Earth's surface. In historical
record, this time period became interwoven with the early ﬂooding associated
with the Electric Wars, and a later time period of ﬂooding, all consolidated
into the story of your Biblical Flood. The Guardian organizations knew that
the Third Seeding of the human lineage would have to be orchestrated once
the planetary environment re-balanced. But the Third Seeding could not
take place directly through Earth's core as the Sphere of Amenti morphoge-
netic field was now in the Andromeda galaxy. The Third Eye of Horus portal
through which the Second Seeding took place would no longer be useful as
its connection to the Sphere of Amenti had been severed, so a new portal
bridge needed to be created between the Andromeda galaxy and Earth in
order for the Third Seeding to take place. The Third Eye of Horus portal
bridge remained open as a passage between Earth and Sirius B (frequently
used by the Kantarians of Sirius B for visitation during the Third Seeding),
but it no longer connected to the Sphere of Amenti and so could not be used
for ascension to Tara.  
                                             The Arc of the Covenant  
                                                          840,000 YA        
       A  portal bridge between the Sphere of Amenti in the Andromeda galaxy
and the Earth's D-2 core was constructed by the Guardian organizations
about 840,000 years ago. This inter-galactic bridge was called the  Arch of the
   Covenant of Palaidor , and later became known as the Arc of the Covenant.
Through the Arc of the Covenant the race souls of the Sphere of Amenti