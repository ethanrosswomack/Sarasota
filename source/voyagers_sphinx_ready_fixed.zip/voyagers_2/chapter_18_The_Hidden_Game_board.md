18       
                                   
                                      
                                          
                                     
                    The Hidden Game-board
                          Final Conflict Drama
                              
                                           APIN SYSTEMS; THE FALCON, THE ANDROMIES
                                                           AND THE DOVE 1943-1951
    From 1943, the Zeta-Rigelian-Drakonian force continued to “spread its
wings” of inﬂuence across the globe following their 1943 success in creating
the Phi-Ex Wormhole network. Drakonian Illuminati races became painfully
aware that the Zeta Rigelians had intentions of orchestrating mass genocide
among select populations  in preparation for the 2000-2017 Final Con flict
with the Anunnaki and Necromitons. In the late 1930s , the Zetas began
experimenting with '' Ethnic Viruses '' (DNA/race type speci fic) as they
explored their options for reducing select Human, and competing Illuminati,
populations during the SAC drama. Beginning in late 1943,  the Zetas
began using their Phi-Ex Network technology  (code-named '' the Falcon, ''
after the Atlantic wormhole’s ancient Atlantian name) for testing of sub-
space sonic scalar pulses  to induce localized, targeted “natural disasters”  in
desired areas.  
    Primary locations for Zeta/Illuminati sonic scalar pulse testing  have
included areas of Alaska, Antarctica, Australia, Central America, Mexico,
the Middle East, various desert regions and beneath the Atlantic, Paci fic and
Indian Oceans, the Aegean, Mediterranean and Caspian Seas, the Sea of
Japan, Persian Gulf and Gulf of Mexico. Throughout the 1950s , the
Necromiton-Andromie  force became more actively involved in Illuminati
contact and began to assemble teams of Illuminati ''converts '' from the
Zeta-Rigelian Drakonian international Illuminati ranks. In 1951  certain
factions of pro-Anunnaki Necromiton-Andromies from Omega Centauri
accepted Templar conquest “deals”  from a competing Jehovian-Annu-
Elohim Anunnaki  OWO invasion force from Sirius A, Arcturus  and the
Trapezium  (Theta) star cluster in '' Orion’s Sword .'' The Bipedal Dolphin
People, Anunnaki and Annu-Elohim Fallen Angelic forces that comprise
this ancient Lemurian-Atlantian Jehovian-Nephite Invasion Team  are
collectively known as the '' Dove .'' 
    The '' Dove '' symbology  refers to the physical shape , when viewed from
the air with photo-radionic scanning equipment, of their global Atlantian
Pylon Implant Network (PIN) Control Grid  that was last implanted into
366 
                        


                                                                           The Lion, the “Lamb,” the Sphinx and the Eagle
Earth’s Planetary Shields during the 25,500 BC Lucifer Rebellion. The
“Falcon Phi-Ex PIN ” connecting to the Zeta-Rigelian Drakonian “Falcon
wormhole,” is also one of these ancient Atlantian PIN Control Grids, as are
numerous others  soon to be discussed. These Atlantian Pylon Implant
Network (APIN) systems  were in active use as tools of territorial dominion
by various competing Fallen Angelic/Intruder ET factions throughout the
Atlantian period. APIN systems differ in the type of Planetary Shield
implanting  that is used, but all implanting utilizes sophisticated crystal-based
technologies  similar to the silicon-based microchips  used in conventional
computer technologies. The APIN systems can be compared to massive
global grid  systems made of strategically placed  ''crystalline microchips ''
that interface directly with the natural, multidimensional, electromagnetic
energy conduits of Star Gates, Axiatonal and Ley Line systems  organic to
Earth’s Templar. APIN technology is not intrinsically a “negative”
technology, but rather an environmentally valid application of the natural
spiritual and scientific laws of Creation Physics. Before these technologies
fell into the hands of Fallen Angelic races, they were used openly by various
Guardian races in many universal systems  to facilitate and enhance the
experience of evolution and ascension for all. Prior to the Lucifer Rebellion
of 25,500 BC , Emerald Covenant Founders races and the Angelic Human
and Indigo Maji races of Earth utilized APIN systems for everything from
global free energy systems, climate stabilization and healing, to inter-stellar
sub-space communications and broadcasting networks . 
            THE LION, THE “LAMB,” THE SPHINX AND THE EAGLE  
    The Angelic Human and Indigo Maji races of Earth originally had two
great global APIN systems  on Earth that operated Earth’ s T emplar naturally
on a D-l2 “ 12-Code Pulse Christiac Current ” through Star Gate-12 , its
corresponding Inner Earth Star Gate-12 “ Cue Site ” and interface with
Earth’s natural Crystal Pylon Networks (CPNs). The Emerald Covenant
APIN systems were known as the '' Great White Lion '' and the ''Golden
Eagle .'' The Founders designed the blueprint of their APIN systems  with
two primary criteria in mind—first, that the APIN was precisely calculated
mathematically to encompass and modulate natural frequencies through
the 12 Primary Star Gates, Axiatonal and Ley Line systems in Earth’s
Planetary Templar . Second, once the technical elements of the APIN “grid”
were in place, the Founders desired to “ leave a part of themselves reflected
in the APIN ” to remind the races of Earth that they were never alone or
abandoned. The “design” of the Founders’ APINs was also to serve as a “ sub-
sonic planetary identification flag” when viewed from space via Photo-
radionic scanning equipment. (See APIN diagrams pp. 527-530). The Great
White Lion APIN system  belonged to the Elohei-Elohim Christiac
Founders  races of D-12 Aramatena-Lyra —the feline-hominid Anuhazi
Leonine  race. The Great White Lion’ s '' heart '' was located at Earth’s Star
Gate-12—Montsegur, France . The “throat  from which the lion roared” was
at Star Gate-1l, Southern England.  Its “head” looked out to the west,
cresting the north polar regions, spanning central and northern Europe,
across Atlantis and into northeastern North America. The '' body  of the
Lion'' lay at rest across the expanse of the Asian continent,  while the Lion’ s   
367 
                                                                                                                                            

                                                                   
                        The Hidden Game-board Final Conﬂict Drama
''great front paws '' stretched out across North America and northern South
America, its rear left paw shrouding the continent of Africa. The “tail” of the
Lion extended outward and down from the far eastern side of the Asian
continent, through Australia, south to Star Gate-1 at Halley, Antarctica,
then curved back up and northward to encompass the southern portion of
South America. The Elohei-Elohim Anuhazi installed the “Great White
Lion” APIN system on Earth in stages, beginning just after the “Electric
Wars” of 5.5 million years ago.  
    Though Earth’ s continents and land masses have changed position
several times since the Electric Wars, Earth’s Star Gates always remain in
the same positions  within Earth’ s Planetary Shields Scalar T emplate. Earth’ s
crust ''slides across '' the fixed geographical Star Gate coordinates of the
Planetary Shields; APIN systems are installed along precise coordinates
within the Planetary Shields,  and thus the form of the APIN systems
remain constant in relation to variable planetary surface geography . The
original Egyptian Sphinx  had the face of a lion , not of a man. The design for
the Sphinx was chosen, by the Indigo Child Maji, Angelic Human and
Emerald Covenant-loyal Annunaki races of Earth, as a tribute to the Elohei-
Elohim Leonine Christos Founders race. The structure broadcast a statement
to the Fallen Annu-Elohim and Annunaki Fallen Angelic collectives that
the Earth races were united under the common banner of the Founders’
Emerald Covenant Co-Evolution Peace Treaty . The design of the original
Sphinx was a three-dimensional representation of the Great White Lion
APIN system, created from translating the Founders’ APIN maps , as held in
the Emerald Covenant CDT-Plate records. The primary purpose of the Great
White Lion APIN was to assist Earth through natural Stellar Activation
Cycles  until Earth’ s Planetary Shields could be repaired  from the damage
incurred during the Electric Wars cataclysm. If the Great Lion, and its
companion “ Golden Eagle ” APIN systems had not been installed following
the Electric Wars, Earth would suffer cataclysmic pole shift during every
SAC , and eventually the planet would implode due to the severity of its
Scalar Template distortions.  
    The Great White Lion APIN was modeled  in the image of the feline-
hominid  Elohei-Elohim Leonine Christos Founders of D-12 Lyra,
Aramatena . It represented the D-12  (silver- white ) Lyran-Sirian APIN
system of Earth, the “anchoring rod” and stabilization grid  for 12 Primary
Axiatonal Line “vertical frequency conduits ” running along the polar
North-South  longitudes in Earth’ s T emplar Complex. The companion
Golden Eagle APIN system  belongs to the Emerald Covenant Cerez-
Seraphei-Seraphim Avian  races and Aethien-Mantis  races of D-8 Mintaka,
Orion  and the related Serres Avian-hominid  races of Alcyone, Pleiades.  
   The Golden Eagle, modeled in the image of the A vian (bird people)
Cerez, is the D-8 “anchoring rod”  and stabilization grid  for the 12 Primary
and many secondary horizontal Ley Line systems  running East-West  along
the equatorial latitudes of Earth’s Templar, and for the diagonal Ley Line
system. The Great White Lion  is the “ Guardian of the North and South”
and the Golden Eagle  is the '' Guardian of the East and West .'' The “Great
White Lion,” has its heart at Star Gate-12,  through which the silver- white,
 D-12 “Christos” frequency  of the planetary Pre-matter Template,  or
   368  
 

                       
                                                                The Lion, the “Lamb,” the Sphinx and the Eagle
''Divine Blueprint '' opens into Earth’s Planetary Shields. The Great White
Lion became the symbol of the eternal Christos Founders Elohei-Elohim
Anuhazi races, the  L yran-Sirian Guardians of Earth’s D-12 Christiac
Divine Blueprint —the “ The Powerful Lion with the Pure, Christed Heart
of a Lamb. ” In technical terms, the Great White Lion and its Golden Eagle
companion APIN systems literally hold Earth’s shattered Planetary Shields
and scalar template together during SACs.  
   Interestingly , in the Jehovian Anunnaki/Fallen Annu-Elohim
distortions added to the ancient Emerald Covenant texts  that later became
the Bible,  the Jehovian “promise” was that the day would come '' when the
Lion would lie down with the Lamb .'' What the Jehovians failed to explain
was that the '' Lamb ''—the Star Gate-12 ''Heart of the Great White Lion ''
APIN—was '' sacrificed and cut out upon the altar '' of the Fallen Angelic
Omicron Drakonian  (“Dragon” APIN) force of Alnitak, Orion, during the
last consummated SAC of 208,216 BC . At this time, Earth’s Templar
activated on an unnatural 10-Code Pulse,  blocking activation of Star Gate-
12 and “stilling the heart of the Lion,” due to Omicron invasion. The Annu-
Elohim also fail to mention that in 25,500 BC , their Jehovian Anunnaki
assisted the Marduke-Luciferian Anunnaki of Alpha and Omega Centauri  to
''seize the Lion '' by its Star Gate-11 England '' throat '' via the NDC-Grid.¹
Since this time, the Jehovian Anunnaki and various competing Fallen
Angelic factions have “ quested to tame the Lion ” APIN system under their
respective dominion, and have progressively used the NDC-Grid to prevent
the Elohei-Elohim Founders from accessing the Great White Lion APIN to
assist the peoples of Earth. The Jehovians intend for the '' Lion '' APIN  to
''lie down with the sacrificed Star Gate-12 Lamb ,'' to be  ''resurrected '' and
re-activated under the dominion of the Fallen Annu-Elohim, when they
succeed in pulling Earth into the Phantom Matrix . They hope to ''re-start
the heart'' of the Lion by arti ficially linking Earth’s Star Gate-12 Lamb to the
Star Gate-11 ''throat of the Lion.'' If the Jehovians have their way, the ''Lion
will have its heart in its throat,'' and both the “Lion and the Lamb” will '' lie
down together before the alter of Jehovah ,” to be “resurrected” by the Fallen
Annu-Elohim, as an '' energy-vampiring '' system to feed the Phantom
Matrix.  
     Sad, isn’t it ? Here humanity was led to believe that the statement of
“When the Lion lies down with the Lamb” represented a time when “Peace
and love, and the end of fighting, would come between the aggressive and the
passive, and we’d all enter the kingdom of Heaven joyously together.” This
example illustrates beautifully the cruel sense of humor, manipulative
soothsaying  and outright deception  offered to us by the Fallen Angelic
Annu-Elohim Jehovian Anunnaki collective. What the Jehovian Anunnaki,
and the other Fallen Angelic collectives did not anticipate was that the
''Heart of the Lion '' would begin '' beating with a 12-Code Pulse '' at the
January 1, 2000 , commencement of the present SAC. This is precisely
what has occurred  due to continuing Elohei-Elohim and Seraphei-
Seraphim  crisis-intervention  efforts   in  the  contemporary  drama.  Now  all of
___________________________  
                              1.    See Masters Templar Coursebook. 
                             369  
                                                                                                                                        

The Hidden Game-board Final Conﬂict Drama  
the Fallen Angelic collectives are in a ''race for time'' to fulfill their intended
OWO dominion agendas, in hopes of preventing the Great White Lion and
Golden Eagle APIN systems from fully awakening from their long slumber. If
the Great White Lion and its Golden Eagle companion awaken, the
numerous APIN systems belonging to the Fallen Angelic races will be
progressively healed and re-coded to a natural “Christiac D-12 12-Code
Pulse. ” In this case, Earth, Inner Earth and the Halls of Amenti will be
permanently spared further advancement of the Fallen Angelic dominion
campaign. The Big Question  is ''Can the Great White Lion and the Golden
Eagle be healed and awakened in time ?'' 
     As the Great White Lion, and a return to the L yran-Sirian Christiac,
love-based culture model that it represents, struggle now to awaken , the
Golden Eagle has a '' rapid healing '' to complete before its “wings are opened,
free to fly.” During the 25,500 BC  Lucifer Rebellion, when the Marduke-
Luciferian-Anunnaki and Necromiton-Andromie-Annunaki-hybrid races of
Alpha and Omega Centauri , and the Thoth-Enki-Zeta Anunnaki  races of
Nibiru implanted the Nibiruian Diodic Crystal Grid (NDC Grid) in Earth’s
Templar, the “Lion was grabbed by its Star Gate-I1 throat” and the ''Eagle
was Caged.'' The Golden Eagle  APIN system fell to Necromiton-Andromie-
agenda Anunnaki forces , as the NDC Grid  was used to reverse the natural
scalar template sequences (''Fire Letters'') on Earth’s  Primary Ley Lines 4
and 10 . The horizontal L4/L10 ''double Ley Line '' emerging from Star
Gate-10 Abadan, Iran , and Star Gate-4 Giza, Egypt , is the L4/L10 ''Giza
Ley Line, '' the East-West  center-line axis  upon which the Golden Eagle
APIN system  is structured. (See APIN diagrams pp. 527-530.)  
      
                             THE WHITE EAGLE AND THE MELCHIZEDEK DECEPTION          
    Since 25,500 BC, the Golden Eagle APIN system has been “held
hostage”  and used to “do the bidding” of the Necromiton-Andromie-
Anunnaki, Nephilim and Marduke-Luciferian Anunnaki  of Alpha and
Omega Centauri.  This group proudly refers to themselves as the '' Alpha-
Omega Order of Melchizedeks '' and uses the symbol of a White  Eagle  as an
antagonistic mockery to the Emerald Covenant races , denoting the Alpha-
Omega’s (unfortunate) victory in claiming the Guardian Cerez’s Golden
Eagle APIN. The Golden Eagle was intended to become the symbol of a
free America when the U.S.A. was formed . Instead, the '' white-headed ''
Bald Eagle  became the national mascot, symbolizing the Alpha-Omega
Order’s partial victory  in becoming the directors of a controlling portion of
the US. Illuminati force— the Free Mason-Knights Templar legion.  ''Arch-
(fallen)- angel  (Nephilim) Michael '' is a ''pet contact nam'' used by this
diabolical anti-Christiac Melchizedek collective, as is the '' Alpha-Omega
Melchizedek Orde r.'' At certain times throughout history the Founders had
entrusted this collective to join the Emerald Covenant on “ Redemption
Contracts ,” through which their races could be assisted in gaining freedom
from the Phantom Matrix via restoration of a D-12 Pre-matter “Christiac”
                    Divine Blueprint Template. Repeatedly they  have used  such opportunities  
              to exploit other races and compromise Emerald Covenant freedom
                         
                            370  
             

                             
                          The Sacred Cow, Faces of Man, Easter Island Heads and the Trion Field
agendas , just as their Anunnaki groups have done in their September 12 ,
2000 , defection from the Emerald Covenant Treaty of Altair.  
   lt is important in the contemporary drama for people to realize that the
Melchizede k Cloister and “Order of the Yunasai”  is the universal
organization of the Emerald Covenant Christos Founders races in this Time
Matrix. The Cloister promotes  egalitarian, non-gender biased spiritual -
science freedom teachings for all, and does not promote the utter falsehood
of the “Christ Cruci fixion” story, nor “worship” of external gods.
Melchizedek “priesthoods” of the Alpha-Omega Order  are control
paradigms  based on the dogmas of the Fallen Annu-Elohim, Anunnaki and
Necromiton races, originating from the Phantom Matrix.  As of the Alpha-
Omega false order of Melchizedek’s September 12, 2000, entry into the
United lntruder Resistance (UlR) Edict of War, the Melchizedek Cloister
will no longer offer peace negotiations  to these groups that include their
demand of non-disclosure  regarding their true history of deception and
manipulation of earthly populations. The Alpha-Omega Melchizedek Order
will no longer be permitted to “hide beneath the skirts” of the Emerald
Order    Melchizedek   Cloister   and   the   Christiac Freedom    Agenda, for   which
it stands.             
 THE SACRED COW, FACES OF MAN, EASTER ISLAND HEADS
                                   AND THE TRION FIELD  
   The Cerez-Seraphei and Elohei-Elohim Leonine Emerald Covenant
races will free the caged “White Eagle” APIN and restore the Golden Eagle
to its original dignity  and the Great White Lion APIN will soon awaken
with a loving roar . With the awakening of the Great White Lion and the
Golden Eagle, yet another once-sacred APIN will be restored to its original
grace. The APIN known as the Blue Oxen,  or the '' Sacred Cow ,'' originally
the contact network between Earth and the Maharaji Blue Human
guardians of Sirius B Star Gate-6 , Council of Azurline, once held all of
India  and portions of Eastern Europe and Asia  in its protective embrace.
(See APIN diagrams pp. 527-530.) The Blue Oxen APIN system was jointly
created by the Sirius B Maharaji and a Density-3 Emerald Covenant Bovine
race² from Anteres  and Altair  called the Rashayana  of the Bra-Ha-Rama
Amethyst Order.  
    The Oxen design for the APIN was chosen by the Sirius B Blue Human
Maharaji as a tribute to the Rashayana for their assistance. The Blue Oxen
APIN was created as a specialized interplanetary contact network  in 22,500
BC, in conjunction with a more sophisticated PIN system implanted by the
Emerald Order Founders. In the 10,500 BC  Luciferian Conquest, the Blue
Oxen APIN system was overtaken by the Blue Centaur Fallen Angelic
collective of Omega Centauri,  and has been utilized since this time to
further the OWO dominion agendas of the '' Centaurians '' and their frequent
allies, the Necromiton-Andromie-Anunnaki of Alpha and Omega
Centauri . Through the Final Conflict drama of the 2000-2017 SAC, the
Blue Oxen will also be reclaimed by the Maharaji, to once again become the
                             _____________________________
                              2.    Oxen-shaped biology, Etheric-matter density. 
                                371  
                        
                                                                                                                                                 

                       
                       
                       The Hidden Game-board Final Conﬂict Drama
“Sacred Cow” it was designed to be. The reason why Emerald Covenant races
can succeed  in protecting humanity during the Final Conﬂict drama of the
2000-2017 SAC is due to a specialized APIN system  that allows Earth’ s
Planetary Shields to connect directly with Earth’s counterpart planet in a
different Time Matrix called the Trans-Harmonic Time Cycle . Through this
specialized Founders’ APIN, Earth can enter what is called a Meajhé Field,
Trion Field , or “Tri-Veca Time Continuum,”  through which the planet will
be prevented from being drawn into the Phantom Matrix, and pole shift will
be averted during the 2000-2017 SAC.  
   In 22,500 BC,  just before the failed SAC of 22,326 BC , the Azurite -
Eieyani Universal Star Gate Security Team  of the Inner Earth  Time Cycle
visited the remaining Lumerian Islands  (Muaravhi) and the Mu’a Maji
Human races residing there. With the assistance of the Mu’a,  the Azurite-
Eieyani “Indigo Children”  implanted another PIN system , an advanced
Lumerian -Pylon-Implant Network (LPIN) , in an attempt to stabilize Earth’s
Templar and “resurrect” the Great White Lion and the Golden Eagle APINs
in preparation for the 22,326 BC SAC. The Azurite LPIN  was known as the
''Faces of Man ,'' ancient depictions of which can still be found in the
''heads '' rock  sculptures of Easter Island  off the coast of Peru, which were
erected by Mu’a race descendants after their exile from Kauai, Hawaii.3
There are '' 12 Heads '' in the Faces of Man LPIN system—one  set of four
Heads on Earth,  another set of four Heads on Parallel Earth and the final set
of four Heads on Inner Earth . Collectively, the 12 Faces of Man are known as
the '' Guardians of the 12 Pillars. '' Each set of four Lumerian Pylon Implant
“Faces” grids connects directly to the other two corresponding sets of “four
Faces” on Parallel and Inner Earth. When the Faces of Man LPIN is
activated, four massive pillars of inaudible, interdimensional standing
sound waves  anchor in Earth’s Planetary Shields through the “four Faces”
template. The four Sound Pillars in each planetary body carry the full
frequency spectra of dimensions 3-6-9-12,  a frequency combination known
as the '' Halls of Amorea Passage .'' 
    The Halls of Amorea Passage frequency bridge connects Earth, its
Parallel and Inner Earth directly to the Universal Pre-matter Template
“Divine Blueprint” of Aramatena-Lyra  (“Double-Double”), via D-6 Sirius B
Star Gate-6, D-9 Star Gate-9 Mirach Andromeda  and the  T rans-Harmonic
Time Cycle . The Eieyani intended to activate the Faces of Man LPIN system
during the 22,326 BC SAC,  to place Earth under full D-12 Maharic Shield
and to seal the Phantom Matrix  before the Fallen Angelics of Atlantis
succeeded in drawing Earth into the black hole. In 22,326 BC, in an event
called the Eieyani Massacre,  the Thoth-Enki-Zeta Anunnaki of Nibiru
destroyed the Eieyani civilization in what is now Kauai, Hawaii ; the Eieyani
races would need to wait until the next SAC, the 2000-2017 SAC,  to
complete activation of the Faces of Man LPIN system. The “Faces of Man”
LPIN system was designed in the image of the  Angelic Human race and the
Azurite-Eieyani Maji Indigo Children races of Inner Earth . The “four Faces
                        _____ ___________________