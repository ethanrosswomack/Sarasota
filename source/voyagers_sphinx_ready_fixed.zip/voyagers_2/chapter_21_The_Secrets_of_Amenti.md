21 
 
                                                                                                                               

         
        The Secrets of Amenti  
Seal of Amenti, which appear as a build-up of electrical particles within the
etheric body called  miasms , which distort the natural functioning of the chakra
system and accelerate the manifestation of physical disease. The Seal of Palaidor
must be released before the Seal of Amenti can release, both achieved by assembling
the full fourth DNA strand.  
  For a period of time following the end of the Electric Wars, Earth could
not sustain life. For over 4,000 years Earth was plagued by erratic weather
patterns, tectonic shifting and climatic anomalies. Earth experienced a slow,
partial pole reversal and tilted several degrees on its axis between 5,508,100
and 5,504,000 years ago, as a result of damage done to Earth's energetic grid
and portal systems during the Electric Wars. Numerous ET races visited the
planet during its more stable periods, some serving as Guardians over the
Sphere of Amenti. Various animal forms were again reseeded by visiting
races. Approximately 5,504,000 years ago a sudden, final shift in Earth's grid,
as its poles realigned, caused a “quick freeze” Ice Age  to occur, which wiped
out most life-forms on the planet except for some of those residing in deep
caverns beneath the seas. Following this shift the vibrational rate of Earth's
grid dropped swiftly and it could no longer hold the higher frequencies of the
Sphere of Amenti at its core. If the Sphere of Amenti were not removed, the
Earth would explode.  
  In order to avoid planetary destruction the Elohim of HU-3 and the Ra
Confederacy entity families detached the Sphere of Amenti morphogenetic
field from Earth's core in D-2, 5,500,000 years ago. It was placed in a secure
position in deep space within the fourth-dimensional frequency bands.
Because the Sphere was placed within the D-4 frequency bands, it acquired a
fourth-dimensional frequency seal, which meant that souls who had not yet assem-
bled their fourth strand of DNA could no longer merge with their Root Race mor-
phogenetic ﬁeld/soul matrix or that of their Cloister.  Root races 3 and 4, and their
Cloister Races, who were to be reseeded on Earth with the Seal of Amenti in
their genetic code, could not evolve to assemble the fourth strand, as this
strand was assembled through birthing through the Fifth Root Race. This
fourth-dimensional seal on the Sphere of Amenti became known as the Seal
of Palaidor , as it sealed the races out of their Palaidorian morphogenetic field
once they had entered manifestation. The Root Race 3 Lamanian/Lemurian
and Root Race 4 Atlanian/Atlantean souls of the Second and Third Seeding
could not reincarnate into the Fifth Aeiran/Aryan Root Race and became
trapped in time within the second, third and fourth dimensions. Following
death, these souls would enter D-2 Earth core and their consciousness would
fragment into the Earth's D-2 Uni fied Field. Having lost their form-holding