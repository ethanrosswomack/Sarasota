12 Tribes  out of which your present human lineage has emerged.                               
                                                                                                          THE  HALLS OF AMENTI
                                                The Cloistered Races of Parallel Earth—
                                               the Second World—Rescue Mission Stage 1
                                                                2 50,000,000-25,000,000 YA
          From the Sphere of Amenti five smaller spheres were created, which    
    became the morphogenetic patterns for five races known as the Cloistered                
  Races.  Collectively the five Cloistered Races were called the Palaidorians, as   
    they represented the beginning of the ful fillment of the Covenant of        
    Palaidor . They represented the Earthly counterparts to the larger Palaidorian
   group from HU-2. Of the original Turaneusiam-1 12-strand DNA package,  
 each Palaidorian race held the morphogenetic imprint for DNA  strands 7-12
   (which held the electro-tonal frequencies corresponding to dimensions 7-
   12), plus the imprint for strand l, and each of the five groups carried the 
 imprint for one additional DNA strand corresponding to dimensions 2,3,4,5                            
       and  6    . The Cloisters served as “Guardians” for  the  evolution  of  the  additional