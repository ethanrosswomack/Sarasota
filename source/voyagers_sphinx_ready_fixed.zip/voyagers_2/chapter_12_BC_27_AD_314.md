12 BC-27 AD 314
12,00000YA 18 
12.500YA 64, 69 
12,550 YA 61
1244 325
1244AD 316,330 
12-Code Pulse 369
12-strand DNA 2, 3, 4, 7, 8, 9, 11, 12, 17,
                   43, 84, 94, 99, 102, 104, 148,
                   186, 189,291,482
      relationship to consciousness 108
12-Tribes and Roundtables 295
13,000 BC 321
1340-1331YA 96 
1353 BC 323 
1370-1353YA 96
144,000 persons 145, 160, 179, 194—195
144,500 Indigo Children 196, 203
1458 BC 323
1459 BC 322 
147,900 BC
     -75,877 BC 244 
1476 BC 321,322
148,000 BC 244,329
     -75,000 BC 329
150,000,000YA 18
150,000
     couples 195
     Indigo Children 186
150,000 BC 329 
1500  325
1500 AD 330
151,000 BC 329
152,000 BC 329 
559155,000 BC 329, 356, 390 
1550 BC 322
15-Dimensional Physics 241
1600 124
1670 BC 321,322
1670 BC-1550 BC 322
1748 124, 134, 135, 142, 206
1750 32, 124, 326
1750 AD 317,  330
1800s 361
18-23 103
1900s 361
1902  125
1902-1986  206
1903 139
1906 122
1916 317, 326, 330
1920s-1930s 399 
1926 125 
1930 426
    -1943 360 
1930-1940 330
1930s 126, 246, 257, 317, 361, 378
1939 361
1940s 126, 134, 317 
1941
    December 7 362
1943 130, 139, 142, 143, 144, 172, 188, 210,
                     350, 353, 361, 378, 387, 399
     -1951  366
     August 12 359, 362 
1945
     August 12 362, 363        
     August 9 363
1949-1972 131
1950 132 
1950s 366, 379
     -1960s 377
1951 366
1951-1983 374
1952-1968 132 
1961 115
1970s-1980s 375
1972 133, 134, 143, 185, 374 
       -1974 122, 132
       -1980 375
       -2012 136
        February 375 
1973-1980 136 
1974 133 
1980-2001 376
1980s 376
1982 122, 136     - 1984 137
1983 137, 139, 172, 210, 244, 245, 317, 326,
          330, 375, 376, 378, 379, 388, 418
    -1984 379
    -1992 379
1984 133, 140, 141, 142, 144, 187
1986 125, 135, 136, 142, 185
         -1998 187-193                                          Index, Volume ll  


                  401, 415, 417, 420, 426, 427, 465 
     One World Order dominion campaign 245 
     Stellar Activations Cycle 242, 243, 245,339
2001 178, 209
   -2003 178 
   -2005 251 
   -2012 293 
   August 429
   August 12 404, 406, 408 
   February 330  
   May 429 
   November 430
   October 430
   September 11 335-337, 344, 353, 373,
           377, 389, 408, 429, 432
                   9 warning telephone calls
                        ignored 409
                  What Really Happened 403-413 
   September 17, Giza alignment 206, 208
   September 3 406, 409, 429 
   September 7  409
2001-2008 365
2002 209, 210, 345 
        -2003 343 
        August 431
        August-September 415 
        May 429, 430
        September 431
2003 139, 140, 143, 162, 167, 172, 173,174,
                178, 257, 330, 338, 340, 386 
    -2004 252, 327
    -2008 245, 250 
    August 256
    August 12, Zeta Experiment 210 
    Dimensional Blend Experiment 344 
    Mass Mind Control experiment 327 
2003-2008 318, 319
2004 138, 139, 142, 162,173, 174, 209, 210,
                212, 330, 340, 384 
   Frequency Fence 344 
   September 9, birth of Avatar 4 209, 212
2005
     -2017 196, 213
   January 1, Stellar activations 213
2006  138, 173, 214
2006-2007 412
2007  214
2007  YA 100
2008 330, 340, 412, 426
      -2012 318
       July 22, birth ofAvatar 5 215
2009 216 
         -2017 181
2010 216 
2011-2016 196
2012 37,66, 123, 125, 131, 136, 137, 140, 
             141, 142, 156, 160, 169, 181, 185, 
             186, 191, 252, 330
   -2017 123, 126, 130, 134, 143, 161, 162,
        166, 174, 181, 185, 196, 482
   -2022 37, 41,185
   critical mass needed by 168, 176 
   December 21, Earth Enters Photon Belt 220 
   January 1, Earth’s 7th V ortex opens 216
   May 5, birth of Avatar 6 218
   May 5, opening of the Halls of Amenti  135,
                                                                               Index, Volume II
1987
      August 16, Harmonic Convergence 187 
1988   142, 185, 186, 192
1989   188
1992 136, 186, 189, 244, 245, 326, 330, 350, 
                  353, 354, 380, 383, 384
     -2012 193 
     August 12 381 
     January 11,11:11 188 
     July 26, birth ofAvatar 1 189, 193   
     June 6, Second Seal opens 189 
     November 241, 243, 318, 354, 381
1994   143, 192,382,383
      -1998 382
     December 12, 12:12 189
 1994-1998 382
 1995  191
 1996  143
       June 24, birth of Avatar 2 191,193
     1997  176,383
October 25, Ashayana Deanes’ 
         encounter 234
1997- 98  253
1998, 142, 176, 193, 197, 350, 384, 410 
      -2004 209
      -2012 179
     June 384
     June 26, birth of Avatar 3 194, 197, 201                   
     June 26, Sparking of the Arc of the 
              Covenant 235
1998- 1999 385
1999 186, 326, 347
      -2000 196 
      -2004 203 
      August 11 346 
      December 12 346 
      June-July 346 
      March 345 
      November 330
      November 18 346
      October 344
 2,024 BC 330 
 2,500,000YA 29 
 2,668 BC 322, 330 
 20,000 BC 311,320,330
 2000  140, 142, 143, 185, 186, 318, 347, 360             
      -2017 199
      August 247, 318
      January 245, 253, 318, 327, 330
      January 1 326, 346, 369
               Day of Transcendence 186
      January 1, Earth’s 4th vortex opens 201, 203      
                July 247
      July 5 246, 327, 330, 385 
      July 5th 318
      May 5 Earth frequency raised 181 
      October 338
         September 241,247,250
                       Anunnaki Sabotage 247 
      September 12 247, 249, 250, 257, 318, 
               326, 327, 330, 374 
      September 7-12 344
2000-2017 246, 253, 255,286, 288, 293,
                 303, 305, 311,314, 318, 323, 324,
                 326, 328, 354, 355, 360, 371, 372, 
                 379,383, 388, 393, 394, 397, 398,
560                                  

                 
Index, Volume II               
                             
          194 , 208
 2012 YA  98, 136
 2017 65, 66, 67, 85, 96, 97, 104, 122, 125,
                130, 142, 143,145, l55, 162,167,
                172, 176, 179, 181, 183,186, 187,
                196, 224, 227, 231, 239, 461, 470
     -2029 196
      January 1, Gaia’s Violet Flame 213
      June 30, Stellar activations 210
       May 5, Stellar activations 210
2022 175, 187
     January 1, Earth’s 7th vortex closes 228-229
     V oyagers deadline 169
2024 BC 244, 313, 322
2025 194
2047 229
206,000 BC 284
2072-2084 37
208,100 BC 328
208,216 BC 285, 293, 328, 369, 422