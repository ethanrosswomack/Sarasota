24 United Intruder Resistance Nibiruian Crystal Temple Bases .. …... .525
                        The Four Faces of Man/Guardians of the 12 Pillars LPIN System ..... .526
                   The Great White Lion Guardian APIN System  ...................................... .527
                   Golden Eagle APIN System  .......................................................................528
                   The Falcon and Dragon Intruder APINs ..................................................529
                Anunnaki and Anunnaki-Andromie-Nephite Intruder APINs ............. .530
                   Angelic Human 12-Tribes & Indigo Maji Grail Lines Summary  ..….. .531
                   Intruder ET & Illuminati Races, 2001 UIR OWO Team Summaries ...532      
    Appendix VI Crisis Intervention Expedited Amenti Opening Schedule .........5 38      
                Events Leading to GA Crisis Intervention and 
                            Expedited Amenti Opening ...............................................................538
                   Expedited Amenti Opening Crisis Intervention Program Begins ......... .540
                   2011 Meajhe Field Weakness, UIR Jehovian Seals
                            and Trumpet Pulse .............................................................................. .552       
                   UIR, “ Wingmakers” the Labyrinth Weapon and 2011. ......................... .553
    Index, V olume II ............................................................................................ 558    
     viii      
This PDF sold to Ethan Womack - dudeinwrens@gmail.com  Transaction: 7960

                       
                                                               
                                              
                                                                                                                                                                                                             
                                                                       
       Preface to V olume II   
           For there is nothing hidden except to be revealed, nor is anything kept
          secret except in order that it may be made known. If any man has ears
                       to hear, let him be listening and let him perceive and comprehend.
                                                                                 —Mark 4: 22-23
             
                 Voyagers: Secrets of Amenti  is a remarkable achievement. The magnitude
          of the implications fostered by its very existence is, in a word, stupendous. In
            the inspired writings of India, Voyagers  would be regarded as Shruti,  which
             functions as its own authority , since it is the product of immediate insight
          into the nature of ultimate reality . Ashayana’ s experience with the Guardian
           Alliance represents, in my opinion, a true Gnosis —a direct experience with
         higher intelligence—the direct experience of knowledge, with no loss of res-     
                                olution.  
            Ashayana, by her own admission, functions here solely as scribe. Voyagers
       is the product of nearly 30 years of direct, physical, consensual, and—most
        importantly—on-going contact with pro-human higher intelligence, be they
       Extra-, Meta- or Ultra-terrestrial; hence a Gnosis in the truest sense. This
            Gnosis is passed on to the reader, engaging a higher level of cognition or             
          precognition, if one is already one step ahead of the game.
        Voyagers is a precious jewel in “Indra’s Web,” spoken of in the Buddha’ s
      Flower Garland Sutra , itself a testament in previous times to a profound
       knowledge and understanding of advanced Keylontic Morphogenetic Sci-                       
     ence. In the following pages, you will be reawakened to a model of interdi-
  m e n s i o n a l  p h y s i c s ,  t i m e  m e c h a n i c s ,  D N A  c o n s t r u c t i o n  a n d  m u l t i -
   dimensional identity structure that will revolutionize your comprehension of
     our world, our universe and yourselves.  
                          These teachings are being returned to us at a most critical juncture in our
                 tenure as embodied souls, “in order that you may , as free and proud shaper of
                your own being, fashion yourself in the form you may prefer .” ¹ These teach-
                   ings are submitted, as Rod Serling ( The Twilight Zone ) would say, not “for your                                                                                                                     
                         
                               
                                 ix
                      
  
   
This PDF sold to Ethan Womack - dudeinwrens@gmail.com  Transaction: 7960

  
   
       Preface to Volume II
         approval,” but rather for your consideration. Do consider them carefully. For
      “If most of us remain ignorant of ourselves, it is because self-knowledge is
        painful and we prefer the pleasures of  illusion.'' ² 
                As so aptly put, in The Adornment of The Spiritual Marriage ,ᵌ “Knowledge
       of ourselves teaches us whence we come, where we are and whither we are
     going. We come from God and we are in exile.” You, the reader, are about to
    cross the event horizon of a ground-breaking work of singular s ignificance for      
     Earth and its inhabitants.  V oyagers  is, quite literally , a road map to the
      stars...and beyond. Inside these pages is truth , not re-veiled...but unveiled-
     stripped of the distortion, dogma and elitism still so pervasive within tradi-
    tional and contemporary works of higher calling. Voyagers  establishes a cos-
     mographic paradigm through which all others can be organized and uni fied,
    providing a most compelling and impressive body of information regarding
     the true origins of the human lineage, as well as our hidden (until now!) evo-
     lutionary destiny.  
            We stand on the threshold of the fulfillment of a covenant made a long
      time ago in “a special pre-existent place”—a place known to the Acoma as
       Ha Ku, to the Mayan as Hunab Ku—the Egyptian Ku, to the Lakotas’
          Peschla.
         To the Dorothy in each of us, the Emerald City of OZ, the heavenly
       Tula...Tara...Home. Prepare for a new level of revelation.
                                                  
      _____Philip L.Gruber
                Founder/Director,
                Quantum Access Group
      ________________________________
        1.  Giovanni Pico della Mirandola, Oration on the Dignity of  Man, trans. A. Robert Caponigri.
              Chicago: Gateway Editions, 1956.
         2.  Aldous Huxley, The Perennial Philosophy , 1944-1945 Harper and Row Perennial Library.
         3.  Jan Van Ruysbroeck, London 1916
       x

                    
      
                  Required Reading
                  
    The second edition of V olume ll of the  Voyagers  series has been vastly
enlarged so as to include much important, current information about what is
happening on Planet Earth, up to and including the tragic national events of
September ll, 2001, when hijacked airliners were intentionally crashed into
the World Trade Center and the Pentagon.  
                          
    To ensure that you have an appropriate understanding of this informa-
tion, it will be necessary for you to obtain and read, if you have not done so
already, the second edition of       Voyagers, Vo l u m e  I .  S e e  “ O r d e r i n g    i n f o r m a -
tion” on page 580. Specifically, the following bolded  sections of  V oyagers  I ,
second edition, are essential  to understand before proceeding : 
 *Introduction................................................................................................................... ........................ .ix 
 *The Azurite Temple of the Melchizedek Cloister, Inc (updated)...........................................xxxv
 *About the Author ...........................................................................................................................xxxvi
 *CDT-Plates, Emerald Covenant and the Mass Drama ...........................................................xliii
 *Administrative Levels of the Emerald Order Melchizedek Cloister........................................xlix
               The Yunasai..............................................................................................................................xlix
                Yanas.........................................................................................................................................xlix
               Breneau Order Founders Races ................................................................................... .............l
               Density-5 MC Eieyani Master Council ............................................................................ .... lii
               IAWF —Interdimensional Association of Free Worlds................................li
               Azurite Universal Templar Security Team............................................................................liii
               GA—Guardian Alliance .................................................................................................................... .liv 
l UFOs, Visitors, and the Interior Government.....................................................................................1