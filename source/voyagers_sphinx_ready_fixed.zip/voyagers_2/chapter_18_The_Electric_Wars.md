18
          
        

   
                                                                           
                                                                   The Electric Wars
Amenti or were relocated to other HU-1 planets with the help of the Elohim
and HU-2 Palaidorians. Those who lost their immortal genetic codes and did
not leave Earth perished, along with many animal life-forms, as Earth's plan-
etary environment was thrown into chaos. Earth would have been destroyed
if the Breneau from HU-5 had not intervened.                      
                                       T he Seal of Amenti and the End of the Electric Wars
                                                                              5,508,100 YA       
     The Breneau entities negotiated a treaty between these opposing fac-
tions. In the agreement the Root Races of Earth would be allowed to evolve,
but the Halls of Amenti —the portals between Earth and Tara —would be
sealed to humans until the mutations within the genetic code of Root Races
3 and 4, which had contaminated the morphogenetic fields, could be
reversed. ln terms of souls evolving out of HU-1, the sealing of the Halls of
Amenti meant that they could evolve into the morphogenetic field of their
Cloister Race and pick up DNA strands 7 —12, but they could not pass
through the Cloister morphogenetic field of their Root Race into the collec-
tive Palaidorian morphogenetic field where DNA strands of the other Root
Races, strands 4 —6 could be assembled. Without the imprint frequency pat-
terns of strands 4 —6, the incarnate soul could not plug strands 7-12 into the
operational genetic code.  The Halls of Amenti were sealed to the human lineage
by removing from the morphogenetic ﬁelds of the Third and Fourth Cloistered
Races, the activation codes/overtonesᵌ that would allow the particles and anti-par-
ticles of the body to merge, transmute and assemble strands 7 —12 into the opera-
tional DNA.  This morphogenetic alteration effectively sealed the particles of
the physical body out of the etheric body (anti-particle body), making the
final transmutation of Cloister overtone codes 7-12 impossible. This mani-
fested as an energetic block between the physical and etheric bodies within the
human bio-energetic auric ﬁeld, and a sealing out of the Primary D-1 overtones
within the base chakra of the human—an auric conﬁguration still carried today
within the contemporary human.  It also created perception of duality between
consciousness and body for those baring this genetic con figuration.
    Normally an incarnate would build up the DNA strand of its Root Race
then build up the activation strands from its Cloister Race, which would
allow it to pull strands 7-12 into manifestation from the Cloister morphoge-
netic field. The seventh strand (a primary base tone strand), which contained
the frequencies of all of the strands below it, would plug in to the single
strand assembled through the Cloister, then assemble all of the other Root
         ______________________________  
             3.   The frequency patterns that corresponded to their form double in the parallel universe.