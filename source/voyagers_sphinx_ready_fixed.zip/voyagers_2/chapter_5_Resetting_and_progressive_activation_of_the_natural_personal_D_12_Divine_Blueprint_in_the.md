5    Resetting and progressive activation of the natural personal D-12 Divine Blueprint in the                                                        
      DNA Template, via consistently applied Bio-Regenesis technologies and Temporary Per-     
      sonal Maharic Seal can allow anyone opportunity to partake of the benefits of Meajhé
      Zone areas and the Bridge Zone time continuum shift.
550 
 
                 
               
         

     
                                 Expedited Amenti Opening Crisis Intervention Program Begins
  after Earth’s successful passage into, and stabilization within, the Bridge Zone time 
   cycle. On Earth, the UIR is likely to succeed in at least partially fulfilling its  2005 
  First Contact '' invasion  attempt within the Trion Zones.  If the GA is successful in 
  creating the 2003 Level-3 Temporary Planetary Maharic Seal, the 2003 UIR invasion 
  schedule will be effectively postponed, but not permanently prevented. In 2005 , it is
  unlikely that UIR will be able to utilize their massive Mother -ship ﬂeet, due to the 
  Cap on the Falcon-Phoenix Wormholes. The use of smaller craft and a less dramatic
  public debut are the more likely UIR strategies. (If UIR erodes the Level-3 D-12 Cap 
  on the Wormholes, the UIR "Mother ship" agenda may unfold in 2005 as they had 
  originally planned.) The GA’s successful activation of the "4 Faces of Man"/"Guard-
  ians of the 12 Pillars" LPIN and "Great White Lion" and "Golden Eagle" APINs will 
  thwart the UIR “real estate clearing through 2008 pole shift” agenda. The GA LPIN/
  APIN systems, coupled with the Trion/Meajhé Field Planetary Buffer Blanket, will 
  hold the core of Earth’s Planetary Shields stable throughout the SAC until 2011, 
  when the only remaining “ window of opportunity ” to create planetary pole shift             
         arises.   
    
    Whether the UIR has succeeded or not in progressing to on-planet physical pre-
sence, they will launch their last invasion attempt in 2011.  This will be their last chance
to prevent the Emerald Covenant nations from permanently  severing the links between 
our living Time Matrix and the Phantom Matrix  via fulfillment of the Emerald Cove-
nant Founders’ Christos Realignment Mission.   It will be the UIR’s last opportunity ever
to gain access to the Halls of Amenti Star Gates and Inner Earth Time Cycle territories.  
   If the GA is successful in 2012, the scalar-field templates of our Universal Time 
Matrix and those of the Phantom Matrix will be permanently severed , effectively closing
all Wormhole links to the Phantom Matrix in our 15-Dimensional Time Matrix. Our 
Time Matrix will be prevented from being consumed by the Black Hole Sub-time Distor-
tion system Phantom Matrix anomaly and finally, after literally 250 billion years of 
intergalactic warring,  Phantom Matrix races will no longer be able to enter our Time 
Matrix for feeding and invasion.  Phantom Matrix races remaining in our Time Matrix 
will require DNA Template 12-Code Bio-regenesis  to biologically survive in this system,
and their advanced weapons systems and technologies will no longer function without 
access to the reversed-polarity  electromagnetic currents  of Phantom Matrix.  
                 If the UIR’s intended 2011 final invasion attempt fails, as it is likely to do  if the GA
Crisis Intervention Plan succeeds to this point, Fallen Angelic races will have one final 
opportunity to enter Emerald Covenant Redemption Contracts for DNA Bio-Regenesis 
under galactic quarantine in the Sirius star system . If they refuse this opportunity, their 
only remaining options will be to return to Phantom Matrix before it is closed, or to 
live out a finite destiny of rapid biological and technological deterioration, within galax-
ies of this Time Matrix that have not yet been placed under full Level-12 Maharic Seal. If 
the Planetary Christos Realignment Mission, which was originally scheduled for comple-
tion during the 22,326 BC SAC , is not completed during this SAC, the Halls of Amenti 
will progressively fall to Phantom Matrix particle fusion.   
             The Phantom Matrix is an unnatural Black Hole system  that continually accretes 
 energy and consciousness  from the living “host” Time Matrix to which it is attached.  In          
           22,326BC, the Founders recognized that the Phantom Matrix, created during the Lyran-    
              Elohim Founders Wars 250 billion years ago,6 had almost reached critical mass accretion. 
The Black Hole system had pulled into itself nearly as much energy mass and conscious-
ness than that organically held within our natural living Time Matrix. If the Phantom 
Matrix reaches critical mass accretion , its draw upon the living Time Matrix will progres-
                             sively accelerate and our living Time Matrix will be permanently “pulled off  the grids” of                                 
                  the Density-5 Primal Light Fields and into the chaotically organized, finite Phantom 
                              Matrix. If the Christos Realignment Mission  is not successful during the current SAC,    
                     this entire Time Matrix, not only the Earth, will be pulled into the Phantom Matrix  
                             Black Hole via the Halls of Amenti Star Gates. Many innocent inter-galactic civilizations   
                           
                             ________________
                            6.    Earth time translation    
                               
    
                            551                                                                                                         
                                                                                                                                                        
                                                                                                                                        
                                                                                                                               

                      Crisis Intervention Expedited Amenti Opening Schedule
would be trapped in Phantom Time, denied their birth right of organic Ascension, Mas-      
tery and Eternal life. The Emerald Covenant Founders have allowed the Phantom Matrix      
to remain attached to our Time Matrix for over 250 billion years,  in hope of lovingly re-      
evolving the Fallen Angelic races r esiding there within. The Founders and the Fallen      
Angelics knew in 22,326BC that the “ time was up ” for giving the Fallen Angelic races      
further evolutionary opportunity; the " host" Time Matrix was due to collapse  due to the       
continuing competitive choices of exploitation repeatedly made by the Fallen Angelic      
races. No one is treating the Fallen Angelic races unfairly; since 22,326 BC they have      
been faced with the product of their own unloving, exploitative choices .              
       Since the issue of severing the ties between the Living and Phantom Matrices came                     
 to a head in 22,326 BC, the Fallen Angelics have planned to achieve forced dominion of      
this Time Matrix, with intention of drawing it into Phantom Matrix as an energetic “food           
supply”. They continue to make this unfortunate choice, rather than accepting the             
Founders continually loving invitation into peaceful Emerald Covenant Co-evolution           
Freedom Treaties. Through cooperation with the Founders races, the Fallen Angelic races     
could progressively heal to re-enter At-One-ment with the Cosmic design, through              
which the Phantom Matrix could be healed.  If the Anunnaki had been true to the 1992        
Pleiadian-Sirian Agreements, the time of  Fallen Angelic accountability would have      
been postponed until the 4230 time continuum end. Due to the Anunnaki, Drakonian      
and Necromiton-Andromie races continual and contemporary choices of War over peace,      
hatred over love and dominion over freedom, they have brought their own “Day of Judg-      
ement”  down upon themselves. The Emerald Covenant nations wish the Fallen Angelics’     
no harm, and are not judging them as “unworthy”, but neither can they further permit the     
self-serving Fallen Angelic nations to bring death, sorrow, pain and destruction to the      
peace-loving races of this Time Matrix. The Planetary Christos Realignment Mission  will        
be fulfilled in 2012 , as part of the Universal Christos Realignment Mission  now taking      
place in this Time Matrix. It is the time for the Fallen Angelics themselves to judge      
“which side of  the fence” they will end up on as the Christos R ealignment Mission is fulfilled . 
                 2011 MEAJHÉ FIELD WEAKNESS, UIR JEHOVIAN SEALS  
                                                           AND TRUMPET PULSE    
        
     In 2011 the UIR will attempt to take advantage of a temporary weakness  in the 
Planetary Meajhé Zone Field. This Meajhé Zone weakness will naturally occur as Earth’s 
Planetary Shields transition from D-9 Quatra Phase Merkaba into D-12 Mahunta Phase
Merkaba  to make the final 2012 link with the Inner Earth Bridge Zone time continuum.
As Earth’s Planetary Shields are prepared to fulfill the 2012 shift in Angular Rotation of 
Particle Spin from the 4.25 Trion Buffer Blanket, the natural spin ratios of the planetary 
Quatra Phase Merkaba will temporarily slow. This temporary 3-4 month Quatra Phase 
Merkaba slowing  will cause the Level-9 Planetary Maharic Seal to temporarily dip to a
Level-7 (7-dimensional) Maharic Seal . During this period there is a remote chance that 
the UIR could utilize the " Seven Trumpets"  sub-space sonic pulse technology on D-7
Phantom Arcturus  to re-activate the Seven Jehovian Seal sites on Earth, to blast 
through the temporary Cap on the Wormholes before the Cap becomes permanent in 
2012.  
                        If  this endeavor were to be successful, and the Falcon-Phoenix Wormholes were to 
                 be reactivated as the Meajhé Zones of Earth were transitioning into the Bridge Zone con- 
                 tinuum, cataclysm would result. The Quatra Phase Merkaba needed for the Bridge Zone 
                 link would be slowed in speed, via “Trumpet” pulse, to that of a D-6 Hallah Phase Mer-
                    kaba Vehicle. Once Meajhé Fields were reduced to D-6 vibration, the “Trumpet Pulses” of 
                 D -7 Phantom Arcturus could be used to force Earth’s D-6 Hallah Phase Merkaba into the 
                 re verse-rotation characteristic to Phantom Matrix. The Trion/Meajhé Field Buffer Blan-
                 ket would prevent Meajhé areas of Earth from being pulled into Phantom Matrix, but 
                 would not sustain grid speed acceleration sufficient to make the Bridge Zone link. Cata-              
                 clysmic Earth changes would begin followed by pole shift by 2012 . If this diabolical UIR 
                 strategy   were    to     succeed,  little  of      Earth’ s     populations would   survive. GA    Maharajhi      fleets  
                  from Sirius B would descend through the Halls of Amorea passage in attempt to launch
                  
                                 552                                
                         
                       
   

                                       
                             UIR, “Wingmakers”, the Labyrinth Weapon and 2011
evacuations and to protect the 12 Primary Cue Site entrances to the Inner Earth Halls of 
Amenti control temples. Intensive “Star Wars”  would break out in Earth’s skies and
regional galaxies, with earthly nations caught in the crossfire, as UIR and competing rebel 
Omicron-Drakonian ﬂeets from Phantom Matrix poured into Earth’s local galaxies.
Though Emerald Covenant ﬂeets would succeed in preventing UIR takeover of the Inner 
Earth Halls of Amenti control sites, the Planetary Christos Realignment Mission and 
Level-12 Planetary Maharic Seal could not be fulfilled due to further damage to Earth’s 
Planetary Shields. Human civilization on Earth would again be decimated, as it has been 
several times in the past, and major intergalactic wars would again break out as they did 
550 million, 30 million, 5.5 million and 4.5 million years ago. The 2011 period of weak-
ness in Earth’s Meajhé Zones is anticipated to begin between April-July 2011 , and will 
last for a 3 to 4 month  period, into August or latest Nov of  2011. UIR has their  final con-
quest invasion strategy underway, but so too do Emerald Covenant nations have their
counter-strategy in place.  
                  
                                        UIR, “WINGMAKERS” THE LABYRINTH WEAPON AND 2011                   
                                         A collective of renegade Necromiton-Andromie/Jehovian Anunnaki hybrid
 Nephilim races , now members of the UIR, have been initiating progressive covert con-
tact with a group of Humans known as the Labyrinth Group ”. The Labyrinth Group is a 
covert collective of humans directly involved with the 1972-1973 archaeological discover-
ies known as the " Ancient Arrow Wingmakers Site " in New Mexico . Using their usual 
talents of truth-twisting, dispensation of partial knowledge and embellished disinforma-
tion, this Nephilim group, which is code named the “ Corteum ”, have deceived the Laby-
rinth Group into assisting them to create a  crystalline-scalar-mechanics based weapons
technology . In order for the UIR to take advantage of this final 2011 invasion opportu-
nity, they must re-activate the Seven Jehovian Seal sites on Earth in order to use the
"Seven Trumpets" technologies of D-7 Phantom Arcturus to upcap the Falcon-Phoenix 
Wormholes. The Seven Jehovian Seal sites will have been re-calibrated to a Level 9 12-
Code Pulse7 by 2011. The technology the Corteum has inspired the Labyrinth Group to 
create is intended to assist the UIR in re-activating the seven Jehovian Seals on a Phan-
tom Matrix electromagnetic pulse, to allow for fulfillment of the UIR’s OWO final vic-
tory.  
   The Corteum technology utilizes inter-time manipulations  intended to create
"minute time rips " into the Phantom Matrix in regions connecting to the Seven 
Jehovian Seal sites. Through these "minute time rips." which represent a type of worm-
hole bridge, the UIR intends to build up sufficient sub-space photo-sonic "charge" within
the Axiatonal Line system of Parallel Earth.  The photo-sonic charge is intended to be
progressively stored and amplified in the Parallel Earth Planetary Shields until  2008,  
at which time the charge is intended to be split into two " Phantom Electrostatic ionic 
pulses. " One pulse is to be sent back in time to the original 10,500 BC creation of the 
Falcon-Phoenix Wormholes, the other into " future time " in the Phantom Earth time 
cycle.  The "past" pulse will connect the 10,500 BC  Atlantian period  of Phantom Earth,  
in which the Luciferian Rebellion takeover attempt succeeded, to our present time con-
tinuum line. The "future" pulse will connect the "future" of Phantom Earth, which 
evolved from the successful Phantom Earth Luciferian Conquest “past”, to our present
time continuum. Through the mechanics of the Labyrinth Group’s Corteum technology,
which the group has code-named the " Blank Slate Technology " or " BST " (Founders
think of it as " the BeaST "), the UIR intends to accumulate photo-sonic charge in the 
Phantom Earth future location and the 10,500 BC Luciferian Conquest period of Phan-
tom Earth Atlantis. When the 2011  "window of opportunity" opens, the UIR intends to
use the contemporary "BeaST" to direct the amplified photo-sonic charge simultaneously 
into the Seven Jehovian Seal sites of Earth’s Planetary Shields, in the contemporary time,
past Atlantian and future Phantom Earth periods.   
         
         ____________________________  
          7.   9th dimension sealed to the 12th sub-frequency band.  
          553  
                                                                                                                            
                                                                                                                                                                                                                                                                     

         Crisis Intervention Expedited Amenti Opening Schedule  
       Release of the “ BeaST Pulse ” is intended to accomplish several invasion objec-
 tives, the first of which is to re-activate the Seven Jehovian Seal sites in each time period. 
 The second objective of the BeaST Pulse is to tear Earth’s Shields apart via bonding 
 Earth’s grids to the compromised grids of Parallel Earth, which are presently linked to 
     Phantom Earth. Completion of the second objective, which would culminate in the       
      North American continent begin vertically ripped into two sub-continents along the               
       Mississippi River vertical,  is intended to set the stage for fulfillment of objective three .
 Objective three constitutes the intentional shattering of the dimension 8 through 12 por-
 tions of Earth’ s Planetary Shields and reversal of the natural “Fire Letter Sequences”8 
 in the D-1 through D-7 portions of Earth’s Planetary Shields. This despicable plan would 
 seemingly serve to " erase history ," creating a " Blank Slate " of Earth history within which 
   to inset the history of Phantom Earth (thus the “BS-T” code name). Once the BeaST         
    Pulse was used to link past and future Earth to Phantom Earth, the “ Seven Trumpets ”           
   sub-space sonic pulse technologies of Phantom Arcturus would then be used to un-Cap,
  then merge, the Falcon-Phoenix W ormholes in present time. Portions of Earth’ s Plane-
  tary Shields under Trion Zone  suspension would be torn away and drawn into merger 
  with Phantom Earth. Corresponding portions of our present time line would be drawn 
  into merger with a corresponding present point in the Phantom Earth time line, and 
  these  portions of our present time line would be "spliced " into a position between the 
  10,500 BC Atlantis and future Atlantis in Phantom Earth’s time line .  
       It would be as if our true history was “erased” and a  portion of our present literally
 inserted into the Phantom Earth time line.  Portions of Earth’s Planetary Shields under 
 Meajhé Zone  protection would be destabilized under a D-6 Planetary Hallah Phase Merk-
   aba Vehicle, and what remained of Earth would be heading for rapid pole shift  in 2012.          
  The Labyrinth Group of the Ancient Arrow Wingmakers project have no idea that
they are being deceived into creating the very technology that could lead to the 
destruction of Human civilization in 2011 . (Wake up guys—you’ve been taken for  a 
ride!).The people involved with the Labyrinth Group and associated organizations have   
been convinced  by the Nephilim “Corteum,” (they don’t even know they are Nephilim)     
that   only by developing the Corteum’s “BeaST” can Earth be protected from ET invasion.                             
The Labyrinth Group was told that a “big, bad invader race”9 is planning to invade Earth        
in 2011 and that the Corteum “BST weapon” is the only way to prevent this invasion.
 The UIR Corteum need the Labyrinth Group to create this technology for them,  as the
 Corteum cannot access the earthly scientific facilities, resources or geographical positions 
 needed to assemble the tactile components of the BeaST weapon. It is the Corteum
 themselves, and their recent allies of the UIR, that are intending to invade in 2011 ; 
 their rebel Omicron-Drakonian adversaries are intending a counter-invasion in hope of 
 preve nting UIR/Corteum victory.    
             The “Wingmakers Ancient Arrow” archeological site does not belong to the Lab-
 yrinth Group, or to the Corteum.   It belongs to a group of Emerald Covenant Angelic
  Human Races  from the Interdimensional Association of Free Worlds  in the 6520 AD 
 time period and to the Elohei-Elohim Founders , who long ago buried “time capsule trea-
 sures”  in this region specifically for discovery in this time.10 The Elohei-Elohim have 
 approached the Labyrinth Group with invitation to the Emerald Covenant, but the Laby-
 rinth Group refused when the Elohei-Elohim explained the non-violent solution  to the 
 pending UIR invasion. The Labyrinth Group also knows that the “Central Race” Elohei 
 and Angelic Humans will not support their efforts of creating the BeaST weapon , but the
 Corteum have convinced the Labyrinth Group that the invasion cannot be prevented using 
 peaceful methods. The Corteum and UIR are very interested in the Ancient Arrow site, as 
 hidden within this area is the very tool by which Emerald Covenant nations can prevent
 the 2011 UIR/Corteum Invasion.   
          
            _________________________________   
  8.     scalar-wave sequences.  
  9.     AKA the UIR’s rebel Omicron-Drakonian adversaries.  
  10.   The labyrinth Group refer to these races, whose identity is actually unknown to them, as 
          the “ Wingmakers”  or “Central Race ”. 
  554  
          
         

UIR,  “Wingmakers,” the Labyrinth Weapon and 2011
An ancient device called a “Signet Shield” is buried in the area of the Wingmakers  
Ancient Arrow site, under GA Eieyani sonic-force field protection. The Signet (“Star  
Gate”) Shield disc is one of a set of 12 Signet Shields given to the Human Cloister Race  
Guardians of Earth over 200,000 years ago, by the Maharajhi of Sirius B, on behalf of the  
Elohei-Elohim Emerald Covenant Founders. The 12 Shields are manual activation/control  
devices for Earth’s 12 Star Gates, which can be put into use by combining them with their  
12 corresponding Emerald Covenant CDT-Plate disc activators.11 The Wingmakers site in  
New Mexico has been the storage place for Signet Shield-6, since the device was removed  
from Cue Site-6 in India in 5,900 BC, when the Rama races endured direct aerial assault  
from the Marduke-Dramin-Anunnaki and Centaur group during the Centuarian Invasion  
period. Signet Shield-6, and its corresponding SG/Cue-Site-6, is the Emerald Covenant  
“Trump Card” in this Final Con ﬂict drama. Signet Shield-6, SG/Cue Site-6 and the D-12  
Halls of Amoera Passage, in conjunction with three other Signet Shields/SGs/Cue Sites and  
Masters Planetary Templar Mechanics, will be used in 2011 to protect Earth and the Bridge  
Zone Project from UIR invasion during the Meajhe Zone weak period. GA anticipates a  
successful passage through the potential UIR invasion of 2011.
_________________________________________________________________________
If we make it this far in Plan A and "fix the problem," the forces of peace , love
and genuine Christos enlightenment are likely to achieve final 2012 victory on
Earth and in this Time Matrix.________________________________________________________________________
    The Wingmakers “Music discs,” CD translations of which are presently promoted  
via mainstream distribution networks, were not originally part of the GA/Emerald Cov-  
enant Founders “time capsule.” These musical subliminal-command encryption pro-  
grams were provided by the Corteum and added to the Ancient Arrow site “finds,” as 
were certain pieces of Corteum artwork containing bio-stimulus mathematical codes,  
and a set of history recorder discs that have yet to be unearthed containing falsified  
Nephilim/Human history.
The real Wingmakers history and musical recorder-discs, smaller versions of the  
CDT-Plates, were placed in 5,900 BC, and are still in various protected regions of the  
GA Wingmakers site. Discovery of these true Human Race history Records, along with  
other such “GA Time Capsules” placed around the globe, will be permitted by the  
Founders between 2013-2017, as part of GA identity validation just prior to Emerald  
Covenant nation mass contact. The Corteum music and art selections are ‘Trojan  
Horse” technologies intended to affect the function of the DNA Template, creating the 
emotional experience of “calm, bliss and spontaneous cognition” via subtle biochemical/  
neurotransmitter/brainwave direction, while simultaneously blocking natural Pineal  
Gland and DNA Template 12-Code activation. These technologies can, however, be  
enjoyed without detrimental effect, if the Temporary Personal D-12 Maharic Seal Tech-  
nique (see page 499) is used prior to listening or viewing. The D-12 sub-harmonics of the  
natural Maharic Seal will block detrimental portions of the subliminal sound/light pro-  
grams from activating in the DNA Template. The Wingmakers Art Work is a combina-  
tion of Angelic Human visual/bio-stimulus images, with select pieces of Corteum  
control-program images mixed in among the Angelic Human artwork. One can detect  
the subtle difference in frequency between “healthful” Angelic Human images and  
“repressive” Nephilim/Corteum Intruder ET images by using the Maharic Seal Tech-  
nique, then sensing the energy signature behind the image. A deep, low, rumbling “ULF  
background cyclic vibration pulse” can be easily sensed in the Corteum images. Angelic  
Human images will not have this ULF “Phantom under-pulse,” but rather, each image  
will carry a set of three subtle UHF “inner sound tones” that are “frequency keyed” to  
12th-sub-frequency band of D-6 and the 6th-DNA Strand Template. Angelic Human  
Wingmaker images were designed to frequency-trigger progressive activation of Human  
and Indigo DNA Strand Templates 4-5-6, to accelerate Pineal Gland and DNA Tem-  
plate 12-Code activation.
_____________________________        
11.CDT-Plates are all under GA protection as of 1999.      
 
555

  Crisis Intervention Expedited Amenti Opening Schedule
    36.  2012 Dec:  Meajhe-Trion Separation, Christos Realignment and Emerald Covenant
Mass Contact . The Final Con ﬂict drama of the 2000-2017 SAC will reach its conclu-
sion in 2012. The two bi-polarized segments of Earth’s particle base, the Trion Zones  
and the Meajhé Zones , that were held in suspension within the Trion/Meajhé Field
Buffer Blanket begin their final separation . Through the Indigo Children Planetary
Templar Security Team, the GA will release specific information on Meajhé Zone safe 
areas, urging populations to remove into these areas before Dec 2012. Trion Zone
areas will undergo regional Earth Changes  during 2012, as the final phase of the
Christos Realignment Mission completes in 2012. In early Dec 2012 , the frequencies
of the final Stellar Activations /Stellar Wave Infusions will begin. Meajhé Zones  of 
Earth will remain in the 4.25 Trion Buffer Bubble, as the suspended frequencies of the 
D7/D8 Gold Wave Infusion/ Arcturian Activation  that began in Aug-Sept 2002,
complete  activation in Earth’s grids. Completion of the Arcturian Activation will be 
rapidly followed by release of the suspended frequencies of the D8/D9 Silver Wave 
Infusion  and Orion Activation , and the D9/D10 Blue-Black Liquid Light Wave
Infusion and Andromeda Activation (original schedule 2017) . As the Arcturian, 
Orion and Andromeda Activations complete, the Trion Zone  areas will begin their 
cycle of localized Earth Changes that will mark the passage of unsecured areas of
Earth’s Planetary Shields into merger with the Phantom Matrix time line.  Portions of 
Earth territories under Meajhé Zone / Quatra Phase Merkaba protection will begin
their shift into full merger with the Inner Earth Bridge Zone time continuum.  In the
original Amenti Ascension Schedule, due to terms of the 1992 Pleiadian-Sirian 
Agreements, the final phase of the Founders’ Christos Realignment Mission was not 
due for completion until the 4230  end of our present continuum cycle. Due to the 
Anunnaki/Anu-Elohim defection and nullification of the Pleiadian-Sirian Agree-
ments and UIR War Edict, the Emerald Covenant Founders will now complete the 
   Christos Realignment Mission , as they had attempted to do during the failed SAC of 
22,326 BC.  The Founders intended to complete the Christos Realignment Mission 
since that time long ago, until compromising their agenda to accommodate the
potentialities of peace  held within the 1992 Pleiadian-Sirian Agreements.
    37.  Dec 21, 2012 : This is the date the Founders have chosen for fulfillment of the Chris-
         tos Realignment Mission .  This date now translated into our contemporary calendar 
    from the ancient Lemurian/Mu’a Founders calendar system, was  not recently chosen.  
    This date was chosen for completion of the Christos Realignment Mission in 22,326 
    BC , by the Emerald Covenant Elohei-Elohim Founders, Eieyani, Azurite, Maharajhi 
      and Angelic Human races, when the SAC of that Lemurian/Atlantian time period
         failed due to Anunnaki invasion.  The date was chosen through mechanics of inter-
           time physics; the point in “future time” that we now identify as Dec 21, 2012, marked 
            a point   within   the 2000-2017 SAC in which planetary positions would be in  the  most 
                                appropriate alignment to complete full , Permanent Level-12 Planetary Maharic
         Seal.  Throughout our recorded history this date was known by various ancient cul-
         tures as the time of the “ Great Cleansing”  or “The End of Time”, as illustrated for us 
           today in the ancient Mayan Calendar .            ________________________________________________________________________                          
                        On Dec 21, 2012, the GA will finally be able to fulfill their originally
                                    intended mission of setting Earth, and this Time Matrix, 
                                                        free from Fallen Angelic terrorism.           _________________________________________________________________       
     
     On this date, the Emerald Covenant Founders races will release the Universal SC 
Seals on Universal SG-12 in our Time Matrix, the Inner Earth Time Matrix and the 
Trans-Harmonic Meajhé Time Matrix, fully linking the three Time Matrixes, the " Divine 
Cosmic Trinity ," together. While remaining in the Bridge Zone time continuum and 
Trion/Meajhé Field Buffer Blanket, Earth will receive three additional Stellar Wave 
Infusions/ Transmutative Stellar Activations on this day . The D10/D11 Silver-Black 
Liquid Light Infusion  and D- 10 Lyra-Vega Activation , the D11/D12 Pale Silver Mah-
arata “Christos”  Liquid Light Infusion  and D-11 Lyra-Aveyon Activation , and the long-
awaited D-12/Primal Light Field “Rainbow Ray”  Infusion  and D-12 Lyra- Aramatena  
Activation.  D-12 Lyra-Aramatena, home of Universal SG-12 in our Time Matrix, is the
556 
                                                                  

                                 
                                     
                                        UIR, “Wingmakers”, the Labyrinth Weapon and 2011
          Density-4, D-12 Pre-matter Hydroplasmic Liquid Light " Christos Divine Blueprint " of 
           the Earth-Tara-Gaia System. The "Shield of Aramatena," as this scalar template is called,
          is also the D-12 Pre-matter Universal Divine Blueprint,  or “Universal Christos”, for all
         intergalactic systems in the 12 dimensions of Densities-1 through 4 in our Time Matrix. 
    
                     Earth    will enter  the "Christed" state of   D-12 Mahunta Merkaba  on Dec 21, 2012;
          the Halls of Amenti    Star Gates and 12 Star Gates  of Earth’s Templar will remain per-
         petually open  after this point, and Emerald Covenant races will begin preparation for a 
         long overdue re-introduction. Earth’s SGs and Seven Primary V ortices will not enter a 
           closing cycle, as they would have done in the original Amenti Ascension program. As the
            Permanent Level-12 D-12 Planetary Maharic Seal  activates in the Planetary Shields of 
        Earth-T ara-Gaia, the scalar-wave templates of our Time Matrix and those of Phantom 
           Matrix will naturally and permanently separate.  
          ________________________________________________________________            
                    The Universes in our Time Matrix will begin the victory celebration  they have  
                    awaited 250 billion years,  since formation of the Phantom Matrix during  the  
                                                        Founders Lyran-Elohim WarS.               _______________________________________________________________           
                                     Earth races will soon afterward be prepared for a visit from the Inner Earth Eieyani , 
         Sirius B Maharaji, Azurite, Aethien and Serres Emerald Covenant races , who will
           make contact on behalf of the Founders, to invite Earth’s peoples into the Emerald Cove-
         nant. Physical Mass Contact with Emerald Covenant nations is scheduled for 2017
            The UIR will be unable to use their weapons technologies, or infiltrate Earth’s Halls of 
           Amenti SG system once Earth is under full Permanent Level-12 Planetary Maharic Seal/
        D-12 Mahunta Phase Merkaba. Fallen Angelic and Illuminati races that do not engage 
        DNA Bio-Regenesis will be unable to biologically withstand Earth’s environment. 
        The GA  will of fer escorted evacuation to quarantined healing facilities in the Sirius star sys-
        tem in this Time Matrix to Fallen Angelic/Illuminati races that remain in this Time 
          Matrix. Remaining Human and Indigo populations will progress in DNA reverse-muta-
         tion and 12-Code activation while under the protective Planetary Buffer Blanket of the
           Trion/Meajhé Field.  
                              _________________________________________________________________                                 
                                 A new age of enlightenment will most definitely begin if we successfully make it to 
                                                             this December 21, 2012 Universal Day of Renewal.                            ____________________________________________________________
                                                                                                                                     
                         557  
                                                        

                                                                    
                                  
                                   *This is the book as in publication.       
           ARhAyas Productions has found page number discrepancies
         between the earlier and later editions.
                          We have included both.
         558

Numerics
1,000 000 years ago (YA), from 2000 AD 6,
                  123
1,275,000YA 29 
1,353 BC 330
1,458 BC 330 
1,459 BC 330
1,476 BC 330 
1,500,000YA 29
1,670-1,550 BC 330