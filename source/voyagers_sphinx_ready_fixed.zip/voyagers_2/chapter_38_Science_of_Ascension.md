38 
       
      
  

                                                                                                           
                                                                                                          
                                                                                                             Science of Ascension
that consciousness is the result of the body's biochemical/neuro-electrical
functions. Following these erroneous beliefs they draw an equally erroneous
conclusion that consciousness ends at the death of the physical body. Yet at
the same time they are unable to identify the creative, intelligent force
through which an ordered system, such as the body, could be created. Current
scientific thought creates a paradox within itself, as an attempt is made to
define the mechanics of infinite reality within the con fines of the finite, 3-
dimensional mind. This paradox can be overcome once it is realized that
consciousness and intelligence predate the manufacture of the body, and
transcend its finite life span. Once this is realized, science will be confronted
with a whole new order of multidimensional reality, and a whole new science
through which that multidimensionality can be understood. The process of
ascension is not some quasi-religious concept based upon the meandering of
the human mind. Ascension is a highly scientific process of multidimensional
energy mechanics that represent the universal order through which con-
sciousness experiences itself as being. There is an order to the universe, and
there are indeed natural laws of energy mechanics that govern and uphold
the functioning of that universal order. Ascension represents the path of order
through  which  consciousness evolves through a structured, multi  dimensional   system.
     In terms of planetary ascension, this process involves the transmutation
of particles and anti-particles into progressively less dense states of matter,
through which a planetary body is able to evolve from the lower dimensional
frequency bands into the higher dimensional reality fields of the 15-dimen-
sional scale. Ascension also involves the understanding of morphogenetic
fields, or the form-holding energy constructions that allow matter and anti-
matter particles to build into individuated form. The process of personal
ascension involves precisely the same process, as the human is part of the
greater morphogenetic field of the planet, and the progression of dimensional
ascension of the human and the planet are intimately intertwined.  
     Without delving into the technical mechanics of the ascension process,
let us just say that planets and people ascend/evolve through the dimensional
scale through the intrinsic universal laws of energy which form and hold
together the structures of consciousness that form identities in time. Spiritual
ascension is not separate from these laws of energy structure, for conscious-
ness is sentient energy, and must therefore abide by the natural energetic laws
which hold universal structure in order. Ascension is a science, with speciﬁc
mechanics that allow for the evolution of consciousness from simple to more com-
  plex forms.  In the highest states of evolution identity evolves into the highest
dimensional fields and then beyond, moving from the simple forms of biolog-
ical expression into the more complex structures of pure conscious identity.
Every being in existence is involved in this evolutionary process, and so the dynam-
ics of the science of ascension apply directly to each and every one of you.  If you
can realize the signi ficance of this science your evolution will occur much