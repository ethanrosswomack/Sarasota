12 DNA strands were assembled, the body form of the incarnate would progres-
               s ively transmute into a less dense state and ascend into HU-2 on Tara. Origi-
   nally only one Ea rth body was needed for this process, as the form would
               assemble the DNA patterns within the two 12-cycles in one very long lifetime
 and then transmute and ascend.  
    The ascension occurred through the portal from the Sphere of Amenti to
which the incarnate’s dimensional band/time period was connected. Once
passing through its dimensional portal into the Sphere of Amenti, the incar-
nate could enter one of the other portal bridges, and appear on Tara in a
future space/time coordinate, becoming free from HU-1. Through this pro-
cess the consciousness of Tara’s fragmented parts would be returned to Tara’s
planetary grid piece by piece, progressively de-densifying the matter particles
of Earth and transmuting them back into Tara’s grid. As the lost souls
returned to Tara, so did the lost portions of Tara’s morphogenetic field.
         Though the dynamics of this process are complicated, the principle is sim-
ple. The portals within  the  Sphere of Amenti served as a time-portal structure through
which the lost substance/energetic thrust of Tara could be returned, and the lost souls
of  Tara could return to their original identity as souls incarnated upon the planet Tara.
In ancient Taran history this planet had once, long ago (eons before the 560
million year ago Turaneusiam seeding) been located within the First Harmonic
Universe, and had successfully evolved into the fifth dimension and Second
Harmonic Universe. The fall represented a portion of Tara being thrown back
into its own past, through which it had to re-evolve in order for the planet to
evolve into its natural future. The portals within the Sphere of Amenti operated as a
warp in time through which re-evolution could take place more quickly . The human
lineage is an intimate part of that re-evolutionary plan, and this plan is the
underlying hidden dynamic and purpose for present human evolution. This
plan is part of a larger Taran/Gaian evolutionary plan which ultimately will
lead to all consciousness involved returning to its Source.  
         The Sphere of Amenti contains the purposes and mechanics of humanity’ s
evolutionary blueprint. The time portal structures within the Sphere of
Amenti regulate the processes of humanity’s dimensional ascension/evolution
or “return to God.” The portals within the morphogenetic field of the Sphere of
Amenti are known as the Halls of Amenti . They are the dimensional passage
ways one must pass through in order to ascend from Earth, out of the Time Matrix
and dimensionalized reality.  The Halls of Amenti have been a closely guarded
secret since the time of your inception on Earth, and the Priests of Ur and Mu,
their earthly descendants and the ET and metaterrestrial ancestors of your
Turaneusiam lineage from Harmonic Universes two through five have been the
Guardians of this secret since the time of its inception 550 million years ago.