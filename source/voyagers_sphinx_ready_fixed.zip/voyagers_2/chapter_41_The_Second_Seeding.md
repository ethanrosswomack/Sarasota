41 
                                                                                                                            
                                                                                                                                                                                                                    

     
     
        The Second Seeding  
necessary frequency patterns into their DNA, which means they would end up
remaining in the present time cycle, and having to reincarnate into that cycle
to continue evolution. Many of these souls will choose to leave their bodies at
this time so their consciousness can assemble the needed frequencies in time to
catch the ascension wave. The soul, not the personality, will make this deci-
sion. Only natural,  soul-orchestrated  death  transition will allow  for  the   consciousness
to ascend . Suicide will not assist in this process, because, if the soul is ready to
leave its manifest body, the death transition will occur naturally or through soul
arranged events, and not at the hands of an un-awakened personality. We
heartily request, to those who may be thinking along such lines,  do not use sui-
cide as an attempt to release yourselves from the body, for this can actually stop the
ascension process.  If the body cannot transmute, but the soul essence is ready to
ride the ascension wave, the soul awareness will arrange for the appropriate
death scenario. The soul uses the body as a means of assembling frequency pat-
terns into the consciousness, and if the body is released prematurely, the con-
sciousness of the individual may not have reached a high enough level to catch
the ascension wave. The body helps the consciousness evolve to higher fre-
quency, and only the greater soul identity knows when the consciousness has
reached a high enough level to ascend properly. Taking matters into the hands
of the personality, such as is the case in suicide, usually botches the soul's ascen-
sion plan, and during the coming ascension wave it is very important that the
personality allow the soul to direct its ascension process. Under no circum-
stances do we endorse suicide as a way of making this transition. If  you are  still in
a body, then that is where your greater soul identity wants you to be, in order to best
facilitate your evolutionary process.  
    The ascension wave offers the souls of Earth the opportunity to reach
their next level of evolution. This evolutionary ful fillment of Earth was fore-
told in ancient stories as the “Return to the Garden of Eden”  or Man's
Ascension to Heaven.  
    The Seventh Race cycle will occur upon T ara many years in the future.
Presently the Sixth Race cycle is just beginning with the third wave of the
Melchizedek Cloister birthing onto the planet. This cycle represents the transi-
tional race cycle as Earth begins to merge with Tara. This transitional cycle,
and the civilizations that will be built through it, represent the coming Fifth
World prophesied in Native American legend. For over one million years all of
your spiritual traditions have, in some way or another, attempted to prepare you
for this point within Earth's time cycle. In the Fifth World, the sixth races will
evolve, followed by the seventh races, and through this evolution you will tran-
scend the mechanics of death, disease and aging, and rediscover the reality of
the Immortal Body and a fully conscious connection to God. The Seventh
Race cycle will assemble DNA strand 6, and open the potential of ascension to
Gaia (Earth-Tara's HU-3 counterpart) following the Taran cycles. The Cloister