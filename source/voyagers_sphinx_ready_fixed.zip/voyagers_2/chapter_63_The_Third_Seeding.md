63 
                                                                                                               
                                                                                                                                                                                                                              
      

       The Third Seeding  
an interstellar teleport station. The Arc of the Covenant remained stable but
surface conditions were thrown into chaos once again. The pole tilt created
massive ﬂooding in many places throughout the globe, and the rearrange-
ment of some land masses. Once surface conditions stabilized, the races
returned to the surface to rebuild, while the Anunnaki Resistance collected
the Templar-Annu they had rescued and placed them back upon the Islands
of Atlantis, helping them to reconstruct their civilization. Anunnaki of the
Sirian Council remained in Egypt, then extended their influence into
Atlantean Island territory, returning the Atlantean and Annu-Melchizedek
survivors they had exiled in the Inner Earth to the Atlantean Islands, while
slowly swaying a good percentage of the Atlantean Templar-Annu to give up
their Anunnaki Resistance affiliation.  
    Though the Law of One was beginning a resurgence in the Atlantean
island cultures between 30,000-12,500 years ago (28,000 BC-10,500 BC), the
Anunnaki of the Sirian Council, and the Arc of the Covenant which they
continued to protect, remained more vulnerable to Anunnaki Resistance
infiltration, because the Galactic Federation and Sirian Council ﬂeets could
no longer instantaneously come to Earth's defense due to the disruption of
the Giza pyramid teleport station. Around 12,500 years ago (10,500 BC) the
Anunnaki Resistance, angered by the loss of their stronghold in Atlantis,
launched an aggressive air strike against the Sirian Council Anunnaki out-
post on Mars and then in Egypt, in an attempt to destroy the Arc of the Cov-
enant, and claim dominion over the Earth civilization. The Martian outpost
was destroyed. The Sirian Council and various interstellar allies squelched
the takeover attempt and drove the Anunnaki Resistance ﬂeet out of Earth's
vicinity to the distant planet of Nibiru, but they did not arrive in time to pre-
vent the destruction of the Great Pyramid, the Sphinx and various other cul-
tural centers in Egypt. The portal bridge of the Arc of the Covenant survived
the attack, as did the Inner Earth territories, but following this brief
onslaught of 10,500 BC, the pyramids, Sphinx and other Egyptian structures
had to be rebuilt. The Atlantean Islands were not directly involved in these
attacks, though Resistance-Loyal Templar-Annu created minor uprisings
against their Sirian Council Loyalist relatives, until word of the Resistance
defeat drove them into temporary underground seclusion. The Atlantean
Islands continued on with mounting tensions between the two groups, and by
9,500 BC the Resistance-Loyal Templar-Annu had once again regained their
stronghold in Atlantis.  
    In Egypt, following the Resistance attack, the Sirian Council Anunnaki,
Annu-Melchizedeks, Cloister Melchizedeks and Serres-Egyptians rebuilt the
primary structures of their civilization. The ankhs, which had been hidden in
the Inner Earth during the raid, were again brought to the surface, and the
Great Pyramid of Giza, the Sphinx, and several new structures were rebuilt.
The Sphinx and Great Pyramid were placed in their previous locations mark-
64 
                                                                                                            
   

                                                                              
                                                                                                        2017 AD Appointment
ing the fortification of the Arc of the Covenant and Inner Earth portals. The
Great Pyramid was slightly realigned in order to create a Harmonic Reso-
nance link with the Pleiadian star system through the planet Alcyone, which
would allow the structure to be used once again as an interstellar teleport sta-
tion. Because of the disturbances of the Earth grid that occurred during the
Atlantean explosions 30,000 years ago (28,000 BC) the original alignment
with the Sirius B system could not be reestablished. The Third Eye of Horus
portal bridge to Sirius B did remain operational for smaller-scale visitations.
The Earth was now more closely in alignment with the interstellar energy
spirals that ran through the Pleiadian system, and so the new pyramid was
oriented to an energetic alignment with Alcyone.  
 
                                2017 AD APPOINTMENT     
 Earth enters a new 26,556-Year Time Cycle, Ascension Cycles  
                              and the 2017 AD Appointment  
                                22,326 BC - 2017 AD - 4230 AD  
       
    The civilizations of Earth continued to prosper and once again enjoyed
interstellar visitation from their Sirian and Pleiadian allies. Atlantis contin-
ued to digress under the in ﬂuence of a resurgence of the Templar-Annu. The
crystal generators were adapted into devices of torture for those not in com-
pliance with the Templars, and a period of genetic experimentation and ram-
pant power abuses ensued within Atlantean culture. The Arc of the
Covenant and the Inner Earth remained safe under the protection of the Sir-
ian Council as Earth began her next natural 26,556-year cycle of evolution
through the interdimensional time spirals. Earth entered her new 26,556-year
cycle 24,324 years ago in 22,326 BC, with the challenge of rebalancing her
energetic grid following the Atlantean explosions of 28,000 BC. With the
close of the old cycle came a natural period of dimensional blending through
which the Sphere of Amenti could have been re-entered into the Earth core,
but due to the continuing setbacks and necessity for planetary rebalancing,
the Earth grid did not vibrate high enough for the Sphere of Amenti to be
returned. At the onset of the new cycle in 22,326 BC, the Halls of Amenti
would have to remain closed to the masses, as human evolution continued
slowly along its course.  
    The first 4,426 years within the new cycle represented a time of great
promise, for this cycle period constituted the natural point at which Earth
would release two morphogenetic waves, through which masses of people
could ascend to Tara if the Halls of Amenti were opened. The first morphoge-
netic wave was released from Earth in 20,113 BC, the second wave in 17,900
BC, but the populations were unable to ascend as the Halls of Amenti were
not yet opened. Within the 26,556-year natural time cycle of Earth, morpho-
genetic waves are released only during four periods, the first two waves within