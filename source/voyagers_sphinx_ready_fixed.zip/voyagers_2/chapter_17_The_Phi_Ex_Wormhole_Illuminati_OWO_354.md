17 The Phi-Ex Wormhole &  Illuminati OWO  ..............................................354              
       The Bermuda Triangle, Phi-Ex Wormhole, Falcon Matrix and WW II ......354
        The Phi-Ex Wormhole, and the Phantom Matrix “Pit”—1943 ............. .359
          Necromiton-Andromies and the “Unholy Alliance” .............................. .359
        “Big Brother Drac,” the Andromies, Hiroshima and Hitler ..................361