5 Merkaba Field serves to hold Tara-Earth’s morphogenetic field and particle
base in place.  
     Tara-Earth’s D-6 Merkaba field extends thousands of miles out from Tara-
Earth into outer space in HU-2, at the sixth-dimensional frequency level. It
serves to keep Tara’s atmosphere in place and encompasses within its energy
field HU-2 planet Tara, the planets of Tara’s solar system, the planets orbiting
around Alcyone in the Pleiades in HU-1 and all of the planets orbiting
around Earth’s Sun in HU-1. The multidimensional structures of planetary
Merkaba Fields are referred to as Stellar Spirals.  They represent vast con-
structs of electromagnetic energy through which all planetary systems in the
15-dimensional galaxy are energetically connected.  
    The Merkaba Fields of the higher dimensions encompass the Merkaba
Fields of the lower dimensions and all matter forms contained within them.
The frequencies of the 15 smaller-dimensional Merkaba Fields combine to
form larger Harmonic Universe Merkaba Fields. Harmonic Universe Merk-
aba Fields combine to form the largest Merkaba Field, the  Meta-galactic
Merkaba Field.  The Meta-galactic Merkaba Field is composed of a 15-
dimensional, inverted, counterclockwise spiraling magnetic field and an
upright, 15-dimensional clockwise spiraling electrical field. The magnetic
spiral extends from D-1 upward through the Meta-galactic Core at D-8 and
into the 15th dimension. This spiral of magnetic energy serves to draw elec-
trical energy from the anti-particle universe through the dimensional mor-
phogenetic fields in D-9 through D-15, into dimensions 1 through 7 of the
particle universe, then back into the Meta-galactic Core. The electrical spiral
extends from D-15, downward through the Meta-galactic Core and into D-1.
127 
                                                                                                                                                                                                                 

 
   Countdown to Amenti  
The  electrical spiral serves to transmit electrical energy from the Meta-galac-
tic Core, into the anti-particle universe, through the morphogenetic fields,
then into dimensions 1-7 of the particle universe. These are the energy
mechanics through which the universe is perpetually sustained . The Zetas are
aware of these energy mechanics, which gives them a tremendous technolog-
ical advantage over present-day human technological capability. The energy
mechanics of the Merkaba Fields holographically creates the perceptual/experiential
illusions of matter, space and time through the refraction of energy particles. The
reality behind this illusion is an eternal Uniﬁed Field of energy within which every-
thing resides, and out of which all things are composed. The following example
will give you some idea of how that holographic projection tricks human per-
ceptions into the experience of space, time and matter.                                                  
Agartha   
    The civilizations of  Agartha,  the Inner Earth, which exist in a frequency
modulation zone between Earth and its parallel-universe double, between D-3
and D-4 time bands, actually exist at the core of Earth’s Sun, within the 3.5-
dimensional frequency level. Particles in the D-3.5 vibration spin at a 22.5°
reverse angular rotation to the particles in D-3 (Earth’s atmosphere) and at a
22.5° angular rotation to the particles in D-4. (D-4 particles spin at a 45°
reverse angular rotation to D-3 particles). The gold core crystal of Tara-Earth’s
D-4 Merkaba Field  appears as a Sun to those of the Inner Earth. This D-3.5
area is called the Inner Earth because one must travel through the Earth’s
external portals, downward through the Earth into the D-2 Earth morphoge-
netic field, then into the D-1 iron core crystal in the center of Earth (which in
reality exists inside of the sphere of the Sun) in order to re-emerge within the
D-3.5 frequency level of the Sun where Agartha exists. Just as the gold core
crystal of Tara-Earth’s D-4 Merkaba Field appears as a Sun when viewed from
Agartha at the 3.5-frequency level, the iron core crystal of Earth’s D-1 Merkaba
Field appears as Earth’s Sun when viewed from the D-3 frequency level.¹ What
you perceive as the Sun actually represents the iron core crystal D-1 Merkaba
Fields of the 11 planets plus the Sun in your local solar system. Though the
planets and Sun appear to be externalized from the Earth, in reality, the sub-
stance of the Earth and the local planets exists within the energetic substance
of what you perceive as the Sun. (As your Sun is actually the eighth star within
the Pleiadian system, your Sun and its contents are likewise contained within
the energetic substance of Alcyone, the central sun of the Pleiades.) Your D-2
telluric/elemental and D-3 atmospheric Earth, and those levels of the planets in
your local solar system, are in reality orbiting around the iron core crystals of
   ______________________  
1.   Note: your present perceptual field is that of the D-3 frequency bands. You are able to per-
     ceive the D-3 frequency bands as manifest reality because your consciousness is presently
       stationed in D-4.  
128 
    

                                                                                             
                                                                                                   Merkaba Fields
their D-1 Merkaba Fields, which exist within the core of each planet and col-
lectively manifest as your Sun. When viewed from the vibration level of the
third dimension, which is where your consciousness and instruments are pres-
ently focused, the D-1 Merkaba Fields, which exist within the core of Earth and
the local planets, and which are within the core of the Sun, appear to be
located outside of the planets, many miles away in outer space. You are dealing
with multi-layered reality fields that take place in the same space, but appear to
be separated due to the relationship between particle pulsation rhythm and
angular rotation of particle spin.  
    The perceivable experience of movement, passing time, matter, space,
distance between objects and separation of forms is an illusion created by the
multidimensional, holographic refraction of particles and anti-particles,
which pulsate and spin at varying speeds and angular rotations in relation to
each other. The movement of particles itself is a holographic illusion; movement
only appears to be such when consciousness views itself through the layered prisms
of multidimensional order.  It will be centuries before your scientists begin to
comprehend these facts of reality construction. However, while your con-
sciousness is focused within the multiple layers of dimensional reality, the
concepts of space, time, matter and movement will indeed appear to apply, so
we will continue our discussion following that paradigm of perception.
     Y ou can begin to stretch your perceptual and conceptual fields by simply
pondering the following concepts and allowing your intuitive senses to bring to
you a sensed cognition of these realities of which we speak. When you look at
your Sun from the third dimension, you are seeing the D-1 Merkaba Field of
Earth and her sister planets. From the D-3 frequency level, when you view the
D-2 Merkaba Field surrounding Earth’s iron core crystal, which holds Earth’s
morphogenetic field, it appears to be the solid matter makeup of your Earth’s
body and elemental/telluric kingdom. From the D-3 view, the D-3 Merkaba
Field is the Earth’s atmosphere within which your present reality takes place.
The distance of outer space that you perceive between Earth, the Sun and the
planets represents the magnetic repulsion zone that separates the D-1, D-2 and
D-3 frequency bands of HU-1 from the counter-rotating D-4, D-5 and D-6 fre-
quency bands of HU-2.  
     All dimensions exist in the same space, but seem to operate separately due
to the particle pulsation rates of which they are composed. Particle pulsation
rates are created by the degrees of angular rotation at which particles and anti-
particles spin in relation to each other. In one universe there are 15 primary
dimensional bands. Dimensional frequency bands group in sets of 3, and each
set of three dimensions represents a Harmonic Universe. Thus there are five
Harmonic Universes within one 15-dimensional Universe. The degree of angu-
lar rotation of particle spin shifts 90° from one dimension to the next within
one Harmonic Universe. In each Harmonic Universe containing three dimen-
129 
                                                                                                                                                                                                                              
                                                                                                                       

     
     Countdown to Amenti  
sions, there are two 90° shifts of the angular rotation of spin between the parti-
cles. Between one Harmonic Universe and the next there is a 45° reverse
angular rotation of particle spin. This 45° reverse angular rotation of particle
spin creates a Magnetic Repulsion Zone, or “void” between Harmonic Uni-
verses, which keeps the reality fields contained there within separated from
each other. These Magnetic Repulsion Zones are what you perceive as the
seemingly endless vestiges of outer space. Through this structure of relative
angular rotations of particle spin, the holographic illusions of multidimensional
reality, matter, time, space, movement and individuation of form are perpetu-
ally created and sustained. This will conclude our brief introductory lesson in
multidimensional physics; we hope we have provided some interesting ideas for
your more courageous scientists to explore.  
                 THE PHILADELPHIA EXPERIMENT AND SOLAR CRISIS                                     
                                 The Philadelphia Experiment 1943  
     We will now resume our discussion of the Zetas plan to stop the merger of
Earth and Tara’s grid and what they did to the Sun in 1943 that almost caused
the extinction of the human population on Earth in the 1970s.  
    The Zetas determined that in order to retain control of the human soci-
ety within the future space-time coordinates where they had successfully
achieved dominion over Tara-Earth’s territories in the D-4 time cycle, they
had to stop the fifth DNA strand from manifesting within the human popula-
tions of present-day Earth. Re-alignment of the fourth DNA strand by
Guardian groups had broken down their D-4 Frequency Fence and they were
losing control of their human subjects in the future. If the fifth DNA strand
activated within 8% of Earth’s present human populations, the race Morpho-
genetic Field in the Sphere of Amenti would realign the Frequency Fence
distortions in the grids of Earth and Tara, and the Zetas’ Frequency Fence and
Zeta Collective Mind Complex in D-4 would be destroyed. The upcoming
morphogenetic wave period of 2012-2017 in Earth's present time cycle would
allow all Earth humans to begin assembly of their fifth DNA strand and the
D-4/strand-four Zeta Seal would be released in all humans. After 2017 the
Zetas would totally lose control of the future human populations, if they did
not stop the fifth DNA strand from activating within Earth humans and stop
the present Earth grid from receiving its scheduled infusion of fifth to ninth-
dimensional frequencies.  
    From the beginning of their involvement with the covert human gov-
ernments, the Zetas held this secret agenda of Earth in filtration. When they
offered the Allied Governments technological information that helped them
win World War II, the Zetas had ulterior motives. In 1943 the Zetas offered
the U.S. Navy a rudimentary technology that would allow them to make
objects appear invisible. On August 12th, 1943 the experiment was con-
130 
 

                                                     
                                                   
                                      The Philadelphia Experiment and Solar Crisis
 
ducted in Philadelphia, PA, using a battle ship, the U.S.S. Eldridge. The
event became known as the Philadelphia Experiment.  W e will not detail the
experiment here, as there are several published accounts of this event, but we
would like you to understand the Zetas’ motivation for instigating this
project. The Zetas knew that in creating such an experiment, which utilized
the creation of an external, manufactured Merkaba Field, that the functions
of Earth’s natural Merkaba Fields would be disrupted. They failed to share
this knowledge with the US. government. The experiment created a “rip in
space-time,” or a tear in the natural Merkaba Fields, which served as a dimen-
sional warp through which the Zetas could secretly pass their ships to Earth
from their D-4 future location. Using this rip in space-time, the Zetas were
able to transport large numbers of their spacecraft, undetected by human
observation, into Earth’s D-2 Merkaba Field, and, from there, the ships could
be used to broadcast speci fic electromagnetic pulses directly into Earth’s D-1
Merkaba Field at the center of the Sun.  
    Because the Earth is directly connected to Sun through the Stellar
Spirals of the multidimensional Merkaba Fields, the Zetas knew they could
misalign the grids of Earth and Tara by manipulating the Merkaba Fields of
the Sun. They desired to create a Frequency Fence on Earth that would cause
the grids of Earth and Tara to repel each other in 2012. Earth would be
unable to receive its infusion of D-5 frequency, which would stop the fifth
DNA strand imprint from manifesting in the races and keep Earth trapped
within HU-1 for another 26,556-year cycle. They also knew that such a Fre-
quency Fence, applied during the half-point in the second ascension cycle,
would cause a pole shift on Earth, creating cataclysmic changes on Earth,
wiping out the majority of the populations, once the environment had re-sta-
bilized, the Zetas and Dracos planned to claim Earth’s territories as their own.
      The covert human government had no idea of the Zetas’ real plan when they
entered treaties with them during WW2, and they still do not know the extent to
which they have been manipulated by the Zetas.  The Interior Government was
not aware of the dire consequences that could have resulted from these
actions. Violation of human rights through covert forced abductions of citi-
zens for hybridization experimentation was the least of the troubles created 
by the Zetas’ involvement. In 1943 the Zetas used the opportunity presented
by the Philadelphia Experiment to begin their plan of shifting the Earth’s grid
out of alignment with Tara via manipulating the energy fields of the Sun. To
the present day, the Interior Government does not realize that it was this
event which triggered abnormal activity on the Sun between 1949 and 1972,
activity which had some of Earth’s scientific community very concerned
about the probability of a major pole shift occurring sometime during the
1970s or 1980s. The Merkaba Fields of the Earth, the Sun and Tara are inti-
mately intertwined with each other and with the Pleiadian star system and
131 
                                                                                                      
                                                            

      Countdown to Amenti  
others, so following 1943 the Zetas plan brought many different Guardian
groups into Earth's drama.  
    After the rip in space-time was made on August 12th, 1943, the Zetas
secretly positioned their spacecraft beneath Earth’s surface in the D-2 fre-
quency bands and began beaming electromagnetic pulses into the Sun.
Using these EM pulses, the following effects were created:  
    The spin of the base tone particles/magnetic field of the Sun’s D-1 Merk-
aba Field was reversed, which made the Sun’s D-1 magnetic spiral become
electrical. This change in the Sun created a reciprocal shift of polarity within
the D-1 Merkaba Field of Earth. Earth’s D-1 base tone particles/magnetic spi-
ral became electrical. This, in turn, caused Earth’s D-1 electrical/overtone
particle spiral to reverse and become magnetic. Through spacecraft posi-
tioned within the D-4 frequency bands, the Zeta next reversed the spin on
the Sun’s D-4 Merkaba Field, which set the pattern for Tara's grid through
the gold core crystal at the center of the Sun. The D-4 Merkaba Fields of par-
ticle and anti-particle Tara were reversed. These actions constituted a full
reversal of Earth’s D-1 electromagnetic Merkaba Fields, and a partial reversal
of Tara’s D-4 electromagnetic Merkaba Fields, putting both out of alignment
with the Merkaba Fields of D-2, D-3, D-5 and D-6.  
    Normally , when the grids of T ara and Earth begin to enter alignment
with each other about five years before the half-cycle point, the D-1 and D-4
Merkaba Fields line up as follows:  
    Earth’ s electrical overtone spiral in D-1 aligns with T ara’ s base tone mag-
netic spiral in D-4, and Earth’s magnetic base tone spiral in D-1 aligns with
Tara’s electrical overtone spiral in D-4.  
    This alignment of D-1 electrical to D-4 magnetic and D-1 magnetic to
D-4 electrical creates an interdimensional Resonant Tone through which the
planetary grids can fuse. Following the reversal of Tara’s D-4 and Earth’s D-1
Merkaba Fields, the new alignment between Earth’s and Tara’s Merkaba
Fields became D-1 electrical to D-4 electrical and D-1 magnetic to D-4 mag-
netic. The particles, which compose the planetary grids, would magnetically
repel each other and the grids of Earth and Tara could not fuse. But this plan
also causes major imbalance within the D-2, D-3, D-5 and D-6 Merkaba
Fields. If the Sirian Council and other Guardian groups had not intervened, the
human populations of Earth would have been vaporized between 1972-1974.  
    By 1950 Earth scientists began to notice odd phenomena occurring on
the Sun, as the Sun appeared to release periodic spirals of energy toward the
Earth. This phenomenon was heavily observed between 1952 and 1968, and
there was great concern that this solar anomaly would alter the wobble of
Earth upon its axis, creating a pole shift of the planet. Although most of this
information was blacked out of the media and kept from the public, some of
these studies were published in scienti fic journals and news papers, especially
after 1968, when the scientists calculated that if events continued as they
132 
 

                                                                         
                                                                            Solar Crisis and 11:11/12:12
    were, by 1972 there would be a huge explosion on the Sun that would cause
pole reversal and wipe out humanity by about 1984. On August 7, 1972 the
solar explosions began to occur. Earth scientists observed a rapid increase in
solar flares for several days, which peaked on August 7th, with the most
intense ﬂare ever recorded. Solar winds accelerated at an alarming rate in the
most intense solar storm ever witnessed by Earth scientists. Published
accounts of these observations can be found in scienti fic literature from this
time period. The solar winds increased rapidly between August 7th and
August 10th I972, then strangely the winds began a rapid decrease in speed
and the solar storms appeared to die down in the month that followed. This
was a perplexing observation to Earth scientists; they had no idea that the Sirian
Council had intervened.  
                                
                                 SOLAR CRISIS AND 11:11/12:12                                         
                                             Wave-of-Flame and Red Pulse         
      In January of 1972 members of the Sirian Council, Sirian-Arcturian
Coalition for Interplanetary Defense, the Pleiadian Star League and several
other Guardian groups entered the UHF bands of Earth’s atmosphere, aware
of the solar events that were to occur. If they had not intervened, Earth’s
populations would have been wiped out by 1974. When the electromagnetic
Merkaba Fields of the Sun are artificially manipulated, such as they were by
the Zetas following the Philadelphia Experiment, erratic electrical energies
build up within the Sun’s energetic grid, throwing all of the Sun’s Merkaba
Fields out of balance. As the misalignment of the Sun’s EM fields progresses,
it manifests as an acceleration of solar- ﬂare activity, which eventually culmi-
nates in surface explosions and temporary expansion of the Sun’s Merkaba
Fields, lasting about 950-970 years.  
      In 1972, the first explosions began to occur . The explosions would have
continued until about September of 1973, when the Sun’s D-1 Merkaba Field
would have burst open and expanded. The expansion of the Sun’s D-1 Merke
aba Field would have sent an intense wave of ULF energy out through all of
the planets in the local solar system. This wave of energy would cause a
chain reaction within all of the planetary Merkaba Fields, through which
pole reversal and vaporization of surface life would result. This wave of
expanding D-I energy is called a Red Pulse (red denoting its D-I frequency),
and it constitutes a wave of solar ﬂame within the D-1 frequency bands. Life-
forms on planets in the First Harmonic Universe cannot survive such an infu-
sion of ULF D-1 energy, because it would implode the molecular structure
before the genetic code could expand enough to process those frequencies.
    In order to avert the pending termination of Earth life, the Guardian
races, under the direction of the Sirian Council, altered several layers of the
morphogenetic fields of Earth and the local planets. As the Red Pulse Wave
133 
                                                                                                                                                              
                                                                                              
  

      Countdown to Amenti  
of Flame would be coming in on the electrical overtone D-1 frequency bands,
all of the D-1 overtones were temporarily removed from the planetary mor-
phogenetic fields. This served to create a D-1 seal around Earth’s core, so the
ULF of the Red Pulse could not enter Earth’s grid, or the grids of the neigh-
boring planets. Next, a frequency seal was placed within the D-4 frequency
bands, in order to block D-4 frequencies from entering into Earth’s morpho-
genetic field. Once the overtones of D-1 were removed, Earth’s core could
not synthesize incoming D-4 frequency, and the core would explode, so D-4
frequencies had to be temporarily blocked from Earth. To create the D-4 seal,
the first 11 (out of 12) base tones and overtones of D-4 were removed from
Earth’s morphogenetic field, which meant that Earth’s lower three Merkaba
Fields connected with the D-4 Merkaba Field only at the level of the 12th
base tone and 12th overtone. These morphogenetic manipulations created
another Frequency Fence, which served as a protective barrier around Earth
and the neighboring planets. In energetic terms the  1 1:1 1/12:12 Frequency
Fence  took the form of a spherical band of energy surrounding Earth, within
the D-1 and D-4 frequency bands —a protective “bubble” of multidimen-
sional energy.  
    Following the implementation of the Guardians’  Frequency Fence,
humanity was under three layers of frequency modulation, the original Fre-
quency Fence Quarantine from 9540 BC, the Zeta Seal Frequency Fence
from 1748 AD and the 11:11/12:12 Frequency Fence of 1972. All three of
these Frequency Fences would need to be lifted in order for the Blue Flame of
Amenti to become embodied on Earth between 2012 and 2017. As Fre-
quency Fences are morphogenetic manipulations, they also manifest within
the DNA imprint of the races. The DNA of 8% of the human populations
would have to be realigned and purged of the three Frequency Fence Seals
and the remaining mutations from the earlier Amenti, Palaidorian, Templar
and Templar-Axion Seals by January 1, 2012. Guardian races began conduct-
ing mass-level, consensual, soul-agreement abductions of humans since 1972,
in order to help humans begin repairing these genetic mutations, and also to
begin education on preparation for 2012. Memory repression tactics were
used to spare humanity the terror of facing events that it was not yet prepared
to understand. The Zetas had been conducting frequent forced abductions
since the late l940s as part of their hybridization program. They also used
memory repression tactics. Guardians did not participate in these forced
abductions, nor did they participate in intrusive experimentation.  
    When the 11:11/12:12 Frequency Fence was established in 1972, the
Guardians knew it was a temporary measure to buy the time they needed to
rebalance the Merkaba Fields of Earth and the Sun.  Balancing the Merkaba
Fields was the most important project in the Guardian agenda.  Since 9558 BC,
when the islands of Atlantis sank and the Earth tilted on her axis, the Guard-
ians knew they would have to assist in realigning the Merkaba Fields of Earth
134 

                                                                              Solar Crisis and 11:11/12:12
before the 2012-2017 ascension cycle. Following the events of 1943-1972,
this re-balancing effort would be much more dif ficult to achieve. Originally
the Guardians planned to slowly accelerate the vibration rate of Earth’s grid
through occasional infusions of D-4 energy that would slowly bring the grid
into alignment and correct the pole tilt over the course of about 2,000 years.
These occasional energy transmissions began in 196 BC, when Earth entered
its present 4,426-year cycle. In their original plan the Guardians intended to
raise Earth’s grid vibration into the UHF bands of the third dimension begin-
ning in the 1950s, so the first seal on the Arc of the Covenant could be
released no later than October of 1986. Following the release of the first seal
on the Arc, the Sphere of Amenti would begin its 12-14 month descent into
Earth’s core.  
    The Sphere of Amenti had to be in place no later than 1/1/1988 so the
Sphere would be able to ful fill the first 12-year phase of its activation cycle no
later than 2,000 AD. Once the Sphere was fully activated to the 3-dimen-
sional level in Earth’s D-2 core, it would cause Earth’s grid to send a spark of
D-5 frequency into the Arc of the Covenant, releasing the second seal on the
Arc. This would begin the 12-year descent of the Blue Flame of Amenti and
the shift of Earth from the D-3 to the D-4 time cycle. The second seal on the
Arc of the Covenant had to spark open no later than 6/1998 so the shift into
the D-4 time cycle would begin by 1/1/2000, in order for the Earth’s grid to be
prepared for proper fusion with Tara’s grid between 2012-2017. The D-5 fre-
quencies of the Blue Flame had to be embodied within the populations of
Earth, no later than 5/5/2012, or else Earth changes would result when the
grids began to merge.  
    When the Zetas’  Frequency Fence and genetic mutation from the
future began affecting Earth in 1748, creating blockages of the D-4 frequen-
cies in Earth’s morphogenetic field and fourth-strand DNA mutations in the
races, the Guardians began construction of an arti ficial D-4 grid imprint
within the Earth’s morphogenetic field. They re-entered the aligned D-4 fre-
quency patterns into the gold core crystal D-4 Merkaba Field at the center of
the Sun, which began to restore the D-4 imprint in the Earth’s morphoge-
netic field and within the Sphere of Amenti. This allowed the Guardians to
continue infusing Earth with D-4 frequency to slowly reverse Earth’s unnatu-
ral tilt on its axis. This arti ficial D-4 imprint also began the deterioration of
the Zetas’ Frequency Fence and a reverse mutation of the fourth DNA strand.
The new D-4 imprint manifested as a band of UHF energy surrounding the
outer portions of the Earth’s atmosphere, about 444,000 miles out in space,
just beyond the 12th overtone of the third dimension. It allowed human
consciousness to continue its expansion into D-4 perception and allowed the
Earth’s infusion of D-4 energy accelerations to continue. This arti ficial D-4
grid which the Guardians began constructing in 1748, has frequently been
referred to in New Age terminology as the “ artificial Christ Consciousness      
135                                                                                                                
                                                                                                                   
                                                                     

        Countdown to Amenti  
Grid ”. This term was chosen because the upper frequency bands of D-4 rep-
resent the beginning levels of the Turaneusiam 12-strand DNA conscious-
ness, which was exempli fied on Earth by Jesheua-12 in 12 BC-27 AD. When
the problems arose with the Zetas’ manipulation of the Sun between 1943-
1972, the arti ficial D-4 grid became blocked by the 11:11/12:12 Frequency
Fence.  
    In 1972, the Guardians had to accelerate their whole energy infusion
program in order to reverse the damage the Zetas had caused, which meant
that humanity would be put on a course of very rapid evolution between 1972
and 2012. For the arti ficial D-4 grid to become operational again, the 11:11/
12:12 Frequency Fence had to be removed, which meant that the D-4 and D-