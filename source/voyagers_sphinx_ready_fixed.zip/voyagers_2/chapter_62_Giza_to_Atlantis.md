62 
                                                                   

                                                                                              
                                                                                              
                                                         Giza to Atlantis
Council Anunnaki. The Anunnaki of the Sirian Council developed a strong
hold in Egypt for a time, creating a system of pyramids and other structures
that housed a network of power points through which energy was drawn from
the great crystals of Atlantis, through the Earth's grid lines and into desired
locations. About 35,000 years ago the pure Melchizedek Cloister race began
their first full birthing wave into human civilization, reinforcing the teach-
ings of the Law of One and bringing their fifth DNA strand potentials into
the human genetic pool. Guardianship of the Arc of the Covenant was
slowly turned over from the Sirian Council Anunnaki to the Annu-
Melchizedeks, Cloister Melchizedeks, Hebrew (hybrids of fifth race Cloister
Hibiru and the sixth race Cloister Melchizedeks created through the Host
Matrix Transplants of the Second Seeding), and the Serres-Egyptians, all of
whom became members of the early Egyptian priestcraft.  Since the times of
their creation, the Sphere of Amenti (550 million years ago) and the Arc of the
Covenant (840,000 years ago) were the primary foci of human evolution as the
purpose and process of the human evolutionary imprint was held within the secrets
of Amenti.  
                Guardian Alliance & Galactic Federation Intervention  
                                            28,000 BC-10,000 BC          
    The Templar-Annu grew progressively more hostile within the territories
under Sirian Council protection, and many relocated to Atlantis, which was
becoming the Templar-Annu strong hold. Angered that they were not per-
mitted to enter the Inner Earth or use the Arc of the Covenant, the Templar-
Annu devised a plan to conquer the Inner Earth territories by using the
Atlantean crystal generators to tear down the electromagnetic barriers that
secured the Inner Earth portals. The Templar-Annu began their conquest
from the continent of Atlantis, but quickly discovered the Inner Earth portal
shields could not be easily destroyed. As they forced excessive power through one
of their main generator crystals, the crystal unit exploded, with more than 10 times
the force of an atomic bomb.  Several other smaller generators also exploded,
ripping apart the continent of Atlantis and sending the majority of its land
mass under the sea. Following the explosions of 30,000 years ago (28,000 BC),
the Atlantean land mass was reduced to three islands and most of its popula-
tions were destroyed. Just prior to the explosion, the Sirian Council removed
various groups from Atlantis, distributing them throughout various locations
on the globe, many being taken to Egypt for re-settling. The Egyptians were
forewarned of the coming event, and most of the culture retreated under-
ground into Inner Earth communities, finding shelter from the Earth changes
that would result from the explosions.  
    During the explosions in Atlantis, the Earth was tilted slightly on its axis,
throwing the Earth's grid out of balance, breaking the energetic link between
the pyramid of Giza and Sirius B.  The Great Pyramid could no longer function as