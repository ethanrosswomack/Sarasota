3  Other as-yet-undiscovered “Head” sculptures exist in other areas of the globe as well, cre-    
                                     ated at various times to mark planetary grid positions signi ficant to activation of the Faces
                                     of Man LPIN.   
                               372  

   
      The Sacred Cow, Faces of Man, Easter Island Heads and the Trion Field
of Man” LPIN of Earth emerges from a central point  in Earth’s geography in
the Gulf of Guinea , where the '' chins '' of the “four heads” meet at Longitude
0° and Latitude 0°, where the vertical Greenwich Meridian intersects the
Equator. From this center point, each “head” extends as a pillar, two running
horizontally east/west, one above and one below the equator, and two
running vertically north/south, one on each side of the Greenwich Meridian.
The “four Pillars of the Faces of Man” intersect again, where the “front tops
of their heads” connect at Longitude 180° E-W and Latitude 0°, near
Howland Island  in the Equatorial Center Paci fic Ocean.  (See APIN
diagrams pp. 527-530.)  
   T h o u g h  F a l l e n  A n g e l i c s  h a v e  m a d e  n u m e r o u s  a t t e m p t s  a t
compromising the four Faces of Man LPIN system since its installation in
22,500 BC, none have succeeded in “cracking its coding.” The four Faces of
Man LPIN runs on what is called the Khundaray/Kee-Ra-ShA Primal Life
Force Currents  from dimensions 13-14-15 and the Trans-Harmonic
“Trion” Currents  from beyond this Time Matrix. These powerful interstellar
frequencies are far beyond the range and power of those accessible to Fallen
Angelic races. Once brought into critical mass activation , through Humans
and Indigos running “Tri-Veca Rainbow Roundtables,”  the four Faces of
Man and Guardians of the 12 Pillars LPIN system will rapidly clear and
override Planetary Shield distortions  caused by the APIN systems of the
Fallen Angelics. Activation of the four Faces of Man will progressively bring
the Emerald Covenant '' Great White Lion '' and ''Golden Eagle '' APIN
systems fully into original working order, allowing Earth’s grids to remain
balanced as the Phantom Matrix wormholes are sealed  during the 2001-
2004  period of the present SAC. The Great White Lion, Golden Eagle and
the four Faces of Man are the ancient '' Guardians of the Four Corners of
the Earth. '' If humanity assists the Emerald Covenant races in “ Awakening
the Ancient Guardians ''-the LPIN/APIN  systems  left behind as our
Lumerian/Atlantian Legacy—further progression of the UIR OWO
dominion agenda can be averted.                           ____________________________________________________________      
                   If we do not assist, the Illuminati agenda will continue,
         leading humanity into global War, physical “Intruder ET” Invasion,
                                    and pole shift between 2003-2008.                         ____________________________________________________________           
      If we do not think the potential dangers of the Fallen Angelic/Illuminati
OWO agenda are real, perhaps  this  point  will  be  ''driven home''  if  we  explore
a bit more about how the agendas of the Falcon, the Dove, the Serpent, the
Phoenix and the Dragon have unfolded since 1951. It is the progressive
advancement  and  final   amalgamation  of     these   fallen   Angelic   agendas  that
brought us to the ''Trigger Event '' of the September 11, 2001, WTC/Pen-
tagon  Terrorist Attack, and the grim   reality of   progressive international
war that this Trigger Event was intended to set in motion .  
373                                    
                                                                                                                              
                        
                                                                                                                

                        
                        The Hidden Game-board Final Conﬂict Drama
                                                           THE FALCON, PHOENIX PROJECT
                                   AND THE ANDROMIE-RIGELIAN COALITION 1951-1983                                          
     In 1951,  the Alpha-Omega Necromiton-Andromie-Anunnaki
accepted “deals” of collaboration offered b the Jehovian Anunnaki “Dove”
collective , through which they would combine the stolen ''White Eagle '' and
the specialized Jehovian '' Dove '' APIN systems . (See APIN diagrams pp.
527-530.) Together, the '' White Eagle'' and the ''Dove '' would attempt to
open the second ancient Atlantian Wormhole, the ''Phoenix Wormhole ,'' in
order to claim dominion over the Zeta-Rigelian/Drakonian Falcon
Wormhole and Phi-Ex Port Interface Network. The Eagle-Dove Anunnaki
collective was unable to successfully open the Phoenix wormhole, at
Axiatonal Line-7/Ley Line-4 , until the opportunity presented itself in 1972
as other Anunnaki forces who controlled the ancient Phoenix and Serpent
APIN systems  accomplished the feat for them. Presently , due to the 1951
Alpha-Omega Necromiton and Jehovian Anunnaki alliances, the “ Eagle
flies with the Dove,”  and since September 12, 2000 , these combined forces
have made further deals with the '' Falcon, '' ''Phoenix ,'' ''Serpent '' and
“Dragon,” to form the collective anti-Christiac force of the UIR OWO
dominion campaign. The Jehovian Dove and Necromiton-Andromie “White
Eagle” progressively launched sonic scalar pulse  transmissions throughout
the 1950s,  in hopes of opening the ancient Phoenix wormhole to defeat the
rising Zeta-Rigelian/Drakonian Falcon. The Sonic Pulse  and '' Ethnic Virus ''
testing programs  of the covert '' Falcon '' were accelerated in the 1960s, when
they and the Drakonian Illuminati began using the Falcon Network to create
targeted climatic and seismic disturbances  to further their hidden political-
positioning agendas  in the international arena. The Andromie-Necromiton
White Eagle and Jehovian Dove forces continued a quiet invasion strategy of
building subterranean and marine bases in key Star Gate control areas of
Earth, and began making more direct contact with key controllers in several
Illuminati factions. The various competing Pleiadian and Nibiruian
Luciferian Anunnaki forces  were “in a tizzy ,” as they watched their long-
cosseted, exquisitely orchestrated, Atlantian take-over agenda become
progressively “hi-jacked” by the Drakonian force.  
     In 1972  the Zeta-Drakonian Falcon force began to expand the next
intended wave of territorial conquest, attempting to use the Phi-Ex
Network  to gain control over the Anunnaki’ s “prize possession,” the Great
Pyramid of Giza, Egypt . Since Atlantis, Planetary Star Gate-4 at Giza has
assisted the Anunnaki in controlling the D-4 NET,  as it is the site where
Universal Star Gate-4 , the D-4 astral Solar Gate , connects to Earth’s
Planetary Shields. The Luciferian Anunnaki intervened directly in 1972,
in a partially successful attempt at preventing the Zeta-Drakonian Falcon
Phi-Ex Network from overtaking Anunnaki holdings at Giza. The  Pleiadian
Samjase-Luciferian-Anunnaki  made alliances with the Nibiruian Enlil-
Odedicron-Reptilian Anunnak i. Together they used the portions of the
NDC Grid, the NET and Nibiruian Crystal Temple Network that they could
collectively access, to expedite the agenda they had originally intended for
the 2000 commencement of the SAC.  
374    
                        
                           

     
                                                                                                 
                                                                                              The Falcon, Phoenix Project...
    The '' Phoenix Project ,'' which had existed since the beginning as part of
the 9560 BC Luciferian Covenant, was actively launched in February 1972.
The Pleiadian/Enlil-Nibiruian Anunnaki force simultaneously transmitted
sub-space scalar sonic pulses  from Density-2 Alcyone and the Nibiruian
Battlestar “Wormwood”  into the D-4 Solar Gate  to Giza (Ley Line-4), Iran
(Star Gate-10) and into Earth’s NDC-Grid at Stonehenge, England
(Axiatonal Line-l1, or A11). The specialized A11-L4 pulses  merged at their
intersection point  in the Atlas Mountains  of W . Algeria then traveled west
beneath the Atlantic Ocean to their intended destination, the second of the
two “capped” Atlantian Wormholes , referred to since Atlantian days as the
“Phoenix Matrix .” The Phoenix wormhole, opened by the Pleiadian-
Nibiruian Anunnaki in 1972, is positioned directly at the interface point  of
Ley Line-4, the '' Giza Horizontal ,'' and Axiatonal Line-7 (vertical), which
intersect off the coast of St. Augustine, FL , in the Atlantic, directly south
of the Falcon wormhole.  The “Frequency W ar” began in earnest when the
Necromiton-Andromie White Eagle and Jehovian Anunnaki Dove began
aggressive territorial conquest campaigns, gaining partial control of the
Phoenix Wormhole, in an attempt to protect their interests from the
advancing Pleiadian-Nibiruian Anunnaki competition.  
     As the Pleiadian-Nibiruian “reptile Anunnaki league ” advanced their
agenda, the Jehovian Dove and Necromiton-Andromie White Eagle  began
more direct contact with their Illuminati Sleeper races. Enoch , then heading
the Jehovian Dove OWO agenda, produced his “training manual” to lead
unsuspecting Humans and Illuminati Sleepers to assist in bringing the Dove
APIN system into activation . Although Enoch and some of his Jehovian
Anunnaki (Sirius A, Arcturus, Trapezium, Orion) petitioned for Emerald
Covenant Redemption Contracts in 1983 , the “Jehovian OWO Agenda”
has been continued by the Jehovian Anunnaki majority and their Illuminati
contacts under the name of Enoch, much to Enoch’s present disapproval. The
White Eagle Necromiton-Andromie league  began upscaling its
''Harvesting '' agenda,  orchestrating numerous contacts with Illuminati and
Human individuals to “invite” them into their Templar Alpha-Omega Order
“Melchizedek Priesthood.” Ordinands and followers alike received,
unknowingly, astral field Tagging  linking their DNA Templates  to the
Necromiton-Andromie Matrix, through which they could unknowingly pass
on the “same privilege” to others in the form of false  “Melchizedek
Ordinations.”4 As the Jehovians, Necromiton-Andromies and Zeta-
Rigelian/Drakonians progressively advanced their agendas throughout the
1970s into the early 1980s , giving rise to more international “political
issues” of territorial conquest, the Pleiadian-Nibiruian Anunnaki continued
their own conquest efforts.  
    A  series of smaller EM scalar pulses were used by the Pleiadian -
Nibiruians  between 1972 and 1980  to progressively open the ancient
Phoenix APIN system,  which connects to the Phoenix wormhole. The
Phoenix APIN  is a large APIN system running East-West along the L4/L10
                          ____ ________________
                         
                                4.    Nothing outrages the Founders quite as much as observing the sacred Melchizedek Clois-
                                           ter Emerald Covenant spiritual-science teachings abused and misused in such a way.    
                                375                                                            
                                                                                                                                                               

                                                                                                                                         
                        
                        The Hidden Game-board Final Conﬂict Drama
                  Giza-Iran center line.  The '' hear''  of the Phoenix is Star Gate-4 Giza,
Egypt ; the ''eye'' of the Phoenix is Star Gate-10 Abadan-Iran  (near Persian
Gulf); the body of the Phoenix extends across the Atlantic and North
American continent; and its wings spread eastward to “meet its tail” in the
Pacific Ocean. (See APIN diagrams pp. 527-530.)  
     In 1976 , another Nibiruian Anunnaki  contender, the Thoth-Enki-Zeta
group , temporarily joined the Pleiadian Samjase-Luciferian and Nibiruian
Enlil-Odedicron reptilian Anunnaki contingent to activate the '' Serpent ''
APIN system.  The '' Thoth group ,'' most frequently affiliated with the
''Galactic Federation '' mixed Anunnaki league and the Necromiton-
Andromie Anunnaki  early alliances following the fall of Atlantis, “turned
coats” for a brief period, just long enough to receive the assistance of the
“Phoenix” group in activating the Thothian Serpent APIN system. The
Serpent APIN system has its “head” in Central America and Mexico. It coils
southward into northwestern South America, back northward, spanning the
entire eastern USA, then stretches across the Atlantic Ocean, with its
“heart” at England Star Gate-11, its body curving down through the Middle
East and Star Gate-4 Giza, and its “tail” extending north through Eastern
Asia. (See APIN diagrams pp. 527-530.) By 1983,  the Thoth group returned
to its “White Eagle” affiliations, once again competing with the Pleiadian-
Nibiruian Anunnaki of the Phoenix Project, while the Galactic Federation
focused upon supporting whomever appeared to be leading in the Fallen
Angelic “race” for final OWO dominion.  
       
                           ANDROMIE-RIGELIAN COALITION, THE DRAGON, BIN LADEN
                                          AND THE “WAR ON TERRORISM” 1980-2001                 
   By the early 1980s, Pleiadian-Nibiruian Anunnaki legions  had made
alliances with various factions of the regained strongholds within several key
positions of the Illuminati World Management Team,  threatening previous
Zeta/Drakonian Illuminati dominion. In hopes of retaining Zeta/Drakonian
dominance within the covert global Interior Government sector, Zeta
Rigelian  races of Rigel Orion petitioned the assistance and collaboration  of
the Necromiton-Andromie  races. The Rigelians negotiated between
Drakonian-sympathetic factions of the “White Eagle” Necromiton-
Andromies, and the Omicron-Drakonian and Odedicron-Reptilian legions of
Orion, forming the Andromie-Rigelian Coalition ; a ''friendly enemies '' deal
aimed at disempowering the advancing ''Phoenix Project'' Anunnaki
Illuminati influence on Earth. Not all Necromiton ''White Eagle'' factions
agreed to participate in the pro-Drakonian agenda Andromie-Rigelian
Coalition,  due to favored connections among the '' Dove '' Jehovian
Anunnaki races. The factions of the White Eagle Necromiton-Andromies
that favored the Zeta-Rigelian/Drakonian Falcon agenda entered the
Andromie-Rigelian Coalition, and began using their access to White Eagle
APIN sites to further the Falcon agenda. The White Eagle Necromiton-
Andromies opposed to the Falcon agenda  offered greater support to Jehovian
Anunnaki Dove  factions, and Ashtar Command’s  ''Arcturian '' Anunnaki
lent their assistance to the White Eagle-Dove cause. Many Drakonian,
Reptilian and non-Rigelian Zeta forces, opposed to or fearful of the  
376 
                 
                 

          
   Andromie-Rigelians, Dragon, bin Laden and the “War On Terrorism”...  
Necromiton-Andromie force, refused to enter the Andromie-Rigelian
Coalition deals, and the Drakonian/Reptilian Illuminati races began
breaking into opposing factions,  causing ripples of further instability within
the external world political drama.  
    The majority of Omicron-Drakonians5 of Alnitak Orion, and a large
faction of Odedicron-Avian-Reptiles  from Alnilam-Orion, refused the
Andromie-Rigelian Coalition ''White Eagle-Falcon'' deal, and set their sights
on activating their ancient '' Dragon '' APIN system,  which had been
implanted in Earth’s grids in 75,500 BC.  The Dragon APIN has its “head” in
what is now far eastern Siberia  and northeastem China  and Japan . Its long,
thick “body” extends westward across Asia, the Middle East, Africa, Russia,
Europe, crosses the Atlantic ocean to the Central USA and south into
South America. (See APIN diagrams pp. 527-530.) The majority of the
''Dragon '' agenda races also refused to join the UIR  deal of September 7-
12, 2000, choosing instead to “fight to the end” for the Omicron/Odedicron
Drakonian OWO agenda.  
    In our contemporary drama, the Islamic extremist faction  called the
Taliban of Afghanistan , is headed by several, well-placed Illuminati that are
covertly motivated by the Omicron-Odedicron ''Dragon '' agenda  Fallen
Angelics. The terrorist group of Osama bin Laden , on the other hand, works
a ''double-agenda '' on behalf of the UIR Zeta-Rigelian “Falcons” and the
Omicron-Odedicron Dragon force. In the WTC/Pentagon drama  of
September 11, 2001, the bin Laden group was covertly motivated by the
UIR to assist them in creating the “ Trigger Event ” that is intended to set the
''wheels'' of the WW3 drama  in motion. The UIR also knew that this event
of bin Laden terror would ensure that the rebelling Dragon agenda Taliban
Illuminati would be forced out of power in Afghanistan , making way for
UIR governance. As the UIR intended, the many Angelic Human and Maji
populations of Afghanistan  would be ''conveniently'' reduced in number
through orchestration of this international drama. The bin Laden terrorist
group evolved first under the Falcon agenda  in the 1970s, covertly motivated
by the Zeta-Rigelians with Psychotronic scalar pulses, to '' build the
movement '' that was  intended  to become a Falcon '' Sleeper Cell Force ,''
once the Final-Conflict WW3 drama had begun. Due to the UIR’s present
acceleration of their OWO dominion plan , the bin Laden group was instead
used to set the UIR WW3 drama in motion.  
    The Eieyani tell us that there are numerous such '' Illuminati Sleeper
Cells '' of various ethnic, cultural and religious backgrounds  in at least 15
different countries . Various Fallen Angelics began organizing these
Illuminati factions in the 1950s-1960s , in order to ''have them in place
awaiting their awakening,'' when the Final Conﬂict began. The
contemporary '' War On Terrorism '' goes much deeper and ''higher '' than
world political leaders suppose ; it is a war that cannot be won until the
causal element of the hidden Fallen Angelic/Intruder ET presence is fully
identi fied. The Final Conquest for Star Gate and Templar control site
dominion is on, and the WW3 drama is the method by which the Fallen
                             _________________________
                             5.  Dragon-moths   
                                                                                                                377                                                                                                                    
                                                                                                                                                                                                                                                

                           The Hidden Game-board Final Conﬂict Drama
Angelics of the UIR intend to lay claim to desired territories, while
reducing numbers of Angelic Human and Indigo Children populations .
     Areas such as Pakistan, Iraq and Iran  are territories housing key access
sites to the coveted  Star Gate-10,  so these areas, as well as several others,
will be preliminary “zones of conquest”  that the UIR will attempt to secure
under UIR Illuminati governance. Egypt, home of the OWO key control site
Star Crate-4, will experience sporadic areas of rebellion as “Dragon” agenda
Illuminati races are motivated by the Omicron-Drakonian forces to resist the
national-compliance inherent to UIR objectives.  
    Tibet , home of Star Gate-9 , is also precariously perched to become the
objective of competing Dragon and UIR-Dove “affections.” Jerusalem,
Israel,  has long been a battleground for control of Primary Planetary
Vortex-2,  a direct link to Star Gate-2,  the Gru-AL  “Holy Grail Point” of
Sarasota, Florida , which is the '' control gate '' for Earth’s Planetary Shields.
And the U.S.A . has been, since formalization of the Luciferian Covenant in
9560 BC Atlantis , the intended arena  within which the Fallen Angelic
Final-Con ﬂict drama '' Battle of Armageddon '' is planned to unfold, making
way for the '' Rise of the One World Order. '' The Emerald Covenant races
have repeatedly returned to Earth incarnation in attempts to prevent this
Fallen-Angelic-devised ''End Times '' scenario  from occurring.  
          
                   MONTAUK PROJECT, “WAR IN THE HEAVENS, ”  
            SONIC PULSE AND “UN-NATURAL DISASTERS” 1983  
    Through the Andromie-Rigelian Coalition deals of the early 1980s ,
Illuminati races originally running the Falcon agenda under command of the
Rigelians and the Zeta Treaties suddenly found their 1930s Zeta Treaties
were nulli fied. The fate of the Drakonian Illuminati was placed forcefully
and precariously in the hands of the new, fully dictatorial Necromiton -
controlled Andromie-Rigelian-Coalition.  T o strengthen the Necromitons’
covert access to Earth territories, the 1983 Montauk Project  was organized
by the Necromiton-Andromie White Eagle  and Zeta Rigelian/Drakonian
Falcon  forces, through cooperating (and now terri fied of rebelling) Illuminati
factions.  
   Through the Montauk Project, the Phi-Ex Wormhole from 1943 was
“spliced into,” directing a main channel to Necromiton-Andromie Alpha-
Omega Centauri territories in the adjacent Phantom Time Matrix . The
Necromiton races now had extensive access to Earth territories, and they
began a covert genocide program  against Illuminati races that would not join
the Andromie-Rigelian Coalition. The Illuminati fiasco of the 1930s-1940s
turned into the Illuminati chaos of 1983.  In response to the threat of the
Andromie-Rigelian Coalition, the Omicron-Drakonian  forces of Alnitak
Orion  sent large fleets into the Density-26 and Density-37 territories
surrounding Earth-Tara-Gala, with the intention of protecti ng the interests
of the original Drakonian/Reptilian Dragon OWO agenda. In response to
this advancing Drakonian/Reptilian presence, various competing Anunnaki
________________________  
                              6.    Dimensions 4-5-6.  
                                 7.    Dimensions 7-8-9.
                               378                                                                                                               
                                                                                                                                             
   

                                                                                                  
                                                
                                         Guardian Intervention and the Bridge Zone Project 1983-1992
legions of Sirius A, Arcturus, Pleiades-Alcyone, Nibiru, Andromeda,
Orion, the Galactic Federation and Ashtar Command  sent ﬂeets of
reinforcements into proximity of Earth access points.  
    Warring  in Densities 2 and 38 broke out between competing Anunnaki
and Drakonian/Reptilian forces, in both our Time Matrix and the Phantom
Matrix. The '' war above '' became the covert  ''War of Frequency '' below , as
each group intensi fied its use of sub-space sonic scalar pulse technologies  to
secure their holdings of various APlN sites. The progressive use of covert
sonic pulse technologies, which was progressively accelerated by the Fallen
Angelic legions since the  1950s , was directly responsible for a host of
regionally cataclysmic “natural disasters,”  particularly those involving
Earthquake and Hurricane  events. (“Sonic Pulse “Un-Natural Disasters”
1935-1992 Summary Chart” on page 522.)  
                            
                                     GUARDIAN INTERVENTION  
                AND THE BRIDGE ZONE PROJECT 1983-1992 
      Throughout this mess of interstellar chaos at our earthly door , Emerald
Covenant Maharaji  fleets from Sirius B , Tara and Gaia and the many
interstellar Emerald Covenant nations have tried to sustain a frequency
“buffer zone ” around Earth access points. The GA, Eieyani and Founders
have done their best to prevent this growing intergalactic “Battle of the
Angelic and Fallen Angelic Kingdoms” from descending into Density-1
Earth territories. The Emerald Covenant Founders races of Lyra Aramatena9
intervened directly . They became aware that by  2976  Earth would be
destroyed, before the intervention opportunity  of another SAC  could occur,
if Zeta Rigelian/Drakonian occupation of Earth was successful during the
2000-2017 period. Between 1983-1984  the Founders, GA, lnterdimensional
Association of Free Worlds and Emerald Covenant nations created the
Bridge Zone Project  crisis-intervention plan (see page 142).  
   Through tenets of the Bridge Zone Project initiative , Amnesty
Contracts were offered to any interstellar races in our Time Matrix willing to
enter the Emerald Covenant Peace Treaty. Redemption Contracts  were
offered to the Fallen Angelic/ET races from the Phantom Matrix, in which
they would receive the extensive assistance needed  to become free from the
Phantom Matrix Time Cycles, if they would enter and honor the Emerald
Covenant. Many non-Rigelian Zeta races  accepted Amnesty and
Redemption Contracts, fearful of the building “ Super-Stellar-powers Final
Conflict” drama.  Guardian races were hoping that Anunnaki legions  could
be persuaded to give up their long-held OWO dominion agenda to make a
United Emerald Covenant Stand  against the dominant Drakonian/Reptilian
Necromiton-Andromie/Zeta-Rigelian “Falcon” force. Smaller factions  of
some Anunnaki collectives, such as the Jehovian Enoch collective  of Sirius
A, Arcturus and Orion, gave up their previous OWO Jehovian Anunnaki
dominion agenda  in 1983 for Emerald Covenant Redemption Contracts.
___________________________  
8.    Dimensions 4-9.