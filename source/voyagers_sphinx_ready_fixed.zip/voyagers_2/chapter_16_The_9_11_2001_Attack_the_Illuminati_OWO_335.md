16 The 9/11/2001 Attack & the Illuminati OWO ..........................................335 
           “ UFO I nvestigation” and “Trigger Events”. ............................................336
           One World Order (OWO) Master Plans, GA State of War Alert
                  and Imminent Crisis Order ................................................................. .337
           Star Gate-6 and the Selenite Crystal Temple Network .......................... .339
           Trion-Meajhé Fields and Expedited Amenti Opening . ..........................342
           The October 1999 Classified Document, Psychotronics,
                   Montauk and OWO  .............................................................................344
           Sleepers, Terrorists, Remote Viewing, RITs and the NET... .................. .347