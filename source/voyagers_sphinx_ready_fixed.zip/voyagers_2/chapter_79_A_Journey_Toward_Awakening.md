79                                                                                                                
                                                                                                               
                                                                                                       
   

A Journey Toward Awakening  
nation are designed. Through the Frequency Fence the Ego became cut off
from conscious relationship with its personal morphogenetic field and from
the morphogenetic fields of its race and the planet. The Ego awareness felt
itself to be isolated and separate from the world around it, and could not per-
ceive the creative principle or purposes through which it came to be. Human
consciousness became “locked within the illusion of matter” as a result of the Fre-
quency Fence, unable to perceive or comprehend the reality of non-manifest sub-
stance through which all manifest things are created. Human consciousness lost
touch with the common Source within and behind all things, and so lost its ability to
identify with and comprehend the beings and things that appeared to exist outside of
itself.  Humanity's connection to the Universe remained a reality, but the Ego
awareness lost the ability to consciously perceive that reality. The Egotistical
mind perceived itself as limited and finite, and so developed an overly aggres-
sive need to dominate and control its external environment as a means of
attempting to insure its survival. As humans evolved to view themselves as
finite creatures at the mercy of a seemingly hostile external environment, the
lower Egotistical mind became isolated, lonely and very frightened. Healing
of the Egotistical mind would require its integration with the Higher Self
mind, through which its power and place within the universe could be under-
stood.  
      The Higher Self mind could not only perceive in the highest frequency
bands of the third dimension, it could also “plug into” the D-4 astral identity
and the soul matrix identity that is contained within the fourth-, fifth- and
sixth-dimensional frequency patterns of the Amenti morphogenetic field.
The Higher Self allowed the fourth and fifth DNA strands to begin manifest-
ing, if those strand imprints were contained within the race DNA imprint.
As long as the Frequency Fence was operational the Ego could not translate
higher dimensional data into conscious awareness, nor could it translate the
comprehension of the Higher Self mind. But the elemental aspects of the
human body, the portions of consciousness manifesting through the second
DNA strand that are focused within the second-dimensional frequency fields,
could translate portions of the Higher Self cognition, as the 10th-12th over-
tones of DNA strand two could translate some of the electrical impulses from
the 10th-l2th overtones of DNA strand 3. Strand two had already been
altered through the Seal of Palaidor, creating the division between the D-2
emotional identity and the D-3 mental awareness which created the sub-con-
scious mind, so the portions of the Higher Self perceptions that could trans-
late through the D-2 strand appeared within the body through the sub-
conscious mind, appearing as felt emotional response. The Higher Self com-
municated data to the conscious awareness via sub-consciously sensed feel-
ing, that became known as the Intuitive Sense. Intuition represents information
from the Higher Self sent to the conscious awareness via the body and sub-conscious
mind.