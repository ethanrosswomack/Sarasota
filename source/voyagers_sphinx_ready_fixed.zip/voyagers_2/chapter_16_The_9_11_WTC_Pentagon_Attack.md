16 
                                                                                        
                                             
                                                              
                                    
                  The 9/11 WTC/Pentagon Attack
                                      and the
                      Illuminati One World Order                
          Due to the continuing barrage of “stop-the-presses” new emergency
release information provided by the Guardian Alliance (GA) since the
United Intruder Resistance (UIR) Edict of War on September 12, 2000,
preparations for this updated Second Edition (2e) printing of Voyagers II  has
taken far too long. Information that was originally intended to become a
simple glossary for this book rapidly expanded in size to become another book
in its own right. This partially completed new book was then quickly put “on
hold” as a progressive series of GA emergency release dispensations rapidly
accumulated over 400 pages. Meanwhile, our Planetary Shields Clinics
workshop and site work excursions were scaled up to top GA priority,
solidifying into an immediate Crisis Intervention Program  called the
Emerald Covenant Masters Templar Planetary Stewardship Initiative . As
we began our new Ireland-England Planetary Shields Clinics tour in July
2001,  I was able to finally complete the “2001 Update” and related materials
for Voyagers II  , 2e. After a year’s worth of frustrating but unavoidable delays,
the lovely people with Saintly Patience at Granite Publishing could finally
''put the book to rest'' with ful fillment of its second printing— or so we all
thought . As this book was about to go to press in September 2001, the
''unbelievable '' occurred.  The events of September 11, 2001 , which we
have all rapidly come to know so well, intruded into the American heartland
and homeland with all of their inherent, numbing, horrific fervor, and “life as
we’ve known it” in the USA was suddenly and abruptly “changed forever.”
The events of the 9/11/2001, terrorist attacks  upon the NYC World Trade
Center Towers  and the Pentagon  in W ashington, D.C., have literally and
rapidly cast not only America, but literally the entire world,  into a
completely new and utterly “alien” uncharted political landscape , the
implications of which most peoples of all nations are presently struggling to
comprehend.  
   The old American expression of shared national mourning and
cultural, mental and emotional fixation that was once expressed by a
generation before in the query of “Where were  you when Kennedy was shot?”
     has now been permanently deposed from its once-prominent position within
      335 
                                                                                                                                               


                                                                                      
 
The 9/11 WTC/Pentagon Attack and the Illuminati One World Order  
the national collective mind. The old question has now been indelibly and
forcefully replaced within THE collective cellular memory of the American
psyche  by the query of “ Where were you on 9 /11/2001?”  within this
general question and ''query of our times'' the answer to which is fully
branded into the memory of many American citizens, resides the even more
important silent questions of '' What in the world is going on? '' and '' How
will all of this affect us ?'' The horrific events of 9/ll, and even more so their
potential rami fications, have made questions regarding the “Kennedy
Assassination” and other unresolved issues and shocking moments of our
collective past seem almost irrelevant. Events prior to the Trade Towers/
Pentagon attacks literally pale by comparison to anything we have known
since WW2. Due to the collective “emotional-mental stun factor” generated
by the “9/ll Disaster,” and the obvious resultant aftermath  of “ major
movement within the global political landscape ” that now dominates the
focus of world attention, many previously important questions may fall
away from mass attention . In some cases such environmentally forced
redirection of our mental and emotional focus from fixation on past events
and issues represents a potential healing catharsis within the collective
psyche, as individuals and nations begin to reassess and redirect their
priorities. But in other cases, distraction from pertinent past concerns can
prevent us from acquiring the very answers we seek concerning the     
contemporary drama .       
    
              ''UFO INVESTIGATION” AND “TRIGGER EVENTS''  
    One of the most important multifaceted issues  that might readily and
“conveniently” succumb to further malnutrition of mass attention is the
highly complex issue of '' UFO investigation. '' The “UFO issue” is, in truth, a
compendium of a  variety of  interrelated subjects:  “UFO sightings”; crop
circles; ET visitation/abduction; the “UFO Movement”; the “New Age
movement”; “angelic” contact; “channeling” communication; “spiritual
development”; “ascension teachings”; “official denial”; “Illuminati One-
World-Order agendas”; “forbidden archeology”; and the multitudes of
related, politically charged, '' conspiracy theories '' one must inevitably
address if thorough investigation of the “UFO issue” is to be ascertained. In
our present drama, seemingly born of very “3-D international political
issues,” it is more important than ever to keep questions of the “UFO
issue” firmly and foremost in mind.  The answers to the most ominous'
''silent questions'' of “What in the world is going on? and ''How will this
affect us?'' do not reside within the well-orchestrated “3-D political forum”;
these answers exist squarely within the core of the “UFO issue.” The tragedy
of the Trade Towers/Pentagon Attack is a global “wake up call” for 
''things unknown as-yet-to-come .'' Unfortunately, such an event, which
could serve as our greatest catalyst for mass awakening, is instead being
utilized to serve as our greatest mass distraction from the knowledge our
world most needs to rapidly comprehend.  In the immediate aftermath of the
911/2001 Terrorist Attack, three of the greatest and fully justifiable
unspoken questions  within the minds and hearts of the courageous people
who have supported the GA work since 1999 were as follows. “ Did the GA
know this attack would occur ?” “If not, and the GA supposedly knows so       
336         

                         OWO Master Plans, GA State of War Alert and Imminent Crisis Order
        much, then why didn’t they know ?'' ''If they did know, then why didn’t
they stop it or warn us? '' Along with questions regarding GA awareness, the
same questions were understandably directed toward myself, and
my associates MC.'' Did we know? '' “ What did we
know? '' ''Couldn’t we, through our GA Guardian contacts, have done
something to prevent it ?'' 
    As this book was ready to go to press, the “Unbelievable Events” of 9/
11/2001, unfolded, and with them a massive wave of personal and public
questions that cried out for answers. Though the final text of this book was
intended to be complete with the “2001 Update” material, Granite
Publishing rightly and wisely requested that a further update covering the
Trade Towers/Pentagon Attack  be provided as conclusion to Voyagers II  2e.
As “fate” or '' Divine Synchronicity '' would have it, the printing deadline for
this book had not yet passed when these monumental events of mass mayhem
occurred. In this final emergency release update of Voyagers II  2e, I will do my
best, as GA representative Speaker, to address the most obvious questions
regarding the “9/11 Disaster.” More importantly, I will try to brie ﬂy explain
within the limited space remaining in this book, the relationship between
the “9/11 Disaster” event and the GA emergency release materials that we
have been progressively teaching within the public forum since the end of
2000.  It is within our understanding of the '' Big Picture '' drama  that Real
comprehension  of events such as the “9/11 Disaster” can be gained. Real
comprehension is essential if we are to recognize that this seemingly isolated
event of international horror represents the greater reality of what is called a
''Trigger Event ,'' which is an external, mass event that is covertly
orchestrated by seemingly unrelated ''hidden forces '' from “behind the
scenes”—an event that represents the “pressing of the start  button” within
the invisible Illuminati World Management Team machine. Trigger Events
are orchestrated strategically from off-planet sources  in order to set in
motion, through remote psychotronic mobilization  of the unsuspecting on-
planet Illuminati force,  a series of national and global changes  that are
intended to move the global arena toward fulfillment of hidden Fallen
Angelic/Intruder ET objectives. It is through understanding these hidden
objectives  as they exist behind and within the global drama that we, as
individuals and nations, are empowered to choose educated, effective action
through which the ideals of peace, freedom, brotherhood and love can be
attained .  
               OWO MASTER PLANS, GA STATE OF WAR ALERT  
                              AND IMMINENT CRISIS ORDER   
    The '' 2001 Update '' materials  preceding this text were completed
and submitted to the publisher in early July 2001 . They contain a brief
summary of GA emergency release dispensations  that have been
progressively provided since the September 12, 2000, Edict of War  was
issued by the Fallen Angelic/''Intruder ET'' UIR .¹ Before any obvious
                
       ________________________________  
         
                          1.     Anunnaki/Andromie/Centaurian/Zeta/Drakonian/Reptilian/Illuminati “Unholy Alliance"
                                     
                            337  
                                 

                                                                                                                              
The 9/11 WTC/Pentagon Attack and the Illuminati One World Order  
indication  was made apparent within the “external world,” the GA ’ s
information provided since September 2000 and brieﬂy summarized in the
original “2001 Update” section of this book, revealed that contemporary
Earth is caught within a long-anticipated, “presently hidden ” inter-
dimensional, Interstellar War. A war that would become “all too real” to
us in “3D” terms  if humanity was unwilling to assist Emerald Covenant
nations in peacefully securing Earth’s Templar/Star Gate Complex  from
further Fallen Angelic/Intruder ET/Illuminati in filtration before 2003.
Within the GA security release dispensations we were gently shown that not
only was humanity facing the challenges of planetary physics  inherent to
natural SAC’s, but we were also faced with progressively growing obstacles
created through the actions of “human” Illuminati  races manipulated by the
Fallen Angelics. The 2001 GA revelations exposed the long-term, highly
organized and progressively orchestrated Fallen Angelic directed Atlantian
Conspiracy² '' Illuminati OWO Master Plan ,'' which has been a core
commonality between the various competing Fallen Angelic/Intruder ET
races since 9560 BC Atlantis.  This information revealed the true scope  of
the drama we are presently in3, the scope of this drama and the long-term
Illuminati OWO Master Plan is massive  and “bone chilling” (if you don’t
understand the peaceful solutions).  
    Of greatest signi ficance, the 2001 GA revelations brought into focus the
details of the intended stages  of the contemporary phase  of the Illuminati
Master Plan , so we can become aware of the basic progression of events we
would see  should the Illuminati Master Plan advance. When the Anunnaki
races defected from the Emerald Covenant to support the UIR’s September
12, 2000, Edict of War, the various Illuminati OWO Master Plan agendas of
previously competing Fallen Angelic/Intruder ET factions were blended into
a dominant uni fied strategy . This uni fied strategy combined various previous
initiatives of several Fallen Angelic groups into the UIR Illuminati OWO
Master Plan,  directed by the Necromiton-Andromie  force. Renegade Fallen
Angelic legions of Omicron-Drakonian,4 Odedicron (Reptile-avian),
Necromiton5 and rebel Anunnaki who refused to join the UIR are still
attempting to orchestrate their original OWO agendas, but all have lost
critical amounts of support from Earthly Illuminati collectives. As of October
2000,  the predominant force  within the covert Interior World
Government ( see Voyagers I ) Illuminati World Management  Team  is now
the UIR Fallen Angelic collective. This '' shift in Illuminati administration ''
has already become subtly apparent within the external, political
maneuverings of various nations since October 2000 . The subtle shifts
(and some not-so-subtle) within our global political arena, which have taken
place since October 2000 in response to the covert influence of the
September 2000 UIR Edict of War, represent only the beginning
externalization  of the UIR OWO agenda into the visible “Official Reality”
arena.  
                             ________________________________
                   2.     See  Forbidden Testaments of Revelation , forthcoming.
                     3      lbid.
                     4.     Dragon Moth
                     5.     Andromie Beetle-insectoid-hominid 
                  338   
                 

                                                 
                                                                
                             Star Gate-6 and the Selenite Crystal Temple Network
                                                      
                                                      STAR GATE-6  
                       AND THE SELENITE CRYSTAL TEMPLE NETWORK  
                
    Since the GA ’ s direct intervention with initiation of the Bridge Zone
Project  in 1983 (see “The Bridge Zone Project” on page 142), the GA  have
been peacefully and diligently working to prevent advancement of the
various competing Fallen Angelic/Intruder ET and Illuminati OWO agendas
on Earth. Through the peaceful tools  of inter-stellar Emerald Covenant Co-
evolution Peace Treaty negotiations and strategically applied and directed
Masters Inter-Galactic Templar Mechanics , there was great hope of avertin g
the long-anticipated 2000-2017 SAC Final Conﬂict drama. The GA had also
explained from the beginning that whether or not Illuminati OWO
dominion agendas could be averted would depend a great deal upon the
progression of choices  made by both earthly Human and Illuminati
collectives.  Though several major victories in the name of Human freedom
have been peacefully won through progression of the GA Crisis Intervention
Initiative, the realities of potential advancement of Fallen Angelic and
Illuminati OWO dominion agendas has not, as yet, been brought to an end.
Alongside the recent collection of strategic victories won through the GA
Peace Effort,  there have also been numerous setbacks.  The most notable
recent setbacks to the GA Peace Effort are the September 12, 2000,
Anunnaki defection from the Treaty of Altair and resultant UIR Edict of
War , and recent challenges associated with the Montauk Project . These
issues of inter-stellar political setback have spawned further, mounting
concerns regarding the challenges of planetary physics  posed by the
progressing 2000-2017 SAC. Emerald Covenant nations have not only
entered a State of War Alert  in response to the building tensions, continued
volatility and the September 2000 Edict of War within the inter-stellar
political  drama —they are also under a State of Imminent Crisis Order . The
Imminent Crisis Order was issued due to the progressively increasing
instability of Earth’s planetary Templar Complex  and potentially
cataclysmic reactions, in terms of planetary physics, that may now occur
during the 2000-2017 SAC as a result of the UIR’s more aggressive use of EM
scalar pulse technologies.  
    During our Labor Day 2001 workshop  of September l-3, the GA
provided a new level of high security data pertaining to two areas of pending
crisis.  Attending Indigo Children were asked to assist Emerald Covenant
nations in an immediate Top Priority Crisis Intervention strategy , and we
were provided with additional introductory training in even more advanced
Masters Templar Mechanics, called “ Veca-Code Mechanics ,” and planetary
healing outreach. The first area discussed was that of the present acceleration
of Stellar Wave Infusions  (see “Stellar W ave Infusions” on page 466) into
Earth’s Planetary Shields. In  May 2001 , as necessitated  by the September
12, 2000,  Anunnaki defection from the Treaty of Altair agreements, the
Maharaji Council triggered early activation of the D-6 Sirius B Star Gate
(Density-2), in order to begin overriding Nibiru’s Photo-sonic hold  on
Earth’s planetary Merkaba, Templar and EM fields. If this initiative were not
taken, the Anunnaki of the UIR intended to use the Nibiruian Templar      
339                    

                                            
    
                    The 9/11 WTC/Pentagon Attack and the Illuminati One World Order
connection to force cataclysmic pole shift  on Earth by 2008; Earth’s Templar
had to be freed from its arti ficial Nibiruian alignment by 2003  or pole shift
could not thereafter be prevented. Star Gate-6 was not originally scheduled
to enter its opening cycle until 2008 , four years after the 2004 opening cycle
of Star Gate-5 Alcyone. One of the greatest challenges  posed to Earth by
expedition of SG-6 activation is that of retaining the delicate EM balances
of the planetary grids  as Earth’ s Planetary Shields6 rapidly activate in
accelerated sequence  in response to ampli fied and expedited D-4, D-5 and D-