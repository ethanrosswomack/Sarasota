12 Fire Letters  (12 Fire Letters per Dimension x 1 dimension of manifest-
          tation = 12 Fire Letters).  
      • When Fire Letter Sequences in a Manifestation Template are in natural or-
        der ,  the frequencies in different dimensional bands can  merge  with each
           other.  
  • The 12 Fire Letter Sequences (144 Fire Letters) inherent to the 12-Strand
      DNA  T emplate of each Angelic Human Race in each Evolutionary
      Round correspond to the 12 Fire Letter Sequences  that compose Earth’s
      Planetary Shields . The DNA Templates of each Race in each Evolution-
       ary Round holds a specific portion of the Fire Letter Sequences corre-
          sponding to Earth’s Planetary Shields.   
     • As an Angelic Human Race Round evolves on Earth, the correct Fire Letter
    Sequences of the Universal Christos Divine Blueprint, the D-12 Shield
    of Aramatena  (Earth’s D-12 Pre-matter Liquid-Light Template) transfer
   from the Angelic Human DNA Template into Earth’s Planetary
     Shields.  This transfer of Fire Letter Sequences, or scalar-standing-wave                                                                                                                             
       frequencies, takes place through the Universal Kundalini, Maharata, Kee- 
  291                                                                                                                
                                                                                                                      
            

        The Angelic Human Heritage and Rainbow Roundtables  
   
    Ra-ShA  and Khundaray Life Force Currents that run through the human
     body and Planetary Shields. The process of Fire Letter  Sequence transfer
      from Angelic Human DNA  to Earth’ s Planetary Shields functions proper-
     ly only if the DNA  T emplate Core carries the correct  Fire Letter Se-
      quences  corresponding to the Universal Christos Divine Blueprint
    natural order  of the 12 Dimensions of manifestation within the Universal
       15-Dimensional Scale.           
              ANGELIC HUMANITY’S ORIGINAL SACRED MISSION  
       •  The Divine Commission  of the Angelic Human Race, the Sacred Mission
        for which we were originally seeded on Earth, is to correct the Fire Letter
        Sequences within Earth’s Planetary Shields , which were damaged dur-
      ing the “Fall from T ara” 550 million years ago. This Divine Commission
         is called the Christos Realignment Missio n. 
      • The four Evolutionary Rounds  of the Angelic Human Cycle of the
        Rounds were seeded simultaneously , each within their own Time Cycle
          that is synchronized with the others. The Angelic Humans and all other
             life forms on Earth during each Evolutionary Round all serve a role in an-
          choring a specific portion  of the Fire Letter Sequences  of Earth’ s D-12
          Shield of Aramatena Divine Blueprint.       • The Angelic Human race was commissioned as the  Guardians of the Plan-
      etary Christos Realignment Mission.  The Angelic Human DNA T em-
      plate is designed to carry the correct arrangements of Fire Letter
       Sequences that correspond to the core program  of Earth’ s Planetary
      Shields. If Angelic Humans are not present on the planet, and do not  suc-
      cessfully complete their intended role  during SACs,  Earth’ s damaged
     Planetary Shields can  not synthesize  the infusion of interdimensional
       frequencies  from Earth’ s opening Star Gates. In this event, Earth’ s elec-
         tromagnetic fields reverse polarity  and the planet enters pole shift  during
          a SAC . 
     • The Angelic Human Races of Earth were commissioned to serve as the
        “Frequency Transducers” for Star Gate Frequency  during SACs; a
        “Collective Buffer Blanket”  to prevent pole shift on Earth during SACs,
        while progressively re-setting the Planetary Christos Divine Blueprint
            in Earth’s Planetary Shields.  
     • As the Star Gate frequencies of the Universal Life Force Currents run
              through the human body and DNA  T emplate, the DNA  T emplate pro-
             gressively sends the corrected Fire Letter Sequences  back into Earth’s
        Planetary Shields.  With a  critical mass  of Angelic Humans transmitting
          the corrected Fire Letter Sequences into Earth’s Planetary Shields dur-
          ing a SAC,  Earth’ s grids will progressively receive the Fire Letter Se-
       quences needed for the Planetary Shields to synthesize the Star Gate
                  frequencies normally.                    
                    •  Infusion  of the correct Fire Letter Sequences enables the planet to retain                                
              its natural electromagnetic balances and axis alignment  during  SACs .
                •  If the Angelic Human races in each of the four Evolutionary Rounds  can
                   simultaneously fulfill their part in running the correct Fire Letter Se-
                         292  
     
    

                                                                               
                                   Angelic Humanity’ s Original Sacred Mission
    
          quences into Earth’s Planetary Shields during  a SAC, the Planetary
           Christos Realignment Mission will be successfully completed. Comple-
          tion of the Planetary Christos Realignment will create a natural “D-12
          Planetary Maharic Seal”  in Earth’ s T emplar Complex Star Gates, Ley
          Lines and V ortices. A  natural Planetary  Maharic Seal will return the po-
           tentials of Immortal Life, Star Gate travel and Self-Directed Ascension
           to the Angelic Human Races of Earth, while protecting Earth and human-
               ity from any further Fallen Angelic infiltration.  
    • The last SAC occurred on Earth in 208,216 BC  during the First Evolution-
   ary Round of the Palaidia Urtite-Cloister Race 12-Tribes . In our                    
present Time Continuum, the Palaidia Races were invaded  by Fallen An-
      gelic Drakonian Races from Orion and were unable to successfully com-
     plete their intended Divine Commission. Earth entered pole shift in
                    208,216 BC,  the Palaidia Empires were destroyed and survivors were re-
     settled to begin the Second Evolutionary Round  of the Cycle of the
          Rounds.  
   • Earth’s Planetary Shields have encountered progressively more misalign-
        ment  and corruption  since the failed 208,216 BC SAC. The pattern of
        Fallen Angelic Invasion culminating in pole shift that was set during the
        last consummated SAC has repeated in each Evolutionary Round since
        the pattern was set in 208,216 BC  in our Time Continuum. This Plane-
           tary Karma  pattern is presently set in Earth’s grids as a misaligned series
        of Fire Letter Sequences,  which will cause the pattern to repeat again
           during the 2000-2017 SAC.  
   • Pole Shift  in our present Time Vector can be averted by realigning the cor-
                   rected Fire Letter Sequences in Earth’s Planetary Shields  between
       2001-2012 . This will enable Earth to shift into Trans-Time Alignment
         with the Time Continuum in which the other three Rounds of the Chris-
         tos Realignment Mission are occurring successfully ; the Christos Re-
            alignment Mission will thus finally reach completion . 
                  
                     293                                                                                                         

                                                                
                                                                     The 12 Tribes and the Roundtables
                       THE 12 TRIBES AND THE ROUNDTABLES
  • The 12-Tribes of the four Rounds of the Angelic Human Cycle of the
  Rounds Evolutionary Divine Blueprint were seeded on earth specifically
   for the purpose of serving the Sacred Commission of fulfilling the Plane-
   tary Christos Realignment Mission.  
 • Each of the 12-Tribes in any one Evolutionary Round was composed of var-
    ious combinations of the 5 Primary Races manifest within that Evolution-
    ary Round.  
 • The DNA Templates of each of the 12 Tribes were encoded with the DNA
    Signet Codes encrypted into the DNA  T emplate and each Tribe was seed-
   ed on the two primary locations affiliated with the Star Gate number to
         which the DNA Signet Codes corresponded.  
 • Though numerous periods of Earth changes have occurred since the Round-