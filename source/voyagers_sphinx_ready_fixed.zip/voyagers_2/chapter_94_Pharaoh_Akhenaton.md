94 
      

                                                                                      
                                                                                                             Pharaoh Akhenaton
a traitor in 1348 BC by the corrupt Serres-Egyptian Priesthood at Thebes (with
whom he had been raised in childhood), tortured for his knowledge of the
secrets of the Arc of the Covenant, then executed in 1344 BC.  
    Sabatoth left behind him a legacy within which lived the hope of the
Keepers of the Blue Flame. A child was born to Ihopetohetep, the wife of
Sabatoth, several months after he was incarcerated in Thebes in 1348 BC.
The child was named Tutankhaton. Haremhab and the Keepers of the Blue
Flame kept the child’s true lineage hidden and orchestrated a marriage
between this child and Akhenaton’s third daughter Ankhesenpaaton. In
1340 BC Smenkhkaré was assassinated by Haremhab’s secret guard, and 8-
year old Tutankhaton was proclaimed Pharaoh. In order to avert the suspi-
cions of the Serres priesthood, Haremhab arranged for the royal couple’s ini-
tiation through the Serres priesthood at Thebes, where their names were
changed to Tutankhamon and Ankhesenamon. Tutankhamon acted as a
puppet Pharaoh under the direction of Haremhab and an elder councilor-
priest named Aya, and the capitol was again moved from Akhetaton at Tel el-
Amarna to Memphis, so activities at Giza could be more closely monitored.
Originally Haremhab intended to uphold his commitments as a Keeper of the
Blue Flame. This required a slow but steady integration of the belief systems
of the Amonist and Atonist peoples. Under mounting pressure from the
Serres-Egyptian priesthood at Thebes, Haremhab succumbed to taking
actions which appeared to be more politically correct, and the teachings of
the Law of One became lost as he influenced Tutankhamon to abandon all
Atonist sympathy and revert to old Amonist perspectives. Having loyalties
to the Keepers of the Blue Flame, Tutankhamon attempted to resist Harem-
hab’s campaign.  
    In 1331 BC, when the 17-year old Pharaoh Tutankhamon was suffering
from an illness, several of Haremhab’s advisors took matters into their own
hands and poisoned him, removing the primary obstacle to Haremhab’s new
direction and ending the nine-year reign of Tutankhamon, the child king
(1340 BC-1331 BC). Haremhab quickly appointed the aging Aya, a long-
time friend and Serres-Egyptian sympathizer, to the Pharaonic throne. Fall-
ing hopelessly under the manipulation of the Serres-Egyptian old order,
Haremhab appointed himself Pharaoh following the death of Aya in 1324
BC. In order to preserve his political standing, Haremhab methodically set
about destroying any evidence of his prior affiliation with the Atonist move-
ment and involvement with the Cloister Melchizedek Keepers of the Blue
Flame. Haremhab reigned as Pharaoh from 1324 BC until his death in 1309
BC, appointing Rameses I as his successor. Following the death of Aya in
1324 BC, the Melchizedek Cloister Keepers of the Blue Flame became scat-
tered throughout Egypt, being considered criminals of the state for their prior
affiliation with Akhenaton. Some found refuge within the secret ranks of the
Serres priests at Giza, who still worked under the directive of the Priests of