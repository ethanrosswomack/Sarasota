29 
                                                                                                                   
                                                                                                       
 
                                                                                                                           
                                                       

 
                                                T he Second Seeding
bodies on Earth and within the parallel system. Root Race three Lumarians,
now Lamanians,  had strand one and the base codes of strand 2, their Ur-
Antrian Cloister had these plus the imprint for 7-12.  
    All of the races of the Second Seeding carried trace codes of the Pleia-
dian-Sirian Dagos. Races of the Second and Third Seeding, like their ances-
tors of the First Seeding, also carried grounding codes within their
operational DNA strands, which contained partial frequency patterns for
each of the 12 dimensions within the 12-strand Turaneusiam imprint. The
grounding codes allowed each race to manifest with some degree of three-
dimensional, physical matter density and also allowed for transmutation of
the physical matter particles once the overtone activation codes were opera-
tional. Though all of the races carried the grounding codes, not all could acti-
vate them because of the Seal of Amenti. As long as the Seal of Amenti, the
missing sixth overtone of the first DNA strand, was contained in their mor-
phogenetic pattern, none of the races could activate the grounding codes of
the higher dimensions. As races 3-5 of the Second and Third Seeding would
be born with the Seals of Palaidor and Amenti, only those whose imprint
contained the fourth DNA strand (the Fifth and Sixth Root Races) had the
potential to activate all of the grounding codes to ascend.         
    The Fifth Root Race, which was also born with the Seal of Amenti, held
the hope of activating the grounding codes, if they could fully assemble their
fourth DNA strand. This would give them astral plane/D-4 mobility of con-
sciousness through which they could pass into their Cloister morphogenetic
field on the astral plane, then merge with their double there, through which
the Seal of Amenti would release from strand 1. Then strands 2 and 3 could
plug into their doubles and into strand 4. Once strands 1-4 plugged into each
other, the matter particles would begin to fuse within their anti-particles,
which would activate or fire the fifth, sixth and seventh grounding codes,
allowing the body to fully transmute through the Blue Flame and the Halls of
Amenti to reappear on Tara.  
  The Sixth and Seventh Root Races and their Cloisters carried the
remaining fifth and sixth DNA strands of the 12-strand package. Neither of
these races entered full manifestation during the Second and Third Seedings.
The Sixth Root Race are the Muvarians, their Cloister the Melchizedeks,
they will assemble DNA strand number 5, corresponding to the fifth-dimen-
sional frequencies and represent the transitional race cycle through Earth’s
ascension passage into merger with Tara. The Melchizedeks are a blended
race carrying various racial strains. Though they represent the Cloister that
originally began the yellow-skinned races on Earth, they are not limited to
manifesting through this racial line. Melchizedeks appear within strains of all
the races as they became involved as a Host Matrix/surrogate morphogenetic
field for many of the races toward the end of the Second Seeding. The
Melchizedeks carry DNA strands 1-4 and the base codes of 5, plus the