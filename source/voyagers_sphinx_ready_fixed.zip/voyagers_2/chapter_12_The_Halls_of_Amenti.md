12
           
                 

                                                                                   
                                                                                                              
                                                                                                              The Halls of Amenti
                                       The Staff of Amenti Blue Flame Morphogenetic Field
                                                                The Ivory Gates of Tara
                                                                          25,000,000 YA  
        
     Once the Halls of Amenti were created 25 million years ago, the priests
   of Ur on T ara drew out from T ara's fifth-dimensional core a pattern of fre-
       quency that represented the morphogenetic field for the entire planetary grid
      structure. They removed from T ara the morphogenetic field through which
    T ara drew its energy imprint for its grid line structure and matter form. By
    removing this form-holding energy field from Tara's core, Tara could no
    longer build a bridge of frequency between its core and Gaia's core at the
   eighth-dimension Metagalactic core. This removal of T ara's interior morpho-
  genetic field was done out of necessity. If the morphogenetic field had
 remained within T ara's core, T ara's progression of dimensional ascension into
   the Third Harmonic Universe would have continued, up to a point. When
  the planetary grid of T ara had pulled in the remaining frequency bands from
  the Uni fied Fields of dimensions 5 and 6, through the morphogenetic field at
 its core, it would next begin to pull in the frequencies of the seventh dimen-
  sion and begin its ascent into the Gaian planetary grid structure. This is the
 natural path of evolution for a planet. However, if the seventh-dimensional
 frequency bands entered and expanded T ara's morphogenetic field, certain
 portions of these frequencies could not plug into the grid lines of the planet
 as they needed to do, because portions of these grid lines had been ripped
  apart during the fall event.  
     The energy carrying the frequencies of D-7 that could not pass into the
 framework of the planet's energetic structure would build up within the mor-
 phogenetic field of Tara's core, eventually causing the entire grid system and
 the planet to explode. The morphogenetic field of Tara had to be temporarily
 removed from the planet's core, which would leave T ara with the ability to
 draw energy through its grid from the Uni fied Fields of Dimensions 4 through
 6, but would not allow any higher frequency energies to enter into its grid sys-
 tem. This meant that T ara would be trapped in the time bands of Harmonic
 Universe 2, unable to evolve out of those frequencies until its morphogenetic
  field had been returned to the planetary core. The planet had to remain con-
  nected to its morphogenetic field in order to retain its form, but the field could
     not be stored within the planet structure.  
     The morphogenetic field of Tara had to be placed within the portions of
   the original morphogenetic field that had been blown apart, broken down
    among the 12 HU-1 planets. Each of the 12 planets would hold a portion of
   T ara's morphogenetic field, and Tara could draw in sustaining energy from