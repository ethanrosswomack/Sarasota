27  
                                                                                                                                                                                                                                                                       
      
     


                                                                                                              
                             The Second Seeding  
  became semi-dense physical beings upon merging with the morphogenetic
  field of humans from the Second Seeding. Much later the Kantarians founded
  the Kantarian Federation,  gaining approval from the HU-1 Galactic Federa-
  tion to serve as a guardian and educator race for Earth humans of the Second
  and Third Seedings and they became heavily involved with old Sumerian
   and Egyptian cultures, as well as that of Atlania and Atlantis.  
    The portal bridge between Sirius B, the Sphere of Amenti and Earth
   allowed for greater evolutionary options for the fourth and fifth races, those
  who carried the third DNA strand in their race morphogenetic field. This
    option was not available to Lamanian/Lemurian and Ur-Antrian cultures, as
  they did not carry the full third stand imprint in their morphogenetic field. The
  option assisted Atlanian/Atlantean races and their Breanoua Cloister who suc-
  cessfully assembled the third strand, and also the Aeiran/Aryan races and their
  Hibiru Cloister who were not able to fully assemble their fourth DNA strand
   prior to death. For these races, instead of the soul essence fragmenting into D-2,
   D-3 and D-4 following death (as would be the case due to the Seal of Palaidor),
  the soul essence who had assembled most of the third strand could move into
  the race morphogenetic field in Sirius B. Within the morphogenetic field of
    Sirius B the soul could evolve here for a time as disembodied consciousness to
   assemble more frequencies into its code, then pass into the Sphere of Amenti
  through the portal bridge. Souls taking the Sirius B path of evolution could
  release the Seal of Palaidor, but not the Seal of Amenti. They could return to
  the Palaidorian morphogenetic field and wait there for the seeding of the fifth
  race into which they would incarnate to assemble the remainder of the fourth
  strand. This was a much better option than fragmentation, which would create
   loss of the personal identity imprint as the soul fragments merged with the con-
   sciousness of the fifth races. Individual sentient identity could be retained
  through evolving through Sirius B. During the Second Seeding this portal
      bridge became known as the  Hall of Amorea,  in the Third Seeding, during the
  times of Atlantis and Egyptian Pharaonic rule, it became known as the Third
    Eye of Horus,  and represented the culmination of the “Left Eye of Horus” and
   “Right Eye of Horus” mystical teachings. The Third Eye of Horus was a closely
  guarded secret, and passage through this dimensional bridge was reserved for
        the few elite races who carried the needed third strand genetic imprint.  
                             The Second Seeding - the Fourth World                                                                                      3,700,000 - 848,000 YA         
     The morphogenetic field for the Second Seeding Races was entered into
   Sirius B approximately four million years ago. The races began incarnating on
   Earth through a small group of human hybrids who had found exile and
   evolved within the HU-1 Pleiades star system during the Electric Wars.
    Through the Sirian Council of HU-2 and the Galactic Federation of HU-1,