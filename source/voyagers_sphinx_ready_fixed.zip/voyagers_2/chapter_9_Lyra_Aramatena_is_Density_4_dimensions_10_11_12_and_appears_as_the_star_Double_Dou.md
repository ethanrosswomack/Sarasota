9     Lyra Aramatena is Density-4, dimensions 10-11-12 and appears as the star “Double Dou-                                                                     
       ble” in Lyra from Density-1 Earth view.   
379                                                                           
                                                                                                         

                           
                          The Hidden Game-board Final Conﬂict Drama
Other Anunnaki factions, such as Ashtar Command , the Nibiruian-Thoth-
Enki  collective, the Galactic Federation , the Pleiadian-Samjase-Luciferian
collective, the Marduke-Dramin  collective, the Alpha-Omega Nephilim
Annu-Melchizedeks  and Necromiton-Andromies  held onto their respective
OWO agendas until their “ ultimate stronghold”  was considerably
compromised in 1992.                       
                        THE PLEIADIAN-SIRIAN AGREEMENTS  
                               AND HURRICANE ANDREW 1992 
    Since implementation of the NDC-Grid Photo-sonic installation and
the NET of 25,500 BC Atlantis,  the Anunnaki races have steadily moved
their intended Atlantian Conspiracy Luciferian Covenant OWO dominion
agenda forward through remote Photo-sonic control  of Earth’ s Planetary
Templar Complex via the NDC-Grid.10 Throughout the progression of the
1980s Andromie-Rigelian Coalition agenda, the Anunnaki races remained
confident of their ultimate victory and OWO dominion within the pending
2000-20I7 AD SAC Final-Con ﬂict drama. The Anunnaki believed that they
would be able to use the NET to awaken and manipulate enough of their
civilian Illuminati Sleeper Races, and unsuspecting Human races within the
''channeling '' movement,  to make a stand against the Illuminati factions that
they had lost to the Necromiton-controlled Andromie-Rigelian Coalition.
The Anunnaki intended to use  ''channelers '' to teach unsuspecting
Illuminati Sleepers and Human populations how to orchestrate false
planetary healing operations  utilizing distorted Biotronic scalar-pulse and
Merkaba Mechanics  technologies  that would be ampli fied through the
NDC-Grid.  Through these distorted Biotronic/Merkabic technologies, the
Annunaki believed they would be able to reclaim from competing forces
Earth’s 12 Primary Star Gate territories and corresponding Ley Line systems,
as each Star Gate naturally opened during the 2000-2017 SAC.  
    In  1992  Anunnaki legions were confronted with yet another unpleasant
surprise as Andromie-Rigelian and collaborating factions of the Omicron-
Drakonian and Odedicron-Reptilian Falcon force began to utilize the
Montauk-Phi-Ex Wormhole and Falcon APIN system to gain control over
the Anunnaki NDC-Grid and the NET via scalar pulse transmissions.
Suddenly the overly con fident Anunnaki  forces became willing to enter
negotiations for Emerald Covenant Redemption Contracts  with Emerald
Covenant nations.  
    Because the Anunnakis feared complete loss of their NDC-Grid/NET
stronghold on Earth, some of their leading factions reluctantly entered the
Emerald Covenant Pleiadian-Sirian Agreements  in November 1992 . In
these agreements, the Pleiadian and Nibiruian Anunnaki  legions and
portions of Galactic Federation  and Ashtar Command  agreed to put the
NET/NDC-Grid installation  and their artificial hold on Solar Star Gate-4
back under Guardian Azurite Universal Templar Security Team
protection . The Andromie-Rigelian Coalition had their immediate sights set
on conquest of Anunnaki-held Nibiru , a planetary environment more
___________________________  
10.   See Masters Templar Coursebook,  forthcoming.  
380 
                   

                                            
                                          The Pleiadian-Sirian Agreements and Hurricane Andrew 1992
suitable to Necromiton-Andromie biological requirements and a strategic
“power spot ” in relation to conquest of Earth and dominion over the Halls of
Amenti. The Pleiadian-Nibiruian Anunnaki of the “Phoenix” and “Serpent”
APIN systems promised to honor the Emerald Covenant if the Founders
would assist them in using the NET/NDC-Grid to close by force  the
Necromiton-controlled Montauk-Phi-Ex/Falcon Wormhole . If utilized by
Guardian races via Sirius B Star Gate-6 , the already operational NET/NDC-
Grid installation could be reprogrammed to carry and amplify D~12 and
Primal Life Force Trion Currents from beyond this Time Matrix. If returned
to the protection of the Emerald Covenant nations, the NET/NDC-Grid of
Earth had the power to temporarily seal or “Cap” the Montauk-Phi-Ex/
Falcon Wormhole,  preventing the Andromie-Rigelian “Falcon-Eagle,”
Omicron-Odedicron Drakonian “Dragon” and Jehovian Anunnaki “Dove”
raider races from further advancing their Earth-Nibiru-Amenti dominion
agendas. Emerald Covenant races had been trying unsuccessfully to cap the
Montauk-Phi—Ex/Falcon Wormhole since WW2.  On August 12, 1992,  they
had almost succeeded when the Zeta Rigelians, with the assistance of the
Necromiton-Andromie '' Montauk Boys ,'' launched a vicious sonic pulse
transmission from their Star Gate-3 Bermuda base , into the Falcon
Wormhole, further expanding the Falcon  and preventing application of the
frequency cap.  
    The unstable expansion of the Falcon W ormhole caused major deep
marine disturbances  throughout the Atlantic Ocean, reports of which the
Illuminati Withheld from public disclosure. On August 24, 1992 , the Falcon
wormhole amplified the intensity of Hurricane Andrew,  creating wind
speeds in the range of 250-300 m.p.h. Hurricane Andrew changed direction
suddenly , heading for the Dade County, FL, area. The Falcon agenda
Illuminati knew of the direction change in time to call for evacuations , but
their Fallen Angelic Necromiton-Andromie ''commandos'' ordered them to
''misplace '' this information  and give warning only when evacuation time
was spent. The Zeta-Rigelians and Necromiton-Andromie forces used
Hurricane Andrew to secure yet another Human and Maji ''Population
Reduction '' event . The devastation of Hurricane Andrew was one of the
greatest recorded “natural” disasters in US history. When the Pleiadian-
Nibiruian Anunnakis finally decided they wanted to “deal,” and offered to
turn over their NDC-Grid, NET, Phoenix and Serpent APIN systems to
Emerald Covenant races, the opportunity to safely cap the Falcon Wormhole
was finally at hand. In November 1992,  the Pleiadian-Sirian Agreements  of
the Emerald Covenant Peace Treaty were formalized.  
381 
                                                                                                                                             
                     
                                                                                                                            

  
                        The Hidden Game-board Final Conﬂict Drama
                                                  TEMPORARY CAP ON THE MONTAUK
                                                       PHI-EX WORMHOLE 1994-1998           
   When the 1992 Pleiadian-Sirian Agreements were initiated, both
Emerald Covenant and Pleiadian-Nibiruian Anunnaki races, and the
Galactic Federation, made subtle and physical contact  with selected
members of the Illuminati and Interior World Government forces, offering
them opportunity to defect  from Andromie-Rigelian and Drakonian/
Reptilian “ Falcon-Eagle ” dominion. Through a temporary photo-sonic
interface system  created by the Emerald Covenant Maharaji  Blue Human
races of Density-2 Sirius B , portions of the NET/NDC-Grid  were able to
receive and transmit speci fic scalar pulses through Earth’s Templar that
served to '' jam' ' the frequencies  used to sustain the Montauk-Phi-Ex
Wormhole.  
   By 1994 , the united Emerald Covenant and Anunnaki legions
successfully created a temporary ''cap '' on the Montauk-Phi-Ex APIN
system , and a partial cap  on the Falcon wormhole ''hub.'' The Montauk-Phi-
Ex/Falcon cap prevented the Necromiton-Andromies Zeta Rigelian, and
Drakonian/Reptilian fleets from furthering their intended covert infiltration
of Earth’s subterranean bases. The Montauk-Phi-Ex Cap was a temporary
solution that depended upon the Anunnakis upholding the Pleiadian -
Sirian Agreements . In these agreements the Anunnaki legions had promised
to release Earth from Nibiruian subjugation, dismantle the NET  and
return the NDC-Grid and Solar Star Gate-4,  which they had “hijacked by
force” during the 25,500 BC Lucifer Rebellion, back over to the Emerald
Covenant Founders’ protection by 2000.  
   Had the Anunnaki races upheld the Pleiadian-Sirian Agreements,
Emerald Covenant races would have used the NET/NDC-Grid installation
on Earth to accomplish two vital Bridge Zone Project crisis intervention
initiatives.  The most pressing intervention needed was that of rapidly re-
balancing  Earth’ s electromagnetic Merkaba fields to prevent pending pole
shift  from occurring during the 2000-20l7 SAC, due to the original,
inorganic Photo-sonic program of the NDC-Grid. The second intervention
was that of using the  NET/NDC-Grid network during the SAC  to
permanently seal the Montauk-Phi-Ex/Falcon Wormhole and the Phoenix
Wormhole , while activating the Face of Man LPIN system  and the Great
White Lion, Golden Eagle and Blue Oxen APINs . Success in these
objectives would prevent further Fallen Angelic invasion, setting in motion a
Free World Order of Emerald Covenant interstellar co-evolution  on Earth.
  From 1994-1998  Pleiadian-Nibiruian Anunnaki, Galactic Federation
and Emerald Covenant in ﬂuence gained dominance within many Illuminati
factions. Preparations were being made among cooperating Illuminati
alliances to begin non-threatening, progressive public release of ''ET-
           Angelic Presence Confirmation '' via Official Global Proclamation. As part
           of the Pleiadian-Sirian Agreements,  Emerald Covenant races had agreed to
        wait  until humanity had dealt with the initial revelation of the reality and
        immediacy  of ''Visitor Contact '' before releasing the full historical data  
                  
                   382                                              
                          

                               
                                              
                                                 
                                           Temporary Cap on the Montauk Phi-Ex Wormhole 1994-1998
concerning Anunnaki infiltration via the Atlantian Conspiracy Luciferian
Covenant agenda.  
    Without use of the earthly NDC-Grid installation  and natural
realignment of Solar Star Gate-4,  Emerald Covenant races would be unable
to prevent pole shift,  nor would they be able to seal the Montauk-Phi-Ex/
Falcon Wormhole, without launching immediate physical on-planet
presence of fleets capable of advanced Photo-sonic scalar pulse
transmission . If Guardian ﬂeets attempted to deploy direct physical presence
on Earth, they would be intercepted by Necromiton-Andromie, Rigelian-
Zeta, Drakonian and Reptilian fleets, setting in motion a literal '' Star Wars ''
drama within and surrounding D-3 Earth territories. Such a Star Wars drama,
utilizing the Photo-sonic and Photo-radionic technologies possessed by all
interstellar races, would not only decimate large portions of Earth
populations, but would also guarantee pole shift  by further disrupting the EM
balances in Earth’s grids during the 2000-20l7 SAC. An easy, peaceful
victory on Earth over the pending Fallen Angelic/Illuminati OWO Final
Conﬂict drama depended upon the Anunnaki races honoring their
promises of Emerald Covenant support and cooperation with Guardian
nations—promises that were made in the 1992 Pleiadian-Sirian
Agreements.   
        The 1994    capping   of     the    Phi-Ex Wormhole  gave   the  Anunnaki   races
opportunity to once again advance their influence  among the Illuminati
races of the World Management Team. If they had been honoring their 1992
Agreements, this “in ﬂuence” would have progressed in representation of the
Emerald Covenant . The Anunnaki and Emerald Covenant races continued
to initiate a slow but steady “wake-up call ” among their respective civilian
Sleepers. The Anunnaki released the message among some of their channels
that “the Zeta races had left Earth and there was nothing now to fear.” The
originally sinister intentions of the Anunnaki-orchestrated aspects of the
“New Age Movement” brieﬂy became upgraded to support the Emerald
Covenant peace treaty and freedom teachings, creating a renewed solidarity
between once-competing ideological factions in the New Age arena.  
    In 1997  Guardian races began the “wake-up call” to their Emerald
Covenant Speakers and Indigo Children, in preparation for the scheduled
release of the Emerald Covenant teachings pertaining to Masters Planetary
Templar Mechanics, which were to be given once  consummation of the
2000-2017 SAC  was confirmed.  Plans were made among Anunnaki loyal
Illuminati and Human members of the World Management Team to begin
“Official Disclosure ” of “Visitor Race Presence.” Official Disclosure was
intended to prepare human populations to make a united, peaceful stand  in
protecting Earth’s territories from further advancement of the several
competing Fallen Angelic OWO invasion agendas, using the natural,
spiritual-science based tools of Masters Planetary Templar Mechanics.  
    Guardian races intended to release the Emerald Covenant Masters
Templar Mechanics teachings  into the public forum, to educate Humanity
in the methodologies required  to orchestrate Planetary Shields Clinics,
through which Earth’s EM grids could be rapidly healed to prevent pole
shift  from occurring should the 2000-2017 SAC commence as anticipated. If
the 2000-2017 SAC commenced , Guardian races intended rapid    
383  
                                                                                                                                              
                              

  
                    
                        The Hidden Game-board Final Conﬂict Drama
dispensation of information  pertaining to humanity’ s invitation into the
Lyran-Sirian Founders Emerald Covenant Co-Evolution Peace Treaty , and
the awakening and training of the Amenti Planetary Templar Security
Team  was to immediately commence. The Amenti Security T eam was
intended to be trained to assist Guardian nations in using the NDC-Grid
installation  to permanently sever the link between Earth and the
Montauk-Phi-Ex/Falcon and Phoenix Wormhole , preventing further Fallen
Angelic in filtration. Once the Montauk-Phi-Ex/Falcon and Phoenix
Wormholes were permanently shut, Fallen Angelic races would be unable to
send in larger ﬂeets to intercept and initiate “Star Wars” with Guardian ﬂeets
as they made their inevitable '' First Contact '' mission. As 1998 approached,
all appeared to be going relatively well within the delicate political balances
of the 1992 Pleiadian-Sirian Agreements.  
                
         ANUNNAKI DEFECTION, FALCON UN-CAPPED, INDIGO  
                     HUNTING AND EDICT OF WAR 1998-2001 
   When it became clear in June 1998  that the SAC would commence in
2000, the Pleiadian-Samjase-Luciferian, Nibiruian-Enlil-Odedicron,
Thoth-Enki-Zephelium  and Galactic Federation Anunnaki  collectives
immediately defected  from the Pleiadian-Sirian Agreements, seizing this
opportunity to continue activation of the Phoenix and Serpent APIN
systems for Earth conquest. They made deals with the Jehovian “Dove” and
Necromiton-Andromie “White Eagle” to interface their NET/NDC-Grid
and APIN systems  with the Zeta-Rigelian/Andromie Montauk /Phi-Ex
facility  in order to undo the access to Earth’ s T emplar that Emerald
Covenant nations had recently gained. They rapidly began to “set the stage”
for “ Lowering the NET ” into the D-3 Frequency bands via  interface with
earthly electrical-grid technologies  to create the 2004 '' Frequency Fence ''
mass-mind-control network.  
    The Alpha-Omega Nephilim Annu-Melchizedeks  began an aggressive,
sweetly rendered “ Indigo Child Hunting ” campaign within the New Age
Movement, hoping to locate as many Indigo people (especially Type-3
Human-Anunnaki hybrids) for astral Tagging  and DNA  bonding-bio-field
possession. Great efforts were applied to directing the “Channeling”
movement via the NET/Phi-EX  transmitting station, through which a
progressively growing number of infiltrated  Illuminati and Human “ Greeting
Teams ” were assembled among Earth populations ¹¹ 
    As the Anunnaki Greeting T eams advanced in the New Age movement,
many Anunnaki legions that had remained loyal to the 1992 Pleiadian-Sirian
Agreements finally defected under growing pressure from the Galactic
Federation and the Nibiruian Thoth-Enki Anunnaki collectives. Numerous
popular '' Energy/Spiritual Healing Systems '' were in filtrated and
progressively used to orchestrate astral Tagging  in New Age populations.
  
                         _____________________
   
                             11.      Check out the Galactic Federation, “Archangel Michael” and several other very popular
                 New Age and UFO Contact movement representatives and you’ll get an idea of how well  
                 the Fallen Angelic “Greeting Team” effort is going.
                             384  
                           
                     

                                        Anunnaki Defection, Falcon Un-Capped, Indigos, Edict of War. 
Meanwhile, many un-awakened Indigo Children and Humans became
infiltrated with Anunnaki implantation, possession and '' pseudo spiritual ''
indoctrination , and the “Michael Matrix,” Zeta-Rigelian and Dracos stepped
up their own interest in the '' Body-Snatching game .'' This caused a
progression of disputes among Anunnaki factions and between Anunnaki
and Drakonian agenda forces.  
  Between 1998-1999, the Zeta Rigelian and Necromiton-Andromie
Falcon-White Eagle force , with the assistance of their '' Montauk Boys ''
Illuminati, successfully removed the partial cap on the Falcon wormhole and
partially ripped through the Montauk-Phi-Ex wormhole cap. “ Un-capping
the Falcon ” allowed them to reactivate portions of their global Montauk-
Phi-Ex-Falcon/White Eagle APIN system, through which Psychotronic  and
sub-space Sonic Scalar Pulse  transmissions capacity was restored. Since this
1998-1999  fiasco began, Emerald Covenant nations have used their once-
again limited access to NET transmission to '' poke holes '' in the NET, by
which their Indigo Children Types-1 and 2 could receive a rapid emergency
“wake-up call .¹² Expedited Emerald Covenant CDT-Plate translations
began in late 1999, after the original May 1999 simultaneous publication of
the Voyagers I and II.  
  Throughout 1999-2000, Emerald Covenant races have continued
negotiations in attempts to resurrect the Pleiadian-Sirian Agreements with
Anunnaki races, temporarily securing the July 5, 2000, Treaty of Altair
with the Anunnaki and several renegade races, due to the continuing
disputes between Anunnaki and Drakonian agenda factions. Between
September 7-12, 2000,  the Andromie-Necromitons  settled several pending
Anunnaki/Drakonian disputes over intended distribution of captured Inner
Earth territories, the UIR was formed and their War Edict  was issued on
September 12, 2000.  
___________________________________________________________
Since September 12, 2000, Emerald Covenant nations and awakening Indigo
Children and Humans  who have not yet succumbed to Fallen Angelic astral
 tagging, etc., have been working with progressively more advanced Masters
                   Planetary Templar Mechanics  to secure Earth’s Templar
                                       under a critical-mass 12-Code Pulse before the 2003 deadline.                                                      ____________________________________________________________
                             
                             
                             ____________________________
                                 12. Scalar transmissions to activate dormant portions of the DNA Template.
                              385