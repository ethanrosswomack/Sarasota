25 
                                                                                                                  

 
        The Secrets of Amenti
on Earth would not be able to remember what existed on the Earth, or that
 Earth was a member of vast multidimensional reality fields containing innu-
 merable sentient forms of life. The human developed tunnel vision, a condi-
      tion which remains today within the majority of people on Earth.  
   Great hope was placed upon the success of the Fifth Root Race evolution,
     for the Fifth Root Race was designed to assemble the fourth DNA strand, the
        strand that corresponded to the fourth dimension. If the Fifth Root Race could
    fully evolve its strand, their astral awareness could pass through the Seal of
         Palaidor. While they were still alive in body, they could consciously awaken in
 their astral bodies, discover the secrets of their missing codes and begin to con-
 sciously heal the mutations in their gene codes. The Fifth  races would  become
          the Keepers of Records for Earth  until the Sphere of Amenti was returned to
     Earth's core, as they could pull the lost race memory from the Sphere of
 Amenti in D-4 and bring it alive once again upon the planet.  
       Following the removal of the Sphere of Amenti from the Earth's core
    5,500,000 years ago, the Earth grid rapidly plunged in speed, then began an
     even more rapid acceleration as erratic energies left over from the Sphere fil-
 tered through Earth's bioenergetic system. Climatic changes again occurred,
  land masses slid beneath waters, and great quakes rumbled through the
   planet. Within three years of the removal of the Sphere, a great ﬂood came
  that covered over 85% of Earth's surface. The memory of this ﬂood, along
  with that of two others, was given to you by the Elohim and recorded in your
     Biblical history as one event. The ﬂood of 5,500,000 years ago just described
 is the first major ﬂood on Earth, the second ﬂood occurred about 849,000
  years ago and the third during the Third Seeding of the Root Races. There
  were many other periods of ﬂooding but these three periods were the most
       notable. With the Seal of Palaidor came a wall in time behind which the
     truth of human lineage was hidden. Humans born in the Second and Third
  Seedings would be marked by the Seals of Amenti and Palaidor, baring the
           burden of a past of which they would have no memory. It could take millions
  of years for the Earth grid vibrational rate to rise enough so that life with
    fourth-dimensional coding (the fifth races) could be sustained and the Sphere
   of Amenti returned so the Seal of Palaidor could be lifted. Human evolution
                  was stunted 5.5 million years ago and would have remained so if it were not
          for Sirius B.  
       
        
        
         26