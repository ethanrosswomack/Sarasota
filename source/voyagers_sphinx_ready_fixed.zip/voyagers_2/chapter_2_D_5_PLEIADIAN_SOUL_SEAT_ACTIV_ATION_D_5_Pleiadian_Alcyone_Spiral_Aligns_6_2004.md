2   D-5 PLEIADIAN - SOUL SEAT  -ACTIV ATION : D-5 Pleiadian-Alcyone Spiral Aligns 6/2004
         DATES A V AILABLE FOR ACTIV ATION : 9/9/2004 - 2022 general populations
            STAR CRYSTAL SEAL ACTIV ATES:  #6 D-5/D-6  INDIGO STAR CRYSTAL , In 8thchakra between chakras 4 & 5
  RELEASES STAR CRYSTAL SEAL : #3 D-2/D-3 Yellow Star Crystal Seal opens
  DNA:  Strand 5 assembles to activate 2012 -2022 Fire Code : strands 2- 3 activate ACCRETION LEVEL : 4 to 5
  CHAKRAS:  draw frequency from Alcyone Spiral through chakras 10 &11 into chakras 5 & 6 then into
   Indigo Star Crystal Seal
      Violet-Blue Wave Infusions  of D-6/D-7 frequency began at lndigo Star one-half activation                                         ______________________________________________________________________________________ __