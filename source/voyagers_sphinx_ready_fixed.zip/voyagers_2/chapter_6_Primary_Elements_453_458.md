6 Primary Elements 453-458
    technology 122
     Time Codes 7
Khundaray 272, 310
     Primal Sound Fields 299
     Sound Currents 306
Khundaray/Kee-Ra-ShA Primal Life Force
                 Currents 373
King Arthur 324
      and the Knights of the Roundtable 315-317
King Arthurus, see King Arthur
King David 323
King Solomon 323
Knights Templar 317, 370
    Free Masons 356
    Invasion 312, 321, 330
Kundalini 306
     -Maharata Life Force Currents 351
Kuntureaz 27
L
Lake Titicaca, Peru 392, 409
Lamanians, see Second Seeding
Lamb 367-369, 416
landing 327
languages
    five Christos 303
    Mu'a/Anuhazi 303
Larsa Kings 312, 320, 321
Las Vegas, NV 409
Law of One 3, 4, 25, 33, 34, 35, 36, 45, 57-
                64, 67-69, 89, 93, 95, 97-104,
                137, 170, 398, 496
  materialistic distortion of 45
Laws
  of Creation Physics 389
laws
  spiritual 4
Lemuria 261, 317, 353
   continent of Muarivhi 58
   Holocaust 319, 330
Lemurians, see Third Seeding
Leonines 60, 86
  see also Sphinx
Leviathan 398, 401
     Anti-Christiac King 313
     Force 328
Leviathan Force   353                                                                       
Ley Lines 247, 342, 348, 357, 367,
light
   -Symbol Codes 457, 460
                program 461
   workers 177, 186, 203
Lion 367-382, 414, 432

                                                                                                          Index Volume II
Little Grey 317
Lohas 314, 315, 316, 319, 320, 321
  -Celtec-Drueidec Freeze Out 31
   firmament collapse 311
Lohas-Celtec-Drueidec Freeze Out 320, 330
London, England 409
Long Island, NY 346
LPIN 372, 386, 392, 405, 432
Lucifer 330
Luciferian
-Anunnaki 320, 321, 322
Anunnaki 313
Centaur-Omega Centauri 317
Conquest 311, 320, 330, 391, 417
Covenant 245, 312, 313, 318, 320, 321,
         325
Hyksos Kings 323
Knights Templar 316
-Pleiadian 322
-Pleiadian-Nibiruian 317
Pleiadian-Nibiruian Anunnaki 318
Rebellion 244, 245, 311, 319, 330
Luciferian Rebellion 367, 370
Lulcus 390
Lumeria 372
Lumerian-Pylon-Implant-Network, see LPIN
Lyran 2, 6
High Council 250
-Sirian Anuhazi 318
-Sirian Elohie-Elohim 303
-Sirius A Anuhazi 266
M
Machu Picchu 212
   see also vortices
magnetic
   field collapse 113
   repulsion zone 130
Magnetic Peak 362, 408
Mahabharata 312
Maharaji 250, 312, 318, 320, 371, 379
Maharata 260, 302, 424
Maharic Seal 352, 419
   bene fits of using 498
Maharic Shield 258, 304, 497
   Manifestation 298
Majestic-12 126, 317, 326
Majestic-12, see MJ-12,
Maji 262, 281
    Grail Kings 321
Manhattan V ortex 408
Manhattan, NY 346
Manifestation 423
manifestation 152
   how to gain control over 159
   learning to de-manifest 159
Manifestation Template 291, 299
Marduke
     -Anunnaki 319      
    Dramin-Anunnaki-Omicron 245
      Necromiton Nibiruian 244
     -Necromiton-Luciferian-Alpha Centauri 317
Marduke-Luciferian Anunnaki 370
Marduke-Luciferian-Anunnaki 370
Mars 64, 123
Martial Law 411
572                                                                                                                                
Mary 251
Mary Magdalene 101
Mary, mother of Jesus 99-100
     see also Jeudi
mass
     dreams 152
     landing, staged 178, 208
Mass Awakening 405
Mass Landing 252
Master Key Codes 278
Masters Inter-Galactic Templar Mechanics 339
Masters Planetary Merkaba Mechanics 427
Masters Planetary Templar Mechanics 402, 413
matrix
15-dimensional 452, 458, 474
cosmic 459
host 30, 190
oversoul 457
silicate 101, 195, 477-478
soul 457
time 8
transplants 46, 168, 482
matter, as an illusion 129
Mayan
    calendar 239, 461
    Raids 312, 322, 330
Meajhé Field 342, 343, 372, 386, 405
Medianite-Hyksos 322
Mediterranean 366
Melchazedek 32
     see also Turaneusiam
Melchizedek
    Deception 370-384
    false ordinations 375
Melchizedek, King of Salem 98, 100, 101
Melchizedeks
   Alpha-Omega Order 370
Melchizedeks, see Cloistered Races
memory
      and dimensional bands 151
      erasing 92
      repression 134
Memphis 95
Men In Black 245, 317, 318
Men in Black 360, 392
mental
    bilocation 79
Meridan 315
Merkaba 248, 432, 499
External Reversed 257, 258
Group 258
Mayhem 259
Mechanics 258
natural Christiac spin ratio 259
reversed spin ratios 258
tailbone mark of reversal 260
Vehicles 418
Merkaba Fields 126-141, 188, 259, 456, 458,   
                  464, 466, 482
Harmonic Universe 127
Mechanics 126
Meta-galactic 127
Of Earth 127, 136, 140, 142, 144, 472
of Tara’ s gold core crystal 165
of Tara-Earth 136
of the Sun 133, 136, 143, 171
                                                       
             

 Index Volume II
     three levels of 150
Merkaba Vehicle
      Hallah Phase 301
Merlin 316
Messiah 102
Metagalactic Core 13, 34
Mexico 366, 391, 408
Miami, FL 409
miasms 22, 24
microchips
    crystalline 367
    silicon-based 367
Middle East 103, 251, 366, 377
Midianite-Hyksos Kings 321
Milky Way Galaxy 470
mind control 348, 351
Mintaka 368
Mintaka-Orion 279
Mion Field 407, 416
Miracle Cures 411
Miriam 314, 323
missing
    fetuses 235
MJ-12 354, 357, 361
Montauk 388, 409
Montauk Project 136-139, 172, 210, 339-
            346, 350, 352, 378-385, 388, 399
            408, 409, 429
Montauk, NY 359
Montsegur, France 367
Mormon faith, see religion
morphogenetic
Crystal Seals 473-477
Keylons 458
PartikiGrids 458
Partiki Strands 458
Partiki Units 458
wave 110-112, 123
                  backﬂow from 112
                  importance of 121
                  of 2017 67
Morphogenetic Field 5-25, 27, 30, 35, 40, 53
                  88, 124-130, 133-135, 300
Amenti 46, 124, 140
of a person 41, 150
of Earth 150, 228
of Sphere of Amenti 168
race 15, 79, 96
Moses 251, 324
most important thing you can do 231
movement
    as an illusion 129
MT 2, 12, 181, 233
Mt. Mitchell, NC 359
Mu 3, 4, 7, 54
 Council of 3
 Lumians of 3
 Lumiar Ceres of 4, 6
     Priests of 3, 4
Mu‘a
     Urtite 263
Mu’a 272, 274, 276, 278
     Lemuria 317
Muarivhi, see Lemuria
Muarivhia, see Mu’a
multidimensional
 573    physics 130 
    reality, lost memory of 53
multidimensional space-time
     mathematical structure of 226
multiple reality fields 147
mystery schools 67, 101
N
N. Ireland 359
Nadial
   substance 458
Nadis 35, 456, 457
Nagasaki 362, 363
Native Americans 29, 239, 325, 328, 461
natural healing 241
Nazis 363
NDC grid
    see Nibiruian Diodic Crystal Grid
NDC-Grid 380, 382, 387, 388, 392, 400, 415
NDE 493
     light at the end of the tunnel 493
Neanderthal 390
Necromiton 250, 317, 318, 360
   -Andromie 244, 250, 317, 327, 338, 359,
             362, 376, 378, 383
    -Andromie-Anunnaki 370, 371
Nefertiti 93-94
Nepal l0l 
Nephedem Annu-Melchizedek 323, 324, 325
Nephilim 370
Nephilim, see hybrids
Nephite-Nephilim-Necromiton Anunnaki-hybrid
              collective 244
NET 349, 355, 357, 380, 382, 384, 387, 388,
                 394, 397, 400, 403, 406, 416
New Age 248, 317, 336, 400
New Angelic World Government 252
new dawn 240, 462
New World Order 173
New York, NY
Nibiru 98, 242, 244, 246, 256, 314, 319, 327,
                  339, 379, 387, 391, 392
      Battlestar, see Battlestar 245
      Checkerboard Mutation 259
      more suitable to Necromiton-Andromies 380
Nibiruian 319, 326
     -Anunnaki 322
     Crystal Temple Network 340, 343, 345, 349
     Diodic Crystal Grid 311, 319, 324, 327,
               328, 355
Diodic-Crystal Grid 313, 321
Electrostatic Transduction, see NET
-Enlil-Odedicron 384
Enlil-Odedicron-Reptilian Anunnaki 374
Luciferian-Anunnaki 374
Marduke-Anunnaki 319
Re-acquaintance 330
     -Thoth-Enki 380
Noah 6, 324
Nohasa 311, 315, 319, 320
Noors 360
North America 56
Nubia 86, 102
numbness 249

 
O
observational outpost 60
Odedicron 313, 317
    -Avian-Reptilian 244
    -Reptilian 246
Odedicron-Avian-Reptiles 377
Odedicron-Lizard 265
Official Disclosure 383
Omega Centauri 245, 366
Omicron-Drakonian 244, 246, 247, 252, 265,
                313, 317, 323, 324
Omicron-Odedicron 377
One World Order 253, 254, 255, 320, 324,
336, 354-365, 366, 378, 379, 386,
390, 400, 403, 405, 410, 417, 426
   Master Plans 337
Oraphim 262, 264, 266
Bra-ha-Rama 267
Cetaceans 267
magnetic field 267
procreation 268
Oraphim-Turaneusiam 266
ordered energy 155
Origins 2
Orion 45, 123, 223, 242, 244, 246, 247, 253,
                317, 323, 379, 392
Black League 360 
-Drakonian 320
Intrusion 326, 330
-Mintaka 266    
Wars 246
Orion’s Sword 366
Osirius Kings 321
out-of-body travel
    dif ficulty in remembering 124
Over-Soul Integration 301
overtone 16, 17, 19, 20, 21, 24, 30, 35, 72,
75, 80, 83, 92, 111, 119, l26, 134,
135, 143, 161
OWO, see One World Order
Ox 414
P
Pacific 359, 366, 373
Pacific Ocean 56
Painted Desert 188
Pakistan 378
Palaidia 263, 269, 270, 275, 276, 278, 280,
                    284
   Urtite-Cloister 282, 293, 295, 308, 310
Palaidor 7
   Council of 33
   Covenant of 7, 8, 18, 33, 36, 69, 97, 107,
           121
Resistance Entity Wars of 18
Seal of 22-26, 28, 33, 43, 50-52, 105,
          134, 205
Palaidorian 271
/Amenti morphogenetic field 23
birthing contracts 194-198, 201
and rights of the incarnate 196
finalization of 196
Incubation Rite 197
protection of couples 197
    collective
574                                                                                                                                                                   
                          Index V olume II
            
           see Cloistered Races, five 17
  see Cloistered Races
Palestine 409
Paradisians 195
   see also Cloistered Race Yunaseti
   see also Seventh Root Race Euanjhechi
parallel
    Earth 9, 93, 110, 164, 296, 372
Pardo 146
particle 453, 458
   conversion period 223-225
   pulsation speeds 150
Particum 453-454
Partika 453-454
Partiki 452-461
   Grids 454, 459-461
   strands 454
past, illusion of the 148
Path of the Night of the Two Moons 183
Peace 252
pearly gates 15
Pearly Gates of Heaven
   see pearl ates
Pegasai 264
Pentagon 335
   see 2001-September ll
people, disappearance of 182
perception
   five-sensory 79
perceptual
   stations
           Bridge Zone 183-184
           descending planet 182-183
Persia 101
Persian Gulf 366
Personal Christos 296, 297
Personal Divine Blueprint 304
Peru 212, 430
   Machu Picchu 247
Phaelopea 91
Phantom Arcturus 418
Phantom Arcturus Matrix 418
Phantom Earth 392, 397
Phantom Earth, see Earth, Phantom
Phantom Matrix 369, 371, 372, 378, 387, 388,
                 394, 395, 396, 397, 420, 421, 431
Phantom Planet system 282
Phantom Pulse 345, 346, 406
Pharaoh
     Ahmose 322
Akhenaton 88-110, 323
Amenophis III 88, 89, 94
Amenophis IV 88
Djoser 322
Queen Hatshepsut 323
Rameses I  95                                             
Tutankhamon 90, 95-96
Tutankhaton 95
Tuthmosis III 321, 322                                  
                                             
Phi-Ex Wormhole 354-363
Philadelphia Experiment 130-131, 133. 137,
139,143,172. 188. 210, 350. 359
362, 387, 399
Philadelphia, PA 359, 408, 409
Phoenix 386-??, 388, 389, 391, 392, 393,

          
Index V olume II
              396.?? 399, 408, 417
Spiking Matrix 398
Phoenix Project 374-384
Phoenix Spike Matrix 394
Phoenix Spike sites 409
Photon Belt 114-116, 142
    discovery of 115
Photon Belt, see Universal Maharata Curren-
physical evacuation 340
PIN 359, 366, 388, 389
Place Holders 203
Planetary
12-Cycle 296
Merkaba Reversal 259
Security Seal 255
Shields 254, 258
Shields Clinics 247, 255-257
Signet Key Codes 277
Star Gate Security Codes 255
Templar Complex 245
          Star Gate system 241
Time Continuum 287
Time Cycles 296
Planetary Shields 294, 314, 343, 348, 368,
                    427
      Clinics 335, 346
      Reversal 401
Planetary Shields Clinics
      methodologies 383
Planetary Shields Crisis 426
Planetary Trion Field 342
planets
and holographic beam 115
ascension 8, 167
descending 167, 168, 174, 482
Earth 6, 7
      connection to Tara 40
Jupiter 6
Maldak 6
Mars 6, 45, 60
Mercury 6
Neptune 6
Nibiru 6, 64
Pluto 6
Saturn 6
twelve 5
Uranus 6
Venus 6
Pleiades 114, 127, 143, 242, 360
      -Alcyone 379
Pleiadian 6, 28, 29, 34, 35, 36, 51, 55, 57, 65
         69, 128, 374
-Alcyone 266
-Nibiruian 312
-Nibiruian Anunnaki 252, 254, 316, 324,
             325. 326
-Nibiruian Council 256
-Nibiruian Luciferian Anunnaki 317, 319,
       320
-Nibiruian Samjase-Luciferian-
                 Anunnaki 320
-Nibiruian-Luciferian-Anunnaki 320
-Samjase-Luciferian 380. 384
Samjase-Luciferian-Anunnaki 374
Serres 266
-Sirian Agreements 354
575    Star League 97.133. 141, 191. 233
Pleiadian-Sirian Agreements 241.242 243
246, 253, 256, 258, 318, 326, 330
350, 353
     Anunnaki defection from 245
Polarians. see Gaia
Polaric Codes 273
pole shift 22, 122. 131—134, 245. 250. 251,
253, 254, 255, 256, 257, 293, 314
318, 319, 321, 330, 340, 383, 412
     preventing 302
Pope 252
Port Interface Network, see PIN
portal 11, 12, 31, 33, 38, 45, 60, 61, 74, 76,
                89, 125, 128, 206, 227
bridge 27, 28, 51, 52, 64
control of 191
Hawaiian 235
Link  7
mechanics 4
project 177. 191
Portland,ME 359
power
     -generator crystals 5
     generators 57
Priests
of Amon 89
of Melchizedek 31-33
            balanced 33
            founding of 98
            unbalanced 33
of Mu 3,11,12, 32, 46
of Serres 95
of UR 264
of Ur 4, 11, 12, 32, 33, 56, 85, 89, 91-104,
         194, 197
Primal Creation Mechanics 422
Primal Order 281, 296, 297, 298
Primary Conjunction Points, see time cycles
Prime Initiative 352
Procyon 266
prolonged darkness and daylight 114
propaganda 178, 179
Protestant & Catholic Invasion 325
Psonns
     Master 303
     sacred 303
psychotronics 247, 251, 257, 344, 347, 356,
                       377, 385
public landing, to be staged 173
Pylon Implant Network, see PIN
pyramid 60. 61
   Cheops 61
   of Giza 61, 62, 63, 71, 86, 89-95, 100-
           102, 143, 187, 207
              alignment with Alcyone 65
              King’s Chamber 207
              rebuilt 86
Q
quarantine 70, 187
Quebec, Canada 430      
Queen Tiy 88-89

R
Ra 7, 22, 24, 34, 36, 46, 47, 50, 55, 56, 57,
               59, 66, 69, 96-100, 122, 233
Amonites 7, 34
Aton-a 7, 47
Azurites 7, 34, 97, 99, 100
Brigijhidett 7
Ra Confederacy, see Ra
race
      amnesia 255
      memory 25, 53, 76
radio
       as carrier for human programming 211
Rainbow Ray 302, 310
Rainbow Roundtable 303, 310, 315, 319, 324
      Regents of 302
      Rite of 306
      Tri-Veca 373
Rainbow Wearers 302, 306
Rama 263, 276
Rashayana 371
Real Ratios 259
reality fields 452
recent history 122-126
Red Pulse 133-134, 188
Redemption Contacts 380
Redemption Contracts 370, 379
Reiago 146
reincarnation 20, 148
Anna remembers her 236
ending the cycle 108
two 12-cycles 16
religion 411, 422