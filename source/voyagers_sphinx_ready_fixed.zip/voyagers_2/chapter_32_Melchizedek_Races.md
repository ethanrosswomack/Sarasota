32 
 
 
    

                                                                                     
                                                                                                                                          Melchizedek Races  
today. During their first appearance they created the Priesthood of
Melchizedek on Earth, a spiritual organization specializing in the process of
ascension, which over time developed a strong elitist, sexist, patriarchal slant
due to Atlantean and Sirian-Anunnaki influence. About 32,000 years ago
some of the Melchizedeks joined forces with the matriarchal Taran Priest-
hood of Mu, creating a more balanced Melchizedek Priesthood which more
closely followed the teachings of equality promoted in the original
Melchizedek Priesthood. The balanced Melchizedek priesthood became
known as the Cloistered Family of Melchizedek , for they carried with them
the original sacred Law of One teachings of the Melchizedek morphogenetic
cloister.  
    The egalitarian Melchizedeks became known as the Speakers of the
Blue Flame  about 10,000 years ago (about 8,000 BC) when the Priesthood of
Ur and the Palaidorian Council of Tara transferred Earth guardianship of the
Staff of Amenti/Blue Flame/Tara's morphogenetic field out of the hands of
the unbalanced, patriarchal Melchizedek Priesthood and into the hands of
the balanced Melchizedek Priesthood. The Taran Priests of Ur disassociated
themselves from the patriarchal Melchizedeks, attributing their elitist, sexist
slant to infiltration of the Sirian-Anunnaki cultures, who brought with them
to Atlania, and later Atlantis, the distorted teachings of the original Templar
Solar Initiates whose elitist, aggressive misuse of power for materialistic gain
had culminated in the cataclysm of Tara 550,000,000 years ago. This transfer
of guardianship of the power of the Blue Flame 10,000 years ago resulted in
the instrumentation of two more genetic frequency seals being placed upon
members of the sixth race Melchizedek Cloisters who were associated with
Templar distortions of the Sacred Law of One and also on any descendants of
the Templar-Melchizedeks or races who interbred with them and picked up
their genetic coding.  
    The Templar Seal,  as the first alteration became known, was imple-
mented 10,000 years ago, and represented a sixth-dimensional seal upon the
Halls/Sphere of Amenti. The second Templar Seal was administrated about
3,500 years ago when descendants of Templar-Sealed Melchizedeks infiltrated
Egyptian culture and violated the Covenant of Palaidor by opening the D-2
Earth portals as a way of orchestrating ascension through the D-1 and D-2
Underworld. Through their misdeeds many chaotic forces were unleashed
upon the Earth, and humans with distorted morphogenetic imprints were
released from the Seals of Palaidor and Amenti and allowed to pass into Tara.
Many tragic events since took place on Tara as a result of this misadventure
3,500 years ago, and a seventh-dimensional Seal  was added to the T emplar-
Melchizedeks who participated in these events. The second Templar Seal is
called the Templar-Axion Seal.  Both T emplar Seals made physical ascension
through the Halls of Amenti impossible for those who carried this genetic
configuration, and only under certain circumstances could the soul essence