93 
                                                                                                               
                                                                                                                                                                                                                                 
 

Return to Amenti  
core of Sirius B, under the Templar-Axion Seal. This group included over
1,000 people, who would be allowed to ascend to Tara as soul essences once
the Halls of Amenti were reopened, but once there, they had to repeatedly
incarnate on Earth until they had fully assembled the fragmented portions of
their soul essence from the D-2 elemental kingdom. Akhenaton and his half
brother Sabatoth, and various others of Cloister Melchizedek and Serres-
Egyptian lineage were among those placed under the Templar-Axion Seal.
This Sealing was again employed as a protective measure, to insure that the
remaining portions of the Amenti Sphere were not compromised by the mis-
aligned energies of D-2. But unfortunately, through generations following
this lineage, portions of the Templar-Axion Seal were passed down indiscrim-
inately throughout various racial families, and the Templar-Axion Seal
became like a curse to the races, causing misalignment in various portions of
the Amenti Sphere, which were further passed on through various genetic
lines. These distortions in the Sphere of Amenti would have to be realigned
with the 12-strand DNA imprint before anyone could again ascend through
the Halls of Amenti.  
    Suffering from confusion caused by the cumulative effects of these events,
Akhenaton grew progressively more disinterested in the common affairs of
Egypt and devoted his attention to ensuring the position of his son as the next
heir to the throne. At this point, conspiratorial plans to remove Akhenaton
from power brewed heavily within his own legions, promoted primarily by his
uncle (the younger brother of Amenophis Ill). His first wife Nefertiti found
sympathy with the conspirators, as she did not take well to the intended trans-
fer of her position and power, pending the validation of the son as heir. The
Flame Keepers and Ankhi (wife number 4, whom Nefertiti blamed for destroy-
ing her family) appealed to Nefertiti for compliance, at the insistence of the
Priests of Ur. Unfortunately for all, Nefertiti could not muster the required
humility, and in 1361 BC she assisted the uncle in sabotaging Akhenaton’s
plans. The uncle orchestrated the assassination of Ankhi and Akhenaton’s
two-year-old son, thereby leaving the issue of heir to the Pharaonic throne
open to the highest bidder.  
    Distraught over the loss of his son and what he perceived as the failure of
his earthly mission, Akhenaton withdrew from social interaction, as General
Haremhab, Sabatoth and others devised a plan to remove Akhenaton from
power to protect Egypt from Akhenaton’s declining rule. In 1353 BC, with a
heavy heart, General Haremhab turned a blind eye as Akhenaton’s aged uncle
led the final conspiracy, assassinating Akhenaton and arranging the temporary
succession of Smenkhkaré (husband of one of Akhenaton’s daughters, who
secretly held a pro-Amonist outlook) to the throne. Haremhab, Sabatoth and
the Keepers of the Blue Flame hoped to see Smenkhkaré replaced by Sabatoth,
but after the fall of Akhenaton’s reign in 1353 BC, Sabatoth was imprisoned as