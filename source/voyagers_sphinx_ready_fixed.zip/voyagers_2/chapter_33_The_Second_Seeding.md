33                                                                                                                    
                                                                                                                                                                                                                 
  

       
      The Second Seeding  
 pass through the Blue Flame. Those baring the Templar-Axion Seal could
 eventually pass into Tara and enter incarnations within the sixth races, but
  the Templar-Axion Seal did not allow them to transmute into their immortal
 seventh race bodies. The Templar-Axions were destined to repeat innumera-
  ble incarnational cycles upon Earth in order to clean up the mess they had
 made by releasing the chaotic forces of D-2.  
    Only the Elohim, the Axious Entity Family and Ra Confederacy families
     of the Azurites and Amonites, from the Metagalactic Core, or the Breneau
     Entities from HU-5 had the power to release the Templar-Axion Seal, and
      would do so only for humans who gained their favor through serving the
    truth of the Sacred Law of One.  
     The Templar-Axion Seal became as a curse upon the human lineage, as this
    distortion was passed on genetically;  as the Melchizedeks and their Hebrew
    hybrids interbred with other racial strains, the Templar Seals were passed on,
    in whole or in part, to incarnate souls who did not have this prior affiliation.
         Fragments of the Templar Seals that passed on genetically created a variety of
      incarnational and ascensional problems for anyone involved with them. The
  Seals were to remain intact for those whose prior affiliations with the Tem-
 plar Solar Initiates/Templar-Melchizedeks warranted such security measures,
      but attempts were made to help purge unintended Templar Seal holders of
  their genetic burden. The Elohim, Sirian Council of HU-2 and the Pleiadi-
  ans all assisted in this plan, offering ascension teachings through which the
     burdened races could purge their genetic code of the Templar Seals. Templar
       Seals can only be removed when this is approved by the Ra Confederacy and
   its Axious, Amonite and Azurite gestalt Families, the Entities who orches-
    trated the Templar Sealings in order to protect Earth and Tara.  
    The Templar Seals still affect a majority of the present human population, and
     the Elohim, Pleiadians, Sirian Council and other assistants from the higher Har-
        monic Universes still work to assist unintended Templar Seal bearers.  Through
   spiritual training, humans are led to at least a rudimentary understanding of
    the sacred Law of One, and once this education has taken hold, the Elohim
      or other helpers take the incarnate through the astral planes (if the incar-
      nate's fourth DNA strand is plugged in) into a meeting station within the
    eighth dimension Metagalactic Core. There the incarnate's personal mor-
    phogenetic field is evaluated to determine if Templar Sealing is in order as a
    planetary security measure, and if the Seals are unwarranted the Elohim peti-
    tion the Ra Confederacy to remove any trace of the Templar Seals. If the Ra
   Confederacy agrees, the Seals are removed and the incarnate's consciousness
   is allowed to pass through the eighth dimension where the DNA imprint in
      the morphogenetic field is repaired. The eighth-dimensional meeting place
            and passage way into the Metagalactic Core is often referred to as the Eye of
      Elohi m, or the Galactic Core.  Humans not bearing Templar Seal distortion
      can pass through this dimensional portal once they have fully evolved their