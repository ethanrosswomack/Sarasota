4 Evolutionary Rounds  who are commissioned to run the “Rainbow
        Ray” or “Khundaray” Primal Sound Current  from beyond the 15-Di-
         mensional Time Matrix, into Earth’s Planetary Shields during SACs .
          Running of the Rainbow Ray during SACs enables the planet to retain its
             natural electromagnetic balances to avert pole shift and restores the or-
        ganic D-12 Planetary Christos Alignment.  
  • Since the 9558 BC Atlantian Flood , knowledge of the RRTs  has been in-
       tentionally  hidden  from the Angelic Human races of contemporary Earth,
       by Human Illuminati and Fallen Angelic  races that desire to create pole
       shift during the long-anticipated 2000-2017 SAC.  They hope to use the
       2000-2017 SAC to finally fulfill their plan of clearing Earth’s real estate”
         of Angelic Human races to later resettle their hybrid races on Earth, “after
         the dust settles,” under a “One World Order” Anti-Christiac Agenda of
       totalitarian exploitation and dominion .
310 
 
 
     


                                                                                                                             
                                                                                              The Atlantian Conspiracy
                                  THE ATLANTIAN CONSPIRACY
     • The Fallen Angelic/ Illuminati Human Anti-Christiac Agenda gained a
                stronghold on Earth in 25,500 BC when Nibiruian Marduke-Anunnaki
                ( Anunnaki + Omicron  Drakonian) seized control of Nibiru and Earth’s
                D-4 Universal Solar Star Gate-4 , in an event known as the '' Lucifer Re-
                  bellion. '' 
   •  The name  “Lucifer”  comes from a hybrid Pleiadian-Nibiruian Anunnaki
                     Race that emerged through combining the Density-2 Nibiruian Lulitan
                     family of the Thoth-Enki-Zephelium (Zeta) Anunnaki lineage with the
                     Satain  family of the Marduke-Anunnaki line and the D-11 Necromiton
                    (''Beetle-reptile'') Fallen Seraphim race of Andromeda (most contempo-
                     rary '' Andromie '' channels  are these). From this hybridization the Pleia-
                      dian Samjase-Luciferian Anunnaki and Marduke-Necromiton-
                     Luciferian Anunnaki Races of Sirius B, Nibiru and Alpha and Omega
                     Centauri emerged. This collective of Anunnaki Races promoting an
                     Anti-Christiac dominion agenda became known historically as the '' Lu-
                     c iferians ,'' and were occasionally joined by other Anunnaki and Illumi-
                             nati Human race lines in their “Quest for the Holy Grail.”
  • The '' Holy Grail '' is a term used in reference to the 1 2 Universal Signet
        Star Gates of the Universal Templar Complex,  to which the  Angelic
          Human Race holds the Sacred Commission of “ Guardian .” The “Grail
          Quest” began long before Angelic Humans were seeded on Earth and it
                 has been  the primary theme of motivation  behind all of the Forbidden  and  
               recorded-distorted human history.  
        • The Grail Quest for Earth’s Planetary Templar Star Gates continued into
               Angelic Human 12-Tribes Seeding-3 , following destruction of Seedings-
                1 and 2 via Grail Quest Wars with Anunnaki and Drakonian  Fallen An-
              gelic Legions. During the 25,500 BC Lucifer Rebellion , Anunnaki Lu-
              ciferians gained partial control  over Earth’s Templar through a device
              called the Nibiruian Diodic Crystal (NDC) Grid , which is still in oper-
              ation today  and serves a key role  in the potential outcome of the 2000-
              2017 SAC  
   • In 22,326 BC the Luciferian Anunnaki races decimated guardian races at-
       tempting to intervene in an event known as the Eieyani Massacre, which
         took place on the remnants of the Lemurian Continent  now known as
       Kauai, Hawaii. In 21,900 BC  they collapsed the Firmament Hydro-sus-
         pension Fields of Lohas, northeast Atlantis  in the Lohas-Celtec-Dru-
          idec Freeze Out,  in an attempt to destroy the Maji Angelic Human Grail
          Kings in exile there; this event gave us our last major glacial period of
              21,900 BC-14,000 BC . In 20,000 BC  they staged the Vicherus-Sa-
        cheon Invasion of Russia.  In 10,500 BC  the next phase of the Luciferian
            dominion plan unfolded in an event called the Luciferian Conquest , at
            which time the Atlantian Islands of Nohasa and Bruah  fell to Annu-
           Melchizedek Anunnaki-Human hybrid and Fallen Jehovian and Lucifer-
        ian Anunnaki control.  
  311  
                                                                                                             

                                                                       The Atlantian Conspiracy and Roundtables
  • The Anti-Christiac Agenda of the Luciferian Anunnaki Races (not all
       Anunnaki are in the “Luciferian” category; some run competing dominion
       agendas) was formerly mandated in Bruah Atlantis in 9560 BC  under
       an Agreement called the Luciferian Covenant.  The Luciferian Covenant
         is part of  3 competing One World Order dominion agendas  collectively
       referred to as the Atlantian Conspiracy . The Anunnaki Races of the Lu-
       ciferian Covenant orchestrated the “Atlantian Flood” in 9558 BC  and
         the intentional “re-writing” of human history  since this time. Forbidden
             History reveals a  long-term plot  within which the Anti-Christiac Agen-
         gas of the  Atlantian Conspiracy  emerged after the flood  into the  present
       day.  
   •  The Luciferian Covenant continued after the 9558 BC ﬂood in the  8,900
        BC “Larsa King” Sumerian Invasion, the 8,400 BC “Scarab King”
        Egyptian Invasion , and the 7,500 BC Knights Templar Invasion . The
           infiltration continued with the 5,900 BC Centaurian War, when the
       Sirius B Maharaji  (Blue Human Guardians) intervened directly with air
    raids to prevent Drakonian and Luciferian Forces from claiming world do-
      minion. This event is partially documented  in the ancient Hindu text of
    the Mahabharata.  
    • In 3,650 BC  the Nibiruian Luciferians orchestrated the Mayan Raids , and
          in 3470 BC the “Babble-On” Massacre  was waged, in which Pleiadian-
         Nibiruian  legions, Galactic Federation and the Annu-Melchizedek Hu-
          man Illuminati gained temporary control  over the Maji Grail Kings’ “ Arc
       of the Covenant  Gold Box ,” which contain the “ Rod and the Staff ” star
        gate tools. In conjunction with the Nibiruian-Diodic-Crystal-Grid at
        Stonehenge, England, the Arc Tools  were used in Babylon  to cause tem-
          porary collapse of Earth’s magnetic grids  and to set portions of the Fire
                         Letter Sequences  in Earth’s Planetary Shields into reverse sequence.  
                   • Planetary Shield distortions of the 3470 BC “Babble-On” Massacre  caused
      mutation in the human DNA Template  that shortened human life span ,
      blocked Higher Sensory Perception,  caused loss of  Race Memory and
        ''scrambling '' of our original language patterns,  which are built upon
          DNA Template Fire Letter Sequencing . Our race has been amnesiac,
      dying young and “babbling on”  in rhetorical con ﬂict ever since. This his-
                         torical event was recorded  as the Biblical “Tower of Babel”  story.  
                 
                   • Following the Babble-On Massacre of 3470 BC, Fallen Angelics selected
            “Chosen Ones, ” Annu-Melchizedek hybrid descendants, for minimal
              DNA Template repair and implantation , through which the Luciferians
          and competing Jehovian-Anunnaki and Drakonian legions could begin
             their progressive infiltration  of human spiritual and political systems.
             Through the technology of remote '' channeling '' conducted through un-
         natural DNA Template implantation,  the “Chosen Ones” have been
         progressively fed Anunnaki History and distorted patriarchal ''War
                 God” spiritual teachings, in a strategic and intentional replacement of
               the Angelic Human heritage. They are once again '' channeling '' to us
               and visiting today  as the dominant force  in the New Age and UFO
              Movements.  
        312   
   

                                                                             
                                                                                              
                                                                                                     The Atlantian Conspiracy
                         • “D-12 Maharic Sealed Channels”  can create protection  from interdimen-
             sional manipulation of their natural bio-neurological communication
                lines.  
   •  Following their 2668 BC Djoser Invasion  of Egypt, Galactic Federation
               continued their previous alliance with the Anunnaki of the Luciferian
               Covenant, temporarily stealing the Arc of the Covenant Gold Box and
               Tools in 2024 BC . At this time they launched an attempted world do-
                 minion assault  called the Dead Sea Conquest,  beginning with Babylonia
                  and Sumerian Cities  in the areas of the Dead Sea ; the Biblical stories of
                    the destruction of “ Sodom and Gomorrah ” referred to this event. “God”
                   did NOT destroy these ancient cities any more than “God” orchestrated
                 the scrambling of the languages in the 3470 BC Babble-On Massacre;God
               is NOT a Fallen Angelic-ET.  If Maji Grail King Angelic Human Races
               had not retrieved the Arc of the Covenant Gold Box and Tools in 2024
                    BC, the Jehovian and Luciferian Anunnaki Races of the Galactic Fed-
                  eration  would dominate the world by now.  
    •  Since the time of the staged 9558 BC  Atlantian ﬂood, human history has
                      been a progressive advancement  of the Atlantian Conspiracy and Lu-
                 ciferian Covenant  Anti-Christos Agendas. The stories of Noah, Abra-
                      ham, Moses, the Hyksos Kings and the ''3  Christs '' are key pieces to the
                Atlantian Conspiracy drama. At the center of this drama are the Arc of
                      the Covenant Gold Box,  its star gate tools  and the core objective  of the
                 ancient Fallen Angelic/ Illuminati Human Grail Quest.  
      •  Competing Jehovian-Anunnaki, Luciferian Anunnaki and Omicron , Od-
                                       edicron and Zephelium (Zeta) Drakonian/Reptilian Fallen Angelics  and
              their Annu-Melchizedek Illuminati Human hybrid race descendants¹
                   share one objective-dominion of Earth, in order to claim Earth’s Halls
                   of Amenti Star Gates.  
   •  If the Fallen Angelic races can gain dominion of Earth’s Halls of Amenti
            Star Gates, they intend to use the Amenti Star Gates to destroy Univer-
               sal Star Gate-12 in Density-4.  Destruction of Universal Star Gate-12
                          would effectively seal off from Density-5 Founders Race protection,  11-
            dimensions  of our 15-Dimensional Time Matrix. The manifest life field
             would become “imprisoned in time” for Fallen Angelic exploitation and
            dominion, unable to fulfill the natural evolutionary process of ascension.
           This is the core motivation behind the Fallen Angelics’ continuing Grail
             Quest. Prevention  of this Anti-Christos Agenda is the purpose for which
            the Angelic Human Race  was created 560 million years ago.  
     • To accomplish their objective of claiming Earth and the Amenti Star Gates,
            Fallen Angelics need to possess the Arc of the Covenant Gold Box and
            star gate tools , and to achieve critical mass population  of their hybrid-
               human races, whose DNA Templates  carry reverse sequenced Fire Let-
          ters.  During a Stellar Activations Cycle , the Arc Tools, the still-func-
          tioning Nibiruian-Diodic-Crystal Grid  (from 25,500 BC), Nibiruian
    ______________________________________       
1.     Known as the Leviathan Anti-Christiac : King lines.    
 313                                                      
                                                                                                       

                                                                          
    The Atlantian Conspiracy and Roundtables
  
                 controlled Solar Star Gate-4  and the false-planet Battlestar Nibiru  can
               be used to create intentional pole shift  on Earth to ''clear the real estate.''
     •  If they can successfully exterminate Angelic Human Races from Earth, the
             Luciferian and Jehovian Anunnaki Races intend to return their ''Chosen
              Ones''Annu-Melchizedek descendant humans to Earth during the SAC.
              The “Chosen Ones”  will be used  to run critical mass reversed Fire Let-
              ter Sequences  into Earth’s Planetary Shields  and the Amenti Star Gates
                 in fulfillment of the Anunnaki Anti-Christos Grail Quest Agenda. This
                plan was formalized in the  9560 BC Luciferian Covenant  and has been
                   progressively unfolding . Since 9560 BC the anticipated date  for the Final
              Con ﬂict and intended, orchestrated pole shift  has been the 2000-2017
              SAC.  Now.  
          • Many times throughout the advancement of the Atlantian Conspiracy,
                Guardian Races of the Emerald Covenant have repeatedly intervened.
                  Guardian races have kept the Angelic Human and Maji Grail Line
               DNA Templates  alive within the human gene pool,  so Angelic Humans
                could rise together  during the 2000-2017 BC Final Conflict drama , to
                fulfill the Christos Realignment Mission and prevent further advance-
               ment of the Atlantian Conspiracy.  
    • During the Christ Drama of 12 BC-27  AD the Founders’ Emerald Cove-
                     nant  CDT-Plate teachings  were translated by the 3 Maji Grail Line
                 Speakers,  Jesheua Melchizedek  (aka Jesus Christ), John the Baptist and
                     Miriam, to prepare humanity  for the 2000-2017 Final Conflict.
   • The heart of the 12 BC-27 AD Christ Drama  was not only CDT-Plate
              teachings; Jesheua, John, Miriam and a group of Maji Grail Line Angelic
              Humans were on a Emerald Covenant Grail Quest Mission to secure
                 Earth’s Star Gate-11  from Anunnaki and Drakonian Race infiltration.
                       Both Luciferian and Jehovian Anunnaki Races, and their Annu-
                 Melchizedek Illuminati descendants seek to claim the Arc of the Cove-
                 nant Gold Box and star gate tools to  take control of Earth’s Star Gate-
               11, for use in  imploding Universal Star Gate-12  during the 2000-2017
              BC Stellar Activations Cycle . This plan was known since the success of
                 the 25,500 BC Lucifer Rebellion.  
      • Jesheua and his Universal Templar Security Team intended to use the Arc
              of the Covenant Gold Box star gate tools  (“Rod and Staff”) to release
              Anunnaki Nibiruian Diodic Crystal Grid Crystal  control over Earth’s
                Templar and Solar Star Gate-4. The mission of Jesheua, John, Miriam and
              the Maji was intended to prepare the Angelic Humans of Earth to fulfill
                      the Christos Realignment Mission  during the anticipated 2000-2017
                 SAC . In 23 AD  Jesheua and his Maji were attacked by the Annu-
                Melchizedek Hyksos and Hassa Leviathan King  races, in an event called
              the Essene Divide , which rendered them unable to fully complete  their
              intended journey to the lands previously known as northern Lohas At-
              lantis , the location of Earth’s Star Gate-11.  
        •  To protect the Arc of the Covenant Gold Box and star gate tools, John and   
              Miriam completed part of the journey  to Lohas, burying the Arc of the
                    Covenant Gold Box and tools in the area now known as the Vale of Pew-
           314
     

                                           
                                              King Arthur and the Knights of the Roundtable
      sey, England.  Jesheua and his group of Maji served as a Signet Council , a
        group of Angelic Human Maji commissioned to '' Run the RRT '' prepar-
       ing Earth’s Planetary Shields for the 2000-2017 SAC.  
• The CDT-Plate teachings  of these 3 Essene Emerald Covenant Speakers
           contained the Planetary Templar Mechanics  by which the Planetary
       Christos Realignment could be achieved in the 2000-2017 SAC. These
           teachings were later stolen, edited and falsified int o a Religious Control
            Dogma in 325 AD , by the Council of Nicaea and the Drakonian Infil-
        trated Church of Rome;  the falsified CDT-Plate  teachings of Jesheua,
       John and Miriam were interwoven with Annu-Melchizedek Leviathan
        King Anunnaki history  to create the Canonized Bible.  
• The Mission of Jesheua, John and Miriam later resumed between 559-608
        AD,  when the '' Quest for the Holy Grail '' the Atlantian Conspiracy
       and the hunt for the Arc of the Covenant Gold Box and star gate tools
       continued in the drama of King Arthur and the Knights of the Round-
        table.  
                 KING A RTHUR AND THE KNIGHTS OF THE ROUNDTABLE
•  King Arthurus , or “Arthur” was born from a Druidec Maji Grail King lin-
          eage  originally from Nohasa and later exiled to Lohas Atlantis.  Arthur
         and his selected Signet Council “Knights”  were commissioned to fulfill
       the 10 AD-27 AD Emerald Covenant Mission that Jesheua, John the Bap-
         tist, Miriam and the Essene Maji were unable to complete due to the Hyk-
       sos-Hassa King raids in the 23 AD Essene Divide. Arthur’s legendary
       sword ''Excalibur '' was a battle sword fashioned to hold the Staff star
         gate tool  from the Arc of the Covenant Gold Box,  which Arthur and
           Victorous  (son of Meridan) retrieved from the Vale of Pewsey  in En-
        gland, where John and Miriam had buried it in 23 AD.  
   
• Victorous , son of Meridan , came to be known as “ Merlin ” Arthur’s Vizier
       and court mystic in the Arthur Legends. Victorous’ father Meridan was a
        Knights Templar Annu-Melchizedek  Black Arts Occultist, his mother
        was of a Celtec Maji Grail King line  originally from Lohas Atlantis. Vic-
       torous’ life and service to King Arthur were overshadowed by the struggle
         of “good vs. evil” that existed within his genetic programming.  
• Arthur’s wife  Guinevere  was of a Celtec Maji Grail King  line originally
        from Lohas Atlantis. Guinevere’s sister Saleane , not Guinevere, was the
        lover of Arthur’s imposter Knight “ Sir Lancelot, ’’ a Luciferian Knights
           Templar sent in to sabotage the Emerald Covenant Mission. Knights
       Templar Annu-Melchizedek races intentionally distorted  true Arthurian
        period history. Teachings of the RRTs and Star Gate Signet Councils
         were hidden in occult secret societies of the Knights Templar. The histor-
         ical  realities  of the Maji Grail King lineage and Arthur’s Emerald Cov-
            enant Mission were intentional “ re-written Nibiruian Anunnaki
          style ,” romanticizing Victorous (''Merlin'') and other characters that as-
           sisted the Knights Templar in undermining Arthur’s  Emerald Covenant
          Mission .      
    315                                                                                          
   

                                             The Atlantian Conspiracy and Roundtables
 • Throughout the Arthurian drama (559-608) the Luciferian Knights Tem-
            plar Annu-Melchizedek Illuminati Human  races, under the direction of
           the Galactic Federation  and the Pleiadian-Nibiruian Anunnaki  races,
           quested to steal the Arc of the Covenant Gold Box and “Excalibur
          Sword” Staff  star gate tool from Arthur’s guardianship. Arthur and the
         Signet Council Knights quested to retrieve the Rod star gate tool  and the
         Star Gate-11 control device called '' Signet Shield-11 '' which had been
         stolen from the Essenes by the Hyksos Kings and Knights Templar in the