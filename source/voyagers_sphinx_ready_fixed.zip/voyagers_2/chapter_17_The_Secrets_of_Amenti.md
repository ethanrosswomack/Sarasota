17 
                                                                                                                                             
                                                                                                                         
                     

              
             The Secrets of Amenti  
 Root Race, and first physical Root Race to appear on Earth were the Lumari-
 ans. They were a brown race that appeared about 15 million years ago, who
  were assigned to assembling the second strand of DNA. Following the Lumari-
 ans and their seven sub-races and 49 families was the Second infusion of the
 Breanoua Cloistered race and their five subraces and 25 families. They entered
 through the peoples of their first incarnational wave about 12 million years ago.
 Entering through the peoples of the Breanoua Cloister came the Fourth Root
 Race, the Alanians  and their sub-races and families. The Alanians appeared
 about nine million years ago, a red skinned race, who were responsible for
 assembling DNA strand #3. The five Cloister Races and the Lumarian and
  Alanian Root Races evolved together on Earth between 25 million to 5.5 mil-
 lion years ago, developing high culture and much diversification. Incarnates
 who kept the integrity of their genetic code transmuted through each of the
 races then ascended within their immortal bodies through the Halls of Amenti.
 This period in time is known as The First Seeding,  and represents  the Third
  World in Native American tradition.  
                                                           THE ELECTRIC WARS                     
                               The Electric Wars & Palaidorian Resistance Entity Wars
                                                                                                                  5,509,000 - 5,508,100 YA
       During the course of the First Seeding all went well as many soul frag-
 ments from HU-1 Earth successfully ascended through the Halls of Amenti
 back into Tara. But many members of the races from the First Seeding had
 also begun to digress through animal interbreeding and contact with HU-1
 ETs, some losing the ability of genetic transmutation and thus their immor-
 tality. About 5,509,000 years ago members of the Sirian-Anunnaki race from
 HU-2, along with several other groups of ETs and metaterrestrials from the
 higher Harmonic Universes wanted to stop the evolution of the earthly races
  and abandon the Turaneusiam-2/12 Tribes experiment, for fear that the
 mutating genetic code of the 12 Tribes would contaminate the races of Tara
 as they ascended through the Halls of Amenti. Many HU-2 species did not
 want the digressive human element to return to Tara, for they were already
 creating damage within the energetic systems of Earth, and those of Tara
needed protection from such activities. Numerous other groups simply
 wanted Earth territories for their own purposes. The Resistance groups began
 a war with the Elohim from HU-3, and those of the Covenant of Palaidor in
 HU-2. Entities of the higher Universes descended upon Earth, and great bat-
  tles of pure energy were fought in Earth's local galaxy and within Earth's
   atmosphere. These events became known as the Electric Wars.  The wars
 lasted around 900 years as Entities of these opposing groups battled for con-
 trol over Earth's natural portal system and the Sphere of  Amenti. The human
  races caught in this battle either ascended to Tara through the Halls of