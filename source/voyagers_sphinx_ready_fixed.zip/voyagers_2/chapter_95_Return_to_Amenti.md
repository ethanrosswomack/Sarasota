95 
                                                                                                                            
                                                                                                                                     
                                                                                                                  
         
            

Return to Amenti  
Ur. By 1309 BC the Elohim plans for opening the Halls of Amenti and pre-
paring the races for the mass ascension wave of 2017 AD were lost beneath
the chaos left in the wake of Akhenaton’s clandestine rule.  
    Although Akhenaton was ultimately successful in re-entering the Annu
people into the Sphere of Amenti and successfully orchestrating the ascension
of many individuals during his brief reign, he left an equally detracting legacy of
chaos behind him. The Halls of Amenti were closed, the Sphere of Amenti
was broken in two, with part of the race morphogenetic field in chaotic sham-
bles within the D-2 Earth core and the other part again quarantined in the
UHF bands of the third dimension. The Arc of the Covenant was once again
sealed, and the Frequency Fence, which kept the Sphere of Amenti from
descending through the Arc, was once again put in place. Following the death
of Tutankhamon in 1331 BC, the Elohim and the Priests of Ur, disheartened by
the error of the human element, transferred surface guardianship of the Arc of
the Covenant out of Egyptian hands. The Arc of the Covenant was placed
under the protection of the Hibiru Cloister races, under the supervision of the
Blue Flame Melchizedeks. The Rod and Staff were de-activated, and thus
entry into the portals of the Inner Earth was stripped away from all races within
the surface cultures .¹ 
                                      
                                       THE THREE CHRISTS     Elohim and Sirian Council Favoritism toward Sirian Genetic Strains
  and Promotion of Patriarchal T emplar Creed Distortion. Pleiadian,
 Arcturian, and Andromeda Resistance and Azurites Appointed by Ra
Confederacy as Co-guardians of Palaidorian Covenant. Division within
                the Cloister Melchizedeks and Essene Brotherhood.  
                                               1240 BC -12 BC        
    The chaos which resulted from the misfortunes of Akhenaton’s reign also
created a major division within the ranks of the Elohim of HU-3, the Sirian
Council of HU-2 and the Ra Confederacy from the Meta-galactic Core. Dis-
pute arose as to what should be done with the program of human evolution.
The majority of Elohim had abandoned their loyalty to the human races in
general, and saved their attentions for Annu-Melchizedeks and Hebrew peo-
ples to whom they had closer genetic ties. In the years following Akhenaton’s
demise, the Elohim and Sirian Council began showing their favoritism of
these groups by purposely influencing the developing cultures to adopt the        ________________________  
1.   Some historical reference sources suggest that Akhenaton reigned from 1353-1335 BC
    and place Tutankhamon’ s reign from 1333-1323 BC. Speakers from the Sirian Council
                                provided the dates 1370—1353 BC for Akhenaton’s reign and 1340-1331 BC for Tut-
                            ankhamon; they request that I leave the dates as they have given. I cannot personally                                                                      
                                        attest to the accuracy of either set of dates .