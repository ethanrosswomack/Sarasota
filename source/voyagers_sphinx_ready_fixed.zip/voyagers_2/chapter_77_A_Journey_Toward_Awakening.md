77 
                                                                                                                 
                                                                                                                                                                                                                           
 

A Journey Toward Awakening  
between the waking identity and its astral experience. This gap, created by
the missing 7-12 base tones and 7-9 overtones, created a distortion in dream
recall, in which the consciousness would encounter the missing tones and be
unable to translate sensory information from frequency bands corresponding
to those tones into the genetic code. Prior to the Frequency Fence, memory
of other dimensional experience during the dream state was far more lucid, as
experiences the consciousness had while disassociated from its focus in the
body during sleep would be stored in the form of electrical impulse within the
consciousness, and when the consciousness returned to the body these elec-
trical impulses would be translated through the body into coherent, sequen-
tial memory patterns.  (Note: conscious recall of higher dimensional experience requires the
fourth DNA strand, as this strand allows the higher-dimensional experience
to be transferred into the lower DNA strands and then into cellular memory
and conscious recognition. The Third Lamanian/Lemurian Root Race and
their Ur-Antrian Cloister, and the fourth Atlanian/Atlantean Root Race and
their Breanoua Cloister did not dream multidimensionally as the later races
would, because they did not have the fourth DNA strand manifest within
their genetic code. Their dream experience was limited to activity taking
place within the second- and third-dimensional fields. The Fifth Root Race
Ayrians/Aryans and their Hibiru Cloister brought multidimensional dream-
ing and astral projection of consciousness into the human gene pool, as they
held the fourth strand DNA imprint within their genetic code. In the races of
the First Seeding, before the Seal of Amenti was manifest in the gene code,
dreaming took place on a fully conscious level and a sleep state of disassocia-
tion from the body was not required, as perception of various dimensional
fields took place on a fully conscious level. One would consciously perceive
and interact with the dimensional fields corresponding to the number of
DNA strands in the gene code, and the physical body was continually replen-
ished on a conscious level by drawing energy from the morphogenetic field of
Amenti through breathing. Only after the Seal of Amenti was applied did
humans have to disassociate from the body in sleep to revitalize the physical
structure and participate in other dimensional experience.)  
    After the Frequency Fence of 9540 BC was in place higher-dimensional
experience was unable to translate directly into the human cellular memory.
The electrical impulses within the consciousness, within which the imprint of
higher dimensional experiences were stored, could not pass through the gap
within the third DNA strand, so this experiential memory could not be trans-
lated into conscious, sequential dream recall. In contemporary times, now that
the Frequency Fence is beginning to lift and the third DNA strand is being
repaired, sequential dream recall and memory of higher dimensional experience is
once again developing in the races, and experiences associated with development
of the higher DNA strands, such as lucid dreaming, simultaneous dreaming, con -