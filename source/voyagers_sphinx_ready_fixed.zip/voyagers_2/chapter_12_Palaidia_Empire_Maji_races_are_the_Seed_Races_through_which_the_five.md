12 Palaidia Empire Maji  races are the Seed Races through which the five 
Urtite-Cloister Maji  Races  of the Urtite-Cloister Empires on surface Earth 
emerged between 798,000 BC and 500,000 BC. The five Urtite-Cloister 
Empire Maji  Races that emerged on surface Earth through the 5 Palaidia 
Urtite-Cloister Maji lines  carry the same race names as their Palaidia Urtite-
Cloister forefathers, the Urtite-Cloister Mu’a (Muarivhia), Yu, Ur, Breanoua
and Rama. The Urtite-Cloister Maji races that founded the surface Earth
Urtite Empires carry 12 to 24 Strand DNA Templates containing the 144 
Planetary Master Key Codes and 1728 Planetary Encryption Key Codes; the
Planetary Signet Key Codes  of the Amenti Templar Planetary Security 
Team. The 5 Urtite-Cloister Empires of surface Earth are the Seed Races 
through which the 5  Cloister Races (7 to 12 +1 Strand DNA Template) and 
seven  Root Races  (2–6 + 7-12 Strand DNA  T emplate potential) of the con-
temporary 12 -Tribes Angelic Human Races emerged (see page 15) to form
the genetic origins of the contemporary human race. The first 2 Angelic 
Human Root Races, the Polarians and Hyperborneans, evolved on Etheric 
Density-3 Gaia. The remaining 5  Cloister and 5 Root Races  of the Seeding-3 
12-Tribes Angelic Human “Maji King” Christiac-Rishic Holy Grail Line,
progressively emerged on Earth through the 5 Urtite-Cloister Empire Maji 
Races that emerged on surface Earth from the 798,000BC Palaidia Empires.  
______________________________  
14.  144 Encryption Keys per Gate x Gates 1-10 = 144 x10 =1440  
277 
                                                                                                           

   
     The Angelic Human Heritage and Rainbow Roundtables                                                   
                                               THE RIDDLE OF THE “ROUNDTABLE” — 
                         LOCATION OF RACE SEEDINGS AND RITES OF THE ROUNDS 
                           
                              Palaidia Empire Geographical Settlements and  
                                   DNA Template-Star Gate Correlation  
      The significance of understanding the nature of Palaidia Urtite-Cloister
Races from which contemporary humanity emerged is not only  in that we 
can regain insight into the original majesty and “Divine Nature” of the 
human genome  and the  hidden purpose of humanity’s Divine Mission that 
the human genome implies. Through understanding the design and purpose  
through which the Palaidia Races were seeded also reveals the intrinsic
design and hidden purpose behind and within humanity’s genetic evolution ,
and where within this greater evolutionary design our contemporary human 
culture  fits. 
        The five Palaidia Races were seeded in precise locations  on Earth that 
corresponded directly to the locations of Earth’s 12 Templar Cue Sites  (see 
page 269 ). Earth’s 12 Templar Cue Sites  mark the surface Earth locations of 
the 12 Inner Earth Star Gates  and Crystal Pylon Temples , through which
the opening of surface Earth’s 12 Primary Templar Signet Site star gates
could be manually directed .   Not only were the five Palaidia Races distributed
among Earth’s 12 Templar Cue Sites, they were distributed with precision .
The DNA Template  encoding of each Palaidia Urtite-Cloister race directly 
correlated  to the 12 Master Key Codes  and 144 Encryption Key Codes
of each Signet Set that corresponded to the Templar Cue Site  to which they
were assigned. The Palaidia Races were settled in geographical areas in 
which their DNA Template encoding corresponded directly to the Star 
Gate affiliated with that location. The five races  of the Palaidia Empires col-
lectively carried the 12 Universal Master Key Codes and 144 Universal 
Encryption Key Codes  through which the 12 Planetary, Galactic and Uni-
versal star gates of our Time Matrix  could be brought into remote activa-
tion. The Mu’a (Muarivhia) races carried the 43-48 Strand DNA Templates
corresponding to Universal Star Gates 1 through 12 , and were thus 
assigned to Earth’s Templar Cue Site 12  as Guardians of the 12th Gate.  In 
the Primal Order  of dimensionalized frequency fields, the highest frequency 
fields have the greatest power, and thus the dimension-12 Star Gate-12  nat-
urally possesses overriding directional power  over the 11 Star Gates  below
its placement in frequency. The 12th Gate in the  Universal T emplar is the
frequency passage that opens to dimension-12  of the Density-4 Pre-matter
 ''Liquid Light'' field , the Universal Christos “ Divine Blueprint ”; the  
“Shield of Aramatena ” (see Chapter 12) that corresponds to the coordinates 
of the Universal Star Gate-12 planet Lyra, Aramatena .  
     In the Founders  plan of creating the D-12 Christos Realignment  within 
the four Densities of the Manifestation Templates of Earth, Tara and Gaia 
and their surrounding galaxies , Universal Star Gate-12  holds the final key
278 
         

                                                                                                    
           The Riddle of the “Roundtable’’
to planetary and galactic Christos Realignment . Through Universal Star
Gate-12, the  D-12 ''Christos Templat''  frequencies can be run through the 
planetary bodies in a galaxy, to  reset  the original natural Pre-matter Tem-
plate , or “Divine Blueprint ”, upon which the galaxy and its planets first
manifested. The Mu’a races  of the Palaidia Empires were designated as 12th 
Gate Universal Guardians , and so they were settled in geographical loca-
tions  of Earth that corresponded to Earth’s activation and opening sites of 
the Universal Star Gate-12  Lyra-Aramatena  Gate. The Mu’a race lines
were incarnate members of the GA’s D-12 Council of Lyra-Aramatena.  
     The Mu’a races held the Universal Signet Key and Encryption Key
  Codes  to all 12 Universal, Galactic and Planetary Star Gates  within  their 
DNA Templates. The Mu’a races were thus settled in locations correspond-
ing to Earth’s  Star Gate-12 , and also in locations corresponding to other
Star Gates  of Earth’ s T emplar that were in most need of additional security .
The Yu races  of the Palaidia Empires carried the Universal Master Key and 
Encryption Key Codes  to Universal, Galactic and Planetary Star Gates  2 
through 11  in their 37-42 Strand DNA Templates .  Universal Star Gate-
11 is the Density-4, D-11  Pre-matter  gate corresponding to Aveyon, Lyra ,
the second most powerful Star Gate  in the Universal Templar . Members of 
the Yu race  are incarnates of the GA ’ s D-11 Council of A veyon , the desig-
nated 11th  Gate Universal Guardians , and thus Yu races were settled in geo-
graphical locations corresponding to Earth’s Star Gate-11  activation and 
opening points. The Yu races were also settled in other gate areas correspond-
ing to Star Gates 2 through 11 , that were in need of additional security. The 
Ur (Urta) races of the Palaidia Empires carried the Universal Master Key 
and Encryption Codes  corresponding to Universal Star Gates 5 through 8  
in their 31-36 Strand DNA Templates , and were thus 8th Gate Universal 
Guardians. The Ur races  are incarnate members of the GA ’ s D-8 Council of
Mintaka-Orion, and were settled in areas of Earth that corresponded to Uni-
versal Star Gate-8 and in areas corresponding to Star Gates 5 through 8  that 
were in need of additional security.    
     The most powerful Universal Star Gates  in relation to the operations of
planetary, Galactic and Universal systems in our Time Matrix, and thus those 
most vulnerable to incursion by Fallen Angelic infiltration , are the D-12
Aramatena-Lyra , D-11 Aveyon-Lyra , D-10 Vega-Lyra  and D-8 Mintaka-
Orion Gates . In addition to these main Universal Star Gates, Universal Star 
Gates 1, 2 and 5 are also points of vulnerability. Star Gates 1, 2, 5, 8, 11 and 
12 are “Control Gates ” in the Universal Templar; they are the “ Gates of
the Middle Pillar ”, a reality that will be further explained shortly. Races such 
as the Mu, Yu and Ur, Breanoua and Rama races of the Palaidia Empires, who 
carry Universal Templar Security  commissions, are always settled in the 
geographical locations of Earth that correspond to the Star Gates  to which 
their DNA Temples are encoded . They are also assigned to Control Gate  
areas that are in need of additional security . The seedings of the Angelic 
279 
                                                                                                           
 

                                                                                                                                                   
    The Angelic Human Heritage and Rainbow Roundtables                            
Human races of Earth were never random  occurrences , nor were the hubs of 
human settlements determined by general environmental factors , such as 
proximity to water and natural food supply. Though environmental factors 
affiliated with the “hierarchy of needs” for human survival are an influence  in 
regard to human settlement on Earth, it is the location of the Star Gates of 
Earth’s Templar  that have always governed every human seeding and reset-
tlement.  The significance of understanding the DNA Template Star Gate 
Correlations  between the “ancient” Palaidoria Races is not only  in that 
through doing so we can identify the core geographical regions from which
  human civilization emerged .  The greatest importance  in understanding the 
DNA Template Star Gate Correlation  lies in that through this realization 
we can begin to understand the personal and collective roles  that contempo-
rary humans  play in relation to the Founders Christos Realignment Mis-
sion.  We can also begin to realize why the true history of our evolution on 
Earth has been saturated with attempts of Fallen Angelic  infiltration and 
intended dominion.   
    The ancient Urtite-Tri and Bi-Cloister Races  that seeded the Palaidia 
Empires of 798,000 BC  represent the  genetic heritage  from which contem-
porary humanity  emerged. The emergence of contemporary humanity was
not an accidental occurrence  that randomly emerged from this previously
organized  Palaidia Empire plan.  The evolution of contemporary humanity 
has always been an intrinsic part of the Palaidia Empire Emerald Covenant 
agenda; humans of the present time  are as much a part of the Founders 
intended Planetary Christos Realignment Mission  as are the Palaidia races 
of ancient times. What was not an intended part of the Palaidia Angelic 
Human Divine Evolution plan  was the degree to which Fallen Angelic infil-
tration, and resulting DNA Template  and consciousness mutation, has pro-
gressively occurred within humanity’s evolution on Earth. Humanity’s
current state of amnesia  regarding its Angelic Heritage, and subsequent   
neglect of its intended Divine Commission  as the force through which 
Planetary Christos Realignment would occur, was not part  of the Founders
plan. This digression of human biology and consciousness was, however , pre-
cisely the intention of Fallen Angelic races , who understood that the 
Angelic  Humans of Earth were a primary obstacle to fulfillment of their
plan  to take over the Universal Templar Complex  in this Time Matrix. 
The human evolutionary design of 12-Tribes Seeding-3 began with the five 
Urtite-Cloister Maji races  that seeded the first 12 Palaidia Empires  in 
regions corresponding to Earth’s 12 Primary Star Gates, but this plan did not
stop with the Palaidia Empire races.   
                     280
                 
                                          

                                                                                                                                                      
                                                               The Riddle of the “Roundtable’’  
                              Cycle of the Rounds, the Divine Blueprint of Human Evolution,                                                                Christos Realignment Mission    
       The Evolutionary Divine Blueprint  of human evolution on Earth was 
designed to accomplish the Founders Planetary Christos Realignment  
through a series of races cycles  called rounds .  Each Round  of human race 
settlement was intended to progressively bring in a cycle of frequencies  from 
the Universal Christos Template , the Shield of Aramatena. The Manifesta-
tion Templates of the Earth-Tara-Gaia body cannot be fully corrected to the
Christos Blueprint all at one time. Manifestation Templates are scalar-stand-
ing-wave grids of interdimensional light and sound frequencies upon which 
the planetary molecular base  builds up into manifestation. The molecular 
structure  of the planetary body must progressively expand to hold the  
greater amounts of interdimensional energy  that will infuse into the Plane-
tary Manifestation Template through the Christos Realignment.  If too much 
frequency is fed into the Planetary Template too rapidly, the physical struc-
ture of atoms, molecules and sub-atomic particles will be unable to alter their
natural vibration rhythm  fast enough to keep up with Template accelera-
tion. If an excessive amount of D-12 frequency from the D-12 Shield of Ara-
matena Universal Christos Blueprint was brought into the Planetary 
Manifestation Templates of the Earth-Tara-Gaia system at one time, the
planetary body would literally explode . The Founders designed the human
evolutionary plan with full understanding of these basic principles of Unified 
Field Physics  and Primal Order Creation Mechanics. The Palaidia Urtite-
Cloister Maji races, as bearers of the greatest amount of frequency  through 
their DNA Templates, were seeded first.  The Palaidia Urtite-Cloister Maji 
presence served to regulate the progressive flow of D-12 frequency into the 
Planetary Shields  of Earth’ s Manifestation T emplate and to set the Core 
Template or “Kathara Grid”  of the D-12 Shield of Aramatena within the
Planetary Shields of Earth-Tara-Gaia. Next, a series of evolutionary Rounds 
would take place , by which Angelic Human races with less sophisticated 
DNA Templates,  and thus less frequency transmission capacity , 
would sequentially cycle  on Earth, to slowly and progressively increase  the 
amount of frequency brought into Earth’s Planetary Shields from the D-12 
Shield of Aramatena.   
     The Cycle of the Rounds  was intended to work in the following manner: 
The Seed Races with the highest DNA Template frequency transmission 
capacity were brought in first to anchor the Kathara Grid Template of the
Shield of Aramatena  into Earth’s Planetary Shields. The energy naturally 
transduced through their accelerated DNA Templates was progressively 
received, stored and released in increments into Earth’s Planetary Shields
through the 12 Selenite Rods in the Crystal Pylon Temples of Inner Earth.  
When Earth entered a natural Planetary Stellar Activations Cycle (SAC),  
the Maji Races would hold the natural configuration of the D-12 Shield of  
281
                                                                                                               
  

The Angelic Human Heritage and Rainbow Roundtables                            
Aramatena  on the planet, serving as a temporary D-12 Christos Grid  
within the Planetary Shields. Through the Temporary D-12 Christos Grid  
formed on Earth by the presence of the  Maji Races,  a quantity of D-12 fre-
quency could be re-introduced into Earth’s Planetary Shields during every 
natural SAC . Through this progressive re-introduction of D-12 frequency 
into Earth’s Planetary Shields, the portions of Earth’s Axiatonal Line and
Ley Line systems  that had been damaged in the 549,998,000 BC cata-
clysm of Tara  (see Page 2), could be progressively realigned  with the Shield 
of Aramatena Christos Blueprint. The physical bodies of the Maji Races  
served as literal conduits of electromagnetic energy,  through which the D-