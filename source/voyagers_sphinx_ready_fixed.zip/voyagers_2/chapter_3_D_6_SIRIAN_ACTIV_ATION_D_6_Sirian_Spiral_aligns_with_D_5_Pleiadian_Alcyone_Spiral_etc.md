3  D-6 SIRIAN ACTIV ATION : D-6 Sirian Spiral aligns with D-5 Pleiadian-Alcyone Spiral. etc
           DATE:  6/2008 - 1/2012 TARAN ACTIVATION
       EARTH VORTEX OPENS : V ortex # 6 - Caucasus Mountains, USSR - 6/2008 - 1/2012
       GOLD WAVE INFUSION : 2010 -2014  D-7 BT & D-8 OT frequencies enter Earth's Core
       DNA:  strand # 6 assembles, Gold Star & Indigo Star  crystals activate 5/5/2012-2017
       EARTH ACCRETION LEVEL  : 4 to 5  HUMAN ACCRETION LEVEL : 5 to 6
           (grids of Earth & Tara begin to merge and Ascensions to Tara begin 5/5/2012)                                _________________________________________________________