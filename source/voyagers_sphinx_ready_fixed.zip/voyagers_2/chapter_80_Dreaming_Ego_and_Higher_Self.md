80  
 

                                                                
                                                                                       
                                                                                         Dreaming, Ego, and Higher Self
    In the present day human, as the third DNA strand begins its reverse-
mutation through the lifting of the Frequency Fence, the perceptions and
cognition of the Higher Self become consciously available to the lower mind
of the Ego, and through this conscious connection the Ego rediscovers its
multidimensional aspects of awareness. When the third DNA strand is com-
pletely assembled, the Higher Self aspect of identity will merge with the Ego
and the mental awareness will comprehend itself as being a multidimensional
identity. The Higher Self serves as a bridge between the identity focused in
HU-1 reality and the soul imprint of that identity which is focused in HU -2.
The first step in integrating the Ego into its multidimensional identity is to
open the lines of conscious communication between Ego and Higher Self. In
contemporary terms this is often called “ channeling your Higher Self, " but the
reality of that process is assembling the third DNA strand through which the
two levels of mind can merge.  
     If the Ego makes a conscious effort to allow its Higher Self to speak, the
third DNA strand assembly process is accelerated, and information received
from the Higher Self will evolve from vaguely sensed intuitive impressions, to
direct inner verbal and visual communication, then eventually the Ego will
understand the Higher Self to be part of its own identity, a focus of conscious-
ness into which it can direct its awareness to receive a greater spectrum of
information. Once a person becomes the Higher Self, there is no longer an
egotistical focus, as the lower and higher minds have become integrated into
a “Superconscious Mind,” which can develop multidimensional perception
and abilities. Through the super conscious mind the D-2 sub-conscious mind
and D-l physical body consciousness can also be integrated into the con-
scious awareness. Working with, through, and becoming the Higher Self is
the next step in human evolution, and through this endeavor the healing and
assembly of the DNA can occur, under the direction of the super-conscious
self. The Higher Self and the Ego came into being within the human lineage in 9540
BC, manifesting as a result of the Frequency Fence that was created to stop the
Sphere of Amenti from destroying the Earth by entering the Earth's core prema-
turely.