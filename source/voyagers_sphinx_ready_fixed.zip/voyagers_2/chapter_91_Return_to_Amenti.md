91 
                                                                                                                                                                                                                        
                       

Return to Amenti  
Akhenaton in 1363 BC, and the child was later secretly taken to Giza by his
mother and several other Keepers of the Blue Flame. General Haremhab’s affil-
iation with the Keepers of the Blue Flame had not yet been discovered, and he
remained an operative within Akhenaton’s ranks, attempting to soften
Akhenaton’s wrath toward those whom he perceived as traitors. In 1362 BC,
shortly after the child was taken from Akhetaton to Giza, a final confrontation
took place between Akhenaton and the Keepers of the Blue Flame. The con-
frontation took place within the hidden passages beneath Giza, when
Akhenaton and his men followed Haremhab through the alternative portal
route and caught the Keepers of the Blue Flame in their ascension practices.
Using the Staff, Akhenaton attempted to close the Halls of Amenti. The
Flame Holder transmitted the D-5 frequencies held within her body into
Ankhi, who was to be the next Flame Holder. Ankhi transmitted the D-5 fre-
quencies of the ﬂame into the Sphere of Amenti to counter the transmissions
of the Staff, forcing the Halls to remain open. Akhenaton and Ankhi were
held within a duel of energy, with the Sphere of Amenti between them. Saba-
toth, Akhenaton’s unrecognized half brother, retrieved the Rod instrument
from Akhenaton’s guard and activated the second-dimensional frequencies of
the Rod in hope of knocking the Staff from Akhenaton’s grasp, fearing that the
power duel taking place would destroy the Sphere of Amenti. In a brief
moment the course of intended history was changed, as the second-dimen-
sional energy transmissions of the Rod interacted with the fifth-dimensional
energy transmissions of the Staff to create a double overtone frequency field.
When the double overtone was struck, the energetic barrier around the Sphere
of Amenti collapsed, opening the D-2 Earth morphogenetic field into the
Sphere of Amenti. This released the chaotic energies of the soul fragments
caught in D-1 and D-2 (known as the Underworld) into the morphogenetic
field of the Sphere of Amenti.  
    The Elohim immediately intervened, descending through the Arc of the
Covenant, resealing the Sphere of Amenti. Portions of the Amenti morpho-
genetic field had been contaminated by the chaotic forces of D-2, and the
Elohim had to separate the Sphere of Amenti, leaving the contaminated por-
tions within the D-2 Earth core morphogenetic field. The portions of the
Sphere that had not been compromised were placed back into the Arc of the
Covenant in the UHF bands of D-3, where the Sphere of Amenti was once
again sealed. Because of these events, the Halls of Amenti were once again
closed. The portions of Amenti that remained in Earth’s core stayed opened,
but the frequency bands of the Amenti Sphere that allowed passage into Tara
were sealed away in the UHF bands of D-3 within the Arc of the Covenant.
On the evening when this confrontation occurred, all members of the con-
flicting parties were energetically altered and returned to their home in
Akhetaton, having their memory of the night's proceedings erased.