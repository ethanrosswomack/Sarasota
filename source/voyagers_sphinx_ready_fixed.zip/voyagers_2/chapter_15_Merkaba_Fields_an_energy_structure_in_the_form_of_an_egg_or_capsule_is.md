15 Merkaba Fields, an energy structure in the form of an “egg” or capsule is
formed within the dimensional Uni fied Field of each of the 15 dimensions.
464                                      

                                                                                                                     
                                                                                                                 
                                                                                                              Stellar Activations
Through these dimensional energetic capsule structures, the chakra system,
or dimensional energy supply system, is formed. Through the chakra system a
form’s particle base builds up into structures of multidimensional matter. The
15 energetic capsules exist within the same space, separated by variance in
dimensional particle pulsation rhythms. The energetic form of the capsules
gives the auric field the appearance of capsules within capsules, or 15 distinct,
interpenetrating, capsule-shaped layers.  
      The process of dimensional ascension and biological and planetary evo-
lution is the process of accretion or the drawing of successive multidimen-
sional frequency bands into the morphogenetic field. As a planetary body or
human body evolves through frequency accretion, the energetic capsules
within the auric field progressively undergo transmutation of form. Once a
morphogenetic field has accreted most of the frequency bands from the three
dimensions that compose one Harmonic Universe, the energy capsules that
correspond to these three lower dimensions begin to dissolve. The particles
contained within the dissolving auric capsules open into the auric capsules of
the next three highest dimensions, in the next Harmonic universe up. This is
the energetic dynamic by which forms and consciousness progressively evolve
from one Harmonic Universe to the next.  
      The process of dissolving the lower-dimensional energy capsules and
transmuting their particle content into next Harmonic Universe is referred
to as a  Transmutative Activation  or Stellar Activation.  Stellar Activations
are a natural part of the accretion/evolution process, and occur as the pulsa-
tion rhythm of particles in the lower three dimensions speeds up into the
rhythms of the next three dimensional frequency bands. Through the process
of Stellar Activations the levels/capsules of the auric field progressively open
up into each other, dissolving the dimensional frequency barriers that kept
the levels separate within the morphogenetic field. The levels dissolve as the
morphogenetic field progressively draws in more frequency patterns from the
dimensional Uni fied Fields.  
       As the levels dissolve, progressively more energy and awareness merge
with and become held within, the matter-form, and the matter-form shifts
from one set of dimensional time continuum cycles to another. Earth and the
human populations are now approaching a series of Stellar Activations, as
part of Earth’s natural 26,556-year Euiago cycle. The auric field of the planet
and those of Earth’s populations will undergo transformation between 2000
AD-2017 AD. In order for humans to achieve ascension to the Bridge Zone
Earth and avoid becoming trapped in the D-3 time cycle, a minimum of one
and one half personal Stellar Activations must take place. Earth will experi-
ence six such activations between 2000-2017.  
       Humans who do not prepare the body, consciousness and chakra system
for these activations will be unable to shift into the Bridge Zone time contin-
uum or ascend to Tara and beyond. (This applies to disembodied, HU-1 soul
465 
                                     
                                                                                                                                                                                                                        
    

Ascension Cycle Dynamics  
essences, as well as to souls living within HU-1 bodies.) They will also expe-
rience varying degrees of disruption within their personal auric field, chakra
system, DNA and physical, mental and emotional bodies.  
  The Transmutative Activations are referred to as Stellar Activations
because the infusions of progressively higher-dimensional frequency bands
that transmit into the auric fields of Earth and humans, enter into the Earth’s
bio-energetic field through a chain of spiraling, dimensional Merkaba Fields.
The frequency infusions come to Earth following a path of Merkaba Fields
that runs through various star systems before entering Earth’s system through
the Pleiadian-Alcyone and Solar spirals.  
   The six Transmutative Activations, with which we are now concerned,
interface with Earth through the following spiraling, inter-stellar energetic
path: D-10 Lyra-Andromeda, D-9 Andromeda-Galactic Core Morphogenetic
Field, D-8 Meta-galactic Core and Orion, D-7 Arcturus, D-6 Sirius, D-5 Ple-
iades-Alcyone, D-4 Solar Spiral, D-3 Earth. As each of these spiraling Stellar
Merkaba Fields come into alignment with each other and with the three-
dimensional Merkaba Fields of Earth, the frequency patterns associated with
each spiral progressively enter into the Earth’s bio-energetic system and core.
This infusion of multidimensional frequency, which transmits to Earth in the
form of light, sound, electromagnetic and scalar waves that are beyond pres-
ently identi fied spectra and frequency bands, directly alters the particle pulsa-
tion rhythm of Earth’s three-dimensional particle base. This in turn directly
affects the bio-energetic fields of all life forms on the planet and thus the met-
abolic and biological processes of the body that are controlled through the
personal bio-energetic field.                                        
                                 STELLAR WAVE INFUSIONS  
                                                                    Transmutative Wave Infusion s      
       Blue Wave D-5/D-6, Violet Wave D-6/D-7, Gold Wave D-7/D-8, Silver Wave D-8/D-9,
        Blue-Black Liquid Light Wave D-9/D-10 and Silver-Black Liquid Light Wave D-10/D-11
   As the Stellar Activations progressively take place, infusions of UHF
energy begin running through the auric fields of Earth and humans, causing
particle pulsation rhythms to increase and accelerating the Stellar Activation
process. Six Stellar Activations will soon occur on Earth and humans work-
ing to build DNA will also have the opportunity to undergo six Stellar Acti-
vations. Stellar Wave Infusions are a natural part of the DNA evolution
process and will become part of the experiential reality of humans upon the
Bridge Zone or Ascension paths.  
   The first Stellar Activation begins following an infusion of energy into
the Earth’s core, through which the Earth’s core particle pulsation rhythm is
raised high enough to merge with the frequency bands of the first Stellar Spi-
ral, when it aligns with Earth’s Merkaba Fields during the ascension cycle.
466 

                                                                                                                    
                                                                                                             
                                                                                                            Stellar Wave Infusions
Normally the ascension cycle initiates because the human populations of
Earth have reached a high enough vibration of consciousness and DNA
assembly level to pull Stellar Frequency into their bio-energetic fields. 
   The bio-energetic fields of the human collective then serve to raise the
particle pulsation speed of Earth’s grid, which raises the pulsation rhythm of
Earth’s core high enough to link with the Stellar Spirals when they begin to
align with Earth’s Merkaba Fields. Thus humans assist the planet in its parti-
cle evolution. If the consciousness, DNA and bio-energetic fields of humans
are not at a high enough particle pulsation rhythm when the Stellar Spirals
align with Earth, the Earth’s core pulsation rhythm will be too low to link
with the frequencies of the Stellar Spirals. In this case Earth’s Stellar Activa-
tions would not take place, the planet would remain within its HU-1 time
cycle until the next Stellar Spiral alignment and the opportunity for acceler-
ated planetary evolution and dimensional ascension would pass by.  
   If the Guardians had not intervened and arti ficially infused Earth’s core
with D-4 frequency, Earth would not have been able to link with the Stellar
Spirals during this ascension cycle; the opportunity for Earth’s ascension to a
faster moving time continuum and escape from Dracos-Zeta Resistance in fil-
tration would not have been available. The human collective consciousness
alone did not reach a high enough vibration level, the DNA had not assem-
bled enough to create the initial Earth-grid acceleration that would prepare
Earth to receive the frequencies of the Stellar Spirals. The Guardians inter-
vened directly to avert the pending destruction of Earth and the Pleiadian
Star system that would otherwise have taken place in 2976 AD due to Dracos-
Zeta Resistance in filtration. Originally the Guardians planned only to assist
in stimulating the Earth’s core and aligning Earth’s Merkaba Fields to receive
the Stellar Spirals during the ascension period. The rest was to be left up to
humanity’s ability to evolve. Once the pending cataclysm of 2976 AD was
discovered, direct intervention in Earth’s affairs was permitted.  
    Because of the Guardians efforts, Earth is now prepared to receive its first
Stellar Activation on 5/5/2000. During the past seven 26,556-year Euiago
cycles, Earth has been unable to successfully link with the Stellar Spirals to
achieve Stellar Activations. Earth is now approaching the end of its eighth
Euiago cycle, which would naturally occur in 4230 AD, at the close of the
present ascension cycle. Earth and the human lineage have been trapped in
the HU-1 time cycles for 210,216 years to date. The coming period of Stellar
Activations has not been available to or witnessed by members of the present
lineage of the human race, which began with the Third Seeding of the Root
Races 75,000 years ago.  
   Because of the Guardians’  intervention and the necessity of the Bridge
Zone Project, this opportunity and the challenges it will present are available
to the current generation of humans. The events that will occur on and with
467 
                          
               

Ascension Cycle Dynamics  
the molecular and bio-energetic structure of Earth during the 2000-2017 AD
Stellar Activation cycle are unprecedented in recorded human history.  
   The first Stellar Activation begins as a result of Earth’s core pulsation
rhythm reaching a sufficient rate of speed to link with the first aligning Stel-
lar Spiral. Stellar Wave Infusions begin after the onset of the first Stellar
Activation. Halfway through the first Stellar Activation, the first Stellar
Wave Infusion begins. Through the Infusion, the frequency bands of the next
Stellar Activation are entered into the personal morphogenetic fields of
humans and the morphogenetic field of Earth’s core, while the first Activa-
tion is still underway.  
   When the first Stellar Activation is complete, all frequency bands associ-
ated with it have been released from the Earth’s morphogenetic field and are
transmitting through Earth’s grid. The next Stellar Activation begins as the
frequency bands entered into the Earth's morphogenetic field during the first
Stellar Wave Infusion cycle begin to transmit through Earth’s grid. This
sequence of Activation-Infusion-Activation continues through the six Stel-
lar Activations, and each Activation has a Stellar Wave Infusion halfway
through its activation cycle. The process operates within the human auric
field, DNA and body in the same way that it occurs within the Earth’s auric
field and particle body.  
   The first personal Stellar Activation occurs when the fourth DNA strand
begins to assemble (the fourth strand begins to assemble when the personal
morphogenetic field is at a 3-accretion level—all of the frequency bands of
D-1 through D-3 have been drawn into the morphogenetic field.) When half
of the fourth DNA strand is assembled (accretion level 3.5—all of dimen-
sional frequency bands one through three and one-half of the fourth-dimen-
sional frequency bands, are drawn into the morphogenetic field) the first
Stellar Wave Infusion begins within the human auric field and body.  
    By the end of the first Stellar Activation, the first level of the D-1 etheric
body auric capsule dissolves and its particles expand into the D-4 astral cap-
sule and increase their pulsation rhythm to that of the D-4 time cycle. As
each Stellar Activation and Wave Infusion continues, the HU-1 dimensional
auric capsules progressively dissolve and the particles pass into the HU-2
auric capsules, then the HU-2 particles expand into the HU-3 auric capsules
in like fashion. The auric level separations within the human auric field pro-
gressively collapse and the corresponding chakra centers activate and release
their seals. These bio-energetic changes cause higher-dimensional frequen-                                                                                        
cies to transmit through the DNA and body cells, which transmutes the cel-
lular structure, as the particles of the HU-1 body merge with their anti-
particles and increase their pulsation rhythm to that of HU-2.  
  The consciousness is transferred into the time cycles and three-dimen-
sional perceptual experience of HU-2 Tara, HU-3 Gaia or beyond, depending
468 

                                                                                                                   
                                                                                                             Stellar Wave Infusions
upon the level of Stellar Activation that is completed. These are the dynam-
ics of the science of ascension, which is one application of Keylontic Science. 
   The term Stellar W ave Infusion is derived from observation of the actual
energetic process that takes place as these higher-dimensional frequencies
enter the auric field. Once a DNA strand has reached one-half assembly, the
frequency bands from the dimensions above begin to ﬂow in spiraling, ener-
getic waves or sequential pulses of energy, through the lower-dimensional
Merkaba Fields of the body. When viewed with higher-sensory vision, the
energies carried on these energetic wave pulses appear as an infusion of col-
ored electricity or light spectra, bearing the hue associated with the dimen-
sional frequency band carried on the wave.  
   Stellar W ave Infusions not only affect the subtle body structures of the
human aura and chakra system, they directly interact with the physical body
construction, and can be felt as infusions of “jittery”, higher-vibrating electri-
cal current running through the body cells. As the Activations progress, the
Infusions become progressively more noticeable and intense, creating tem-
perature variations, changes in hormonal activity, alterations in sleeping and
eating patterns, fluctuations in bodily energy levels, change of the metabolic
rate, heart rate and breathing patterns, and various other bio-chemical and
neurological symptoms.  
    In bodies that are unprepared to receive the increase in particle pulsation
rhythms brought on by the Earth’s Stellar Activations, the Stellar Wave infu-
sions will create a mounting sense of mental, emotional and biological
fatigue. During Earth’s activations, the energetic systems of humans are
placed under a progressively increasing amount of electromagnetic stress at a
sub-atomic level. This stress will manifest itself in a variety of ways within
the human organism. Physical “sparking” of increased static electricity,
(which can occasionally affect the function of electrical and magnetic appa-
ratus) may develop in some individuals, until the auric body balances the
new frequencies within the body systems.  
   For most people the infusions will not produce such pronounced symp-
toms, but will rather manifest as progressively less subtle symptoms of degen-
eration, lessening of vitality and physical deterioration. The Stellar
Activations and Infusions progressively cause more noticeable physical symp-
toms, which begin subtly and progressively intensify. Through learning to use
the chakra system properly and developing the ability to consciously use
these new frequencies for positive evolution, the potential undesirable effects
of Earth’s Stellar Activations can be avoided.  
    The symptoms produced by Stellar W ave Infusions can be frightening if
one does not understand what is taking place and they can be life threatening
if the lower chakras have not been balanced and the physical body has not
been prepared for these alterations. Through  the Stellar Activations and
469 
                                                       

                     
                        Ascension Cycle Dynamics
Wave Infusions new areas of the brain are brought out of dormancy and the
glandular systems of the body, such as the Thymus, Thyroid, Pineal and Pitu-
itary glands, undergo metamorphosis. People who choose the path of ascen-
sion, or who do not want to end up trapped in the D-3 “Phantom Earth” time
cycle, will need to be aware of these changes. In future communications we
will provide more detailed technical information as to how the Stellar Acti-
vations and Stellar Wave Infusions can be handled with as little discomfort as
possible. At this time we would simply like you to become aware of the con-
cepts of which we speak, so you may begin to consider how you will approach
the coming changes.  
    People who have not chosen the path of conscious, accelerated ascen-
sion still need preparation to accommodate these changes. The Earth body
will undergo six Stellar Activations and Infusions between 5/5/2000 and
2017, whether or not your personal bio-energetic system has been prepared. If
you do not know how to balance your personal subtle energy bodies in the
face of Earth’s grid accelerations, you may find rapid deterioration of your
physical, mental and emotional systems. Your soul identity will attempt to
balance the energies and prepare your body to handle the new frequencies,
but you need to work consciously with your higher identity to employ
changes in habitual mental, emotional and physical activities that may be
detrimental to the process. The Guardian Alliance will offer a program for
Ascension Cycle Adaptation as soon as possible, for those who are interested
in gaining survival skills in this area. For now, you can simply learn about the
auric field and chakra systems through available resources, and begin working
to clear and balance your in-body chakras through energy work, visualization,
toning and other holistic health practices.  
                                     THE STELLAR BRIDGE                                                     
                  Stellar Spirals, Stellar Activations and Wave Infusions  
   During the two ascension cycle periods at the beginning and end of a
26,556-year Harmonic Universe Euiago cycle, certain alignments of multidi-
mensional Merkaba Fields take place. At these times, the spiraling electro-
magnetic currents of the multidimensional Merkaba Fields blend into each
other, forming a large 15-dimensional, spiraling pathway of energy transit
from the Meta-galactic Core at D-8 to all of the other dimensional systems.
These spirals of EM energy run through various galaxies and star systems
before entering into Earth’s solar system. There is a natural pathway of inter-
dimensional Merkaba Field alignment through which these energies interface                                                                                               
with Earth during the second ascension cycle period.    
   The form-holding morphogenetic imprint for the Milky Way Galaxy exists 
within the frequency bands of D-9, thus D-9 is considered to represent 
the Galactic Core. (D-8 holds the morphogenetic field for the entire 15-  
470                                                                                                                              

                                                                                                                         
                                                                                                                   The Stellar Bridge
dimensional Universe, and is thus considered the Meta-Galactic Core.) The
D-9 Galactic Core is located, in spatial terms, within the Andromeda Star
System. Part of Andromeda is located within D-10 frequency bands and is
connected to the D-10 Lyra Star system (Lyra extends from D-10 through D-
12) and part of Andromeda is located within D-9 frequency bands.  
    The Merkaba Field spirals of the Andromeda system are composed of D-9
and D-10 frequency bands and when this D-9/D-10 Merkaba Field interfaces
with the D-1/D-2/D-3 Merkaba Fields of Earth, D-9/D-10 frequencies trans-
mit into Earth’s core and run through Earth’s grid. The D-9/D-10 Merkaba
Fields cannot directly interface with the lower-dimensional Merkaba Fields of
Earth, these EM spirals must connect with a series of other stellar Merkaba
Field spirals in order for a “frequency bridge” to be established between the
higher and lower-dimensional Merkaba Field spirals.  
    This frequency bridge occurs only during certain time periods, when the
Merkaba Fields of these various star systems come into direct alignment with
each other, four times every 26,556 years; twice at the beginning and twice at
the end of the 26,556-year period. When this alignment of spiraling EM
Merkaba Fields occurs, Earth has the opportunity to raise the pulsation speed
of its particle base into that of higher-dimensional time cycles. At these times
interdimensional portals/passageways between Harmonic Universes, dimen-
sional bands and time cycles open and a planet or person can ascend into the
planetary systems of higher-dimensional time cycles or out-of-form manifes-
tation.  
  The pathway of multidimensional, inter-stellar Merkaba Field spiral
alignment runs from the higher-dimensional fields of D-10 Lyra-Andromeda,
through D-9 Andromeda-Galactic Core, D-8 Orion-Meta-galactic Core, D-7
Arcturus, D-6 Sirius, D-5 Pleiades-Alcyone and into the D-4 Solar Merkaba
Field spiral, then down into the D-3/D-2/D-1 Merkaba Fields of Earth. Each
of these inter-stellar dimensional Merkaba Field spirals is referred to as a Stel-
lar Spiral.  Each Stellar Spiral bears the name of the star system through
which it flows and carries within its energy field the light spectra and fre-
quency bands embodied within that star system.  
    Earth is now approaching the alignment of the Stellar Spiral Bridge that
runs from D-9 Andromeda down through the D-4 Solar Spiral to Earth.
Earth’s alignment with each spiral of the Stellar Spiral Bridge occurs in six
phases, beginning with the D-4 Solar Spiral upward through the D-9
Andromeda Spiral.  
    The point at which a Stellar Spiral aligns with the Merkaba Field spirals
of Earth begins a Transmutative Stellar Activation.  Between 5/5/2000 and
2017 Earth will experience six Stellar Activations, through which the six
Stellar Spirals of the multidimensional Earth-to-Andromeda Stellar Bridge
progressively align with Earth’s Merkaba Fields. During each Stellar Activa-
tion, the dimensional frequencies carried within the activating spiral begin to
471 
                                                                                                                                            
 

Ascension Cycle Dynamics  
transmit through Earth's core morphogenetic field and grid, raising the pulsa-
tion rhythms of Earth’s 3-dimensional particle base. It is through this process
that Earth’s grid is raised into the HU-2 time cycle to merge with the grid of
Tara. Before a Stellar Activation begins, the frequencies of the activating
Stellar Spiral are entered into Earth's core morphogenetic field through a
Stellar Wave Infusion.  In simple terms, a Stellar Wave Infusion begins when a Stellar Spiral
begins to align with Earth’s Merkaba Field spirals, and through the Stellar
Wave Infusion, the frequencies of that Stellar Spiral begin to enter Earth’s
core morphogenetic field. A Stellar Activation occurs as the Stellar Spiral
comes into full alignment with Earth's Merkaba Field spirals. At this time,
the frequencies from the Stellar Wave Infusion that have been building up
within Earth’s morphogenetic field begin to release from the morphogenetic
field and transmit through Earth’s 3-dimensional grid and particle base.  
   When half of the frequencies of a Stellar Spiral are released into Earth’ s
grid, halfway through the Activation, the remaining frequencies of the Stel-
lar Spiral completely “download” into Earth’s morphogenetic field. Once all
of the frequencies of a Stellar Spiral have fully entered Earth's morphogenetic
field, the next dimensional Stellar Spiral begins alignment with Earth and
the next Stellar Wave Infusion begins.  
   When half of the frequencies of the new Stellar Spiral have entered
Earth’s morphogenetic field, all of the frequencies from the previous Stellar
Spiral complete activating/transmitting through Earth’s grid, the previous
Stellar Activation ends and the next Activation begins. Halfway through the
next Activation, the previous Wave Infusion ends and the next Wave Infu-
sion begins. The process of Stellar Activations and Stellar Wave Infusions
represents a complex, multidimensional synchronization of Stellar Spiral
movement. It is not necessary to comprehend the complexities of this pro-
cess, but at this time it is important for you to know the basic mechanics of
Stellar Spiral alignment, as you will be faced with these conditions between
5/5/2000 and 2017.  
   Earth will experience six Stellar Activations and W ave Infusions, which
will alter the pulsation speed of Earth’s three-dimensional particle base, as
progressively higher frequencies are transmitted through Earth’s grid. If
Earth’s core had not been raised to a high enough particle pulsation rhythm,
via the Guardians D-4 frequency transmissions, the Solar Spiral would not
have been able to transmit its D-4 frequencies into Earth's core when the
Solar Spiral aligns with Earth’s Merkaba Fields on 5/5/2000. Earth would
have been unable to begin its Stellar Activations and Wave Infusion cycle,
and thus would have remained trapped within the D-3 time continuum,
unable to enter the Bridge Zone continuum.  
   The outcome of this would have been planetary destruction in 2976 AD,
due to Dracos-Zeta Resistance in filtration. We want you to understand the
472 

                                                                                                    
                                                                                                  Morphogenetic Crystal Seals
principle of raising core pulsation rhythm high enough to receive frequency
transmissions from the Stellar Spirals, for this principle applies directly to
your bodies and consciousness, as well as to planetary energy dynamics.  
   If the core energy centers within your bodies are not raised to sufficient
pulsation rhythm to receive the stellar frequencies which will be transmitting
through Earth’s grid during Earth's Stellar Activations, you will be unable to
accompany Earth in the Stellar Activation process. In this case, Earth will
make the shift into the Bridge Zone time continuum, but you will not; you
will find yourselves stationed upon the ''Phantom Earth'' Descending Planet.
On Phantom Earth you will be cut off from your soul matrix and evolutionary
blueprint and in need of a Host Soul Matrix Transplant in order to continue
evolution. Humans are connected to their HU-2 soul matrix via the Sphere
of Amenti race morphogenetic field, which will remain at the core of Bridge
Zone Earth. This condition can be avoided through conscious participation
in the Stellar Activation process.                         
                          MORPHOGENETIC CRYSTAL SEALS  
       Seed Crystals, Star Crystals and Transmutation of the Human Body  
   As Earth enters its cycle of Stellar Activations and Stellar Wave Infu-
sions, humans also have the opportunity to participate in Activations and
Infusions, which will accelerate the evolution of the DNA, body and con-
sciousness and allow humans to enter the time continua of the Bridge Zone
or Tara, for continued evolution. The process of Stellar Activations, as it
applies to people, operates energetically in a way similar to that of planetary
Activations. In planetary Activations, progressively higher-dimensional
sound frequencies and light spectra run through the Earth's grid and three-
dimensional particle base, as the Earth's Merkaba Fields link with and draw
energy from the Stellar Spirals.  
   In humans, the three Merkaba Fields of the physical, mental and emo-
tional levels of the bio-energetic field draw energy from the Stellar Spirals via
the Earth’s three-dimensional Merkaba Fields and grid, through the higher-
dimensional chakras. This energy then moves into the three-dimensional
body via the lower-dimensional chakras. Once stellar frequency is pulled into
the human bio-energetic field, it is passed into the multidimensional, per-
sonal morphogenetic field of the human via Stellar Wave Infusions, just as
stellar frequencies are added to the Earth’s core morphogenetic field through
Wave Infusions.   
  Planetary bodies and human bodies are multidimensional in structure.
The primary morphogenetic identity (form-holding pattern) for galaxies,
planets and people is held within the entry point to the 15-dimensional sys-
tem, the D-8 Meta-Galactic Core. From that point the morphogenetic design
spreads outward into each of the 15-dimensional particle fields. The slower
473 
                                                                                                                                                                                                                             
  

Ascension Cycle Dynamics  
moving particle fields of dimensions 1-7 hold the morphogenetic design of a
form as it will manifest within varying degrees of matter density. The faster
moving particle fields of dimensions 9-15 hold the morphogenetic design of a
form as it exists in terms of pure, electro-tonal conscious energy. Morphoge-
netic dimensions 9-15 are connected to dimensions 1-7 through the D-8
Meta-Galactic Core and energy continually circulates through this 15-
dimensional structure.  
   The collective Uni fied Field of the 15-dimensional Universal system is
referred to as the 15-Dimensional Matrix. Both planets and people are organ-
ically connected to each of the 15 dimensions within the 15-dimensional
Matrix. The 15-Dimensional Matrix is structured into five groups of three
dimensions called Harmonic Universes and portions of the personal and
planetary morphogenetic fields are contained within each of the five Har-
monic Universes. Earth represents the HU-1 portion of the planet, Tara rep-
resents the HU-2 version of Earth and Gaia represents the HU-3 version of
Earth. In terms of humans, the incarnates of Earth are the HU-1 expressions
of the personal morphogenetic field, the Soul Matrix or Dora (dimensions 4,
5 and 6) is the HU-2 version of the personal identity and the Over-Soul
Matrix or Teura  (dimensions 7, 8, and 9) is the HU-3 version of that iden-
tity. In like fashion, Tara can be viewed as Earth’s soul and Gaia as Earth’s
Over-soul. There are also versions of each planet and person that exist as
non-matter energy forms within HU-4 and HU-5.  
   Each planet and person is connected to each of the seven lower-dimen-
sional fields by a minute crystalline pattern of frequency that represents one-
dimensional level of the personal or planetary morphogenetic field. This
minute crystalline structure is called a Morphogenetic Seed Crystal; it serves
to keep the multidimensional aspects of the identity connected to each other
and to the primary morphogenetic imprint within the D-8 Meta-galactic
Core.  
  There are 15 Morphogenetic Seed Crystals within the morphogenetic
structure of a planet or person, one corresponding to each of the 15 dimen-
sions. The Seed Crystals serve as seals that keep the morphogenetic field sep-
arated and locked into each dimensional band; thus we refer to them as Seed
Crystal Seals. The Seed Crystal Seals control the speed at which fourth-
dimensional Merkaba Fields will rotate, and so direct the pulsation rhythm of
particles within each dimension. Along with the Seed Crystal Seals there are
15 more minute patterns of crystallized morphogenetic frequency that exist
within the bio-energetic structure of a person or planet. Whereas the Seed
Crystal Seals set the morphogenetic field into the center of each dimension,
the other 15 seals are placed between dimensional bands and serve to regu-
late the function of the Seed Crystal Seals. The 15 morphogenetic seals exist-
ing between dimensional bands in the bio-energetic structure of a planet or
person are called  Star Crystal Seals or Fire Crystals.  The Star Crystal Seals
474 

                                                                                                            
                                                                                                  
                                                                                                  Morphogenetic Crystal Seals
control the angle at which the Dimensional and Harmonic Merkaba Fields
will rotate, thus they direct the angular rotation of particle spin between the
dimensional bands of a forms particle construction. The Star Crystal Seals
control the operation of the Seed Crystal Seals in each dimension and can
release the Seed Crystal Seals, allowing the dimensionally separated portions
of the morphogenetic field to merge with each other.  
   The D-2 Orange-Gold Flame of Earth’ s morphogenetic field, the D-5 Blue
Flame of Tara’s morphogenetic field and the D-7 Violet Flame of Gaia’s mor-
phogenetic field, which we have previously discussed, represent three of the 15
planetary Morphogenetic Seed Crystal Seals which connect the planet to its
15-dimensional morphogenetic field. Earth-Tara-Gaia also has 15 Planetary
Star Crystal Seals, which exist within various locations throughout the 15-
dimensional universe, that keep the dimensional planetary particle fields sepa-
rate and regulate the angle of rotation of the planetary Dimensional Merkaba
Fields.  
    Planetary Star Crystal Seals regulate the evolution of planets and stars over
extensive periods of time, through directing the orbital patterns of planets, stars
and galaxies. The upcoming ascension period is possible precisely because of
the natural function of the Planetary and Galactic Star Crystal Seals. The
Planetary and Galactic Star Crystal Seals direct the angle of rotation of the
Universal Merkaba Fields, which allows the Dimensional Merkaba Fields of
Star Systems to come into direct alignment at certain times to form a Stellar
Spiral Bridge.  
   This process creates Stellar Spiral Alignments, such as the one Earth is
now approaching. During the Stellar Spiral Alignments the Morphogenetic
Seed Crystals of Earth, Tara and Gaia will temporarily release or open, allowing
the particle base of the planets to raise in pulsation rhythm for grid merger.
Through the Stellar Activations that will accompany the Stellar Spiral Align-
ments, higher-dimensional frequency from the Stellar Spirals will enter into
the Star Crystal Seals of the planets. The Planetary Star Crystal Seals will then
transmit this frequency into the Planetary Seed Crystal Seals that are located
within the centers of the primary vortex/portal systems of Earth, Tara and Gaia.
Through this energy infusion Earth’s particle base will be shifted into the
Bridge Zone time continuum. The Stellar Activation process works the same
way in relation to the human body.  
   The multidimensional bio-energetic field of the human, like that of a
planetary body, possesses 15 Seed Crystal Seals which control the pulsation
rhythms of the body’s multidimensional particle base. The human body is
connected to its HU-2 Soul Matrix, HU-3 Over-soul Matrix and Morphoge-
netic Identity of HU-4 and HU-5 through its 15 Seed Crystal Seals. The
human bio-energetic body also contains 15 Star Crystal Seals that control
475 
          

Ascension Cycle Dynamics   
the operation of the Seed Cr ystal Seals. The Seed Crystal Seals of the human
body are located at the center of the 15 primary chakra centers, nine of
which are located within the physical body structure.  
    Of the n ine embodied chakras, two are presently dormant; these will be
called into activation in humans participating in Stellar Activations. The six
remaining chakras exist within the bio-energetic field, some close to the
body, others extending outward into the galaxy. The six disembodied chakras
connect the human bio-energetic system and dimensional Merkaba Fields to
the Merkaba Fields of Earth and the Stellar Spirals. The disembodied higher
chakra centers will also be called into activation during Stellar Activations.
The human bio-energetic field also contains 15 Star Crystal Seals which con-
trol the function of the Seed Crystal Seals and the angle of rotation of the
personal Dimensional and Harmonic Merkaba Fields. Six of the Star Crystal
Seals are located outside of the body, nine are stationed within the body at
various levels of dimensional frequency.  
   The Star Crystal Seals of the human body are presently in a dormant
state, which keeps the Seed Crystal Seals of the chakra system closed, the
body’s particle base and consciousness separated and the personal Dimen-
sional Merkaba Fields locked into their respective dimensional frequency
bands. These conditions keep the human locked within the space-time coor-
dinates of Earth's present time cycle. For humans to shift out of the D-3 time
cycle and into the Bridge Zone with the majority of Earth’s particle base, the
human body must complete a minimum of 1.5 Stellar Activations. Through
the process of the first two Stellar Activations, two Star Crystal Seals will
activate and two Star Crystal Seals will release, allowing the particle pulsa-
tion rhythm of the three-dimensional human body to increase and the angu-
lar rotation of particle spin to shift into that of the HU-2 time cycles.  
     Each of the six Stellar Activations the Earth will encounter between
2000 and 2017 can also be achieved by humans upon the planet, because the
interdimensional Stellar Spirals come into alignment during this time period.
Each of the six Activations will activate various Star Crystals Seals within
the human body, if the human chakra system is used appropriately to draw in
frequency patterns and light spectra from the Stellar Spirals.  
     When the Star Crystal Seals activate, as a result of this infusion of fre-
quency, each progressively opens various Seed Crystal seals within the
chakras. Through this process, the HU-1 incarnate’s Merkaba Fields open
into and merge with the HU-2 soul matrix Merkaba Fields, allowing the
human body and consciousness to progressively transfer its particle content
out of HU-1 into HU-2, then from HU-2 into the Over-soul matrix of HU-3.
This is a complicated process of interdimensional energy dynamics. For our
discussion, it is enough for you to know that the Star Crystal Seals and Seed
Crystal Seals exist as part of your bio-energetic make up. These energy cen-
476 

                                                                                                                           
                                                                                                               The Silicate Matrix
ters will be used during Stellar Wave Infusions and Activations, in order to
transmute the particle content of the body and consciousness out of the D-3
time cycles and into the HU-2 time cycles of Bridge Zone Earth or Tara .
                                 THE SILICATE MAT RIX        
       The Crystal Seals, Seed Codes, Fire Codes and The Silicate Matrix  
  The process of assembling DNA strands by working with the higher
chakras is the process of bringing frequency from the Stellar Spirals into the
Star Crystal Seals. There is an intimate relationship between the Seed Crys-
tal Seals, Star Crystal Seals and human DNA. Each Seed Crystal corresponds
directly to and controls the basic function of one strand of DNA. The foun-
dations of human DNA are minute templates of crystallized frequency—elec-
tro-tonal sound patterns and electromagnetic light spectra that magnetically
group into crystalline form. These minute, multidimensional crystalline tem-
plates are referred to as DNA seed codes . 
    Of the 15 Seed Crystal Seals within the bio-energetic body of the human,