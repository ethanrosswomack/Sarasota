74 
 
 

                                                             
                                                                             Sinking Atlantis and Earth Quarantine
tex/chakra to collapse, which would systematically create a build up of energy
throughout the remaining vortices and the Earth grid would explode. If the
Sphere passed through the astral plane into the frequency bands of the third
dimension in 7558 BC, the Earth would be reduced to space dust.  
    In order to avert this pending Earth cataclysm the Ra Confederacy ,
Palaidorian and Sirian Councils, Elohim and several other Earth guardian
groups devised a plan through which the Earth could be spared this prema-
ture demise. This plan was put into effect in 9540 BC. The Elohim were com-
missioned to alter the Earth's D-2 morphogenetic field in a way that would
create a natural Frequency Fence, or energetic barrier, surrounding the Earth
through which the Sphere of Amenti would be unable to pass. Certain free
quency patterns were removed from the Earth's morphogenetic field, so the
fourth-dimensional frequencies could no longer “plug into” Earth's three-
dimensional body. The seventh through the twelfth base tones and seventh
through the ninth overtones of the third-dimensional frequency bands were
taken out of Earth's morphogenetic pattern. Without these frequencies, the
fourth-dimensional frequency bands could not connect to the Earth's 3-
dimensional body, so the Sphere of Amenti would be halted within the low-
est frequency bands of the fourth dimension, as the path of frequency through
which it would descend into the third dimension was severed. It would
remain in the astral plane until the 3-dimensional frequencies were re-
entered into the Earth's morphogenetic field. Without those frequencies the
Earth would not be able to pull those speci fic tones into its planetary grid, so
Earth would be halted in its tracks of time within the middle frequency bands
of the third dimension. Though this protective measure was necessary at the
time, it also stunted the planet's ability to evolve naturally out of HU-1. The
guardians intended to release the Frequency Fence during an appropriate
time cycle period, once the Earth grid had rebalanced and its vibrational rate
had increased enough to accept a rapid return of the Sphere of Amenti.  
    There were certain advantages and several drawbacks to this Frequency
Fence plan. The 10th-12th overtones of the third dimension were left within
the Earth's morphogenetic field, which meant that a portion of Earth's parti-
cles would manifest within the 10th-12th frequency bands of the third
dimension. A higher-vibrational “Earth phantom” was created, into which
the Sphere of Amenti could be released during an appropriate time cycle.
Once the Sphere was returned to the Earth Phantom energy imprint, the
higher 3-dimensional aspects of the race awareness would be released from
the D-4 Seal of Palaidor, and would be able to enter their race Cloister after
death, so part of the soul essence could return to Sphere of Amenti to await
the release of the fifth-dimensional Seal of Amenti. This meant that in the
dimensional blending period of 6835 BC the Sphere of Amenti could be
entered into the 10th-12th overtone frequency bands of D-3, and from that
point on soul fragments would no longer become trapped in the D-4 astral