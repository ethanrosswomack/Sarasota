73 
                                                                                   

                  A Journey Toward Awakening
from the Blue Flame in order to charge objects with UHF fifth-dimensional
energy. Two objects were charged prior to this sealing, so the Egyptian cul-
tures would have a tool through which the Inner Earth portals could be
opened. One object was a small, cylindrical object, ﬂat on one side and made
of gold, which housed a small portion of the Earth's D-2 morphogenetic field,
a small part of the Orange-gold Flame of Earth's core. This object became
known as the  Rod . The other object, also made of gold, was a staff about 3'
long, containing several crystalline stones, which housed a minute portion of
the Blue Flame morphogenetic field. This object was called the Staff.
Though these objects did not have the power of the Ankhs, they enabled
humans to enter the Inner Earth portals and could be used to facilitate heal-
ing, to in ﬂuence weather patterns and to access the portals of parallel Earth.
The objects were stored within a lead-lined chest that was energetically
charged with a frequency barrier so the energies of the Rod and Staff could
not escape while the objects were in storage. The Rod and Staff, and the
Ankhs were placed in the custody of the Annu-Melchizedeks from the Inner
Earth, and the Ankhs were banned from being used by surface cultures. For a
time, the Rod and Staff were used by the Egyptians who rebuilt the surface
cultures, but later they were also banned from surface use and de-activated.
Through time the chest in which the Rod and Staff were stored became
known as the Arc of the Covenant, and the true meaning of the Arc of the
Covenant and of the morphogenetic ﬂames of the D-2 Rod and the D-5 Staff
became lost to all but a select few who remembered the true significance of
these terms.  
    The most treacherous problem created by this Atlantean misadventure
was that the original seal on the Arc of the Covenant, which kept the Sphere
of Amenti in place within the Andromeda planetary core, was sparked open
by the EM-pulse transmission from the Great Crystal. The Sphere of Amenti
began its descent to Earth. The Sphere of Amenti could only be entered into
the Earth core if the Earth grid vibrated high enough to hold the frequencies
within it, and only during the dimensional blending periods inherent to the
Earth's natural time cycles. The descent of the Sphere from the Andromeda
Galaxy would take 2,000 years. Not only was the Earth grid unprepared to
house its energies, but the timing of entry would be completely out of syn-
chronization with Earth's natural cycles. Having been released into the Arc
of the Covenant portal bridge in 9558 BC, the Sphere of Amenti would
intercept Earth sometime in 7558 BC. It would not arrive in time for the
dimensional blend period of 9048 BC, and would arrive before the next
dimensional blend period in 6835 BC. If the Sphere of Amenti attempted to
enter Earth's three-dimensional body during a time period when Earth's
fourth-dimensional vortices were not opened, the Sphere would explode
upon impact with the natural frequency barrier that separates the third and
fourth dimensions. This astral explosion would cause the Earth's fourth vor-