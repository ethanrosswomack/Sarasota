23 
                                                                                            

         
              The Secrets of Amenti  
 dimensions two, three and four where they would have to merge with Aeiran
consciousness in order to ascend. A great burden was placed upon the Aeiran
Root Race and its Cloister Hibiru, for they became responsible for assimilat-
ing the fragments of consciousness from their race three and four ancestors,
before they could fully ascend. These ancestral soul fragments appeared as
fragments of incarnational memory and chaotic identities, sub-personality
fragments from the elemental, mental and astral planes, which would assem-
ble into the conscious awareness as the astral, mental and emotional bodies
merged through assembly of the fourth DNA strand. Along with this burden
the Aeirans and Hibiru also had to integrate the missing sixth overtone in
DNA strand one through which the Seal of Amenti could release and ascen-
sion take place.  
   Until the Seal of Amenti was released, the anti-particle codes that could
not merge with the physical body built up within the etheric body level of
the auric field—the anti-particle double within the parallel Earth. This elec-
trical build-up in the etheric body caused the physical body particles to
become overly dense and manifested as blockages (called miasms) within the
natural energy channels of the body, accelerating the manifestation of physi-
cal disease and the cellular deterioration process. The Aeiran and Hibiru
races, and their Aryan and Hibiru descendants would inherit this burden of
cellular clearing. Most humans of the present day have the fifth race coding,
and are subconsciously involved with this process of cellular clearing, inte-
gration of the emotional, mental and astral bodies, and assembling the fourth
DNA strand in order to release the Seal of Amenti and ascend. The Seal of
Palaidor would create a build-up of chaotic energies/identity fragments
within the elemental, mental and astral planes, until the Fifth Root Race ful-
filled its genetic imprint and assembled the fourth DNA strand through
which these soul fragments could be released. An alternative to fragmenta-
tion was offered to the races through the later inception of what came to be
called the Third Eye of Horus.  
  Though the burdens of evolution placed upon human consciousness
under the Seals of Amenti and Palaidor would be great, the Elohim and Ra
Confederacy knew this before orchestrating the Second Seeding, and they
allowed it to occur as a way of assisting to purify the digressive genetic codes.
The lower-vibrating genetic imprints would dissolve into the Uni fied Field of
           D-2, while the soul essences could re-evolve through the Fifth Races. They
             knew that one day, when Earth's grid vibrated high enough, the Sphere of