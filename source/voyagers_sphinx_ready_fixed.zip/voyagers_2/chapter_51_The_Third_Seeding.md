51 
                                                                                                                                    
                                                                                                                                                                                                                              

    
         The Third Seeding        
could once again be reseeded on Earth. Souls from the Sphere of Amenti
would pass through the Arc/bridge as pure consciousness, merge with the
Earth's morphogenetic field in D-2, then birth into physical manifestation. A
fifth-dimensional security seal was placed upon the Arc of the Covenant,
which meant that this portal operated as a “one-way door”; souls of the races
could descend through the passageway but could not return to the Amenti
morphogenetic field for ascension unless they had fifth-dimensional coding in
their gene structure. This genetic ticket to freedom became known as the
Shield of the Arc,  and the incarnates who bore this fifth-dimensional Shield
within their genetic code could pass through the Seal on the Arc of the Cov-
enant and return, through Amenti, to Tara. As races 3, 4 and 5 did not have
the fifth DNA strand within their genetic imprint, they could not return
through the Arc, even as consciousness, unless the Seals of Palaidor and
Amenti were released.  
    Release of the Seal of Amenti would allow these races to merge with
their anti-particles and pick up the fifth strand, but first the fourth-dimen-
sional Seal of Palaidor had to be released. Evolution would take time for races
3-5 of the Third Seeding. Those who could not reenter the Amenti morpho-
genetic field would evolve within the fourth-dimensional astral planes
between incarnations, along with those identity fragments created through
the Seal of Palaidor, until the time when the Arc of the Covenant was
opened and the fifth-dimensional Seal on the Arc released. The sixth race
Muvarians and their Melchizedek Cloister then held the key to ascension, as
the fifth DNA strand was included in their genetic imprint. The sixth races
would be born with the Shield of the Arc in their genetic code, and as the
Anunnaki-human hybrids Annu were to be seeded through the Melchizedek
Cloister —the Annu would also bear the Shield of the Arc. Those bearing the
Shield of the Arc would become the Earth guardians of the Arc of the Cove-
nant and the Sphere of Amenti.  
     The Arc of the Covenant was designed in such a way that the Sphere of Amenti
could eventually be re-entered into the Earth core through the portal bridge of the Arc.
In this way the Arc became self-regulating. The return of the Sphere of Amenti
would depend upon conditions in the Earth's planetary grid, and the Guardians
would not have to reenter the Sphere. The fifth-dimensional Seal on the Arc
of the Covenant was designed to be released once a certain percentage of the
Earth's population had assembled the fifth DNA strand, which meant that a
certain number of the Melchizedek Cloister would have to be born upon the
planet. If   8% of the living population could assemble the fifth DNA strand, the
Earth's grid vibration would rise, affecting the vibrational speed of the energy
particles within D-2 Earth core. As the D-2 particles began to vibrate faster a
blue-white spark of fifth-dimensional high-frequency energy would be sent up
from the Earth core, through the portal bridge of the Arc of the Covenant.
This spark would penetrate the fifth-dimensional Seal on the Arc and enter the