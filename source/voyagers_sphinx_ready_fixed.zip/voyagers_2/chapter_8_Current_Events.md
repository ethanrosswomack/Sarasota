8 
                   
                         
                                                                                                                                                           
                         Current Events  
                      
                                             THE BRIDGE ZONE PROJECT  
                           
                                        The Bridge Zone Time Continuum Shift  
                    12/1984 - present
         
    Before the Dracos-Zeta legions had altered the EM fields of the Sun in
1943 the Guardians’ preparation plans were relatively simple. Using their
artificial “Christ Consciousness” D-4 grid from 1748, they progressively sent
transmissions of UHF D-4 energy into Earth’s grid to raise the vibration of
Earth’s core high enough to send the first spark into the Arc of the Covenant
by October of 1986. The Sphere of Amenti would complete its 14-month
descent through the Arc from the UHF bands of D-3 by 1988. The Sphere of
Amenti would merge its D-1, D-2 and D-3 frequency patterns with, and
expand Earth's morphogenetic field no later than 6/1998, which would spark
the Arc a second time, beginning the 12-year descent of the Blue Flame and
Earth’s temporary 2000 AD shift into the D-4 time cycle. The Guardians
would continue to gradually realign Earth's Merkaba Fields/electromagnetic
fields to correct the tilt caused by Atlantis sinking. This would align Earth’s
fourth vortex/Heart Chakra at Giza with the Alcyone energy spiral by 2004,
in preparation for Earth’s entry into the Photon Belt and Holographic Beam,
and the opening of the Halls of Amenti in 2012.  
    The original Quarantine Frequency Fence from 9540 BC would begin to
lift once the Arc of the Covenant first opened, and all traces of the fourth-
strand DNA Zeta Seal mutation and Zeta Frequency Fence would dissolve
once the Arc was sparked a second time and D-4 frequency from the Sphere
of Amenti would begin transmitting through Earth’s grid . Between 1/1988 and
1/2017, the seven natural seals on Earth’ s seven primary vortex points would pro-
gressively  open  as   the    dimensional  Merkaba  Fields   and   Stellar  Spirals   began   opening
and blending into each other, while the Guardians assisted the Earth grid to remain
balanced through these transitions . The Guardians planned to offer dispensa-
tions of teachings to humans while the veils between the ego, higher self and
142 
              
            


                                                                              
                                                                               The Bridge Zone Project
soul identity began to lift, as the DNA progressively assembled. The Guard-
ians’ primary concern at this time was to realign Earth’s Merkaba Fields and
bring Giza into alignment with Alcyone. They would ensure that the descent
of the Sphere of Amenti and the Blue Flame stayed on schedule. Guardians
were to maintain planetary balance while Earth’s seven vortex seals opened,
and they would begin making subtle contact with humans, to help them pre-
pare for the opening of the Halls of Amenti.  
    Following the 1943 Philadelphia Experiment, the Zetas’  manipulation
of the solar Merkaba Fields and the necessity of the Guardians’ 11:11/12:12
Frequency Fence of 1972, the Guardians’ preparation plan and deadline
schedule became more taxing. Before the original plan could continue, the
11:11/12:12 Frequency Fence, which blocked all of the fourth-dimensional
frequencies except the 12th base tone and overtone out of Earth’s grid, had to
be dismantled. Though the Guardians could alter the Frequency Fence
enough to allow the Sphere of Amenti to enter Earth's core on schedule, the
fence could not remain intact when the Sphere of Amenti began transmit-
ting D-4 frequency into Earth’s grid in 1/2000, when the fourth vortex seal
opened. lt would take about four years for the Earth’s grid to balance once
the 11:11/12:12 Frequency Fence was released, so the fence had to be down
no later than 1/1996.  
     Once the Sphere of Amenti was opened, if the D-4 frequencies could not
enter Earth’s core in 1/2000, the D-4 Merkaba Field of Tara, the gold core
crystal stored at the center of the Sun, would explode. In this event, not only
would Earth explode, but so would the other 10 planets of the local solar sys-
tem and the Sun, all of which are energetically attached to the D-4 Merkaba
Field gold core crystal. This would begin a similar chain reaction within the
Pleiadian star system, to which Earth’s Sun belongs. As you may now under-
stand, balance and timing are extremely important factors when the Halls of
Amenti open. In order to remove the 11:11/12:12 Frequency Fence, the
Merkaba Fields of the Sun would have to be carefully realigned no later than
6/1994, which would allow one and one-half years for the Earth’s grids to
rebalance before the Frequency Fence was lifted. Realigning the solar fields is
a delicate process in and of itself, but this process combined with the general
preparations of opening the Halls of Amenti within the scheduled deadlines
served to make the Guardians’ task even more complex.  
     As if these complications were not enough, the Guardians then discov-
ered the potentially disastrous results of the Dracos-Zeta Resistance infiltra-
tion and their plan to re-institute their Frequency Fence and Zeta Seal in
2003. The events of the 2017 ascension cycle were taking a very serious turn,
and if the circumstances were not handled properly, the human populations
would be decimated by severe Earth changes between 2012-2017. The
option of stopping the Sphere of Amenti from descending through the Arc of
the Covenant, and thus allowing Earth and humanity to remain trapped
143 
                                                                                                                     
                                                                                                                 
                                                                                                              

  
   Current Events  
within HU-1 time cycles for another 26,556 years, was no longer open. The
Earth changes of 2012-2017 could be primarily avoided in this case, but
humanity would fall under dominion of the Dracos-Zeta Resistance and
under that in ﬂuence the Earth would meet with an untimely, cataclysmic end
in 2976 AD. These events could not be allowed to transpire, as they were set
to occur. The explosion of Earth would cause tragic consequences for Earth,
Tara and numerous other star systems. The lost souls of Tara, whom the
Guardians had so painstakingly nurtured and protected for the past 550 mil-
lion years, would once again be fragmented and left with no evolutionary
blue print to follow.  
    The Rigelian/Futczhi Zetas working with the Dracos would not listen
to reason and the Dracos would not release their claims on Earth. Confronta-
tional force between the Guardians and the Dracos-Zeta Resistance, during
Earth’s most vulnerable period, would destroy the planetary balances of
Earth, so t he Guardians had to turn to high-spiritual technology in order to shift the
course of events as they were evolving on Earth.  In 1984 Guardian groups from
HU-1, HU-2 and HU-3 joined together to create the Bridge Zone Project.
The basic idea behind the Bridge Zone project involved shifting Earth com-
pletely out of the HU-1 time cycle, an event that would not occur naturally
until the second morphogenetic wave of the second ascension cycle, during
the natural Doreadeshi in 4230 AD. Since the Guardians could not move the
Dracos-Zeta Resistance out of the way of Earth’ s intended evolution, they would
instead move Earth out of the way of the Dracos-Zeta Resistance. The Guardians
would construct an artiﬁcial time continuum between the third and fourth dimen-
sions, into which Earth could pass in 2017. This constituted orchestrating a forced
Doreadeshi, 2213 years ahead of its natural schedule.  
    In order for the Dracos-Zeta Resistance’ s Frequency Fence to work in
2003-2004 AD, they had to transmit very speci fic EM pulses, at very speci fic
angles through the Earth’s grid. The Zetas had worked since 1943 to deci-
pher the appropriate calculations to use for the projections of their EM
pulses. If the Merkaba Fields of Earth were rapidly accelerated, which would
constitute a planetary leap in time cycles from the HU-1/D-3 cycle to Bridge
Zone D-3.5 cycle of the lnner Earth, between D-3 and D-4, the Zetas-Dracos
calculations would be useless. The Earth’s grid speed would be increased to a
level that the Frequency Fence EM pulses could not reach. The Dracos-Zeta
Resistance would not have enough time to decipher new calculations, and
once Earth was stabilized in the Bridge Zone D-3.5 time continuum, and
under full Guardian protection, the Dracos-Zetas could not successfully
launch an infiltration. Furthermore, if Earth was successfully shifted, and its
frequency  raised suf ficiently, the Dracos-Zetas would lose control of  their  Fre-
quency Fence and their human captives  in the D-4 cycle. For humanity to shift
into the Bridge Zone with Earth, the populations would have to fully assemble
their DNA to the 4.5 -strand level, and a minimum of  8% would have to assemble
144 

                                                                                   
                                                                              
                                                                  The Bridge Zone Mechanics
the ﬁfth DNA strand. Along with this , 144,000 individuals would need to fully
assemble the sixth strand, embody their entire soul matrix and begin to assemble the
seventh-twelfth strands.  This acceleration of the human genetic imprint would
release the D-4 Zeta Seal from all of the human races, present and future, and
would allow Earth’s grid speed to raise high enough to remain in the Bridge
Zone.  
    Following the shift to the Bridge Zone, Earth would leap ahead 2213
years by skipping the second half of its D-3 cycle, then move backward in
time 1106.5 years within the Bridge Zone cycle. After completing 1106.5
years in the Bridge Zone, Earth would leap ahead another 1106.5 years by
skipping the first half of its first D-4 cycle. Earth would then pass into the first
D-4 cycle at the half-cycle point and continue its path of natural evolution
through the D-4 time cycles. This movement of 2213 years ahead, 1106.5
back, and 1106.5 ahead in time represents a cumulative leap of 2213 years in
evolutionary space-time progression. The Dracos-Zeta Frequency Fence
would end up in the dimensional frequency bands below the Bridge Zone fre-
quency bands in which the Earth was positioned, and thus Earth’s grid would
be unaffected. However, once Earth was above the frequency fence, it could
not be re-entered into the dimensional bands below the fence. The Merkaba
Fields of Earth would re-seal in 2017, locking Earth into the Bridge Zone
time continuum. If the Guardians were going to force an early Doreadeshi, by
moving both the overtone/electrical fields and the base tone/magnetic fields
of Earth into the Bridge Zone time continuum cycle during the 2017 half-
cycle point, the move would have to be permanent.  
 
                                    BRIDGE ZONE MECHANICS  
    The idea of shifting a planetary body from one time continuum to
another may seem quite outrageous to a civilization that does not yet have a
working comprehension of multidimensional physics. We assure you that
such a procedure is most definitely real and valid in terms of the structural
energetic dynamics of the Time Matrix. This procedure is not used fre-
quently, for it is a complex and delicate process requiring direct intervention
from the higher Harmonic Universes of HU-3 -HU-5. For the most part,
planets and civilizations are allowed to evolve along the course of their own
development, following their own choices and meeting with the conse-
quences of those choices. But occasionally a planet and its peoples get into
trouble that has far-reaching consequences for numerous planetary systems,
and in these cases intervention in the course of evolution is permitted. Earth
is presently in such a state of potential crisis, unbeknownst to most of its pop-
ulations.  
145 
                                                                                                                     
           
                                                                                                                   

 
            Current Events  
                           TIME-CYCLE MECHANICS AND EVOLUTION  
                                       
                                                    Time-Cycle Mechanics  
    In order to understand the dynamics involved in such a time continuum
shift, it is helpful to realize that the structure and illusion of linear time is cre-
ated through the pulsation rate of particles and their relationship to that of
other particles. Each of the six 4,426 year smaller cycles within one 26,556
year Harmonic Time Cycle represents one time continuum. A 26,556-year
Harmonic Time cycle, through which a planet evolves through the 3-dimen-
sional bands of one Harmonic Universe, is called an Euiago.  A planet passes
through each of the six smaller time continua as it progresses upward through
the 3-dimensional scale within its Harmonic Universe. Each dimensional
band contains two time continua of 4,426 years each, so each dimension rep-
resents a time track of 8,852 years.  
    Of the six time continua in a 26,556-year Euiago cycle, four time con-
tinua represent forward-moving tracks of time called Pardo,  and two repre-
sent counter-rotating tracks of time called Reiago,  in which the planet passes
through the parallel universe.  A Pardo = 17,704 years  (4 continua of 4,426
years each = 4 x 4,426 years = 17,704 years). A Reiago = 8,852 years  (2 con-
tinua of 4,426 years each = 2 x 4,426 = 8,852 years) spent in the parallel uni-
verse.  Each Euiago contains one Pardo and one Reiago.  
    A  planet’ s progression through one time continuum creates a 45° shift in
the angular rotation of particle spin, or 1/8th of a full 360° rotation of parti-
cles, thus one continuum represents one dimensional Octave.  One Octave =
a 4,426-year track of time.  One dimension contains two time continua, or two
Octaves. A planet’s progression through one dimension creates a 90° shift (2
shifts of 45°) in the angular rotation of particle spin, or one-fourth of a full
360° rotation, thus one dimension represents one Harmonic Quadrant.  One
Quadrant = an 8,852-year track of time.  Three dimensions, three Quadrants,
or six Octaves (time continua) represent one Harmonic Universe.  One Har-
monic Universe = a 26,556-year track of time.  
    As a planet progresses through the first two Pardo Octaves, the angular
rotation of particle spin shifts 90° from its original position. Upon entering
the two Reiago Octaves in the parallel universe, the angular rotation of parti-
cle spin undergoes a 90° reverse rotation, bringing the angular rotation of
particle spin back to its original position. As the planet completes the final
two Pardo Octaves, returning from the parallel universe, the angular rotation
of particle spin again shifts 90°. Through the progression of three dimen-
sions, or Quadrants, the angular rotation of particle spin has a cumulative
shift of 90° (+90°, -90°, +90° = +90° shift), so in one Harmonic Universe the
angular rotation of particle spin undergoes one-quarter of a full 360° rotation.
    When passing from one Euiago cycle (Harmonic Universe) to the next,
the angular rotation of particle spin shifts 45°. Between HU-1 and HU-2, the
146 

                                                          
                                                                 Time-Cycle Mechanics and Evolution
45° shift is a 45° reverse angular rotation of particle spin. Earth enters HU-2
with its particles at a 45° angular rotation from their original position upon
entering HU-1 (+90°, -45° = +45° shift). In the progression from one Har-
monic Universe to the next, the angular rotation of particle spin moves for-
ward 1/4th, then backward 1/8th of a full 360° rotation.  
     It  is through the multidimensional relationships between angles of particle and
anti-particle spin that multiple reality ﬁelds can take place in the same space, while
remaining invisible to each other. As a planet evolves through this process, the rate
of particle pulsation, and thus the speed at which time moves, progressively
increases, while the density of matter particles progressively decreases. This is the
process of planetary evolution through the 15-dimensional scale.  
     A  planet moves from one dimensional frequency band to the next, and
from one time continuum to the next, by magnetically drawing into its mor-
phogenetic field, particles from the Uni fied Field of energy for each dimen-
sion. When a planet has pulled in all the frequency patterns of one
dimension into its morphogenetic field, it then moves upward into the next
dimensional field to complete the same process.  
     As a planet pulls in particles and patterns of frequency from the Uni fied
Fields, its morphogenetic field progressively expands to include those fre-
quency patterns and the pulsation rate of its particles progressively increases.
For each dimensional band there is a corresponding speci fic rate of particle
pulsation and also a speci fic angular rotation of particle spin. In one Har-
monic Universe a planet simultaneously has three levels of energetic identity,
one in each of the three-dimensional fields of that Harmonic Universe. The
three levels of a planet’s identity function together to give you the illusion of
Earth’s matter solidity. The particle content of each level of Earth’s body pul-
sates at a rhythm characteristic to the dimension in which each portion of
the body is stationed, and particles spin on an angular rotation that is charac-
teristic to the respective dimension. The planet exists within each of six
time continua simultaneously, as each of the three levels of the planet’s body
pulls in energy from its respective dimensional band, through the synchroni-
zation of particle pulsation speed and angular rotation of spin within each of
the six time continua. A planet evolves out of one Harmonic Universe and
into the next as each level of its three-dimensional body simultaneously com-
pletes pulling the frequency patterns of its respective dimension into the
planet’s morphogenetic field. These processes give the consciousness perceiv-
ing the third dimension the illusion of passage through linear time. In actual-
ity, time is not linear, but simultaneous.  
    Time exists as a Uniﬁed Field of particles pulsating at various rhythms and
spinning on various angles of rotation, through which the illusions of manifest space
and linear time appear to individuated identities, as they bring segments of the Uni-
ﬁed Field of particle substance into view by moving their consciousness through por-
147 
                                                                                                                                
                                                                                                               
                                                                                               

Current Events  
tions of the Uniﬁed Field. Time does not move. Consciousness moves itself through
the Uniﬁed Field of the Time Matrix.                             
                            Incarnational Identities, the Time Cycles,  
                                    DNA and Planetary Evolution  
    The evolution of life-forms upon the planet also takes place simulta-
neously, and, at any given time, activity takes place within each of the six
time continua. As the planet evolves, so does the consciousness stationed upon
that planet. Reincarnational identities represent portions of a person’ s soul aware-
ness that are simultaneously stationed and evolving upon a version of the planet
within each of the six time continuum cycles of an Euiago cycle . Usually, a soul -
HU-2 identity, manifests into 12 simultaneous incarnations, two in each of
the six time cycles in one Harmonic Universe. In each pair of incarnates,
one is male, the other female; this relationship is referred to as “twin ﬂames”,
but does not necessarily imply a romantic “soul mate” involvement.  
    The over soul—the HU-3 identity —creates 12 soul identities in HU-2,
each of which create 12 incarnates within the six time cycles of HU-1. Thus,
each person is part of an incarnational family of 144 incarnates residing
within the six HU-l time cycles. Each of the 144 incarnates carries part of
the 12-strand DNA pattern within the genetic code. As the 144 incarnates
simultaneously evolve with the planet through the six time cycles, the 12-
strand DNA imprint is progressively built up in the genetic code. DNA
evolves and human consciousness expands as identity evolves with the planet
through the Euiago cycles in each Harmonic Universe. The perceptions of
your present races are focused within the middle range of the third dimension
(the sixth and last time continuum of HU-1), and you perceive the reality of
these dimensional bands, from a station of consciousness one dimensional
band above. When you perceive the activity that is simultaneously taking
place in the lower-dimensional time continua, in the lower levels of Earth's
body, that activity appears to you as having taken place in the past. Percep-
tion of the other members of your soul family identity, who are stationed in
time continua below your own, will appear to you as past life incarnational
memory, even though these lifetimes are occurring simultaneously within
their own space-time coordinate. Identities stationed in time continua/
Octaves and dimensions/Quadrants ahead of your own, (which in your case
would be those in the HU-2 time cycles of Tara), will appear as future life
incarnational memory.  
     As you assemble DNA  strands, perception of both past and future incar-
nations becomes progressively more available to your present conscious
awareness. Earth evolves through the HU-1 time cycles, expanding its mor-
phogenetic field and raising the pulsation rhythm of its particle content, until
Earth evolves into the HU-2 time cycles to become Tara. As you move
through HU-l time cycles with Earth, assembling your DNA and expanding
148 
 

                                                        Time-Cycle Mechanics and Evolution
your consciousness, you evolve into the HU-2 time cycles to become your
soul-self identity.  
    T o the soul-self, the 12 immediate HU-1 incarnates that are in its incar-
national family are recognized as living sub-personality fragments of its own
identity, whose reality simultaneously takes place within the dimensional
bands contained within the soul-self’s DNA. The DNA represents electro-
magnetically encoded, digital data imprints of the other living portions of
your identity, which are stationed within other time continua. Through the
DNA, the experiential reality of other-time incarnates is implanted into the
body cells, to create a living Cellular Memory  of your simultaneous partici-
pation within other fields of time. The DNA operates as a window in time
through which your consciousness can perceive and participate in activity
taking place in the other time continua. As you assemble DNA, you expand
the particles of your body and awareness into higher-dimensional time cycles,
and progressively open the windows through time into other space-time coor-
dinates within other time cycles. Through DNA assembly, the Cellular Mem-
ory, which is subconsciously stored within the cellular-body consciousness,
progressively opens into conscious perceptual recognition.     
    In your current time continuum, you technically have one-half cycle
remaining within your third-dimensional time cycle. Earth’s morphogenetic
field has pulled in only half of the frequency patterns of the third dimension.
There is a direct correlation between how many frequency patterns the Earth has
pulled into its morphogenetic ﬁeld and the type of consciousness and biology that will
appear on the Earth at that stage of evolution.  W e call the amount of frequency
Earth has pulled into its morphogenetic field, from the dimensional uni fied
fields, its Accretion Level.  
     Earth is presently at the 2.5-accretion level —Earth has pulled into its mor-
phogenetic field all of the D-1 and D-2 frequency patterns, and half of the fre-
quency patterns of D-3. Earth would normally pass into HU-2 time cycles at
accretion level 3. Normally the three accretion level of Earth would not be
reached until 4230 AD. The life-forms on a planet at the 2.5-accretion level
will have a consciousness that falls near the 3.5 range. Consciousness will per-
ceive as solid matter and external reality the level of Earth’s body that is one
full dimension/Quadrant below the accretion level of the consciousness.
    Present human consciousness has an average accretion level of 3 —3.5,
which means that the energy patterns and activity taking place within the
low to middle frequency bands of D-3, between the 2 to 2.5-accretion level,
within the fifth time continuum, appear as solid matter, and external forms
and events. Present external earthly reality represents the energy patterns of
Earth’s body and the Uni fied Field in the low to middle frequency bands of D-
3, in the fifth time continuum, at accretion levels 2 —2.5. In order to perceive
the 2 —2.5-accretion level of Earth as solid, consciousness must be stationed
149 
                                                                                                                       
                                                                                                                 
                                                                                                              

                   Current Events
within the low to middle D-4 frequency bands at an accretion level of 3- 3.5
(seventh time continuum).  
     When perceiving your own physical body , and the external objects and
activity around it, you are seeing the particle content of your personal mor-
phogenetic field, Earth’s morphogenetic field and the Uni fied Field, as they
exist within the low to middle frequency bands of D-3, in the pulsation
rhythms of the fifth time continuum, at the 2-2.5-accretion level. You per-
ceive these frequency bands as solid while the particle content of your con-
sciousness is stationed within the low to middle frequency bands of D-4, in
the pulsation rhythms of the seventh time cycle, at a 3-3.5-accretion level.
You will perceive the frequency bands of middle to upper D-3, in the pulsa-
tion rhythms of the sixth time cycle, at the 2.5 —3 accretion level, as “inner
space”, the activity taking place “inside your head and body”, and the atmo-
sphere surrounding your body and the Earth, that gives you the perception of
space between objects.  
     The illusion of 3-dimensional perception is created through this triad of
particle pulsation speeds.  The pulsation speed/rhythm of particles is created
as energy substance ﬂows between fields of particles having different angular
rotations of particle spin in relation to each other. The 3-dimensional human
consciousness and the 3-dimensional body of the Earth consciousness are
made of particles that pulsate at three different rhythms, and which exist at
three different positions of angular rotation. These particle fields make up
three levels of Merkaba Fields within and through which physically apparent
manifestation occurs. There is a 90° shift in angular rotation of particle spin
between the three Merkaba Fields, between the three levels of human con-
sciousness, and between the three levels of Earth’s particle body. The three
levels of the personal body and the Earth’s body represent three different time
continua, or Octaves, through which frequency bands from the dimensional
Unified Fields are pulled/accreted into the personal morphogenetic field and
that of the Earth. These three particle pulsation rhythms are synchronized,
and through this dance of particle spin and pulsation, personal consciousness
evolves with the Earth upward through the time cycles of the 15-dimensional
scale, progressively expanding and raising the level of accretion.  
     The level of frequencies accreted into the personal morphogenetic ﬁeld will
determine the level of DNA strand assembly you possess. As you pull in more fre-
quency bands from the dimensional Uniﬁed Fields, your accretion level rises, more
DNA codes assemble and become operational within your DNA strands, and your
consciousness and perceptual ﬁeld expands.  
     A consciousness with a 3 —3.5-accretion level has a DNA code with 3-3.5
strands assembled. The strand assembly and activation level of the DNA cor-
responds directly to the number of dimensional frequencies contained within
the morphogenetic field of the consciousness. The number of dimensional fre-
quencies contained within the personal morphogenetic field corresponds
150 

                                                             
                                                                                  
                                                                                  Time-Cycle Mechanics and Evolution
directly to what dimensional levels of the Earth’s body, and what time con-
tinua, will be perceived as physically manifest reality, to that consciousness. If
your fourth DNA strand is fully assembled, you will have an accretion level of
4, your consciousness will be stationed in lower D-5 and you will perceive
thought-forms and energy patterns existing within the lower D-4 frequency
bands as physically manifest, external events. These thought-forms are the
energy patterns left behind by you and the masses, when your consciousness
was stationed in lower D-4, when you were assembling the fourth DNA strand.
    Presently , most humans do not have more than a 3.5-accretion level, a
low to middle fourth-dimensional focus of consciousness. This level of con-
sciousness corresponds to 3.5 strands of activated DNA, which only allows
the consciousness to perceive thought patterns/energy patterns of objects and
events from the low to middle frequency bands of D-3 as physical reality. The
frequency fields of D-1 are below the range of D-4 perception and appear as
inner darkness. The lower frequency fields of D-2 appear as past memories.
The middle to upper frequency fields of D-3 appear as internal mental/per-
ceptual events and thought-forms, and as Earth’s atmosphere and the space
between objects, from D-4 perception. The reality fields of middle to upper
D-4 and above are above the range of present human D-4 perception and
appear as inner and outer light and future memories. As human DNA builds,
the higher-dimensional reality fields come into manifest view, and the lower-
dimensional reality fields fall out of perceptual range.  
    As a dimensional field begins to come into view , it first appears as inner
thought patterns that become inner mental pictures made of light. The qual-
ity known as imagination is, in reality, the consciousness bringing into its
mental view, higher dimensional thought-forms. The images, perceptions
and pondering of imagination represent higher-dimensional thought-forms
made of energy substance, that are placed in the higher-dimensional fields by
the present moment self. Imaginative perceptions may also be thought pat-
terns of the higher-dimensional, future self aspects of identity, that “just
appear” in inner perception, as the present awareness brings the higher-
dimensional reality fields into its inner view. The quality known as past
memory represents the consciousness bringing into its mental view thought-
forms and experiential imprints from the dimensional bands below its focus of
attention. These represent thought-forms of past identity aspects, presently
focused in the lower time continua or within lower frequencies of the present
time continuum. Dreams represent portions of thoughts and experience that
is taking place in both higher/future and lower/past dimensional fields/time
continua, entering into the present moment station of awareness.  
    The low to middle D-4 frequency bands, in which human consciousness
is presently stationed, represent the now-moment stream of consciousness,
which is always the point of personal creative power. Thoughts held in the
present moment focus of conscious attention will be left as imprints of ener-
151 
                                                                                                                
                                                                                                                   

   Current Events  
getic substance within the frequency bands in which those thoughts were
held. Once the focus of attention has moved beyond those thoughts and on
to the next, the thought imprints left behind become morphogenetic fields,
as the now-moment focus of attention moves forward into the next set of fre-
quency bands.  
    The process of moving forward through time is the process of progressively
accreting sound frequencies into your personal morphogenetic field. As you
pass your consciousness through a now-moment point, it internalizes all con-
tained within that manifest moment as a minute, digital electro-program made
of frequency. The process of internalizing that moment in time expands your
morphogenetic field, which creates a subtle acceleration in the pulsation
rhythm of the particles of which your body and consciousness are composed.
This acceleration of pulsation rhythm perceptually and energetically moves
you-as-consciousness forward into the next set of frequency bands. The fre-
quency bands of the previous moment internalize and fall from your view, as
the set of frequency bands directly above them become your next now-moment
of conscious focus. Movement through time is frequency accretion.  The manifest
illusion you perceive before your eyes is, in reality, a Unified Field of frequency,
composed of energy particle substance in the form of digital, electro-tonal
thought patterns. Every thing and person outside of yourself, including your
body, and the contents of your conscious mind at that moment point, exist as
energy imprints within the Uni fied Field of that now-moment. If you can teach
yourself to perceive each moment of your external reality as a dream-scape that is
manifesting through your consciousness, you will get closer to consciously sensing the
stream of consciousness through which your external reality manifests directly through
you. Just as your internal dreams seem to take place within your consciousness
while you participate within them, your external reality is also a dream-scape,
manufactured by your consciousness, through which energy particles are
shaped into thought-forms that will later become manifest. You are walking
within the con fines of a mass dream, and the sooner you can grasp that con-
cept, the sooner you will be able to assert creative control over the form your
personal part of that mass dream will take.  
    Every time you think a thought, you are leaving a morphogenetic
imprint within the frequency bands in which your consciousness was sta-
tioned. You will run into that thought pattern, in combination with others
from the collective consciousness, as a manifestation in physical reality. Mor-
phogenetic fields are the form-holding patterns through which matter forms
and events manifest. When a morphogenetic field is created, it begins to draw
frequency patterns into itself, expanding, accreting, and “fleshing itself out
into matter”. Have you ever considered where thoughts go once your atten-
tion has left them? Part of what appears to you as manifest reality now, from
your D-4 station of attention, represents your thought-forms, and those of the
collective masses, that were left behind as morphogenetic fields when your
152 
                             
                                           

                                                            
                                        Time-Cycle Mechanics and Evolution
conscious focus of attention was stationed in the dimension below your
present focus. Part of what you see before your eyes represents the living
thought-forms of your past selves (from this incarnation and those previous),
and those of the masses. Your thoughts become morphogenetic fields within
the morphogenetic field of the Earth, planted within the frequency bands in
which your consciousness is presently stationed, left within your present time
cycle, to be rediscovered as manifest objects and events, once your conscious-
ness has evolved beyond them.  
     Another part of what you perceive before your eyes represents the collec-
tive thought-forms of your future selves, whose focus of attention is stationed
in space-time coordinates ahead of those in which your present consciousness
is focused. Thought-forms expand, backward and forward in time, up and
down the dimensional scale, from the position in which the thought-form
was created. Your present manifest illusion is composed of the thought-forms
of your past and future selves, and the thought-forms you presently hold. A
thought-form placed in one dimension will align the energy substance of all
the dimensions below it, into a version of that pattern; the thought sets a
morphogenetic field in each of the dimensions below. The thought will also
group with like thoughts from the future, the higher-dimensional frequency
bands, and set a morphogenetic imprint of itself in all the dimensions above.
Thus the thought expands backward and forward in time.  
    Every thought you think now combines with like thoughts of past and
future selves, to give you the manifest illusion you presently perceive. Like
thought and action attract and re-manifest like thought and action. Your past
thoughts and deeds will show themselves in your present reality, but you have
the absolute power to change them, by using your present focus of attention
to create new thoughts and redesign those that are undesirable, whether they
are coming from the past, present or future. Thought patterns from your past
selves, which are composed of more dense and slower-pulsating particles,
manifest within the cellular structure of your body. This is frequently referred
to as your karmic imprint or karmic debt.  These thought patterns of past
selves will remain in the body, and replicate themselves in the present and
future, until the slower-pulsating particles of those thought patterns are raised
in speed and released from the frequency patterns of which the body is com-
posed. You have the power, in your present moment, to change any thought
pattern from your personal past, present or future, and in doing so you will
change the contours of your present reality.  
    Y ou can become “ karma immune”  once you learn to master this power,
for you will train your consciousness to move backward and forward in time,
to recreate undesired events and redesign more desirable outcomes. The slow
way to release slower-pulsating thought patterns and their manifest discom-
forts from your life is to wait until the events manifest in external reality, or as
conditions of disease within the body. Then you take action in the present to     
153                                                                                                                
                                                                                                                                                                                                                                                                              
                                                                

  Current Events  
 create a present solution, and that solution expands backward and forward in 
time to create some degree of resolution of the pattern in the past and future.
This is the usual path of “walking through your karma,” or walking through
the cumulative thought patterns of your past, present and future selves. The
fast way to change your karmic imprint is to catch those slower-pulsating
thought patterns before they move into manifestation. This is easier said
than done, but it is not exceedingly difficult to do, once you have trained
your consciousness to manipulate energy in certain ways. Thought patterns
from the past and future become part of the particle make-up of your con-
sciousness, bio-energetic field, body, DNA and external reality field. They
become stored in the DNA as minute crystallizations of energy, which inhibit
the natural process of DNA strand assembly.               _____________________________________________________________
       The crystallized thought patterns stored in your DNA and cellular imprint will
continue to manifest within your body and before your eyes, until you learn to ﬁnd
and release them while they are still within the Cellular Memory imprint of your
body. This is easy to do, with practice.            ____________________________________________________________
   To release your crystallized thought patterns from your DNA and cellu-
lar memory imprint, please refer to Field Exercise 1, on page 495, and prac-
tice it now. Through exercises of this nature you are learning to consciously
modulate the pulsation rhythm of the particles of which your consciousness is
composed, training your present moment consciousness to move up and
down the multidimensional scale.  
    Y ou are training your consciousness to time travel, forward and backward
in time, so you may begin to directly affect the collective thought patterns of
portions of your identity stationed in other space-time coordinates. You are
beginning to train yourself to control the manifestation of external events, by
mastering the inner energetic dynamics through which those events manifest.
    W e have given you this exercise because it is one of the fastest and most
effective ways to clear the “karmic imprint” of slower-pulsating crystallized
thought patterns from the body cells and DNA. This is extremely important
to do if you plan to accelerate the assembly and activation of your DNA
strands. As you begin to work with UHF energies from the higher chakra
centers (which we will teach you to do in subsequent books), these energies
will begin to rapidly release slower-pulsating thought-form crystallizations
from the body cells and DNA. As this occurs the “karmic imprint”, or event
manifestation program, contained within the thought-form crystallizations
will begin to manifest itself in personal, external events and within the phys-
ical body form. If the human mind and body is not prepared to synthesize the
frequencies of energy released from the thought-form, one can become
extremely ill in physical terms, or the mental and emotional bodies can
become severely unbalanced. The outer events of one’s life content and rela-
tionships can also turn to chaos during rapid cellular activations, as multiple
154 
  

                                                           
                                                                 Time-Cycle Mechanics and Evolution
karmic dramas begin to manifest themselves at every turn. When you partic-
ipate in accelerated DNA evolution you are rapidly shifting and elevating the
frequency patterns of which your body and consciousness are composed. This
rapid shift in frequency can appear as utter chaos in terms of external condi-
tions and events.  
      Though the ultimate outcome of these cellular activations is a restructuring of
your body, consciousness and life drama into a higher level of peace, harmony, 
health and order, the process of “getting there” rapidly can be very treacherous 
indeed.  When using exercises such as the one provided, you are learning to 
take control of this process so it does not take control of you. The point at 
which you break up the thought-form crystallization and its energy releases, 
is the point that the karmic imprint would normally begin to manifest into the 
body and external events. DNA Activations alone will get you to this point.
However, in the exercise you then take that released energy, transmute it
through D-5 and D-8 frequency patterns, (the “sun” image), and project it
directly into the DNA. Merging the energy of the karmic imprint with the
D-8 frequencies serves to raise its energies to the highest levels of harmony
and order. That ordered energy  is then placed directly into the DNA, where
it can blend in unobtrusively with the imprints of the operational strands. It
will stimulate further assembly and activation of DNA strands, but in an
orderly fashion that does not cause excessive disruption in your bio-energetic
fields, and which will not throw your life into chaos.  
   In cellular activations, the energy will release at the frequency level in
which the thought-form crystallization existed, sending a rush of photonic
energy through the body at that frequency level. The energy will then indis-
criminately alter the existing order of energies in that area, a condition
which will manifest as chaotic energies moving through the bio-energetic
field, body, and consciousness, then into manifestation. This exercise con-
trols the release of energy and directs it into harmonious order.  
     Learning to direct mental energies, and those energies released from 
thought- form crystallizations will become a needed survival  skill in the near future,   
whether or not one is on the path of ascension, or interested in spiritual activities.  
      The Earth is entering an ascension cycle acceleration period, its grid will
  be infused with UHF D-5 through D-9 energies via a process of Stellar Acti-
   vations. The Stellar Activations will occur as Earth's Merkaba Fields align
  directly with the Merkaba Fields of six Stellar Spirals, as parts of Earth's natu-
    ra l procession through its 26,556-year Euiago time cycle . Everyone on the                             
planet will begin to have cellular activations directly through the Earth’ s grid, due 
to the coming Stellar Spiral alignments and the planetary Stellar Activations  these 
alignments will create.         
  The human bio-energetic field is directly connected to that of the Earth,
  and when the energy infusions of the Stellar Activations begin running through
     Earth’s grid, progressively accelerating between   now and  2017, the   human   body       
    155                                                                                                                                
                                                                                                                               

   Current Events  
will also receive these energy infusions. These energy infusions will cause a rapid
release of the crystallized thought patterns stored in the cells and will trigger rapid
DNA activation, assembly and expansion of consciousness.  
   The thought-form crystallizations held within the body , unbeknownst to
the conscious personality, will begin to release their energies as the pulsation
rhythm of the particles of Earth's body progressively increase between now
and 2017. Your DNA and Cellular Memory will activate whether or not you
are ready, and regardless of whether your body and mind have been prepared
to synthesize these new frequencies of energy. The least prepared may find
their entire life drama falling into shambles, the health of their physical and
mental bodies rapidly deteriorating and their emotions exploding into chaos.
We are not joking, nor exaggerating.  
      Be Prepared . Learn to direct these energies now, before they overwhelm you.
Your survival and ability to remain centered and effective in handling external
events will depend upon your development of these subtle energy-directing skills.
The exercise provided is a good place to begin. In 2012, very intense Stellar
Activation energy infusions will begin, so we suggest that you begin preparing
now, as these skills take a bit of time and practice to develop. We recommend
that you clear as many of these hidden karmic imprints as possible before 2012,
when they will begin to rapidly burst into physical manifestation.  
                                                          
                                                      DNA 
                    DNA Initiations, Consummations and Activations  
    Before we resume our discussion on the mechanics of the Bridge Zone,
 we would like to share with you a little secret about human DNA. Presently
  your conscious awareness is stationed within the low- to middle-frequency
  bands of D-4, and the reality fields you perceive as solid matter and external
  events are those of the low to middle frequency bands of D-3. When you
  think a thought from your present station of focus in D-4 (such as “this is so
  and so now”, or “I see such and such now”), that thought, being a quantity of
    particle substance made of units of electromagnetic energy , automatically
  becomes part of the D-4 Uni fied Field of energy. That thought also becomes
 coded as an energy imprint within the fourth DNA  strand. When you are
  assembling DNA  strands, you are pulling frequency patterns from the Uni fied
   Field into your personal morphogenetic field, one set of dimensional sub-fre-
   quency bands at a time. These dimensional frequency patterns that are pulled
     into the morphogenetic field progressively manifest as new electromagnetic
  codes within the DNA  strands, which means the DNA  progressively expands
  or accretes, as the morphogenetic field expands by pulling in more frequency
 patterns from the dimensional Uni fied Field.  
    When you are assembling your fourth DNA strand your consciousness will
  be stationed within the fourth dimension and you will perceive the Uni fied
   156 
  

                                                                                                            
                                                                                                                      
                                                                                                                
                                                                                                                 DNA
Field of the dimension below in terms of matter solidity. It is the present focus
of your consciousness that magnetically draws frequency patterns from the
dimensional Uni fied Field into your personal morphogenetic field. Once your
consciousness has moved into one sub-frequency band, it pulls that frequency
pattern into the morphogenetic field, the morphogenetic field manifests that
frequency pattern into the corresponding DNA strand and shifts the conscious-
ness to the next sub-frequency band up. Whatever thoughts you held at one
station of consciousness become programmed into the DNA strand that corre-
sponds to the dimension in which that thought was held. A thought-form cre-
ated while the consciousness is focused in D-4 becomes a manifest part of the
fourth DNA strand and is entered into the Cellular Memory stored within the
sub-atomic particles of which the body cells are composed.  
    Once the personal morphogenetic field has pulled in all of the 12 sub-
frequency bands in one dimension, the full DNA strand corresponding to
that dimension is fully assembled and the consciousness is transferred into
the first sub-frequency bands of the next dimension up. We call the point of
evolution when the full DNA strand is assembled the Consummation  and
the point when the consciousness transfers into the first sub-frequency band
of the next dimension up the Initiation.  
    With the Consummation of one DNA  strand, and the Initiation of the
next strand, the contents of the consummated strand begin to progressively
appear in physical manifestation for the consciousness, now focused in the
dimension above. We call the point where the contents of a DNA strand
begin to physically appear within the perceptual range of the conscious per-
sonality the Activation of the strand.  
    For example, when the consciousness has moved through the entire 12
sub-frequency bands of D-3 and thus assembled the third DNA strand, the
identity is considered to be at its third Consummation, (the morphogenetic
field and consciousness have “consumed”, or drawn into themselves, the fre-
quency patterns of the third dimension). At the third Consummation, the
fourth Initiation begins, as the station of consciousness transfers to the first
D-4 sub-frequency bands and the D-4 frequencies begin to enter the morpho-
genetic field and the DNA. As the first sub-frequency band of D-4 initiates
into the morphogenetic field, the first sub-frequency band in the D-3 third
DNA strand begins to Activate, or holographically project its contents into
the range of physical perception. Thus the Consummations, Initiations and
Activations of DNA go together, and represent the points at which the focus
of consciousness transfers from one dimension to another, and the collective
thought-forms from the dimension below begin to come into conscious per-
ception as physically manifest form.  
    As we have mentioned, consciousness will perceive as physical reality
the energy patterns of the frequency bands that exist one full dimension
below the station of awareness. The progressive DNA Initiations of one
157 
                                                                                                                                                                                     
                    
                                                                                                                     

      
       Current Events  
dimensional band create the progressive Activations of, or manifestation of
the collective thought patterns contained within, the DNA strand that cor-
responds to the dimension below. This process of progressive frequency infu-
sion into the DNA, and the DNA-strand assembly it creates, gives you the
perceived illusion of passage through linear time.  
   The new frequencies progressively increase the pulsation rhythm of the
particles that compose your body and consciousness, moving your conscious-
ness into the next set of dimensional sub-frequency bands, while propelling
the contents of one sub-frequency band below into manifest perception. The
manifest illusion of moments passing forward in time within a physical reality
represents your consciousness perceiving the progressive Activations of the
last DNA strand you assembled. These progressive Activations of the last
DNA strand occur as your consciousness progressively Initiates new sub-fre-
quency patterns from its present dimensional focus, into the morphogenetic
field. Time does not move forward, in fact, time does not move at all. The
experience of progression through time is created as consciousness progres-
sively draws into itself frequency patterns from the dimensional Unified
Fields, which progressively expands the consciousness, morphogenetic field
and physical body. The particles of which the body and consciousness are
composed pulsate progressively faster as higher frequencies are embodied in
the morphogenetic field, DNA and consciousness, the body matter grows
progressively less dense and the consciousness expands upward through the
multidimensional Unified Field.  
     W e wanted you to know this little secret about the true nature of
human DNA, and how the DNA is the literal vessel through which the illu-
sionary experience of physical, external reality is manufactured. Knowing
this, you may then realize that when you are shifting your consciousness and
using the imagination to program desired thought-forms into the past, present or
future, you are literally reprogramming the frequency patterns of your cellular con-
tent and the operational holographic program that will manifest into physical reality
through the DNA.  
    The holographic, thought-form program through which your external real-
ity will manifest is literally stored, as a multidimensional electromagnetic pro-
gram, within the sub-atomic particle structure of your cells, much as a computer
stores data within its memory. The DNA serves as the literal conduit through
which that holographic program will project data from cellular memory into
physical manifestation, much as a computer’s circuitry allows the electronic data
stored in memory to be projected onto the screen, into forms recognizable to
human perception. Your external reality field is the screen upon which the
thought-forms that are stored within your cellular memory program will be dis-
played, and the DNA operates as the electromagnetic circuitry through which
that memory comes into perceptual manifestation.  
158  

                                                                                                           
                                                                                                              
 DNA
      To gain creative control over your manifest events, you must edit the cellular
memory ﬁles  (clear and transmute the lower pulsating particles from the body
and auric field), upgrade the holographic thought-form program (create new visu-
alizations of desired past, present and future events, living them in imagina-
tion “as if they are happening now” within the desired time period) and
expand the DNA circuitry (consciously use the chakra system to accelerate
DNA strand assembly) in order to allow new, desired reality pictures to project
into your world of manifest events.  In the practice of conscious evolution, cellu-
lar clearing and DNA transmutation, this is precisely what is taking place.
     When you create “future memory” visualizations, you are putting spe-
cific manifestation instructions into the morphogenetic field of the DNA
strands you have not yet assembled. You will encounter those reality pictures
in manifest form once those DNA strands come into activation, through the
initiation of your consciousness into the frequencies of the next dimension
up. When you recreate “past memories” from your present focus, you are lit-
erally putting new reality pictures, in the form of electromagnetic impulses,
into the DNA strands you have already built and activated. You can literally
shift things in your present manifest experience by reprogramming the past
memory impulses stored in your DNA; add new past memories and new
events will manifest in your present. Create future memories now, and you
can direct the path of your evolution from your present moment in time.
    When you release crystallized thought-forms composed of slower-pulsat-
ing particles from your present cellular structure, you are stopping those lower
thought-form patterns from activating into your DNA, through which they
would otherwise project into physical manifestation. Your moment of power
is always in the present, when you realize that your present focus of attention
can alter and direct events in both past and future, and within the present. It
takes practice to develop skill in conscious manifestation and you must
become familiar with the “feel” of your own inner focus of consciousness in
the present, in order to direct your power of manifestation.  
         Prior to learning manifestation skills, you must learn de-manifestation skills.
Learning how to remove undesirable morphogenetic thought-form patterns from
your active holographic program, which is stored within the cells and made oper-
ational through the DNA, is the first step in gaining mastery over the contents of
your external reality field. By removing slower-pulsating particles from your body
systems, you make room for the addition of new morphogenetic thought-form
patterns composed of faster pulsating particles, which contain the electromag-
netic imprint for more harmoniously ordered events.  
     W e are telling you of these things because the Guardian Alliance needs
your help to ensure the success of the Bridge Zone Project. We need you to
take responsibility for consciously building your personal DNA, expanding
your consciousness, clearing your cellular memory and directing your
thought-forms to the Bridge Zone.  
159