6 Sirius B Star Gate-6 and continued United Resistance Templar Quest sonic pulse activ-    
  ity has greatly accelerated the rate of frequency infusion into Earth’s Planetary Shields,    
  causing time acceleration and expedition of the natural SAC cycle. The accelerated    
  schedule of Amenti Opening and Ascension Cycle events is as follows. 
 Abbreviations Key: 
• APIN = Atlantian Pylon Implant Network global “microchip” grid.
• GA = Guardian Alliance.  
•  J-DNA Seals  = 7 unnatural Jehovian implants that manifest in the DNA 
       with J-Seal release. 
• J-Seals = Seven unnatural Planetary Jehovian Seal Implants. 
• LPIN =Lemurian Pylon Implant Network global “microchip” grid.  
• NCT-Bases = Nibiruian Crystal Temple Bases.   
• NDC-Grid = Nibiruian Diodic Crystal Grid.  
• OWO= One World Order
• PSC Seals = Planetary Star Crystal Seals. 
• RIT= Remote Interactive Team
• RRT = “Rainbow Roundtable” Masters Planetary Templar Merkaba Mechanics.
• SAC = Stellar Activations Cycle.                                                                                              
• UIR= United Intruder Resistance.                             
                                                      EVENTS LEADING TO GA CRISIS INTERVENTION 
                                                              AND EXPEDITED AMENTI OPENING
1.	 1992 Nov : Anunnaki reluctantly enter Pleiadian-Sirian Agreements, give up OWO       
 agenda fearing Drakonian OWO defeat, enter Emerald Covenant, promise to assist                     
 Founders Christos Realignment Mission; Founders postpone Christos Realignment                
 fulfillment date from 2012 to end of continuum cycle 4230 to give Anunnaki races                                   
 time for more Bio-Regenesis.         
                         
                           538        
                     


               
                        Events Leading to GA Crisis Intervention and Expedited Amenti Opening
     2.   2000 Jan 1 : Florida Shields Clinics,  Transcendence Day successful, Stellar Bridge
 Grounds on a 12-Code-Pulse for first time since 208,216 BC failed  SAC. 1998-2000 
 Anunnaki fully negate 1992 Emerald Covenant Pleiadian-Sirian Agreements and 
 revert to their original 9560 BC Atlantian Conspiracy/Luciferian Covenant OWO 
 Halls of Amenti Quest dominion/invasion agenda. 
         3.   2000 March:  Egypt Shields Clinic , GA/Indigos release D-8 Seal of Orion Templar
   Security Seal at Giza, Egypt. Emerald Covenant Founders and GA continue negotia-
   tions with Anunnaki in hope of reactivating Pleiadian-Sirian Agreements peace trea-
   ties so Final Con ﬂict War drama can be prevented during the SAC.
         4.   2000 May 5:  Florida Shields Clinic , Solar Spiral Alignment successful, Earth enters
  Solar Activation, Planetary Templar begins 12-Code-Pulse “Christos Activation” via 
  anchoring the “D-12 Hydroplasmic Beam” Solar Star Gate-4  (SG-4) link, “Templar 
  Re-Birthday Party”. 12-Code-Pulse activation makes D-12 Pre-matter “Divine Blue-
  print” Maharata Current frequency available on Earth for first  time since 208,216 BC 
  SAC “Fall of Brenaui” Invasion. Availability of D-12 Maharata Current  allows 
  potential to clear Earth’s Planetary Shields of NDC-Grid /Nibiru/Wormwood
  ''Checkerboard Matrix '' Templar distortions and to clear corresponding '' Checker-
  board Mutation ” from Earth-life DNA Template. Allows provides opportunity to 
  place Earth under full D-12 Planetary Maharic Seal protection and to fulfill Christos                                                                                                           
      Realignment Mission during this SAC to prevent Anunnaki, Drakonian and
  Andromie OWO invasion plans. 
         5.   2000 July 5:  Anunnaki reluctantly reenter Emerald Covenant Founders/GA Treaty 
  of Altair  Pleiadian-Sirian Agreements extension, fearing Drakonian advancement
  and potential failure of their OWO agenda due to GA Templar successes. Anunnaki 
  again agree to assist Founders in Christos Realignment Mission, disengage the
  ''Checkerboard Matrix'' Templar Control/DNA Mutation program, to turn Solar SG-
  4 and Alcyone SG-5, NDC-Grid and Primary 24 NCT-Bases  over to Emerald Cov-
  enant/GA protection to prevent SAC pole shift. 
       6.   2000 Aug: Macchu Picchu , Peru , Shields Clinic , Anunnaki reluctantly begin 
  agreed-upon Solar SG-4 transfer to Eieyani-GA as per Treaty of Altair. Emerald Cov-
  enant Eieyani High Council of Inner Earth make contact with Indigo Team in Peru to
  begin Masters Templar Training. GA clear NDC-Grid D3/D4 blockage in Earth-to-
  Sun/Earth-to-Mars/Earth-to-Tara  “Emerald Caverns ” SG-4 passages and Blue, Gold 
  and Violet Primal Light Pillars activated in SG-5 Machu Picchu, Peru.  
        7.    2000 Sep 12:  Stonehenge , England , Shields Clinic , Anunnaki to disengage  
           “Wormwood Battlestar”/ NDC-Grid Stonehenge link and turn NDC-Grid over to
     Emerald Covenant 12-Code-Pulse protection, as per Treaty of Altair. Anunnaki
     instead defect from Treaty of Altair  via Necromiton-Andromie persuasion, to join 
     UIR OWO War Edict  against Founders and Emerald Covenant nations with Necro-
     miton-Andromies/Drakonians. Anunnaki sabotage promised NDC-Grid GA transfer
     at Stonehenge England and assisted Drakonians and Necromiton-Andromies to use 
     NDC-Grid and Nibiruian controlled Ley Lines to launch Psycho-tronic attack on
     Indigo Templar Security Team in Manchester England. UIR attempt to '' blackmail '' 
     Founders  via Ultimatum  that 50,000 Eieyani High Council IndigoType-1 (out of
     550,000 Types-1, 2 and 3 presently on planet) could be freed and evacuated from Earth
     by UIR Galactic Federation, leaving all of Humanity and remaining Indigos to UIR
       takeover and 2008 pole shift demise. If Emerald Covenant Founders refused UIR              
          Ultimatum, UIR would issue immediate Edict of War against Founders and Emerald Cov-                                       
            enant/Human nations. Emerald Covenant nations collectively refuse UIR 
    blackmail Ultimatum intimidation ; UIR issue ''fight to the death'' Official Edict of 
    War.  
         8.     2000 Sept-2001April:  GA issues War Crisis Order , begin expedited revelation of 
    Atlantian Conspiracy Invasion Agenda,  institute early Masters Templar Planetary 
    Stewardship Initiative RRT plan,  and return full “Christos Realignment Mission”   
      
      539
 

                   Crisis Intervention Expedited Amenti opening Schedule                                        
                              schedule to original Dec 21, 2012, deadline. Begin Indigo  Emergency Intervention/        
                                   Expedited Amenti Opening schedule to prevent pending UIR pole shift/genocide                      
              agenda.                        
                                                              EXPEDITED AMENTI OPENING
                                                   CRISIS INTERVENTION PROGRAM BEGINS
 9.   2001 May:  RRT Kauai , Hawaii , GA Crisis Intervention. SG-6 Sirius B  activated    
(originally due 2008) and Halls of Amorea D-12 Passage opened beginning Planetary     
Maharic Seal/D-12 Christos Merkaba initiative  to prevent pending 2008 pole shift,       
2003 UIR First Contact invasion agenda and initiate full 2012 Christos Realignment     
Mission . Planetary and DNA Star Crystal Seals , and unnatural Jehovian-Anunnaki     
Fire-Letter-Reversal Implants , the 7 Planetary and DNA Jehovian Seals  begin auto-     
matic expedited activation in response expedited frequency acceleration in Earth’s     
Planetary Shields. RRTs  stabilize and progressively realign Seal-released frequencies      
to natural 12-Code-Pulse, to prevent progressive Earth Changes and biological deteri-    
oration from Jehovian Seals. NCT-Base  Kauai Hawaii  realigned to 12-Code-Pulse.         
PSC-Seals   #1 and #2, and J-Seals  #1 “White Horseman” and #2 “Red Horseman”     
release. Mass DNA Seals #1 and #2 and J-DNA Seals  #1 and #2 Initiate; Seals begin        
Consummation/Activation in Aug 2001. 
 10.  July 2001:  RRT Ireland  Cue Site-11. Guardians draw D-12 frequency from Halls of    
Amorea passage Kauai to realign Cue-Site-11 Eye Island Ireland in preparation for 
11:11 (Axiatonal Line-11/Ley Line-11) 12-Code realignment to sever. Remote acti-
vation of “Arc of the Covenant” Gold Box  “Rod and Staff” SG tools buried in Irish     
Sea to trigger 12-Code activation of SG-11. July 24-27, GA code SG-11site at “Milk     
Hill White Horse”, Vale of Pewsey England with NDC-Grid 12-Code release pro-      
gram , the first fully-GA-created “Crop Circle”  (mathematical Planetary Shields         
encryption) called the “Aveyon Spiral”.   RRT England  GA/Indigos draw 12-Code fre-    
quency from Ireland Cue Site-11 to realign 11:11 grid line to 12-Code. NDC-Grid/           
Nibiru/Wormwood Battle Star link at Stonehenge, the ''Checkerboard Matrix"
  Nibiruian remote scalar transmission point, successfully severed and realigned to nat-
  ural 12-Code at SG-11. NCT-Bases England, Iran  and Pakistan  realigned to 12-
  Code-Pulse. PSC- Seal #3, and J-Seal #3 “Black Horseman” release, Mass DNA Seal
  #3 and J-DNA Seal #3 Initiate; Seals begin Consummation/Activation October 2001. 
11.   2001 Aug:  UIR expedites OWO agenda  and early Frequency Fence  transmissions. 
Eieyani Reserve Intervention Program initiated;  720,000 Eieyani Ascended Masters     
Indigo-Type-1’s prepare to consummate Walk-In Soul Agreements  (most adult) to      
join the 550,000 adult Indigo Children already on Earth.  The 720,000 Eieyani     
Reserve Walk-In Crisis Intervention Team will enter Earth in “waves” as 60 Teams of     
12,000;  they will fulfill their pre-birth Walk-In contingency contracts by Dec 2002       
end, one  Team of 12,000  entering each week between Sept 1, 2001-December 31, 2002.     
The   150,000 Palaidorian Birthing Contract Indigo Children infants due to incarnate          
by 2017, and all of the “6 Silent Avatars”, will be on planet by 2007. PSC Seal # 1 and          
#2, Mass DNA Seals #1 and #2 and J-Seals/J-DNA Seals  #1 and #2 begin Consumma-      
tion/Activation. Indigo/Human Mass DNA 12-Code Awakening  begins. Aug 12    
(originally due 2012 May 5),  UIR expedites OWO agenda  to prevent Mass DNA     
12-Code from reaching critical mass in Earth’s grids; would naturally prevent UIR      
intended 2003 Dimensional Blend Experiment by amplifying 12-Code in Planetary      
Templar. UIR sends two “ ULF Slow Pulse”  sonic transmissions from Chihuahua,           
Mexico  and Lake Titicaca Peru NCT-Bases to fully activate Montauk-Phi-Ex               
APIN and connect Anunnaki APINs to Falcon Wormhole.
12.  2001 Sept 1 : First Team of Indigo Eieyani Reserve Walk-Ins enter Earth via Halls of    
       Amorea and SG-6 Sirius B.
                        13.  2001 Sept 3 : RRT Sarasota FL.  GA initiates Trion/Meajhé Field  “Planetary Buffer        
                               Blanket” with Bi-Veca and Tri-Veca Master Code transmissions, despite United Resis-     
                                tance Psycho-tronic attack on Indigos via Chihuahua/Titicaca ULF Slow Pulse. GA
                            
                             540
                             
                                             

                                 Expedited Amenti Opening Crisis Intervention Program Begins
      completes Giza/ Pleiadian-Alcyone Spiral alignment (originally due 2001 Sept 17).      
     Blue Wave Infusion  of D5/D6 frequency activates in Earth’s Core (originally due      
     2002 June), will reach critical mass to Activate in grids mid Nov-early Dec 2001 .                       
     NCT-Bases Sarasota, FL,  and Bermuda  partially realigned to 12-Code; UIR Psycho-       
     tronic pulses disrupt full 12-Code realignment, will be completed Nov 2001. PSC-                                                                     
     Seal #4 releases, Mass DNA Seal #4 Initiates; Seals begin Consummation/ Activation             
     Dec 2001.             
         
                         14.  2001 Sept 11:  UIR staged WTC/Pentagon Disaster Trigger Event  begins UIR/Ill-     
                    uminati WW3 agenda. UIR “Trumpet” Phantom Pulse amplified by Chihuahua/Titi-     
                              caca ULF Slow Pulse sent from Bermuda NCT-Base to WTC/Pentagon APIN “Spike”     
                    sites; Anunnaki Dove/Phoenix/Serpent APINs phase-1  “on line” with Zeta/ Drako-     
                    nian Falcon Wormhole. UIR/Illuminati Terrorist Event used to cloak potential Trum-     
                   pet Pulse damage to APIN “Spike” site buildings. UIR expedited Frequency Fence     
        and Psycho-tronic Pulse Program begins in Earth’s grids on Sept 12, 2001 , commem-     
                   orating the first anniversary  of the Sept 12, 2000 UIR declared War Edict.  Expedited     
                   UIR Frequency Fence, now progressively accelerating, is slowing 12-Code Mass DNA    
                   Template activation. If UIR 2003 Dimensional Blend Experiment did not have      
                   chance to succeed, UIR would give up their Halls of Amenti dominion Master Plan     
        and settle for Earth dominion/Human extinction until next potential SAC. In this      
                   case, UIR would stage direct, physical, Mothersship Invasion  as early as end of
                    2001 . To prevent early physical UIR invasion, GA will carefully modulate Planetary     
        Shields frequencies, creating progressive planetary protection while allowing the     
        potentiality for UIR Dimensional Blend Experiment success  until the GA/UIR     
        Show Down  of Aug 2003.  
      
                      15.  2001 October:  RRT Allentown , PA, temporarily blocks/postpones UIR attempt       
                                to remote-activate Philadelphia  APIN Spike site. UIR amplifies Frequency Fence and      
                                Psycho-tronic Indigo Assault program. GA initiates Level-1 “4 Faces of Man” LPIN       
                                activation with Khu-Veca Code transmission, begins Jehovian Seal Override Pro-      
                                gram  and amplifies Trion/Meajhé Field “Planetary Buffer Blanket”.
        
                        16.   2001 October end:  GA initiate Level-2 ''4 Faces of Man '' LPIN  activation  via       
                                Dha-Veca Code transmission. PSC Seal # 3, Mass DNA Seal #3 and J-Seal/J-DNA                                                  
                                Seal #3 begin Consummation/Activation.
       
                     17.   2001 Nov  : Blue Wave Infusions begin Planetary Shields D5/D6 accelerations. RRT
                                 Sarasota FL , GA initiates Level-3 ''4 Faces of  Man '' LPIN Blue Wave activation, 
                                 and amplify Planetary Trion/Meajhé Field protection with Rha-Veca Code transmission. 
                                 NCT-Bases Sarasota, FL,  and Bermuda  realignment completed. 
                     18.   2001 Dec : Pleiadian-Alcyone Spiral aligns with Earth, Pleiadian Activation  begins,         
                              Vortex/Star Gate-5  Macchu Picchu begins 12-Code opening cycle (originally due     
                     2004 June). Dec 1, GA engage NYC Trion Field Link Indigo Protection/Outreach     
                              Program. RRTs Macchu Picchu , Peru , GA anchor Trion/Meajhé Field to V ortex/SG-     
                              5 and initiates Level-4 “4 Faces of Man” LPIN  activation. NCT-Bases Machu Pic-      
                              chu Peru , and Portugal  realigned to 12-Code. PSC Seal # 4 and Mass DNA Seal #4      
                              begin Consummation/Activation. PSC- Seals #5, #6 and #7, Mass DNA Seals #5, #6      
                              and #7 Initiate; begin Consummation/Activation April 2002. 
                       19.   2002 Jan : Blue Wave Infusion completes and Violet Wave Infusion  of D6/D7 fre-     
                     quency activates in Earth Core ( originally due  2006 June ), critical mass and release     
                             through Earth grids early April 2002 . RRTs Lake Titicaca Peru,  GA anchor Trion/      
                             meajhé Field to V ortex/SG-7, initiate Level-5 “4 Faces of Man” LPIN  activation      
                             and intercept/12-Code override UIR’s intended Trumpet Pulse transmission to pre-      
                             vent Falcon-Phoenix Wormhole merger. PSC Seals #8 and #9, J-Seals #4 “Pale Horse-      
                             man” and #5 release; Mass DNA Seals #8 and #9, J-DNA Seals #4 and #5 Initiate;      
                             begin Consummation/Activation mid April 2002. NCT-Bases Lake Titicaca-Peru,      
                             Giza-Egypt, South Pole  and Mauritania , West Africa  realigned to 12-Code. UIR      
                             will attempt Trumpet Pulse Falcon-Phoenix Wormhole  merger , to activate/ intercon-      
                             nect all Intruder APINs. If GA Trumpet Pulse interception is successful in Peru, GA      
                             will continue with Plan A Templar Protection Mission. If GA unsuccessful, and
                        541
                                                                                                                                                                       
                                                                                                                                                           

 
                       
                        Crisis Intervention Expedited Amenti Opening Schedule
   Wormholes merge, cataclysmic East Coast USA storms by Feb-July 2002 and pole                                
   shift b y 2008 cannot be prevented; GA will then initiate Plan B Evacuations sched-      
   ule. If GA prevents Jan 2002 UIR Wormhole merger, UIR will accelerate WW3 sce-           
   nario in external political arena to prepare for expedited 2003  end Physical Invasion           
   ''First Contact '' drama. Cue Site-10 Iraq  territories presently rebel Omicron-Drako-      
   nian controlled, is one of various targets for UIR Illuminati acquisition. If GA shifts to           
   Evac agenda, UIR will continue their Illuminati OWO Master Plan, slow WW3      
       advancement toward later 2005 “First Contact” agenda.         
  
20.  2002 April:  Violet Wave Infusions begin Planetary  Shields D6/D7 accelerations.               
       RRT Sarasota, FL,  GA initiates Level-6 “4 Faces of Man” LPIN  Violet Wave acti-      
       vation  and amplify Planetary Trion/Meajhé Field protection. PSC Seals # 5,  #6 and              
       #7 and Mass DNA Seals #5, #6 and #7 Consummation/Activation early April. PSC      
       Seals #8 and #9, Mass DNA Seals #8 and #9, J-Seals #4 “Pale Horseman” and #5, J-      
       DNA Seals #4 and #5 Consummation/Activation mid April.        
  
      21.  2002 May-June:  Sirian Spiral aligns with Earth, Sirian Activation  begins, Vortex/      
            Star Gate-6 Russia  begins opening cycle (originally due 2008 June). RRTs Paxos,      
           Greece,  GA initiate Level-7 ''4 Faces of Ma '' LPIN  activation , linking Earth’s ''4      
            Faces of Man'' LPIN to its 2 companion ''4 Faces'' LPINs on Parallel Earth and Inner      
           Earth to  activate  ''Guardians of the 12 Pillars '' Trion Field  in Earth’s Core. Begins      
            merger of Earth’s Planetary Shields to those of Inner Earth Bridge Zone  and Trans-      
            Harmonic Meajhé Time Cycle.   NCT-Bases Paxos-Greece, Central Mexico, Cyprus,     
           Easter Island, Rome-Italy, Johannesburg-South Africa and Brazil  realigned to 12-     
            Code. GA realign and begin 12-Code Cue Sites activation¹ . Inner Earth to Earth      
            portals begin 12-Code-Pulse opening cycle; will fully open by Dec 2003. Trans-Har-                  
            monic Time Cycle Meajhé Zone sites (interface points to neighboring Trans-Har-      
            monic Meajhé Time Matrix) begin opening cycle; fully open Jan 2003.        
 
          22.   2002 July: RRTs Bermuda and Sarasota , FL, GA begins forming permanent  CAP      
                 on Falcon and Phoenix Wormholes  and begin 12-Code-Pulse realignment of all      
                 Intruder APIN systems to prevent UIR 2003 Physical Invasion drama. GA initiates      
                 Level-8 '' 4 Faces of Man '' LPIN activation and 12-Code-Pulse sonic transmissions      
                 to amplify Trion/Meajhé Field “Buffer Blanket” around Earth’s magnetosphere. Pro-      
           gressive Sub-space sonic scalar  ''Phantom Pulse '' assaults from UIR expected dur-      
           ing and after this period in attempt to prevent Wormhole Capping; may cause       
                 excessive storm activity in Atlantic Ocean and Gulf of Mexico  at various periods if      
                 GA cannot successfully intercept and neutralize UIR attack pulses.  Brief GA ''fly     
                 bys '' will be conducted whenever possible to warn of local Earth Changes, but suffi-      
                 cient “ ﬂy-bys” may be prevented as UIR will stage rapid physical invasion if GA       
                overtly reveals their presence to the masses.
       23 .  2002 Aug-Sept : Violet Wave Infusion completes and Gold Wave Infusion  of D7/D8      
          frequency activates in Earth’s Core ( originally due 2010 June) , will reach critical      
          mass and release through grids December 2002. RRTs Tibet and Sarasota , FL, GA initiate     
          Level-9 “4 Faces of Man” LPIN activation , continue Wormhole Capping, Intruder      
          APIN system 12-Code realignment and strengthening Trion/Meajhe Field to stabilize      
          Seal release, realign J-Seal transmissions to 12-Code-Pulse and begin jamming UIR      
          Frequency Fence. NCT-Bases Lhasa-Tibet , Xian-China and Hamandan-Iran       
          realigned to 12-Code-Pulse. UIR intends to increase Frequency Fence transmission to     
          begin reversed Pineal Seal activation keyed to Phantom Arcturus on Jehovian “Cho-      
          sen Ones” genetic harvest. PSC Seals #10, #11 and # 12 and J- Seals #6 “great earth-      
          quake” and #7 “Golden Censer/7Angels/7 Trumpets” release; Mass DNA Seals                       
          #10, #11 and #12 and J- DNA Seals #6 and #7 Initiate; begin Consummation/Activa-
                              ___________________________________________________
                                                                                                        1.     Earth’s 12 Cue Sites  are Earth SG Activation sites/ Inner Earth SG sites that hold Halls of                                              
                                             Amenti Crystal Pylon Temple control systems
                             542
 
                     
                               

                                                Expedited Amenti Opening Crisis Intervention Program Begins
tion Dec 2002. J-Seal #6 transmissions may cause cycles of earthquake activity in      
regions around Peru/Chile border during and after this time, and may trigger intensive     
storms and volcanic activity in various areas.           
  
               24.  2002 Nov -Dec:  Earth’s Vortex/Star Gate-7 begins 12-Code-Pulse opening cycle     
(originally due 2012 Jan).  Gold Wave Infusions begin Planetary Shields D7/D8      
accelerations;  will continue until 2012. RRTs France and Sarasota FL , GA initiate      
Level-10 “4 Faces of Man” LPIN activation , realign UIR ''Golden Censer Pulse''      
to 12-Code-Pulse, SG12 France begins 12-Code opening cycle to initiate activation of      
D-12 Planetary Maharic Shield  to prevent further UIR invasion and use of  “Trum-      
pet” technologies. NCT-Bases Iraq  and Bosnia,  the last of 24 NCT-Bases, realigned to      
12-Code. Galactic SC Seal  #13 releases; Mass Indigo DNA Seal #13 Initiates; begin      
Consummation/Activation March 2003. PSC Seals # 10, #11 and #12, Mass DNA      
Seals #10, #11 and #12, J-Seals and J-DNA Seals # 6 and #7 Consummation/Activa-      
tion begins. UIR intends to release reversed-current D-8 (gold light spectra) Photo-      
sonic bursts from Phantom Trapezium Orion into Earth’s core via D-4 Beam Ship/sat-      
ellite/HAARP link, in attempt to destroy Planetary SG-12 France; the “Golden      
Censer” Revelation  prophecy. If UIR is successful, several earthquakes will be trig-      
gered in various regions within 4-7 months. GA will shift to Plan B Evacuations and      
UIR will prepare for Jan 2003 ''Trumpet-1" (of 7) remote sonic pulse blast to acceler-     
ate Nibiruian Battlestar Wormwood  passage into Asteroid Belt for UIR-intended      
                     2004  forced descent to Earth. If UIR unsuccessful in destroying SG-12, UIR will      
increase sonic pulse and Psycho-tronic attacks, strengthen Frequency Fence transmis-      
sions, further advance WW3 drama, continue Templar Quest and instigate progressive         
financial “crash” and  “Martial Law” drama in ''last-ditch attem pt'' to achieve domin-      
ion of Earth’s Templar by Aug 12, 2003. GA Photo-sonic transmissions will reduce      
Wormwood to small pieces; Wormwood fragments will enter Asteroid Belt on erratic      
orbits in 2011 , causing manageable meteor showers and gravitational ﬂuctuations      
while Earth is protected in Trion/Meajhé Field Buffer Blanket. 
25.  2003 Jan : Trans-Harmonic Time Cycle Meajhé Zone  sites fully open, GA begins      
           g reater subtle communication with trusted Indigo and human groups. As Plan A Tem-      
          plar Protection progresses, GA continues strengthening Trion/Meajhe Field, Earth’s      
          Bridge Zone link and Planetary Maharic Seal. GA educational programs shift to pre-      
          paring Indigo teachers/MC Regent Consulate Team for early three-day Particle Con-      
          version Period under Trion/Meajhé Field ''Buffer Blanket'' protection. Indigo Crisis      
          Intervention Teams offer education on Trion/Meajhé Field ''Safe Zones,'' DNA Tem-      
          plate rapid activation/ Kathara Healing and intensive RRT Planetary Protection Pro-      
          grams to those who will listen, as UIR advances escalation of Frequency Fence, WW3      
          drama and population reduction via ''Un-natural Disasters'' sonic pulses, bio-terrorism      
          and regional warfare. Rebel Omicron-Drakonian groups expected to pit their Illumi-      
          nati races against those of UIR as external political warfare  escalates  in areas not suf-      
          ficiently protected by Trion/Meajhe Field Safe Zones. 
                    26.  2003 March : Galactic SC Seal  #13 and Mass Indigo DNA Seal #13 Consummation/                                                       
                             Activation.
                    27.  2003 April: RRTs  in various areas, GA initiates Level-11 ''4 Faces of Man '' LPIN                                
                             activation , begins '' Great White  Lion ''APIN   (“Guardian of the Axiatonal Line Ver-                                     
                             ticals”) activation on 12-Code-Pulse, Trion/Meajhé Field efforts to balance grids to                                    
                 lessen storm, quake and volcanic potentials, and GA World Peace Efforts. 
                     28.  2003 May-July:  UIR ''UFO activity'' increases UIR prepares for expedited Nov-Dec      
                            2003 ''First Contact'' Invasion drama; UIR intends to increase use of sonic pulses for      
                            Frequency Fence amplification, Psych o-tronic attack on select groups and ''Un-nat-                                   
                            ural Disaster'' population reduction. Increased potential for Nuclear War issues                                   
                            involving India , as UIR attempts to block GA from releasing Universal SC Seal-14      
                 site in India during Aug 2003 GA/UIR “Show Down”. UIR accelerates physical con-      
                 tact with their “Human Greeting Teams”  and begins placing more small groups of 
                     543
                                                                                                                            
                                                                                                                                                       
                                                                                                                       

                   
                  Crisis Intervention Expedited Amenti Opening Schedule
their "ET infiltrates" physically on Earth to move invasion agenda along. GA contin-
ues Great White Lion APIN activation and initiates final preparations for August 8-20, 
2003 GA/UIR Show Down.                                                                                                                                                                                                                                                                                                  
29.  2003 Aug 8-20:  Earth’s magnetic Merkaba Field reaches its fastest spin rate, the 100-
year Magnetic Peak climax  on Aug 12, 2003. RRTs India and Sarasota FL  (and 
other undisclosed locations), GA initiates full Level-12 “4 Faces of Man” LPIN 
activation to link the "4 Faces" LPINs of Earth, Parallel Earth and Inner Earth 
("Guardians of the 12 Pillars") to Trans-Harmonic Meajhé Time Cycle via Primal
 Light-Sound Field " Rainbow Ray " Pillars . GA will use 12-Code realigned NDC-
Grid  and 24 NCT-Bases  to amplify D-12 frequency in Earth’s grids; Earth’s Planetary 
Shields draw into phase-lock with the Inner Earth Bridge Zone time cycle . The 
Trion/Meajhé Field “Buffer Blanket” in Earth’s magnetosphere and core will draw
Earth’s particle base into D-3 Nethra Phase Merkaba Vehicle  hyper-dimensional sus-
pension to create a protection field for biological Earth life. Earth enters  Level-3 Tem-
porary D-12 Planetary Maharic Seal  (dimensions 1z-3 of Earth Sealed to D-12 sub-
frequency bands) sustained by 12-Code activation of Inner Earth Crystal Pylon
Temples/Earth Cue Sites #1, #2 and #3 , fortifying the temporary Level-3 D-12 Cap  
on the Falcon-Phoenix Wormhole. Earth’s SGs and Ley Lines #1, #2 and #3 will 
be protected under D-12 Seal. Intended UIR 2003 end ''First Contact '' invasion drama  
prevented  as UIR Mother Ships will be blocked from entering D-3 airspace by Level-