42 Strand DNA Template ; like their Palaidia Urtite-Tri-Cloister kin the
Mu’a (Muarivhia), the Yu Seed Race in their present incarnations on Earth
are also called Type-1 Indigo Children; the Yu are Gold Order MC Indigos.  
Other than the Mu’a , the Gold Order  Yu, and their ascendant race lines, 
are the only human races on Earth whose DNA Templates are imbued with 120 4
of the  144 Universal Signet Master Key Codes  corresponding to Universal
Star Gates 2 through 11. The 42-Strand DNA Template  Y u races have 120
of the 144 Universal Signet Master Key  Codes,  and 1584 5 of the 1728  Uni-
versal Encryption Key Codes, encoded in their DNA. Other than Mu’a 
race incarnates,  individuals of   Yu genetic coding  are the only human indi-
viduals on Earth  capable of single-handedly opening the  four Density Lev-
els of Earth’ s Primary Signet Site Star Gates  2 through 11 . Only Mu’a can
open Universal Star Gates 1 and 12.  Yu incarnates can run two-thirds  of the 
Rainbow Ray Current to initiate individual remote activation  of 11th Signet
      _______________  
3.   In ancient Hebrew teachings, the coveted Polaric Maji genetic code was referred to as the 
       ''Code of the Golden Dawn.''  
4.    12 Master Keys per Gate x Gates 2 through 11  
5.    144 Encryption Keys per Gate x Gates 1-11  
273 
                                                                                                                     
                        

The Angelic Human Heritage and Rainbow Roundtables  
Shield, 11th Signet Plate and 11th Templar Cue Site ;  the 11th Signet Set  
through which all other Signet Sets below 11,  and the 2nd through  11th of 
Earth’s 12 Templar Signet Site  star gate opening points, are activated and
directed. Only the Mu’a’s 12th-Signet Set has the power to override and 
redirect the 11th-Signet Set to which the Yu are entrusted as guardians.  
    The Amethyst Order Bra-ha-Rama Maji DNA Template embodies the
full spectrum of the Triadic Codes , the DNA Fire Letters  corresponding to 
the third level  of individuation from Source, the Triadic Level  of the Energy 
Matrix. Beings with Triadic DNA Templates , such as the Amethyst Order  
Urtite-Cloister Maji, incarnate from the  T riadic Level-3  of the Primal 
Sound Fields ; they are legitimately considered Level-3 Ascended Masters . 
Triadic DNA Coding  allows an embodied being to run one-third  of the 
Khundaray Primal Sound Currents, the Violet Flame Tones, and all corre-
sponding Primal Creation Currents below , through the physical body, when 
the Triadic DNA Codes are activated.  The Amethyst Order Bra-ha-Rama 
Maji incarnate through a Tri-Cloister genetic template composed of 12-
Tribes Melchizedek Cloister-“red”-skinned line , Hibiru Cloister  “white”-
skinned line  and Ur-Antrian “brown”-skinned line , combined with a domi-
nant Bhrama and recessive Shambali Mixed Cloister  genome from the Inner 
Earth Palaidorian races . The Amethyst Order Urtite-Cloister Maji Holy 
Grail line races of Seeding-3 are called the Urta  seed race , most often 
referred to as the Ur. The Urtite-Cloister Amethyst Order Maji Christiac-
Rishiac Holy Grail Lines  are called the '' Keepers of the Violet Flame-Guard-
ians of the Triadic Code ''6. The Urta, or Ur Seed Race Urtite-Tri-Cloister 
Maji Christiac-Rishiac Grail Line has a 31-36 Strand DNA Template . Like 
their kin, the two Secondary  Palaidia  Urtite-Bi-Cloister Maji Flame Keeper 
Holy Grail Line Seed Races, the Breanoua and Rama Seed Races , the Ur
Seed Race  in their present incarnations on Earth are called Type-2 Indigo 
Children; the Ur are Amethyst Order MC Indigos.  
    The Amethyst Order  Ur, and their ascendant race lines,  are the only 
human races on Earth, other than the Mu’a  and Yu , whose DNA Templates
are imbued with 487 of the  144 Universal Signet Master Key Codes  corre-
sponding to Universal Star Gates 5 through 8.  The  36-Strand DNA Tem-
plate Ur races have 48  of the 144 Universal Signet Master Key  Codes,  and
11528 of the 1728  Universal Encryption Key Codes, encoded in their 
DNA. Other than Mu’a and Yu race incarnates,  individuals of  Ur genetic 
coding  are the only human individuals on Earth  capable of single-handedly
  opening the  four Density Levels  of Earth’ s Primary Signet Site Star Gates  5 
through 8 . Only  Mu’a  can open Universal Star Gates 1 and 12, and the full 
__________________________________  
6.   In ancient Sumerian culture, the coveted Triadic Maji genetic code was referred to as the 
        '' Code of the Violet Sun '' 
7.     12 Master Keys per Gate x 4 Universal Star Gates  
8.     144 Encryption Keys per Gate x Gates 1-8  
274 

      The Three Primary Urtite-Tri--Cloister Maji Flame Keeper Holy Grail Line                                                              
spectrum of Star Gates 1 through 12.  Y u can open Universal Star Gates 2 
through 11 .  Ur  incarnates can run one-third of the Rainbow Ray Current to
initiate individual remote activation of  8th Signet Shield, 8th Signet Plate 
and 8th  T emplar Cue Site ;  the 8th Signet Set  through which Signet Sets
below 8,  and the 5th  through  8th of Earth's  12 Templar Signet Site  star gate 
opening points can be activated and directed. The Mu’a’s 12th-Signet Set 
and the Yu’s 11th Signet Set , have the power to override and redirect the 8th
Signet Set  to which the Ur are entrusted as guardians.  
      The three Primary Urtite-Tri-Cloister Maji, with a 36-48 Strand Maji
DNA Template, incarnated as members of the Azurite Universal Templar 
Security Team, collectively carrying the Universal Master Signet Key Codes
to the 12 Star Gates of the Universal Templar in their DNA Templates. The 
Universal Signet Master Key Codes are the 144 Master Key Codes9 
and the 1728 Encryption Key Codes10  corresponding to the Universal Level of 
the 12 Universal Templar Star Gates. The three Primary Urtite-Tri-Cloister 
Palaidia Empire Seed Races were entrusted with the power to remote acti-
vate the 12 Star Gates of the Universal Templar . The Star Gates of the
Universal Templar are the 12 primary Star Universal Star Gates that open
vertically between the four Density Levels in our Time Matrix ; the Uni-
versal Templar is the Primal Energy-Feed System to which all Galactic, Plan-
etary and Personal Templar complexes are connected. In founding the 
underground cities of  the Palaidia Empire  in  798,000 BC , the Mu’a  (Muar-
ivhia), Yu and Ur  (Urta) Urtite-Tri-Cloister Flame Keepers Maji Grail Line 
Angelic Human Seed Races set up the foundation structures  upon which
Earth’s Templar Complex  was intended  to function throughout 12-Tribes
Seeding-3 .  They, and their Holy Grail Line ascendants to the present time ,
represent the common seed  from which all contemporary humans  of Earth 
originally emerged  before Fallen Angelic corruption of the Angelic Human  
gene code.   
     The Mu’a, Yu and Ur Seed Races  are members of the Azurite Univer-
sal Templar Security Team embodied in Maji Christiac-Rishic Angelic 
Human form. They carry the genetic potential  to run the Rainbow Ray Cur-
rent, the Universal Primal Light-Sound Currents, into Earth’s Templar for
remote activation of Earth’s Star Gates, and the 12 Primary Star Gates of the 
Universal Templar. As  representatives of the Yanas, Breneau and Founders’ 
Emerald Covenant , the Emerald, Gold and Amethyst Order Maji have 
returned to contemporary Earth incarnation as Types-1 and 2 Indigo Chil-
dren . The indigo Children Types 1 and 2 have returned in hope of assisting
the Angelic Human 12-Tribes  of  Earth to finally fulfill the Sacred Mission 
of Planetary Guardianship  for which they were originally commissioned.  
  _______________________________________________  
   9.   12 Master Keys for each of 12 Universal Star Gates  
  10.  144 Encryption Key Codes for each of 12 Universal Star Gates  
 275 
                                                                                                             
                                                       

The Angelic Human Heritage and Rainbow Roundtables  
                  THE  TWO SECONDARY URTITE-BI-CL OISTER  
         MAJI FLAME KEEPER HOLY GRAIL LINE SEED RACES  
                                 OF THE PALAIDA EMPIRES  
    The three Primary Urtite-Tri-Cloister Maji Seed Races were combined to 
create the two  Secondary Urtite-Bi-Cloister Maji race lines  with  24-36
Strand Maji DNA Templates , who serve as members of the Azurite-Amenti 
Galactic-Planetary Templar Security Team. The two Secondary Maji Flame 
Keeper Holy Grail Line Seed Races responsible for co-founding the Palaidia 
Empires  of 798,000 BC are the Breanoua  and Rama Urtite-Bi-Cloister 
Seed Races, which emerged simultaneously with the Urtite-Tri-Cloister Maji 
races within the underground Palaidia Empires of 798,000 BC . The Brean-
oua Urtite-Bi-Cloister Maji Race  emerged through combining the genomes  
of the Emerald Order Mu’a (Muarivhia) and Gold Order Yu  Urtite -Tri-Clois-
ter Maji race lines, to form a race line that would carry the portions  of the 
1728 Universal Encryption Key Codes  characteristic  to the Mu’a and Yu  
races. The Breanoua race lines are known as Keepers of the Blue-Gold Flame,
as they can embody and run the Blue and Gold spectrum  of the  Primal 
Sound-Light Currents  through their DNA Templates. Breanoua races and 
their ascendancy lines have a 28-30 Strand DNA Template , categorizing 
their contemporary incarnations as Type-2 Indigo Children . The Breanoua 
30-Strand DNA Template  is imbued with 3611 of the 144 Universal Signet 
Master Key Codes  for Universal Star Gates 9, 6 and 3.   The Breanoua 30-
Strand DNA Template  contains  288  Universal Encryption Key Codes  for 
Universal Star Gates 12 and 11 and the 1296 Universal Encryption Codes
corresponding  to Universal Star Gates 1-9; a total of 1584 of 1728 Univer-
sal Encryption Key Codes.12 The  30-Strand DNA  T emplate  Breanoua  races 
have 36 of the 144 Universal Signet Master Key  Codes,  and 1584  of the 
1728 Universal Encryption Key Codes, encoded in their DNA.  
     The Rama Urtite-Bi-Cloister Maji Race  emerged through combining 
the genomes  of the  Gold Order Y u and Amethyst Order Ur  (Urta)  Urtite -
Tri-Cloister Maji race  lines, to form a race line that would carry the portions  
of the 1728 Universal Encryption Key Codes  characteristic to the  Yu and 
Ur races. The Rama race lines are known as Keepers of the Gold-Violet
Flame , as they can embody and run the Gold and Violet spectrum  of the Pri-
mal Sound-Light Currents through their DNA Templates. Rama races and 
their ascendancy lines have a 25-27 Strand DNA Template, categorizing 
their contemporary incarnations as Type-2 Indigo Children. The Rama 27-
Strand DNA Template is imbued with 3613 of the 144 Universal Signet Mas-
ter Key Codes for Universal Star Gates 10, 7 and 4.   The Rama 27-strand
______________________________  
11. 12 Master Keys per Gate x 3 Universal Star Gates.  
12.  144 Encryption Keys per Gate x Gates 1-9 and 11-12 = 144 x11 = 1 584.  
13.  12 Master Keys per Gate x 3 Universal Star Gates.  
276 

   The Two Secondary Urtite-Bi-Cloister Maji Flame Keeper Holy Grail Lin e 
DNA Template contains  1440 Universal Encryption Codes corresponding 
to Universal Star Gates 1-10.14 The 27-Strand DNA T emplate Rama races
  have 36 of the 144 Universal Signet Master Key Codes, and 1440 of the 1728  
Universal Encryption Key Codes , encoded in their DNA. The two  Second-
ary Urtite-Bi-Cloister Maji  Seed Races, the Rama and the Breanoua, collec-
tively carry, within their 25-30 Strand DNA Templates, the Galactic Signet 
Key Codes;  the Signet Master Key Codes and Signet Encryption Codes of the 
Galactic and Planetary Levels of the 12 Universal Star Gates. The three Pri-
mary Urtite-Tri-Cloister Maji Seed Races, the Mu’a (Muarivhia), Yu and Ur, 
collectively carry, within their 31-48 Strand DNA Templates, the  Universal 
Signet Key Codes;  the Signet Master Key Codes and Signet Encryption 
Codes of  the Universal, Galactic and Planetary  Levels of the 12 Universal 
Star Gates.  
     The  five Palaidia Urtite-Cloister Maji Christiac-Rishic Holy Grail Line 
races, the Mu’a, Yu, Ur, Breanoua and Rama, founded the 12 Palaidia 
Empires that began 12-Tribes Angelic  Human Seeding-3 in 798,000BC.  The