20 HAARPs, Trumpets, Horsemen, and Heaven ...........................................403  
                    What Really Ha ppened on 9/ 11/2001 ..............................................................403
                     The  Trumpets, Towers and Terrorists-
                                   The Hidden Realities of the WTC/Pentagon Disaster. ...................... .407 
        UIR OWO Master Plan Agenda. .................................................................410                       
      Decoding “Revelations”—the OWO Schedule ........................................ ..414
             Revelations and “Saint John the Divine” ...................................................416
              The  “Seven Churches,” “Seven Angels” and “the Dove” .....................417
            The Seven Seals and the Four Horsemen of the Apocalypse .................419
          Return to Innocence ......................................................................................422