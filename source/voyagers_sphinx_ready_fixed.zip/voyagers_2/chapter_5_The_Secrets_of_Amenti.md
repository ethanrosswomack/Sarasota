5                                                                                                                        
                       

                                                                                                                                                                                                                                                                                                                                The Secrets of Amenti
              
  
   nized through the morphogenetic field of a star, and re-manifested within 
    a slower vibrating dimensional scale. The 12 new planets entering HU-1 55
    million years ago are the planets of your local solar system —Mercury, Venus,                    
 Earth, Mars, Maldak  (imploded to become the asteroid belt), Jupiter, Saturn,
   Uranus, Neptune, Pluto, Nibiru  (very long orbit, not yet discovered by Earth
  scientists), and your Sun (the part of Tara’s morphogenetic field that fused with
  this already existing, non-Taran sun). The fragments of Tara became part of the 
 Unified Field morphogenetic structure of Harmonic Universe 1.                       
                    
                                                   The Fall of Man and the Lost Souls of Alania
                                                                            550,000,000 YA
       The    event    of     Tara’s     cataclysm  became   known   as   the    “  fall     of    man.”   This    his-
tory beca me interwoven with other events on Earth that occurred since that 
time, appearing in various forms throughout human mythology. The Adam and
Eve drama of Biblical stories combined this event as the fall from God’s grace 
and removal from the Garden of Eden, with other earthly events, including the
Drakon in filtration of around one million years ago. The stories became a 
depiction of multilevel events from various time periods, woven together into a
symbolic event portrayed in the stories. This was also done in relation to the
Biblical Flood and Noah. The consciousness of the beings who were blown
apart in Tara’s fall, also fell into HU-1. They became ripped from their race
morphogenetic field at Tara’s core and disengaged from their original soul 
matrices through which they needed to evolve in order to pass out of the Time
Matrix and dimensionalized systems, and return to Source as pure conscious-
ness. The souls of Alania became trapped in time, fragmented as units of con-
sciousness within the Uni fied Field of HU-1, and there they would have 
remained if a rescue mission had not been orchestrated.                                              
                                 
                                                           AMENTI RESCUE MISSION
                                           The Covenant of Palaidor and the Palaidorians of Tara
                                                                            550,000,000 YA
              Just prior to the cataclysm on Tara 550 million years ago the Ceres, Ur-Tar-      
      ranates and Lumians of Mu devised a plan to rescue the Taran souls that would          
be lost in HU-l during the approaching disaster. Being skilled at time portal    
mechanics and lnterdimensional portal travel, the Ceres created a plan that
the Ur-Tarranates would ful fill. With the assistance of the Sirian Council, Elo-                  
him, and HU-2 Pleiadians, the Ur-Tarranates formed an agreement with sev-   
eral other HU-2 races called The Covenant of Palaidor.  Through the    
Covenant of Palaidor a rescue mission for the Taran souls of HU-1 was set in 
motion. Those involved in this agreement (the Sirians, Pleiadians, Ur-Tarran-
ates, Elohim, Lyrans, Ceres, Lumians and Alanians) became known as the