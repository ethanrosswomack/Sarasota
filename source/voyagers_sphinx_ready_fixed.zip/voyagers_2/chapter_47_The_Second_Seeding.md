47 
                                                                                                                    
                                                                                                                                                                                                                 
 

    
      The Second Seeding  
and the Serres which escalated about 850,000 years ago into a great intergalac-
tic war between the Elohim and the Anunnaki, each fighting for control of the
Earth territory and the evolutionary direction of the human lineage. This war
became known as the Thousand Years’ War  as it lasted approximately1,200
years (850,000 - 848,800 years ago). Most of the Earth races sought exile in
other planetary systems, some retreated to the Inner Earth and most of the
Nephilim were relocated to Sirius A and later to the planet Nibiru. The few
races remaining on the surface were destroyed by the ravages of high-tech war.
Again the Breneau of HU-5 had to intervene, and about 848,800 years ago
they assisted the Elohim and Sirian-Anunnaki to negotiate a treaty through
which both the Anunnaki and Elohim would assist in the Third Seeding of the
human lineage.         
The Treaty of El-Annu, th e Annu-Melchizedeks, and the A nunnaki
                            Resistance and Templar-Axion Seal  
                                                  848,800 YA   
      The agreement the Breneau negotiated between the Elohim and the
Anunnaki 848,800 years ago was called the Treaty of El-Annu,  through
which it was agreed that the Nephilim would not return to Earth but were
allowed to evolve in other systems, and that attempts would be made to cre-
ate another Anunnaki-human hybrid, but only if the Anunnaki agreed to
uphold the Law of One. The new hybrid race would be entered into the
human morphogenetic field through the Sixth Race Melchizedek Cloister,
and through this cloister the remaining Atlanian-Egyptian-Nephilim-Aton
A souls from the previous Host Matrix Transplants could be re-integrated
into the Sphere of Amenti. The new hybrid Melchizedek/Anunnaki race
would be called the Annu, and would be entered into Earth through combin-
ing the fifth race Melchizedek Cloister with the fourth race Atlantean-Egyp-
tian sub-race, during the Third Seeding. The Melchizedek Cloister would
serve as a Host Matrix Family for the Annu and later the remaining portions
of the Egyptian-Nephilim morphogenetic field, which had been place with
the Aton-A Host Matrix Family, would be integrated into the Melchizedek
line. The treaty was created in order to end the war through agreements that
were fair to everyone, allowing the Anunnaki to advance the spiritual aspects
of their evolution through working with the Law of One, while allowing
human evolution to remain on course.  
    The Treaty of El-Annu created a division within the ranks of the Anun-
naki races, and between the Anunnaki and their sister race the Sirian Blues
from Sirius A, who like the Kantarians of Sirius B, served the Law of One and
accepted the authority of the HU-2 Sirian Council. Not all of the Anunnaki
agreed to this treaty, and those who continued to pose a threat to Earth secu-
rity were banned from Earth visitation, and became known as the Anunnaki
Resistance.  The few remaining Dracos hybrids that had previously found