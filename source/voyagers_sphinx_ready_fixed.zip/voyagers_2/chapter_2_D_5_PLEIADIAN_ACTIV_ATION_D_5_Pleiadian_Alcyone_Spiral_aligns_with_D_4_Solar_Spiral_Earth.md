2   D-5 PLEIADIAN ACTIV ATION : D-5 Pleiadian-Alcyone Spiral aligns with D-4 Solar Spiral & Earth
           DATE:  6/2004 - 6/2008 EARTH ACTIVATION
         EARTH VORTEX OPENS:  V ortex # 5 - Machu Picchu, Peru - 6/2004 - 6/2008
         VIOLET WAVE INFUSION : 2006 -2010  D-6 BT and D-7 OT frequencies enter Earth's Core
         DNA : DNA strand # 5 assembles, activates after 5/5/2012, Indigo Star crystal pre-activation
         EARTH ACCRETION LEVEL : 3 to 4 HUMAN ACCRETION LEVEL : 4 to 5
         ( accretion levels 4.5= Bridge Zone 5 = Tara, Indigo Star activates after 5/5/2012)                                _________________________________________________________