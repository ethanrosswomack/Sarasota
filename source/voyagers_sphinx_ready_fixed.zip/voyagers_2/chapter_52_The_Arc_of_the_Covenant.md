52 
  
                                                                                      

                                                                                       
                                                                                       The Arc of the Covenant  
Blue Flame within the Sphere of Amenti. The Blue Flame would then send a
corresponding    spark       of      fifth-dimensional frequency      back     into      the       Earth's  core,
which would open the Earth's morphogenetic field to accept the Sphere of
Amenti, while raising the Earth's grid speed high enough to hold the D-5 Blue
Flame morphogenetic field of Tara.  
    Upon the second spark, the Sphere of Amenti would begin its descent
through the Arc of the Covenant, while the Blue Flame remained within the
Andromeda planet. Originally, the descent of the Sphere of Amenti was to
take about 2,000 years, its energies becoming progressively more available to
the peoples of Earth, stimulating the assembly of the fifth DNA strand and
the raising of consciousness. During its 2,000-year descent, the Earth grid
speed would rise in increments, allowing the Earth's energy system to adjust
to the increasing infusion of high-frequency energy. Once the Sphere was re-
positioned within the Earth core, there would be a period of several years for
the Earth grid to assimilate the new frequency, and the race memory would
progressively infuse the Earth grid. As the race memory from the Amenti
morphogenetic field filtered through the Earth grid, this energy would stimu-
late the DNA of everyone on the planet, and the lost memory would reenter
the cellular memory of individuals as their DNA strands began to assemble
through the new fifth-dimensional frequency now available to them through
the Earth core. Over the course of those several years the races would evolve
rapidly and a mass awakening to the lost memory of multidimensional reality
would occur within large numbers of the population. Through these ener-
getic processes the Earth and her people would be prepared to receive the
Blue Flame of Amenti.  
        The Blue Flame would begin a rapid descent to Earth core following the open-
ing of the Arc of the Covenant.  It would take approximately 12 years for the
Blue Flame to descend to Earth through the Arc of the Covenant. Return of
the Blue Flame was a very precise process, and had to be orchestrated in syn-
chronization with the natural time cycles of which Earth was a part —enter-
ing Earth during the period of natural dimensional blending that occurs at
various times within Earth's time cycle. Timing was very important in the
return of the Blue Flame, as certain conditions had to be planned in advance
of its return. During the dimensional blend the Blue Flame could not directly
enter the Sphere of Amenti as the Sphere would be connected to the Earth's
morphogenetic field at D-2. The Inner Earth portals to D-2 open during the
dimensional blending period, and if the fifth-dimensional frequencies of the
Blue Flame merged directly with the second-dimensional frequencies of
Earth's core, Earth's planetary grid would explode. The fifth-dimensional fre-
quencies had to be dispersed through the Earth grid, via the energetic fields of
certain people alive on the planet. The bio-energetic fields of those individu-
als would serve as frequency modulators for the fifth-dimensional energy.
These individuals would hold the D-5 frequency of the Blue Flame within