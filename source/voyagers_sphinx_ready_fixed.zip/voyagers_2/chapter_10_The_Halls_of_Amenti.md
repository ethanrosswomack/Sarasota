10                 

                                                                                                           
                                                                                                          
                                                                                                            The Halls of Amenti
-20 million YA) the pathways of evolution through dimensional ascension
were reopened for the lost souls of Tara.  
    These races anchored the morphogenetic fields of dimensions 7-12 into
dimension one and Earth. Through their evolution, the one strand of the 12-
strand DNA package was pulled together in Earth particles and connected to
the Turaneusiam morphogenetic field.                                                       
                                                                                  The Halls of Amenti—Rescue Mission Stage 3
                                                                   25,000,000 YA
     The morphogenetic consciousness of the five Cloistered Races held within
the Sphere of Amenti began the third stage of seeding humans on Earth 25
million years ago. They opened the Sphere of Amenti within the Earth Core in
dimension 2, which opened a portal bridge to Tara’s core in dimension 5, a por-
tal that linked the Earth of 25 million years ago with pre-cataclysmic Tara of
550 million years ago. Working with the Priesthoods of Ur and Mu on Tara, the
consciousness of the five Cloistered races created five other portal bridge exten-
sions from the center of the Sphere of Amenti, each of the five opening into
dimensional fields 2 through 6. Dimensional fields represent positions in space/
time within the Time Matrix, stages a planet or being will pass through in its
evolutionary progression of dimensional ascension. The six portals  from the
Sphere of Amenti  (the original one to Tara’s past and five new ones into various
stages of Earth’s future ) linked Tara’ s past, through various time periods on Earth,
into Tara’ s future, creating a new track in time through which Earth could re-evolve
into the ﬁfth-dimensional frequency bands and merge with Tara . Once this merger
was accomplished Earth would become Tara, new lands would open up within
and emerge upon Earth, and Tara would reclaim the energetic thrust lost in the
fall so evolution into the seventh-dimensional Gaia could continue.  
    The six portals in the Sphere of Amenti also allowed the five Cloistered
races to incarnate into dimensional bands/time fields 2 through 6, pulling into
their consciousness and body forms the fragmented consciousness of the lost
souls from each of those dimensional bands. The time codes (frequency pat-
terns) from the first dimensional strand of DNA that had been built up through
Root Races one and two would link into the frequencies of dimensions 2
through 6. The consciousness within the Sphere of Amenti would leave the
morphogenetic field and express into manifestation as Root Races within each
of those dimensional bands, building up into the DNA pattern strands 2
through 6. Through this pattern of building DNA through time, incarnates
within each time period/dimensional band would be able to pull together the
frequencies  of  their  dimensional strand (through a series of  24  incarnations/two
12-cycles), link with the morphogenetic field of their Cloistered Race, pick up
strands 7-12 from the Cloister, pass through the other Cloisters and pick  up  the