20
                                    
                              
    
    
  HAARPs,Trumpets, Horsemen,
                  and Heaven                             
                                                 WHAT REALLY HAPPENED ON 9/11/2001 
                                                
                                                      HAARPs, DNA and the Mass Awakening                    
      Like the sadly manipulated spiritual movements of humanity’s last
10,000 years the '' science-technology movement ,'' unfortunately, is the only
one which “appears” to offer something more empowering. Such “beauty is
only skin deep” when it comes to both the spiritual and scientific
perspectives through which we attempt to comprehend the meaning and
purpose of our lives. This was not always the case. In fact, our present
condition of innocence about “what makes the universe go ‘round” is a rather
recent evolutionary detour taken in 9558 BC, when we “lost our way,” and
our memory, as we emerged from the ruins of Atlantis. Presently, people who
are learned in the scientific traditions most often succumb to the Drakonian -
inspired ego-trip propaganda  of '' scientific expertise ,'' whereby most of
humanity’s best “rational minds” believe that they know that ETs, angels,
souls and God do not really exist. Psychology  has done its part well in
feeding the covert Fallen Angelic One World Order (OWO) dominion
agenda, by unknowingly promoting utterly false interpretations of the
workings of the Human mind . People who begin to “get a glimpse above the
Anunnaki NET” into the higher dimensional frequencies, or report “alien
abductions,” or begin to remember “other lives,” or think that “mass
conspiracies might exist” are conveniently labeled as “mentally disturbed.”
Classic psychiatric responses to the above noted perceptions include
“Psychics are charlatans—there’s no such thing as ESP”; “Sleep disorders
cause abduction hallucinations and the illusion of out-of-body travel”;
“multiple personality syndrome creates false memories of reincarnation”; and
 finally “Conspiracy theorists are paranoids or have savior complexes.” Oh,
  please....  
      One of the most valuable contributions our Fallen Angelic inspired 
Scientific Establishment has contributed to the “Silent Invasion” agenda,
with the assistance of the Illuminati-manipulated U.S. government, is
creation of the infamous '' High-frequency Active Aural Research 
Program ,'' or HAARP . You know the one...that '' Angels Don’t Play .'' Both
  scientists and outer External Government authorities have created the
   403  
                                                                                                                                                                                                                                                            
                         
                                                                                                                          


                        
                        
                         HAARPs, Trumpets, Horsemen, and Heaven
HAARP installation with no knowledge whatsoever  that it is anything but a
“potentially useful, though possibly risky” technology. Even the few elite, “in-
The-know,” members of the Illuminati World Management Team don’t know
the real ET -intended application of the HAARP  installation  and its other
hidden “sisters.” The elite “Key Controllers” within Illuminati
establishments do know it is intended to assist the “Visitors” in creating the
Mass Frequency Fence —they have been told the Frequency Fence is needed
to “prevent mass panic” when the ETs make their “public debut.” The
HAARP installation is a high-frequency radio transmitter complex
positioned in Gakona, South Central Alaska  160 miles north east of
Anchorage. It is operated (unknowingly on behalf of “guess who”?) by the
U.S. Navy and Air Force, and Phillips Laboratories. The U.S. military
intends to use HAARP to focus a billion-watt pulsed radio beam into
Earth’s outer atmosphere . Transmission of this beam will supposedly form
Ultra-ULF waves and’ bounce them back to Earth. The Ultra-ULF waves are
intended to '' improve submarine communications '' (not to mention ET
underwater base communications ) and will allow detection of subterranean
phenomena such as “oil reserves and underground missile silos.”1 
       Much public controversy has emerged around the potential dangers  in
using the HAARP network, due to the claims of some researchers that it will
''blow 30-mile holes in Earth’s upper atmosphere '' and might possibly
''disrupt the subtle magnetic energies of Earth and biological life-forms .''
Oh brother. . .here we go!  
      Under natural environmental conditions, dormant portions of the DNA
templates of biological life-forms spontaneously and progressively activate in
reaction to the frequencies of Stellar Wave Infusions that occur during
SACs. This natural DNA function allows the physical, emotional and
mental body structures to create temporary adaptability  to the increased
UHF of SACs, preventing illness and premature death . The DNA
template responds to the planetary electrical and magnetic fields , and
certain kinds of “disruptions” in the magnetic balances of Earth’s outer
atmosphere block the natural DNA-activation process. Temporary Scalar-
pulse disruption of Earth’s outer atmosphere is precisely the method used by
Galactic Federation in 3470 BC , on behalf of the Nibiruian Council, to
further “erase” our then-re-surfacing Atlantian race memory and to further
scramble our DNA templates and language patterns. Presently, due to efforts
of the Emerald Covenant races and lndigo Children of Earth, who have been
consciously working with Bio-Spiritual tools to heal and activate their DNA
templates; spontaneous, natural, critical-mass DNA activation has now been
triggered within the Human and lndigo masses. It is for this precise  reason
that the United Intruder Resistance (UIR) has accelerated the schedule of
its Illuminati OWO Master Plan from the intended 2002-2003 to August
12, 2001, which is when the “Big Game” really began.  
  Human DNA  is designed to enter this natural Spontaneous Mass
Activation cycle  during SACs, in response to increasing frequencies within
_____________________  
1.   Conveniently, the HAARP will be very handy in locating underground bases, “parked
        space ships,” Nibiruian Crystal Template Network sites  and APIN Systems  as well!   
404