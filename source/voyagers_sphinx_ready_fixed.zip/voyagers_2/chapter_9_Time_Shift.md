9
                                            
                                                                                                  Time Shift  
                    
                                ASCENDING AND DESCENDING PLANETS  
      The Bridge Zone, Shift to Agartha, Ascending and Descending Planets
          The speed of evolution of a planet is directly connected to the rate of
evolution of the life-forms upon the planet. In the Bridge Zone Project we
are going to shift Earth entirely out of its present D-3 time cycle, which con-
stitutes accelerating the pulsation rate of particles and shifting the angular
rotation of particle spin by 22.5°. In order to make this shift successfully, 8%
of Earth’s populations have to fully assemble the fifth DNA strand, 144,000
individuals must assemble the sixth DNA strand and the remaining popula-
tions must rapidly reach an accretion level of 4.5, which is the assembly of all
of the fourth DNA strand and half of the fifth strand.  
    Remember that consciousness will perceive as solid the dimensional fre-
quency bands one dimension below its present station of focus. For the con-
sciousness of humanity to experience the physicality of Earth at the 3.5-
accretion level of the Bridge Zone, that consciousness must have a minimum
of 4.5-accretion, which comes with assembly of all of the fourth DNA strand
and half of the fifth strand. The human collective represents part of the
Earth’s matter body, and if the collective accretion level of human beings
remains at its present 3 —3.5 average, the accretion level and vibration rate of
the Earth’s grid will be held down. In the Bridge Zone time continuum, the
Earth’s accretion level will be raised from its current 2.5- to a 3.5-level of
accretion. In order for the Earth's grid to reach this accelerated level of accre-
tion in time to begin entering the Bridge Zone by 2012, most of the human
populations must be able to reach no less than a 4.5-accretion level. If the
majority of the populations cannot reach the 4.5-accretion level, the vibra-
tion rate of Earth will not reach 3.5 and the planet will not shift into the
Bridge Zone Time continuum.  
  In terms of a planet shifting into another time continuum, what is
really taking place is that the pulsation rate of particles, within the three lev-
160 
       
  


                                                              
                                                                                         
                                                                                      Ascending and Descending Planets
                    els of the planet’ s body , is being increased and the angular rotation of particle
spin is being shifted. These adjustments constitute a shift of the planetary
bodies into faster moving time cycles. The consciousness of those upon the
planet must also make such a shift, and the particles of which the body and
consciousness are composed will undergo the same acceleration of pulsation
speed and change in angular rotation of particle spin.  
    Normally , when a planet reached its half-point in its second ascension
cycle, which constitutes the 2.5-accretion level, the electrical overtone parti-
cles of its D-3 Merkaba Fields would merge with their anti-particles, form a
morphogenetic wave and transfer into the next Harmonic Universe into the
sixth-dimensional frequency bands. Also included in this morphogenetic
wave are the electrical overtone particles of the D-1 and D-2 Merkaba Fields.
The D-2 overtone electrical particles transfer to D-5 and the D-1 electrical
overtone particles transfer into D-4. So normally, during the half-point mor-
phogenetic wave the clockwise rotating electrical Merkaba Fields of D-1, D-2
and D-3 open up and merge with the counterclockwise rotating magnetic
Merkaba Fields of D-4, D-5 and D-6. During the 10-year period surrounding
the half-point, all of the electrical overtone particles that Earth had pulled in
from dimensions 1, 2 and 3 and stored in the morphogenetic field, are trans-
muted through their anti-particles and transferred into the morphogenetic
field of Tara in HU-2.  
    At the completion of the ascension cycle, 2213 years later, the same pro-
cess occurs with the magnetic base tone particles within Earth’s morphoge-
netic field. The particles of Earth’s counterclockwise-rotating, magnetic
Merkaba Fields, of D-1, D-2 and D-3, open and merge with the particles of
Tara’s electrical clockwise-rotating Merkaba Fields of D-4, D-5 and D-6.
Earth’s morphogenetic field fully merges with that of Tara and Earth leaves
the time continua of HU-1 and shifts into the time continua of HU-2. Earth
becomes Tara. During this process, the consciousness stationed within the
three levels of Earth’s body, the six time continua of Earth’s HU-1 Euiago
cycle, also transmutes and transfers into the time cycles of HU-2. A planet’s
shift from the time cycles of one Harmonic Universe into the time cycles of
the next Harmonic Universe usually takes place in two phases. The overtone
particle base transfers at the half-ascension cycle point and the magnetic par-
ticle base shifts 2213 years later, at the end of the ascension cycle.  
    The Bridge Zone Project will accelerate this process; the two phases of
Earth’s particle conversion from HU-1 to HU-2 will take place at once,
between 2012 and 2017. The arti ficial time continuum into which Earth will
shift exists between the natural time cycles of the third and fourth dimensions.
In the natural procession of merging the grids of Earth and Tara, the Earth’s grid
progressively raises in speed, beginning 15-20 years before the half-cycle point.
    The pulsation rate of Earth’ s D-1 particles raises to the rhythm of D-4,
Earth's D-2 pulsation rate accelerates to the rhythm of D-5 and Earth’s D-3 par-    
161                                                                                                                             
                                                                                          
                                                                     

Time Shift  
ticles enter the D-6 rhythm. For a period of five years before the half-point,
Earth’s grid begins to intersect with that of Tara, as Earth’s D-1 particles shift
into the pulsation rhythm of the D-4 time continuum. Following the half-
point, scheduled for 2017 AD, Earth would naturally begin returning to the D-
3 - D-1 pulsation rhythms of the HU-1 time cycle. The Dracos-Zeta Resistance
plans to broadcast the EM pulses of their Frequency Fence through the pulsa-
tion rhythms of HU-l dimensional frequency bands.  
    The Bridge Zone Project will allow the primary particle base of Earth to
remain at a higher level of pulsation within the Bridge Zone time continuum,
at the point Earth would normally begin to slow in pulsation rhythm and revert
back into the HU-l time cycles. The Earth must begin its ascent into the HU-
2 particle pulsation rate now, its D-1 particle base accelerating to the D-4
rhythm, in order for the entire grid (both electrical overtone and magnetic base
tone particles) to shift into the D-4 time cycle. Earth’s morphogenetic field will
temporarily reach a stable 4-accretion level, the accretion level of the D-4 time
cycle, by 2012. Acceleration of the particle pulsation rhythm of Earth’s grid
into the D-4 rhythm is a normal part of the ascension cycle process. For the
Bridge Zone project to succeed, this acceleration must be intense enough to
raise both overtone and base tone particles into HU-2 rhythms, and must also
be able to counter balance the ULF EM pulses of the Frequency Fence the Dra-
cos-Zetas plan to use in 2004.  
     If Earth does not make it into the pulsation rhythm of the D-4 time cycles
by 2012, full merger between the grids of Earth and Tara will not take place, the
Halls of Amenti will not open and Earth will not be able to shift into the
Bridge Zone Cycle. In this case the Frequency Fence transmissions of the Dra-
cos-Zeta Resistance (should they be successful in orchestrating their 2003
experiment) will begin chain reaction Earth changes between 2012-2017, as
the natural fusion process of particle and anti-particle within the Earth’s grid
are disrupted.  
    The Frequency Fence would cause the particle pulsation rhythms in cer-
tain portions of Earth grid to drop rapidly in speed, while other portions of the
particle base attempted to rise in speed. The fabric of Earth’s particle base
would begin to tear open and fragment. In areas of Earth’s grid where this frag-
mentation occurred, landmasses would begin to break apart, new fissures within
the Earth’s tectonic plates would emerge and plate shifting would result. This
does not have to occur. The populations are fully capable of accelerating their
genetic evolution by consciously building DNA through working with the
higher chakra centers. If humanity successfully raises the pulsation rhythm of
the particles that compose the physical, emotional and mental bodies, the
Earth’s grid will proceed to accelerate its own pulsation rhythm into the D-4
time cycle. Earth will reach a high enough pulsation rhythm by 2004 to shift
162 
 

                                                                      Ascending and Descending Planets  
out of range of the Frequency Fence transmissions and the Halls of Amenti
plan will proceed on schedule. The Guardians are con fident that humanity
will be able to do its part now,in order to ensure its own survival.   
       Earlier in our discussions we have mentioned the existence of the Inner
Earth, Agartha, which is located in a frequency modulation zone between
Earth and Earth’s double in the parallel universe. Agartha represents part of
Earth, and like Earth, Agartha has three levels of the planetary body. The
Earth’s three primary body levels exist within dimensions 1, 2 and 3. There is
a relationship of particle pulsation speed between Earth and her parallel dou-
ble: 
     The particle pulsation speed of Earth’ s D-2 = anti-particle pulsation
speed of parallel Earth D-1.  
       Earth’s D-3 particle pulsation speed = that of parallel D-2, etc.  
     The speed of particle pulsation within each dimensional band in the
anti-particle universe is faster than that of the corresponding dimension in
the particle universe. The particle pulsation speeds of the dimensional bands
in the particle universe run one dimension behind those of the dimensional
bands in the anti-particle universe. The speed of particle pulsation in the par-
ticle universe D-2 would be the speed at which anti-particles pulsate in D-1
of the parallel universe. Earth’s D-2 particles are stationed within the same
dimensional Uni fied Field as the D-l anti-particles of parallel Earth:
        Particle D-2 = Anti-particle D-1.  
        Particle D-3 = Anti-particle D-2.  
        Particle D-4 = Anti-particle D-3, etc.  
    The frequency bands that make up the D-2 particles of Earth are the
same frequency bands that make up the D-1 anti-particles of Parallel Earth.
    Earth’ s D-3 particles co-exist with parallel Earth’ s D-2 anti-particles.
    Parallel Earth’ s D-2 anti-particles co-exist with Earth’ s D-3 particles, etc.
    When observing Earth’ s D-3 landscape (which are the dimensional fre-
quency bands that appear solid to a consciousness stationed in D-4 of the par-
ticle universe) one perceives the contours of D-3 particle and D-2 anti-
particle Earth.  
      It is important to realize this intimate relationship between the particle
content of Earth and anti-particle Earth, if one is to understand the reality
fields in which Agartha, the Inner Earth, takes place. In view of the above
dimensional particle and anti-particle relationships, the three levels of
Earth’s planetary body and those of the parallel Earth can be understood as
follows:  
    Earth's D-2 elemental body = anti-particle Earth’ s D-1 iron core crystal.
    Earth’ s D-3 mental body/atmosphere = anti-particle Earth’ s D-2 elemen-
tal body.  
163 
                                                                                                                  
                                                                                                                  
                                                                                                             

Time Shift  
    Anti-particle Earth’ s D-3 mental body/atmosphere = Earth’ s D-4 astral
body, which is the D-4 gold core crystal Merkaba Field of Tara, stationed
within the center of Earth’s Sun.  
    Agartha represents an Earth reality field that exists between the Earth
and her parallel double. Earth’s D-1 iron core crystal is stationed within the
first-dimensional frequency bands of the particle universe, at 0-accretion
level. Anti-particle Earth’s D-1 iron core crystal is stationed within the D-2
frequency bands of the particle universe, Earth’s elemental kingdom, at accre-
tion level 1. Agartha’s D-1 iron core crystal can be viewed as being stationed
halfway between Earth’s D-1 core crystal and the core crystal of parallel Earth
at particle universe D-2, which would represent a .5-accretion level in the D-
1 frequency bands. For Earth, parallel Earth and Agartha, the elemental
body is one dimensional band above the placement of the iron core crystal,
and the mental body/atmosphere is one dimensional band above the elemen-
tal body, or two dimensional bands above the iron core crystal:  
•   The particle base of Earth is in D-1 of the particle universe at accretion
       level 0 to 1.  
  •   The particle base of parallel Earth is in D-2 of the particle universe at
      accretion level 1 to 2.  
   •    The particle base of Agartha is half in D-1 and half in D-2 of the particle
       universe, at an accretion level of .5 to 1.5.  
 •    The elemental body of Earth is at particle universe D-2, accretion level 1
      to 2.  
 •    The elemental body of parallel Earth is at particle universe D-3, accretion
      level 2 to 3.  
•    The elemental body of Agartha is at particle universe half D -2—half D-3,
      accretion level 1.5 to 2.5.  
•   The mental body/atmosphere of Earth is at particle universe D-3, accre-
      tion level 2 to 3.  
•   The atmosphere of anti-particle Earth is at particle universe D-4, accre-
      tion level 3 to 4.  
•   The atmosphere of Agartha is at particle universe half D-3 —half D-4,
      accretion level 2.5 to 3.5.  
       From the perspective of the fourth dimension (where human conscious-
ness is presently stationed) the D-1 iron core crystal of anti-particle Earth,
(that is stationed within the overtone D-2 frequency bands of the particle
universe) and the D-1 iron core crystal of particle Earth, (that is stationed
within the D-1 frequency bands of the particle universe), perceptually merge
and appear as the Sun. The Sun appears to be separated by many miles from
Earth. From this perspective, what appears to be the physical body of Earth is
164 
 

                                                             
                                          Ascending and Descending Planets
actually the low to middle D-3 frequency fields, the slower-moving particles
of Earth’s “mental body.”  
      The atmosphere on and surrounding Earth is the middle- to upper-D-3
frequency fields. The “outer space" existing beyond Earth’s atmosphere repre-
sents a Repulsion Zone and the frequency fields of D-4 through 15 that exist
beyond this Repulsion Zone. From the fourth-dimensional perspective, there
appears to be a separation of many miles between Earth and the Sun because
the natural Repulsion Zone between D-3 and D-4 creates the illusion of
absence of light and expansion of space. This Repulsion Zone is created by
the 45° shift of angular rotation of particle spin that occurs between one Har-
monic Universe and the Harmonic Universe above. There are five primary
Repulsion Zones within the 15-dimensional universe, which create the illu-
sion of vast distances between star systems existing within the 15 dimensions.
    Though Earth, the planets and the galaxies appear to be separated in
space by great distances, that distance is only a natural holographic illusion
created by the refraction of energy waves through varying angular relation-
ships between spinning particles. All that you perceive outside of yourselves,
including Earth and what appears to lie beyond, in Earth’s immediate solar
system, actually exists at the center of Earth’s Sun, at varying rates of particle
pulsation and angular relationship of particle spin. Earth’s Sun is likewise
contained within a larger solar structure with other planetary bodies, which
would appear to exist outside of that Sun from various stations of perception.
The reality of the mechanics of energy is that dimensions 1 —3, and all things
contained within them, exist within the D-4 Merkaba Fields of Tara’s gold
core crystal and that core crystal is stationed at the center of the Sun. The
gold core crystal at the center of Earth’s Sun serves as an electromagnetic por-
tal structure between HU-1 and HU-2. Though the Universe appears spread
out over great distances, in reality it all exists within the same space, at vari-
ous dimensional frequency levels and particle spin relationships.  
    W e are telling you of these hidden reality mechanics so you may begin
to comprehend what will be taking place on Earth as your half-cycle period
approaches and the Bridge Zone Project goes into operation. We have said
that Earth’s accretion level will be shifted from its present 2.5 level to that of
3.5 accretion. The present 2.5-accretion level is the measurement of the fre-
quencies contained within Earth’s morphogenetic field. Accretion level 2.5 is
also the measurement of the beginning of Earth’s atmospheric body, the part
which is closest to Earth’s surface.  
    Earth’ s atmospheric body represents the portions of the D-3 Uni fied Field
that have not yet been pulled into Earth’s morphogenetic field, the particle
fields of D-3 that exist outside of Earth’s morphogenetic field and thus outside
of Earth’s physical body structure. Earth’s atmosphere is composed of the
upper frequency bands of D-3, which represent the 2.5 —3-accretion levels.
Earth’s atmosphere is thus said to be at 2.5 accretion.  
165  
                                                                                                                  
                                                                                                                                                                                                                          

      Time Shift  
At present, Earth’s D-2 elemental body is at 1.5 accretion and its D-1
particle base is at .5 accretion. Agartha’s atmosphere is at 3.5 accretion, its
elemental body at 2.5, thus Agartha’s elemental body is located within
Earth’s atmosphere at a different angular rotation of particle spin than that of
Earth’s particles, and so appears invisible. Agartha’s particle base is at 1.5
accretion, thus Agartha’s particle base is located within Earth’s elemental
body.  
    During the Bridge Zone transition, when Earth’ s atmosphere is shifted
from 2.5 accretion to 3.5 accretion, it will be merged with the atmosphere of
Agartha. Earth’s elemental body will shift from 1.5 accretion to 2.5 accre-
tion, Earth’s elemental kingdom will merge with that of Agartha. Earth's par-
ticle base will shift from .5 accretion to 1.5 accretion, Earth’s particle base
will merge with Agartha’s particle base. When Earth merges with Tara’s grid
in the D-4 time cycle between 2012 and 2017, the Earth’s morphogenetic
field temporarily reaches a height of accretion level 4, then returns to its nat-
ural 2.5-accretion level following 2017.  
    In the Bridge Zone Project, Earth’ s morphogenetic content will peak at
accretion level 4 when merging with Tara’s grid between 2012-2017, then
instead of returning to its natural 2.5-accretion level/D-3 time cycle after
2017, Earth will return to the 3.5-accretion level. The 3.5-accretion level
represents the time cycle between D-3 and D-4, in which Agartha’s reality
takes place.  
     In the usual process, Earth’s particles would undergo a 45° shift in angular
rotation of particle spin to enter the D-4 cycle, then shift back 45° to return
to the D-3 time cycle. In the Bridge Zone, Earth will undergo the 45° shift of
angular rotation of particle spin to merge with Tara. Instead of shifting back
45° to return to the D-3 time cycle, Earth’s particles will shift back only 22.5°,
placing Earth within the 3.5-accretion level, the time cycle between D-3 and
D-4, merging Earth and Agartha. Earth will become the Inner Earth, Agar-
tha, through the 2012-2017 transition.  
    Humans who have assembled all of the fourth DNA  strand and half of
the fifth will perceive this transition as the emergence of new lands and struc-
tures on Earth, and the literal disappearance of some of the existing Earth
structures. Humans who do not assemble these strands will perceive a differ-
ent reality entirely. During this transition, the particles of Earth that are
unable to fully shift into the faster pulsation rate, those that cannot reach an
accretion level of 3.5, will not make this shift into the Bridge Zone. The par-
ticles that do not shift will create a Phantom Earth  that will return to the D-
3 time cycle. The Phantom Earth will no longer remain attached to the mor-
phogenetic field of Earth and Tara. This condition is referred to as a planet
being “cut out of the grid.” The planet is no longer attached to the evolution-
ary imprint contained within its morphogenetic field. A phantom planet is
no longer capable of evolving out of the Harmonic Time cycle in which it is
166 

                                                                  Ascending and Descending Planets
placed, it is no longer considered an Ascension Planet, it is called a
Descending Planet.  Such a planet will continue to evolve within its Har-
monic Universe time cycles, slowly expending the energies held within its
core, until its particle pulsation rhythms slow, its temperatures cool and even-
tually it implodes to become a black hole. It can take billions of years for a
Descending Planet to meet this destination, this does not occur quickly, and
life can continue to evolve upon its surface for many years. In the case of
Earth’s coming changes, when the planet is shifted to the Bridge Zone, the
portions of Earth’s particles that do not make the shift will become a Phan-
tom Earth —a Descending Earth.   
      The phantom version of Earth will be cut off from the interdimensional
Time Matrix grid, and the Phantom Earth will return to the D-3 time cycle
following 2017. The entire Bridge Zone Project was designed to keep Earth’s
primary particle base out of that D-3 time cycle, because in that time contin-
uum the Dracos-Zeta Resistance successfully employs the Frequency Fence
and creates Earth’s destruction in 2976 AD. (This probable future for the D-3
time cycle can be averted if the Resistance-inspired 2003 experiment does
not take place.) In the Phantom Earth D-3 time cycle Earth changes occur,
which debilitate a portion of human civilization, and the Zeta-Dracos hybrids
come to “help put things back together”, while placing the remaining popula-
tions under covert mind control through the use of Frequency Fence and
Holographic Insert technology.  
    Humans who do not assemble DNA  strand 4 and half of strand 5 will find
themselves within this probability on the D-3 Phantom Earth. They will not
know they are being controlled, and they will not realize the Dracos-Zeta
Resistance manipulates and covertly directs world culture. They will not
realize they are not free. And the souls of D-3 phantom Earth will con-
sciously have no idea of the ultimate destiny of soul fragmentation toward
which they will be headed. Most souls caught in this D-3 incarnational cycle
in 2017 will have to continue reincarnating within the D-3 continuum, until
they slowly assemble the fourth and half of the fifth DNA strand, which will
be exceedingly difficult to do while under Frequency Fence control. Your
future incarnational selves will be those humans faced with the 2976 cata-
clysm. Through the Bridge Zone Project the severity of this future can be
lessened.          
     If  the Bridge Zone Project is successful, the D-4 time continuum, in which
the Zetas now have their strong hold, will become free from Dracos-Zeta con-
trol, so the 2976 AD explosion of Earth will be avoided for the D-3 Earth. The
Resistance will still attempt to in filtrate and control D-3 Earth, but their
chances of success will be greatly reduced after losing control of the D-4 con-
tinuum.  
    Humans remaining in the D-3 time cycle will not benefit from the genetic
acceleration opportunity that is open to Bridge Zone humans, as they will be
167 
                                                                                                                  
                                                                                                              
                                                                                        

Time Shift  
cut off from the Sphere of Amenti morphogenetic field, which will remain in
Earth’s core in the Bridge Zone. They will follow a different course of evolution
on Descending Earth. It is much more difficult for individual souls to ascend
from such a planet, as their personal connection to the Sphere of Amenti mor-
phogenetic field, which allows them direct access to their higher-dimensional
identity, also becomes severed.  
     The Bridge Zone Project is an absolute necessity to ensure the survival of
Earth, and it also allows humans the opportunity to evolve beyond the reaches
of Dracos-Zeta manipulation. If events unfold perfectly, all humans will shift to
the Bridge Zone in 2017, and thus no one will fall under Dracos-Zeta domin-
ion, but the chances of such high success are slim. It is presently essential that
a critical mass of humans reach a 4.5-accretion level before 2012.  
     If this does not occur, no one will make it to the Bridge Zone continuum,
the Halls of Amenti will not fully open and some degree of Earth changes will
take place between 2012-2017. Humans who are able to assemble the fifth
DNA strand can be rescued by guardian transports, but there will be little time
for such an evacuation, and the majority of the population could not withstand
transport travel to Agartha or Tara. If the Bridge Zone Project is not successful,
most of the human populations will be unable to escape Earth changes, covert
Dracos-Zeta rule and separation from their personal soul matrix. If the Bridge
Zone Project fails, Earth will meet its untimely demise in 2946 AD. Guardian
Host Matrix transplants would have to be used to shift Descending Planet souls
into Agartha before 2976 destruction. This would constitute another massive
Guardian rescue mission in the future, the prospects of which are not promis-
ing, if   humanity were under Resistance  Frequency  Fence control. The need for
this rescue will be removed if  present day humans can accept responsibility for
their personal evolution now, and assist the Guardians in making the Bridge
Zone Project a success.  
     Y our future is in your hands, and your races will live the consequences of
your collective choices. Each individual has the power and the responsibility
for choosing the path of personal destiny that will unfold. In choosing to
ignore the reality of Earth’s present multidimensional affairs, you will be sub-
jugating your personal power to those hidden forces that would be delighted
to control your destiny for you. If you are wise, you will not surrender your
evolutionary survival so easily. You have all the help you need to succeed, but
humanity must also do its part and become responsible for personal evolu-
tion. 
168  

                                                                         
         Three T racks of T ime
                                       THREE TRACKS OF TIME  
Humanity Facing Three Probable Futures and Three Tracks of Time
   The technical information we have provided on the mechanics of the
Bridge Zone Project serves to illustrate some of the operations of multidimen-
sional physics. We are quite aware that it will be centuries before earthly sci-
entific communities can comprehend some of the dynamics of which we
speak. We provided the information so those of scienti fic persuasion might
begin to realize the sophistication of true spiritual science, so they might be
less prone to dismiss the importance of the information we have given. We
suggest that one use the intuitive senses when trying to understand some of
the more complicated concepts we have presented, as the intuitions are bet-
ter equipped to translate this data into cognition, than are the facilities of the
logical-analytical mind alone. To simplify the meaning of the Bridge Zone
Project, it can be viewed as the vessel through which three probable future
paths of development open to the human population. Between the years
2012-20l7, there will be three distinct time continua into which the human
consciousness can pass to continue its evolutionary journey. These time con-
tinua represent three different tracks of time that different portions of
humanity will follow.  
1. Time Track One-—Voyagers Ascension—D-4 Time Cycle 5532.5-year
    Leap into the Future  
   The first track of time opening to the human population in 2012, and
the most desirable for those who can achieve it, constitutes catching the crest
of the morphogenetic wave between 2012-2017 and ascending into the D-5
time cycle of Tara (or into the higher-dimensional fields of Gaia and the
Meta-galactic Core.) We refer to the individuals who will complete bodily
ascension as the V oyagers. To become a V oyager one must fully assemble the
fifth DNA strand no later than 2022.  After 2022,  this first time track is no
longer an option. In this future one would expect to experience subtle com-
munications with a guardian group of either ET or metaterrestrial nature,
prior to the ascension period.  
  Through this communication one will be taught how to prepare for
their personal ascension, and will be given times and locations as to when
and where the physical event will take place. For individuals who are
ascending but cannot fully transmute the body to do so, preparation for
achieving ascension following natural death will be provided through subtle
communications and spiritual work. Most ascending individuals will be
required to engage in conscious cellular transmutation work, and will be
guided through personal spiritual work, to the appropriate methodology for
their personal development.  
       Individuals who will bodily ascend will at some point in their develop-
ment experience direct physical or conscious etheric contact with a Guardian
169 
                                                                                                                                                      
                                                                                                                           
                                                                                                                       
 

  Time Shift  
group. At the designated time, they will be secretly brought to the location
from which they will ascend. Some will be taken, via various portal routes,
into the Halls of Amenti. They will be led into the Halls and assisted in
transmuting their bodies into light (which constitutes raising the pulsation
rhythm of particles in the body and consciousness). As light, they will pass
their consciousness into the Sphere of Amenti and through the portals of the
Halls of Amenti, they will embody the frequencies of the Blue Flame Staff of
Amenti within their consciousness and morphogenetic field, and pass into
Tara. Once transferred to Tara, such individuals will then have the pulsation
rate of their consciousness slowed to D-5 frequency, and they will find them-
selves re-manifest in a less dense, more perfected version of their body. They
will appear in one of several receiving stations on Tara, set up for this pur-
pose, and will be met by greeters appointed by the Priests of Ur and Mu on
Tara. The greeters will escort them to one of several residential learning cen-
ters, appropriate to the personal level of development, and they will be pro-
vided with all necessities.  
    Couples or groups who ascend together will be able to remain together if
they so choose. For a time the V oyagers will be offered classes through which
they can acclimate to their new reality, and will then be offered communal
residence or will be hosted by private Taran families who will provide lodg-
ing, sustenance and love. Memory of multidimensional experience will be
fully returned, and the V oyagers will have the opportunity to commune with
soul friends and family whom they had forgotten in earthly life. V oyagers will
learn to integrate themselves as time travelers, into a culture that exists about
5532.5 years in the future of present day Earth. This culture is built upon the
principles of the Law of One, and love, brotherhood, freedom, health, spiri-
tual at-one-ment and joy are the foundations upon which this society is built.
It is well worth the V oyage for those who can achieve ascension.  
    Some who are on the ascension time track will not have the full fifth
strand of  DNA assembled but will be close to this 5-accretion level. They will
be unable to pass directly through the Halls of Amenti portals, so will instead
be guided to Transport locations on Earth where they will be brought upon
interdimensional transit craft and prepared for a journey into space.  
    Some of those on the transports will have their consciousness transferred
into a clone body of their original body form (these clones were prepared in
advance through guardian abduction/visitation encounters). The Guardians
use cloning only in cases of individuals who possess most of the necessary fifth
strand DNA assembly. Guardian cloning is used for individuals who would
have been able to ascend if they had not encountered genetic damage while on
Earth. Cloning is used for near-ascension—level individuals who experienced
irreparable genetic damage due to intruder ET manipulation, birth defects,
accidents or illness suffered on Earth.  
170 
   

                                                                                                                                       
                              Three Tracks of Time  
    Not all individuals taking the Transport ascension route will have their
consciousness transferred into a clone body. Most will simply have their bio-
energetic fields adjusted to facilitate rapid fifth DNA strand building. (Note:
clones created by the Guardian ET groups are expressly for the purpose of facil-
itating human ascensions. These are not to be confused with cloning tactics
used by intruder Dracos-Zeta forces for in filtration into human culture). V oy-
agers on the Transports will be taken into outer space, then through the D-4
Merkaba Field at the center of the Sun and into the Halls of Amenti at the D-
4 level (this is the same ascension path used by souls who die/drop their bodies
and ascend to Tara as soul essence. However, individuals on the Transports will
not be leaving a body behind). The Transport craft will emerge through the
core of Tara’s Sun in D-5, then proceed to landing facilities on Tara. Interdi-
mensional Transport vessels are designed for such solar passage, as they are able
to modulate frequency bands and alter the composition of their structure. Most
human V oyagers will experience a period of deep sleep then a bit of temporary
time disorientation as the Transports encounter the solar passages. Once they
land on Tara, the Transport V oyagers will experience the same orientation
events as those who ascended directly through the Halls of Amenti. All V oy-
agers will have a companion assigned to them following their arrival on Tara.
The companion will assist them in adjusting to the new reality, and will remain
with them until the V oyager has comfortably integrated into Taran culture.
    Some V oyagers, who have fully assembled the sixth DNA  strand and
have reached an accretion level of 6, will have the opportunity to ascend
beyond Tara in HU-2, to Gaia in HU-3 or into the Meta-galactic Core at D-8
and completely leave matter form, the dimensional system and Time Matrix.
This is the path of full mastery. Normally it is available to only the few who are
born into the highest resonating genetic codes. Due to Earth’s upcoming infu-
sion of fifth-dimensional frequency, in the Bridge Zone time track, the fifth
DNA strand assembly will be made available to everyone who works con-
sciously to assimilate the D-5 frequency into the body. Once the fifth DNA
strand is assembled, assembly of the sixth strand begins, and some individuals
will be able to fully assemble the sixth strand between 2012-2017, while the
Halls of Amenti and portals to Tara and Gaia are opened (Gaia’s portals open
for only three days in 2017). Guardians will be available to assist in all ascen-
sion procedures, those leading to Tara and beyond.  
    The V oyagers’  ascension to T ara will be done solely through private,
personal contact. There will be no mass landings of Guardian ships to pick
up intended V oyagers, there will be no public knowledge of the logistic
orchestration of these events. Individuals who are able to participate in this
activity will be contacted privately and secretly guided to the appropriate
location, just prior to leaving. Publicly conducting such activities would
serve only to cause major chaos within your social orders, not to mention
171 
                                                                                                      
                                                                                
                                                                                                                    
       

       Time Shift  
military interference, so ascensions will remain a closely guarded covert
guardian activity.  
       We present this material now to assist potential V oyagers in remembering
their soul agreements to participate in these activities. Those who are
intended to ascend can find this information through working directly with
their own spiritual identities. Even if you do not consciously remember such
soul agreements, you will feel a certain way about the ascension option when
confronted with this material. If the path of ascension is the right one for
you, you will sense this, and find your soul-self awareness guiding you to the
appropriate preparatory procedures. The ascension path is not something the
Guardians have made happen for you, it is the natural path of your personal
soul evolution. The Guardians do not control the ascension process-—they
simply facilitate humans and the souls and over-souls of humans who are
                  ready for this natural evolutionary step.  
                       2. Time Track Two—Phantom Earth Descending Planet—D-3 Time  
        Cycle Returning to the Present  
         The second track of time opening to the human population in 2017 is
that of the natural procession through the half-point, in which Earth returns
to the D-3 time cycle following 2017. If the Bridge Zone Project is successful,
the Earth that will return to the D-3 time cycle will be the “phantom Earth,”
the remaining particles of Earth’s body that were unable to transmute to
higher accretion levels. This is the least-favorable option available to
humanity, as this is the future in which humanity falls under the covert con-
trol of the Dracos-Zeta Resistance. Humans who will see this future after
2012 will be those who have not assembled their DNA to at least the fourth
strand by 2012.  
     On August 12th, 2003 the Dracos-Zeta Resistance plan to motivate cer-
tain factions of the Interior Government to orchestrate another experiment
similar to those of the Montauk Project of 1983 and the Philadelphia Experi-
ment of 1943. The Interior government will be led to believe this project is
for the bene fit of humankind, that it will stop Earth changes from occurring
in 2012.  
    T o those of the Interior Government who may be reading this material,
please heed this warning:  You are being tricked and used as pawns by the Dracos-
Zeta Resistance. They are planning to use you to orchestrate a covert take-
over, through which you, the populations and the Earth will be placed under
subliminal, bio-neurological Resistance control. If you allow this experiment
to take place, you will ensure that the populations remaining in the D-3 time
track will fall under Dracos-Zeta Resistance Frequency Fence and Holo-
graphic Insert control. You can stop them from putting the Frequency Fence
in place if you refuse to participate in this experiment. Stop “buying into the
lies” and false promises of the Dracos-Zeta Resistance. If not for the sake of
your planet or your people, then at least for the sake of your own personal
172 
  
 

                                                                                  
                                                                                 Three Tracks of Time
safety. Rethink your positions in relation to the Resistance and redirect your
course of action. There is still time left to shift the fate of the D-3 time con-
tinuum. If the Dracos-Zeta plan is not stopped in 2003, they will begin
broadcasting the EM pulses of the Frequency Fence in 2004 and beam in
Holographic Inserts by 2006. People who do not have a minimum of 3.75-
accretion level, (3.75-accretion level constitutes full assembly of the third
DNA strand and 75% of the fourth strand), will fall under the bio-neurologi-
cal block of the Frequency Fence and will become subliminally controlled
and directed by the Dracos-Zeta Resistance. This includes those of you in
the Interior Government who are foolish enough to believe these EBEs are
your allies. No one will know they are being controlled. Those under the
new Frequency Fence will become cut off from their personal intuitive senses
and organic connection to their soul matrix. They will be unable to further
assemble the DNA strands, and thus will not be able to participate in acceler-
ated evolution and the coming ascension opportunity. The EBEs will offer a
new belief system of a religious nature that will teach subservience to a higher
order of spiritual hierarchy, which will become the belief catalyst for the
“New World Order” of covert control and dominion foretold in your Biblical
stories.  
    When the phantom Earth enters the 2012-2017 period, there will be
geographical and climatic changes on Earth, the degree of which we cannot
fully foresee. The severity of such changes will depend completely upon how
the Earth’s grid reacts to the frequency disruptions of the Frequency Fence. It
is the Frequency Fence that will be primarily responsible for causing severe
Earth changes, so if the 2003 infiltration is stopped, the severity of potential
Earth changes between 2012-2017 can be signi ficantly reduced.  
    What do you think might happen to your nuclear weapons and reactors if
such Earth changes take place? It is time your governments began consider-
ing these issues. If these events go unchecked, and the Frequency Fence plan
is not diverted, it is presently estimated that about 40% of Earth’s surface will
be heavily affected by these changes, 15% of this 40% taking place within
the territories belonging to the USA. These estimates may change, depend-
ing up how this Earth drama unfolds between now and 2012. Needless to say,
the cultures of Earth’s D-3 time cycle would be adversely affected. The popu-
lations surviving such events would remain under covert Dracos-Zeta Resis-
tance control, unaware of the truth that had caused them such suffering. We
reiterate: These events can still be changed, before 2003, if the Interior Gov-
ernment changes its agreements with the Resistance forces.  
    There is a tentative plan by the Dracos-Zeta Resistance to stage a public
landing in 2001, after allowing bits of information concerning their presence
to reach the general public. They intend to send their Rutilia operatives
(Zeta-Dracos hybrids that resemble Zeta Greys, called EBEs by the covert
173 
                                                                                                                  
                                                                                                                 
                                                                                                            

Time Shift  
government) to members of the Interior Government, posing as emissaries.
They will offer technology and friendship.  
    Do not trust them . We implore the Interior Government on Earth to
refuse any and all dealings with these beings, for they are not your allies nor
friends. They are attempting to pull a covert “Trojan Horse” stunt on you.
This can succeed only if you “open the gates,” enter agreements with them
and allow them to convince you to orchestrate experiments, the conse-
quences of which you do not understand. The Bridge Zone Project will
remain operable regardless of the choices of the Interior Government.
Humans are advised to begin working with the higher-chakra centers to
accelerate the assembly and alignment of the third and fourth DNA strands
before 2004. If the Resistance is successful in orchestrating the Frequency
Fence in 2004, humans whose DNA has not reached the 3.75-accretion level
will be susceptible to the perceptual distortions caused by the Frequency
Fence. You can all learn to protect yourselves from this manipulation if you
take responsibility for working with your bio-energetic system to accelerate
DNA assembly.  
    Reach for spiritual integration with your soul identity while it is easy to
do so, for if you begin this integration process now (by assembling DNA
strands 3 and 4), it will completely protect you from the Frequency Fence.
   If you fall under Dracos-Zeta control, you will continue to evolve as
souls upon a Descending Planet. You will not consciously realize that you are
being controlled and subliminally manipulated. Experientially those who are
under Frequency Fence control will be unable to perceive the effects of the
multidimensional changes taking place between 2012-2017.  
    If the Earth changes meet or exceed the damage we have estimated,
human culture will be dealt a severe blow and your social, political and eco-
nomic structures will be unable to easily recuperate from these events. If we
are successful in convincing the Interior Government to stop negotiations
with the Dracos-Zeta Resistance and the experiment of 2003 does not take
place, a different reality picture will be perceived by those remaining in the
D-3 time cycle. Localized grid imbalances will most likely still occur, and cli-
matic deviations will continue to accelerate until 2017. Your primary social
structures will remain intact, but national disaster relief funds and insurance
organizations may collapse due to an overabundance of claims and needed
expenditure. If the Resistance is unable to employ the Frequency Fence by
2004, which they cannot do if the 2003 experiment does not take place, they
will have little recourse. As long as the Interior Government refuses dealings
with the Resistance, the Resistance will be unable to orchestrate a full infil-
tration into human society.  
    Once the Earth grid passes through 2017 without the complications of
the Frequency Fence, and the primary vulnerability of the portal structure
ebbs, Guardian Visitors will be able to enforce a ban on Dracos-Zeta presence
174 

                                                                                    Three Tracks of Time
and these intruders will leave. Your government systems will still evolve
under the inﬂuence of the human Interior Government. Guardian Visitors
will again attempt to make contact with this covert organization, in order to
establish public contact procedures through which human social conscience
and order can be redirected toward peaceful evolution. Humans remaining
in the D-3 time track will still find themselves evolving on a Descending
Planet and the opportunity to rapidly evolve the fifth DNA strand will have
passed, as the phantom Earth will not receive the full infusion of D-5 fre-
quency.  
    Y ou will reincarnate on this Descending Planet until you can assemble
the third through fifth DNA strands, which is a slow process that takes
numerous lifetimes, except during the acceleration opportunity presented in
the ascension cycle. If you die after  2022  without the D-4 and D-5 frequency
patterns assembled in your personal morphogenetic field, reincarnation in
HU-1 will be mandatory. This is simply the nature of the energy dynamics
involved in soul evolution. While evolving on a Descending Planet it is very
important for individuals to have conscious knowledge of ascension mechan-
ics, for the opportunity of spontaneous mass ascension is no longer an option.
Guardian Visitors will assist in keeping this knowledge alive and available to
humans remaining on phantom Earth in the D-3 time cycle. We pray that
each individual can be reached with this message, so the opportunity of
ascension and freedom is not lost to your present identity. If the 2003 experi-
ment and the Dracos-Zeta Frequency Fence can be averted, those in the D-3
time cycle will follow a different path of evolution than humans in the Bridge
Zone and ascension time cycles. They will have the opportunity to evolve
more slowly, yet still have the option of free will and more open contact with
guardian races. The severity of Earth changes during the 2012 —2017 transi-
tions will be greatly reduced.  
    If the Dracos-Zeta Resistance is successful in 2003, life in D-3 will con-
tinue under their covert dominion and Earth changes will take place between
2012 —2017. Once D-3 Earth is under Resistance Frequency Fence control,
the Dracos-Zeta Resistance will be motivated to protect their “vested inter-
ests” on Earth from guardian tampering. If the Resistance gains leverage and
confidence through successfully orchestrating the Frequency Fence, it will be
very difficult for the Guardians to enforce a ban on them without direct mili-
tary confrontation. Such a “Star Wars” confrontation between Resistance
and guardian forces would have further catastrophic consequences for D-3
Earth, and it has not been decided by the guardian legions whether such
intervention would be conducted.  
    The Guardians are taking a “let's wait and see what happens” approach to
this subject. The Guardians can only protect humanity from the conse-
quences of its choices for so long, after which point full responsibility for per-
sonal evolution must be returned to the human race. The opportunity to
175 
                                                                                                                           
                                                                                                                      
          

  Time Shift  
create self-protection is now being offered through the Guardians’ attempts
to educate humanity. If this opportunity is ignored, the humans remaining in
the D-3 time cycle will have to accept responsibility for their selected igno-
rance and face the consequences of covert Dracos-Zeta rule. Further guardian
intervention would only be considered if the D-3 populations made a show of
effort to take responsibility and make the needed changes prior to 2017. The
Guardians are willing to help those who are willing to help themselves, but
have little patience left for those who refuse to learn, grow and become
responsible for their choices. If the Bridge Zone Project is not successful,
Earth will remain in HU-1 under Dracos-Zeta rule, and your incarnational
destiny on HU-1 Earth will meet a premature end in 2976 AD. The majority
of the human population can avoid these less favorable futures by seizing the
opportunity of accelerated evolution represented by the Bridge Zone Project.
3. Time T rack Three—the Bridge Zone—D-3.5 Time Cycle 2213-year
     Leap into the Future  
     The third time track available to humanity in 2017 is that leading into
the Bridge Zone. Individuals having a 4.5-accretion level/assembly of the full
fourth DNA strand and half of the fifth will enter the Bridge Zone time contin-
uum. We need a critical mass of people to reach 4.5 accretion before 2012 in
order for the Earth’s grid to raise high enough in speed to enter the Bridge Zone
in 2012. The accretion level of Earth is being continually measured and moni-
tored, and as of this writing (August 1998) things look quite promising. Recent
events involving the Sphere of Amenti have given us much encouragement for
the success of the Bridge Zone Project, and we are still on schedule for the
opening of the Halls of Amenti in 20I2. The transition of Earth moving into
the Bridge Zone began in 1997 as we infused Earth’s grid with UHF energy to
assist in raising the particle pulsation rate of  Earth’s core. The speed of Earth’s
core particles will be progressively raised between now and 2012.  
    As Earth progressively moves closer to 2012, a subtle division will begin
to appear within the populations of Earth. Those with higher accretion rates
will progressively find themselves surrounded by others of similar accretion
levels, and those with low accretion rates will likewise group. You will see a
more apparent division between what you consider the “light and dark
forces” moving within your populations. You may see extremes of this condi-
tion, especially in geological areas in proximity to the seven major Earth vor-
 tices/chakras (we will discuss the V ortices in following pages).    
         Small-scale wars may break out in some areas, motivated covertly by vis-
iting members of the Ancient Anunnaki Resistance, who entered orbit
around Earth in D-4 in 1997, with the intention of amplifying the potentials
of Earth changes to see the downfall of human culture. The Anunnaki Resis-
tance will not directly intervene, nor do they work with the Dracos-Zeta
Resistance, they are simply here to see Earth purged of what they consider
176 
 

                                                                               
                                                                                  Three Tracks of Time
the “cosmic virus” of the human race. They will motivate conﬂict and per-
sonal and collective strife by attempting to manipulate people from the D-4
astral plane. Their purpose is to increase grid instability, as they know this
will amplify any Earth changes that may occur. They are not as highly moti-
vated as the Dracos-Zeta Resistance, and will not attempt direct interference
in Earth affairs, so as to avoid direct con ﬂict with the Sirian Council, their
Council Loyalist Anunnaki Brothers and the other Guardian groups from
HU-2 and HU-3. They are simply game players who will try to tip the bal-
ances of the unfolding Earth drama in the favor of human extinction.  
    The only people who will be susceptible to Anunnaki Resistance
manipulation will be those who have low accretion levels and who have not
learned to put protective energetic barriers around the astral identity. Any-
one working consciously and sincerely to integrate the soul identity will have
protection from Anunnaki Resistance manipulation. Humans with high
accretion levels will be called upon to assist the guardian races in building a
frequency block in D-4 to protect Earth's major portals/vortices from Anun-
naki Resistance energy transmissions. Guardians from the Andromeda galaxy
presently have Earth’s vortices sealed under a protective D-4 frequency seal,
but in the event that the Anunnaki Resistance manage to decode the fre-
quency seal co-ordinates (which they occasionally do, requiring repeated
guardian resealing of the vortices), the Andromies will need human help to
ground a more sophisticated vortex frequency seal. Human Light-workers
involved with the “Portal Project” are presently on stand-by, waiting for the
time when they will be called into service. Human Light-workers will also
assist in keeping the portal regions balanced on Earth between 2012 —2022.                                                    
                                                ET Inﬂuences 
    Presently the human collective moves together toward the three diver-
gent tracks of time. By 2012 the divisions within the populations will be set,
as the three groups, with three different accretion levels, begin to move into
their appropriate track of time. Those on the ascension track will have
already made preparations in their DNA and have a more conscious under-
standing of the process with which they are involved. Those on the
Descending Planet time track will proceed with “business as usual”, unaware
of the changes taking place around them. If the Dracos-Zeta Frequency
Fence is successful, the “peripheral blindness” of those on the Descending
Planet track will be amplified.  
    There may exaggerated movements from within the Interior Govern-
ment to ban, discredit, confuse and black out from public view, information
pertaining to ascension mechanics, advanced multidimensional technologies
and the truth of Visitor agendas. These tactics are already being used to keep
the general populations unaware of what is taking place regarding ET and
metaterrestrial contact. You will see counter-movements emerging through
177 
                                                                                                                  
                                                                                                        
           
                                                                               

  Time Shift  
which genuine information is made available to those who will listen. Many
of the traditional religious organizations will be used as dis-information vehi-
cles, through which the public is taught to view the new information as
“evil.” This tactic is orchestrated through Zeta-human in filtrates presently
working within various organizations. You will see many distraction tactics
emerging, through which public attention is purposely and covertly directed
away from the issues of spiritual development and into fear-base, conflict-
laden agendas. The threats of economic disaster, war and famine, as well as
menial issues will all be used, through covertly manipulated media propa-
ganda, to divert public attention away from the real issues taking place. The
Zetas are expert propagandists, and subliminal manipulators, and are quite
accustomed to subliminally in ﬂuencing the unsuspecting minds of humans in
key positions to carry out their bidding.  
    The propaganda program, which has convinced the majorities that ET
presence is not real, has been in effect since the 1940’s, and you will see a con-
tinuation and acceleration of this propaganda until about 2001, when the
program will be changed to begin preparing the public for intended EBE con-
tact. When information about the possible validity of ET presence begins to
make it into public view, the Dracos-Zeta Resistance will present themselves
as Guardians and attempt to make guardian groups appear as intruders. The
Resistance may orchestrate a mass landing in 2001, but only if they are confi-
dent that they will succeed in motivating human Interior Government to
conduct the 2003 experiment. If by 2001, the Resistance fears their Fre-
quency Fence plan will not succeed, they will not stage a landing. They will
still work to instigate the 2003 experiment, and may increase their abduc-
tions within the general populace, making it appear as though guardian
groups are responsible, in order to trick the Interior Government to continue
with the 2003 experiment. The shift in the perspective of the propaganda
program will take place between 2001-2003, if it takes place at all.  
    If news validating the reality of visiting ET presence reaches public dis-
tribution networks by 2001 you can be sure the Dracos-Zeta Frequency Fence
plan is still in operation and that the Interior Government continues to work
with the Resistance. If a mass level, public landing takes place any time
between 2001 —2003, realize these are not friendly Visitors regardless of what
they may claim.  
    In the event that the Frequency Fence plan remains operational and
the Resistance schedules its mass landing, several guardian ET groups may
create mass sightings, to increase public awareness of the reality of ET pres-
ence. They will not conduct a mass landing or initiate physical contact on a
public or governmental level. If Guardians deem such “ ﬂy-by” tactics neces-
sary, these events may take place anywhere between 2000 —2003. The pur-
pose of such an event will be to warn humans who are aware of these hidden
agendas that the Resistance still plans in filtration. If the guardian “ ﬂy-by’s”
178 
 

                                                                                       
                                                                                    Three Tracks of Time
occur, this is intended as a sign for the populations to begin preparation for
Earth changes, because if the Frequency Fence is employed, some degree of
tectonic shifting will result.  
                                                    Be aware!  
    If you begin to experience mass “ ﬂy-by’s” between 2000 —2003, you need
to make provisions for coming climatic and Earth changes. In this event the
Guardians will provide information on “safe space” locations through their
private human contacts. If the Resistance believes its in filtration plan will not succeed, they will
not land between 2001 —2003, and the Guardians will not conduct mass “ ﬂy
by’s.” The old propaganda program of  blocking public awareness of ET pres-
ence will resume and the Interior Government will continue to distract pub-
lic attention from this issue so as to retain control of the populations. If the
2003 experiment is stopped (the Resistance needs the cooperation of the
Interior Government for this experiment to be successful) there will still be
three tracks of time facing the human populace.  
    In the D-3 time cycle Descending Planet track, the Dracos-Resistance
will leave of their own accord, knowing they cannot claim dominion over
human populations and that after 2017 Guardians can enforce a ban on Dra-
cos-Zeta presence. If the Earth’s grid is balanced in 2012, the Dracos-Zeta
Resistance and the Anunnaki Resistance will leave. Earth’s populations can
then focus upon the primary issues at hand, assisting the Guardians to keep
Earth’s grid balanced and accelerating personal evolution in preparation for
the opening of the Halls of Amenti between 2012 —2022.  
    If  92% of Earth’ s populations could reach a 4.5-accretion level by 2012,
no one would take the second track of time back into the D-3 time cycle of
the Descending Earth. This is not likely, however, so as it stands some of the
Earth’s populations will indeed return to the D-3 continuum. These are the
only individuals susceptible to the Dracos-Zeta Frequency Fence, and we
hope that the Interior Government will stop the 2003 experiment so these
individuals do not have to contend with the Frequency Fence and resulting
changes of the D-3 Earth. If humans begin working now to consciously
assemble DNA and increase accretion level, there is still time to become
immune to that intended Frequency Fence and prepare to leave the D-3 con-
tinuum. If you can achieve a 4.5-accretion level by 2012 you will automati-
cally end up in the Bridge Zone continuum in 2017. As long as 8% of Earth’s
populations reach a 5-accretion level, 144,000 people reach a 6-accretion
level, and about 40% reach a 4.5 level, the Bridge Zone Project will be suc-
cesfully.  
    In approaching the Bridge Zone time track, humans will perceive a
growing gap between the populations following old, fear-based agendas and
those following the path of personal enlightenment between 1998-2012.
Those on the Bridge Zone path will begin to bond together in a global net-
179 
                                                                                                                
                                                                                                         
                                                                                                                    

Time Shift  
work of enlightenment, doing personal and planetary energy healing work
and preparation for Stellar Activations. The schedule of events leading up to
the opening of the Halls of Amenti will continue to unfold up to 2012, when
Earth’s grid begins to merge with Tara’s and the Halls of Amenti begin to
open.  
      As this schedule of events proceeds, the population divisions will begin
to fall out of range of each other’s perceptions. Those headed to the Bridge
Zone will experience progressively more awareness of multidimensional real-
ity, personal purpose and incarnational memory, as the Sphere of Amenti
progressively releases more of the race memory back into the Earth’s grid.
That multidimensional memory will be available to everyone, those who will
access this memory will be people who have the genetic ability to pull higher
frequency into their operational genetic codes. The more DNA you assemble,
the higher your accretion level, the more information and memory you will
be able to draw from the Earth’s grid. The consciousness of the accelerating
individuals will rapidly expand, while the awareness of the people entering
the Descending Planet will remain about the same.  
      Between 1998 and 2012, these two groups of people will progressively
become more “invisible” to each other, as the procession of their lives moves
in opposite directions. There will appear to be natural sequences of events
that occur as individuals of lower accretion begin to move out of the lives of
those of higher accretion levels, to be replaced by new individuals who have
a higher accretion level. Those of lower accretion levels will find themselves
more and more in like company.  
      The progressive separation of populations will take place as the particles
which compose the bodies and consciousness of people with higher accre-
tion/DNA strand assembly levels begin to pulsate at progressively faster
rhythms, moving people of higher and lower accretion levels farther and far-
ther out of each others perceptual range. During the coming transitions, par-
ticle fields are separating. The bodies and consciousness of people are made of
particles, thus humanity will also experience separation of its peoples into
those with faster and slower-particle pulsation rhythms.  
     All humans will experience Earth’s temporary shift into the D-4 time
cycle and the Stellar Activations that create this shift. Humans with lower
accretion levels will have difficulty assimilating the frequencies of the Stellar
Activations. The Stellar Activations will create time acceleration for the
people of Earth. This acceleration can be used to advance the evolutionary
blueprint through consciously assimilating these energies into the body, in
order to create greater health, vitality, harmony and awareness. If the new
frequencies are not assimilated into the body, the time acceleration will apply
to the degeneration of the body and consciousness and the manifestation of
disharmony and disease.  
180 
 

                                                                            
                                                                                  Three Tracks of Time
     The Bridge Zone populations will accelerate their ability to access
guardian information, and some will become involved in subtle communica-
tion with Guardian groups. In 2012, when the more intensive changes begin,
localized climatic deviations and smaller Earth changes may arise, and the
Bridge Zone people will pull together to help each other through these
changes. Between 2009 —20l7 those in the Bridge Zone will begin to see cer-
tain public organizations, businesses and institutions either reach their natu-
ral ends or begin to take their operations in a more enlightened direction.
Those on the Descending Planet will not perceive these changes. Some of
the Bridge Zone people will become aware that the Inner Earth portals have
opened and will have invitation to explore those realms. Some of the struc-
tures of the Inner Earth geography will begin to emerge on the Bridge Zone
Earth, new islands will be discovered on Earth during this transition period,
and new organizations of spiritual and social order will begin to emerge.
Some groups of individuals will have open contact with various guardian ET
and metaterrestrial Visitors. The particle base of both the Descending Earth
and the Bridge Zone Earth will enter the D-4 time cycle between 20l2 —2017.
The infusions of D-5 through D-9 energy will enter the grid of Bridge Zone
Earth, and the spontaneous assembly of the fifth DNA strand imprint will
begin within the populations whose accretion level at 2012 placed them in
the pulsation rhythms of the Bridge Zone time track. The two Earth’s will co-
exist simultaneously within the D-4 time cycle between 2012 and 2017 and
each of the two groups of people will simultaneously perceive two different
sets of events.  
      In order to comprehend the nature of these changes, one must realize
that the energy dynamics taking place involve Earth’s particle base being sepa-
rated into two different rhythms of particle pulsation, and the particle sub-
stance out of which human bodies and consciousness are composed will also
experience such a separation.    
      In 2017 human populations will completely separate into two groups,
each perceiving a different set of events. These events will take place in two
separate fields of particle pulsation rhythm. It will be as if part of the popula-
tion “switched the channel on the television set of manifest events,” one
group remains watching the old channel, and the other group switches the
channel of perception to a new station.   
          The particle pulsation rhythm of the entire Earth will temporarily be
raised to the rhythm of D-4 frequencies between 5/5/2000 and 1/2012. The
Guardians will infuse Earth’s particle base with UHF D-4 energy transmis-
sions until 5/5/2000. The portion of Earth’s particle base that can hold this
frequency pattern will increase to a higher D-4 pulsation rate and begin the
Stellar Activation cycle, while the portions of Earth’s particle base that can-
not hold this frequency will remain at the lower D-4 rate of pulsation.
181 
                                                                                                                                                                                                                  
                                                                                               

Time Shift  
    In the Bridge Zone particle base, the angular rotation of particle spin will
be altered by the Guardians, in order for it to be transferred into the pulsation
rhythms of the Bridge Zone-Agartha time continuum in 2017. The angular
rotation of particle spin of Earth’s higher vibrating particle base will be
shifted 22.5° in reverse from the angle of particle rotation of Earth's lower
vibrating particle base. This separation of particle pulsation rhythms will
reach completion in 2017, just when Earth’s grid is in full alignment with
that of Tara and the Holographic Beam passes through the Photon Belt into
direct alignment with Earth’s seventh vortex/chakra. As the energies of the
Holographic Beam pass into the Earth’s bio-energetic field in 2017, the
higher and lower vibrating particle bases of Earth will completely separate.
The lower vibrating particle base will rapidly drop in vibration and return to
the pulsation rhythm of the D-3 time continuum. The higher vibrating par-
ticle base will complete its 22.5° reverse shift in angular rotation of particle
spin and fix its pulsation rhythm at the 3.5-accretion level of the Bridge
Zone-Agartha time continuum.  
    When this separation transition completes in 2017, the populations will
find themselves permanently divided into two separate groups.  
                                   
                                               Perceptual Stations 
1.  Group One — Descending Planet Perceptual Station  
     Humans with lower accretion levels will perceive none of the multidi-
mensional activity that is taking place. As long as the Frequency Fence is
not operational, they will not experience massive Earth changes, but some
localized shifting may occur. They will experience a three-day period of ten-
sion, fatigue and accelerated atmospheric pressure and a temporary disruption
of the function of electrical apparatus at the height of the separation from
Earth’s higher vibrating grid in  2017. Scientists may detect odd variations in
Earth’s magnetic fields and a sudden, unexplainable increase in gamma ray
activity. Solar storms and ﬂare activity will appear to increase for several
months, then rapidly return to normal appearance. At the height of the sepa-
ration, a phenomenon that resembles a prolonged, spontaneous solar eclipse
may occur, depending upon the stability of Earth’s bio-energetic grid.  
    The most notable occurrence will be that numerous groups of people will
seem to have vanished from the Earth without a trace. There will be no
explanation for these vanishings in conventional terms. For Earth in the D-3
continuum, little will have appeared to change, and populations will move
forth into their D-3 evolution. The Halls of Amenti will be closed to them,
as will the portals to the Inner Earth. They will experience massive Earth
changes only in the event that the Frequency Fence is operational.  
    In either case, Guardians will assist in realigning the planetary grids and
returning Earth to stability. In the event that the Frequency Fence is opera-
tional, the D-3 populations will be totally unaware of the changes taking
182 
  
 

                                                                                 
                                                                                     Three Tracks of Time
place, including the vanishings, as Holographic Inserts will be used to block
perception of these events. Only the Earth changes would be apparent to the
D-3 populations. Descending Planet populations will remain in the D-3 time
continuum and the opportunity for mass ascension will no longer be possible
in the future. Ascension of individuals will have to be orchestrated through
Host Matrix Transplants. If the Frequency Fence becomes operational in
2004, they will see Earth changes and will be under covert Dracos-Zeta Resis-
tance mind control. If not, they will slowly evolve and reincarnate toward
building the fourth and fifth DNA strands through Host Matrix assistance.  
2.  Group Two — Bridge Zone Perceptual Station  
    The populations who shift into the Bridge Zone will experience more
obvious phenomena of change as the two particle bases of Earth complete
their 2017 separation. Many structures of inorganic substance, composed of
lower-vibrating particles, will simply appear to vanish, as well as populations
having lower accretion levels. New island land masses will have appeared to
emerge out of the oceans, seemingly over night. New passageways into the
Earth will be found that lead into the Inner Earth territories. The most amaz-
ing phenomenon to manifest in the Bridge Zone will be the sudden appear-
ance of buildings, roads and other structures of civilization that one did not
remember having existed prior to this shift.  
    Earth’ s Bridge Zone populations will find themselves in old familiar terri-
tories having the new twist of people, organizations, landscapes and social
structures that resemble what was, but which are operating at a higher level
of vibration/pulsation and enlightenment. In 2017, portions of the Inner
Earth, Agartha civilizations will suddenly be visible, and it will seem as if
they had always been there. This may create a bit of temporary time-space
and memory disorientation to the populations of the Bridge Zone. During
the height of the separation in 2017, the Bridge Zone populations will also
experience a three-day period of tension and sensation of atmospheric pres-
sure, and they may perceive the appearance of very bright moon halos or two
moons in the sky during this three-day period. For this reason we refer to the
Bridge Zone time continuum as The Path of the Night of the Two Moons . If
you perceive these lunar effects in 2017, you will know you have entered the
Bridge Zone time continuum.  
    In the Bridge Zone, more open relations with Guardian V isitors will
begin, and humanity will continue to evolve along a more enlightened,
accelerated path. New fuel sources, such as photonic energy containment,
will be discovered as well as many new technologies based upon light, sound
and Keylontic science. As the Bridge Zone Earth will receive the infusion of
D-5 through D-9 energy during the 2012 —20l7 period, the populations will
have the opportunity to assemble the fifth DNA strand to become V oyagers
and enter the path of time travel/ascension to Tara. Some will also have the
opportunity to assemble DNA beyond the fifth strand and enter the acceler-    
183                                                                                                                        
                                                                                                                  
                                                                                                           

Time Shift  
ated path of mastery to ascend to Gaia or the Meta-Galactic Core. Bridge
Zone populations will be completely free from intruding ET Visitor manipu-
lation. Perceptually the sensation of lightness, or less weight, will be felt in
the atmosphere and within the body and a greater feeling of peace, optimism
and personal vibrancy will be experienced. Higher chakra centers in the
human bio-energetic system will come into activation and the conscious
integration of soul awareness will accelerate.  
    W e have undertaken great labors to provide you with this detailed and
often complex information concerning the changes your race will soon
encounter. We wanted you to be prepared. We wanted you to know what is
going on so you can begin to make good, conscious choices now, to ensure
your highest evolutionary potential.  
    Knowledge is power; thus we have given the gift of power to those who
care enough to use this gift wisely.  
    Now that we have provided you with the basic foundations of knowl-
edge concerning the coming changes Earth and the human populations will
face, our primary interest is to prepare you for the opportunity of the opening
of the Halls of Amenti. We will give you an idea of what to expect and
when, and how each of you can best prepare for the future you prefer to expe-
rience. As previously mentioned, there is a schedule of events that the
Guardians have to follow to ensure the opening of the Halls of Amenti. Tim-
ing of these events is crucial to the success of Amenti opening and so far
everything is right on schedule.  
      
  
184