53                                                                                                             
                                                                                                                     

  
   The Third Seeding  
their own energy system through the height of the dimensional blending,
then when the natural cycle of dimensional blend reached its close, the Blue
Flame would be returned to the Sphere of Amenti at Earth's core and the
Halls of Amenti —the ascension portals to Tara —would open to those on the
planet who had assembled the fifth DNA strand and could pass through the
Blue Flame. For people who had not yet assembled the fifth strand, much
information on how to go about accelerating this process would be made
available, as the memory banks of the race would be restored. As long as the
Blue Flame remained within the Sphere of Amenti at Earth's core, the ascen-
sion portals to Tara would remain open to the races, allowing them to evolve
rapidly and complete their tour of incarnational duty on Earth. The souls
trapped within the D-4 astral and D-2 elemental kingdoms could also com-
   plete their evolution and ascend.  
       The individuals who would be responsible for holding the fifth-dimen-
sional frequency within their bio-energetic field during the time of transition
are called Keepers of the Flame,  and they would, over a period of years, dis-
pense the fifth-dimensional frequencies throughout large numbers of the pop-
ulation, assisting the populace to assemble the fifth DNA strand, expand
their consciousness and transmute their bodies, so portions of the population
could “catch the morphogenetic wave” (discussed later) and pass through the
Halls of Amenti on the wave, while the dimensional blend was still in effect.
Once the cycle of dimensional blending was through, the Flame would be
placed back in the Sphere and the remaining populations would continue to
evolve on Earth until the next morphogenetic wave. The people who were
able to catch the first wave would find themselves teleported into the future,
where they would appear on the Taran land mass that was once called the
continent of Mu. This Taran location represents the primary reality of Earth
as it exists about 2,500 years in the future —the version of Earth whose grid
has completed its merger with Tara. This path of accelerated evolution con-
stitutes leaping past 2,500 years of evolution within Earth's present time con-
tinuum, and represents literal, biological time travel into the future. With the
opening or “sparking” of the Arc of the Covenant, this path of accelerated
   evolution would become available to some humans on Earth.  
       The Keepers of the Flame would be responsible for assisting people who
were ready to take this morphogenetic wave voyage in preparing their bodies
and consciousness for this transition. The Keepers of the Flame would receive
their infusion of D-5 frequency from one primary individual who had the
genetic code that would allow the Flame to be fully embodied as it passed
through the Arc of the Covenant. That person is called the Flame Bearer or
the Staff Holder.  The Flame Bearer would have to activate the 12-strand
DNA package within the body before being able to embody the Flame. This
person would incarnate with a support team of six fully activated 12-strand
avatars (souls from the fourth Harmonic Universe), who would raise the