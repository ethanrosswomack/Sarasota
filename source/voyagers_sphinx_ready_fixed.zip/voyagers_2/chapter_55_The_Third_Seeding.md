55 
                                                                                                                
                                                                                                                      

The Third Seeding  
the Lamanians and Ur-Antrians, forming a new guardian race through incar-
nating souls via the Melchizedek Cloister morphogenetic field via the Arc of
the Covenant. The new race was called the Urtites ; they appeared on Earth
about 800,000 years ago and, working with races of the Inner Earth and the
HU-2 Palaidorians, the Urtites established the Priesthood of Ur  on Earth.
The Urtites lived primarily underground and within the Inner Earth civiliza-
tions, serving as guardians of the Arc of the Covenant. When conditions on
    Earth were conducive to supporting mass surface life, the Urtites were given
authority by the HU-2 Sirian Council, Ra Confederacy and Priests of Ur on
Tara, to begin the Third Seeding of the human lineage. Many sub-races and
families emerged through the Urtite genetic strain, as each of the five Clois-
ter races birthed their race line through the Urtite Host Race. The races were
located throughout various regions of the globe, each developing surface cul-
tures from about 750,000 to 75,000 years ago. The Urtite lineage developed
divergent cultures extending from what is now known as Africa, through
regions of East Asia, North and South America, central Europe, Egypt and
into what is now called Iran. Through development of these diversi fied cul-
tures, the Host Race Urtites created a new cradle of civilization through
which the Root Races and their Cloisters could be reseeded on Earth.  
     The Third Seeding of races three, four and five began again via the Arc of
the Covenant, under the direction and through the lineage of the Urtites. The
third race Ur-Antrian Cloister began birthing about 75,000 years ago, their
Lamanian Root Race 73,000 years ago. The Lamanians of the Third Seeding
were called the Lemurians,  and they were seeded on a land mass that existed in
the area now occupied by parts of the Pacific Ocean and also within the region
of the Andes Mountains. The Breanoua Cloister of the fourth race entered
about 72,000 years ago in lands that existed in the area now occupied by parts
of the Atlantic Ocean, and into the territories that became known as Egypt,
followed by their Root Race Atlanians 70,000 years ago. The Atlanians of the
Third Seeding became the Atlanteans.  The fifth race Hibiru Cloister entered
through the Host Matrix of the sixth race Melchizedek Cloister into various
positions throughout the globe, about 68,000 years ago, followed by their Root
Race Ayrians 65,000 years ago. The fifth Root Race Ayrians of the Third Seed-
ing were called the Aryans, concentrations of this race were seeded into
regions near what is now called the Black Sea and in the area of what became
the Carpathian Mountains.  
    The Annu-Melchizedeks were seeded into the Atlantean Root Race-
Egyptian sub-race through the Melchizedek Cloister Host Matrix morphoge-
netic field about 68,000 years ago. The Annu prospered in Atlantis, many
migrating to various parts of the globe and interbreeding with other races.
    The primary concentration of Annu remained in Atlantis, where open lines
 of commerce with their Sirian-Anunnaki forefathers became a standard way