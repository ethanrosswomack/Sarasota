5 Primal Light Fields and the Maharata Current standing-wave frequencies of 
the Density-4, Dimension-12 Pre-matter Hydroplasmic “Liquid-Light” Chris-
tos Fields.  
270 
                                                                                                                                     

                  Shambali, Bhrama and Annu-Melchizedek Races of Inner Earth.
              
            SHAMBALI, BHRAMA, AND ANN-MELCHIZEDEK  
                                      RACES OF INNER EARTH.  
    The two Mixed Cloister races of Inner Earth  with which the Urtite-
Tri-Cloister Maji genome  is combined are races of the Inner Earth regions 
that received genetic enhancement  from the Sirius B Maharaji  blue humans 
following their exile to Inner Earth during the Thousands Years War  of 
846,800 BC  (see Page 43).  Previous to this genetic acceleration, Inner Earth 
Shambali and Bhrama  Mixed Cloister  races had emerged into Inner Earth from 
12-Tribes Seeding-1 during the Electric Wars  of 5,498,000 BC  (see 
Page 18 ). They were originally members of the 12-Strand DNA T emplate 
Christiac Grail Line  Angelic Human Cloister race lines of Seeding-1 . Exiled 
Shambali and Bhrama  races of Seeding-2  integrated  into their related Inner 
Earth cultures exiled from Seeding-1, then received further genetic accelera-
tion from the Maharaji blue human Christiac-Rishic Grail Line race of Sirius 
B. Following this genetic acceleration, which was obtained through consen-
sual intermarrying of family lines from Shambali and Bhrama races with
Maharaji blue human family lines residing in Inner Earth, the Mixed Cloister
Shambali and Bhrama race lines evolved into 24-48 Strand Christiac-Rishic  
DNA Templates. This genetic enhancement allowed them to serve as the
two primary guardian races  for the Crystal Pylon Temples , Halls of 
Amenti and the activated star gate system  of Inner Earth’s Templar ; a posi-
tion they still hold today.    
     The Shambali are  a Melchizedek and Breanoua Mixed Cloister  race, 
plus Maharaji  blue human, and the Bhrama  are a Melchizedek and Ur-
Antrian Mixed Cloister  race, plus Maharaji .  The Shambali inhabit the clois-
tered Shambali-Ionian Islands  and parts of the Inner Earth Agartha conti-
nent called Shamballah . The Bhrama nations are concentrated on the
Agartha continent, which supports various strains of occasionally conflicting
races . Presently the Annu-Melchizedek  Anunnaki-Human Bio-Regenesis 
races, exiled from surface Earth during the Lemurian and Atlantian cata-
clysms of 50,000 BC, 28,000 BC  and 9558 BC,  represent one of the largest 
populations in the Inner Earth territories of Agartha.  Due to the Pleiadian-
Nibiruian Anunnaki Fallen Angelic Legion’s recent refusal  of the Emerald
Covenant , many Annu-Melchizedek races of Inner Earth have joined the 
United Intruder Resistance (UIR)  campaign of overthrowing Emerald 
Covenant races for dominion of the Halls of Amenti  star gates and the terri-
tories  of Inner and surface Earth. The Shambali and Bhrama races of Inner 
Earth and the Palaidorians of Tara are the appointed Azurite Universal Tem-
plar Security Team guardians and Keepers of the Halls of Amenti star gates
and of the natural Universal Star Gates in Density-1 (dimensions1-2-3). 
The Palaidorians of Tara  (see Page 6) have held this Azurite Universal Secu-
rity Contract since the initiation of the Covenant of Palaidor  just prior to 
the 549,998,000 BC Taran cataclysm (see Page 2). The Shambali and 
271 
      
                                                                                                                                                                                                                                                          
                  

  The Angelic Human Heritage and Rainbow Roundtables  
Bhrama  races of Inner Earth were officially entered into the Palaidorian Cov-
enant and Azurite Universal Templar Security Team following their genetic 
acceleration after the Thousand Years War in 846,800 BC. Since this time
the Shambali and Bhrama races of Inner Earth are also referred to as
“Palaidorians ”, just as their Taran Palaidorian elders.    
                          THE THREE PRIMARY URITITE-TRI-CLOISTER MAJI FLAME                                                        
                                            KEEPER HOLY GRAIL LINE   
                                           SEED RACES OF THE PALAIDIA EMPIRES  
         The Emerald Order  Elohei-Elohim Maji DNA Template embodies  the
full spectrum of the  Eckatic Codes , the electro-tonal patterns, or DNA “ Fire 
Letters ”, corresponding to the first level  of individuation from Source, the 
Eckatic Level  of the Energy Matrix. Beings with  Eckatic DNA Templates,
such as the Emerald Order  Urtite-Tri- Cloister Maji, incarnate from the  Eckatic
Level-1  of the Primal Sound Fields ; they are legitimately considered  Level-1
Ascended Masters . Eckatic DNA Coding  allows an embodied being to run 
the Full  Blue-Gold-Violet  “Flame-Tones ” of   the Khundaray Primal Sound 
Currents and all Primal Creation Currents below , through the physical body,
when the Eckatic DNA Codes are activated.  The Emerald Order Elohei-Elo-
him Maji incarnate through a Tri-Cloister genetic template composed of 12-
Tribes  Melchizedek Cloister- “white ”-skinned line,  Breanoua Cloister  “red”
-skinned line and Yunaseti “black”-skinned line, combined with a dominant 
Shambali and recessive Bhrama Mixed Cloister  genome from the Inner 
Earth Palaidorian  races . The Emerald Order Urtite-Tri-Cloister Maji Holy 
Grail line races of Seeding-3 are called the Muarivhia  seed race , sometimes 
referred to as the Mu’a. The Urtite-Tri-Cloister  Emerald Order Maji Chris-
tiac-Rishiac Holy Grail Lines  are called the Keepers of the Blue Flame- Guard-
ians of the Eckatic Codes.” ¹ . The Muarivhia, or Mu’a  Urtite-Tri-Cloister Maji 
Christiac-Rishiac Grail Line has a 43-48 Strand DNA Template ; in their 
present incarnations on Earth, the Mu’a, along with Maji from the  Yu Seed 
Race  line are called Type-1 Indigo Children; the Mu’a are Emerald Order 
MC Indigos .  
     The Emerald Order  Mu’a,  and their ascendant race  lines , are the only 
human races on Earth whose DNA Templates  are imbued with the full spec-
trum of 144 Universal Signet Master Key Codes² corresponding to  Universal 
Star Gates 1 through 12 . The 48-Strand DNA Template Mu ’a races have all 
144 of the 144 Universal Signet Master Key Codes, and all  1728  (144 
Encryption Keys per Gate x Gates 1-12) of the 1728  Universal Encryption
  Key Codes , encoded  in their DNA.  Individuals of Mu’a genetic coding, who 
have a  fully activated 48-Strand DNA Template , are the only individuals on______________________________  
 1.  In ancient Egypt, this coveted Eckatic Maji genetic code was referred to as the  “Code of                                 
        the Blue Nile’’  
  2.   12 Master Keys per Gate  x 12 Universal Star Gates.  
272 
                                                                            
     

              The Three Primary Urtite-Tri--Cloister Maji Flame Keeper Holy Grail Line                                                               
Earth  capable of running  the full “Rainbow Ray Current”  to single-handedly
open the  four Density Levels  of Earth’ s 12 Primary Signet Site  Star Gates. 
They are the only humans on Earth able to individually initiate remote act-
ivation  of 12th Signet Shield, 12th Signet Plate and 12th Templar Cue Site, 
the 12th Signet Set  through which all other Signet Sets  and Earth’ s 12 Tem-
plar Signet Site  star gate opening points are activated and directed.  
   The Gold Order  Seraphei-Seraphim Maji DNA  T emplate embodies the 
full spectrum of the Polaric Codes , the Fire Letters corresponding to the sec-
ond level  of individuation from Source, the Polaric Level  of the Energy 
Matrix. Beings with  Polaric DNA  T emplates , such as the Gold Order  
Urtite-Cloister Maji , incarnate from the  Polaric Level-2  of the Primal
Sound Fields ; they are legitimately considered  Level-2 Ascended Masters . 
Polaric DNA Coding  allows an embodied being to run two-thirds of the 
Khundaray Primal Sound Currents, the  Gold-Violet Flame Tones, and all 
corresponding Primal Creation Currents below , through the physical body, 
when the Polaric DNA Codes are activated.  The Gold Order Seraphei-Sera-
phim Maji incarnate through a Tri-Cloister genetic template composed of 12-
Tribes Melchizedek Cloister- “yellow”-skinned line , Yunaseti Cloister  “yel-
low”-skinned line and  Hibiru “ white”-skinned line, combined with equal 
proportions of the Shambali and Bhrama Mixed Cloister  genome from the 
Inner Earth Palaidorian races . The Gold Order Urtite-Tri-Cloister Maji
Holy Grail line races of Seeding-3 are called the Yu Seed Race . The Urtite-
Tri-Cloister  Gold Order Maji Christiac- Rishiac Holy Grail Lines are called 
the ''Keepers of  the Gold Flame —Guardians of the Polaric Codes ’’3.          
    The Y u  Urtite-Tri-Cloister Maji Christiac-Rishiac Grail Line has a 37-