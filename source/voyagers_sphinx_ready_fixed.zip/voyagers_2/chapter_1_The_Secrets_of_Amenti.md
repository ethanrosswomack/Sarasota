1
   


  
                                                                                                                                                                                                                                                                          
 
The Secrets of Amenti                    
                                                                                                                                                                                                                                                                                                                                             ORIGINS AND THE FALL                                                                                                           
                                                                 Origins—the First World —Tara                                                                                                                                               
              560,000,000 - 550,750,000 YA                                                              
            Approximately 560 million years ago (YA), upon the planet  Tara within  
       the Second Harmonic Universe), (your Earth is presently in the First Har-                                         
      monic Universe), many ET and metaterrestrial races combined their genetic          
             and energetic make-up to create a master race of beings that would serve as  
          Guardians of the planet T ara. The Sirian Council from Harmonic Universe       
    2, along with several other groups were appointed as directors and overseers 
       of the project, the Turaneusiam-1 (T -1) experiment. Metaterrestrials from         
     the Fourth and Fifth Harmonic Universes were the founders of this project,    
                working through a seed race called the Lyrans from the Third Harmonic
Universe. The Lyrans created a race of beings in Harmonic Universe 3 called   
the Elohim , who would become overseers for the Sirian races in Harmonic                  
universe 2.The Elohim became one of the numerous supervisory groups within 
the Turaneusiam-1 experiment, due to the Sirian race contribution of genetic 
      identity to the experiment.    
       The Turaneusiam race evolved for about eight million years on Tara, with      
    12 primary sub-racial divisions among them. Each of the 12 Turaneusiam sub-      
    races carried a genetic slant derived from the 12 primary contributors to the T-1   
    experiment, but all of them carried the unique l2-strand DNA  package the        
     T -1’ s were designed to embody . The 12 Turaneusiam sub-races were the Bra-   
  ha-man, Dhr-ah-men, Atoni, Trin-i-ten, Azurtan, Celtos, Addami, Yut-     
  arans, Luri, Cerrasz, Nezack-tai, and the  Melchizedakz . After evolving suc-   
   cesfully for many years the Turaneusiam race began to digress, their genetic    
   code breaking down and their cultures falling into disharmony. Manipulation    
   by and inter-breeding with various unrelated ET strains was the primary cause  
   of this digression. About eight million years into their evolution (552,000,000 
   YA) the Turaneusiam race divided into two primary racial strains, the Alanians  
  (sometimes referred to as the Beli-Kudyem ) and the Lumians  (frequently      
   called the Adami-Kudmon ). The two strains of Turaneusiam evolved together 
  on one large land-mass called E-Den, creating two cultures known as Alania   
 and Lumia.  Both cultures evolved on T ara for about one million years   
   (551,000,000 YA). Both races carried the original 12-strand DNA genetic code     
  of their Turaneusiam lineage, and both carried mutations and digressions of       
   that code from inter-stellar breeding. Cultural disturbances escalated along 
   with the continued digression of the Alanian and Lumian strains, and hostility
  arose as the Alanians sought dominion over the more passive Lumian culture.