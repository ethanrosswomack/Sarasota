2 
  
          
     
            
   
                         

      
                                                                                                                 
                                                                                                                Origins and the Fall                                                            
                                        
                                             Mu, the Lumians, Ceres and the Priesthood of Mu                                                                                                  
550,750,000 - 550,700,000 YA
    Keeping a close eye on their Alanian antagonists, about 550,750,000 years
ago (YA) certain members of the Lumian race foresaw a cataclysm in their    
future, brought on by the increasingly dangerous Alanian experimentation   
with power generation through Tara’s planetary core. The Lumians petitioned    
assistance from the Harmonic Universe 2 (HU-2) Sirian Council and the HU-