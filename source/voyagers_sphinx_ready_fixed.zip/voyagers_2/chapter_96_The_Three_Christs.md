96 

                                                                                         
                                                                                      
                                              The Three Christs
distorted Templar Creed. They believed that by promoting male dominance
within the races (which was already a rampant distortion promoted by the
corrupted Serres-Egyptian line), the course of interbreeding could be con-
trolled . By controlling the women breeders and in ﬂuencing a male elite to practice
interracial discrimination, the Elohim's preferred lineage of humans could be kept
genetically pure. These selected “chosen ones” would be given special privilege
of ascension if they followed the teachings of the Elohim’ s altered Templar
Creed. The Elohim had basically given up on the rest of the human population,
and made no attempt to assist the general populace in realigning the damage done to
their genetic codes through the propagation of the Templar-Axion Seal.  
    Other members of the Elohim, Pleiadian Star League Council, Androm-
eda and Arcturian Federations felt this preferential treatment was unfair, and
appealed to the Ra Confederacy for intervention. The Ra Confederacy
agreed that this treatment was discriminatory and detrimental to the human
evolutionary plan. In 700 BC the Azurite Family of the Ra Confederacy was
called into operation as primary protectors of the Covenant of Palaidor, and
though willing to work with the biased Elohim, the Azurites were given an
equal hand in the orchestration of human evolution. Their primary concern
was to realign the morphogenetic field of the Sphere of Amenti, reintegrate
all of the races who had been removed and prepare the races for another
opening of the Halls of Amenti, to be scheduled in coincidence with the
mass ascension wave of 2017 AD. The Azurites and Elohim worked together
through the Melchizedek Cloister, establishing the Essene brotherhood about
1240 BC, which was originally designed to bring the undistorted Templar
teachings of the Law of One back into manifestation on Earth. (The Essenes
were originally one of the 25 families within the Melchizedek Cloister race.
Members of this family were interbred with the Hibiru Cloister races to cre-
ate a hybrid Hebrew strain. The Essenes thus had two primary racial divi-
sions, those of the Melchizedek Cloister and those of Hebrew mixed-Cloister
lineage.) Within several generations the biased Elohim took the project in
their own direction, interbreeding some of the Cloister Melchizedek families
with the Hebrew-Melchizedeks and promoting the patriarchal Templar
Creed, which became the primary focus of the Essene Brotherhood teachings.
By 1150 BC the Priests of Ur disassociated themselves from the primary fam-
ilies of the Essene brotherhood, and began working with a few select families
within the Essenes, and the Hibiru and Melchizedek Cloisters. These families
were chosen to reintegrate the undistorted pure Templar teachings and to
work directly with the Priests of Ur to ensure the race preparation for the
ascension wave of 2017 AD. In 700 BC the Ra Confederacy gave the Azur-
ites equal directive control over human evolution and appointed them pri-
mary guardians of the Covenant of Palaidor. The Azurites began their work
on Earth through the Essenes of the Priests of Ur. In 196 BC the Azurites and
the Sirian Council attempted to mend the growing rift within the