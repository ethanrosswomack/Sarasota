12 TRIBE NAMES AND SACRED PSONNS  
   • The original names  of the Angelic Human 12-Tribes were spoken in the
    first of five  Christos Languages;  the Mu’a/Anuhazi  language of the
     Palaidia Urtite Cloister Mu’ a  race. Anuhazi (“Mu’a”) is the original  first
   externally spoken language  in our Time matrix, the native tongue of the
        Emerald Order Breneau  and Lyran-Sirian Elohie-Elohim  Christos
      Founders races from Density-5 (dimensions 13-14-15).  
      • The 12-Tribes names  were the audible-tone translations of the specific
       Fire Letter Sequences  contained within the  T ribal Shield DNA T em-
      plates  of each Tribe. The tones of the Tribal names were used to activate
      the 144 Fire Letters  of the Tribal Shield in the personal  DNA Template,
     providing the Angelic Humans races with the ability to consciously reg-
      ulate  the activation level  of their DNA Templates  and Primal Life Force
      Currents.   .The Sound-Tone  programs  that are used to activate the DNA  T emplate
         and Primal Life Force Currents are called ‘ ‘ The Sacred Psonns. ’’ The
     Tribal name  was the Master Psonn . In running the Rainbow Roundta-
     bles, the Signet Council Regents bring their Tribal Shield ‘ ‘Flame Codes’ ’
          into activation by singing rounds  of the Sacred Master Psonns .                                                                      . The true Angelic Human 12-Tribes names were intentionally changed  and       
            the knowledge of the Mu’a Anuhazi language  strategically concealed on           
           Earth by Fallen Angelic legions and their Illuminati Human hybrid races.                
     The tactic of deception was used to ensure that the Angelic Humans of                 
     Earth would be unable to activate their Tribal Shield DNA Template                         
           Flame Codes  to run the Rainbow Roundtables during the 2000-2017 AD                    
              Stellar Activations Cycle, so pole shift and destruction of the Angelic Hu-
          man race would take place during the 2000-2017 SAC.  
 
  • This ill-intended agenda can be stopped if Angelic Humans are willing to
     assist Guardian Nations in running the Rainbow Roundtables between
         2002-2012                           
                  THE THREE KEY ELEMENTS OF THE CYCLE OF THE ROUNDS
                        
                                    Key Element- 1: “The 12 Signet Tribes and Races List”                   
              • The methods by which we can fulfill our intended part of the Planetary
        Christos Realignment  become apparent through understanding Three
                      303  
                                                                                                                                 
            

                 The Angelic Human Heritage and Rainbow Roundtables
      
         Key Elements  of   the  Cycle  of the Rounds  Angelic Human  evolutionary
      design.  
• Element-1. The 12 Signet Tribes and Races List: The list of Signet An-
       cestral Ascendancy ,  which reveals the 12 Signet Tribes appointed as
    Guardians and “Keepers of the Keys” for each of the I2 Universal Star
   Gates and their earthly correspondences. The 12 Signet Tribes and Races
    List traces the genetic lineage  of the 5 Palaidia Urtite-Cloister Angelic
    Human Seed Races that founded the 12 Signet Tribes of Seeding-3  up to
      their contemporary race lines.  Through revelation of Signet Ancestral
    Ascendancy , we can identify the original Signet Tribe  from which our
    current genetic code originally emerged, and thus we can reclaim the
    knowledge of the “ Signet Council ” to which we presently belong. This
    information, recorded on CDT Signet-Plate-12,  allows us to identify the
       Core Signet Key Codes  upon which our  personal DNA  T emplates  are
    built, so we know to which of the 12 Star Gates our  DNA  T emplate is
    ''Keyed .'' Identifying which of the 12 Tribes represents our predominant
       genetic lineage  enables us to discover the core '' Master Symbol-Color -
     T on '' Keys  we need to rapidly initiate accelerated “Fire Letter” activa
       tion sequences  in our dormant 12-DNA Templates, to expedite embod-
  iment of our personal D-12 Inner Christos “Maharic Shield" Template.  
              
        • Progressive embodiment of our Personal Divine Blueprint,  the D-12 Pre-
    matter Maharic Shield  allows us to progressively attain real 12th-dimen-
          sional ''Christ Consciousness, '' rather than false “Christ conscious-
       ness.” False Christ consciousness  teaches us to give spiritual “lip
    service”  and “wishful thinking”  to the concept of becoming “Christed”
     through worship of false externalized gods , but teaches nothing of the re-
     alities of Sacred Science 15-Dimensional Human Anatomy and Ascen-
    sion Physics.  The Founders’  Sacred Science  knowledge represents the
     '' Keys to the Kingdoms of Heaven '' without which one  cannot attain
       genuine Christ Consciousness , Spiritual Mastery or Ascension
            Though full translation of the 12 Signet Tribes and Races List  for          
             Seeding-3 would literally fill thousands of books, a basic analysis  of the An-
       cestral Ascendancy contained in the list, herein, will provide sufficient
    data for many of us to trace our Primary DNA Template Signet Coding .
      Through the rudimentary but accurate listings  provided in this book,
     many of us will be able to identify our original Tribe and Primary DNA
     Template Signet Coding,  and thus the  Star Gate, Signet Set and Master
     Symbol-Color-T ones  to which our DNA  T emplates are “frequency
     keyed.” In Global Healing Efforts, Planetary Templar Grid Work and
     actualizing Earth’ s Christos Realignment , it is essential for us to under-
     stand the Three Key Elements of the Cycle  of the Rounds  Angelic Hu-
     man Evolutionary Design. Understanding the basic realities of the Cycle
       of the Rounds will determine whether we will be lovingly and tangibly ef-
      fective or well meaning but unable to fulfill our good intentions, in our
     planetary healing endeavors. The First Key Element  of the Cycle  of the
     Rounds is the 12 Signet Tribes and Races List , through which we can
     discern which Star Gate is waiting to receive our personal  “piece of the
    Christos ” to '' fill in the frequencie '' of its own Divine Christos Blue-
       print.  
 304 
 

  
                                                 The Three Key Elements of the Cycle of the Rounds  
                            Key Element-2: “The Signet Maps and Keys’ ’  
   • The Cycle of the Rounds Key Element-1, The 12 Signet Tribes and Races
      List, provides us with the first necessary tool  to discovering the Master
      Symbol-Color-T one sequences and Star Gate Signet Council to which
      our personal DNA  T emplates and Soul Contracts, are keyed; our original
       Tribe.  Once we have a basic idea  of what Palaidia Empire Seed Tribe our
      genetic lineage (and our reincarnational lineage  as well!) emerged from,
       we can then utilize the information contained in Key Element-2  of the
       Cycle of the Rounds. Key Element-2  is the Signet Maps and Keys Chart ,
      which reveals the Tonal Encoding  of each 12 Tribe name , the Star
    Gate-Signet Set assignment  of each Tribe, the specific geographical lo-
     cations  of the 12 Templar Signet Site  star gate opening points and their
       corresponding Templar Cue Site  activation points. The  Signet Maps and
       Keys Chart also reveals the  Master Symbol  (frequency director), initiat-
     ing Master Tone Suffix  (frequency activator), the  Psonns  (primary tonal
      activation sequence), Flame Code  (frequency selector: Signet Master
       Key Code) and Master Color  (frequency selector; Signet Encryption Key
         Code) for each of the 12 Tribes. This data represents the ''Fire Letter''
      Frequency Programs to expedite activation  of the personal DNA Tem-
     plate and the  Frequency  Keys by which each of the 12 Star Gates and
     Signet Sets are activated . Like Key Element-1: The 12 Signet Tribes and
       Races List , full translation of Key Element-2: The Signet Maps and Keys
      Chart , would fill many volumes; the Signet Maps and Keys Chart  is
       drawn from the “ Book of Maps and Keys ,” stored on CDT Signet-Plate-
      11. Advanced study of Masters Sacred Physics Mechanics  is required be-
      fore the full body of knowledge  contained within the Book of Maps and
        Keys  can be sufficiently understood and functionally utilized.  
  • Due to the progressive difficulties emerging in Earth’ s 2000-2017 Stellar Ac-
          tivations Cycle (SAC), there is presently no time available to methodi-
         cally initiate advanced study of Masters Sacred Physics Mechanics ; such
         study will be made available to the public if Earth’s 2000-2017 Planetary
         Christos Alignment is successful. If the 2000-2017 '' Bridge Zone Project ''
         (see page 142) and its inherent Planetary Christos Realignment Mission
         (see Chapter 12) are not successful, pole shift before 2017  will be un-
         avoidable; in this event, the Founders’  first priority will be evacuation ,
         followed by education. The Signet Maps and Keys Chart  is a translation
    of entry level study  of the Book of Maps and Keys ; it provides sufficient
    information by which individuals can reclaim the basic tools through
    which the Planetary Christos Realignment  can be achieved during the
       2 000-2017 SAC.  Once the personal Tribe  is identified through the 12
     Signet Tribes and Races List,  and the Signet Maps and Keys  correspond-
     ing to the Tribe are revealed, the final element  of the Cycle of the Rounds
      will allow this knowledge to be used directly for personal and planetary em-
     powerment . The knowledge offered through the Three Key Elements of
     the Cycle of the Rounds  represents the Divine Right Empowered  Wis-
         dom  through which the Bridge Zone Project  Time Continuum Shift, the
        Planetary Christos Realignment  and the Founders ’ Emerald Covenant
      Vision of Angelic Human freedom  can be actualized. Key Element-3  is
      called the '' Rites of the Rainbow Roundtable '' 
305 
                                                                                                                                                      
                                                                                                           

                                           
    The Angelic Human Heritage and Rainbow Roundtables  
                
                        Key Element-3: “Rite of the Rainbow Roundtable”  
 • Key Element-3 in the Cycle of the Rounds is called the Rite of the Rain-
        bow Roundtable (RRT)  which is composed of two primary components.
       One component of the RR T is referred to as Tribal Shield Activation,  the
         second component is called the Signet Stands . Component one of the
        Rite of the RR T , Tribal Shield Activation, is the ancient process of  inter-
         nal energy direction  by which the Palaidia Urtite-Cloister Races con-
        sciously brought the core coding of their DNA  T emplates into activation.
     Through activation of the Tribal Shield  in the DNA  T emplate, the An-
      gelic Human body can run  the ''Rainbow Ray '' Primal Kee-Ra-ShA
        Light and Khundaray Sound Currents  and the D-12 Maharata ''Chris-
          tos Current '' Pre-matter hydroplasmic ''carrier wave '' that is necessary
        for embodiment of the 15-dimensions-plus Rainbow Ray Ante-matter
       Currents. Through activation of the Tribal Shield one learns to direct the
         personal Kundalini Life Force energies into their originally designated co-
        ordinates within the four Density Levels of Earth’ s Planetary Shields, to
          effectively create a Trans-Geographical and Trans-Time Connection
           with the other members of the '' Rainbow Wearers Signet Counci '' soul
       group to which the frequencies carried in your DNA  T emplate are inher-
        ently keyed. Activation of the Tribal Shield begins rapid restoration  of
        the natural 12-Strand or higher Angelic Human DNA  T emplate,  reor-
           dering genetic mutations  and blockages that have historically plagued our
         race due to Fallen Angelic manipulation.  
    • Once the Tribal Shield is activated, the DNA Template “goes on automatic
        pilot, ” progressively running the appropriate sequences of Strand Acti-
          vation in synchronization  with the progressive activation of Earth’s
         Planetary Shields  as they come out of dormancy during the SAC. In ac-
         tivation of the personal Tribal Shield, ones becomes a ''walking Rainbow
        W earer ''-a biological electromagnetic “anchoring rod” for the D-12 Ma-
         harata Christos and Rainbow Ray Kee-Ra-ShA  and Khundaray Currents.
        Y ou will draw in and transmit only the amount of frequencies your DNA
         T emplate is “keyed” to carry , and your natural Spiritual Integration and
         Actualization process will naturally unfold under the guidance of your
            own D-12 Inner Christos “A vatar” level of consciousness. As a Signet
            Council Rainbow W earer ,  your biological presence  progressively be-
        comes an agent of natural healing , not only for yourself, but also within
        any environment  into which you may travel. Rite of the RR T component
        two,  Signet Stands , reveals the three Primary Positions,  or “Stands,”  for
        arranging members of a group  when orchestrating intensive Site W ork
        RR T s in a Planetary Shields Clinic setting. Groups of Rainbow W earers
          can amplify and direct the Rainbow Ray Current  in the most effective
           manner by utilizing the geometrical relationships  between the electro-
         magnetic fields generated by DNA  T emplate-activated bodies. Key Ele-
         ment-3: The Rites of the RRT is drawn from one of the “Books of Process,”
           stored on CDT Signet-plate 12.  
     
   
      306  
                   
               

                                                                                               Tribal Shield Dynamics
                                  
                                        TRIBAL SHIELD DYNAMICS  
           
               Triba l Shield Activation, “Fire Letters” and the DNA Template  
  • The Tribal Shield refers to the core programming of Fire Letters  held with-
          in the personal DNA  T emplate. The personal 12-Strand DNA  T emplate
          is composed of specific groupings of scalar-standing-waves , fixed points
            of light and sound wave frequencies, that represent the blueprint  upon
           which the personal DNA, the body’ s molecular structure and the embod-
         ied consciousness manifest. All humans have a common Base-12  12-
            Strand DNA  T emplate; Maji races, such as the contemporary Indigo
             Children , have the Base-12 Template and can have up to 48 full DNA
          Strand T emplates, which activate in synchronization with the Base-12
         Template. Each strand  of the DNA Template is composed of 12 Fire Let-
         ters . A “Fire Letter” is a fixed point of consolidated scalar-frequency that
         is composed of 12 smaller units of frequency  called Vector Codes . Each
          DNA  Strand T emplate, with its inherent '' Base Codes, '' ''Acceleration
          Codes '' and ''Activation Fire Codes '' (see “DNA 101” on page 478) rep-
          resents one '' Fire Letter Sequence. '' A 12 Strand DNA Template  thus
         carries: 12 Fire Letter Sequences (Strands), 144 Fire Letters ,¹ and 1728
            V ector Codes .² The Maji 48 Strand DNA Template carries: 48 Fire Let-
           ter Sequences (Strands), 576 Fire Letters ,3 and 6912 Vector Codes .4
          The 48 Strand Maji DNA  T emplate is sophisticated enough to carry the
          144 Universal Signet Master Key Codes and 1728 Universal Signet
            Encryption Key Codes  corresponding to the 12 Universal Star Gates  of
             the Universal Templar Complex in our Time Matrix.  
  • Each of the 12 Angelic Human Tribes carries the same core 12-Strand DNA
            T emplate, plus whatever additional strand coding characteristic to the
             Race Cycle or “Round” within which it is manifest. The Base-12 DNA
           T emplate, with its 12 Fire Letter Sequences, 144 Fire Letters and 1728
                V ector Codes, is the personal '' Divine Christiac Blueprint ''; the D-12
           Maharic Shield  Pre-matter T emplate through which the full 1 2-dimen-
             sions of genuine '' Christ Consciousness '' can embody when the 12-
              Strand T emplate is fully activated .5 All Angelic Human Tribes emerge
             from the same  D-12 Christos Blueprint, but each Tribe  has the Fire Let-
             ters  in each Strand Template arranged in a different order or sequence .
          The DNA  T emplate is the electromagnetic blueprint through which spe-
           cific frequencies and corresponding dimensions of consciousness  are
           drawn into manifest embodiment  from the Universal Unified Field of en-
            ergy-consciousness in our Time Matrix. Variation of DNA Template
            Fire Letter Sequencing between  the 12- Tribes seed races allows each
             Tribe  to draw and transmit a specific arrangement  of frequencies and spe-
             cific dimensions of consciousness, into Earth’ s Planetary Shields. Each of
           __________________________    
1.   12 Fire Letters per Strand x 12 Strands.  
2.   12 Vector Codes per Fire Letter x 144 Fire Letters.  
3.   12 Fire Letters per Strand x 48 Strands.  
4.   12 Vector Codes per Fire Letter x 576 Fire Letters.
                              5.    Contemporary humanity carries an averag of 2.5 to 3.5 DNA Strand Tempate activ-
                                     tion level.  
                          307                                                          
                                                                                                                              

                                                                                 
     The Angelic Human Heritage and Rainbow Roundtables       
   the l2 Angelic Human Tribes is designed to enter a specific part  of the
    D-12 Shield of Aramatena Universal Christos Divine  Blueprint  into
   Earth’ s Manifestation T emplate, in fulfillment of the Planetary Christos
   Realignment Mission  (see Chapter 12). The specific DNA Template
    Fire Letter Sequence program unique  to each of the 12 Tribes seed races
       is referred to as the '' Tribal Shield. '' 
    • The DNA Templates of all contemporary humans originally emerged from
       one of the 12 T ribes,  which were composed of various combinations  of
      the five Palaidia Urtite-Cloister seed races . When we activate the Tribal
        Shield, via our innate Inner Christos Divine Blueprint, through using the
          Master Symbol-Color-T ones  that correspond to our Tribal Shield im-
        print, we progressively realign the Fire Letter Sequences in our DNA
        T emplates to their original, organic Christiac order . Realignment of the
      DNA  T emplate with the innate personal D-12 Christos Blueprint allows
      the 12-Strand DNA  T emplate to realign distortions, so the Strand T em-
       plates can activate in the  specific sequence  for which they were designed.
      Activating our Tribal Shield allows the '' Internal Star Gate '' within our
       DNA  T emplates to open, creating a direct  energetic conduit of frequency ,
       and bridge of conscious awareness,  between our present incarnation  and
     our other simultaneous incarnations that exist now in other space-time
      vectors of the Cycle of  the Rounds . To create the Trans-Time Connec-
      tion through which the Planetary Christos Realignment  can be fulfilled,
       our personal DNA  T emplates must progressively open to allow the fre-
       quencies  from the other related Time Vectors  to enter Earth’ s present
                      Time Vector  
  • The human DNA Template was designed to allow for this Trans-Time Con-
     nection frequency bridge. Through activating the proper sequences  with-
    in our DNA  T emplate Tribal Shield, we progressively allow the proper
   sequences of the Universal D-12 Maharata and Rainbow Ray Current to
    enter our bodies. From our sequentially activated DNA  T emplates, we
       then pass the proper sequences of frequencies  from the Universal Chris-
       tos Blueprint into Earth’ s Planetary Shields, resetting the part of the D-12
      Shield of Aramatena to which our race cycle is assigned, within Earth’s
   Manifestation T emplate. The Angelic Human race was designed to fulfill
   this Divine Commission.  As we assist the planet to become “Christed”
      (embody its full D-12 Christos Blueprint), we in turn progressively return
     to our originally Christed state, as our personal Christos Blueprint  em-
   bodies. Through embodiment of our personal lnner Christos Divine Blue-
         print, we achieve genuine spiritual actualization  and reclaim our
   dormant ability to pass through the 12 Universal Star Gate ''Ascension
   Passage '' at will, in fulfillment of our intended Angelic Human mastery
     of the space-time-matter experience.  
  • When we use the knowledge gained from Element-1: The 12 Tribes and
       Races List , Element-2: The Signet Maps and Keys , with Element-3: Rite
      of the RRT T ribal Shield Activation , we become empowered  Angelic
        Humans  capable of fulfilling the Planetary Christos Realignment Mis-
        sion . As empowered Angelic Humans, we reclaim our heritage, our innate
       divinity , our ability to love unconditionally and wisely , and we reclaim
    308  

                                                                               
                                                                              Tribal Shield Dynamics  
our personal and collective freedom  to have a direct, immediate and per-
sonal co-creative relationship with Source-God. The Tribal Shields Acti-                     
vation teachings show  how  to activate the appropriate frequencies in our
DNA Templates, and where  to direct those frequencies into the Planetary
Shields, to anchor the part of the Universal Christos Blueprint that we
were personally commissioned to deliver when we entered the Angelic
Human incarnational cycle. Activation of the Tribal Shield allows us to
work alone or in groups  to achieve accelerated personal spiritual devel-
opment  and to orchestrate effective, remote planetary restoration  with-
out having to physically visit the locations of Earth’s Star Gates and
Templar Cue Sites. Through Tribal Shield Activation we reclaim the
ability to remotely activate the 12 Signet Shields and Signet Plates,
Earth’s  Star Gates and the Planetary Christos Blueprint.  
309