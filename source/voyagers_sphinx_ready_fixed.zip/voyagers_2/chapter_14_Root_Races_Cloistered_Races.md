14

                                                                                        
                                                                                  Root Races - Cloistered Races  
  sents the manifestation of patterns of dimensionalized electro-tonal frequency.
Through linking the frequency bands of dimensions 1 through 7 within the
morphogenetic field, a planet or a person can ascend/evolve out of the matter
based systems and into pure sentient consciousness. This is the evolutionary
process. So the Blue Flame Staff of Amenti, stored within the time warp mor-
phogenetic field of the Sphere of Amenti, represents the key to the evolution
of Earth, and the human lineage, and one of the keys to the evolution of the
planets in your solar system, Tara and Gaia.  The Staff of Amenti is the gateway
into Tara's morphogenetic ﬁeld.  Whether the Staff is held within Tara's core or
within the Sphere of Amenti at Earth's core, it represents the gateway to which
the Halls of Amenti lead. One can pass into the Halls of Amenti, but must pass
through the Blue Flame in order to transmute form and appear on Tara. In later
Egyptian mystery schools the Blue Flame gateway became known as the Gates
of lvory, which became translated in Biblical terms as the Pearly Gates of
Heaven.  In each case the writings referred to the Blue Flame Staff of Amenti,
the energetic gateway to Tara. Needless to say, the Sphere of Amenti and the
Staff which allows the Halls of Amenti to open into Tara are quite valuable
commodities. Every human on Earth now is in some way energetically con-
nected to the race morphogenetic field within the Sphere of Amenti, and it is
through the Halls of Amenti (or through the Taran morphogenetic Sphere
within one of the other 11 planets in your solar system) that you must ascend to
fulfill your evolutionary imprint as souls and return to your Creator/Creative
Source.                                                                        ROOT RACES - CLOISTERED RACES                                    F orming of the five physical Root Races and their Cloisters  
                             Blue Print For Evolution Through DNA Assembly  
                                                    Rescue Mission Stage 4  
                                                             25,000,000 YA                       
    After the Staff of Amenti was set within the Sphere of Amenti at Earth's
D-2 core, the forming of the five remaining Root Races began. The five Clois-
tered Races within the morphogenetic field of the Sphere polarized, splitting
their energy fields, each creating two smaller morphogenetic fields within the
Sphere of Amenti. The 10 new spheres collectively held the blueprint for
DNA strands one through 12. Each of the five Cloistered races was responsible
for the evolution of one pair of these new morphogenetic fields. Each sphere
became the morphogenetic field for one Root Race plus its companion Cloister
Race that would simultaneously manifest into physical expression on Earth,
during the time periods that corresponded to the dimensional DNA strand to
which each race was appointed. These five morphogenetic fields became Root
 Races 3—7, through which DNA strands 2—6 would be assembled.