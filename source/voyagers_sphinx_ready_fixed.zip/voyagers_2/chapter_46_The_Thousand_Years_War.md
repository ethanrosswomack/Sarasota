46 
 

                                                                             
                                                                                                   
                                                                                                     The Thousand-Years’ War
The original morphogenetic field for this sub-race became distorted through
Anunnaki interbreeding of the Nephilim, at which time the Elohim and oth-
ers removed the distorted portions of the Egyptian morphogenetic field from
the Sphere of Amenti, placing this portion of the race under the care of a
Host Matrix Family from the Ra Confederacy called the Aton-A. The por-
tions of the Egyptian sub-race that remained in the Amenti morphogenetic
field were fused with the morphogenetic field provided by the HU-2 Seres,
which created a hybrid Egyptian race called the Serres, who became the
Pharaonic line within Egyptian culture. The Serres-Egyptians began a new
line of Egyptian bearing an advanced genetic strain.  
    Later, during the Third Seeding, the Egyptians carrying Sirian-Anunnaki-
Nephilim morphogenetic fields were remixed with the Serres-Egyptians so the
morphogenetic field of the Sirian-Egyptians could be integrated into the
Sphere of Amenti. Descendants of the Serres-Egyptians held the line of Egyp-
tian royalty throughout the early dynasties, but eventually the Sirian-Egyptians
were integrated into this line and, for a time, open relationships with the Sir-
ian-Anunnaki and Sirian Blue Races resumed. The Egyptians carried a special-
ized genetic code because of this early morphogenetic manipulation. During
the Third Seeding this imprint became even more specialized as portions of the
Egyptian line were adopted by the Sixth Race Cloister Melchizedeks, who
served as a Host Matrix Family to realign an over-development of Anunnaki
genetic coding. Of all the human races to walk the planet, the Egyptians carry
the most diversi fied genetic code. The Melchizedek Egyptians of the Third
Seeding orchestrated the Atonist movement about 3,000 years ago, in order to
redirect Egyptian culture back toward practice of the Law of One, teachings
that had fallen into digression through Anunnaki involvement with Egyptian
culture. The Serres were created during the Second Seeding about 945,000
years ago, their Atlanian sub-race morphogenetic field being merged with the
Breanoua and Hibiru Cloisters of the fourth and fifth races, which brought the
Ayrian and Hibiru lineage into the Atlanian-Egyptian line. This realigned and
advanced the genetic blueprint for the Egyptian subrace, creating what would
                        become the primary Egyptian lineage throughout the Third Seeding.    
        After a period of development, the human evolutionary imprint began to 
prosper, and about 900,000 years ago the Elohim, and the Sirian Council, Seres
and Palaidorians of HU-2, re-entered the Sphere of Amenti into the Earth
core. At this time Sirian-Anunnaki from HU-1 and HU-2, along with Drakon
and other sympathizers, decided to take human evolution in another direction.
Still angered over Elohim interference with their Nephilim race, the Anunnaki
from Sirius A devised a plan to destroy the Sphere of Amenti and utilize the
Earth humans as a worker race to harvest Earth gold for Anunnaki purposes
(the Anunnaki of Sirius A needed gold to replenish depleting elements within
their planetary atmosphere). Wars broke out between the earthly Nephilim