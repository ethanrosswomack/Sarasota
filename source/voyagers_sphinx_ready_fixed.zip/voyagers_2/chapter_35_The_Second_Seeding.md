35 
  

     
     The Second Seeding  
and ascend out of matter form. The Axion Seal required that the soul con-
tinue innumerable cycles of birth and rebirth within the earlier races, until
the time when Tara and Earth would merge. The sixth base tone of the first
strand, sixth base tone of the fifth strand and sixth base tone of the sixth
strand of DNA were all removed from the morphogenetic field. This genetic
conﬁguration of the Templar-Axion Seal was the original meaning behind the sym-
bolism of the “666”, and these numbers also ﬁgured prominently in the earlier
building of the Great Pyramid, for this Seal had originally been applied to the Sirian-
Anunnaki in HU-2, who assisted in the construction of this machine . The “666”
became the trademark of members of the Sirian-Anunnaki who refused to
accept leadership from the HU-2 Sirian Council, and who would not uphold
the Law of One. The “666” became a part of the human genetic code through
the interbreeding of the Melchizedek Cloister with visiting Anunnaki, who
created the hybrid races Nephilim  and Annu,  and then again through the
imposition of the Templar-Axion Seal following the opening of the D-2 por-
tals in Egypt during the Third Seeding. To administer the Templar-Axion
Seal, part of the morphogenetic field was put under the jurisdiction of the
Arcturian races and part within a planet in the Andromeda galaxy, which
meant that the soul essence would have to evolve a disembodied conscious-
ness, first through the Pleiadian system, then Arcturus, and then into
Andromeda, before it could finally rebirth on Tara. Once its Taran cycle was
completed, the soul had to return to Earth. By passing the consciousness
through these other star systems, teachings of the Law of One could slowly
heal the identity, until eventually its tour of duty on Earth would be ful filled.
This tour would last until Earth had successfully re-evolved into Tara and the Cov-
enant of Palaidor was fulﬁlled.                  
    Due to the T emplar and T emplar-Axion Seals the concept of “ soul har-
vesting”  became part of many religious teachings. Soul Harvesting referred to
souls bearing the Templar Seals being brought, by one of the helper organiza-
tions before the Ra Confederacy for review, at which time those souls deemed
safe for transit to Tara or higher systems would be released from the Templar
Seals and allowed to end the perpetual cycles of birth and rebirth on Earth.
Those passing the review would have evolved to comprehension of the
necessity for the Law of One, and would have actively employed these princi-
ples within their present incarnation. Passing the review meant the soul
would be “harvested” or cleared of its distortions and allowed to ascend to
Tara for rebirth within the sixth and seventh races, and following its com-
pleted Taran cycles, the soul could ascend out of matter. In some traditions
this concept became translated as “ judgment day”  or similar ideas of having
to “pass God's tests” and become “worthy.” But in truth, God's universe is
free, and these concepts applied only to beings bearing the Templar Seals,
who wore the armor of their disregard for the Law of One within the con figu-
rations of their genetic codes. Processes of initiation that developed through