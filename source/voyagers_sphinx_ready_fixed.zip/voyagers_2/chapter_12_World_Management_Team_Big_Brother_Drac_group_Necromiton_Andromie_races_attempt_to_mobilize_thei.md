12 World Management Team ''Big Brother Drac'' group. Necromiton-Andromie  races attempt to mobilize their     
Illuminati races in Hawaii and Nagasaki Japan  to built underground bases to hi-jack the Zeta-Rigelians Falcon     
APIN Port Interface System at its Nagasaki APIN  site. Zeta-Rigelians instruct their Illuminati hybrids in Japan and    
US via MJ-12, to launch Pearl Harbor strike; US and Japanese Illuminati know plan from start. Zeta’s provided allies    
with A-Bomb technology  specifically to use on Nagasaki, to regain Nagasaki Falcon APIN site under Zeta-     
Rigelian control . Hiroshima Necromiton-Andromie Illuminati wiped out on behalf of Zeta-Rigelian Agenda, Maji     
Grail Line Human YU race Indigos of Hiroshima destroyed , Nagasaki reclaimed under Zeta-Rigelian control.     
Necromiton-Andromies prevented from building Nagasaki base, Falcon APIN continues to be activated by Zeta-Rigelians. 
• 1943 : Zeta-Rigelians expand Falcon APIN system via August 12 , 1943 Philadelphia Experiment , putting east    
coast US Falcon APIN system “on-line” with Falcon wormhole . Create the Phi-Ex wormhole  Port Interface    
Network.
• 1951:  1951 White Eagle-Dove Alliance.  (AKA ''Archangel Michael joins Enoch''). Pro-Anunnaki Necromiton-    
Andromies make deals with Jehovian Anunnaki to combine and activate their respective '' White Eagle '' and '' Dove ''   
APIN systems  to regain Anunnaki OWO dominion over Illuminati force and Earth’s Templar. Attempt to open    
Phoenix Wormhole off eastern coast of Florida. Unsuccessful until 1972. Zeta-Rigelians continue Un-Natural    
Disaster/Ethnic Virus testing, covert Interior Government contact, abductions throughout 1950s-1960s. 
• 1972:  Pleiadian-Nibiruian Anunnaki assist White Eagle-Dove Alliance (AKA. “Samjase, Thoth, Galactic Federation    
and Ashtar Command join Archangel Michael and Enoch) to break through cap on Phoenix wormhole via Solar    
SG-4 sonic transmissions, begin activation of the Phoenix, Serpent , Dove  and White Eagle APIN systems;    
intensifies Solar anomalies from 1943 Phi-Ex opening to Solar Fl are/Red Pulse crisis point. GA implements    
11:11/12:12 Frequency Fence to prevent 1973 Red Pulse destruction, initiate Solar SG-4 repairs. Anunnaki begin    
 regaining strength in Illuminati World Management Team.                        
                                                                                              ©2002 Ashayana Deane
                           519                                                  
                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                   

   2001 Update Summary Charts
• 1980s:  Rigelian-Andromie Alliance. Zeta-Rigelians make deal with Pro-Drakonian Necromiton-Andromie forces, Omicron-
Drakonian races of Alnitak and Dracos hybrids of Earth get directly involved and combine APINs to prevent Anunnaki groups from 
getting upper hand in Illuminati World Management Team. 1983 Falcon-White Eagle- Dragon Alliance.
• 1983:  M o n t a u k  P r o j e c t  orchestrated by Rigelian-Andromie Alliance, further connects Phi-Ex Falcon APIN system of Earth/
Phantom Earth to Phantom Alpha and Omega Centauri and Alnitak Orion . Create Montauk-Phi-Ex Falcon APIN system. 
Drakonian Agenda races regain dominance in World Management Team. Falcon-White
Eagle-Dragon become “ Superpower ” and sets sites on overtaking Anunnaki APIN systems. White Eagle-Dove Alliance seek 
dominion of Phoenix and Serpent APIN’s to prevent Drakonian Agenda advancement. 1983-1984 GA initiates Bridge Zone Project 
and begin Emerald Covenant peace treaty negotiations with Fallen Angelic groups. 1986 GA 9540BC Frequency Fence released.
• 1992 : Pleiadian-Nibiruians (Pleiadian Samjase-Luciferian and Nibiruian Thoth-Enki-Zeta and Enlil-Odedicron Anunnaki ) 
attempt to cap Falcon wormhole to prevent Falcon-White Eagle-Dragon group from overtaking NDC- Grid system. Falcon group 
uses sonics on August 12 , to expand Falcon wormhole , preventing attempted Anunnaki cap; Hurricane Andrew hits east 
coast US August 24 as result of Falcon wormhole expansion and sonics. White Eagle-Dove group continue campaign for control of 
Phoenix wormhole, related APIN’s and Giza.
• 1992 November : Pleiadian-Nibiruian, Galactic Federation and Ashtar Command Anunnaki grudgingly enter Pleiadian-Sirian 
Agreements/ Emerald Covenant, White Eagle-Dove refuse, when Falcon-White Eagle-Dragon Drakonian Agenda races nearly take 
over Phoenix and Serpent APIN’s, NDC-Grid, NET and Giza/Mexico Nibiruian Crystal Temple Network.
• 1992-1994:  Emerald Covenant races with assistance of Pleiadian-Sirian Agreements Anunnaki use Nibiruian NET and NDC-Grid 
to temporarily CAP Falcon wormhole , shutting down Montauk-Phi-Ex Falcon APIN system . Anunnaki races vow to turn 
NDC-Grid, NET and Phoenix-Serpent APIN systems over to Emerald Covenant Founders by 2000 SAC start, for co-operative 
progression of Earth Freedom Agenda and Planetary Christos Realignment Mission.
• 1994-1998:  Pleiadian-Sirian Agreements Anunnaki races gain dominance in Illuminati World Management Team, supposed to 
(as per 1992 Agreements) begin preparing Illuminati for '' Official Disclosure ''/ entry into Emerald Covenant. GA 11:11/12:12 
Frequency Fence released . Rebel Anunnaki groups form and begin using '' Phantom Pulse '' tracer sub-space electrical 
transmissions along known electrical lines for Psycho-tronicsand Anunnaki APINs/NCT-Bases “hi-jack”.
• 1998:  ''Arc Spark'' grid acceleration confirms 2000-2017 SAC will commence in 2000, most Anunnaki join rebel groups/ defect 
from Pleiadian-Sirian Agreements for opportunity to fulfill their original Luciferian Covenant OWO agenda. Anunnaki began 
shutting down Emerald Covenant communication lines in the NDC-Grid, NET and APIN systems. Falcon-White Eagle-Dragon 
Drakonian Agenda group blow CAP off Falcon wormhole, begin competitive campaign to achieve Falcon APIN and illuminati 
dominance. Begin reactivation of Montauk-Phi-Ex- Falcon APIN.
• 1998-1999:  Competing factions of White Eagle-Falcon-Dragon, Rebel Dragon, White Eagle-Dove and Phoenix- Serpent groups 
compete for APIN grid activation, territory dominion and Illuminati dominance. New Age Movement Anunnaki OWO agenda 
“Astral Tagging” domain, UFO Movement Drakonian OWO Agenda “Astral Tagging” domain, numerous Rebel factions from each 
group. White Eagle-Falcon-Dragon continue activation of Montauk-Phi- Ex Falcon APIN sites. Competing White Eagle-Dove and 
Phoenix-Serpent groups accelerate their respective APIN activation.
• 1999:  GA continue GF, Ashtar, Thoth, Samjase, Anunnaki, renegade negotiation in hope of reestablishing Pleiadian-Sirian 
Agreements to prevent escalation of Final Conﬂict drama. Drakonian groups begin Psycho-tronic
Sonic Pulsing to USA, Jerusalem and China for instigation of the WW3 drama; pulses slow-release, intended to take effect end 
2002-2003 .
• 2000  January  1: G A Planetary Shields Clinics start. Emerald Covenant nations/Indigos succeed in activating Earth’s Templar 
on a 12-Code Pulse during 1/1/2000 Grounding of Stellar Bridge. Emerald Covenant races now have ability to override Fallen 
Angelic NDC-Grid, NET, NCT-Bases, APINs, close Atlantian Wormholes and fulfill 22,326BC Planetary Christos Realignment 
Mission; IF critical mass 12-Code-Pulse can activate in Earth’s Templar before 2003 .
• 2000  July 5: Most Pleiadian-Nibiruian Anunnaki and a few Jehovian Dove and Odedicron-Reptilian factions temporarily agree to 
Emerald Covenant Treaty of Altair , due to likelihood of either Emerald Covenant or Drakonian Agenda defeat. Emerald Covenant races 
begin 12-Code-Pulse grid re-coding and Human DNA Template
clearing and activation’s.
                                                                      ©2002 Ashayana Deane
           
\
       520

                  2001 Update Summary Charts
• 2000  August:  Peru, Treaty of Altair races begin transfer of Phoenix, Serpent APINs, NDC-Grid and NET to Emerald 
Covenant control. Emerald Covenant /Indigo races advance 12-Code-Pulse clearings, threatens to override ALL 
OWO agendas by building Planetary Maharic Seal Earth protection field.
• 2000 September 7: Necromiton-Andromie White Eagle groups unite, negotiate Jehovian Anunnaki Dove, Falcon- 
Dragon, GF and Ashtar “friendly enemies” deals to combine White Eagle-Dove-Falcon-Dragon APINs to defeat 
Emerald Covenant and Treaty of Altair Anunnaki races. Necromiton-Andromies petition Pleiadian-Nibiruian Phoenix- 
Serpent and renegade Anunnaki of Treaty of Altair to combine agendas and APINs to enter United Intruder 
Resistance (UIR) OWO Master Plan .
• 2000  September  12: Pleiadian-Nibiruian Anunnaki defect from Treaty of Altair , join UIR, allow Necromiton- 
Andromies/ Omicron-Drakonians to use previously secure Phoenix APIN grids, England, for Indigos Psycho-tronic 
attack. UIR gives ultimatum to Emerald Covenant Founders to abandon Earth and Humans to UIR genocide 
agenda in return for evac’ of 50,000 Indigos (out of 550,000). Emerald Covenant Founders reject UIR attempted 
Black Mail . UIR initiates official Edict of War against Founders, all Emerald Covenant and Human races. GA 
reverts to original December 21,2012 Christos Realignment Mission, begins War Crisis Order and Masters 
Templar Planetary Stewardship Initiative RRT Intervention.
• 2001  May:  Emerald Covenant races initiate Crisis Intervention, early-open Sirius B Star Gate-6 and ancient Halls 
of Amorea Passage in May 2001 , to prevent UIR intended 2003 Dimensional Blend Experiment , Frequency 
Fence and WW-3 invasion schedule. Expedited Amenti Opening and Planetary Seals Release begins. (See Crisis 
Intervention Expedited Amenti Opening Schedule Chart ).
• 2001  August  12: Mass Awakening DNA 12-Code activation begins; UIR expedites OWO ''First Contact'' Invasion 
agenda, accelerates Montauk-Phi-Ex Falcon APIN activation to initiate Phoenix-Serpent-Dove APIN/ Falcon 
Wormhole link. UIR launch 2 ''ULF Sonic Amplification Slow pulses '' from Chihuahua, Mexico and Lake 
Titicaca Peru . NCT-Bases.
• 2001  September  3: Mexico Sonic Amplification Slow-Pulse passes through SG-2 Gru-Al Point Sarasota, FL as 
Indigos assemble for RRT to realign Sarasota FL and Bermuda NCT-Bases. Thoth-Enki-Zeta Nibiruian Anunnaki 
group via Chihuahua Mexico site sends Psycho-tronic “rapid release” pulse along Amplification Slow-Pulse 
frequency to attack RRT group in hope of preventing September 3 RRT. RRT partially successful.
• 2001  September  7: Sonic Amplification Slow-Pulse continues along Ley Line-4 to intersect/bond with Titicaca Sonic 
Amplification Slow-Pulse at Axiatonal Line-7 (70W Longitude). Bonded Sonic Pulse drawn through Phoenix and 
Falcon Wormholes to SG-3 Bermuda Zeta-Rigelian NCT-Base. Sonic Amplification Pulse charge collects at Bermuda 
NCT-Base.
• 2001  September  11: W T C / P e n t a g o n  U I R  W W 3  ''Trigger Event .'' Sonic Amplification Pulse combined with 
''Trumpet '' long-range remote pulses from Phantom Sirius A, Arcturus and Trapezium Orion ''Dove''APIN. 3 
amplified rapid-fire combined Trumpet/Slow-Pulse sub-space sonic pulses , sent from Bermuda Base to NY and 
DC targets , via the Montauk/ Philadelphia APIN sites of Montauk-Phi-Ex-Falcon Port Interface system . The 
4th ''Trumpet Pulse'' not sent to Philadelphia target, as 4 th terrorist plane ''Cloak Event'' did not make it to site. “ 2001 
September 11 UIR successfully linked/ activated WTC/NYC and Pentagon/DC Phoenix Spike sites to Falcon 
Wormhole and APIN system . Terrorist attacks as “ Cloak Event ” cover to hide Sonic Pulse activity damage to
the WTC and Pentagon buildings.
©2002 Ashayana Deane
521

2001 Update Summary Charts                 
     Sonic Pulse “Un-Natural Disasters” 1935-1992 Summary Chart
 Caused by covert Fallen Angelic/Intruder ET and Illuminati use of scalar pulse technologies 
                                                            Earthquakes:
     Date:                            Location:                Mag.                    Sonic Pulse Action
 1935 May 30                 Quetta, Pakistan           7.5           Zeta Population Reduction Test
 1938 November 10       Alaskan Islands             8.3          Falcon Sonics Test
 1939 January 25            Chillan, Chile               8.3          Falcon Population Reduction Test
 1939 December 26        Erzincan, Turkey          8.0          Zeta-Andromie land dispute
 1942 November 26       Turkey                           7.6          Zeta-Andromie land dispute
 1942 December 20        Erbaa, Turkey               7.3          Zeta-Andromie land dispute
1943 September 10       Tottori, Japan                7.4          Phi-Ex Falcon APIN August 12
1943 November 26       Turkey                        7.6           Phi-Ex Falcon APIN August 12
 1944 December 7          Tonankai, Japan            8.3          Zeta-Andromie Phi-Ex dispute
 1945 January 12            Mikawa, Japan              7.1          Zeta-Andromie Phi-Ex dispute
1945 November 27       Iran                                8.2          Falcon Phi-Ex Port link August 12
1948 October 5             Turkmenistan USSR     7.3          Falcon Population Reduction Test
1950 August 15             India/Tibet                    8.7          Falcon Maji Population Reduction
1952 July 21                  Kern County, CA         7.5           Falcon Illuminati Reduction Demo
1954 September 9         Algeria                          6.8          Falcon A11/L4-10 link August 12
1954 December 16        Dixie Valley, NV          7.3          Falcon Phi-Ex Port link November
1957 March 9                Alaskan Islands            8.8          Falcon Sonics Test
1957 July 2                    Iran                               7.4          Falcon-Dove SG-10 land dispute
1957 December 13        Iran                               7.3          Falcon-Dove SG-10 land dispute
1958 July 10                  Lituya Bay, Alaska       8.3          Falcon Sonics Test
1959 August 18             Montana                       7.3          Phi-Ex Falcon APIN August 12
1960 May 22                 Chile                             9.5          Falcon Maji Population Reduction
1963 July 26                  skopje, Yugoslavia       6.0          Dove APIN site activation
1966 August 19              Varto, Turkey              7.1           Zeta-Andromie land dispute
1968 August 31              Iran                              7.3          Falcon APIN site SG-10 activation
1970 March 28               Gediz, Turkey             7.3           Andromie-Dove raid on Falcon
1970 May 31                  Peru                             7.8           Falcon Phi-Ex Titicaca Port link
1972 April 10                 S. Iran                          7.1           Phoenix wormhole February open
1972 December 23         Nicaragua                    6.2           Phoenix APIN site November 22
1974 December 28         Pakistan                       6.2           Phoenix APIN site November 24
1975 September 6          Turkey                         6.7           Phoenix APIN site August 12
1976 February 4             Guatemala                   7.5           Serpent APIN activation
1976 May 6                    Italy                             6.5           Dragon-Serpent land dispute
1976 July 27                   Tangshan, China         8.0           Dove APIN site SG-8 activation
1976 August 16              Philippines                  7.9           Serpent-Phoenix APIN dispute
(more between 1976-1983 Iran, Italy)
 1983 October 30             Turkey                        6.9          Falcon-Eagle vs Dragon dispute
 1985 September 19         Mexico                       8.1          Serpent APIN site amplification
 (more between 1985- 1992 India, Turkey, Iran)
 1993 September 29         S.India                       6.3           Falcon-Eagle fight Phi-Ex cap
 1998 February 4              Afghanistan               6.1           Phoenix-Dragon APIN site dispute
 1998 May 30                   Afghanistan               6.9           Phoenix-Dragon APIN site dispute
 2001 January 26              India                          7.7           United Resistance raid GA APIN
 
 Sample of Related Hurricanes (many more too numerous to mention, various regions)
    Related to Fallen Angelic/Intruder ET/Illuminati Sonic Pulse and Falcon/Phi-Ex/Phoenix activity  H=Hurricanes
1919  FL, TX –H Falcon wormhole open cycle.     1958  Japan – Typhoon “Vera” Phi-Ex
1935 FL Keys – H Falcon Sonic Pulse                   1960  FL, East US- H “Donna” Phi-Ex
1944  Northeast US – H Phi-Ex                               1965  FL, LA – H “Betsy”  Phi-Ex
1955  Northeast US – H “Diane” Phi-Ex                           1972 Northeast US- H Agnes Phi-Ex amp
1992 August 24, - H Andrew, FL- 215-350mph winds –Zetas ﬁght Aug.12 Falcon Cap
                                                      
                                                   
                                       ©2002 Ashayana Deane  
522
         

                                                                                                                                                                                                                                   
2001 Update Summary Charts