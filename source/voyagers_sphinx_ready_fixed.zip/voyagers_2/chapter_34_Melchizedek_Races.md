34
         
       

                                                                                              Melchizedek Races  
seventh DNA strand. Those bearing the Templar Seals must be assisted by
the Elohim, Azurites, Amonites or their many helpers, in order to pass
through the eighth dimension to heal their DNA of Templar distortion. Oth-
ers who rightfully bear the Templar Seals can find freedom through working
with the lessons of love, unity and equality as taught through the sacred Law
of One. When these lessons are learned, the incarnate's consciousness is no
longer a threat to interplanetary security, and assistance in lifting the Tem-
plar Seals will be provided.    
   Though we will not address the mechanics by which the Templar Seals
operate, we will provide a bit of information regarding the DNA strands
affected. The Templar Seal is a sixth-dimensional seal affecting the second,
fourth and fifth DNA strands. The sixth base tone of strand 2, the sixth over-
tone of strand four and the 12th overtone of strand 5 were all removed from
the morphogenetic field of the Templar-Melchizedek Cloister. The portion of
the Melchizedek Cloister morphogenetic field containing the Seal was
removed from the Sphere of Amenti and placed within the planet core Alcy-
one within the Pleiadian star system, which required the Seal bearer to
evolve within the Pleiadian star system for a time as pure consciousness
before being able to ascend through the Sphere of Amenti to rebirth within
the sixth race on Tara. The fourth strand distortion of this seal created a
polarization within the fourth/heart chakra (which corresponds to fourth-
dimensional frequencies), and a barrier within the Nadial Capsule that sepa-
rates the mental and astral awareness and separates the third/mental body
and fourth/astral body levels within the auric field. It limited astral travel to
the lower astral planes. It created a separation within the astral awareness,
creating a lower  and higher  astral identity. The lower astral identity became
known as the “evil twin”  or the “ dweller on the threshold”  within some
religious teachings. The Second strand distortion created a division within
the D-2 elemental/emotional body, which created two levels of the sub-con-
scious mind, a higher level and lower level. The higher level held identity
fragments of sub-personalities, while the lower level created a chaotic emo-
tional force that came to be known as “the shadow self,”  exaggerating the
human’s primitive emotional impulses. The Second strand distortion also
made it impossible for these humans to successfully interbreed with other spe-
cies from Earth or from the stars. It created an ampli fied blockage between
the first, second and third chakras, blocking out clear communication with
the body consciousness and with the Earth's elemental kingdoms. The fifth-
strand distortion made the physical earthly body unable to transmute or
ascend, so the consciousness would have to rebirth into the sixth races on
Tara to continue evolution.  
    The Templar-Axion Seal  did all of this and more. It is a seventh-dimen-
sional seal which meant that once the consciousness had managed to ascend
to Tara it could not evolve into the seventh races, reclaim the immortal body