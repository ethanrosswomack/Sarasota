69 
                                                                                                                 
                                                                                            

   The Third Seeding  
through an event created at the hands of the Atlantean Templar-Annu. Follow-
ing this event, human culture would enter a long period of digression, as the
planet was placed under intergalactic quarantine, and the previous powers of
advanced civilization were lost. This event of 9,500 BC was the first of several
major setbacks the guardians encountered as they attempted to prepare the races
for the opening of the Halls of Amenti and the mass ascension cycle of 196 BC-
4230 AD. Preparing the races would be no easy task while the Templar-Annu
and their Resistance allies exerted forceful in ﬂuence over the developing human
cultures. Many struggles and hardships would be encountered as the power
struggle between the HU-2 races who upheld the Law of One and those who
placed self-promotion above universal balance, was played out through the evo-
lution of humanity on Earth. Through the evolution of freedom, co-creative
endeavor and unity consciousness that power struggle will one day come to an
end, and peace will be restored to the races of the Third Seeding.  
                  
                        
                       
                                                      70