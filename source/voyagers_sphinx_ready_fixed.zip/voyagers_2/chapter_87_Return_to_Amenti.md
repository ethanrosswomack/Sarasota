87 


                  Return to Amenti
Flame . In order to raise the grid speed, 8% of the total global population had to have
the ﬁfth strand activated, which meant that the Sphere of Amenti could not descend
into Earth’ s core until a concentration of Cloister Melchizedeks had been born . The
second mass birthing wave of Melchizedek Cloister souls was scheduled to
occur around 1500 BC, so the tentative date for the opening of the Halls of
Amenti was set for a period following the 1500 BC Melchizedek Cloister
birthing wave.  
      The Sphere of Amenti was released from D-4 by the Elohim in 2409 BC.
The seventh through 12th base tones of the third dimension, which had been
removed from Earth’s morphogenetic field to create the Frequency Fence,
were readjusted. The eighth through 12th base tones of D-3 were re-entered
into the Earth’s morphogenetic field, reconstructing the Frequency Fence
between the sixth and eighth base tones of the third dimension. This allowed
the Sphere to enter into the UHF bands of D-3 until it was time to open the
Halls of Amenti. Releasing the Sphere from the UHF bands of D-3 did not
require synchronization with a natural dimensional blend period as would
have been necessary if the Sphere remained in D-4.  
     Following the Melchizedek birthing wave of 1500 BC, plans were made
for the opening of the Halls of Amenti. This opportunity would also be used
to begin the reintegrating of the Annu-Melchizedek morphogenetic field,
which was stored in Alcyone under the Templar Seal. It was decided that in
the year 1398 BC an avatar from HU-2 would birth on to Earth through the
Annu-Melchizedek morphogenetic field, then through the Sphere of Amenti
and into the Earth. By passing an avatar soul essence, who carried at least 9-
dimensional frequencies within its personal morphogenetic field, the genetic
imprint deviations in the Annu-Melchizedek morphogenetic field could be
realigned with the HU-2 frequency patterns. This process would serve to
clear the Annu morphogenetic field of its distortions and reintegrate the
Annu back into the Cloister Melchizedek morphogenetic field in the Sphere
of Amenti. Following the birth of this avatar, the Annu peoples would be
released from the Templar Seal and would be able to ascend to Tara with the
unsealed races when the Halls of Amenti opened. The birth of the avatar
would “spark,” or quickly raise the frequency of the Earth grid, which would
in tum cause the Earth core vibrational rate to increase, so a spark would be
released from the Earth core into the Arc of the Covenant, thereby releasing
the Sphere of Amenti into the Earth core.  
    The avatar chosen for this project was a pure Anunnaki soul essence
appointed by the Sirian Council from HU-2 It was necessary for an Anun-
naki to serve this role in order to realign the Annu genetic imprint to its orig-
inal order. The avatar was born in 1398 BC, in the city of Thebes, Egypt, as
the son of a Serres-Egyptian father and Annu-Melchizedek mother. This
child became known as Amenophis IV , son of Pharaoh Amenophis III and
Queen Tiy. When the child was grown he changed his name to Akhenaton