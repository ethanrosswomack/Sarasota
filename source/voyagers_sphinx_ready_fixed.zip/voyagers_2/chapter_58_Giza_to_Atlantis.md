58 
 
                                                                                                                                                                       

                                                                                          
                                                                                              
                                                                       Giza to Atlantis
environment stabilized most of the remaining races returned to the surface to
rebuild. Atlantis again became a cultural center, but never again reached its
previous height of development. Most of the Dracos were evacuated from Earth
by their Anunnaki-Resistance accomplices, and the Templar-Annu continued
to hold their ground within Atlantean and Egyptian cultures.  
    Following the cataclysm of 52,000 years ago the Anunnaki of the Sirian
Council and several other stellar neighbors returned to Earth, assisting the
humans to rebuild. During the explosions beneath the ground the portal pas-
sage to the Arc of the Covenant had been damaged, and the energetic grid
beneath the Atlantean continent was unstable. The Elohim, Ra Confederacy
and other guardian groups from HU-2 restructured the Arc of the Covenant,
moving the portal that connected it to Earth out of Atlantis and into the
regions of Egypt, where the Earth grid structure was more stable. The Serres-
Egyptian races would now share guardianship and control of the Arc of the
Covenant with the Annu-Melchizedeks and Hebrew peoples who migrated
there following the explosions. The cultural hub of Earth was relocated from
Atlantis to Egypt about 51,750 years ago, and Egypt began to thrive.  
                                      
                                        GIZA TO ATLANTIS       
      Anunnaki of the Sirian Council and Earth Protection, the First  
       Building of the Great Pyramid of Giza and the Sphinx, Ankhs,  
           Outpost on Mars, First Birth Wave of Melchizedek Cloister  
                         and Re-establishment of the Law of One.  
                                          48,500 - 35,000 YA           
    Following the relocation of the Arc of the Covenant 51,750 years ago,
Egyptian culture prospered, and Egypt became a center for the Annu-
Melchizedek, Hebrew and Serres-Egyptian guardians of the Arc of the Cove-
nant. Atlantean culture also prospered as the generator crystals were once
again restored to operation after being put out of service during the Lemurian
cataclysm 52,000 years ago. The generator crystals were once again charged
with multidimensional frequency using the Arc of the Covenant in Egypt.
Through this period of rebuilding and expansion the influence of the Tem-
Plar-Annu (Annu whose genetic line had been contaminated by the Templar
Seal through interbreeding with members of the Anunnaki Resistance) con-
tinued to spread, creating a growing chasm between races serving the Law of
One and those falling under the in ﬂuence of the Anunnaki Resistance Tem-
plar Solar Initiates' Creed. In Egypt the Templar-Annu were at first met with
resistance to this influence, and many of them relocated to Atlantis where
the Templar-Annu had a stronger hold over the cultural environment. The
Templar-Annu of Atlantis began using their influence to corrupt the
Atlantean priest cast and eventually the social and moral climate in Atlantis