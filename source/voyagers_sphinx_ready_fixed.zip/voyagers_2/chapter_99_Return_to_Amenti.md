99                                                                                                                      
                                                                                                                                      
                                                                                                                   

   Return to Amenti  
      
  In 7 BC the Elohim orchestrated the birth of a ninth-level avatar, who
would serve to re-integrate the Templar-Axion Sealed souls of Sirius B, back
into the Sphere of Amenti and restructure the patriarchal Templar creed to
be more re ﬂective of the Law of One. This child was named Jeshewua (herein
Jeshewua-9), and the stories of his birth to the Hebrew-Melchizedek Essenes
Mary and Joseph are recorded as the birth of Jesus in contemporary Christian
doctrine. Jeshewua was not born of an Immaculate Conception either, but
rather through the visitation of an ET Nephilim, who, like King Melchizedek
had been, was part of the entity named Jehovah. The entity Jehovah, who
was one of the original contributors to the creation of the Sirian-Anunnaki
races of HU-2, had worked with the Elohim since the time of the Treaty of
El-Annu 848,000 years ago. Jeshewua’s mother Mary was also born of ET
Nephilim conception. Following the events of Akhenaton’s reign, the Elo-
him did not want knowledge of ET ancestry available to the general human
populations, so the truth of Jeshewua’s birth was hidden within the story of
the Immaculate Conception.  Through the centuries that followed the births of the
two avatars, the life stories of Jesheua-12 and ]eshewua-9, plus another man who
was not an avatar, became consolidated into one personage called Jesus Christ.
    With the birth of Jesheua-12, the 12th-level avatar, the Hebrew and
Melchizedek morphogenetic field in Alcyone was reintegrated into the Sphere
of Amenti. Through Jesheua-12 the integrity of the Hebrew Melchizedek
genetic imprint was restored, and he became known by some as the “savior” of
the Jewish peoples for this reason. The portions of the Amenti Sphere that had
been trapped within Earth’s D-2 morphogenetic field, as a result of
Akhenaton’s reign, were realigned and the integrity of the Sphere of Amenti
was once again restored. In a greater sense, Jesheua-12 became the savior for
the races, for through his birth the Halls of Amenti could once again be opened.
The realigned Sphere of Amenti was kept in storage within the UHF bands of
D-3, now under protection of the Azurites of the Ra Confederacy. At age 20 (8
AD), following his study in Persia and India, Jesheua-12 was taken to Egypt by
the Priests of Ur. At the Great Pyramid of Giza, while Jesheua-12 was between
20 and 33 years of age (8 AD through 21 AD), he and the Blue Flame
Melchizedek Essenes secretly orchestrated ascension for various groups, directly 
through the portal passage of the Arc of the Covenant. (Ascensions conducted 
while the Halls of Amenti were closed could only be done through the energy field 
of a 12th-level avatar, whose bio-energetic field could carry the energy fields of 
others through the seals on the Sphere of Amenti. Through the energy fields of the 
avatar, people could pass through the Arc of the Covenant, into the Blue Flame 
of Tara’s morphogenetic field and into Tara.)  
    Through Jesheua-l2, the Hebrew Essene races that followed the Blue
Flame Cloister Melchizedek Essenes were appointed by the Azurites of Ra, to
share guardianship of the Arc of the Covenant with the Melchizedek and
100 
 
 

                                                                                                                 The Three Christs
 
Hibiru Cloisters. The descendants of these groups presently carry the full 12-
strand DNA package within their gene codes, as this group was one of those
chosen in 1972 AD to receive full-genetic realignment through interaction
with the time traveling, hybrid Zionite  race (see Vo y a g e r s  I , p.38). The Zion-
ites were created during the present-day Zeta infiltration and were sent back in
time to realign certain ancestral groups with the 12-strand DNA imprint, in
order to accelerate the evolution of present-day humans. The followers and
descendants of the Jesheua-12 Essenes were one of the groups chosen for this
realignment. Groups involved with Zionite genetic restructuring are consid-
ered to be of Celestial Human lineage as they carry the full 12-strand DNA
Silicate Matrix within their operational genetic codes, regardless of their pri-
mary racial line. (The Silicate Matrix appears within family lines as a recessive
gene composite, which remains dormant until it is called into activation via
opening of chakra centers 8-15.) Various groups within Root Races 3-5 and
Cloister races 3-6, along with several other hybrid race strains, were chosen for
this genetic realignment, so the Silicate Matrix is distributed at random
throughout present-day human genetic lines. The greatest concentrations can
be found within the Hebrew, Melchizedek, Aryan, East Indian and Tibetan
racial lines.  
     During the period that Jesheua-12 practiced in Egypt (8 AD - 21 AD),
the second Christ, Jeshewua-9, grew in popularity among the families of the
Templar Melchizedeks and Hebrew Melchizedeks who were not aware of, or
interested in, the birth of Jesheua-12. Jeshewua-9 was also taken to Egypt for
initiation, ascension training and ordination as a Melchizedek priest, and
portions of these rites were conducted by Jesheua-12. Prior to his ordination
in Egypt, Jeshewua-9 had traveled throughout Nepal, Greece, Syria, Persia
and Tibet, training in various inter-faith doctrines. Jesheua-12 studied prima-
rily in India and Persia before coming to Egypt at age 20 and his Templar
teachings showed a stronger eastern orientation than those of Jeshewua-9.
The training and ascension activities of Jesheua-12 and the Blue Flame
Melchizedek Essenes remained primarily hidden and practiced as a secret
“mystery school” within Egypt at Giza and in various other locations. The
teachings of Jeshewua-9 became more well-known, which caused him pro-
gressively more persecution from Roman inﬂuence and also within some fac-
tions of the Hebrew and Templar-Melchizedek race lines who did not accept
deviations from the original patriarchal Templar creed as set within the Jew-
 ish religion by King Melchizedek.   
         When Jeshewua-9 was 32 years old (25 AD), with the assistance of sup-
portive Templar Melchizedek Essenes, the Elohim exiled Jeshewua-9, his wife
(the woman who came to be known as Mary Magdalene  in Biblical reference),
and their three children to the territories of France, to avoid political persecu-
tion. Another man, by the name of Arihabi,  who was a Jerusalem-born
101 
                                                                                                                       
                                                                                                                    
                                                                                                                 

Return to Amenti  
Hebrew-Annu-Melchizedek, was led by the Elohim, through a series of visions,
to believe that he was the true Jeshewua-9, and this is the man who was cruci-
fied. Neither of the avatar Christs were cruciﬁed, and both of them left genetic
family lines within the Hebrew-Melchizedek  races . The sacri fice of Arihabi was
orchestrated to divert attention away from Jeshewua-9, his family and his lin-
eage. The resurrection of the “body of Christ"/Arihabi, was orchestrated by the
Elohim through the use of holographic inserts, but Arihabi was indeed resur-
rected following the holographic display. In return for his assistance in divert-
ing attention from Jeshewua-9, the body of Arihabi was restored to life by the
Elohim, even though he was not an avatar. He was then taken to India, where
he lived for another 30 years. Upon his natural death, Arihabi’s soul essence
was ascended to Sirius B through the Third Eye of Horus portal bridge. After
his ascension to Sirius B, the Elohim granted him special favor and adjusted his
energy field so he could ascend to the Sirius star system in HU-2 via the plane-
tary core of Sirius A in HU-1. The story of Jesus Christ, as it is known in con-
temporary times, evolved through the mythology the Elohim used to conceal the
identity of their avatar, Jeshewua-9, and to perpetuate their patriarchal slant on
the Templar Creed. The distortions of the true facts of history were used to pro-
tect the lineage of Jeshewua-9 from political persecution, making it appear as if
the Christ had no descendants, thereby allowing those descendants to remain
obscured from the public view . The teachings of Jeshewua-9 and the Templar
Melchizedeks became the primary foundations for both the contemporary Jew-
ish and Christian faiths, but the Jewish religion did not acknowledge Jeshewua-
9 as their savior. In truth, Jesheua-12 was the true savior of the Hebrew peo-
ples, for he re-entered their race morphogenetic field into the Sphere of
Amenti. Few people knew of Jesheua-12 and his Blue Flame Melchizedek Ess-
ene ascension school, so the majority of the Hebrew people did not realize that
their foretold Messiah had, indeed, arrived. Even though Jesheua-12’s accom-
plishments went unnoticed by the majority of the Hebrew people, his affect on
the restoration of their genetic development was valid —an unseen gift to the
Hebrew peoples for which Jesheua-12 did not receive credit.  
    Between 8 AD and 21 AD, while Jesheua-12 practiced ascension rites at
Giza, several expeditions were made by Jesheua-12 and the Blue Flame
Melchizedek Essenes. They traveled throughout Egypt and Nubia and into
Jerusalem, promoting the original Templar teachings of ascension and gather-
ing together groups of people to take to Giza for ascension. Plans were made to
perpetuate the Jesheua-12 lineage, which carried the full 12-strand DNA
imprint, and six women of various Melchizedek Cloister sub-races were chosen
to bring forth the children of Jesheua-12, the First Christ. Couples were cho-
sen to serve as guardians of these children. Each of the six females to receive
the seed of Jesheua-12 was matched to a male Blue Flame Melchizedek who
102 
 

                                                                                        The Three Christs
would serve as adoptive father to the child of Jesheua-12. Jesheua-12 did not
interact directly with the raising of these children, nor did he serve as husband
to any of the six women chosen to carry his seed. The children were created
through sacred procreative rites for the sole purpose of perpetuating the 12-
strand DNA pattern within the human races. Descendants of these children
became spread throughout various regions, some appearing within the French
Aristocracies, others within the Celtic, Egyptian and African genetic lines.
One line of the descendants of Jesheua-12 now resides within the continental
United States. Of the six families of Jesheua-12 that were seeded between 18
AD and 23 AD, five of the children survived to bring the 12-strand DNA lin-
eage into the contemporary human gene pool. The lineage of Jeshewua-9’s
three children also prospered and spread throughout various nations to the
present day. In his later years, Jeshewua-9 traveled to Tibet, where, with the
help of the Elohim, he ascended out of matter in 47 AD to HU-3, through the
portion of Tara’s morphogenetic field stored within the planetary core of  Venus.
(This ascension passage requires a tenth-strand DNA imprint, and is thus not
available to most humans, without direct assistance and DNA reconstruction
by the Elohim, Azurites or other HU-2 guardian groups.)  
    The teachings of Jesheua-12 were highly censored by T emplar
Melchizedeks who later came into political prominence, and were kept alive
through the secret mystery schools that evolved throughout Europe, Egypt, the
Middle East and in certain parts of China and Indonesia. The teachings of
Jesheua-l2 were originally included in the manuscripts that became the Chris-
tian Bible, but were distorted or edited entirely at various times, to suit the
needs of the power elite within the evolving political-religious machine. Even-
tually the teachings were banned by the early Christian churches, for they dis-
closed the identity and tactics of the Elohim and other ET groups, and told of
the divisions within the Melchizedek Templar Creed. Very few of the original
Jesheua-12 teachings have survived into the present time, though there are
remnants of these teachings secretly preserved in France, that will one day be
discovered. The original teachings of ]eshewua-9 were also distorted and mis-
represented through political and religious structures of various times. The
teachings of contemporary Christianity, though they provide a basic structure
upon which social organization and spiritual initiation can be built, reﬂect little of
the depth, content or meaning of the original teachings of the avatar Christs.  
  Following the establishment of Jesheua-12’s lineage (18 AD-23 AD) the
avatar had completed his work on Earth. The Blue Flame Melchizedeks carried
on his teaching legacy and became the primary keepers of the secrets of the Arc
of the Covenant and the Sphere of Amenti. Various groups were assigned vari-
ous portions of the whole story, with no one group having the entire chronol-
ogy of the teachings of Jesheua- 12. Jesheua-12 left Earth through the Arc of the
103 
                                                                                                                                                                                                                               
 

Return to Amenti  
Covenant at 39 years of age in 27 AD. He did not die, but rather bodily
ascended to Tara, and has since evolved far beyond the con fines of physical
matter. The Arc of the Covenant was resealed within the UHF bands of D-3
following his ascension, awaiting the time when Earth’s grid rose high enough
in vibration to allow for the return of the Sphere of Amenti, which was sched-
uled to occur before the mass ascension wave of 2017 AD. The Azurite Coun-
cil, Interdimensional Association of Free Worlds and their many supporters
maintained a stance of non-interference following the success of ]esheua-12’s
mission. They allowed the Elohim and various other Host Matrix Families to
direct the course of earthly events as they desired, knowing that the truth of the
Templar and the Law of One, as upheld by the Blue Flame Melchizedeks and
Priests of Ur, would eventually come to light within the evolving human con-
sciousness. The Azurites planned to wait until the return of the Sphere of
Amenti to Earth's core before bringing this knowledge back into the public
domain, and in the meantime hoped to unite the Melchizedeks within the
teachings of the sacred Law of One.  
    Though Jesheua-12 had successfully aligned the race morphogenetic
field at Amenti with the original 12-strand DNA imprint, most of the races
still carried traces of genetic distortions from the Templar and Templar-
Axion Seals, which would need to be cleared prior to the opening of the
Halls of Amenti. The Elohim, Templar Melchizedeks, Blue Flame
Melchizedeks and many other unrelated Host Matrix groups have assisted,
and continue to assist, many individuals in clearing their genetic codes in
preparation for ascension. All present-day ideologies that teach conscious evolu-
tion, and DNA activation and transmutation, are geared toward this purpose,
including the new information currently being provided by various guardian ET and
metaterrestrial forces.  Jesheua-12, the 12th-level Turaneusiam avatar from
Tara, ful filled his purposes on Earth. Through him the Sphere of Amenti was
made ready for re-entry into Earth’s core, following which the Halls of
Amenti would eventually be opened. The race morphogenetic field had been
reunited, so following the opening of the Halls of Amenti, all souls could
again ascend through Amenti, once their genetic imprint had evolved to
assemble the fourth and fifth DNA strand. The plan for preparing the races
for the 2017 AD ascension wave was put back on schedule. Since 27 AD,
when the avatar Jesheua-12 ascended, the races of Earth evolved under the
primary influence of the Elohim and various other Host Matrix groups not
associated with the Christian and Jewish perspectives.   
    Through the achievements of Jesheua-12 and Jeshewua-9, the primary
morphogenetic imprint for all of the races was returned to the Sphere of
Amenti, and the Sphere of Amenti was once again made whole. These accom-
plishments set the stage for mass ascension, but the races still had a long way to
go in healing and evolving their consciousness and genetic codes. The Fre-
104 

                                                                                      
                                                                                                                The Three Christs
quency Fence quarantine (UHF D-3 seal) still blocked Earth from open rela-
tions with the inter-stellar communities. The Arc of the Covenant D-5
security seal kept all but the Melchizedek race strains from bodily ascension.
The races still carried portions of the Amenti Seal (DNA strands one, two and
three mutation, anti-particle “death” seal), the Palaidorian Seal (DNA strands
two and three mutation, D-4 seal), the Templar Seal (DNA strands two, four
and five mutation, D-6 seal) and the Templar-Axion Seal (DNA strands 1, 5
and 6 mutation, D-7 seal; the “666” seal) within their genetic codes and the
memory of the human lineage still remained locked away within the Sphere of
Amenti in the UHF bands of the third dimension. These conditions would
have to evolve and heal before humanity would be prepared to face the ascen-
sion wave of 2017 AD.  
    Throughout the evolution of the races, guardian races attempted to
awaken humanity to the reality of its evolutionary destiny. All of the major
Earth religions were seeded at one time or another by guardian groups, to help
the races prepare for their eventual ascension out of HU-1. Though the teach-
ings are often quite different or seemingly contradictory and all religions have
suffered manipulation and distortion at the hands of man and covert intruder
ET forces, they are united through their original purpose of achieving ascension
and freedom from the illusions of matter.  
     The secrets of Amenti were ultimately kept under the protection of the Blue
Flame Cloister Melchizedeks and the Hebrew Essenes who followed them, but
the reality of Amenti belongs to all of the races and world religions. The Sphere
of Amenti, Arc of the Covenant and Halls of Amenti represent the manifesta-
tion of the Covenant of Palaidor, which holds the evolutionary promise and pro-
gression for all races of the human lineage. It is the promise of humanity
returning to the integrity of the Immortal God-being that is the original morpho-
genetic imprint of the human race.          
      The promise of ascension is the hidden heritage and legacy of the human
condition, the ful fillment of humanity’s evolutionary blueprint.  
105