15                  

             
             The Secrets of Amenti  
  Each Root Race was responsible for evolving/assembling one strand of
DNA while its companion Cloister Race would hold the imprint of that
strand plus strands 7 —l2. The Cloister Race would appear first and through
this race its Root Race would emerge. The Cloistered Race broke down into
five Cloistered Sub-races, and each sub-race further broke down into five
Cloistered families. The Root Race would then break down into seven sub-
races, and each of the seven sub-races would further break down into seven
families. Soul fragments from the dimension that corresponded to the DNA
strand of the Root Race would be pulled from the Uni fied Field of that
dimension into the body form, progressively pulling the frequency bands of
that dimension into the DNA until all the frequencies of that dimension
were assembled into the morphogenetic field of the body. This process was to
be accomplished within 24 incarnations, i.e., two l2-cycles, that were lived
in one body. With the morphogenetic field in the Sphere of Amenti holding
the pattern for the body form, souls trapped within that dimension could
begin merging their consciousness with the new body form, and through 24
cycles of incarnation pull their consciousness into a pattern that vibrated
high enough to merge with the Sphere of Amenti.  
               Soul fragments would incarnate once then transmute through each of the
seven families of its sub-race, then through each of the five Cloistered fami-
lies of its Cloistered sub-race, building up the lower frequency patterns (base
tones) of that dimension into the DNA through its first 12 transmutations
within the families. Next the now-more-evolved soul would transmute into
each of the seven sub-races of its Root Race, then into each of the five Clois-
tered sub-races of its Cloistered Race, building up the higher frequency pat-
terns (overtones) of that dimension into the DNA. In the final
transmutation, in which all of the frequency patterns for that dimension were
pulled into the DNA and the completed strand assembled, the incarnate
then carried the full base tone pattern of its Root Race and the particle over-
tones of its Cloistered Race within the DNA. In this final phase, the incar-
nate's body, DNA and consciousness would transmute, the base tones and
overtones within the DNA strand merging to create a resonant tone through
which the identity could merge with the Cloister Race morphogenetic field
in the Sphere of Amenti, where it would pick up the remaining “activation”
DNA codes/overtones from the Cloister.  
         The Cloister Race held the higher frequency DNA  codes/overtones for
         that dimension, which match the base tone frequency patterns of the body
 double in the parallel Earth (these are called the Activation Codes, as they