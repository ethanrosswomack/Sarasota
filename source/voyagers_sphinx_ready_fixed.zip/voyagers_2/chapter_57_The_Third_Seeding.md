57 
 

 The Third Seeding                                                                                                                                                               
                                             LEMURIA DESTROYED  
        Anunnaki Resistance,  Annu and the Dracos, Destruction of Lem urian
                     Muarivhi, & Relocating the Arc of the Covenant  
                                               55,000 - 51,750 YA  
     
   As Atlantean and Lemurian cultures thrived, other stellar cultures
watched and waited. Members of the Anunnaki Resistance and their Drakon
and Dracos allies had long planned to overtake Earth territories, waiting until
the growing civilizations had reached a height of maturity. Motivated by their
own desires to utilize Earth as an evolutionary option, the Anunnaki Resis-
tance quietly infiltrated Atlantean culture about 55,000 years ago, covertly
moving within the ranks of Anunnaki of the Sirian Council. Once re-estab-
lished on Earth, the Anunnaki Resistance inter-bred with the Annu, and
over a period of generations distorted the Annu genetic lines with the Tem-
plar Seal (which had been placed on the Anunnaki Resistance following
their refusal to accept the Treaty of El-Annu). The teachings of the Law of
One were slowly distorted as the creed of the Templar Solar Initiates of Tara
(which the HU-2 Anunnaki Rebellion had helped devise), came to replace
the sacred teachings, creating division and social unrest within Atlantean
civilization. The Anunnaki-Annu began to spread their influence into other
cultures, gaining covert control over Egyptian lands and several other smaller
cultural centers.  
    About 52,000 years ago the T emplar-Annu allowed the Resistance allies,
the Dracos, to secretly return to Earth, promising them an earthly home if
they would assist in infiltration of the Earth cultures. The Dracos in filtrated
the Lemurian continent of Muarivhi, creating an extensive network of
underground lairs within the tunnel systems that ran between Lemuria and
Atlantis. Systematically the aggressive Dracos began terrorizing the Lemurian
culture, extending the reign of terror into Atlantis and various other places.
Meetings were held by representatives of all the races through which a plan
was devised to end the Dracos problem. The humans hoped to use the gener-
ator crystals to create small, pin-point explosions within the underground
caverns in order to seal the Dracos within their lairs until the Sirian Council
could come and evacuate the Dracos. But the plan back- fired, as the Earth
grid became energetically overloaded by energy from the generator crystals
and a massive explosion occurred within the lands beneath Muarivhi. The
explosion destroyed the land mass of Lemurian civilization and remnants of the
Lemurians integrated into Atlantean territories.  
      The explosion caused massive volcanic activity , earthquakes and ﬂoods,
and though the Atlantean continent did not suffer massive destruction, it took
generations for them to rebuild, and for the Earth to rebalance her grid. A small
period of ice followed these events, during which most of the races retreated
underground, some permanently entering the Inner Earth. After the surface