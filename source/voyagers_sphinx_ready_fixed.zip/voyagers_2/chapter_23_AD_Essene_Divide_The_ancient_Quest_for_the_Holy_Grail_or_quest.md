23 AD Essene Divide. The ancient “ Quest for the Holy Grail ,” or quest
          for control over the Star Gates of Earth’s Planetary Templar, and the At-
           lantian Conspiracy agendas continued....  
     •  Despite Victorous’ (“Merlin’s”) frequent betrayals of his Emerald Covenant
         agreements, Arthur, Guinevere  and the Knights of the ''Rainbow
           Roundtable '' completed one phase  of their Emerald Covenant Mission.
           They were successful in retrieving the Rod  star gate tool and Signet
           Shield-11  from the Luciferian Knights Templar Annu-Melchizedek Illu-
          minati Humans. Arthur relocated the Arc of the Covenant Gold Box
         with Rod, Staff and Signet Shield-11  to their intended destination at the
            control center for Star Gate-11,  in the lands once called Lohas Atlantis.
            The authentic  Arc of the Covenant Gold Box with its star gate tool con-
         tents, still remains, under Maji Grail King protection, where Arthur bur-
          ied it in 608. 
   •  Arthur and his Knights were unable  to fulfill the entire Emerald Covenant
          Mission of disengaging  the 25,500 BC Nibiruian Diodic Crystal Grid
          network at Stonehenge, England,  to free Solar Star Gate-4  from remote
          Nibiruian Anunnaki control, in  preparation  for the anticipated 2000-
         2017 SAC  and intended fulfillment  of the Planetary Christos Realign-
         ment Mission.  
  •  Since King Arthur buried the Arc of the Covenant Gold Box in 608 AD,
             the Luciferian Knights Templar, Jehovian and Drakonian Annu-
           Melchizedek Illuminati Human lines have quested  to claim the Arc of the
           Covenant Gold Box from its resting-place in Lohas Atlantis. To conceal
          knowledge of the unidentified Lohas-Atlantis location of the Arc Box un-
          til it could be located and confiscated, the Luciferian Knights Templar,
         under direction of Galactic Federation , began a crusade to destroy or dis-
         tort any remaining records of Atlantis.  Further distortion of historical
         records and intentional “planting” of falsified Atlantian Maps were tac-
          tics used to deter competing Illuminati Human forces  from retrieving the
             Arc Box, and thus control of Earth’s Templar, before the Luciferian
          Knights Templar could stake their wrongful claim.  
 • After the 608 AD Arthurian Grail Quest, competing Illuminati Human
          Annu-Melchizedek races progressively rose to positions of political power
         within the global arena, launching continuing campaigns of disinforma-
         tion, historical distortion, Genocide Crusades against  each other and
          against Angelic Human and Maji Grail King 12-Tribes  races. In 1244
          AD the Cathars, Maji Grail King  families of southern France were de-
           stroyed by the Omicron-Drakonian held Church of Rome in the Albigen-
               sian Crusade.  Many murderous crusades followed, including the      
        
         316   
                

                                                    King Arthur and the Knights of the Roundtable        
         decimation of the Bruah-Atlantis and Mu’a-Lemuria Maji Grail King
          Amerind  lines of North America,  in the European quest for the '' New
           World .'' 
      • It was long known among the competing Knights Templar, Jehovian and
         Nephedem  (Omicron-Drakonian) Annu-Melchizedek Illuminati Human
          inner circles  that the “New World” of America  was the Old World  of
              which Bruah-Atlantis,  the location of the central control site ''Gru-AL
           Point '' for Earth’s Planetary Shields, was once part. The competing quests
          for control of Lohas-Atlantis-Star Gate-11,  the Bruah-Atlantis Gru-AL
            Point  and the other Star Gate locations  in Earth’s Templar Complex
         have been at the heart of the continual con ﬂict and race hatred and do-
         minion campaigns throughout our recorded human history.  
     • The three competing factions of Annu-Melchizedek races, representing the
          Luciferian, Jehovian and Drakonian Dominion Agendas , emerged from
           our ancient pre-Atlantian past,  through Lemuria, Atlantis and our early
           recorded history into the powerful global infrastructure  of the contem-
            porary Interior World Government Illuminati One World Order Agenda.
            As part of the planned, pre-meditated Atlantian Conspiracy strategy, in
           1750 AD the Galactic Federation and Pleiadian-Nibiruian Luciferian
  Anunnaki  races began making remote contact  with “Chosen Ones,” de-
   scendants of their respective Annu-Melchizedek Illuminati races, who
    carried the DNA Template implantation  allowing for telepathic rapport
   from their genetic ancestral line. After rising to covert power in Europe
   and various other regions, Galactic Federation and the Pleiadian-Ni-
   biruians motivated the American Revolution  and the founding of the
 United States of America via Secret Society Occult School  “inspiration”
of their Luciferian Knights Templar Annu-Melchizedek Illuminati rac-
 es. This contact progressed from in filtration of ancient traditional reli-
 gious control dogmas  with their “Inner Circle Elite” Occultists, into what
 has become the “ New Age Channeling Movement.”  The New Age
 Movement is primarily dominated by Jehovian-Sirius A, Luciferian-Pleia-
 dian-Nibiruian, Marduke-Necromiton-Luciferian-Alpha  Centauri and Sirius
 B, Luciferian Centaur-Omega  Centauri  and some Necromiton-An-
 dromie channel contacts . 
   • Following covert surveillance  that began in 1916, the Zeta  (“Little Grey”)                                                                                                    
races began physical interaction with Earth on behalf of the Zephelium
         (reptile-insect) Drakonian Agenda  races of Orion. In the 1930s and
        1940s  Illuminati Human Annu-Melchizedek descendants of the Zepheli-
        um-Zeta, Omicron-Drakonian (''Dragon-Moth'') and Odedicron (Rep-
        tile-Avian) Drakonian Agenda races of Orion entered One World Order
         Dominion Treaties  with the Orion Zeta Rigelian  races. The Zeta Trea-
         ties  initiated the formation of '' Majestic-12 '' which began the “ contact
          phenomena ” of what has become the contemporary '' UFO Movement. ''
        In 1 983 the Orion Omicron and Odedicron Drakonian  Agenda Legions
          assumed the leadership role in the Zeta Treaty agreements.  
       • In the 1930s the Necromiton  (Beetle-reptile-insect-hominid) races of An-
            dromeda  became involved with certain factions of the Drakonian Illumi-
        nati Human Interior Government, initiating the '' Men in Black ''   
                                                                                                                         
       317

                                                                                                                                                                                  
   The Atlantian Conspiracy and Roundtables                                                                          
        
             phenomenon; some assisting the Luciferian Pleiadian-Nibiruian races of
            the Luciferian Covenant,  others supporting the Drakonian Agenda races.
   • In November 1992, the Emerald Covenant Maharaji Blue Human and
         Azurite  races of Sirius B, the Serres-Pleiadian  (avian-hominid) races of
          Alcyone and the Lyran-Sirian Anuhazi  (feline-hominid) Founders races
   negotiated the Pleiadian-Sirian Agreements.  In these agreements the
   Luciferian Pleiadian-Nibiruian Anunnaki  races, Galactic Federation
  and a few Jehovian-Anunnaki  races agreed to enter the Emerald Cove-
  nant  peace treaty for co-evolution with the Angelic Humans of Earth in
  a united stand  against the Drakonian Legions’ Anti-Christiac Dominion
  Agenda. The Anunnaki races  vowed to assist in the 2000-2017 SAC
   Emerald Covenant Planetary Christos Realignment Mission.  They
  promised to disengage Nibiruian Diodic Crystal Grid  control of Earth’s
  Templar and to return Solar Star Gate-4  control over to the Founders’
 Emerald Covenant races by 2000, to prevent the scheduled pole shift that
   Galactic Federation had intended to orchestrate as per the Atlantian
 Conspiracy Luciferian Covenant.
  • In January 2000,  when the SAC commenced, most of the Anunnaki Le-
  gions defected  from the 1992 Pleiadian-Sirian agreements, reverting to
their Luciferian Covenant Dominion Agenda. On July 5th , 2000  further
negotiations with the Anunnaki legions culminated in their return to the
Emerald Covenant via an agreement called the Treaty of Altair;  they
were required to release the Nibiruian Diodic Crystal Grid and Solar Star
Gate-4 by August 2000.
  • On September 12th,  2000 the Necromiton Andromie “Men In Black”  of-
          fered co-conspiratorial deals to Luciferian and Jehovian Anunnaki and
          Drakonian races. Galactic Federation  and most members of the Anunna-
          ki legions defected from the Treaty of Altair  to join the United Resis-
          tance (UIR) . The UIR is a co-conspiratorial plot  through which
          Resistance Legions intended to covertly evacuate small numbers  of their
          respective “Chosen Ones” and “clear Earth’s real estate” via pole shift  be-
           tween 2003-2008,  to achieve fulfillment  of the Luciferian Covenant
          Atlantian Conspiracy Agenda between 2008-2012 .
  • On September 12th, 2000 the UIR  Legions  issued an edict of war  against
          Emerald Covenant Guardian races if they did not withdraw support  for
          the Angelic Human 12-Tribes  of Earth. Guardian Nations refused to
         abandon humans  and Earth to Fallen Angelic dominion and exploitation.
         We are now facing the Final Con flict drama  of the ancient Atlantian
         Conspiracy .
  • As the Atlantian Conspiracy advanced from the 9558 BC Atlantian Flood,
          Emerald Covenant  races  knew that the 2000-2017 Stellar Activations
           Cycle  would be the time for  fulfillment of the  Planetary Christos Re-
           alignment,  and that if negotiations with Fallen Angelic legions were not
         successful the Final Conflict drama  would ensue. In preparation for these
         anticipated events,  the Maji Grail King lineage  Indigo Children Types-
            1 and 2  have been incarnating on Earth for the past I00 years. The Maji
           races are here to assist the Angelic Human 12-Tribes of contemporary   
  318  

                                   
                                Progression of Major Events in the Atlantian Conspiracy
  Earth  in completing the Emerald Covenant Mission that King Arthur,
        and Essene Jesheua before  him, were unable to fully complete.
   • To prevent pole shift  in the 2003-2008 period, the Nibiruian Diodic
Crystal Grid  of Stonehenge, England and Earth’s Star Gate-11  must be
re-calibrated  using early activation of D-6 Sirius B Star Gate-6  to over-
ride the D-4 Nibiruian Alignment before 2003 . This will release the D-4
Solar Spiral  from Nibiruian control, preventing the massive  pole shift the
UIR intends. This is the Sacred Mission that Essene Jesheua  (Jesus
Christ), King Arthur  and many Maji Grail Kings before them were at-
tempting to accomplish.
    • Once the Nibiruian hold on Earth is released, the Planetary Christos Re-
  alignment Mission  can be completed  if the Angelic Human 12-Tribes of
  Earth  can successfully “ Run the RRT .” Running Earth’s RRT can be
   done only by the Angelic Human and Maji Grail Line 12-Tribes of
    Earth , whose DNA Templates  carry the DNA Signet Codes  that corre-
 spond to the  correct  Fire Letter Sequences  in Earth’s Planetary Shields.
  Through completing the Christos Realignment Mission by “Running the
   RRT” Star Gate Signet Councils today, the ancient Anti-Christiac At-
  lantian Conspiracy  One World Order Dominion Agenda of the contem-
  porary UIR can be overcome in our present time period.
                            
                              PROGRESSION OF MAJOR EVENTS
                             IN THE ATLANTIAN CONSPIRACY
• 50,000 BC- Lemurian Holocaust: Jehovian Anunnaki  and their Annu-
        Melchizedek Urantia  Illuminati Humans infiltrate Lemurian Muarivhi,
        allow Dracos²  infiltration, culminates in destruction of Muarivhi Pacific
        Continent.
    • 28,000 BC-Atlantian Holocaust: Sirius A Jehovian and Pleiadian-Ni-
        biruian Luciferian Anunnaki and their Annu-Melchizedek Illuminati Hu-
         mans attempt to seize Inner Earth and Atlantis, culminating in cataclysm
         that reduces Atlantic Continent to  three Island Nations: Bruah, Nohasa
        and Lohas.
   • 25,500 BC-Lucifer Rebellion: Nibiruian Marduke-Anunnaki ³ race line
         seize control of Nibiru and D-4 Solar Star Gate-4,  begin Anunnaki Race
        Unity dominion campaign and plant Nibiruian Diodic  Crystal Grid Plan-
         etary Templar Control Network in at Stonehenge, England  (before
         ''Standing Stones''). Anunnaki races infiltrate Bruah, Nohasa and Lohas
         Atlantis.
        • 22,326 BC-Eieyani Massacre: United Pleiadian-Nibiruian Luciferian
        Anunnaki and Marduke-Anunnaki  decimate  Eieyani Maji Races at
        Kauai, Hawaii  location and seize major territories of Bruah and Nohasa
          Atlantis , sending Atlantian Semoli-Bruah and Druidec-Nohasa Maji
        Grail King races into exile  to Lohas, Atlantis and Ionia ( Italy, Greece)
   
     ________________________
   2.    Omicron-Drakonian + Human
   3.    Anunnaki + Omicron Drakonian
  319
  
   
                                                                                                        
                                         

                             
   The Atlantian Conspiracy and Roundtables
• 21,900 BC-Lohas-Celtec-Druidec Freeze Out: Pleiadian-Nibiruian Lucifer-
       ian Anunnaki and Galactic Federation intentionally collapse Firmament
       Hydro-suspension Field over Lohas, Atlantis to force Maji Grail King
       lines away from Lohas Star Gate-11; culminates in 21,900 BC-14,000 BC
      Glacial Period.
       . 20,000 BC-Vicherus-Sacheon Invasion: Alpha-Centauri Marduke -Necro-
       miton-Anunnak i and their Vicherus Annu-Melchizedek  race and Pleia-
          dian-Nibiruian Samjase-Luciferian-Anunnaki  and their Sacheon
      Annu-Melchizedek race invade Angelic  Human Tribe-6  and exiled
        Celtec-Lohas and Druidec-Nohasa Atlantian Maji Grail King lines in
       Caucasus Mountains, Russia , in attempt to destroy Grail Lines . Begin
      intentional concealment of Celtec and Druidec Atlantian Maji Grail
      King and Angelic Human Tribe-6  racial identity. The Vicherus races he-
        came known as the '' Vikings ,'' the Sacheons  as the '' Saxons ,'' both
      groups often “ painting themselves blue ” in honor of the Luciferian Al-
      pha-Omega Centauri Centaur race . In order to hide knowledge of the
       Atlantian Maji King Grail Lines, the “blue raiders ” were later falsely
      identified in historical record as the “Celtics”  of Ireland, the Druidecs as
      the ''Druids.''
  •  10,500 BC Luciferian Conquest: Atlantian Islands of Bruah and Nohasa
        fall to Pleiadian-Nibiruian Luciferian and Sirius A Jehovian Anunnaki
       and Annu-Melchizedek control; the Atlantian Conspiracy  develops  high
      level organization.
 •  9,560 BC Luciferian Covenant: Pleiadian-Nibiruian Samjase-Luciferian
        Anunnaki  (“Blonds”), Sirius B Marduke-Anunnaki  (Anunnaki + Omi-
        cron “Dragon-Moth”), Enlil-Odedicron (Anunnaki + Reptil e-Avian),
         Thoth-Enki-Zephelium  (Anunnaki + Zeta) and Marduke-Necromiton-
       Luciferian (Anunnaki + Alpha-Omega Centauri Blue Centaurs), Galac-
       tic Federation and Nohasa Atlantis Jehovian-Urantia  and their respec-
        tive Annu-Melchizedek races enter full alliance under the One World
         Order Anti-Christos Agenda  formally mandated through the Luciferian
        Covenant. Omicron-Drakonian and Odedicron-Reptilian races of Orion
       form second competing Orion-Drakonian One World Order Agenda.
       Main Sirius A Jehovian-Anunnaki (“Bipedal Dolphin People”) race form
       third competing Jehovian One World Order Agenda.
•  9,558 BC Atlantian Flood: Luciferian-Anunnaki  and portions of  Galactic
      Federation  orchestrate Atlantian Flood in an attempt to take over  Giza,
      Egypt Great Pyramid Teleport Station and its true Arc of the Covenant
      Andromeda Portal Passage. Thoth-Enki  Annu-Melchizedek Illuminati
       Humans that took over Bruah Atlantis  follow initiatives of the Samjase-
       Luciferian-Anunnaki '' Larsa King '' that took over Lohas Atlantis,
         sending EM Pulse from Bruah Generator Crystals to Giza, causing major
      ﬂooding via final collapse of Firmament Hydro-suspension F ield over No-
       hasa and Bruah Atlantis. Only portions of the Atlantian Islands sink; ma-
       jor parts of Bruah, Nohasa and Lohas  Atlantis still remain above water.
      In 9540 BC  the Sirius B Maharaji Blue Human Emerald Covenant Races
      give Rod and Staff  Star Gate Tools in “Arc of the Covenant Gold Box”
      to Maji Grail King  lines of Earth to keep open contact with Inner Earth
 320 
   

                                  
                               Progression of Major Events in the Atlantian Conspiracy
       races via Earth’s portal system. Luciferian, Jehovian and Drakonian quest
       for possession of the Arc Tools  begins, as does intentional falsification
       and eradication  of Angelic  Human historical  record  to conceal the
       knowledge and location of Lohas Star Gate-11 , the lands of which sur-
       vived the Atlantian Flood.
•  8,900 BC Sumerian Invasion: Luciferian and Jehovian Anunnaki and Dra-
       konian  Races and their Annu-Melchizedek legions all raid Angelic Hu-
      man Tribe-10 resettlements of Sumerian UR  and surrounding territories
        (Iraq-Iran) in quest for Star Gate-10  control and Arc of the Covenant
       Gold Box Tools . Samjase-Luciferian-Anunnaki lines as “Sumerian Larsa
      Kings. ” Jehovian Anunnaki lines as “ Hassa Kings and Midianite-Hyk-
       sos Kings, ” Marduke-Anunnaki and Drakonians as Babylonian and
       Akkadian Dragon Kings,  Thoth-Enki-Anunnaki as '' Snake Brother-
       hood Kings .'' Evidence found in Sumerian “Larsa Kings List” tablets.
•  8,400 BC Egyptian Invasion: Thoth-Enki-Zephelium-Anunnaki and their
       Bruah-Atlantis Annu-Melchizedeks raid Egypt from Sumeria , over-
       throwing Serres-Egyptian Pre-dynastic Grail King lines as the Osirius
       King  line. Enlil-Odedicron-Anunnaki  combine, creating the Osirius-
       Isis-Horus King Line, Samjase-Luciferian-Anunnaki Sumerian Larsa
      Kings  combine creating the Egyptian “ Scarab King ” line that dominated
        Dynastic Egyptian History in competition with the Marduke-Anunnaki
       Drakonian Agenda '' Set King '' line. With Galactic Federation  assis-
        tance, Jehovian-Anunnaki Annu-Melchizedek Midianite-Hyksos King
      lines later invade in 1670 BC,  leading to the “Exodus” in 1476 BC  un-
       der Tuthmosis III.
•  7,500 BC Knights Templar Invasion:  Luciferian Covenant Anunnaki races
      raid Celtec and Druidec Maji Grail King races that returned to Lohas At-
       lantis territories in 13,000 BC from exile in the Caucasus Mountains, Rus-
       sia. Forced interbreeding between Nibiruian Thoth-Enki, Pleiadian-
        Nibiruian Samjase-Luciferian and Alpha-Omega Centauri Marduke
      Necromiton-Luciferian Anunnaki Annu-Melchizedek Illuminati Human
      lines and Maji Grail King lines for Illuminati race DNA Template up-
      grade. Creates Luciferian “Super-race” Knights Templar-Sumerian Larsa
        King + Egyptian Osirius-Isis-Horus Scarab King+ Egyptia n-Midianite
      Hyksos King + Indian Centaur King Annu-Melchizedek Anunnaki plus
        Celtec-Druidec Atlantian Grail King (forced interbreeding). Ancestors
       of contemporary Freemasons.
•  5,900 BC Centaurian War: Luciferian Anunnaki Races steal Arc of the
        Covenant Gold Box and Star Gate tools, attempt to cause pole shift from
           Nibiruian-Diodic-Crystal Grid at Stonehenge, England, to claim Earth’s
                    territories. Omicron-Drakonian, Alpha-Centauri Luciferian Centaurs,
           Marduke-Anunnaki and Jehovian Anunnaki races begin counter attacks
       in England, India, Egypt, Tibet, Ionia and North America. Sirius B Maha-
       raji Blue Human Emerald Covenant Races intervene with air raids to stop
       Luciferians’ use of the Arc Tools for pole shift. Maji Grail Kings retrieve
       Arc Box. Partly recorded in Sanskrit Mahabharata Texts.
  321
      
                                                                                                            
                                                                                                                             

                                   
 The Atlantian Conspiracy and Roundtables
  •  3,650 BC Mayan Raids: Luciferian Anunnaki raid Mayan Angelic Human
  12-Tribes in Yucatan and progressively infiltrate selected 12-Tribes settle-
   ments throughout South, North and Central America.
 • 3,470 BC Babble-On Massacre: Galactic Federation and Luciferian Pleiadi-
    an and Nibiruian Anunnaki races steal Arc of the Covenant Gold Box
  and star gate tools, attempt world dominion beginning in Marduke-Anun-
  naki Drakonian-held Babylon. Temporary planetary magnetic grid col-
    lapse created, using Arc tools at Babylon and Nibiruian-Diodic-Crystal-
    Grid at Stonehenge, England, to create reverse-Fire-Letter-Sequence dis-
  tortions in Earth’s Planetary Shields, which caused major mutations in the
  function of the Angelic Human DNA Template. Erased Race Memory,
  blocked natural Kundalini ﬂow in body causing Pineal, Thalamus, Hypo-
    thalamus and Thyroid Gland malfunctions that shorten human life span
    and block interdimensional perception in all but implanted Annu-
          Melchizedek “Chosen Ones” and scrambled natural language patterns.
    Recorded as “Tower of Babel” story in Bible. Grail King races retrieve Arc
        of the Covenant Box and Tools, preventing advancement of world do-
  minion through intended pole shift.
 • 2,668 BC Djoser Invasion: Galactic Federation, Luciferian and Jehovian
   Anunnaki infiltrate Sakkara, Egypt,  with Pharaoh Djoser and their Lu-
   ciferian Knights Templar  “Super-race” and Midianite races of Israel and
   Sumeria. Serres-Egyptian-Lohas Atlantian Grail King Pharaoh Imhotep
  deposed in peaceful surrender. Imhotep remains with Djoser regime as
    “lesser of the apparent evils” compared to the Marduke-Anunnaki Drako-
     nian Agenda invasions progressively advancing from Babylonia.
  • 2,024 BC Dead Sea Conquest: Galactic Federation and Luciferian Anun-
   naki  races steal Arc of Covenant Box and Tools again, launch world do-
  minion campaign again in Babylonia, extending into Dead Sea area
    between Israel and Jordan. Destroy Sumerian cities once located in Dead
    Sea region. Recorded as “ Destruction of Sodom and Gomorrah”  in the
    Bible. Maji Grail King races retrieve Arc of the Covenant Gold Box and
     tools, preventing spread of Anunnaki world dominion.
 • 1670 BC-1550 BC Hyksos Invasion: Medianite-Hyksos King  Jehovian
 Annu-Melchizedeks cross with Luciferian Knights Templar Anu-
  Melchizedeks from Sakkara, Egypt Djoser  lineage. Infiltrate Egypt from
   2668 BC and finally take over Egyptian Dynasty as Hyksos Kings in 1670
  BC.  1550 BC  Drakonian Agenda Pharaoh Ahmose deposes last Hyksos
  King Pharaoh Kamose, leading to 1476 BC Hyksos Exodus  under Dra-
  konian Agenda Pharaoh Tuthmosis III.  Under Galactic Federation di-
   rection, Hyksos intend to invade and destroy Angelic Human Hebrew
  Tribe-2 in Israel.
  • 1459 BC Israel Crusade: Hyksos  from Exodus instructed by Galactic Feder-
    ation and Luciferian Anunnaki  to use stolen Arc of the Covenant Gold
     Box Star Gate '' Rod and Staff '' tools to destroy Hebrew Angelic Human
    Tribe-2.  Intend to claim Israel  as their “Promised Land” as beginning of
     intended global dominion pole shift Luciferian Covenant agenda. Serres-
     Egyptian Maji Grail Kings  exiled in desert retrieve  Arc of the Covenant  
322 
      

       
                                                    Progression of Major events in Atlantian Conspiracy
       
            Gold Box and tools  preventing the Hyksos’ destruction of Hebrew Tribe-
            2. Hyksos do not get their “Promised Land,” the story of the Hyksos Exo-
            dus intentionally integrated into Hebrew and Christian historical teach-
            ings to conceal  Hyksos Annu-Melchizedek presence.  
                         • 1458 BC Hatshepsut Invasion: Serres-Egyptian Maji Grail King Pharaoh
Queen Hatshepsut  of Egypt receives Arc of the  Covenant Gold Box  and
tools from desert Maji Grail kings after they stop Hyksos Israel Invasion.
Her part-Drakonian half-brother Tuthmosis III  invades Hatshepsut’s
     Temple and steals Arc Box.
         •  1353 BC Fall of Akhenaton: Attempt to enter Hyksos-Egyptian King line
into Serres-Egyptian Maji Grail King  line for Galactic Federation-Hyk-
sos Emerald Covenant entry and Hyksos genetic Bio-Regenesis Program.
Pharaoh Akhenaton  fails in his intended Emerald Covenant Mission in
favor of Anunnaki Luciferian Agenda  and is killed by competing Drako-
nian Agenda Uncle. Galactic Federation  defects from Emerald Cove-
nant.
              • 906 BC Fall of Solomon’s Temple: King Solomon,  (Hyksos Annu-
Melchizedek + Serres-Egyptian Maji Grail Line), son of Hyksos King
David , is guided by Galactic Federation  to use stolen Arc of Covenant
Gold Box tools  to destroy Hebrew Angelic Human Tribe-2 races of Israel
to claim “Promised Land” and advance global dominion . Pleiadian-Serres
Emerald Covenant race of Alcyone  intervenes directly with beam ship,
intending to teleport Arc Box and tools  out of Solomon’s Temple  and
return it to Maji Grail king protection, preventing Solomon’s assault on
Hebrews and advancement of the pole shift agenda. Galactic Federation
attempts to teleport Arc Box to their Pleiadian Ship but miscalculate , de-
stroying Solomon’s Temple  completely with a Photo-Radionic Wave          
beam . Pleiadian-Serres retrieve Arc Box and prevent pole shift agenda.
             •  26 BC Roman Invasion:  Omicron-Drakonian  legions of Orion  move their   
Nephedem Annu-Melchizedek Illuminati  races into political power
within the Ionian Empire of  Italy, deposing Angelic Human Tribe-5  
 of Italy and Ionian exiled  Celtec, Druidec  and Seminol  Atlantian Maji             
      Grail Kings to create stronghold of Roman Empire  dominion. Progres-
 sively infiltrate and transpose their race identity  over the Angelic Hu-
 man Tribe-5 and Maji Grail Line Ionians of Italy  and begin corruption 
 of Ionian Grail Kings’ Sacred CDT-Plate Spiritual Teachings  to create
 the foundations for the “ Church of Rome ” Catholic Religious Control 
 Dogma political machine. 
                 •  23 AD Essene Divide:  Galactic Federation  unites groups of Luciferian
  Hyksos King  and Jehovian Hassa King  Annu-Melchizedeks  to raid Em-
  erald Covenant Mission of Maji Grail King Essenes , Jesheua (Jesus
   Christ), John the Baptist and Miriam  in Tel el Amerna , Egypt . Due to 
   Essene Divide raids, Jesheua’s Grail King Essenes are unable to fulfill in-
  tended mission of disengaging the  Nibiruian Diodic Crystal Grid  to free 
   Solar Star Gate-4  and Earth’s Star Gate-11 to  prepare for the 2000-2017
  AD SAC and scheduled Planetary Christos Realignment Mission. The Maji 
    Essenes had fulfilled part of the mission by reclaiming  the Rod Star Gate     
323
                                                                                                                                                                                                             

                                             
                   The Atlantian Conspiracy and Roundtables
tool and its Arc of the Covenant Gold Box  from  Galactic Federation’s        
Noah-Abraham-Moses Hyksos Annu-Melchizedek  illuminati line, but       
could not recover the Staff tool. Following failure of the intended Plane-       
tary Security Mission, Jesheua, John, Miriam and several Maji Grail King      
Essenes hid Arc of the Covenant Gold Box  and its Rod tool in Vale of       
Pewsey, England  via Tel el Amarna Inner Earth portal  passage.  
•	325 AD Council of Nicaea : Omicron-Drakonian legions motivated their       
     Nephedem Annu-Melchizedek Illuminati races governing the Roman      
      Empire  to temporarily join forces  with Galactic Federation  and the Ple-     
      iadian-Nibiruian Anunnaki . In this unholy alliance , the Nephedem, Lu-      
      ciferian Knights Templar, Hyksos King and Jehovian Anunnaki Hassa      
    King Annu-Melchizedeks assembled to '' come up with a cover story '' to      
      hide from public record the realities of Jesheua’s Emerald Covenant Mis-      
      sion . Groups of Hassa King Rabbis , Hyksos Kings  and Knights Templar     
      Priests , and Roman Nephedem Knights of Malta  launched a Crusade to         
      confiscate all records  of the Emerald Covenant Essene CDT-Plate trans-      
    lations. They combined various elements of true history and spiritual      
      teachings with numerous falsifications  and massive omissions of Templar         
      and Ascension teachings, to create the patriarchal, false-God control      
      dogma creed  that became the “ Canonized Bible ”. Their intentions were      
    to forcefully hide all knowledge  of the Emerald Covenant Christos Re-      
      alignment Mission while they searched for the Arc of the Covenant  Gold      
      Box. They intended to claim the Arc Box and prevent the “common peo-      
    ple”from having the Maji Grail King knowledge of the Roundtables , to     
    insure victory of their Anti-Christiac One World Order  dominion agen-               
      da during the 2000-2017 SAC .  
•	608 Arthurian Grail Quest:  Maji Grail King Arthur  (born 559AD) and the             
   ''Knights of the Round Tabl '' were the Maji Grail King Melchizedek                 
   Cloister Regents  who protected the “ Holy Grail ” Knowledge of Earth’s       
   Planetary Templar Complex. Arthur, Guinevere and the Roundtable             
   Knights held the Planetary Security Commission of reclaiming the Staff       
   tool from the Hyksos Illuminati and were intended  to run the RRTs to            
   disengage the Nibiruian Diodic Crystal Grid , in fulfillment of the            
   Jesheua-John-Miriam Emerald Covenant Mission. Though Merlin  assist-       
   ed in the return of the Staff  Star Gate tool (the “ Sword Excalibur ”) to      
   Maji Arthur’s protection,''Merlin'' (Victorous) later betrayed the Emer-       
   ald Covenant Mission in favor of the Hyksos-Knights Templar Galactic            
   Federation  World Dominion agenda. Arthur successfully returned the       
   Staff tool to the Arc of the Covenant Gold Box and relocated the Arc       
   Box  containing the Rod and Staff from the Vale of Pewsey, England to       
   where it remains hidden today . Arthur and his Knights were unsuccessful            
   in disengaging the Nibiruian Diodic Crystal Grid. But at least they man-       
   aged to hide the Arc of the Covenant Gold Box  and Rod and Staff  tools           
   from Galactic Federation,  their  Hyksos-Knights Templar  and the even-       
   tually competing Nephedem-Drakonian Knights Malta, preventing them       
   from fulfilling their planetary genocide  and takeover  agenda. The              
   “Quest for the Holy Grail ” and “Search for Arc of the Covenant Gold                  
   Box ” has continued ever since.             
   324    

                                                            
                                                             
                                     
                                              Progression of Major Events in Atlantian Conspiracy
        . 1244 AD Albigensian Crusade:  Church of Rome Nephedem Annu-       
                        Melchizedek Illuminati , on behalf of the Omicron-Drakonian OWO      
                        (One World Order) agenda, launch a genocide campaign  against the Maji      
                        Grail Line Cather i, the Tribe-12 , Star Gate-12 Guardians in southern       
                     France. The campaign was initiated to stop the Catheri from using their      
              Roundtable knowledge  to disengage the Nibiruian Diodic Crystal Grid,      
                        knowledge gained from CDT-Plate-12 , which was in possession of the       
                        Catheri at this time. The Catheri’s “last stand” was at Monsegur, Southern      
                        France, an event historically recorded as the “Albigensian Crusade”, in       
                        which the Catheri were cornered and burned alive  at the order of the       
                        Church of Rome and accomplices in the government of France. A small       
                        group of Catheri escaped with CDT-Plate 12 , and numerous volumes  of                              
              pure Jesheua-Essene records , which were hidden in France  and will one                         
              day provide witness to the realities of the Atlantian Conspiracy.    
•	 1500 AD Ameka Crusade: The quest for the'' Holy Grai '' continued as               
    Hyksos-Knights Templar  Annu-Melchizedek Illuminati races and Omi-       
    cron-Drakonian Nephedem Annu-Melchizedek  Illuminati races ad-       
    vanced their OWO agenda in pursuit of the “ Holy GRU-AL ”.The  Gru-            
    AL POINT  is the central control point  for Earth’s Templar  and both com-      
    peting groups intended to hold dominion  over the lands of the Gru-AL       
    Point when the 2000-2017 SAC  arrived. The'' Protestant & Catholic             
    Invasion '' of  Native American Tribes  began. The name ''America ''       
    came from the name of one of the Emerald Covenant Maji Grail lines        
    known as the Ameka,  who were protectors of the Gru-AL Point . The                 
    Gru-AL Point was known to exist in the lands of the North American       
    continent , a territory once held by Atlantis . Guided through “ Mystical       
    Secrets Societies ” set up by their respective Fallen Angelic kin, competing          
    groups of Annu-Melchizedek Illuminati races launched a progressive in-       
    filtration and takeover of the North American continent. Each intended       
    to destroy  the exiled Lemurian and native Seminol and Ameka '' Native              
    American '' Maji Grail Line Tribes who had knowledge of Running the              
    Roundtables , in a systematic take-over of the North American Templar. 
       '' America '' was founded by the Luciferian Hyksos-Knights Templar Annu-                               
              Melchizedek Illuminati , who now go by the name of “ Free Masons ”, on                         
              behalf of Galactic Federation  and the Pleiadian-Nibiruian Anunnaki                     
              races of the 9560 BC Luciferian Covenant.  Competing Illuminati groups                      
             and their Stellar co-conspirators intended to use the North American                      
              Gru-AL Point , and their holdings of Star Gate-11 Europe , Star Gate-4                                    
              Egypt and  Star Gate-10  Middle East , to gain full control of Earth’s Tem-                     
             plar on behalf of their Stellar contacts during the 2000-2017 SAC .
                 It was anticipated by all that the “ Final Conflict Drama ” and the “ Battle of      
                  Armageddon ” would take place as the competing Drakonian and Anun-          
                  naki descendant Annu-Melchizedek Human Illuminati legions ''battled it      
                  out'' for control of Earth’s Templar during the long-awaited 2000-2017      
                  SAC. Neither side anticipated that there would be enough surviving An-                    
             gelic Human 12-Tribes and Maji races left with knowledge to run the      
                  Roundtables to prevent the Illuminati, known as the “ Leviathan Force, ”      
                  from succeeding  in their OWO agenda. Included in this OWO agenda    
                 325
                                                                                                                            

              
                The Atlantian Conspiracy and Roundtables
        was the re-initiation of  contact with the Fallen Angelic/ET Legions  as
the SAC   drew closer. The Fallen Angelics intended to slowly make their 
presence known then come in to “ stake their claim ” as the 2000-2017
SAC approached 2012 AD.  The Drakonian- Reptilian-Centaurian  de-
scent Annu-Melchizedek Illuminati races attempted, but failed, to claim 
world dominion over their Anunnaki adversaries via their representative
Hitler in WW2 . Both Illuminati forces have been competing for political 
world dominion . They have been the predominant, hidden source of 
war, race hatreds and territorial, financial and religious competition  be-
hind and within world governments, until the September 12th, 2000
UIR. On September 12, 2000, most competing Illuminati races, and their 
respective Fallen Angelic “ring leaders” agreed to take a united stand
against Emerald Covenant races  to ensure success of the OWO dominion 
agenda and destruction of the Angelic Human races during the 2000-2017
SAC.                 
      . 1750 AD Nibiruian-Re-acquaintance: Pleiadian-Nibiruian Anunnaki                      
            races and Galactic Federation  began initiating remote “ Channel Con-
              tact ” with their '' Chosen Ones ,'' providing contrived spiritual teachings
              intended to develop into the later “ New Age Movement ”, through
                which direct Fallen Angelic/ET contact could be made with little human                     
           resistance . 
    • 1916 Zeta Surveillance: Zeta races begin participating in the Earth drama 
             on behalf of the Zephelium-Zeta Rigelian and Odedicron-Reptilian (Ori-
             on) agenda. 
 
•  1930-1940's Covert Treaties:  The Zeta negotiate covert treaties with                                                                                                    
    Nephedem Annu-Melchizedek Illuminati human government, through                                                                
    which “ Majestic-12 ” and the contemporary “ UFO Movement ” emerge
          on behalf of the Drakonian OWO agenda, which initiated as a result
          of the pending Anunnaki takeover agenda. Anunnaki Fallen Angelics ad-
          vance their remote “Channel” contact with selected humans.  
             
•  1983 Orion Intrusion: Omicron-Drakonian races of Orion get directly in-                      
    volved in the drama, forming alliances with the Odedicron-Reptilian and                 
    Dracos races; Zeta’s lose footing in Illuminati affairs as Drakonians take                         
    over Zeta Treaties, some Zetas leave, Rigelian Zetas join to strengthen             
    Drakonian forces in Earth affairs. 
•   1992 Pleiadian-Sirian Agreements: Pleiadian-Nibiruian Anunnaki  and             
     Galactic Federation  races enter Emerald Covenant  peace treaty when they             
     realize that they may succumb to Drakonian Force in the anticipated 2000              
     -2017 Final Con ﬂict Drama. Agree to turn Solar Star Gate-4  control back              
     over to Emerald Covenant races, to end the Atlantian Luciferian Cove-                  
     nant  for co-evolution programs, to assist Emerald Covenant and Human       
     races in running proper Roundtables  to block further Drakonian infiltra-       
     tion and promise to disengage Nibiruian Diodic Crystal Grid by January 1,              
     2000 . The “New Age Movement” takes a turn toward the Light.
    •  1999 Centaurian-Necromiton Intrusion: Drakonian agenda Necromiton-                
       Andromi and  Alpha-Omega Centauri races get involved to reinforce the               
       Drakonian agenda in reaction to Anunnaki joining the Emerald Covenant.    
     326
                                                      
                                                               

                                                                
                                                           
                                                       Progression of Major events in Atlantian Conspiracy
                      
                      •  January 2000 SAC Rebellion: When Stellar Activations Cycle com-
    menced on January 1, 2000, Galactic Federation and Pleiadian-Nibiruian
      Anunnaki groups defect from Emerald Covenant  once Stellar Activa-
      tions Cycle was confirmed, as Fallen Angelic Annu-Elohim offer full sup-
      port to the Anunnaki OWO agenda.
•   July 5, 2000 Treaty of Altair: Galactic Federation and most Anunnaki 
     groups grudgingly accept re-entry into the Emerald Covenant to secure 
     greater protection when Annu-Elohim  of Sirius A  and Arcturus suffer 
     heavy losses to the Fallen Seraphim Drakonian  force in Density-3 Orion. 
•   September 12th, 2000: Necromiton-Andromie  and Alpha-Omega-Centau-
                      ri  races convince many Drakonian and Anunnaki legions to form a 
        “ United Resistance Alliance ” (UIR) against the Emerald Covenant to 
         ensure fulfillment of their common interest in the OWO dominion agen-
         da. Galactic Federation, Ashtar Command  and most Anunnaki Legions 
         break the Treaty of Altair  to join the UIR. UIR adopts the Anunnaki 
         Luciferian Covenant agenda , which includes “termination” of the An-
         gelic Human races of Earth and forced pole shift, induced via Battlestar
         Nibiru  (“Wormwood”) and the Nibiruian Diodic Crystal Grid. Septem-
         ber 12, 2000 UIR offers Emerald Covenant races an ultimatum.  UIR
         would allow the Lyran-Sirian Guardian races to evacuate  50,000  of their
         '' Indigo Children Maji Grail Lines ,'' then the rest of Earth’s populations 
         would fall prey to fulfillment of the Luciferian Covena nt agenda. Emerald 
         Covenant Races refuse on behalf of all Angelic Human and Hybrid pop-
        ulations of Earth that desire to live in freedom and in order to prevent
         Earth’s Halls of Amenti star gates from falling under UIR dominion. UIR
         issued a formal Edict of  War  on September 12, 2000, against Emerald Cov-
         enant races and the Angelic Humans of Earth.  
                                    
Galactic Federation  and Ashtar Command  is beginning to mobilize their 
             “ Human Ground Crews ” teaching their followers to expect a'' landing ''
              in which ''complete human compliance'' is promoted. The political arena
              is now being set for the UIR’s intended 2003 Mass Mind Control initia-                        
             tive and most humans are completely unaware of what is taking place.
              Emerald Covenant races are intending to awaken the Indigo Children as 
              quickly as possible. The Indigo Children are being prepared now to run 
              RRTs  in order to disengage the Nibiruian Diodic Crystal Grid  through 
              which pole shift can be forced and to seal Earth’s portal system from 
              planned Fallen Angelic 2003-2004  invasion. Before 2003 , Emerald Cov-
              enant races will know if the RRTs are successful and if fulfillment 
              of the Atlantian Conspiracy can be prevented. If not, preparations are al-
              ready underway to assist Humans in DNA Template Activation so some 
              may become biologically capable of portal evacuation.   
                          Sometimes truth is stranger than Fiction.            
                          327                                                                                                           
                          
                                                                                                                                                         

   The Atlantian Conspiracy and Roundtables
                     CORE TEMPLATE GRIDWORK IS REQUIRED
                       to prevent fulfillment of the UIR OWO Agend a
• Through quickly re-learning how to '' Run the Rainbow Rounds ,''Angelic
     Human and Hybrid races can prevent pending Anunnaki-Drakonian 
     OWO dominion during the 2000-2017 SAC. Properly executed RRTs
     can fulfill the Emerald Covenant Christos Planetary Securit y Commission 
       of disengaging the Nibiruian Diodic Crystal Grid  and freeing Solar-Star                                      
                         Gate-4 , which will prevent Fallen Angelics any further access to Earth’s                                         
                 portal-vortex system . Running the Signet RRTs to reclaim Earth’s Tem-
     plar from Fallen Angelic dominion has been known for thousands of years 
     as the 11:11/12:12 Christos Reclamation Mission, the Divine Commis-
     sion previously attempted by Jesus-John-Miriam, King Arthur-Guinev-
     ere-Knights, the Catheri,  the Native Americans and numerous other 
     Maji Grail Line Races  throughout history since the  25,500 BC Luciferian
     Rebellion.
                                                     
                                           Now it is up to Us. 
CREATION OF THE LEVIATHAN FORCE &  RELATED HISTORY
                                              
                                    798,000 BC - 33,000 BC
 250,000,000 Years Ago—
      Parallel Earth Human Seeding-1 five Palaidorian Cloisters
25,000,000 Years Ago—
      Five Human & Five Palaidorian  Cloisters seeded on Earth
5,500,000 Years Ago—Human Seeding-1 destroyed via Electric Wars
 3,700,000 Years Ago—Human Seeding-2
 848,800 Years Ago—Human Seeding-2 destroyed via Thousand Years War                          
                       ANGELIC HUMAN SEEDING-3—
                   CONTEMPORARY LINEAGE BEGINS
798,000 BC—- five Palaida-Urtite-Cloisters Angelic Human Seeding-3: Round-1
669,000 BC-250,000 BC—Rama & Temple Wars Anunnaki/Drakonian In-
       vasions, Nephedem-Drakonian & Urantia-Jehovian-Anunnaki Illumi-
       nati hybrid-humans
250,000 BC—Enki-Enlil-Marduke Pleiadian-Nibiruian Anunnaki (Aquatic-
       ape-hominid) create Lulcus-Neanderthal Primate-hominid slave-race via
       raiding Angelic Human colonies
246,000 BC—Maharaji bring Emerald Covenant Restatement peace treaty to
       Earth races, Angelic Humans enter & Thoth-Enki Anunnaki enter for
       DNA Bio-Regenesis
208,216 BC—SAC, Drac Invasion, Fall of Brenaui, 10-Code Pulse & pole shift
208,100 BC—Urtite-Cloister Human: Round-2 subterranean resettlements
328 
                                                                                           

                                           
                                   Angelic Human Seeding-3 — Contemporary Lineage Begins
155,000 BC—Emerald Covenant Anunnaki Bio-Regenesis Program begins:
      Lulcus-Neanderthal Hyperbornean-Human  upgrade-1 to hybrid Luhari-
      Cromagnon-1
152,000 BC——Luhari Anunnaki-hybrid Ur- Antrian-Urtite-Cloister -Human
      Emerald Covenant (EC) upgrade-2 to E-Luhli-Levi-Cromagnon-2 , ﬁrst ca-
      pable of natural procreation with Humans; Levi-hybrids raided by Drac &
      Anunnaki Fallen Angelics, Anti-Christos Leviathan Force  competing Illu-
      minati genetic lines begin
151,000 BC—E-Luhli-Levi hybrid Breanoua-Urtite-Cloister-Human  EC up-
      grade-3 to E-Luhli-Judah Homo-sapiens
150,000 BC— Jehovian  Wipe out. Competing Drac & Jehovian (Dolphin Peo-
      ple) Anunnaki attempt to seize Earth & Inner Earth. Maharaji of Sirius B
      prevent take over; Firmament Hydro-Suspension fields collapse initiating
      glacial period.
148,000 BC—E-Luhli-Judah hybrid Hibiru-Urtite-Cloister-Human  EC up-
      grade-4 to E-Luhli-Nephi.Jehovian Anunnaki  launch aggressive raids on
      Nephi hybrid races creating the Nephite-Jehovian-Hibiru Illuminati hy-
      brid genetic line
148,000 BC-75,000 BC— Anu Occupation ; Sirius A & Arcturian Jehovian-
      Anunnaki  attempt Earth takeover, launch genocide programs against An-
      gelic Human, Drakonian-Nephedem & Nibiruian Anu-Anunnaki Earth
      races. Enlil-Enki-Marduke Pleiadian-Nibiruian Anunnaki lines unite,
      overthrow Jehovians & seize control of Earth. Emerald Covenant races
      exile & subterranean settlements. Nephedem- Drakonians, Jehovian-
      Anunnaki & Nibiruian Anunnaki Raider Wars begin
75,000 BC—Nibiruian Anu-Anunnaki attempt to seize Inner Earth portals,
      Inner Earth races unite in Inner  Earth Rebellion,  overthrow Anu-Anunna-
      ki dominion of surface Earth, reinstating Urtite-Cloister-Human sover-
      eignty over surface Earth
73,000 BC—Cloister-Human: Round-3  seeding begins with Ur-Antrian Cloister
71,000 BC—Root Race-Human: Round-4  seeding begins with Lemurians
72,000 BC— Breanoua-Cloister-Humans  seeded
 68,000 BC—Root Race-Human Atlantians seeded & E-Luhli-Nephi hybrid
       Melchizedek-Urtite-Cloister -Human EC  upgrade-5 to Annu-Melchizedeks.
       Drakonian, Jehovian-Anunnaki & Anu-Anunnaki Leviathan Illuminati
       hybrid races progressively raid Annu-Melchizedek races creating various
       competing Anti-Christos Agenda hybrid “ Templar-Meichizedek”  Levia-
       than “Super-races”—the Leviathan  Force, leading to the Atlantian Con-
       spiracy & present drama
66,000 BC- Hibiru-Cloister-Humans  seeded
63,000 BC—Root-Race-Human-Aryans
33,000 BC— Melchizedek-Cloister-Humans  seeded & 22,500 BC Eieyani Grail
       Line begins
329 
                        
                                                                                                  

The Atlantian Conspiracy and Roundtables                            
                               SUMMARY OF THE ATLANTIAN CONSPIRACY
50,000 BC - Lemurian Holocaust
28,000 BC - Atlantian Holocaust
25,500 BC  -Lucifer Rebellion
22,326 BC - Eieyani Massacre
21,900 BC - Lohas-Celtec-Druidec Freeze Out
20,000 BC - Vicherus-Sacheon Invasion
10,500 BC - Luciferian Conquest
9,560 BC - Luciferian Covenant
9,558 BC - Atlantian Flood
8,900 BC - Sumerian Invasion
8,400 BC - Egyptian Invasion
7,500 BC - Knights Templar Invasion
5,900 BC - Centaurian War
3,650 BC - Mayan Raids
3,470 BC – Babble-On Massacre
2,668 BC - Djoser Invasion
2,024 BC - Dead Sea Conquest
1,670-1,550 BC - Hyksos Invasion
1,476 BC - Hyksos Exodus
1,459 BC - Israel Crusade
1,458 BC - Hatshepsut Invasion
1,353 BC - Fall of Akhenaton
906 BC - Fall of Solomon’s Temple