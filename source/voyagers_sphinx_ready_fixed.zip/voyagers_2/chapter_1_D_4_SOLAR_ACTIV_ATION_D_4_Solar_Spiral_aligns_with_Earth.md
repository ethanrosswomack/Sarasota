1    D-4 SOLAR ACTIV ATION : D-4 Solar Spiral aligns with Earth
  DATE:  5/5/2000 - 6/2004  EARTH ACTIVATION
  EARTH VORTEX OPENS : V ortex # 4 - Giza Egypt - 1/2000 - 6/2004
  BLUE WAVE INFUSION : 2002 -2006  D-5 BT & D-6 OT frequencies enter Earth's Core
  DNA:  DNA strand it 4 assembles and activates, Blue Star  crystal activates
  EARTH ACCRETION LEVEL : 2 to 3)  HUMAN ACCRETION LEVEL : 3 to 4
  (Earth accretion level presently 2.5, Human average presently 3 to 3.5 accretion)                                _________________________________________________________