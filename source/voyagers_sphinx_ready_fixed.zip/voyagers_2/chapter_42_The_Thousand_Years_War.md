42 
 

                                                                            
                                                                                 The Thousand-Years’ War
of the Seventh Race is the  Y unaseti,  and they carry the full 12-strand DNA
package of the Turaneusiam lineage, in operational form. The Seventh Root
Race is the  Euanjhechi , often called the Paradisians ; they carry DNA strands
l-5, and the base codes for 6-12.                        
    Members of the Seventh Race cycle do not experience death, nor do they
breed through physical means but rather through replication of combined
energy fields. They do not carry exaggerated physical gender distinction, but
are rather primarily androgynous, soul-awakened identities. Their bodies are
composed of less dense matter particles and so they are not as strongly bound by
gravity, which allows for mobility far beyond that of your present bodies. They
can travel through time, and often do, such as when they visit your system.
Many of your ET Visitors are actually your Seventh Race relatives from Tara.  (Not
all Visitors are direct relatives to the human.) They represent the races of
which you will one day evolve to become members, when you walk the beauti-
ful lands of Tara and Gaia. The Seventh Races mark the fulfillment of the
human evolutionary imprint and a return to the glorious beings you all once
were before your fall into HU-l. Evolution beyond this stage will take you into
the realms of pure conscious being and into the “God Worlds” where Entities
play. You are the V oyagers, and have always been. lt is time to awaken to the
reality of your journey. And now we will return you to the times of the Second
Seeding 3,700,000 - 848,000 years ago, when your present Fourth World began
as the reseeding of races 3-5 was orchestrated through the Sirian-Human
hybrid race Dagos. Through understanding this history, you will discover the
truth of The Arc of the Covenant , a well kept secret that will directly impact
the course of your evolution over the next 30 years.  
                                        THE THOUSAND-YEARS’ WAR              The Second Seeding, the Drakon and Dracos, the Anunnaki and the
       Nephilim, the Elohim, Seres, Serres and the Egyptians, Return of the
                              Sphere of Amenti, and the Thousand Years’ War  
                                                      3,700,000 -848,800 YA  
    Great hope lived within the promise of the Fifth Root Race Ayrians and
their Hibiru Cloister of the Second Seeding, for they held within their mor-
phogenetic field and DNA imprint the frequency patterns of the fourth
dimension. The Elohim of HU-3 paid special favor to these races and assisted
a few select families, whose codes were not contaminated by mix-breeding.
The Elohim assisted these families in releasing the Seal of Palaidor within
their genetic codes, by transplanting their energetic bodies into Elohim mor-
phogenetic fields.  
    The Elohim hoped that, by the accelerated evolution of these chosen
groups, the vibration rate of Earth's grid could accelerate more rapidly so the