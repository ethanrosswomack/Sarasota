67 
                                                                                                                   

The Third Seeding  
corruption of the Taran Templar Solar Initiates, orchestrated by the Anun-
naki factions of the HU-2 Sirius star system who were rebelling against the
Sirian Council, the truth and sacred science of the Templar was, for a time,
lost on Tara. And because of this distortion and intentional Anunnaki Resis-
tance manipulation on Earth, the Templar teachings provided to the Earth
races became tainted with lies and distortions, progressively leading human
culture into an elitist, materialistic, dualistic perception of reality. That per-
ception has formed the underlying belief-base upon which culture was organized,
and is still apparent within most of the cultures of present day Earth.  
    The original T emplar creed taught Unity Consciousness and love, coop-
eration and respect toward all other life forms. It did not appoint some groups
as being godly and others as evil; it taught of the necessity for equality
between peoples and genders and the need to heal and integrate all aspects of
society. The original Templar teachings promoted kindness, gentleness, toler-
ance and power through comprehension of sacred energy mechanics and con-
sciousness embodiment of the God-force. They did not  teach that God was a
male authority ﬁgure who passed judgment upon sinful, inferior humans. They  did
not teach that the male gender was formed in the image of God and the
female was a lesser part extracted through the godly male to hold a position of
subservience to men. The original Templar creed did not  endorse the exploi-
tation of the plant, animal and mineral kingdoms for the purpose of personal
sustenance and materialistic gain, it taught respect and reverence for all life.
The original Templar did not  teach of “good and evil”; it taught that evil
deeds were the result of ignorance to the true structure of the universe, and
that evil was cured by education through the Law of One. It taught that peo-
ples were created to be free, and in that freedom should be taught how to
become co-creators with the God-force.  It taught that every being in the universe
was an individual face and expression of God, and that brotherhood was simply the
rational result of this comprehension.  
      Literally all of the elitist, sexist, materialistic distortions to the true Laws of
the Templar were perpetrated through the in ﬂuence of the Anunnaki Resistance,
some of their ET co-conspirators and the Templar-Annu Resistance loyalists lin-
eage who became their earthly operatives. The distorted Templar creeds moti-
vated everything from the Holy Wars throughout history to the structures upon
which economic, political and social organization has been built.  
       The creed of the Templar-Annu spread far and wide, and has colored the
mores of literally every human culture on Earth since the time of the Third
Seeding. The Templar distortions have evolved into a massive program,
which has repressed the majority for the benefit of the few, and has caused
humanity to lose comprehension of its divine source and the true potentials
of its evolutionary heritage. This creed has been a poison  to human society ,
and the pain, disease, war, competition, hatred and violence that have col-
ored the human condition throughout history and into the present, are clear 
68  
 
                                                                                                                           

                                                                                                            
                                                                                                          
                                                                                                          2017 AD Appointment
illustrations of just how powerfully these distortions of truth have affected
you. It would help all of you to realize that these creeds were given to you and
promoted by ET forces who set themselves up as surrogate gods, so human
evolution would remain under their control for the purpose of exploitation.
True spirituality lives within, and it is through that inner truth that you will
be able to separate the chaff from the grain in regard to your spiritual and
physical evolution. In contemporary society there are groups of souls now
being born who have been commissioned by the Palaidorians, Elohim, Ra
Confederacy and lnterdimensional Association of Free Worlds, to bring the
original teachings of the Templar back into your civilizations. They will bring
back to the Earth the truth of the Law of One and the knowledge of sacred
science through which that Law can be actively applied.  
     Many traditional persuasions will attempt to promote the new teachings as
evil or to otherwise discredit them, precisely because restoration of the truth of
multidimensional reality, which these organizations have for long attempted to
hide, will be the downfall of these institutions. Once humanity becomes aware
of the Law of One and the Unity Consciousness created through its practice,
control organizations will no longer be able to blindly lead the people, for the
people will choose freedom and knowledge over ideological imprisonment.
And they will choose love, equality and a personal relationship with the cre-
ative force over judgment, devaluation, hatred, fear, subservience and blind
worship of self-promoting outside authority figures. This evolution of self-con-
cept and re-definition of reality will take time, but through this process human-
ity will progressively grow to become free, and through its freedom will come to
understand its co-creative relationship with the divine.  
    When the guardian races of 22,326 BC planned the preparation of the
races for their 2017 AD awakening, they had not realized the extent to which
these manipulations would distort the evolution of human culture, nor the
degree to which the races would digress under this influence. Despite the
often disheartening setbacks, the guardian races of the higher Harmonic Uni-
verses remained loyal to their cause of seeing the Covenant of Palaidor, and
the evolution of the races, reach ful fillment. They have assisted, and still do,
along every step of the way, helping humanity to awaken to its relationship with the
divine creative Source.  After defeating the Anunnaki Resistance attack of
10,500 BC, and assisting the races of Egypt to rebuild their cultures, the Sir-
ian Council and guardian allies of humanity continued to visit and assist the
evolving cultures, serving as a counterbalance to the Anunnaki Resistance
and Templar-Annu forces that continued to assert their in ﬂuence on Earth.  
                          The new teleport station of the rebuilt pyramid of Giza, now aligned with
the energetic systems of Alcyone and the Pleiades, offered swift guardian inter-
vention and protection of Earth and easy access to Earth visitation. Until about
11,500 years ago (9,500 BC), humanity enjoyed the benefits of open relation-
ship with advanced ET cultures. This open relationship ended in 9,500 BC,