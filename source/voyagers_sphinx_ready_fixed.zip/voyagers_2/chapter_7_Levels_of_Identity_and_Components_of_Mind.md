7 Levels of Identity and Components of Mind ...............................................................................134
*History, Motivation, Meaning and Message ………………………............158
             Guardians and Founders Races.................................................................................................158
                  The IAFW,  Azurite Security Team and the MC Eieyani Master Council…................162
                  The GA and the Angelic Human Lineage .............................................................................165
                  The 12 GA Signet Councils, Star Gate Security & Royal House Deception................ .167
             The 3 GA Signet Councils Of Etheric Matter Density-3(D7-8-9) ............... ..170
             GA Signet Council-6, Sirius B, Indigo Children & Christiac Grail Lines….............171
                 The Maharaji, Angelic Humans, Priests of Ur & Melchizedek Priesthoods.............175
                  The Final Conflict, Star Gate-6, Maji Priests of Azurline & Christ Drama................182
                                                                                                                                
           xi