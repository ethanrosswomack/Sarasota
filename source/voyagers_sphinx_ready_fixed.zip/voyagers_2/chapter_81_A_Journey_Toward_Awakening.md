81 
                                                                                                            

A Journey Toward Awakening  
                          ALCYONE AND THE TEMPLAR SEAL  
  The Templar Seal and the Annu-Melchizedek and Hebrew Races,  
 Realignment of the Melchizedek Cloister Morphogenetic Field, the       
      Annu-Melchizedek and Hebrew Races Removed and Serres-Egyptians  
        and Cloister Melchizedeks Appointed as Guardians of the Arc of the               
               Covenant, Resurrecting the Great Pyramid and the Sphinx . 
                                       8000 BC-5466 BC        
    The races who returned from the Inner Earth to re-establish surface civi-
lization, after the 9558 BC sinking of the Atlantean Islands, were faced with
many new hardships as rebuilding of their cultures was orchestrated through
manual labor, without the use of the Great Crystal Generators and high pow-
ered Ankhs to which they had become accustomed. Following the employ-
ment of Earth's quarantine in 9540 BC, and its resulting genetic mutation,
evolution became an even slower, more arduous task. The Egyptian-Serres,
Annu-Melchizedeks and Hebrew peoples were guardians of the Arc of the
Covenant and were permitted to have custody of the Rod and the Staff so
their connection to the Inner Earth civilizations could remain open. The
Great Pyramid and the Sphinx suffered damage during the ﬂooding that fol-
lowed the downfall of Atlantis, but portions of these and other structures
remained intact, and these were once again used as a central hub around
which the cultures would rebuild. The Serres-Egyptians remained as the royal
line in Egyptian culture, while remnants of the Lemurian and Atlantean cul-
tures and the Breanoua and Ur-Antrian Cloisters, the Annu-Melchizedeks of
the Inner Earth, the Hibiru, Aryans, Cloister Melchizedeks and the Hebrew
races populated Egypt and various other locations of the globe. The first num-
ber of generations were preoccupied with survival issues and the development
of small cultural clans, which eventually led to the development of larger
social orders. The Egyptian culture received much assistance from the Inner
Earth races as the Arc of the Covenant was located within the Egyptian lands
and surface guardianship of this and other portal passages was placed in the
hands of the developing races in this area.  
    During the retreat to the Inner Earth at the time of the sinking of Atlan-
tis, numbers of Templar-Annu had also entered the inner territories. (The
Templar-Annu were those born into the Atlantian-sub-race-Egyptian race
through the Melchizedek Host Matrix, who later interbred with members of
the Anunnaki Resistance, inheriting all or part of the genetic distortion
Templar Seal from this extraterrestrial race). The Templar-Annu interbred
with many different races in generations following Atlantis, especially with
those of the Annu-Melchizedek and Hebrew (Hibiru/Melchizedek) lines,
passing on concentrations of the Templar Seal distortion throughout the
Melchizedek races. The distortions of the Templar creed had also made their