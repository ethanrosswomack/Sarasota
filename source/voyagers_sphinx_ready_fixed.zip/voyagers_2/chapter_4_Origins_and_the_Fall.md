4

                                                                                                                                                                                                   
                                                                                                              Origins and the Fall             
                                                            
                                                                  Cataclysm of Tara
                                                                           550,000,000 YA
                         Approximately 550 million years ago the Power-generator Crystals deep
        underground in Alania exploded, due to the Templar Solar Initiates’ misuse of 
           power from Tara’s planetary core. This created a chain reaction of implosions 
          within Tara’s planetary grid. Portions of Tara’s grid were blown apart and frag-
      mented, becoming detached from the Morphogenetic Field  of the planet. Por-
       tions of Alania were immediately destroyed and the entire planet suffered the 
       effects of rapid pole reversal. For a period of two days Tara ceased to rotate on
      its axis. It took 10,000 years to re-stabilize T ara’ s environment, during which
       time the few surviving Taran races still on-planet retreated permanently under-
       ground. Descendants of those civilizations who survived this disaster still ﬂour- 
         ish within elaborate underground communities. Surface life also returned to
             T ara following this 10,000 year period of healing. Because portions of the
       planet’s energy structures had been ripped from the main planetary grid, planet 
       T ara could not continue its evolution of dimensional ascension into the Third
        Harmonic Universe. T ara could not re-emerge with the energy grid of its
              dimension-7 counterpart Gaia, until its own grid system was repaired. T ara 
                          became trapped in the tracks of time within the Second Harmonic Universe .                           
                      
                                        The Fall to  Harmonic Universe-1 and the 12 Planets
                                                                        550,000,000 YA
                  The fragments of the Taran planetary grid that became dismembered from 
    T ara’ s core energy supply rapidly fell in vibration until they could no longer
      resist the natural magnetic pull of the descending lnterdimensional energy cur-
      rents. The planet fragments were pulled into a sun within T ara’ s universe,
      vaporized, and the morphogenetic field carried in those fragments was pulled 
     into a black hole at the center of this sun¹ and re-emerged into a galaxy within
     the lower-dimensional fields of Harmonic Universe 1. Entering this system as 
     gaseous substance, this morphogenetic field broke down into 12 pieces, which 
      set up a “mini-solar system” around a star within an already existing HU-1 solar 
        system. One of the 12 pieces of Tara’s fragmented morphogenetic field fused 
         with this sun, while the 11 other pieces began to build up matter density and 
     re-manifest their forms through their portion of the morphogenetic field. These 
     planets did not birth into existence in the usual accretion fashion, for they car-
     ried with them the organizational imprint of part of T ara’ s planetary grid mor-
           phogentic field. These planets did not birth into Harmonic Universe 1, they 
     fell into it, literally. Their original morphogenetic field fell in vibration, reorga-
                         _____________________
                                 1.  All suns have sets of black and white holes at their core; they operate as portals through                                                                         
            which energy can pass through dimensional fields.