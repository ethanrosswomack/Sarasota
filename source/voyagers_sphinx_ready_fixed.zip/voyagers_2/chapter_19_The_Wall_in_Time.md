19                                                                       
                                                                                                                  
                                     
 
                                           The Wall in Time
                and Atlantian Secrets of the
                   Phoenix and the Falcon
              
                                     DIMENSIONAL BLEND EXPERIMENT, WALL IN TIME,
                                              AND THE ILLUMINATI MASTER PLAN 2003
            
   The contemporary United Intruder Resistance (UIR) Illuminati One
World Order (OWO) Master Plan is an amalgamation of key components
of the previously disclosed competing fallen Angelic/Intruder ET OWO
agendas.  The UIR has adopted the long-planned '' 2003 Dimensional Blend
Experiment '' and “ 2004 Frequency Fence ” plan originally of the Zeta -
Rigelian Agenda.  The Zeta-Rigelians originally got their idea for the
Frequency Fence from the Annunaki NET  plan, in which the Annunaki had
long planned to “Lower the NET into D-3” to create a Frequency Fence
during the 2000-2017 SAC.  
    The Nibiruian Council mandate of Human Genocide  has been adopted,
and its orchestration is intended to occur through the '' Instigation of War
Among Human Nations '' agenda that has been key to most OWO creeds
since their inception. Advancement of the UIR Illuminati OWO Master
Plan depends upon their preventing Earth’s Templar from reaching a critical
mass 12-Code Pulse.  If the Guardian agenda of activating the Four Faces of
Man LPIN system  to create the Trion/Meajhé Field before 2003  is
successful, the 12-Code Pulse will reach critical mass in Earth’s Planetary
Shields, blocking the Dimensional Blend Experiment  and Frequency
Fence . The DNA Templates  of Indigo Children and Humans are now
beginning mass activation,  despite the Fallen Angelic astral T agging
interference; the biology of these races will automatically and progressively
run higher dimensional frequencies into Earth’s grids. A critical mass of
Indigo Children Types-1 and 2¹ have now cleared sufficient amounts of
NDC-Grid distortions from their DNA Templates  and set sufficient
amounts of the 12-Code Pulse in Earth’s Templar . These events will begin
triggering spontaneous DNA clearing and activation in mass Human /
Indigo populations . If these populations continue cleared DNA Template        
                              ___________________________________
                              1.     48- and 24-Strand DNA Templates, respectively.
                                
                            386
                


                                                                                 
                                                                      
                                                                                          
                                                                             Dimensional Blend Experiment, Wall in Time, ...
activation, they will  unknowingly transmit a critical mass 12-Code Pulse
into the Planetary Shields by 2003, preventing ful fillment of the
Illuminati Dimensional Blend Experiment.  
   The “ 2003 Dimensional Blend Experiment ” was intended to directly
link Earth’s Planetary Shields into the Planetary Shields of a counterpart of
Earth, called Phantom Earth , that was drawn into the Phantom Matrix
Black Hole Sub-Time Distortion Cycle  during the '' Electric Wars ,'' which
ended Human Seeding-l on Earth , 5,500,000 years ago.  Since the Electric
Wars there has been a '' Wall in Time ''—a  frequency Cap  between Earth’ s
Planetary Shields and the chaotic Planetary Shields of Phantom Earth in the
Black Hole Phantom Matrix. This Cap was kept in place by the Emerald
Covenant Founders, in hopes that eventually our Earth would evolve to a
sufficient frequency accretion level  through which the '' Wall in Time ''
could be “Uncapped,”  without our Earth and its life field potentially being
rapidly drawn into the Phantom Matrix. This Cap allows the races in
Phantom Earth an opportunity to have DNA Bio-Regenesis, and the
Phantom Earth to receive Planetary Shields repair, so people and planet
could be retrieved from the “perpetual chaotic time loop” of the Phantom
             Matrix to restore natural evolution.  
           Since the end of Human Seeding-1, Earth has been a literal
“battleground ” between the Emerald Covenant Founders races and the
Fallen Angelic/Intruder ET races of the Phantom Matrix. Each group has
fought to attain a critical mass of frequency  in the Planetary Shields of
Earth and its Phantom. If Phantom Earth accretes greater frequency holding
than our Earth, our Earth, its peoples and the Halls of Amenti in the Inner
Earth Time Cycle will be sucked into the Phantom Matrix black hole. If this
occurs, 11 dimensions of our 15-dimensional Time Matrix will become fully
trapped within the Phantom Matrix Sub-Time Distortion Cycle , cut off
from interaction with the Founders of D-12 and up, under Fallen Angelic
race dominion, completely incapable of natural Ascension out of density .
Such an event would provide sufficient energy fuel to feed and arti ficially
sustain the dying Phantom Matrix for many eons to come.  
    Since the 25,500 BC Lucifer Rebellion, the Anunnaki races of the
Phantom Matrix have been progressively draining frequency from our Earth
and transmitting it into the Phantom Earth Shields via the ' 'relay station ''
of the NET, NDC-Grid, the Reverse-orbit Planet Nibiru and the
artificial Nibiruian Battlestar ''Wormwood .''² In the SAC of 22,326  BC,
the Anunnaki almost succeeded in ful filling the Dimensional Blend
Experiment , through which the '' Cap on the Wall in Time '' would have
been shattered and our Earth and the Halls of Amenti Star Gates would
have become fully trapped in the Phantom Matrix. The Eieyani Founders
races stopped the 22,326 BC SAC just in time to prevent this travesty from
occurring. When the Zetas uncapped the Falcon Wormhole in the early
1900s and launched the 1943 Philadelphia Experiment,  the first full link
between the Planetary Shields of Zeta-controlled Phantom Earth and our
Earth was made in our contemporary times.     
                                        ____________________________
                                      
                                             2.     Yes, for the Biblical reference.
                                           387
                                                                                                                                                       

         
                        The Wall in Time and Atlantian Secrets of the Phoenix and the Falcon
    A  “hole was punched in the Wall in Time”  by uncapping the Falcon
wormhole and creating the Phi-Ex Wormhole Port Interface Network
(PIN) Atlantian Pylon Implant Network (APIN) System . Our
contemporary problems mounted when the Pleiadian-Nibiruians uncapped
the neighboring Phoenix wormhole, and they escalated again when the
“Hole in the Time Wall” was further expanded through the Falcon
wormhole during the 1983 Montauk Project.  If the contemporary UIR
succeeds in orchestrating the 2003 Dimensional Blend Experiment , Earth
will ful fill the Jehovian-contrived ''Biblical Revelations Prophecies,''
experience pole shift  and be drawn into “the Pit” of the Phantom Matrix
black hole3 The potentiality of Earth entering the Phantom Matrix is both
spiritually and scientifically devastating . Regardless of whether these
events are interpreted in terms of physics or spirituality, they are real “on
both counts.”  
    Originally , Emerald Covenant races, Humans and Indigo Children entered
repeated Earth incarnations on “ rescue missions,”  in attempts to save the
mentally and biologically mutated races  of the Phantom Matrix from their
return to undifferentiated units of “space dust” at the eventual, inevitable,
implosion of the Phantom Matrix. Now, due to the anti-Christiac applications  of
the NET/NDC-Grid/Montauk-Phi-EX/Phoenix Project  and Fallen Angelic
APIN technologies , the “Cap on the Wall in Time” must be permanently
closed.         
    If the Cap on the Time W all is not closed, Earth, Inner Earth, the Halls of
Amenti and the many universes within the lower 11 dimensions of our l5-
dimensional Time Matrix will implode  during and shortly after the 2000-2017
SAC.  The imploded systems would then chaotically reorganize their matter-
pattern within the Time Loop of the Phantom Matrix black hole.  The
Founders races must do everything in their power to prevent this event from
occurring, or other neighboring Time Matrix systems will be unfairly placed in
similarly grave jeopardy.  
    The present “Final Con ﬂict” drama on Earth will be the deciding factor of
destiny for many civilizations within our Time Matrix system, as well as for Earth
and the Human race. If the Emerald Covenant Masters Planetary Stewardship
Initiative and Bridge Zone Project  are successful, only a portion of Earth’s matter
base and consciousness fields will be drawn into the Phantom Matrix Time
Track  during the Three-Day Particle Conversion Period of our present SAC
(see page 223). The rest of Earth’s Planetary Shields and life-forms with sufficien t
DNA Template activation will experience a progression of linear time events
that will lead to a future in which Earth and her peoples discover the reality of
the Inner Earth Time Cycle . In this future, Earth becomes a free (ascended)
planet  within the Interdimensional Association of Free W orlds and great
Universal Emerald Covenant communities—the '' heavenly Earth '' so often
promised but never “deliverable” by the many oblivious religious dog mas.  
 . .                       If the GA  Bridge Zone Project is not successful, and the UIR’ s 2003
Dimensional Blend Experiment is not prevented by 12-Code Pulse re-coding of
                                                                       __________________________                                              3.     Not a “pretty sight” in terms of scienti fic physics and even more unsavory in terms of con-      
                                         scious spirit.
                            388  
            

                        
                                The WTC/ Pentagon Disaster and the “Secrets of the Phoenix and Falcon”
the 24 Nibiruian Crystal Temple Networks and setting of the Trion/Meajhé
Fields, the Guardians cannot prevent Earth from “joining its Phantom Shadow.”
This is not a decision of Guardian preference, but merely an unavoidable
condition of the natural Laws of Creation Physics  that govern the
manifestation processes of matter and consciousness.  
    Presently , great progress has been made in the Emerald Covenant freedom
agenda. The DNA Templates of Indigos and Humans are now slowly, but
definitely, clearing and activating. Progressive 12-Code Human DNA Template
activation will culminate in Earth’s 12-Code Pulse critical mass re-coding by
2003, if a critical number of Masters Planetary Templar Mechanics “Rainbow
Roundtables” (RRTs) are conducted by Earth populations.  The Emerald
Covenant RRTs are the advanced Biotronic technologies  of the Christos
Founders races. RRTs are the only technologies  by which the “Four Faces of
Man,” “Great White Lion” and “Golden Eagle” PIN Systems can be rapidly
activated to anchor the needed Trion/Meajhé Fields  in Earth’ s Planetary
shields.  
                           THE WTC/PENTAGON DISASTER
        AND THE “SECRETS OF THE PHOENIX AND FALCON”
     •Phantom Matrix. •The 5.5 million-year-old W all in Time. •The
Atlantian Conspiracy and Luciferian Covenant. •The Falcon and Phoenix
Wormholes. •The 1943-1983 Montauk/Phi-Ex Port Interface Network.
•Atlantian Pylon Implant Networks. •The 2003 Dimensional Blend
Experiment. •The NET (Nibiruian Electro-static Transduction field).
•The Nibiruian Crystal Temple Network. •UIR Illuminati OWO Master
Plans. •The September 12, 2000, UIR Edict of War. •RITs (Remote
Interactive Teams) and Astral Tagging •The “UFO and New Age
Movements.” •Fallen Angelic conquest for dominion of the Halls of
Amenti Star Gates. So what do all of these seemingly “far out sci- fi subjects” have to do
with the very real 9/11/2001 WTC/ Pentagon Disaster,  the contemporary
concern over the threat of International Terrorism and the “War On
Terrorism”?  
  Absolutely Everything!  I personally did not fully understand the
connections between the “Big Picture Drama” and our present global terrorist
issue until the GA/Eieyani “ filled in the missing pieces” as I began to prepare
this final update for Voyagers II 2e.  The well-hidden connections between
these ancient and contemporary realities is not remote or vague —it is direct
and scathing; this connection becomes much more obvious when we
understand the “ Secrets of the Phoenix and the Falcon ” and their
relationship to '' ancient '' Atlantis.  The whole story of the Phoenix and the
Falcon could fill several books; I will simply summarize here the most
immediately pertinent aspects of this historical saga.  
    Previous to the 9558 BC “cataclysm” of Atlantis, life was quite different
than it is now on planet Earth. In 28,000 BC, a major cataclysm ripped apart
the large Atlantic continent upon which Atlantis stood, reducing it to
several smaller Atlantian Island Nations. The three Primary Atlantian
         nations  were Ulta-Lohas-Ur , in what had been the Northeast of the
                          
                            389  
                                                                                                                                               
                                                                                                                                                                                                  

                          
                          The Wall in Time and Atlantian Secrets of the Phoenix and the Falcon
Atlantic continent (remains of it are now England, Ireland, Scotland,
Wales), Ulta-Bruah-UR  in the southwest (now Southern Florida, Cuba,
Bahamas, Haiti, Dominican Republic) and Ulta-Nohassa-Ur  in the central
region (now Bermuda lslands).4 
    The Human Atlantian nation became progressively overrun with a race
called the Anu-Melchizedek Leviathans.  The many competing Anunnaki,
Drakonian and Reptilian family lines of the Anu-Melchizedek Leviathan
races were a product of progressive Fallen Angelic raiding  of an Emerald
Covenant hybridization program that began in 155,000 BC.  The Founders’
Emerald Covenant hybridization program was intended to assist the
Anunnaki and Drakonian/Reptilian races that had joined the Emerald
Covenant to regenerate their DNA Templates  to reclaim the potentialities
of ascension. Genetic engineering  was used to combine portions of the
Angelic Human DNA Template with that of a composite Anunnaki-
Drakonian-Reptilian genetic strain, using the Anunnaki slave-primate
Lulcus5 DNA, upgrading the Neanderthal first to the Luhari ,6 then to the E-
Luhli- Levi,7 E-Luhli- Judah ,8 and E-Luhli- Nephi .9 After thousands of years
of evolution on Earth, and 5 genetic upgrades , the E-Luhli-Levi Cro-
Magnon received its final upgrade to the Homo-sapiens-1 Annu -
Melchizedek . The Annu-Melchizedek race, housing incarnations of non-
human  Fallen Angelic souls on Emerald Covenant “Redemption
Contracts,”  resembled the Angelic Human 12-Tribe races because five of 12
Human DNA Strand Templates were genetically engineered into bonding
with the hybrid DNA.  
    From the E-Luhli-Levi  stage, the hybrid races  could , but were not
intended to , naturally procreate with the  Human race,  due to the
compatibility of the lower DNA Strand Templates  between hybrids and
Humans. This made the hybrid races, especially, the most evolved Annu-
Melchizedeks, a prime target for Fallen Angelic races that desired to
                  incarnate their presence on Earth in quest of Halls of Amenti dominion. By
the later Atlantian period of 10,500 BC,  the number of Fallen Angelic
Annu-Melchizedek Leviathan  (of E-Luhli-Levi) hybrid family lines, born of
Fallen Angelic raiding of the hybridization program, exceeded those of the
Emerald Covenant Human and Maji-Indigo races. Throughout much of pre-
ancient history, Earth’s Star Gate system remained open, and interstellar
commerce was commonplace. In later Atlantis, this circumstance led to
invasion , formation of the competing Leviathan Atlantian Conspiracy
OWO dominion agendas  and in 9560 BC  formalization of the Anunnaki -
Leviathan Luciferian Covenant  OWO Anunnaki Master Plan for final
capture of Earth and the Halls of Amenti Star Gates. Human  populations of
Atlantis were progressively driven into exile  in other regions of the globe, as
                         
                          ___________________________________________
                          
                           4.     '' Ulta'' was a term used to indicate ''place of, UR'' referred to ''Light/Spirit'' and, origi-
                                         nally, to “God.”
                                 5.     Neanderthal
                                 6.     Cro-Magnon-1
                               7.     Cro-Magnon-2   
                               8.     Cro-Magnon-3                              
                                 9.     Cro-Magnon-4
                               390  
                

                         
                                 
                                 The WTC/Pentagon Disaster and the “Secrets of the Phoenix and Falcon”
the competing Leviathan races, on behalf of their Fallen Angelic/lntruder ET
kin, battled for conquest of the Atlantic Continent Star Gates.10 
    The Omicron-Drakonian, Odedicron and Zephelium (Zeta) Reptilian
races gained dominance in the Atlantian power struggle, and several
competing Anunnaki forces motivated their Leviathan races to orchestrate a
final victory over the Drakonian/Reptilian and Angelic Human races. This
motivation was formalized in the official agreement of the Luciferian
Covenant OWO Master Plan, what the Anunnakis referred to as the
''Phoenix Project ,'' the name of the Anunnaki-dominion project from the
10,500 BC Luciferian Conquest . In this original Phoenix Project,
Anunnaki Fallen Angelic races of the United Federation of Planets in the
Phantom Matrix  motivated their Leviathan legions on Earth to attempt to
gain dominion over Earth by opening the ''Wall in Time '' that existed
between Earth and Phantom Earth in the Phantom Matrix.  
    The ''W all in Time'' is an artificial frequency barrier that was placed
within the Planetary Shields scalar templates of Earth and Phantom Earth-
the portion of Earth’s Shields that had been drawn into the Black Hole Sub-
Time Distortion Cycle of Phantom Matrix during the Electric Wars 5.5
million years ago (see page 18). The frequency barrier “ Wall”  protected
Earth’s Shields or “Scalar Template,” allowing Earth to continue its natural
evolution within our organic Time Matrix, without threat of Earth, Halls of
Amenti Star Gate control and the rest of our Time Matrix being drawn into
the Phantom Matrix. The Emerald Covenant Founders had erected the Wall
5.5 million  years ago  to protect this Time Matrix from being ''swallowed'' by 
the Phantom Matrix Black Hole. In 10,500 BC  Atlantis, the Anunnaki
Leviathans created a wormhole  frequency bridge between Nohassa Atlantis 
of Earth and the Phantom Matrix planets of Nibiru11 and Tiamat.12 This 
Atlantian ''Hole in the Wall in Time'' was called the Phoenix Wormhole or
Phoenix Matrix  (English translation). Its entry point on Earth was near
Nohassa Atlantis Star Gate-3 , an Atlantian territory called '' Phoenicia ,''
where Earth’s Planetary Ley Line-4-10 (horizontal) crossed through
Planetary Axiatonal Line-7  (vertical).  
    The Phoenix Matrix was “anchored” into Earth’ s Shields, the Golden
Eagle APIN System, the NET and the NDC-Grid through Star Gate-4/ Ley
Line-4  at Giza, Egypt,  and through a secondary Nibiruian Crystal T emple
Network site called '' Cue Site-4 '' in Central Mexico.13 Through the A7/L4
Phoenix wormhole , the Anunnaki were able to electrically interface  Earth’ s
Planetary Shields with those of Nibiru and Tiamat, via their NDC-Grid and
NET  from 25,500 BC. The Anunnaki used the Phoenix Matrix in their long-
term Luciferian Rebellion Master Plan  of drawing Earth and the Halls of
Amenti Star Gates into the Phantom Matrix via merging Earth’s Planetary
                       
                        ______________________                                                10.   SG-11 Lohas, SG-3 Nohasa, and SG-2 Bruah.
                                11.   Density-1.
                                12.   Density-2 Phantom.
                                13.   “ Cue Sites ” are the location points of Inner Earth’s 12 Primary Star Gates, as they
                                        interface with Earth; they are the activation sites  for the corresponding 12 Primary Star
                                        Gates of Earth, which are located in different geographical positions than their counter-
                                        part Cue Sites.    
                              391                                                                                                                
                                                                                                                                  

                       
                             The Wall in Time and Atlantian Secrets of the Phoenix and the Falcon  
Shields with those of Phantom Nibiru and Tiamat, which linked to Phantom
Sirius A  and Trapezium  (Theta) Orion.  This contrived anomaly of
planetary physics would cause part of Earth’s body to burn up, while the
portions that survived black hole transition would emerge in Density-2 as an
“inhabitable moon” to Nibiru . The “ Phoenix14 would rise from the ashes
to be born with a new life ” under Anunnaki exploiting control, and the
Halls of Amenti Star Gates would fall under totalitarian United Federation
of Planets Phantom Matrix dominion. During the 10,500 BC Luciferian
Conquest, the Drakonian/Reptilian/Zeta Leviathan races discovered and
copied the Anunnaki wormhole technology  under motivation of the Zeta-
Dracos, Omicron-Drakonian and Odedicron-reptile avian  races that ruled
Phantom Earth . The “Drakonian Agenda” races created another Wormhole
near the first, on Axiatonal Line-7, Ley Line-3-9 , its “anchoring” position in
Earth’s Shields was located in the Drakonian-conquered Nibiruian Crystal
Temple Network at Star Gate-7,  now Lake Titicaca, Peru . In Atlantis, the
A7/L3  W ormhole was known as the Falcon Matrix —the Drakonian “Bird of
Prey” that would defeat and consume the “Phoenix” wormhole by forcing
Earth’s Planetary Shields into merger with those of Phantom Earth . The
Drakonian agenda races desired to link Earth, once merged with Phantom
Earth, to their intergalactic holdings of Alpha Draconis  in Draco, and
Alnitak, Alnilam, Bellatrix, Rigel and Zeta.  
    When the Falcon Matrix wormhole in the “W all in Time” was in place,
the Andromie-Necromiton  and Centaur  hybrid Fallen Angelic races of
Phantom Alpha Centauri and Omega Centauri and Andromeda raided
Phantom Earth. The Necromiton force temporarily defeated Drakonian rule,
and began using the Falcon Matrix wormhole to raid Atlantis of Earth,
creating a '' Master '' hybrid dominion  race, now called the '' Men in Black ,''
through raiding Annu-Melchizedek Leviathan genetic lines. Fallen Angelic/
Intruder ET races of all kinds emerged from the Phantom Matrix “Pit” to
initiate conquest of Earth.  The Necromiton-Andromie “Alpha-Omega
Anunnaki” races, already in control of the Golden Eagle APIN system  since
the 25,500 BC Lucifer Rebellion, attempted to merge the Phoenix and
Falcon Wormholes , the Golden Eagle APIN and NDC-Grid together, to
secure final territorial dominion of Earth. Emerald Covenant Founders and
Sirius B Maharaji Fleets  intervened directly in Atlantis, squelching the
Luciferian Conquest  and driving Fallen Angelic invasion forces back into
the Phantom Matrix, some escaping into exile on other planets in our Time
Matrix.   
    The Founders '' Capped '' the Phoenix and Falcon Matrix  frequency
bridges to Phantom Matrix, ''patching the holes in the Wall in Time.''
Without planetary access to D-12 frequency , the Founders could not create
a permanent Wormhole ''Cap,'' or activate the Four Faces of Man LPIN  to
restore the Golden Eagle and Great White Lion APIN Systems. In  9560 BC,
the Anunnaki Fallen Angelic races that had escaped to Density-2 Alcyone
and Tara in our Time Matrix motivated their Annu-Melchizedek Leviathan
force of Bruah Atlantis to again open the Phoenix Matrix Wormhole. In
 ________________________
      14.    Phoenicia-Nohassa-Atlantis.
     392
            

                                  
                                         The REAL Founding of America— “Spiking Out the Territory”
9558 BC  this was done as part of the Luciferian Covenant Master Plan to
fully draw  Earth, Inner Earth and the Halls of Amenti into the Phantom
Matrix  Black Hole Sub-Time Distortion Cycle during the next natural
Stellar Activations Cycle—the 2000-2017 SAC.  This plan was also
intended to “ get rid of the competition ” put forth by Angelic Human races
and other members of the Leviathan force who were affiliated with
competing Fallen Angelic collectives.  
   The Thoth-Enki-Zephelium Nibiruian and Samjase-Luciferian
Pleiadian Anunnaki races motivated their Leviathan hybrids to temporarily
''blow a hole in the Cap '' on the Phoenix Matrix wormhole , using the Arc
of the Covenant portal bridge at SG-4 Giza. The Phoenix Matrix was
temporarily opened just enough for the immediate central Atlantian
territories of Nohassa and select portions of Lohas and Bruah to
experience the regional holocaust  of being sucked into the Phantom Matrix .
Forcing the “fall of Atlantis” was only the first step in the Anunnaki OWO
dominion agenda, the climax of which was scheduled for the SAC  of 2000
-2017.  
    When the Phoenix Matrix was opened, Anunnaki forces from Phantom
Nibiru forced additional Photo-sonic scalar pulses  through the NDC-Grid
and Nibiruian Crystal Temple Network of Earth, creating additional
Planetary Shields Distortions and blockages within Earth’s Templar. The
Photo-sonic transmissions pumped through Earth’s Templar from Nibiru in
the Phantom Matrix instantaneously reduced to dust  any buildings,
structures or Atlantian remains on surface Earth that were not placed under
selective Anunnaki force- field protection . The Photo-sonic scalar pulses
and resultant planetary grid distortions caused further mutation in the DNA
Template of Earth’s biological forms, again reduced the life span of all
creatures and ''conveniently'' caused the '' memory files'' stored within the
Human and Leviathan DNA Template to be further '' unplugged. '' The
Anunnaki could not destroy Human and Indigo-Child races  if their Master
Plan was to succeed, as these races were needed to  run their DNA Template
Amenti Security Codes  into Earth’ s Planetary Shields during a SAC, or
Earth’s Star Gates and portals would not open. The Luciferian Covenant
agenda included a massive  ''Planetary Housecleaning , editing and re-
writing '' of any previous records or evidence  pertaining to Advanced
Atlantian Human civilization. The agenda intended progressive claiming of
Earth’s 12 Primary Star Gate  territories  and subjugation of Human and
Indigo races by the Anunnaki Leviathan force, in time for the 2000-20l7
SAC deadline.  
                        THE REAL  FOUNDING OF AMERICA—  
                                 “SPIKING OUT THE TERRITORY”  
           The “ North American ” continent , known then as Ulta-Amekasan-Ur
or Ame-Ka15-Ra,16 which had become inhabitable following the induced
“lce Age” of the 21,900 BC Lohas Celtec-Druidic Freeze-out territorial
                        ________________   
                                              15.   light/spirit body
                                16.   One
                                393 
                      
                                                                                                                                

   
                  
                       The Wall in Time and Atlantian Secrets of the Phoenix and the Falcon
                  conquest, was intended to become the '' New Jerusalem '' of the Jehovian/
Enochian Anunnaki Leviathan, and the new “ Ame- Re-Ka17 of the
Nibiruian Thothian Anunnaki Leviathan.18 The Pleiadian-Nibiruian
Anunnaki’s 9558 BC opening of the Phoenix Matrix was intended to create
climatic instabilities  and a quick-freeze  within select northern and southern
regions. The Pleiadian-Nibiruians planned to “clear the real estate” and
literally '' put it on ice '' to prevent Emerald Covenant races from reinstating
Human and Indigo Guardians there after the orchestrated ''flood.'' The
Anunnaki of the Luciferian Covenant planned to have their '' frozen assets ''
thawed out and populated by their Leviathan race Illuminati Sleepers Power
Elite ,19 in plenty of time for dominion during the 2000-2017 SAC.  
    Prior to the staging of the “fall of Atlantis,” members of the Thothian
Leviathan of Bruah were taken to every continent of Earth, including North
America, where they created a complex system  of what are called “ Atlantian
Spikes ” in Earth’s Planetary Shields. The Spikes, which had been used in
various global areas since implementation of the NDC-Grid at Stonehenge,
are “ Seed Implants ” made of various types of crystalline minerals and
metals,  which are inserted deep into Earth’s Mantle and Crust via photo-
sonic scalar pulse.  When activated , the Spikes become local and regional
transmission stations , originally receiving frequency “broadcasts” from the
NDC-Grid. “Grid Spiking” is one type of APIN system technology , which
is favored by the Pleiadian-Nibiruian Anunnaki. The Phoenix APIN system
“Spiking Campaign” of 9560-9558 BC  Bruah Atlantis connected speci fic
areas of Earth’s Planetary Shields directly to coordinate points  in the
geography of Tiamat  in the Phantom Matrix,  via the Phoenix wormhole.
When activated just before and during the 2000-2017 SAC, as intended by
the Anunnaki, the Spikes would open a series of '' mini-wormholes ,'' directly
to the Phoenix Matrix wormhole, Nibiru and Tiamat, creating powerful
standing-columnar-wave “Pillars” of inaudible sound . The Sonic Pillars
would anchor Earth to the Planetary Shields of Phantom Nibiru and Tiamat.
Through the Spike network of the Phoenix APIN, the NDC-Grid/Nibiruian
Crystal Temple Network Frequency Fence program, which had been
operating in certain regions of Atlantis, at partial capacity since 25,500 BC,
would be ampli fied and strengthened. After the intended ﬂood, the Phoenix
APIN Spike Matrix would allow the NET (Nibiruian Electro-static
Transduction field) to create a global ''perceptual buffer blanket '' that would
prevent species on Earth from perceiving the D-4 Astral Field and would
block Emerald Covenant nations from direct physical and communicative
interference.
           During the 2000-2017 SAC,  the Phoenix Spike Matrix  was intended
to progressively activate via photo-sonic scalar pulses sent through the
          Phoenix wormhole. The NET Frequency Fence  would descend into D-3
                          ________ ____________________
                             
                                17.  “light/spirit re ﬂection”
                                 18.   ln the Atlantian period, the North American continent was named after Human Tribe-3
                                        the Amekasan-Etur,  who had been exiled from their Emerald Covenant post at Nohassa
                                        SG-3 to the North American Continent, as Nohassa and Bruah Atlantis progressively fell
                                        to Leviathan rule after the 10,500 BC Luciferian Conquest.
                                 19.  Knights Templar-Hyksos-Freemasons.
                                394
               
          

                   
                                                      
                                                  The REAL Founding of America— “Spiking Out the Territory”
frequency bands, putting all races under covert Anunnaki Mind Control.
Under Anunnaki Mind Control, Human and Indigo races would mindlessly
follow Anunnaki instructions on running the DNA Template Security
Codes  to open Earth’ s Shields and the final physical Anunnaki invasion  of
Earth would take place without Human and Indigo resistance. Once
physically on planet, the Luciferian Anunnaki intended to complete the final
installation of the 24 Scalar Pulse generator-ampli fication plants  that they
would need to blast through the Cloaking Fields on the Inner Earth portals.
As the Phoenix APIN Spike Matrix moved into full activation while Earth’s
Star Gates progressed in their opening cycle, the Anunnaki would invade
Inner Earth  and connect the Halls of Amenti Star Gate control temples (12
Crystal Pylon Temples of Inner Earth) to the Phoenix APIN Spike Matrix.
Earth, Inner Earth and the Halls of Amenti Star Gates would be rapidly
drawn into the Phantom Matrix black hole , in a position between Tiamat
and Nibiru. In this event, all of Earth’s Life Field would experience  biological
death . But the planetary and personal consciousness  of Earth’ s life-forms
would reassemble along the chaotically grotesque template arrangement of
the Phantom Matrix.  
    In the Phantom Matrix, the consciousness would become trapped in a
distorted image of its original biological or matter form . The distorted body-
thought-form could neither naturally ascend, nor “die” in the usual
manner , but would rather  progressively become more distorted , the
consciousness digressing into perceptual chaos , until eventually the
thought-form-body would implode in upon itself, fragmenting the identity
into undifferentiated units of consciousness  (“space dust”). Survival of
sentience in the Phantom Matrix  is dependent upon devising ways to
literally feed off life-force energies  from other forms in the Phantom Matrix,
or from living beings and living Time Matrix systems. This is how the Fallen
Angelic races sustain themselves, and is precisely why they have tried for 250
billion years (Earth time) to conquer our living Time Matrix and pull it into
their system. Such a feat would provide them with a massive ''food supply ,''
through which to expand and sustain  their continually contracting thought-
form hologram reality field. 
    If the Anunnaki’ s Phoenix Matrix Master Plan  succeeded, the Halls of
Amenti Star Gates would create an open Wormhole interface  into other
living Time Matrices, and the life-forms of Earth  would become entrapped
in deteriorating thought-form bodies  that would become the “ slave demon
force ” of the Fallen Angelic collectives. This was the intention of the
Luciferian Anunnaki when they devised the “Atlantian Flood Drama”; this is
the Destiny of Sorrow  to which they have long desired to condemn our
race . Joining the Fallen Angelics in their finite Phantom Matrix
“holographic prison” is the false ''eternal life '' they have been deviously
promising Human and Illuminati-Leviathan races since the fall of Atlantis.
Real eternal life  is achieved through genuine Ascension and Mastery of
Consciousness within the living Time Matrix . Phantom Matrix ''life-forms''
are not truly “alive” in biological or spiritual terms; they are, in truth, '' living
dead '' races,  finite consciousness thought-form identities  trapped within a
progressively fragmenting and deteriorating Sub-time Universe, who can take
395 
                                                                                                                                                                                                                                                                  
                                                                                                                           

                        
                     
                      
                        The Wall in Time and Atlantian Secrets of the Phoenix and the Falcon
on “biological life” only through using living forms of consciousness as a
Host.  
       Human and Indigo races were sent into this Time Matrix as a guardian,
protector and healer force , intended to protect the living Time Matrix from
the Phantom Matrix system and to assist, if and when possible, in the
reclamation and redemption of the Fallen races and Universal systems.
Presently, we are in the '' Beginning of the End Times '' that the Fallen
Angelics have so often prophesied to us; the Founders Emerald Covenant
Masters Planetary Templar Mechanics  is the only means by which we can
get ourselves out of this Atlantian-created mess. Fortunately for us all, the
Luciferian Covenant plan was not as successful as the Anunnaki
anticipated; if it had been we would not presently have access to any of the
Founders education. The Phoenix Matrix Cap  was opened in Nohassa
Atlantis via a Photo-sonic scalar pulse  that was '' bounced '' from Bruah
Atlantis (the “Gru-AL” central control for Earth’s Planetary Shields),
through Ley Line-4-10,  to Star Gate-4  in Giza, Egypt,  where the Arc of the
Covenant portal bridge to Andromeda was stationed. (See “The Arc of the
Covenant” on page 51). The Luciferian Anunnaki backed Leviathan races
(“Thoth-line” aquatic-ape/Zeta Nibiruian hybrids) of Bruah, had tricked  the
Jehovian Anunnaki backed Leviathan races (Enoch-line Bipedal Dolphin
people hybrids of Sirius A and Arcturus) of Nohassa, into participating in the
9558 BC Atlantian '' Dimensional Blend '' experiment . Both the Thothian
and Enochian Anunnaki factions were “official” members of the Luciferian
Covenant OWO Master Plan, since their respective 22,326 BC and 10,500
BC defections from the Emerald Covenant Co-evolution peace treaty. The
''cover story '' used by the Thothian Leviathan was that, in combining the
powers of Nohassa’s SG-3 and Bruah’s SG-2 together, the usually competing
Anunnaki races could combine their technological powers  to break through
the protective Emerald Covenant Cloaking Shield on the “Andromeda Arc”
portal bridge at Giza. Once the Arc Seal was released, they could “stage a
joint conquest of Inner Earth” and claim the Halls of Amenti Star Gate
control temples. The Thothian races really intended to claim SG-3 control
for themselves and destroy the Enochian “competition.”  
      When the Leviathan races of Bruah and Nohassa launched the Photo-
sonic scalar pulse, the Bruah pulse was purposely sent with an under-
amplified electrical charge . The combined sonic pulse “bounced off” the Arc
Seal at Giza, rather than penetrating it, returned to Bruah via Ley Line-4,
blowing a hole in the Phoenix Matrix Cap as intended . Then the SG-2
Main Power Generator Crystal Temple was used by the Thothian Leviathan
to redirect the pulse through Axiatonal Line-3  that ran vertically through
Nohassa; the pulse refracted an unsuspected back-pulse  to SG-2 Bruah,
reducing the Temples to dust. The central Atlantian Islands of Nohassa were
reduced to what remains as the Bermuda Islands . The land bridge  that
linked Bruah and the North American Continent to the Atlantian land mass
that held the Phoenix Matrix was also destroyed. Lohas in the north, home of
 SG-11,20 suffered the least, while regions in the extreme north and south,
 _________________________
  20.   England-Ireland-Scotland-Wales
 396
               

                                             
                                             The REAL Founding of America— “Spiking Out the Territory”
once habitable lands, experienced ﬂooding and quick-freeze. What the
Thothian Leviathans had not planned on was that members of competing
Leviathan races would survive,  which they did through temporary
evacuation by their respective Fallen Angelic kin. When the sonic pulse was
sent into Axiatonal Line-3 at Nohassa, it “poked another hole in the Cap on
the Wall in Time.” Inadvertently, the Anunnaki had created a  ''tear'' in the
frequency Cap on the Drakonian Fallen Angelic controlled Falcon Matrix
A7/L3-9 wormhole  that led to Phantom Earth.  When the silent Photo-
sonic Pulses hit, portions of the ''Islands of Atlantis '' began to ''sink
beneath the sea .'' The matter of which these geographical regions were
composed, and the life-forms living upon them, literally first “lique fied” into
a semi-plasmic hydro-standing-wave state,  then internally combusted  in a
massive ''flash '' of Photo-radionic light  and '' sank '' into the Black Hole
''Pit'' of the Phantom Matrix.  
    The Planetary Shields distortions resulting from the “fall of Atlantis”
created several frequency '' rips'' in the Anunnaki-controlled NET , which
permitted Emerald Covenant Eieyani races of Inner Earth and Sirius B a
limited amount of time to directly intervene before cataclysmic Earth
changes ensued. The Eieyani temporarily opened some of the surface Earth
portals to Inner Earth and used the Crystal Pylon Temples of the Halls of
Amenti to stabilize Earth’s grids—the Anunnaki-intended cataclysm did not
proceed as fully as the Luciferians had planned . Stabilizing Earth’s
Planetary Shields allowed the Guardians a limited period of time in which
Human l2-Tribe, Indigo and Emerald Covenant Annu-Melchizedek hybrids
were temporarily evacuated to Inner Earth. Drakonian and Anunnaki agenda
Fallen Angelics from Phantom Earth temporarily evacuated their respective
hybrid races via spacecraft. Once the “dust had settled and the waters had
calmed” all races were returned to Earth by their respective resettlement
teams,  and the battle for “critical mass dominion” of Earth’s Templar
began between the Human and Indigo planetary guardians and the
competing families of the Leviathan Force Illuminati-hybrid ''human ''
races . Emerald Covenant races were unable to fully repair the ''holes in the
Wall in Time,'' but the Anunnaki NET  and Phoenix Wormhole APIN
Spiking Matrix  and the Drakonian Falcon wormhole  were  destabilized
during the fiasco, allowing only limited interface  between Earth and the
Phantom Matrix. Emerald Covenant races could not attempt to dismantle
the Anunnaki NET at this time,  as it served as a buffer  for Earth, protecting
it from erratic frequencies that would emerge from the Arc of the Covenant
Andromeda portal without the NET protection. Throughout our known
recorded history , the Leviathan races grew in number, strength and
territorial power under remote Fallen Angelic guardianship . Meanwhile,
amnesiac Human and Indigo races did their best to survive on Earth, and
Emerald Covenant races did their best to assist them via their limited
communicative access through the NET.                          ___________________________________________________________               
                                                                                          The 2000-2017 SAC is the time when the whole mess
                                                           will inevitably “come to a head.”                        ___________________________________________________________                                                                                                     
                                                                                                                                       
                        397  
                                                                                                                              
       

                                                                                          
                          
                           The Wall in Time and Atlantian Secrets of the Phoenix and the Falcon
                                  OUR HIDDEN HISTORY OF SORROW, 9558 BC-PRESENT
   Competing forces from the Phantom Matrix used their limited access to
the Phoenix and Falcon wormholes to misguide their amnesiac Leviathan
Illuminati-hybrid races with falsified historical and religious dogmas , and
''Secret Mystical Metaphysical Societies '' promoting '' Vengeful Creator
God '' propaganda . These falsi fied Control Dogmas , upon which recently-
ancient and contemporary civilizations were built and are still covertly
controlled, were drawn from the once-valid Law of One  freedom-love
spiritual-science texts of the Angelic Human CDT-Plate teachings.  The
Emerald Covenant CDT-Plate  teachings had been the common property of
early Atlantis and Lemuria (Mu’a) and all Human Seedings that came before;
they were the original Founders records, and the basis for the 12 Primary
Spiritual Union Ascension Teachings  of the Human 12-Tribe races. The
original Spiritual Union teachings all agreed with each other,  each
representing the historical, spiritual and sacred science Emerald Covenant
sacred freedom teachings as held in one of the 12 CDT-Plates.  Each of the