98  
    
  

                                                                                           
                                                                                              The Three Christs
    
                      Reintegration of the Races into and Restoration of  
                              the Sphere of Amenti, the Three Christs,  
                           The Zionites and Preparation for 2017 AD.