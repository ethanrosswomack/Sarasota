24 NCT-Bases overtaken by various competing Intruder factions. Intruder Jehovian-Anunnaki create initial '' Dove ''     
APIN . Golden Eagle APIN  ''hi-jacked'' by Necromiton-Andromies/Nephilim hybrids, run on reverse Phantom Matrix     
current as '' White Eagle '' APIN . Pleiadian-Nibiruian Samjase-Luciferian/Enki-Zephelium/Enlil-Odedicron Anunnaki      
install Level-1 '' Serpent '' APIN.  Progressive Annu-Melchizedek Leviathan hybrid race infiltration of Atlantian culture     
advances. GA/Humans/Indigos/Eieyani successful in preventing full Anunnaki invasion.
• 22,500BC-22,326BC:  Founders realize Phantom Matrix near critical mass accretion to pull Earth in. 22,500     
GA/Eieyani-Indigo Crisis Intervention Team from Inner Earth sent to Lemuria (Mauravhi) for Christos Realignment     
Mission  (Level-12 Planetary Maharic Seal) Earth Rescue plan. Eieyani install advanced '' 4 Faces of     
Man ''/''Guardians of the 12 Pillars '' LPIN  to realign/activate Great White Lion, Golden Eagle APIN’s and draw     
Earth into Meajhe Field for Christos Realignment in 22,236BC SAC. GA Sirius B Maharaji and Anteres/Altair     
Rashayana install Blue Oxen APIN  Interface system. Intruder Jehovian-Anunnaki Dove APIN expanded . Thoth     
breaks Emerald Covenant, leads 22,326BC Eieyani Massacre, Founders Christos Realignment Mission postponed      
to next SAC December 21, 2012, “Final Con ﬂict Stale Mate” to resolve 2000-2017AD SAC.  
• 10,500BC:  Luciferian Conquest : Anunnaki/ Drakonian Leviathan Illuminati Atlantian uprising, competing Templar     
Conquest. Two wormholes constructed in “Wall in Time” between Earth/Black Hole Phantom Matrix. The       
Pleiadian/Nibiruian Anunnaki Phoenix Wormhole/  Phoenix APIN  to Phantom Nibiru/ Tiamat and Zeta-Rigelian/     
Drakonian Falcon Wormhole/Falcon APIN  to Phantom Earth/Alpha Draconis. Two Atlantian wormholes give      
advancing Fallen Angelic invasion forces greater dominion potential over Earth/Halls of Amenti Gates for 2000-     
2017AD SAC. Omega Centauri Intruder Blue Centaurs take over Blue Oxen APIN . Enoch defects from Emerald     
Covenant, assists Intruder Jehovian-Anunnaki to link  '' Dove'' APIN to Phoenix Wormhole , creating the 7     
Jehovian Seals/ ''7Trumpets '' advanced Dove HD-C  (Hyper-Dimensional Cone) APIN.  Mars Base  and      
Sphinx/Pyramid-1 destroyed; Sphinx/Pyramid-2 rebuilt by GA, realigned with Pleiadian-Alcyone following    
        10,500BC squelched invasion. Founders/GA secure temporary Phoenix/Falcon Wormholes Cap ; confine              
        Luciferian Conquest to Atlantian Island territories, temporarily pushing back further Anunnaki invasion of Egypt.  
                                                                                              
                                                                        ©2002 Ashayana Deane
518  
                                                                                                            

                                                                                                                    
                                                                                                  
                                                                                                  2001 Update Summary Charts
.      9560BC-9558BC:  Luciferian Covenant . Atlantian Leviathan Illuminati enter Luciferian Anunnaki dominion cov enant   
9560BC , blow GA Cap off Phoenix/Falcon Wormholes  to stage 9558BC ''Atlantian Flood '' and '' Housecleaning ''   
takeover. Sphinx/Pyramid-2  damaged, Alcyone link broken. GA install 9540BC Frequency Fence  to re-Cap     
Wormholes  and prevent cataclysmic early Blue Flame activation. GA create “ Arc of Covenant Gold Box/Rod and     
Staff Star Gate tools  for Indigo Maji-Human race access to Inner Earth portals. Anunnaki, Drakonian and     
Necromiton-Andromie races and Illuminati hybrids run competing territory conquest agendas since 9558BC, try to     
capture Arc of Covenant Gold Box/Rod and Staff tools to activate their APIN's for Templar dominion. Necromiton-    
Andromies join Blue Centaurs in 5,900BC  Centaurian War  in attempt to use ''hi-jacked'' Blue Oxen APIN India for    
Templar dominion; air attacks squelched by GA Sirius B Maharajhi and Pleiadian Serres. Anunnaki Illuminati     
rehabilitate Sphinx/Pyramid-2  as cultural center 5546BC.  Progressive “ Atlantian Conspiracy ” Templar conquest    
throughout post 9558BC period Sumer to America, Illuminati races infiltrate/hybridize with all major Human 12-Tribe    
cultures; Eieyani-Indigo Maji Grail Line retains pure strain 12-48 Strand DNA to fulfill Christos Realignment Mission    
via RRT’s during long-anticipated 2000-2017 SAC “Final Con ﬂict” drama. 
                                                                                          Wormholes, APIN / LPIN’s 1916-2001
• 1903-1916 : Zeta’s of Phantom Earth open Atlantian Falcon wormhole  off coast of Charleston, South Carolina in    
Atlantic Ocean (was Nohassa Atlantis), begin speculation for invasion . Militant Zeta-Rigelian  force of Phantom    
Alnitak-Orion  take over Falcon Wormhole, begin covert infiltration of Earth governments on behalf of the Zeta-    
Drakonian agenda, overthrowing historically positioned Anunnaki strong-hold on Illuminati covert OWO operations.    
Fallen Angelics begin competing progressive conquest for activation/ dominion of APIN systems in preparation for     
2000-2017 SAC. 
• 1930s:  Zeta-Rigelians make treaties with Illuminati hybrid-human races in several major world governments, begin    
early Zeta Treaties  and Majestic-12 seed group covert Illuminati OWO World Management Team under Zeta’s    
Drakonian Agenda . Zeta-Rigelians set out to activate Falcon APIN,  begin Ethnic Virus/  Sonic Pulse Un-natural    
Disaster  program testing for intended reduction of human populations  if SAC commenced in 2000 and     
abduction/hybridization programs . Zeta-Rigelians assist to organize and strengthen Hitler Nazi movement  via    
physical contact with Nazi Inner Circles; Hitler agrees to advance ''Race Supremacy'' program with intention of     
exterminating specific Hibiru Anunnaki Illuminati hybrid races , while protecting Hibiru Illuminati hybrid lines of    
the Drakonian races. Drakonian Illuminati in Allied Governments  covertly assist Nazis  financing. 
• 1940s:  Hitler  makes double deals  with Necromiton-Andromies, and kills groups of Drakonian Hibiru Illuminati;     
Zeta-Rigelians withdraw Nazi support,  assist Allied Governments in victory over Nazi regime, formalization of MJ-