19 Wall in Time, Atlantian Secrets of Phoenix & Falcon .............................386  
          Dimensional Ble nd Experiment, the Wall in Time,
                Illuminati Master Plan 2003 . ............................................................... .386
          The WTC/Pentagon Disaster and
                  the “Secrets of the Phoenix and the Falcon” .................................... ..389
          The Real Founding of America—“Spiking Out the Territory” ..............393
      Our Hidden History of Sorrow, 9558 BC-present ...................................398
          Spiritual Manipulation ..................................................................................399
          Breeding a Final Conﬂict Army & Planetary Shields Reversal. ............401