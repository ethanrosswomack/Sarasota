5  D-8 ORION - EARTH CORE - ACTIV ATION : D-8 Orion Spiral Aligns 2017 day-2 Holographic Beam
                                          DATES A V AILABLE FOR ACTIV ATION : 2017 day-2 through day-3
                                          STAR CRYSTAL SEAL ACTIV ATES: D-9/D-10 BLUE-BLACK CRYSTAL  chakra 13 In Earth's Core
                                          RELEASES STAR CRYSTAL SEALS:  # 7 D-6/D-7 Violet Star #4 D-3/D-4 Green Star & ½ #1 D-1/D 15 Red Star
                                                DNA : Strand 8 assembles, 7 & 8 activate  Fire Code : strands 6-7,3-4, ½ 1-2 activate ACCRETION LEVEL :7 to 8
                                     CHAKRAS : draw frequency from Orion Spiral through chakras 13. 7 &6, into 9 & 10 then into Blue-Black Crystal
                                           Seal in chakra 13 at Earth’s Core
                                    Blue-Black Wave Infusions  of D-9/D-10 frequency begin at one-half Blue-Black Star activation
                                       _______________________________________________________________________________________ 6  D-9 ANDR OMED A-GALACTIC CORE -ACTIV ATION :D-9 Andromeda Spiral Aligns 20I7day-3 Holograph ic Beam
           DATES A V AILABLE FOR ACTIV ATION : 2017 day-3
           STAR CRYSTAL SEAL ACTIV ATES : D-10/D-11 SILVER-BLACK CRYSTAL.  deep space
           RELEASES STAR CRYSTAL SEALS : #8 D-7/D-8 Gold Star Crystal Seal opens
           DNA : Strand 9 assembles & activates  Fire Codes : strands 7-8 activate  ACCRETION LEVEL : 8 to 9
          CHAKRAS : draw frequency from Andromeda Spiral through chakras 6 & 5, into 10 & 11 then into
           Silver-Black Star Crystal Seal in deep space through Andromeda
           Silver-Black wave Infusions  of D-10/D-11 frequency begin at one-half Silver-Black Star activation
                                                                                ©2002 Ashayana Deane        
                              489  
                                                                                                                                              
              
                                                                                                                              

                     Ascension Cycle Dynamics
                                             PLANETARY STELLAR ACTIVATIONS AND WAVE INFUSIONS
                                               The 6 Stellar Activations Earth Will Face Between 5/5/2000 and 2017.