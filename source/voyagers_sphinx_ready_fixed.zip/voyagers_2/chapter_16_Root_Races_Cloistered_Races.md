16 
             
    

                                                                   
                                                        Root Races - Cloistered Races
allow the DNA particles to merge with their anti-particles, creating transmu-
tation of the matter particles and anti-particles, through which DNA strands
7—12 could “plug into” the operating genetic code.)  
   The Root Race held the lower frequency base tone codes of this Earth.
Once both sets of DNA codes were assembled in the DNA through the 24
transmutations, the overtone activation codes from the Cloister would allow
the incarnate to enter its Cloister's morphogenetic field within the Sphere of
Amenti, where DNA strands 7—12 would “plug into” the activation codes. This
would open the morphogenetic field of the Palaidorian collective ( five Clois-
tered Races), where the codes of the other Root Races could be assembled and
the full 12-strand DNA pattern would be restored. As this process of DNA
activation took place, the incarnate was enabled to enter the Blue Flame mor-
phogenetic field of Tara with its consciousness, which began activation of
DNA strands 7-l2 within the body. This process increased the rate of pulsation
of the matter particles of the body into HU-2 patterns, which allowed the
incarnate to turn its body into light, pass through the Halls of Amenti as pure
energy, then re-manifest within a less dense version of that body upon Tara.
The 24 transmutations were lived in one body, which progressively transmuted
as the DNA assembled, until later genetic distortion. Originally the human
body was designed to transmute and ascend, not die and reincarnate. The 24
cycles of transmutation later became 24 cycles of incarnation, or birth and
death, through which the DNA would assemble as the consciousness passed
from one life to another. The original human body was immortal.         
                                 The First Seeding-the Third World                                                                                                                                   25,000,000 to 5,500,000 YA                  
    The pattern for the evolution of the five remaining Root Races was set in
motion 25 million YA. In the first wave of souls moving out of the Palaidorian
morphogenetic field and into physical incarnation The Five Cloistered Races
were entered into Earth in various geographical locations on the Earth.
Through budding/ fission/replication the five Cloistered families each mani-
fested six male and six female beings on Earth, and the same number on the
   parallel, anti-particle Earth. So in the first wave of physical creation on Earth
   60 human beings were manifested, in adult form, out of the Cloistered Races
  morphogenetic field. Each of the five Cloistered Races began with a family of
  12 humans, six male, six female. They entered Earth together, with equal
  standing, seeding the brown- Ur-Antrian, red-Breanoua,  white- Hibiru,  yel-
   low- Melchizedek  and black- Yunaseti races. Earth populations built up through
 this lineage.  
  After about 10 million years of evolution (25-15 million YA) the Third
Root Race was entered through peoples of the Ur-Antrian Cloister. The Third