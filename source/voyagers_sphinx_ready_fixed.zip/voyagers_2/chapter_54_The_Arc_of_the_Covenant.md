54 
 
 

                                                                             
                                                                                 The Arc of the Covenant
planetary frequency high enough to allow the Flame Bearer to fully activate
the codes. Due to the bio-energetic mechanics of the human body, the Flame
Bearer would have to be female in gender, the avatars all male, in order to
keep the energetic balances of the planetary grid intact.  
     During the opening of the Arc of the Covenant there would also be a fam-
ily of individuals appointed to embody the Rod, the orange-gold Flame mor-
phogenetic field of Earth, during the time of transition. The Rod Holder would
be male. Members of these specialized incarnational groups would have to
incarnate in the proper sequence, within the right time periods in conjunction
with the Earth's time cycles, and within the appropriate genetic lineages that
would provide them with the needed genetic imprint. The process of opening
the Arc of the Covenant and allowing the Sphere of Amenti to return to Earth
required a tremendous amount of multidimensional organization. The ful fill-
ment of the promise of the Arc of the Covenant would take over 800,000 years
to ful fill, and meanwhile the races of the Third Seeding would begin their evo-
lutionary journey toward that destination.       
   The Third Seeding through the Arc of the Covenant, the Hebrew,  
           Serres-Egyptians, Urites and the Priesthood of Ur, Races 3-6  
                                     and the Annu-Melchizedeks  
                                             800,000 - 55,000 YA   
      For a period of time following the creation of the Arc of the Covenant
840,000 years ago the Earth went through a period of re-balancing its ener-
getic grid, and during this time the races did not evolve on the planet's sur-
face. Some descendants of the Second Seeding prospered within the lnner
Earth communities, and a few scattered groups had managed to survive
within the underground tunnel systems created by those of the Second Seed-
ing. Most of the human population had ﬂed, finding exile within other plane-
tary systems. The Nephilim had been evacuated to Sirius A, joining
remnants of the Dracos race who had found exile with those who became the
Anunnaki Resistance. About 800,000 years ago several groups of the now
extraterrestrial humans returned to Earth to begin preparation for the Third
Seeding, which would be orchestrated through the Arc of the Covenant por-
tal bridge. Two primary groups of returning humans, descendants of the
Serres-Egyptians  and the Hebrew (Melchizedek-Hibiru hybrids) from the
Second Seeding, were commissioned by the Palaidorians of HU-2, the Elo-
him and the Ra Confederacy to orchestrate the Third Seeding.  
    Upon returning to Earth, these groups discovered that there was a small
group of survivors remaining from the Second Seeding, descendants of the
Third race Lamanians  and their Ur-Antrian  Cloister . The Serres-Egyptians
(who had been exiled on Sirius B and in the Pleiadian star systems, and thus
now carried a stronger ET imprint within their genetic codes) interbred with