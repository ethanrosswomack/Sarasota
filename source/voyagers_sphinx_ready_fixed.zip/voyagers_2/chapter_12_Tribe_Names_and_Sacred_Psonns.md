12 Tribe Names and Sacred Psonns  
      •  If the specific 12 Tribe lineage cannot be determined , individuals can use
     the Sound-Symbol Program of “Tribe-13 ” the Universal Tribe  contain-
  ing all 12-Tribes , running their Rainbow Ray Current and Tribal Fire
 Letters into the Gru-AL Point central control point for Earth’s Planetary
 Shields . 
    • The Tribal Shield  is brought into activation through sounding of the com-
                     pound tonal programs  that represent the audible sound translation  of the
                  specific frequencies  carried in the Tribal Shield  DNA  T emplate Fire
                      Letter Sequences.