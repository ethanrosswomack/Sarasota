24  
           
           
  

                                                                                                                           
                                                                                                             
                                                                                                                 The Electric Wars
 Amenti could be returned to Earth's core, releasing the fourth-dimensional
 Seal of Palaidor and the souls lost in D-2 and D-4 could ascend.
      Not only did the Seal of Palaidor create problems within the incarnational
     process, it also created problems for the physical incarnates on Earth. The race
  morphogenetic field through which a race incarnates represents the living
    memory bank of that evolving race. If the morphogenetic field of a race is
 removed from a planet and its energies are no longer running through the plan-
 etary grid, the entire race memory is wiped out of the planet’s cellular memory.
 People alive on the planet cannot find the content or sequence of most of the
 race memory. They do not remember their origins, the purposes for which they
 came, or their destination through the course of their evolution. The portions
 of the race morphogenetic field removed from the planet take with them the
 DNA strand imprint through which that memory would be stored within an
  incarnate's bodily cellular memory. Corresponding DNA particles break loose
  from the operating DNA strands, lose their sequence of linear order and cannot
   translate through the neurological structure of the human into conscious per-
  ception. DNA particles breaking loose from the operating strands become what
     Earth scientists call “junk DNA," stored within the cells with seemingly no
       purpose.  
      After the Seal of Palaidor was set, the races of the Second Seeding would
 enter incarnation with no memory of their identity or of the higher dimen-
 sional worlds from which they had come. This knowledge would be stored
 within the fourth dimension and could be accessed only through the astral
    essence. The races would also forget their connection to the Earth and to
 each other, as this memory is stored within the second strand, and is blocked
 from mental view. The human of the Second Seeding would have a new kind
 of consciousness, a perception of exaggerated duality and a sense of separa-
 tion from all things that would bury the memory and the truth of the teach-
 ings of the sacred Law of One . Through the dismantled DNA codes stored in
  the cells, the human would develop a subconscious mind, containing the
 consciousness of its second strand and soul fragments drawn in from the D-2
   elemental Uni fied Field. A time of dream assimilation would have to take
 place in order to begin assembling the astral awareness of the fourth strand
 and the soul fragments drawn in from the D-4 uni fied field. A new kind of
 multi-layer consciousness would develop in the human, quite different from
 the earlier uni fied awareness of its immortal body. Even for Visitors of non-
 human lineage, the memory of the planet's history would not be found unless
 it were accessed through the Sphere of Amenti in the fourth dimension. The
   Seal of Palaidor placed Earth in a frequency quarantine, through which it
     became temporarily disconnected from its inter-galactic community. Humans