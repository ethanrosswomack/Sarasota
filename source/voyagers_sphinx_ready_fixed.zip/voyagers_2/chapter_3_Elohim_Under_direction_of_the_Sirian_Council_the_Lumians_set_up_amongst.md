3 Elohim. Under direction of the Sirian Council, the Lumians set up amongst     
their members an organization called The Council of Mu.  Through the Coun-    
cil of Mu the Lumians moved large numbers of their race across the oceans, to a    
small continent on Tara that was primarily uninhabited by organized culture.     
They named this continent Mu, and for 50,000 years (550,750,000 YA to     
550,700,000 YA) the Lumians of Mu worked with the Sirian Council to redi-    
rect the genetic digression of their race. During this period the Elohim of HU-3    
interbred with Lumians who carried the Cerrasz Turaneusiam sub-race strain in
their gene codes, creating a race called the Ceres , which puri fied the genetic  
strain of the Lumians of  Tara. (Descendants of the Ceres later became known   
as the Seres , who interacted with HU-1 Earth humans at various periods.) The
Lumians and Ceres co-existed peacefully on Mu attending to the inter-galactic  
and spiritual business of the Council of Mu. The Ceres created the Priesthood     
of Mu , an egalitarian spiritual collective with a strong matriarchal slant whose 
practices centered around the teachings of the sacred Law of One, or Unity
Consciousness. The Mu priesthood exists to this day and is a primary motivat-  
ing force within certain Taran communities. The community of Mu continued 
its evolution through the re-aligned 12-strand DNA gene code until about 550   
   million years ago.                                                                                                             
                                      Alania, Templar Solar Initiates & the Sirian Rebellion
                                                                 550,750,000 - 550,000,000 YA
    Throughout the evolution of Mu digression continued within the Ala-    
nian race and anti-Lumian sentiment ran high within the power hungry Ala-   
nian elite. The Alanians employed subterranean grid technologies in hopes       
of bringing the now bountiful continent of Mu under Alanian domain. The    
Lumians and the Ceres foresaw the cataclysm of Tara that would result from    
          these technologies about 900 years prior to the events. The Ceres tried to     
warn the Alanians to no avail. Petitions to the Sirian Council to redirect the     
Alanians had failed, giving rise to the Alanian rebellion and Lumian-Sirian    
resistance. The Alanians were controlled by an elite group called the Tem-     
plar Solar Initiates, who had been entrusted with rulership and guardianship       
over the Alanian continent by the Sirian Council. The Templar Solar Ini-