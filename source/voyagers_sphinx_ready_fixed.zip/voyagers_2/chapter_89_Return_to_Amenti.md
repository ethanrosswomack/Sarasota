89 
                                                                                                                                                                                                                       
 

 Return to Amenti  
Annu lived in concentration in the Inner Earth, and were also disbursed
throughout the lands of Egypt and beyond. Through the inner passageways,
Annu from various locations were brought to Akhetaton at Tel el-Amarna
for ascension initiation and training, and then taken secretly into the lower
chambers of the Great Pyramid of Giza where they could pass through the
Halls of Amenti and return to Tara.   
         Though the Halls of Amenti had been opened in 1374 BC, Akhenaton
did not begin ascension practices until 1367 BC, when his sanctuary at
Akhetaton had been prepared and his training with the Priests of Ur had
been completed. For five years, between 1367 BC and 1362 BC Akhenaton
successfully trained and ascended several thousand people through the Halls
of Amenti, secretly and without incident. Though his spiritual commitments
left him little time or concern for the more mundane earthly affairs of poli-
tics, which made him highly unpopular among the general Egyptian popu-
lace, he was quite successful in fulfilling his purposes for incarnating on Earth,
and was held in high esteem by the peoples of Inner Earth and the surface
dwellers who understood the significance of his work. His success was, how-
ever, short lived, as his less-desirable character leanings of arrogance, intoler-
ance for the beliefs of others and favoritism toward the Annu peoples brought
an early end to his achievements, and ultimately created a major setback in
the greater plan of preparing the races for mass ascension. Akhenaton is still
primarily viewed as a master and revered avatar among descendants of the
Melchizedek people, who understand the purposes for his work on Earth. He
deserves much credit for his achievements in realigning the genetic imprint
of the Annu races and reintegrating their morphogenetic field into the
Sphere of Amenti. Though his general Earth mission was successful, it is still
worth mentioning the less-than-desirable events that colored his reign as
Pharaoh. Because of these events, the Halls of Amenti were once again
closed, and the quarantine under which the races had evolved since 9540 BC
remained in effect long after it was originally intended.             
            Conﬂict Between Ser res-Egyptian-Melchizedeks and Annu-  
         Melchizedeks and Akhenaton, Opening the Portals of the Underworld,
   Closing the Halls of Amenti, Guardianship of the Arc of the Covenant  
       transferred to Hibiru Cloister, Deactivation of the Rod and the Staff  
       and the Templar-Axion Seal, Tutankhamon and Haremhab.  
                                         1362 BC -1309 BC  
        
     Akhenaton successfully practiced the rites of ascension among the Annu
populations from 1367 BC to 1362 BC, following directives from the Priests
of Ur in the Inner Earth. Tensions began to mount between Akhenaton and
the Ur Priesthood when he was instructed to begin ascending other individu-
als not of Annu lineage. In his original soul agreement, Akhenaton was to re-