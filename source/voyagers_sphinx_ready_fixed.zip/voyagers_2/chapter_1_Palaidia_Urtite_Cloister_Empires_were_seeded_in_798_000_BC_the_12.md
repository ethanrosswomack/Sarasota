1 Palaidia Urtite-Cloister Empires were seeded in 798,000 BC, the 12
    Tribes of each Evolutionary Round were repeatedly resettled in the same
    geographical regions of Earth that corresponded to the 12 Star Gates of
    Earth to which the DNA  T emplates of the Tribes were “frequency keyed.”
 • The significance in understanding the Angelic Human Cycle of the Rounds
   Evolutionary Blueprint is in that through this understanding we can learn
   much about ourselves and our contemporary drama today . Contemporary
   humanity is part of the fourth Round of the Cycle of the Rounds. Our con-
   tribution during the 2000-2017 SAC is just as important for the success of
   the Planetary Christos Realignment Mission as is that of the Angelic Hu-
        man nations in the other Evolutionary Rounds.  
 • The other Evolutionary Rounds are not a bygone reality of the ancient past;
   they are reality  now .  Time is simultaneous; the other Planetary Time Cy-
    cles within which the other Evolutionary Rounds are taking place exist
   concurrently with our contemporary Planetary Time Cycle, within their
     respective space-time vectors.  
 • The Time Cycles of the past and future Evolutionary Rounds are intimately
   interconnected with our present Time Cycle; each Round directly affects
        the other.  
     
     
        295
           
  

   The Angelic Human Heritage and Rainbow Roundtable
    
        12-CYCLES, SIMULTANEOUS INCARNATION, AND DNA  
 • The reality of the Cycle of the Rounds holds great personal significance  as
                      well as unprecedented collective  importance.  The individuals incarnated
   within the other Evolutionary Rounds are simultaneous incarnations of
   ourselves.  
 • The fact that we exist here today implies that we also have a personal ex-
             pre ssion of self within each of the other Evolutionary Rounds.  
  • In the Cycle of the Round Blueprint there are four Rounds , each containing
    three Planetary Time Cycles , for a total of 12 Planetary Time Cycles  in
    the Particle Universe.  This interwoven set of 12 Planetary Time Cycles
    is called a “ Planetary 12-Cycle.”  There is a corresponding evolutionary
    12-Cycle concurrently taking place within the Anti-Particle Universe of
   Parallel Earth.  The Cycle of the Rounds Divine Blueprint includes both
    the Particle and Anti-Particle  cycles  for a total of “ two Planetary 12-Cy-
    cles” within  the Cycle of the Rounds.  
  • The pattern of “two Planetary 12-Cycles” is the Core Manifestation Tem-
     plate  of the Angelic Human Evolutionary Blueprint. T o incarnate in hu-
     man form a consciousness must adopt this Primal Order  of the Angelic
       Human Evolutionary Divine Blueprint.  
 • Every human incarnate is part of a larger “ family ” of incarnated selves
         called the Personal Christos.  The Personal Christos is the Eternal Per-
       sonal Identity  that includes 1728  simultaneous incarnations, each placed
        within various space-time locations, or  Time V ectors, within the four
           Rounds  of the Cycle of the Rounds.  
 • In each of the four Evolutionary Rounds  there are 216 simultaneously in-
         carnate selves, and their anti-particle counterparts within  the Parallel
         earth system, for a total of 1728  incarnates.1 
    • The 1728 simultaneous incarnations of the Eternal Personal Identity are in-
      carnated into the Angelic Human race forms characteristic to the respec-
            tive Evolutionary Rounds:  Round-2: Palaidia Urtite-Cloister  race.
     Round-3: Urtite-Cloister Race . Round-4: Cloister race.  Round-1: Root
      Races . Each of us have 216 selves incarnate within the Angelic Human
         race lines characteristic to each of the four Evolutionary Rounds.  
 • Each of the three Planetary Time Cycles in each of the four Evolutionary
      Rounds contains 72 Time Vectors.  In one Planetary 12-Cycle  there are
      864 Time Vectors.²  W e each have one incarnate self  in each of the 864
      Time Vectors of one Planetary 12-Cycle and 864 corresponding selves  in
     the Parallel Earth Planetary 12-Cycle. An Angelic Human with a 12-
     Strand DNA  T emplate has 1728  simultaneous selves manifest within
       1728 Time Vectors of Two Planetary 12-Cycles.  
        ___________________________              
    1.   216  selves x 4 Rounds = 864 selves + 86 anti-particle counterpart selves within the Par-
             allel earth system = 1728 selves.  
                    2.   72 Time Vectors per Planetary Time Cycle x 3 Planetary Time Cycles = 216 x 4 Rounds = 
                                  864 Time Vectors.  
 
                       296  
                                                 
1 

                                             
                          12-Cycles, Simultaneous Incarnation, and DNA
•  Indigo Children Maji Grail Line  Angelic Humans with 24-Strand DNA
          T emplates  have 1728 simultaneous selves incarnate in 1728 Time V ec-
          tors in one Planetary 12-Cycle  and 3456 simultaneous selves  in the
         T wo Planetary 12-Cycles  of the Cycle of the Rounds. Maji with  36-
          Strand DNA  T emplates  have 2592  selves in 2592 Time V ectors in one
          Planetary 12-Cycle and 5184 selves  in the Two Planetary 12-Cycles. 48-
          Strand DNA Template Maji have 3456  selves in one 12-Cycle and  6912
             selves  in the two 12-Cycles.  
    • Each of our 1728  Angelic Human selves in their respective Time V ectors
         is interconnected with each other across time  through a shared DNA
          T emplate.  When activated, the 12-Strands  of the 12-Strand DNA  T em-
          plate serve as “ electromagnetic windows ” or “Internal Star Gates”
         through time.  Through the activated 12-Strand DNA T emplate, the fre-
           quencies of energy  and consciousness  of each of the 1728 selves merge
          into an embodied, unified conscious awareness . Each individual incar-
            nate self comes to know itself as an Eternal Christos Avatar Identity  that
          is simultaneously manifesting  in 1728 different Time Vectors , wearing
         the “ costume”  of 1728 different bodies  and personality characteriza-
             tions.   
  • The 1728 simultaneous incarnations of the Personal Christos Eternal Iden-
          tity  represent the '' reincarnational '' heritage  of every 12-Strand Angelic
         Human  being; every human being possesses the dormant imprint of a
         minimum  of the 12-Strand  Angelic Human design. The tangible reality
         of the Personal Christos is held into manifestation within the Personal
         Christos Divine Blueprint ; the D-12  Pre-matter “Liquid-Light” (Hydro-
             plasm) Maharic Shield.  
  • The Personal D-I2 Christos Divine Blueprint Maharic Shield connects
          each Individual Christos self to the larger  D-12 Christos Divine Blueprint
          of the Species. The D-12 Christos Divine Blueprint is called the Tribal
              Shield.  
     • To understand the realities of personal Spiritual Integration  and Actual-
         ization , in order to fulfill our personal life purpose, it is important to
            comprehend the basic Primal Order  structures of energy, the personal D -