12
                                  
                                                 
                     
                  Author’s Closing Statement,1998  
    
    In early June 1998 I began the final proof work on my book Voyagers: the
Sleeping Abductees in preparation for its intended fall 1998 release date. Fol-
lowing a joint physical encounter event that took place on  October 25,
1997,  in which a tremendous amount of new data was given and the Bridge
Zone Project was introduced, the book needed to be updated to include what
had been learned through that extraordinary event. During the 1997 encoun-
ter a physical visitation event was orchestrated from my New Jersey home by
a group of ET beings identifying themselves as members of a guardian group
called the Sirian Arcturian Coalition for Interplanetary Defense.  Later I
learned that this group is a member of the larger Guardian Alliance.  
  In the early morning hours of 10/25/1997, following a spontaneous
neighborhood power blackout, orchestration of an eerie syncopated light dis-
play and mysterious rappings in my daughter’s bedroom, I was physically
escorted outdoors and to a waiting craft that hovered in near silence over my
home. My escorts were semi-solid beings claiming to be of Arcturian origin
and, though their race was unfamiliar to me, the escorts Dralov and Chental
seemed non-threatening. I accompanied them without resistance, as did my
then five-year-old daughter and a visiting UFO investigator who had come to
explore other odd phenomena that I had recently reported. We were taken  
 via “blue beam” into a craft that hovered over my home. We were then   trans-           
  port ed to a massive Arcturian mother-craft named Ashalum.     
                                           The investigator and I were separately given a pri-  
vate tour of the craft then brought to a large auditorium                                        
where other humans waited for a lecture to be held on                             
the“State of Current Earth Affairs.” In the lecture, the         
 various unrelated groups of humans attending were pro-  
 vided with incredible technical data explaining the  
upcoming Bridge Zone Project, the approaching tim-  
continuum shift, IntruderET agendas (Dracos-Zeta Resistance) and the
necessity for humans to take action now. We were asked to share what we had
234 
     


 
                   Author’ s Closing Statement, 1998
learned and to begin assisting others to protect themselves from Intruder
manipulation and in preparing for the time continuum shift. (A full account
of the 10/25/1997 encounter can be found in Contact Forum: The Journal of
the Fifth World,  January-February 1998 issue, V olume 6, Number 1). ¹ 
     Before the Voyagers  book could go to press, the new information was to
be incorporated into the text, so in early June 1998 I busied myself with these
last-minute preparations. Little did I know at the time how far a journey I
would travel before the Voyagers  book was complete. I felt as if  I lived several
decades during the span of three months that it took me to bring this book to
a close. Over the last three months, The Voyagers series has undergone a
transformation, and with it my personal life has also been transformed.  
   On June 26, 1998 I received a vivid subtle contact experience during a
meditation. In this experience a being came to me in a vision and suddenly I
found myself in a state of  bi-location.  While fully awake and aware in my liv-
ing room, I was also simultaneously wide awake and embodied in a new envi-
ronment that looked vaguely familiar to me from earlier teleportation
abduction experiences. Oddly, in this encounter I was not in my “astral body”
for a “mental bi-location” journey, a state of awareness with which I am quite
accustomed, but rather I knew that my physical cells had somehow been
duplicated. My awareness was stationed simultaneously in two versions of my
physical body, in two separate locations. The place to which I was taken was
somewhat familiar, but I did not know its location.  
   However, the being that brought me to this place was quite familiar to
me. She is a human-Guardian ET hybrid named Charleamea . I knew Char-
leamea well, as she was the product of a “ missing fetus” pregnancy/abdu-
tion I had experienced in 1995. The 1995 event was quite traumatic for me at
the time, but later, in early 1997, I was taken by Guardians via teleportation
abduction to meet the child that had been removed from my body in order to
ensure her survival. I observed in awe that a child that should technically
have been no more than two years of age appeared to be the size of a 6-year-
old human and had the maturity and intelligence equivalent to that of adult
human genius. On June 26, 1998 Charleamea made contact with me at the
request of the Guardian Alliance and somehow “split me in two” to bring me
to this mysterious place. Gazing around at what appeared to be the interior of
a massive crystal-lined cave, I asked Charleamea where this beautiful place
was located. She told me “You have entered the Halls of Amenti via the
Hawaiian portal passage.” Prior to this experience I had never heard this
name before.  
  Charleamea proceeded to tell me that something terribly important
had just occurred on this 26th day of June, an event the Guardians had hoped
and prayed for but did not expect to take place. Excitedly she repeated sev-_____ __________________  
1. For a copy ple ase contact ARhAyas Productions, Sarasota, Fl.  
235 
                                                                                                                                                      
                                                                                                                  
                                                                                                     
 

     Author's Closing Statement, 1998   
eral times “The Arc is Sparked!” as I looked at her numbly, lacking compre-
hension. Then we were met by several other, human-looking Guardians and I
was told that I would be given a Keylontic transmission to translate regarding
this event and that when I was through translating the data I would under-
stand. I was taken to a crystalline chamber within the crystal-cave room in
which we stood.  
     Once inside, the chamber filled with intense blue light that began to
vibrate through my cells; I knew that I was being programmed with the trans-
mission in digital-data form. The blue light reached a level of intensity and
high pitched frequency filled the chamber. Suddenly I lost consciousness in
my double-body and was once again singly focused within my body in the liv-
ing room. As I sat on the couch, intense waves of electrical energy passed
through my body, and when I closed my eyes I could clearly see these waves
of ultra-blue light with my inner vision.  
    I sat very still, observing the waves and feeling the near-rapturous sensa-
tions they created within my body cells. After several minutes, the waves
slowed, and the energy “settled” into my nervous system. Suddenly millions
of Keylontic symbols ﬂashed through my mind and inner vision so rapidly
they almost blurred. As this phenomenon subsided a sudden burst of knowl-
edge just opened up inside of me.  
   Suddenly I remembered large blocks of my incarnational history , I
remembered why I had come to Earth this time around and how all of my
other incarnations had been part of the same purpose. Sitting motionless on
the couch I fully remembered myself as an eternal soul, for the first time in
this lifetime. The purpose for all of my past experiences of ET encounters,
visitations and abductions became crystal clear and I began to consciously
remember my soul agreements with other humans here to assist Earth in her
coming changes. Information and memory ﬂashed through my mind and my
body cells seemed to “sing” with recognition. More and more pieces of my
personal history poured through me and the memory expanded to include
human history over vast amounts of time.  
   Then some deeper part of me responded with recognition that con-
sciously I did not possess. This deeper self said, “Wait! What has happened?
That  information has not been available on Earth or accessible to Earth
humans for five million years!” My personality did not know, but my soul-self
understood that “something big had happened.” Then Charleamea telepathi-
cally whispered in my mind.  
      “ The Arc Has Sparked, ” Charleamea again repeated. “The seal on the
Arc has released, the Arc of the Covenant has opened. ” Suddenly the memory
stopped racing through my mind and my sense of expanded consciousness
“pulled in” a little. I felt a huge quantity of electrical data being pulled into
my auric field and knew the Keylontic transmission was ready for translation.
As the experience ended I was awestruck with what had just passed through
236 
    
     

     Authors Closing Statement, 1998  
me. It had moved so quickly that I could hardly “catch” any of it to translate
into words. The bits of memory and cognition I could retain involved my per-
sonal incarnational history and an odd knowing that I had repeatedly incar-
nated as a member of a soul group called the Keepers of the Blue Flame.  But
I would not rediscover what that term meant until completing translation of
the Keylontic transmission.  
     I was told in the dream state that evening that the new transmission must
be translated as soon as possible and added to the existing Voyagers books.
When I began translation of this material, I had no idea how extensive this
addition would become or that I would be given first hand experience in the
subject matter discussed. From June 27th, 1998, until the day of this writing
September 14, 1998, I have spent the majority of my days and nights in trans-
lation. Everything contained within the updated material is completely new
to me; I learned as I translated. Several times during the translation of this
material, I received powerful infusions of energy running through my body as
I transcribed, energy that could be seen through inner vision as blue waves of
light.  
   T oward the end of this transmission I came to understand that these
waves represented the beginning of a  Blue W ave Infusion that accompanied
my personal Heart Star-Solar Activation. I knew absolutely nothing about
these things prior to the June 26th encounter, but suddenly I was living the
realities of which the Guardians had spoken. I learned of soul contracts and
those I personally came to serve, I learned of the Palaidorians and the Priests
of Ur whom I had encountered various times since childhood but never knew
by name. Throughout this three-month period of translating the Guardians’
6/26/98 Keylontic transmission, I have been personally transformed in ways
words cannot describe. It has been a soul awakening. The V oyagers series has
also been transformed. Voyagers: Secrets of Amenti was born.  
   I know that the information contained within the updated pages may
seem utterly unbelievable to many people. We have such a small concept of
the nature of our race that it may be hard to fathom the true greatness hidden
within our evolutionary blueprint. It may be difficult to imagine that the uni-
verse is as glorious as it truly is after viewing it in such limited terms for so
many eons.  
     Do I personally believe the things of which the Guardians have spoken?
You bet I do! I am living the reality of these experiences. Are “Stellar Wave
Activations and Infusions” real? They certainly seem to be real when I feel
this energy periodically rush through my cells, expanding my consciousness
and triggering greater amounts of memory within me, bringing me ever-closer
to feeling at-one-ment with my soul and with the universe; or when Blue
Wave Infusions begin during the dream state and astral projection then pro-
pel me back into my body with such force that the physical body grows hot
with vibrating blue energy running through its cells. The concept of wave
237 
                                                                                                                          
                                                                                                                   
      

Author’ s Closing Statement, 1998  
infusions is also quite convincing when observing large sheets of violet light
cascading through the atmosphere within the room. Though the violet light
sheets do not occur frequently, I have witnessed this effect with a few other
people on several occasions. Will I do as the Guardians suggest and begin to
prepare my body for Stellar Activations and DNA assembly? You bet I will! If
for no other reason than “ What if they are right?”  
  The Guardians have repeatedly demonstrated to me that they know
what they are talking about. I am now paying very close attention to what
they have to say. They have earned my respect with the incredible logic of
the data they provide and they have earned my love through the incredible
transforming, healing events of soul integration I have been privileged to
experience through my work with the Guardian Alliance. They have cer-
tainly accelerated my spiritual evolution; now it is time to discover if indeed
cellular evolution can also be accelerated. Before the 6/26/98 transmission
words such as the Sphere of Amenti, Morphogenetic Waves, Stellar Activa-
tion, Star Crystal Seals  and Stellar Spiral Alignments meant nothing to me;
I had never heard of these terms before. As far as I was concerned, the Arc of
the Covenant represented a fictitious box of something-or-other that was
sought in an Indiana ]ones movie. The concepts of Palaidorian Birthing
Contracts and Contract Bonds,  coming avatars and Indigo Children were
also new to me. The history of the races as presented in this transmission was
utterly foreign to me, yet “felt right” intuitively and in terms of biological cel-
lular memory. I now feel privileged and grateful to have access to such infor-
mation. The Guardians’ teachings offer tools of empowerment for those who
are ready to learn. I consider myself an avid and attentive student of the
Guardian Alliance.  
   This book is written for those who are on the path of awakening, for
those who intrinsically know they are meant to become V oyagers or sense
they are members of the Blue or Violet Flame soul groups. But it is also writ-
ten for others who would like to understand the changes facing humanity at
this juncture of time and space and for those who seek effective methods
through which these changes can be handled. This book is a primer and
serves to set the elaborate conceptual foundations through which under-
standing of the present human condition can be accomplished. This book is
intended for those who are ready to understand the multidimensional drama
of which Earth has always been a part. I hope the knowledge contained
within this book may inspire, uplift and empower the reader, as it has done so
for me.  
       God Bless, and may your V oyage to awakening be sweet and rapture  
filled.  
        —Ashayana Deane 9/14/ 1998  
238 
 

                                                                                                    
                                                                                                                     
                                                                                                
                                                                                                                       The “I Am" Prayer
                                            T HE I AM PRAYER
                                       I AM a Child of the Original ONE,
                                         I AM a Ray of the Original Sun,
                                           I AM Wholeness, I AM Love.
                                I AM the Truth that Spans the Sands of Time,
                                  I AM the Rainbow of the Very First Shine,
                                              I AM Music, I AM Light.
                                        Let the Light Descend Upon Me,
                                      Guide the Way with Golden Light,
                                    No Other God will Stand Before Me...
                          As I Embrace the One True Life I was Born to Live...
                                         By the Will of the Original ONE.
                                       I AM a Face of the Original God,
                                    I AM a V oice of the Original Sound,
                          I AM a Wave Upon the Ocean of Eternal Light.
                          I Reach My Arms Up Unto the Heavens, and say,
                                                 I AM THIS I AM.
                                     The Presence of the Ancient One
                                       Springs Forth at My Command.
                                               I AM One With God,
                                                 I AM THIS I AM...
                                   And, as I Decree It, So It Is.
239 
                            

                     2001 Update Section
                                       
                                       
                
                 13:  Emergency Release GA
                                            A NEW LEVEL OF (CONTINUOUS) REVELATION          
     The information contained in Chapters 1 through 12 of this book rep-
resents a complete reprinting of the original text contained within the first 
printed edition of Voyagers  Volume 2 The Secrets of Amenti . However, 
since the first printing of this book, and its companion, Voyagers Volume 1:   
The Sleeping Abductees , literally massive amounts of new and detailed 
information covering a wide variety of subject matter  has been progressively 
provided by representatives of the Guardian Alliance.. The progressive dis-
pensation of “next level” data includes subjects such as the Science of Cre-
ation Mechanics, 15-Dimensional Physics and intensive natural healing  
and spiritual development programs  as well as profound revelations of data 
pertaining to humanity’s ancient Forbidden History , the realities of Earth’s   
Planetary Templar Complex Star Gate system  and the  intimate relationship
between our lost history, the star gates and the realities of our contemporary 
global drama .  
    The new information presented from this page forward represents a brief 
summary of some of the most urgent material provided since September 
2000 . At the time of the Voyagers Series Books first release in May 1999, 
the dispensation of data concerning the previously mentioned subjects was
caught within an intensive, volatile interstellar political drama ; a drama             
existing “behind the scenes” which dictated the amount of revelation  that 
could be immediately permitted until the inherent political atmosphere had     
reached a more conclusive direction. When the V oyagers book CDT-Plate 
translations were first presented, the Guardian Alliance and other interstellar      
races of the Founders Emerald Covenant Christiac Co-evolution peace  
treaty were embroiled in extensive political negotiations  concerning two pri-
mary ''ET" visitor races, both of whom have shared a long and difficult rela-
tionship with Human civilizations of Earth. These negotiations began in       
November 1992 , when a series of Emerald Covenant treaties called the Ple-  
iadian-Sirian Agreements  were formed between Guardian Emerald Cove-
241 
                            
                                                                                                                                          
 


       2001 Update Section  
nant races and a large group of extraterrestrial or “Angelic” (AKA multiple
density) races collectively called the  Anunnaki.  The two primary biological
lines of the Anunnaki race are the pure-strain  Annu-Elohim  Anunnaki, the 
Bipedal Dolphin People of Densities 2-4 Sirius A and Arcturus,  and many 
various competing  race strains of Anu-Seraphim aquatic-ape-Fallen Ser-
aphim-hybrid Anunnaki of Nibiru,  the Pleiades,  Alpha-Omega Centauri, 
Orion, and Andromeda.    
    THE ANUNNAKI, THE 1992 PLEIADIAN-SIRIAN AGREEMENTS 
                            AND FALLEN ANGELIC (ET) RACES  
    The Anunnaki races have had an intimate relationship with human 
evolution for many millions of years, and unfortunately, this relationship has
rarely demonstrated peaceful co-evolutionary objectives. The Anunnaki race 
identity includes a variety of different interstellar races, all of which have one
thing in common; they were originally created by and through a self-pro-
claimed “anti-Christiac” Fallen Angelic collective called the Annu-Elohim . 
Within the original text of this book no differentiation was made between 
the Elohei-Elohim feline-hominid Human Christos Founders race and the 
Fallen Annu-Elohim  aquatic-ape-cetacean collective that took an anti-
Christiac stance against their Elohei-Elohim kin 250 billion years ago.  
       The timing as to when this distinction was to be made among contempo-
rary human populations depended upon the Emerald Covenant negotiations 
of 1992. Revelation as to this Elohim distinction and the volumes of history
that pertain to their involvement in human evolution was conditional upon
whether or not the Annu-Elohim collectives would choose to abandon their 
long-held dominion agenda in favor of the Emerald Covenant Co-evolution 
treaty during the 2000-2017 Stellar Activations Cycle. If the Fallen Annu-
Elohim collectives chose to honor co-evolution with the races of Earth, the
history of horrors  they have intentionally inflicted upon the earthly races 
would be released more slowly, allowing the Annu-Elohim and their inter-
stellar races time to demonstrate their proclaimed “good faith” within the 
co-evolution agenda, while allowing the humans of Earth a bit more time to
evolve in spiritual maturity so they would not seek to retaliate against the
Annu-Elohim races, and especially the earthly Human-hybrid descendants of 
the Anunnaki and Annu-Elohim, out of revenge for the historical horrors 
they have visited upon the human race.   
       The Founders and Emerald Covenant races were hoping that humanity
could be spared a direct and immediate confrontation  with the trauma of 
its past.  Such confrontation with the truth of human heritage is ultimately 
inevitable for final healing  to occur, but the “blow would be softened” if 
compassion, spiritual strength, forgiveness and understanding could first be 
fostered within the human collective prior to facing the enormity of what 
242 
                                       

                                     The Anunnaki, the 1992 Pleiadian-Sirian Agreements...  
has transpired on Earth  to bring human civilization to its present state  
of painful limitation and relative amnesia.       
    When the first printing of the Voyagers Series books occurred in May 
1999, historical references pertaining to the Annu-Elohim and Anunnaki 
involvement with Earth were presented in a neutral  context,  providing the 
general atmosphere of human evolution, but the “gory details” were not then 
revealed.The timing and method for revelation of the details depended upon 
whether or not the Annu-Elohim and their numerous Anunnaki races   
refused to abandon their intended agenda  of destroying the Human race of 
Earth during the 20002-2017 SAC.   
    The Annu-Elohim created the Anunnaki races about 568 million years 
ago in reaction to creation of the Elohei-Elohim Human Guardian  race; the 
Anunnaki were created with the intention of their race serving as the vessel 
through which the Christiac Human race would be destroyed to provide the 
Annu-Elohim Fallen Angeli totalitarian collective with exploitative domin-
ion over 11 dimensions of our Time Matrix.   
    For many millions of years, Emerald Covenant races have  attempted to
cultivate peaceful co-evolution between the Human and Anunnaki races in 
order to assist both species in fulfilling  their original potential of becoming     
“Christed” (able to achieve ascension and perpetual life expression) races. At 
various periods in our shared history, many Anunnaki races chose to reclaim 
their Christiac potentials through entering the Founder’s Emerald Covenant
to receive the DNA Template Bio-Regenesis  (regeneration) that would 
allow their vision of freedom  from the anti-Christiac control of the Fallen
Annu-Elohim collective to be actualized. Unfortunately for the Anunnaki     
races of the Emerald Covenant and for the Human races on the Christiac 
path who have attempted to help them, the Annu-Elohim Fallen Angelic 
collectives have done everything in their power to enslave the Anunnaki 
species as an “expendable tool” for Human destruction . Historically the
Fallen Annu-Elohim have consistently put forth great efforts of overt and
covert manipulation to prevent the Anunnaki from defecting from the anti-
Christiac agenda in favor of the Founders’ Emerald Covenant freedom
  agenda.   
     In November 1992, the Pleiadian-Sirian Agreements  emerged 
    through a confrontation between Anunnaki  races of the Fallen Annu-Elo-
him, competing Fallen Anu-Seraphim Anunnaki and Drakonian-Reptilian-
Insectoid races of the Dimension-10 Fallen Seraphim collective and the 
Human and Guardian races of the Emerald Covenant. All interstellar races 
knew since 22,326 BC  that this confrontation was likely to occur during the 
long-anticipated 2000-2017AD Stellar Activations Cycle ; only humanity has 
been “left in the dark” regarding knowledge of these events, precisely due 
to the interstellar political realities  that have existed on Earth since 22,326
BC. The 1992 agreements marked the entry of several previously Fallen
243 
                                                                                                                                     
                                                                                                                                                                                                     

                2001 Update Section  
Anunnaki collectives  into the Emerald Covenant following their many
thousands of years of covert manipulation of Earth Human and Anunnaki-
Human-hybrid races. The Fallen Angelic Anunnaki groups who entered the 
Emerald Covenant in 1992, after a long history of running manipulative 
“One World Order”anti-Christiac dominion agendas on Earth are as follows:  
 •  The J ehovian-Sirius-A Anunnaki that run Galactic Federation  and  
     Ashtar Command ¹   
 •  The “ Archangel Michael”  Nephite-Nephilim-Necromiton Anun-  
      naki-hybrid collective of Orion, Alpha-Centauri, Sirius A and   
     Andromeda .²                                          
 •  The Anu-Seraphim Alpha-Omega-Order Templar Melchizedeks ᵌ.        
 •  The Thoth-Enki-Zephelium- (Zeta) Anunnaki collective of Nibiru    
     and Sirius A .4                   
 •  The Enoch Jehovian-Anunnaki collective of Arcturus and Orion .5   
    •  The Anu-Seraphim Pleiadian Samjase-Anunnaki  of Alcyone and  
     their Enlil-Odedicron  and Marduke-Necromition Nibiruian  
     allies .6  
   In 1992 all of the above Anunnaki groups officially entered the Emerald
Covenant in an effort to gain support from Emerald Covenant races  in their
intended stand against the competing Reptile-Insectoid Rigelian-Zeta-
Zephelium, Omicron-Drakonian (Dragon-Moth) and Odedicron-Avian-
Reptilian Fallen Seraphim races of Orion, the  Necromiton-Andromie “Bee-_________________________________________  
1.     Last defected from the Emerald Covenant in 10AD , after several brief periods of entry 
       and  defection before and after the 9558 BC Atlantian ﬂood.  
2.    Defected from the Emerald Covenant in 148,000 BC  to run Jehovian-Annu-Elohim
        Earth dominion agendas and were directly responsible for the Nephilim invasion that                 
               ended Human Seeding-2 during the Thousand Years War of 846,800 BC.  
3.     Have run Drakonian-Centaur-Necromiton-Andromi Anunnaki-hybrid dominion agen-
         das on Earth, in competition with the Jehovian-Annu-Elohim agenda, for thousands of 
       years on behalf of the Fallen Anu-Seraphim collectives.  
4.  Once-trusted Anu-Seraphim Anunnaki members of the Emerald Covenant since 246,000BC,           
     defected from the Emerald Covenant in 22,340 BC  to join the Lucifer Rebellion                                              
         Anu-Seraphim Anunnaki Race Supremacy world dominion agenda.  
5.    Once-trusted Annu-Elohim Jehovian-Anunnaki members of the Emerald Covenant, 
        defected from the Emerald Covenant first in 10,500 BC Atlantis to join the Luciferian 
         Covenant, re-entered in 2250 BC following betrayal by the Anu-Seraphim “Luciferians”, 
        leading to Enoch’s 2024 BC service as an Emerald Covenant CDT-Plate Speaker, then 
     defected again in 10 AD  on behalf of the Annu-Elohim Jehovian-Anunnaki world 
      dominion agenda, until  Enoch petitioned for re-entry into the Emerald Covenant in 
      1983 AD.  
6.   Have run world dominion campaigns on Earth since 250,000 BC,nearly ended Human 
        Seeding-3 through forced occupation of Earth between 147,900 BC-75,877 BC, initiated
         the formalized Luciferian Covenant of 10,500BC and directly orchestrated the 9558 BC
       Atlantian ﬂood and subsequent “House Cleaning” of Earth’s historical records.  
244  
                                                                                                                 

           Solar Star Gate-4 and Anunnaki defection…
tle-People”  and their “ Men In Black”  hybrids, and the Centaur  and Mar-
duke-Dramin-Anunnaki-Omicron hybrids of Alpha and Omega Centauri.  
 SOLAR STAR GATE-4 AND ANUNNAKAI DEFECTION FROM THE 
                        1992 PLEIADIAN-SIRIAN AGREEMENTS   
    If the Anunnaki races had remained loyal to the 1992 Emerald Cove-
nant Pleiadian-Sirian Agreements, the contemporary Earth drama would 
have unfolded much differently than it has,  as the united Emerald Covenant
 Guardian Races and Anunnaki legions could have easily protected the peo-
ples of Earth from the intended 2000-2017 One World Order dominion cam-
paign of the united Drakonian Agenda Fallen Seraphim races. In this event,
the new updated material in the Voyagers  Books would have focused exclu-
sively upon preparing humanity for the inevitable physical meeting  of the
Emerald Covenant and Anunnaki races, and providing humanity with the 
Sacred Science training  needed for humans to resume their original position
as guardians of Earth’s Planetary Templar Complex and the Halls of Amenti  
star gates. Unfortunately, the well-intended 1992 Emerald Covenant Pleia-
dian-Sirian Agreements did not last.   
    When the January 2000  Consummation of the 2000-2017 Stellar Acti-
vations Cycle came around, the Anunnaki legions refused to return control 
of Universal Star Gate-4,  the Solar Gate, over to Emerald Covenant Azurite 
Universal Templar Security Team protection as they had vowed to do in 
1992. Instead, the controlling factions of all of the previously mentioned 
Anunnaki groups, except for the Enochian-Jehovian-Anunnaki collective, 
defected from the Emerald Covenant, reverting to their previous Luciferian 
Covenant and Jehovian One World Order dominion agendas. Since 10 AD, 
Enoch’s loyalties had been to the Jehovian-Nephite One World Order 
dominion agenda until he petitioned for Emerald Covenant re-entry in 1983 
via a Founders’ Redemption Contract; the contemporary works of Enoch pro-
duced prior to 1983 reflect his previous affiliation. When the other Anun-
naki groups defected from the 1992 Pleiadian-Sirian Agreements, Enoch 
remained loyal to the Emerald Covenant cause, and continues to do so as of 
this writing; a status that could change at any time due to continuing pressure 
from the Fallen Jehovian-Annu-Elohim collective of Density-3 Arcturus.  
    The competing Luciferian Covenant and Jehovian Anunnaki dominion 
agendas both hold at their core the intention of using Solar-Star Gate-4, and
an artificial stellar body known as the Nibiruian Battlestar  (AKA  the Bibli-
cal “Wormwood”), to force cataclysmic pole shift on Earth between 2003-
2008, in order to exterminate human populations  in the quest for dominion 
of the Halls of Amenti star gates.  The Nibiruian Anunnaki had seized con-
trol of Solar Star-Gate-4 from Emerald Covenant Guardian race protection 
during the Lucifer Rebellion of 25,500 BC , at which time they used Battle 
Star Nibiru to force Earth’s Templar into an artificial alignment with the
245 
                                                                                                                 
                                                                                                                                                                            
                                                                                                                                              

   2001 Update Section  
planet Nibiru. If Earth’s electromagnetic fields were not properly realigned
with the natural Pleiadian-Spiral alignment of the Universal Star Gates, 
Earth would be forced into pole shift as the 2000-2017 Stellar Activations
Cycle progressed. The Emerald Covenant races initiated the 1992 Pleiadian-
Sirian Agreements as a means of preventing this pending (and long-prophe-
sied) Earth pole shift drama, in hopes that the Human and Anunnaki-hybrid
races of Earth could be spared this catastrophic destiny.  
    The Anunnaki legions chose to enter the 1992 Pleiadian-Sirian Agree-
ments only because their original take-over plans had been somewhat 
thwarted by human Illuminati Zeta Treaty agreements  of the 1930’s, through 
which the Omicron-Drakonian and Odedicron-Reptilian legions gained an 
unanticipated strategic advantage over Anunnaki influence in the contem-
porary Earth drama. The Anunnaki legions chose to break the 1992 Pleia-
dian-Sirian Agreements because Emerald Covenant Founders would not give
in to their demands that the entire human race of Earth be placed under the 
sole elitist dominion of Annu-Melchizedek Anunnaki hybrid races of Inner 
Earth.  
    The Anunnaki broke their original 1992 agreements of shared Human 
and Annu-Melchizedek co-guardianship of Earth’s Templar, and attempted to
use their “trump card” of holding Solar Star Gate-4 as a means to blackmail 
the Founders into placing human destiny “under the thumb” of Anunnaki 
race supremacy.  To agree to such a demand would represent the equivalent of
selling Earth humanity into perpetual Anunnaki slavery,  and the Hidden
Forbidden History of Earth as faithfully recorded on the Emerald Covenant
CDT-Plate holographic discs, clearly demonstrated that such an act  of per-
mitted Anunnaki supremacy on Earth would guarantee the rapid termination 
of the Human species.   
     When the Christos Founders Emerald Covenant races refused to submit 
to the Anunnaki’s self-serving demand of dominion over of humanity’s right to 
freedom and equality, the Anunnaki legions of the 1992 Pleiadian-Sirian 
Agreements all defected, except for Enoch’s group , from the Emerald Cove-
nant in a unified stance, believing that in their unity they could achieve 
Earth dominion through strategic victory over both the feared Drakonian 
Agenda Orion force and the Emerald Covenant Guardian races. The Emer-
ald Covenant Founders races continued negotiations  with any Anunnaki 
groups still interested in peaceful resolution of this building con ﬂict, and on 
July 5, 2000 a new treaty called the  T reaty of Altair ,  was agreed upon; most 
of the defecting Anunnaki groups reluctantly agreed to re-enter the Emer-
ald Covenant upon the Emerald Covenant races’ promise to assist them in the
presently unfolding Orion Wars of Density-3, in which Fallen Annu-Elohim 
Anunnaki holdings in Orion were under aggressive militant attack by the
Omicron-Drakonian  and Odedicron-Reptilian legions of Orion.  
246 

        
                                                                                       The    July 5, 2000, Treaty of  Altair...     
                    T HE JULY 5, 2000 TREATY OF ALTAIR AND                                                                                                                        
ANUNNAKI SABOTAGE OF THE 9/2000 UK EXPEDITION   
        Through the Treaty of Altair, the Anunnaki races of Orion were 
granted the Founders protection from the Drakonian invasion, if the Anun- 
naki legions would honor their original 1992 Emerald Covenant promises,
abandon their intended Earth dominion agendas and immediately release 
solar Star Gate-4 into the protection of the Emerald Covenant Azurite Uni-
versal Templar Security Team. In July 2000, the Anunnaki legions grudgingly
agreed, and in August 2000,  members of the Azurite Security Team  gathered 
at Machu Picchu, Peru to facilitate Emerald Covenant races in the transfer 
of Solar Star Gate-4 into Guardian Alliance Founders’ protection. The Peru 
event went smoothly, and once again the Emerald Covenant races were 
hopeful that the long-pending earthly “Final Conflict Drama”  between 
Human, Emerald Covenant and Fallen Angelic Anunnaki and Drakonian 
forces could be peacefully avoided. The Solar Star Gate-4 transfer to Guard-
ian protection was to be completed in September 2000,  during an event
 scheduled to take place at Stonehenge, England , the location in Earth’s Tem-
plar to which the Nibiruian Battlestar  and artificial planetary alignment 
with Nibiru are anchored. As per the Treaty of Altair, the Anunnaki races
agreed to secure their many Ley Line holdings in England  from Drakonian
race interference, so that members of the Azurite Templar Security Team 
could gain safe passage  to England to complete the final transfer of Solar-Star 
Gate-4 into Guardian protection.  
         On September 12, 2000 , just before the final transfer was to take 
place, the Anunnaki, in a blatant act of betrayal and unanticipated Treaty of 
Altair defection,  used their Ley Line system in England, in co-operation with 
local Omicron-Drakonian  legions, to launch an aggressive psychotronic
 attack  on members of the Azurite Security T eam in England. The Azurite 
Security Team, unaware of what had taken place, was told without explana-
tion in an emergency Guardian Alliance dispatch, to immediately return to 
Guardian Secured Grid Space , and that the scheduled teaching workshops
in U.K must be temporarily postponed to protect attendees  from the
potential harm of anticipated further psychotronic attacks, since the once-
secured England Grid Space had been compromised. The Azurite Security 
     Team immediately cancelled the remaining U.K schedule and returned  to 
Guardian Alliance secured Grid Space in Sarasota, Florida,  to find out what 
  on Earth had happen to cause the U.K Mission to be so rapidly aborted.  
        Upon our return home to Florida, I received a massive dispensation of 
material regarding the political events surrounding the Treaty of Altair. For 
GA security reasons I had been told nothing of this treaty or the volatility of 
the interstellar political atmosphere prior to our journey to England. Prior to 
September 2000 I simply knew that our site work, called Planetary Shields
Clinics,  in Peru and England was intended to assist the Emerald Covenant
247 
                                                                                                               

    2001 Update Section  
races in realigning Earth’s Merkaba Fields with Solar Star Gate-4, to ensure
our planet’s safe passage through the unfolding SAC. The news regarding the 
Treaty of Altair and of the severity of the political drama concerning the con-
temporary Anunnaki “visitor” groups was as new to me in September 2000, as 
it was to others. The news was not good news ,  n o r 
was it particularly welcomed by me, as it brought me into a full and abrupt 
personal confrontation with the realities of our ancient history and how 
these realities were presently manifesting again within the core of our con-
temporary “New Age and UFO Movement”  drama. Even though I had 
plenty of my reincarnational memory open (since birth), and was quite aware 
of some of the ancient horrors that had transpired (some of which I recall 
having lived, and died, through) during periods when the Fallen Angelics  
had turned their full attentions toward Earth, revelation of the Treaty of 
Altair data sent me temporarily into a “Dark Night of the Soul”.  
          Each progressive wave of new revelation required that I face the physical 
reality of what was taking place just beneath the seemingly calm surface  of 
our three-dimensional world, and how this illusion of calm  could be literally ,
permanently and globally shattered at any moment  due to the presently hid-
den realities of interstellar politics. I did not react to the new revelations with
fear; instead, the revelations inspired within me a series of emotional 
responses  that can only be described as the release of ancient experiential
trauma long buried in cellular memory, through which an expanded cogni-
tion of just how “real” the contemporary drama is, came fully into focus. The 
first feeling was one of wanting to deny the reality of our present circum-
stances, because these circumstances are not the way I would personally like
them to be; yet with this feeling came a knowing that in denying the exist-
ence of an undesirable reality you fully throw away any personal power you 
might posses to heal the condition.                                                                                                                                                                                                                                                                        
Healing comes from identifying the problem and taking effective and 
 appropriate action through which the undesired condition can be remedied.
Though in the face of this new information I could observe within myself 
how the three-dimensionally focused personality could be tempted  to utilize 
the emotional escapism of denial  in order to avoid confrontation with a real-
ity it was never trained to face, my greater Eternal Self  “simply knew better”.
Denial gets you nowhere fast —it is simply a way of creating for yourself a 
“glass house” to live in, and if you are going to hide out in glass houses you’d 
better hope that all of your neighbors are friendly and none of them like to 
play baseball. Denial of the new information was not an option  for me,
for deep within me I knew what the GA had revealed was the truth , and that in 
denying this truth I would not only be deluding myself,  but I would be mis-
leading anyone who depended on me to accurately report the contents of 
CDT-Plates and the GA dispensations.  
248 
  
                                                                                                                          
                                                                  

                                                                                    
                                                                     The July 5, 2000, Treaty of Altair…
Having rejected the potential option of self-deluding denial, the second 
emotional response to the new data that I observed within myself was a tem-
porary feeling of “ almost numbness ”, as my ancient selves and contemporary 
self collided in a moment in time with so much sensory overload and intrinsic 
cognition that the limitations of the physical neuro-networks in my manifest 
form temporarily shut down, conveniently shifting me into “observational 
mode”. From this temporary state of disengagement from direct emotional 
reaction, I was able to observe that a part of me felt a peculiar sense of vio-
lation,  not so much for myself, but on behalf of all humans. As if in this final 
revelation of truth, a final discovery of “how things really are and have been”, 
there was somehow an accompanying loss of innocence . Like a child being 
thrust prematurely from a finely sheltered nursery into a battleground of war, 
having been long protected from perception of the atrocities that can and
  often do occur . This “loss of innocence” feeling might be compared to how 
one would feel after dedicating one’s life to a particular company, for exam-
ple, then discovering to one’s horror that the company was knowingly and 
without remorse allowing its employees to be poisoned, while fully intending 
to dismiss them with no accountability for assisting with the medical bills. 
Or perhaps, discovering that your spouse had not only been “having an affair”, 
but had been conspiring with the “other” to have you killed so they 
could collect the insurance policy. A  rude and painful awakening  occurs 
when you discover that things you have believed in for a very long time, 
things perhaps you have built your life around, have  never been what they 
appeared to be,  but rather an expertly crafted  pack of lies created to harm 
and enslave you. When we desire to “know the truth”, and then the truth is 
revealed, what do we do if it is not the truth we wanted to hear?  
    As the GA  dispensations continued following the initial revelations of
 the Treaty of Altair, I realized how grateful I was to finally understand , yet I 
also acknowledge how “Knowing” has suddenly and forcefully “burst my 
bubble ” of naïveté  concerning the type of world within which we presently 
live. At least in America, a country that until recently had not witnessed the
  tragadies of major airborne war on its mainland territories, we seem to be 
raised with a few cultural blind spot  in which we come to believe that “Oh,
it couldn’t be that bad”, or “That could never happen to me”. Confrontation 
    with the revealed logistics of the behind-the-scenes interstellar drama
    showed me just how ﬂimsy such naïvely optimistic attitudes  really are, and
how ill prepared one will be in the face of adversarial conditions if these atti-
tudes of pseudo self-reassurance are indulged.   
    Pessimism and paranoia are not the answers either, for by their very 
nature both  are  disempowering and self-defeating choices of emotional response. 
When on September 12, 2000 the Anunnaki legions defected from their
Treaty of Altair agreements, the  entire contemporary drama  took a turn 
toward the more extreme  in potential experiential outcomes. These poten-   
249                    
                                                                                                                   
                                                                                                                   
 

2001 Update Section  
tials had existed all along, but the GA had been trying to “ease us into ” an 
understanding of our current circumstance, rather than thrust us into a rude 
awakening  that had the potential to generate fear, anger, outrage and panic,
instead of the calmly rendered effective action  that is required to remain 
personally empowered under the present circumstances. Following the Sep-
tember 12, 2000 Anunnaki defection, the GA had no choice but to reveal 
the whole truth of our history and what has been done here at the hands of 
the Anunnaki, because if we didn’t become “wise to the game”  very quickly, 
humanity was about to be “played as terminal fools”.  
                   
            THE SEPTEMBER 2000 UIR AND THE EDICT OF WAR                         
        The most immediately pertinent and pressing truth  that emerged from 
revelation of the Hidden Forbidden History , is facing the fact we are pres-
ently under a state of  covert global  (and galactic)  war , a war of which our 
populations have no directly tangible evidence. How can I make such an 
apparently threatening and most unwelcome statement while still expecting 
myself to be considered a spiritually awakened being? I can make this state-
ment as a  calm statement of fact because I have been made aware that on
 September 12, 2000 the Anunnaki legions not only defected from the peace 
agreements of the Treaty of Altair, but they subsequently  joined forces with 
the previously competing Drakonian Agenda legions, thanks to the Necro-
miton-Andromie’s instigation of forming a “ United Intruder Resistance ” 
(UIR). As a strategic move to ensure the success of the One World Order  
Earth dominion agenda held by each of the competing Fallen Angelic groups, 
the Necromiton  race of Density-3 Andromeda,  the “ beloved Andromies ” 
who have been in contact with several prominent people in the UFO Move-
ment, opened negotiations between the competing Fallen Angelic collec-
tives, successfully bringing most of them together to take a united stance 
against the Emerald Covenant peace treaty and freedom agenda. On Septem-
ber 12, 2000 the GA was given the  ultimatum  that 50,000 of its Grail Line 
Indigo Children could be evacuated out, then the rest of human populations 
were to be left to the agenda of the UIR. Unfortunately, the UIR races 
intended to  instigate pole shift  on Earth between 2003-2008  to “clear the 
real estate”, allowing the humans of Earth to survive just long enough to be 
used to access Earth’s Star Gate opening codes, at which time all, including
the “Chosen Ones” would be destroyed . On behalf of humanity, 
the Founders, the GA, the Maharaji  “blue humans” of Sirius B, the Sirian Coun-
cil, the Lyran High Council and the many billions of Emerald Covenant 
races in our 15-Dimensional Time Matrix told the UIR to “stick their ultima-
tum where the sun doesn’t shine” and refused to withdraw suppor t of Earth’s 
populations. Promptly, and as expected, the UIR issued an Official Edict of 
War against the Founders and Emerald Covenant legions.  
250  
                                                                                                                  
                                             

                                                                 
                                                    The September 2000 UIR and the Edict of War 
        In t erms of intergalactic politics, an Edict of War issued against the 
Founders races really is a “big deal”; and one that contains the potentialities
of intergalactic cataclysmic consequences not often witnessed in our Time 
Matrix. The last time a full Edict of War was issued against the Founders and 
Emerald Covenant races was when Anunnaki legions attempted to destroy
humanity and take over Earth 5,500,000 years ago  during the First Seeding 
of humans on Earth (see page 17), which concluded in the Electric Wars 
that brought Human Seeding-1 to an abrupt and cataclysmic end. Our con-
temporary drama does not have to conclude with the Electric Wars history
repeating itself, but much of the outcome will depend upon what we, as the 
humans of Earth, choose to do, or not to do in the next nine-year period.
       Presently, the greatest threat to our global well being is not the UIR 
itself but rather our amnesia and resulting ignorance  as to how to handle
ourselves effectively. If  we  all sit around and wait for the  “First Contact Mass 
Landing ” to occur,7 to “prove” to us that our ET visitors are real, by THEN, 
know it is too late to do anything other than seek out the nearest Guardian 
evacuation team.  If the First Mass Contact drama does take place, as the 
UIR presently intends  (anywhere between 2002 end and 2005), they will have 
already gained full control of Earth’s portal systems, and will be able to ini-
tiate pole shift precisely when desired via the Nibiruian Battlestar , the crys-
talline installation beneath Stonehenge, England  and their global network 
of subterranean bases  located across the planet. Prevention is the only way
to solve this drama peacefully  before it goes any further.   
    If the UIR movement has its way , the illusion of peace  on Earth will be
maintained until they have their photo-sonic beam-ship fleets in position , 
cloaked within the lower Dimension-4 frequency bands(as many are already)
The fleets will be positioned over numerous secondary Target Sites and 24 Pri-
mary Target Sites , Earth’s 12 Primary Star Gate “Signet Sites”  and their cor-
responding 12 “Templar  Cue  Sites” , the activation sites for the corresponding
Star Gates.   
        Once fleets are positioned, progressive  instigation and amplification of 
conflict and regional wars among human nations will be further implemented 
via psychotronic technology,8  a process of scalar impulsing that has already
begun; Bosnia was the first mass experimental test run, and several other tests
have been already initiated in China,  the Middle East,  Russia and the USA.        
As “ETs” remain a hidden potentiality  to the masses, instances of “Mother    
Mary”, “Jesus”, “Buddha” and “Holy Figure”  holographic inserts  associated     
“Crying Statues and Paintings” and related pseudo-Divine phenomena will 
progressively appear to groups of humans who are mentally ensnared  in both
     _____________________________   
                       7.    In these ''landings,'' false personifications of '' Jesus, Mary and Moses '' will most likely
                                 emerge from a space ship to greet you.                                                                                                                                                 
                          8.    bio-neurological scalar pulse transmission
                      251                                                                                  
                                                                                                                      
                                                                                                                        
                                                                                                                                        

  2001 Update Section           
Traditional and New Age religious dogmas, promoting reassurance that “Gods 
Chosen Ones” will be “saved” in the “Great Cleansing” or “Tribulation”.  
    If the UIR, and their “Puppet Operatives” among the Human Illuminati 
are permitted to continue with their plan, certain hybrid-target-viruses  will be
released among select populations to reduce the number of races considered by
the Fallen Angelics to be expendable; the AIDS virus  was simply an exper-
imental test run originally orchestrated by the Drakonian Agenda Rigelian Zeta  
races via the their Human pawns within the Illuminati World Management 
Team Interior World Government.  The “chemical seedings” known as the
“Chemtrails Phenomenon”  is part of this plan, as certain chemicals that will 
facilitate the activation of the virus once it is released, are presently being 
imbued into the local atmosphere in target locations.   
        As the UIR plan goes on, the HAARP installation and several other 
related global 'facilities' will be activated to broadcast a mass “ Frequency 
Fence ”, a Photo-sonic scalar pulse technology that can harness human
brain-wave patterns  via bio-neurological blocking into a selected frequency
range within which the natural perceptual facilities can be technologically 
manipulated; the target date for the Frequency Fence is 2003-2004 . Once 
“the stage is set” , and global human con ﬂict, fear and instability has reached
its intended peak, the UIR intends to  stage a Mass Landin g, with Galactic 
Federation,  the Pleiadian-Nibiruian Anunnaki,  the Dracos  Reptilian-
hybrids of the Omicron-Drakonian collective and a few Rigelian Zetas 
thrown in for good measure, leading the way. The invading ﬂeets will “ Come 
in Peace as the Peacemakers ”, claiming they are our ancient creator Gods 
and kin who have intervened to “protect us from destroying ourselves and our 
planet”; they will present seemingly miraculous cures for cancer and several 
other diseases (including the plagues they seeded) and provide seemingly
amazing technologies for environmental cleanup …the personifications of 
“Angels sent from above” . If their plan proceeds as intended, the Pope and a 
collective of global religious leaders will gather to inform the public of this 
“Great gift from God”, seducing the masses  into blind subservience to the
“New Angelic World Government”; a “Unified Humanity in the eyes of 
God”. All of these things are part of the UIR strategy to directly and physi-
cally infiltrate global human culture. If we allow them to go this far, our
“United Nations” will be “welcomed” into the Fallen Anu-Seraphim Anun-
naki controlled “ Federation of Planets” , which is a  cover-name  stolen from a
once-valid Emerald Covenant collective, that is now used to refer to territo-
ries conquered by the Anu-Seraphim Anunnaki; territories that exist under
full Anunnaki totalitarian exploitation and dominion. Then and only then,
will the final phase  of the invasion plan be set in motion.  
    In the final phase of the UIR plan, which must occur before the natural 
2012  opening of the Halls of Amenti star gates if the takeover is to succeed, 
Earth’s portal system will be used to invade the territories of Inner Earth , the
252 

                                                                
                                                                          The September 2000 UIR and the Edict of War
 control matrix for the Halls of Amenti Star Gates, which are the real object 
of the UIR conquest. Once Earth’s portals are used to invade the Inner Earth 
Amenti Temple-Generator Complexes , unannounced pole shift on Earth 
will be rapidly set in motion via the Nibiruian Battlestar and a stunned 
humanity will have little more than three days  time to contemplate
“what just hit them”.   
    This is the UIR Plan,  numerous phases of which have already been set
in motion. When the potentialities of a “Zeta Ruled Society” were revealed 
in the 1997-98 GA dispensations that were first published in the 1999 release 
of Voyagers Volume-1:The Sleeping Abductees,  the possibilities of what 
could occur in the event of a UIR Final Conflict Drama were not even 
addressed. At the time of the V oyagers Series 1999 first printing, the 
Founders and Emerald Covenant races were confident that the 1992 Pleia-
dian-Sirian Agreements with the Anunnaki legions would ensure that the 
Orion Zeta forces would not succeed in their intended 2000-2017 attempt of 
instilling a One World Order totalitarian rule on Earth. If left to their own 
devices, the Rigelian Zeta legions would have  “settled for” general dominion
of Earth and forced enslavement  and exploitation of human populations, 
rather than pole shift destruction. But when January 2000  brought the con-
firmed news that a Stellar Activations Cycle would indeed take place on
Earth, even the Zeta and Human Illuminati initiatives were overrun by the 
involvement of the “ big guns ” from of the Fallen Annu-Elohim and Fallen 
Seraphim collectives of Density-4 Dimensions 11 and 10 respectively. The 
“big gun” Fallen Dark Avatar  collectives “play for keeps”, and are not inter-
ested in enslaving humanity; they desire to destroy humanity,  as the once-
Angelic Human species has historically been the primary obstacle  to the
Fallen Angelics in fulfillment of their age-old intention to take full control of
this Time Matrix. Since 22,326 BC , when Emerald Covenant forces blocked 
consummation of a pending SAC to prevent the “big gun” Fallen Angelics
from seizing Earth and the Halls of Amenti, the Fallen Dark Avatar collec-
tives have watched and waited for the 2000-2017 SAC,  with the intention 
of “finishing what they had started”  in 22,326 BC. January 2000 heralded
confirmation of the 2000-2017 SAC, and the whole mess of the “ Final Con-
flict Drama ” was rapidly brought to our earthly door. The present drama and 
its potential consequences are much more serious  and potentially damaging
than those first revealed in the “Zeta Ruled Society” probability depicted in 
Voyagers V olume-1.   
    But we still have time to prevent this mess, if we get our collective
human act together. Fear is the most useless, self-indulgent response we 
can choose to entertain ; no one is going to “fix this for us” but ourselves, and
if we are wallowing in fear like quaking ninnies we will guarantee our own
defeat. Fear is a chosen respons e and so too is courage  and calm, centered 
action; if necessary, allow a bit of natural fear to move through  you and out, 
253                                                                                                                        
                                                                                                          

  2001 Update Section  
then stand up and be effective anyway —humanity holds the power to see 
this thing through to a peaceful outcome of freedom, but only if we become 
rapidly responsible in employing informed, effective attitudes...and...action. 
      Humanity is not alone or unsupported in this rapidly manifesting
Final Conflict Drama; there is much more direct support from interstellar 
Emerald Covenant nations than there is force behind the UIR. The only rea-
son Guardian legions have not made direct, public contact with humanity to 
warn and prepare us for this political confrontation is because the Pleiadian-
Nibiruian Anu-Seraphim Anunnaki forces have held control of  Universal
Solar-Star Gate-4 since 25,500 BC, and have, since the time of the 1992 Ple-
iadian-Sirian Agreements, threatened to use Solar Star Gate-4 and the
Nibiruian Battlestar to  initiate immediate pole shift and destruction on 
Earth if Emerald Covenant representatives attempted to make mass contact
to warn humanity.   
    It was in the Anunnakis’  vested interests to hold off on pole shift because
 fulfillment of their intended One W orld Order dominion agenda and subse-
quent seizure of the Halls of Amenti star gates requires the temporary use of 
humans to open the Security Seals on Earth’s star gates, which the Fallen 
Angelics cannot full access without human biology (i.e DNA Template).
They would have “cleared the real estate” by now if their plan did not require
the use of the specific scalar-wave templates characteristic of human biology
to access the electromagnetic Star Gate Security Coding on Earth’s Plane-
tary Shields scalar template. Only human biology possesses the Security 
Codes to Earth’s Templar, because the Angelic Human species was created  as 
the legitimate Guardian race of this planet, and thus received from the 
Founders races the Planetary Star Gate codes of Earth and the Halls of 
Amenti star gates, within the biological design of the species DNA Template.
This fact of human biology has been the primary reason that humans have 
been historically preyed upon by Fallen Angelic legions, but has also served 
as our primary means of protection from being completely destroyed by the 
Fallen Angelics in their quest for the Halls of Amenti; as long as we are 
needed to open Earth’s Star Gate Security Seals, they don’t dare destroy us if 
they hope to claim control of the Halls of Amenti star gates. But once we
have been sufficiently used to open the Templar Security Codes of Earth dur-
ing an active SAC, we rapidly become expendable. And this is precisely 
what we have been “set up for” since the 22,326 BC cancelled SAC ended
in a stalemate between Emerald Covenant and Fallen Angelic races.  
254 
 

                                                                         
                                                   The D-12 Planetary Security Seal, Planetary Shields...                                                                                                
                  THE D-12 PLANETARY SECURITY SEAL, PLANETARY SHIELDS                                       
                                              CLINICS, AND CRISIS  INTERVENTION  
    If GA  forces had demonstrated a show of power through orchestrating
a mass contact drama to warn humans  of the Anunnaki and Drakonian
intentions, the Anunnaki intended to abort their desired outcome of strategi-
cally using humans to “open the Amenti Gates”, and would settle instead for
destroying contemporary humans via  immediate pole shift, while capturing a
few humans as potential enslaved “Gate Code breeders”. The Anunnaki 
legions, as well as the Drakonian legions, have long understood that if
humanity became awakened,  the Fallen Angelic Amenti dominion plan 
would rapidly come to a screeching halt. Humanity has a hidden power 
within the DNA Template,  through which the innate Planetary Star Gate 
Security Codes can be used to trigger activation of a  natural 12-Dimensional 
Planetary Security Seal  within Earth’s Templar, which if successfully erected,
would permanently protect Earth’s portals and Star Gates  from any further 
Fallen Angelic infiltration. Humans are the greatest threat to the Fallen 
Angelic agenda,  and for this reason they have gone to great lengths to ensure
our genetically-induced race amnesia  and our ignorance to the Sacred Sci-
ence Physics knowledge  through which humanity can regain its intended 
guardianship of Earth’s Templar Complex star gate system. The contemporary
hidden battle with the Fallen Angelic-ET legions cannot be won with exter-
nal weapons and overt war ; the Photo-sonic and Photo-radionic weapons
capacities of the Fallen Angelic legions makes contemporary human weapons
technologies appear as child’s toys in comparison. In terms of the present 
conflict drama, a military stance on humanity’s part is utterly useless, as
humans are literally  “fighting invisible dragons  (and Anunnaki) —a hidden 
adversary that cannot even be tangibly identified due do their superior inter-
dimensional cloaking technologies . Technologically, we're “gonners”. Exter-
nal Technology is not the medium through which the contemporary “playing 
field” becomes leveled for fair play. Knowledge of genuine spirituality, Per-
sonal and Planetary Templar mechanics  and the dynamics of human biology 
and DNA will be the deciding factors in this Final Conflict drama. In this 
regard, “the organic God-given brain and the biological DNA  are might-
ier than Photo-sonic swords born of unnatural external technologies”;
humans can, in the SAC of the present generation, set this planet free from 
27,500 years of covert ET enslavement  by effectively using their God-given
gifts of biology and Spirit.    
    The technology through which humanity can reclaim its freedom and 
intended heritage during the 2000-2017 SAC, and by which the previously
described UIR One World Order dominion agenda can be stopped in its 
tracks, is an internally directed Divine Science technology called  Planetary 
Shields Clinics.  The technical dynamics  of Planetary Shields Clinics are 
beyond the scope of this book; the GA and Azurite Templar Security Team
255 
                                                                                                                                                                                                                             
                                                                                                                                            

  2001 Update Section  
has been directly engaged in conducting advanced Masters Templar training 
workshops  and active Planetary Shields Clinics  since January 2000,  with 
the intention of assisting Earth and humanity in safe- passage through the 
2000-2017 SAC. As per the 1992 Pleiadian-Sirian Agreements, the Anun-
naki legions of the Galactic Federation, Ashtar Command, the Pleiadian-
Nibiruian Council, the Alpha-Omega Templar Melchizedeks, the Thoth-
Enki-Zephelium (Zeta) Nibiruians, the Enoch-Jehovian-Anunnaki collec-
tives and the “Archangel Michael” Nephilim-Nephite collectives were 
entrusted  to assist the GA and Emerald Covenant races in orchestrating 
Planetary Shields Clinics to ensure a safe 2000-2017 SAC. Only the Enoch-
Jehovian-Anunnaki collective has thus far  remained loyal to that 1992
promise. When the Anunnaki legions defected from the 1992 Pleiadian-Sir-
ian Agreements in January 2000, then rendered their final blow of human
 betrayal  in entering the July 5th, 2000, Treaty of Altair only to use this tempo-
rary status as a means of attempted sabotage against the Azurite Security 
Team, then defecting to support the September 12, 2000 Edict of War issued 
by the UIR, the GA and Emerald Covenant races have been on “ Red Alert ” 
and a direct Crisis Intervention plan  has been set in motion.  
        A  very specific program of “Crisis Intervention” Planetary Shields 
Clinics  has been mandated by the Founders, through which Emerald Cove-
nant races and humans who care enough to assist, can manually recode the 
electromagnetic programs in Earth’s Templar and Star Gates that otherwise 
allow the Anunnaki legions to hold Earth in false alignment with Nibiru via 
the Solar-Star Gate-4. The Anunnaki need Earth’s present artificial align-
ment with Nibiru to retain control of Solar Star Gate-4; without control of 
Solar Star Gate-4, the Anunnaki, and thus the UIR, lose their ability to 
force planetary pole shift on Earth . If humans can assist the Emerald Cove-
nant Guardian Races from the Interdimensional Association of Free Worlds
and Azurite Universal Templar Security Team  to restore the natural align-
ment of Solar Star Gate-4 via releasing the artificial Nibiruian programs  in 
Earth’s Templar that  presently hold  Solar Star Gate-4 under Nibiruian con-
trol, the UIR will lose its present “trump card” in this Final Con ﬂict drama. If 
Emerald Covenant races are successful in realigning Earth’s Templar and 
Solar Star Gate-4 to their natural orientation to the Pleiadian-Alcyone Spi-
ral, the previously mentioned 12-Dimensional natural Security Seal  on 
Earth’s Templar can be effectively triggered into activation, blocking UIR 
ﬂeets from entering Earth’s portal and vortex system any further. The chal-
lenge  of the Emerald Covenant Crisis Intervention Program is that it must 
reach a certain stage of advancement  before August 2003 , when the UIR
intends to begin positioning its Photo-sonic Beam-Ship ﬂeets over the previ-
ously mentioned 24 Primary Target Sites  to begin transmission of the 2003-
2004 Frequency Fence  via linking the transmissions of the beam ships 
with the HAARP grid network of Earth.  
256  
                                                                                                                                                                                                                                              

                         
                                     Invasion Agenda, HAARP , Merkaba-Reversal and the Rude Awakening
                      
               INVASION AGENDA, HAARP , MERKABA-REVERSAL,                                                                        
                                           AND THE RUDE AWAKENING   
    Linking of the Invasion Fleet, cloaked in D-4 Frequency Bands, to the
  HAARP grid network of Earth requires the use of the Nibiruian aligned 
Solar-Star Gate-4 ; if this link is successfully made in 2003, Emerald Cove-
nant  forces  can   do   nothing    to    prevent  the UIR from orchestrating the pole 
shift scenario at their whim. If the Emerald Covenant Crisis Intervention 
Planetary Shields Clinics are successful by 2003 , and Solar Star Gate-4 is 
returned to the Founders' protection, the Invasion fleets will be unable to
link with the HAARP network,  which was installed on Earth under the
orders of the Zeta Rigelians of the 1930’s Illuminati Human-Zeta Treaties, in 
anticipation of the 2003 Frequency Fence initiative, which originally was an
 Drakonian-Zeta agenda that was consolidated  into the UIR OWO agenda on 
September 12, 2000.  If Emerald Covenant Planetary Shields Clinics are not 
successful by 2003, the only recourse to protect human populations will be
attempted Emerald Covenant evacuations , which will most likely bring a 
“star wars” drama  rapidly down on humanity’ s head (as has repeatedly
occurred during SAC periods in the past), along with the obvious global
political  panic and chaos that would result from such a drama. If evacuations 
become the only recourse during the present SAC drama, only humans with 
a minimum of 4.25 Strand Sustainable DNA Template activation will be 
able to biologically survive the portal transit to safe ground.9 
    The “Divine Beauty” and simplicity of the Emerald Covenant Crisis
Intervention Plan is that running the Planetary Shields Clinics to clear 
Earth’s electromagnetic grid system requires no militant stance of aggres-
sion, no projection of personal power onto some “Guru, God, Angel or 
channel” outside of yourself, no adherence to any dogma or sacrifice of 
present belief systems, no hatred toward any “enemy” seen or unseen, and 
no entrapment within ideologies of powerlessness and victimization. The 
Planetary Shields Clinics through which Earth can be set free require only 
a willingness to re-awaken to the Sacred Templar Mechanics that were     ____________________________________________  
                     9.     The GA’s Kathara Bio-Spiritual Healing System,  and the DNA Template Bio-Regene-
                sis T echniques  excerpted from this program that appear at the end of this book , are the 
              fastest methods  of naturally activating the dormant 12-Strand DNA  T emplate of
               humans. Most humans are presently at only a 3 to 3.5 Strand DNA Template activation
               level; an insufficient DNA  activation level for sustained portal transit that would result in
                 biological spontaneous combustion if off-planet evacuations were attempted. Not only 
               will the Kathara Healing System rapidly advance natural healing potentials,  assist in 
               expediting genuine personal spiritual integration and progressively build a natural 
               immunity in the personal bio-energetic field and body to psychotronic manipulation , it 
               will stimulate at least enough DNA  Strand T emplate activation for the human biological 
               organism to sustain a minimum 4.25 DNA  Strand T emplate activation level should off-
               planet evacuation become necessary . The Kathara Healing program is highly recom-
                                            mended for obvious reasons; and these are the very reasons that the GA provided the trans-  
                lation of the ancient Kathara Healing teachings in February of 2000.  
                             257                            
                        
                                                                                                                                               

                                                                                    2001 Update Section
once practiced as “daily common knowledge” among the pre-Ancient 
advanced Angelic Human cultures.  True Templar Technology  has always 
been an internal technology  that operates through advanced, natural, Inter-
nal Merkaba Mechanics ; organic dynamics of interdimensional electromag-
netic energy exchange that take place naturally between the Earth’s core 
scalar-wave blueprint (the Planetary Shields ) and the scalar-wave blueprint 
or “Divine Blueprint” of the human DNA Template.  Internal Merkaba T em-
plar Mechanics, when practiced with integrity, are the very same dynamics of
 energy that allow for full spiritual integration  of higher dimensional con-
sciousness into embodied expression within the physical human form, and 
which allow for the once-natural human attribute  of Atomic Transmutation 
and  self-directed Ascension  out of manifest density.10 
    If you have had the misfortune to unknowingly study Merkaba Mechan-
ics under the Anunnaki “edited teaching system, ” you will have learned 
only enough about Merkaba to know how to “ inadvertently ” link your per-
sonal Merkaba Fields to those of other people to form an amplified “Group 
Merkaba”, without securing the natural integrity  of your own bio-fields via a 
natural D-12 frequency alignment to your personal internal D-12  Pre-matter
Christos level of personal anatomy.11 Once you have been taught to indis-
criminantly “open your fields and activate your Merkaba”, you will also have 
been unknowingly  directed to “ run your Merkaba spin ratios in reverse ”. 
Since you have depended upon the Anunnaki “teachers” to “enlighten” you 
about the “secrets of  Merkaba”, you personally have no idea how a Merkaba 
Field  is really supposed to be activated  or maintained, so you can’t tell the 
difference when you are being conned  into running the External Reversed
Merkaba  which blocks your ability to embody natural D-12 frequency for 
genuine higher DNA Strand Template activation. And if you have bought
into the Anunnaki Merkaba Systems  presently being taught through the 
Thoth-Enki-Zephelium Nibiruian Anunnaki and the Alpha-Omega Order  
Templar Melchizedek Anunnaki legions that defected from the 1992 Pleia-
dian-Sirian Agreements, and their recent cohorts in the '' Archangel 
Michael,''12 Galactic Federation  and Ashtar Command  Anunnaki collec-
tives, you will not realize that your inadvertently created External Reverse -
Merkaba field  is being actively used to amplify the 34-Top-Magnetic-
Counter-clockwise, 21-Bottom-Electrical-Clockwise  and BASE-1 1-accel-
eration Nibiruian Reverse-Merkaba spin ratios  in Earth’s grids. Through 
this External Nibiruian Reverse-Merkaba field that some Humans are being  
tricked into creating , the Nibiruian hold on Earth’s Templar is amplified, 
while the human participants are unknowingly “ down-loading ” their inher-_________________________________  
10.  Via Universal Star Gate passage.  
11. You wo n’t have learned much about the reality of your 15-Dimensional Anatomy from
       the Anunnaki either.  
  12.  More aptly described and historically known as ''Arch-Demon Michael. ''  
                                                                                                                
258                        

                     
                     
                        Merkaba Mayhem, REAL Ratios and the Nibiruian Checkerboard Mutation
ent DNA Template Planetary Templar Security Codes into Earth’s grids to 
assist the UIR  in gaining open access to Earth’s Star Gates.   
     These are items just a few of many little facts that the Anunnaki “ascen-
sion programs” fail to mention to the Humans they are sweetly patronizing
 and covertly brainwashing into assisting the UIR objective  through “ chan-
nel Contact ” directives in the New Age Movement. Heads Up, Guys!  Time 
for the Rude Awakening!   
    Do you trust your own potential, inborn Inner Christos Connection , or 
have you inadvertently placed your power , your free will mode of thinking , 
and your potential for true “Christed Consciousness ” and spiritual mastery, in 
the hands of some glorified, self-proclaimed angel or "demi-god" that prom-
ises to create ascension and Christ Consciousness for you?     
    It is a very good time to muster enough humility to take this question 
very seriously.   
         MERKABA MAYHEM, REAL RATIOS , AND THE NIBIRUIAN 
                                CHECKERBOARD MUTATION                
        The natural ''Christiac Merkab '' spin ratio for a being in Density-1/
dimensions 1-2-3, which allows for natural , progressive , automatic Merkaba
Field acceleration and 12-Strand DNA Template activation  for  attainment 
of real D-12  “Christ Consciousness”, Ascension and Star Gate passage, is as 
follows: 33-and-one-third-Top-Electrical-Clockwise, over 11-and-two-
thirds-Bottom-Magnetic-Counter-clockwise,  which is the natural Merkaba
 spin ratio for Density-1 Earth, when Earth’s grids are not being artificially 
forced into mis-alignment with Nibiru. Merkaba Fields govern the circula-
tion and ratios of particle and anti-particle energy  in matter and within the 
human body. It is due to the artificial Reverse-Merkaba spin of Earth’s Den-
sity-1 Merkaba Field , which the Nibiruians orchestrated during the 25,500 
BC Lucifer Rebellion, that the matter base of Earth, and thus that of the 
Human body has been mutated into having two-thirds more particle density 
than the natural blueprint for Density-1. This Nibiruian Legacy and Hidden 
Horror of History of Earth’s 25,500 BC Planetary Merkaba Reversal, which is 
known as the “ Checkerboard Mutation ,” and its continuing devastating con-
sequences regarding Human evolution, DNA and the biological integrity of
all Earth species, are addressed in detail in the forthcoming GA CDT-Plate 
translations. The true Density-1 natural Internal Merkaba Spin Ratios  pre-
viously mentioned can be manually reset  to progressively heal the personal 
Reverse-Merkaba and its resulting  mutations of the DNA  T emplate within 
the Human body, even though Earth’s grids will continue to carry this distor-
tion until Solar Star Gate-4 is brought back into its natural Alcyone-Spiral 
alignment. To maintain the natural personal Merkaba Spin, it must be manu-
ally reset in the body every 24 hours,  or the Reverse-Merkaba  
Spin in the Earth’s grids will override the personal restoration.  
259  
                                                                                           
                                                                                                   
 

      2001 Update Section  
    Advanced Emerald Covenant Merkaba teachings are in the process of 
being released, but are beyond the scope of this book. The four Bio-Regene-
sis Techniques  (see page 493) begin the process of healing the personal
Merkaba and DNA Template. When the Human Merkaba Vehicle is func-
tioning properly, both males and females use the same “androgynous”  Har-
monic Merkaba Spin  and the small internal D-1 Merkaba Field within the 
Tailbone  is not stationary —it rotates, as it is intended to do . The “fixed” 
tailbone Merkaba Field  is the mark of the Nibiruian Merkaba-Reversal  that 
keeps the physical body literally locked into its present time vector  and 
unable to achieve Star Gate passage —Another  of several other “little secrets  
'' that Thoth and his friends conveniently  forgot to mention to their human 
“students”.  
    One is better off using the D-12 Based Maharata Current Bio-Regene-
sis Techniques  (see page 503) until more advanced, genuine Merkaba  
Mechanics are available, as these Techniques will begin to automatically 
reset the natural Density-1 Merkaba Ratios in the body. Further techniques 
to accelerate  and fully activate  the natural Merkaba are on the way. Most  of 
the humans who have fallen into using or teaching  the Nibiruian Reverse-
Merkaba  have been covertly “set up” by the Thoth-Enki-Zephelium or 
Alpha-Omega Templar Melchizedek Anunnaki races to propagate this Base-
11-Reverse Merkaba  perversion. Most, but not all, human teachers of Merk-
aba do not realize that they have been deceived in this way, and are not
intentionally bringing harm to their students; the teachers themselves are
being victimized and deceived by Fallen Angelic contacts.  
 
                                                     260