3  D-6 SIRIAN  - EARTH STAR - ACTIV ATION: D6 Sirian Spiral Aligns 6/2008
   DATES A V AILABLE FOR ACTIV ATION ; 7/22/2008 - 2017 day-3 of conversion period 5/5/2017 - 6/30/2017
   STAR CRYSTAL SEAL ACTIV ATES  # 8 D-7/D0 GOLD STAR CRYSTAL : chakra 12 6" below feet
   RELEASES STAR CRYSTAL SEAL : #5 D-4/D-5 Blue Star Crystal Seal opens
   DNA : Strand 6 assembles to activate 2017 day-3 Fire Code : strands 4-5 activate ACCRETION LEVEL : 5 to 6
   CHAKRAS:  draw frequency from Sirian Spiral through chakras 12, 9 8& 8 then into chakra 7, back to 12 and
   into Gold Star Crystal Seal
   Gold Wave lnfusions  of D-7/D-8 frequency begin at Gold Star one-half activation
                                             __________________________________________________________________________________ _____