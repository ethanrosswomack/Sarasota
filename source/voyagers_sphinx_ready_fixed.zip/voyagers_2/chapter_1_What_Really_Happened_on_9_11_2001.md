1 

                                                                        
                                                                                    What Really Happened on 9/11/2001
Earth’s Planetary Shields; Human DNA progressively activates the 12th-sub-
frequency band in each of 12 Human DNA Strand Templates, creating a
progressive natural Maharic Seal  and resulting biological immunity to SAC.  
    T o the great dismay of the UIR, the “ Mass Awakening ” has now begun,
which means that even unaware Humans, all over the planet, will now
progressively and unknowingly begin running D-12 frequency into Earth’s
Planetary Shields. After thousands of years of forced DNA template
repression, the Bio-electric Conductor of Human biology  is finally
awakening to do what it was designed to do—transmit 12-Code Pulses  into
Earth’s Planetary Shields, via the DNA Template/Merkaba/Kundalini-
Maharata Current connection. This is Divine Biotronic Technology at its
best! Through the Bio-electric Conductor of the Human body, Earth’s
natural D-12 Planetary Maharic Seal Templar protection field will be
progressively triggered into activation. As the Human DNA Template
awakens, the ancient Emerald Covenant ''Four Faces of Man,'' ''Great White
Lion'' and ''Golden Eagle'' APIN Systems  (see page 527) will
synchronistically come to life, ushering Earth into the “protective blanket” of
the Trion/Meajhé Field (see page 517).  
       Fallen Angelic races of the Phantom Matrix cannot utilize full-spectrum
D-12 frequency or higher—their biology and technologies  are limited to D-
10 to D-11.5 transmission/reception capacity. The D-12 Hydroplasmic
''Christos'' Maharata frequency and Trion Field Primal Creation Currents
will naturally override any Phantom Matrix distortions within Earth’s
Planetary Shields and biological DNA, if D-12 frequency reaches a critical
mass charge  in Earth’s Templar.  Currently , the UIR  has realized that it is
now '' in a race for time ,'' Their originally intended 2003-2004
''Dimensional Blend Experiment '' (see page 386) and '' Frequency Fence ''2
will not occur if D-12 frequency reaches Critical Mass  in Earth’ s Planetary
Shields before 2003 . 
      Critical Mass 12-Code Pulse will be achieved in 2002 if people
continue to assist Emerald Covenant races in Rainbow Roundtables
(RRTs) to activate the Four Faces of Man LPIN and build the Trion/
Meajhé Field and if the  Mass Human DNA  A wakening continues. The
Checkerboard Matrix DNA  Mutation that reversed the Security Code
sequences in Human DNA and Merkaba Field was carefully orchestrated by
the Annunaki Invasion force since 25,500 BC, and painstakingly nurtured
since the 9558 BC fall of Atlantis.'' Due to efforts of the Indigo Children in
working directly with Emerald Covenant nations and DNA Bio-Regenesis,
Maharata Merkaba and RRT technologies to clear ''Checkerboard DNA
Reversal'' distortions, the organic sequencing  of frequencies is now activating
in the Mass DNA Template, clearing ancient distortions as it goes.3 The
entire, long-suffered Fallen Angelic OWO Amenti dominion Master Plan
                        _____________________
2.     Pre-invasion Mass Mind Control/DNA and Pineal Gland suppression campaign.
3.     We have just begun offering “Advanced Personal Coping Skills” programs regarding
        Spontaneous Mass DNA Template purging  and activation. We need to learn to handle
        these organic “purging” energies in our bodies, minds and emotions or these energies will     
        “throw us all for a collective loop.” This DNA purging will affect all Humans and Illumi-
        nati-hybrid races via the Planetary Shields scalar template.         
405                                         
                                                                                                                      
                                                                                                                                                                                                                                                                                
            

                                                                        
                        
                        HAARPs, Trumpets, Horsemen, and Heaven
will be shut down completely if Earth reaches 12-Code Pulse Critical Mass
before 2003. Suddenly their plan has begun to “turn in on them.” All of those
multitudes of excess Human bodies that Fallen Angelics have so carefully
“cultivated” to become their “Reverse Security Code Amnesiac Inside
Invasion Force” in the Final Conﬂict drama are now Spontaneously Healing.___________________________________________________________   
  If the Fallen Angelics don’t do something to prevent further Human DNA
  activation, their “ Human Amnesiacs Force ” will become the “ Awakened
    Human Victory Force ,” the very force by which the Fallen Angelics
                                      diabolical agenda is defeated.   ___________________________________________________________
     The UIR Fallen Angelics are now scrambling to motivate their
Illuminati Sleeper puppets of the World Management Team to force
through immediately their OWO Master Plan.  As they have always known,
it must be done carefully, and in stages, or else public suspicion and mass
chaotic rebellion might occur. The UIR Illuminati have started their OWO
Master Plan off with a bang—actually, more like a “boom,” three big ones
and one small one, to be precise.  
      On Monday September 3, 2001,  the last day of our Labor Day
Workshop, the CIA/Eieyani informed us that the UIR had begun a certain
type of “Phantom Pulse” transmission  through the Montauk-Phi-Ex Falcon
APIN System, which interrelates with UIR Beamships via the earthly
HAARP network . The Eieyani explained that the UIR had begun linking
their D-4 Cloaked Beamship crafts into the hidden HAARP installations
(see page 257) to begin Frequency Fence transmission now, rather than
waiting until their originally scheduled target date of 2004. These
transmissions are intended to rapidly lower the NET Frequency Fence  into
the 3-D frequency bands to prevent continuation of the Spontaneous Mass
Human DNA Template Awakening  that is now occurring. The GA  have
since explained that the HAARP facility in Alaska  is the least powerful of
all and was not the facility from which the August 12, 2001, pulses were
launched . The Alaskan HAARP was created  as a ''decoy ''—there are 12
other similar facilities on Phantom Earth,  that interface with our Earth  via
the Falcon APIN system  and the Drakonian-controlled sites of the
Nibiruian Crystal Temple Network.4 
      The Phantom Earth HAARPs, originally Zeta-Rigelian technologies,
are the intended primary transmission stations  in the OWO agenda.
Unfortunately, Angels do Play These HAARPs —fallen angels,  and they
play “Trumpets” too . The Intruder ET Technology code named the
Trumpet  has been used on Earth by the Jehovian Annunaki and
Necromiton-Andromie Fallen Angelics—primarily during various time
periods when our ancient Intruders desired to “keep the earthly populace in
line.” Classic Biblical references pertaining to the use of the “ Trumpet
 T echnology ” can be found in the stories of the “Walls of Jericho Tumbling
                        ______________________                         
                      4.  The Anunnaki originally entered the 1992 Pleiadian-Sirian Agreements because they
                       had lost programming control of all but 9 out of the 24 Nibiruian Crystal Temple Net-
                      works to Drakonian, Reptilian and Necromiton conquest that resulted from the Zeta
                                   Rigelians’ success in expanding the Falcon Matrix wormhole during the 1983  Montauk   project.    
                                                                                                             
                          406

                                                              
                                                           The Hidden Realities of the WTC/Pentagon Disaster
Down” and the likewise the “Tower of Babel,” and in the fall of “Sodom and
Gomorrah.” The Bible, which derived from Jehovian embellishments of
edited Emerald Covenant Essene CDT-Plate translations, presents colorful,
encoded stories of Intruder  ET/Fallen Angelic technological dominion  of
earthly races  presented under the guise of “ the Wrath of God.”  Decoding
the truths hidden within the drama of the Biblical Revelations  story will
assist us in comprehending the position Earth is presently in regarding
advancement of the Fallen Angelic OWO dominion agenda, and the
advanced technologies they have at their disposal. Full translation of the
“Revelations Story” is extremely pertinent to our times, but this subject is
beyond the scope of this book. Further materials concerning the
''Revelations of Revelation '' will soon be available in other texts. For the
purposes of this writing, l will simply address the subject of the “Trumpets,”
which feature prominently in Chapters 8-11 of the Book of Revelations. Just
as Fallen Angels are skilled HAARP players, they are equally “talented” in the
diabolical arts of '' Trumpeteering .'' It is within the Silent Symphony of the
Fallen Angelic “Brass Section” that the hidden reality  of the September
11, 2001, WTC/Pentagon Terrorist Attack Disaster can be found . 
                 
                                          THE TRUMPETS, TOWERS AND TERRORISTS—
                         THE HIDDEN REALITIES OF THE WTC/PENTAGON DISASTER
     The '' Trumpet '' technology  in which the Jehovian Annunaki and
Necromiton-Andromie Fallen Angelic races specialize is a physical
technology  that utilizes a mechanical frequency generation apparatus to
create and project very specific sound structures  to desired long-range
targets.  The Sound Structures are specifically formed sub-space wave fields
composed of micro-sub-atomic units called Mions.  Mion units are a natural
part of manifest matter, composed of groups of the smaller Partiki, Partika
and Particum units (see page 453) that form the blueprints of matter. Mions
represent the stage of transition  between the scalar-standing-wave Partiki
Grid Template and the manifest quarks, mesons, mueons, and sub-atomic
particles, that group to form the atoms, molecules and matter structures that
our contemporary scientists presently recognize.  
     The Trumpet technology utilizes specifically calibrated electromagnetic
wave fields, combined at precise angles of interface , which, when '' sparked ''
with a specific type of electrical charge, create a “ Sub-space Sonic Beam ”
that is literally shaped like a trumpet. The '' Trumpet '' Sub-Space Mion Field
wave-form  has a long tubelike extension emerging from its point of
projection to its target. At the target site, the Trumpet wave-field expands
outward into an inverted cone, like the “head” of a trumpet instrument. The
Mion vibration rhythm  of the Trumpet wave-field can be precisely
calibrated  to “match” the scalar-template of any matter form. Once the
''Form-lock '' is established, the vibration rhythm of the Trumpet wave-field
is progressively accelerated, which causes the template of the matter-form to
which it is bonded to instantaneously shatter. When the scalar-template of a
wave-form shatters, the physical matter structure literally “de-manifests” into
vapor , leaving only a trace of residual ash behind. The Trumpet technology 
407     
                                                                                                                                                    

                                
                         
                         HAARPs, Trumpets, Horsemen, and Heaven
can be used with loving intention in a variety of ways, but in the hands of
Fallen Angelic races, the Trumpet is a weapon of mass destruction.  
   Strong Trumpet Pulses are more difficult to direct with pin-point
accuracy over long distances—matter surrounding the Trumpet Pulse target
can be structurally affected in long-range, amplified Trumpet Pulse
projection. The Jehovian Anunnaki and Necromiton-Andromie races of the
UIR knew this on August 12, 2001 , as they strategized their plan to fully re-
open and activate the Montauk-Phi-Ex Falcon Matrix APIN system, and
connect it to the “Grid Spikes” of the Phoenix APIN system. The
''Trumpets '' stationed on Alpha Centauri and Arcturus in the Phantom
Matrix would have to be used via Phoenix wormhole transmission, if the UIR
was to fulfill its mission of activating and connecting three of the Primary
Phoenix Spikes to the Montauk-Phi-Ex Port Interface Network and
Falcon wormhole.  
      The site of the WTC Twin Towers buildings in New York City  is one
of numerous Phoenix Spike Sites in NYC that connect directly to the
Phoenix wormhole via the Manhattan V ortex and Montauk-Phi-Ex Falcon
APIN. The area of the Pentagon that was damaged in the September 11,
2001, terrorist attacks was built over another Primary Phoenix Spike site, as
are numerous other buildings and the White House, in the Washington,
D.C., area. The third Phoenix Spike site the UIR had hoped to “put on line”
with the Falcon is located in Philadelphia, PA.  The UIR mobilized the bin
Laden Sleepers group to orchestrate the “terrorist attacks” in NYC and
D.C.  in order to produce a '' cover '' to hide the potential effects of the
Trumpet Pulse  that was to be sent to the Phoenix Spike sites at these
locations. If the WTC Towers “just happened to fall down,” and if part of the
Pentagon ''just happened to collapse'' around the same time, somebody would
definitely take notice. The terrorist attacks  were staged by the bin Laden
and related UIR Illuminati Sleeper factions to create a “public smoke
screen” should the Trumpet Pulses cause collapse of the buildings atop the
Phoenix Spikes . This is the reality  of what took place on September 11, 2001,
as the UIR began their aggressive campaign to accelerate their OWO
dominion agenda.  
    In orchestration of the 9/11/2001 event, first a sub-space sonic
amplification pulse  was rendered on August 12, 2001 . This slower-moving
ULF scalar pulse  was simultaneously launched from two locations  during
the yearly planetary '' Magnetic Peak '' cycle that climaxes on August 12.5
The first sonic pulse was sent from an area in Central Mexico  called ''Cue
Site-4,'' an Annunaki ''Serpent'' Base (Thoth-Enki-Zeta Nibiruian
Annunaki), via the Chihuahua, Mexico, Nibiruian Crystal Temple
Network.  The pulse was sent first north, then east along horizontal Ley
                           
                             ____________________________
                5.   A planetary ''Magnetic Peak'' occurs when the planetary Merkaba Field reaches its fastest
                      spin rotation, which amplifies all types of scalar projections. Primary Peaks occur between 
                      August 7-16, with the climax speed consistently occurring on August 12. Stronger peaks
                      occur on August 12 every 20 years, and the strongest every 100 years. The 1943 Philadel-
                    phia Experiment and 1983 Montauk Project were launched on the 20-year August 12
                     Magnetic Peak. The UIRs’  intended Dimensional Blend Experiment  is planned for the
                              100-year Magnetic Peak of August 12, 2003.   
                   408                                              
                     
                                   

                                                 
                                                         
                                                          The Hidden Realities of the WTC/Pentagon Disaster
                 Line-2,  and passed through the Star Gate-2 Gru-AL Point  at Sarasota, FL,
on September 3, 2001.6 
      The Mexico Pulse intercepted the second pulse off the coast of St.
Augustine, FL, at vertical Axiatonal Line-7, the Falcon wormhole,  on
September 7 . The second “sonic slow pulse” transmitted on August 12, was
released northward from the Zeta/Necromiton-Andromie “Falcon” Base
beneath Lake Titicaca, Peru,  on Axiatonal Line-7. The two ULF sonic
pulses interfaced at the Falcon wormhole  on A7/L4, and were then further
amplified and transmitted via Ley Line-3 to the Star Gate-3 “Falcon” Base in
the Bermuda Islands . The amplification pulse was held at SG-3 Bermuda
until September 11, 2001 . On September 11, the '' Dove '' group  (Jehovian
Annunaki), using the Phoenix wormhole at A7/L4, and the '' White Eagle ''
group (Necromiton-Andromie Alpha-Omega), using the Falcon wormhole,
simultaneously transmitted two massive sub-space '' Trumpet Pulses .'' The
Trumpet Pulses were projected from the Falcon/Phoenix wormholes through
Ley Line-3 to the Bermuda Base. At the Bermuda Base, the Trumpet Pulses
were then combined into one, accelerated via the stored amplification pulse
and directed from the Bermuda Base  through the Montauk-Phi-Ex Port
Interface Network  and into the subterranean WTC NYC  Phoenix Spike
location. Moments later the first plane struck the first WTC tower, as the
UIR had previously arranged and delicately coordinated. Another Trumpet
Pulse was released for WTC Tower 2 and another for the Pentagon, using the
same procedure. The Eieyani explained that the Philadelphia, PA , Phoenix
Spike site was also intended as a UIR target on September 11, but the
“cover,” the fourth plane, never made it to its intended destination, and so
the “fourth Trumpet” didn’t “sound.”  
       Other Primary  Phoenix Spike sites on the UIR “first wave” activation
list include Atlanta-GA, Las V egas-NV , Spokane-W A, St. Louis-MO),
Denver/Boulder-CO, Miami-FL, London-England, Iraq, and Palestine. There
are “ Three Waves ” of such Phoenix Spike site activations planned by the
UIR. Localized '' Unnatural Disasters ,'' as well as '' official war strikes '' and
''terrorist activity '' will be tactics used to ''cover'' the covert activities of
Trumpet Pulse Phoenix Spike site activations. The Eieyani did not become
aware of the UlRs’ Phoenix Spike Site activation initiative until the morning
of September 11 , although they were aware that sonic pulses had been issued
on August 12. During our Labor Day workshop on September 3, the Eieyani
had warned us that the UIR had taken aggressive steps to fully re-activate the
Montauk-Phi-Ex facility and that the UIR OWO agenda was now
advancing. The Eieyani discovered the UIR Trumpet Pulse initiative just
after the first plane was in the air.  
    The Eieyani have stated that at this time, they made contact with nine
other GA contactees  in three countries outside of the U.S.A. , motivating
these individuals (unknown to me) to place nine separate telephone calls  to
various governmental agencies in the U.S.A., warning of the pending
                          __________________________
                             6.     Our Labor Day group was “hit” with this disruptive sonic pulse when it passed through
                                         the Gru-AL as we began our RRT work at Sarasota Beach the evening of September 3. I
                                         didn’t discover until later Eieyani dispensations revealed exactly what had occurred that    
                                         evening.
                            409
                                                                                                                                                               

                       
                        HAARPs, Trumpets, Horsemen, and Heaven
attack. Each call was dismissed as a ''hoax'' at the receiving end, and the
Eieyani could do nothing directly to prevent fulfillment of the UIRs’ bin
Laden/Trumpet Pulse initiative.  
                           
                       UIR OWO MASTER PLAN AGENDA   
      Although the hidden reality of activating Phoenix Spike sites via
Trumpet Pulses was a primary Illuminati objective behind the September 11,
2001, “terrorist attack,” there were also other UIR objectives served
through staging of this event. The intended plan for advancement of the
UIR OWO agenda has always included creation of specific effects within
the world political arena that are intended to serve the Fallen Angelic
invasion schedule. Polarization of the global political arena is one effect
that will serve to expedite war among Human nations, and will set up the
“good-guy-nations vs. bad-guy-nations” population division that the Fallen
Angelics need in order to implement their physical contact phase of
invasion.  
      T ake notice that in the “New W ar On T errorism,” U.S. political leaders
are priming the international public for total polarity of national affiliation.
Since the 9/11 disaster, it has been repeatedly propagandized that nations
who will not support the U.S. initiated “Anti-terrorism Coalition” are thus
“supporting terrorism”-''If you are not with us, you are against us.” This
stance has, in one utterly smooth and superficially “justifiable” motion,
forced all world nations to either “side with the Anti-terrorism Coalition” or
become a target of suspicion, potentially suffering economic sanctions or
military reprisals from nations of the Anti-terrorism Coalition.  
      Though the need for international unity in standing up against terrorism
is needed, we all wish that such unity for a common cause would be entered
honestly, without the condition of utter duress that world governments are
presently facing in regard to their stance on the Anti-terrorism Coalition. I
have observed in utter amazement how swiftly the planet has been utterly
polarized around this issue. On the surface, it is understandable that the
event of terrorism would be officially designated as an internationally
unacceptable action that calls for “retribution.”  
       But when one is aware of the “Hidden Element” of the Fallen Angelic/
Intruder ET/Illuminati “Silent Invasion,” it becomes apparent that the mass
surface events have much more meaning than “meets the eye.” Since 1998,
the Eieyani have gently warned those who cared to listen that the UIR was
involved in instigating global war among Human nations in order to reduce
Human populations and to covertly position world government organizations
for later intended physical ET invasion.  
       As Humanity progressively gets “caught up” in the war drama, which
at this point we have little choice about, the UIR “Silent Invasion” moves
nicely along, undetected, right under our noses. The New Age and UFO
Movement people, who have been misled into believing that they are
“immune” to being affected by national and international war issues because
their “ET-Angels” will save them, are in for a rude awakening. Eventually
they will discover that “bombs and bullets” can disrupt their “positive
thought-constructed lives” just as much as anyone else’s. The big awakening
will come when they realize that it is some of their “beloved ET-Angels” that  
410            
                          
                                                                    

                                                                                  
                                                                                 UIR OWO Master Plan Agenda
  have planned and orchestrated these conditions of Human war all along, in
order to advance a OWO invasion/dominion agenda. A progression to mass
war among Human nations will first of all allow Illuminati races to reduce
the numbers of 12-Strand DNA-activating Human populations, and
secondly, it will prepare the global political arena for the Fallen Angelics’
intended staged “First Contact” event. The “Human Greeting Teams,”
which are presently being set up by Fallen Angelics via their “channel”
contacts in the New Age and UFO Movements, are a key element to the
OWO plan. Through these unsuspecting Human groups, seemingly friendly
“ET-Angels” will be able to get their physical presence fully and covertly “on
planet,” undetected by mass populations and government officials, so that
direct infiltration of world governments and Illuminati factions  can begin.  
    The Fallen Angelics hope to create an atmosphere of Human fear,
suffering and population reduction over a period of a few years, while
advancing private contact with their Human and Illuminati "chosen ones."
The UIR knows that progressive environmental and climatic emergencies
will arise due to escalating electromagnetic imbalances in the planetary grids,
brought on by the Illuminati Frequency Fence. Environmental atrocities,
coupled with the progression of Human war, will methodically reduce
Human populations, while moving the “survivors” into a progressively
greater sense of desperation, yielding intensified “prayers for redemption” and
adherence to the promises of salvation offered by religious dogma. After a
certain point of cultivated global crisis is reached, and general ''Martial
Law” governance affects all nations due to the progression of the war drama,
selected members of the global political and religious Illuminati will prepare
the public for contact with "Friendly ETs" via mass media "Official
Disclosure." Once first contact is made, tentatively scheduled for 2005 after
a series of great Storms emerge from erratic progression of Star Gate opening
in the SAC, the UIR intends to ''save us from ourselves.'' They intended to
present themselves to us as the "great saviors from above," who have “come
in answer to our prayers”7 
     If the OWO plan proceeds, Fallen Angelic groups such as the Galactic
     Federation will openly emerge to politically ''back'' the global government
   ''good guys'' that appear to be those ''fighting for freedom'' against countries
    that appear to represent the ''bad-guy'' end of the “good vs. evil” staged
   polarity drama. W orld religions of the “positive polarity group” will have
    been “nurtured” to a point of ''Unity through T olerance" by the time First
    Contact is staged. Our newly introduced ''friendly space kin,'' endorsed by
       Illuminati-controlled governments of the UIR and W orld Management
  T eam, will then further global religious unity through demonstration of
    contrived religious dogma that becomes the basis for a new global political
               order . Human-looking ET representatives of the ''United Federation of
     Planets'' intend to show false historical and genetic evidence that the
      Annunaki groups are the creators of Human life and that they have returned
     to lead us to an ''enlightened'' future. ''Miracle Cures'' will be offered for                           ________________________                                       7.     First Contact could come at any time, if the UIR thinks its scheduled OWO Master Plan
                                          “Dimensional Blend Experiment” will fail and they opt for direct, rapid, physical inv asion
                                          under the “friendly space brother" ploy.    
                             411                                                                                          
                                                                                                                               

                      
                        HAARPs, Trumpets, Horsemen, and Heaven
healing and environmental cleanup, and new global governmental
structures will be imposed  as a condition of the “good-guy group” being
accepted as the “official world government,” so Earth may be entered as a
''Sovereign Global State in the United Federation of Planets ." The “United
Nations” will be “upgraded” to the UPF—the '' United Planetary
Federation ,” and we will find ourselves as “lowly subjects” upon a planet
ruled by the Fallen Angelic Annu-Elohim and Annunaki of Nibiru, Tiamat,
Sirius A, Arcturus and Trapezium Orion. The Annunaki will introduce the
Drakonian, Reptilian and Necromiton-Andromie races as our joint “allies,”
and global territories will be divided up among various ET factions , with
Human and Illuminati puppet-governments appointed by the UIR
orchestrating international political, economic, religious and social affairs
from behind the scenes. ''ETs" will then walk openly among us and
''undesirable '' populations  that refuse to “buy into” the propaganda
promoted through “official” religious, political and governmental channels,
will be quietly disposed of. The UIR agenda requires that Human populations
be seduced into the “necessary state of willing compliance” by 2006-2007.
      Uncontested visible physical “ET” presence on Earth is intended to be
achieved through amalgamation of the “contactees” of the New Age and
UFO Movements with the powers of Illuminati-controlled traditional official
government and religious organizations, and quiet “eradication” of opposing
forces. Once this is achieved, the UIR intends to complete physical building
of the Photo-sonic Transmission plants that they need to break through the
Cloaking Shields on the Inner Earth portals.
      By 2008,  planetary pole shift will begin, and our “ET brethren” will
abandon us to “unnatural disaster” and calamity  while they stage their
intended physical invasion of Inner Earth  and the Halls of Amenti Star
Gates. This  is the UIR OWO Master Plan , which can still be prevented
through activation of the Emerald Covenant Founders’ Four Faces of Man
LPIN System  (see page 526) and the Trion-Meajhé Field  (see page 517).
      When the Eieyani roughly explained this UIR OWO Master Plan to me
throughout 1999,  I couldn’t imagine how such utter dominion of world
governments could take place so quickly within the ''real world .'' How
could the many nations of Earth be rapidly banded into “Us vs. Them” global
polarity? How could the masses be moved into receptivity to a “Unified
Religion” that would leave us all gullibly vulnerable to the “ETs-as-saviors”
drama? How could religious freedom in the U.S. be hijacked into a
governmentally endorsed set of alternative doctrines, with which non~
compliance would become a “criminal act”? My personal difficulty in
believing that an ET “Silent Invasion” could be set in mass motion rapidly
enough  for the UIR’ s 2008 deadline rapidly turned to a sense of horrified
awe as I observed the post-9/11/200l political machine grind into motion.  
      Suddenly we are right smack in the middle of the polarization  of
international consciousness,  with “good guys” uniting to “fight terrorists"
and “bad guys” assisting terrorists. Suddenly everyone is “getting in touch
with traditional gods,” driven by the mourning and fear generated by the
WTC/Pentagon terrorist attack event. And suddenly, the message of
“brotherly interfaith tolerance” is being promoted within the political arena,
bringing  the once-adversarial world “superpower religions” of Christianity 
412 
                        
                    

                                                                        
                                                                                          UIR OWO Master Plan Agenda
and Islam together under the common banner of anti-terrorism, while
Islamic extremists use their religion as an excuse for destruction of others
different than themselves. Although there are definite advantages to such
unification of nations that will foster a much-needed advancement of Human
rights advocacy, this interfaith unity promoted under the banner of political
government also threatens to more fully reunite the powers of ''church and
state. '' If things proceed as the UIR plans, the “state,” or political
government, even in the U.S.A. where religious freedom is supposed to be
constitutionally protected, will again be empowered as the arbitrator of
personal spiritual belief systems. At this point, all the U.S. government needs
to do is put out propaganda that any spiritual organization they covertly
disapprove of is “suspected of terrorist activity,” and the public will be blindly
supportive of whatever action the government deems necessary to “dispose
of the threat.” The massacre of the “Branch Davidians" at Waco, TX, is an
example of how such scenarios of governmental religious repression could
easily be orchestrated without causing American public uproar. In the
U.S.A., we have come to take certain freedoms of speech, religious belief,
travel mobility and “unencumbered passage” as constitutionally protected
rights. As I observed the U.S. political reaction to the 9/11 disaster, I realized
just how fragile our American illusion of freedom really is.  
      Suddenly , people are frightened of a perceived ''outside threat'' so they
willingly accept ''military presence'' at airports and support increased
governmental covert surveillance of civilian populations as ''needed safety
precautions.'' All that is required to ''push the envelope'' just a few steps
further is another atrocity like the 9/11 disaster, and the American public
will accept, with little if any opposition, the need for government imposition
of general ''Martial Law.'' If the present military campaign of bombing in
Afghanistan extends into Iraq and other areas, as the UIR plans, then the
US. President will be ''rightfully empowered'' and apparently “forced” into
activation of the U.S.  ''War Powers Act '' and FEMA . Once the “War
Powers Act” becomes reality in the U.S.A., the ''Rights of the People,'' as
once protected by the American Constitution, will be effectively suspended.
By the time this book reaches publication, the ''War Powers Act'' may have
already become an American reality. Meanwhile, as the international
community becomes progressively more distracted by the growing D-3 “war
drama,” the UIR Fallen Angelics and their Illuminati races covertly advance
their physical “ET” contact/invasion drama.  
       Unfortunately, there is a  pending crisis of even greater concern  brewing
beneath the external and covert Illuminati dramas-Earth is presently fully
ensconced within the very tangible realities of physics  characteristic to a
Stellar Activations Cycle (SAC) . Earth’s Star Gates are now fully opening for
the first time in 210,216 years,  and Earth’ s Planetary Shields scalar-
template is in a terrible disarray of electromagnetic imbalance due to past and
present abuse by Fallen Angelic and amnesiac Human nations. Planets
physically  pole shift  if they cannot hold the progressive infusion of frequencies
that naturally emerge through the Planetary Templar during SACs. Masters
Planetary Templar Mechanics  are the only tools through which such core
challenges of planetary physics can be overcome. We need to start paying 
413  
                                                                                                                          
                                                                                                                    
                                                                                                                                   

                        
                       
                        HAARPs, Trumpets, Horsemen, and Heaven
          
                        active attention to this greater reality if we hope to pass through the 2000
                          2017 SAC with any degree of safety . 
                               DECODING “REVELATIONS”—THE OWO  SCHEDULE
     Since the Jehovian Annunaki Fallen Angelics’ edited, and partially re-
wrote, the original Essene Emerald Covenant CDT-Plate translations that
were supposed to be the foundations for the Holy Bible, we have been
progressively ''set up'' to assist the Jehovian Invasion Team to fulfill their
OWO vision. The Jehovian OWO agenda of the '' Dove '' APIN  system
group , as of the September 12, 2000,  has become formally incorporated into
the general OWO invasion plan of the UIR. 
    The reality of planetary physics  we presently face can best be illustrated
by ''decoding '' portions of the Biblical ''Revelations '' story  that directly
apply to our contemporary circumstance. We will receive greater benefit
from the “Revelations” story if we can begin to understand the truths and
contrived agendas hidden within this Jehovian-written intended dominion
schedule . The most important aspects of the Book of Revelations have to do
with the stories of the '' Seven Seals ,'' the ''Four Horsemen of the
Apocalypse ,'' the ''Seven Angels with their Seven Trumpets ,'' the ''24
Elders '' before the ''Golden Altar'' and Jehovian ''Throne,'' and the '' Four
Beasts before the Altar/Throne .'' 
   Interestingly in recent modern translations of Biblical Revelations, the
mentioning of the '' Four Beast '' before the Throne of Jehovah has been
lifted in status from its earlier “beastly” translation, to become the ''Four
Living Creature'' before the Throne—yet another subtle little sleight-of-
word translation to further distance us from awareness of the true hidden
translation of this text. We have discussed the ancient microchip-like
technologies  of the APIN systems  left in Earth’ s Planetary Shields from the
Atlantian period (see page 367). The APIN grid networks were designed by
their various creators in the shapes of animals or birds , when viewed from
space with photo-radionic scanning equipment. In the story of Jehovian
Revelation,''St. John the Divine'' reported witnessing the ''Four Beasts''
before the Throne; the first was like a ' 'Lion ,'' the second like an '' Ox,'' the
third had a '' Face like a Man '' and the forth was as a ''Flying Eagle.'' It is no
coincidenc e that the four most powerful PIN systems  on Earth are those
created by the Emerald Covenant Founders races—the Great White Lion
Elohie APIN, the Blue Oxen  Maharaji APIN, the Four Faces of Man
Eieyani LPIN and the Golden Eagle  Seraphei APIN. The Jehovian ''vision''
given to ''St. John'' was a cleverly disguised, almost literal symbolic depiction
of the Jehovian Annunaki and Annu-Elohim intention of securing the
Founders’ APIN systems under dominion of the ''Throne of Jehovah .''
This interpretation of the ''Four Beasts'' in Revelation is not “guess work” or
presumption, it is the truth of Revelations decoded,  as contained within the
Founders CDT-Plate records.  
     In truth, the Jehovian Revelations story is a step-by-step illustration of
the Jehovian Anunnaki’s intended invasion schedule . The reason that it is
pertinent to briefly explore the '' Revelations Schedule '' has to do directly
with the '' Four Horsemen of the Apocalypse '' element, the Horsemen that
         are released upon the Earth to begin delivery of the “wrath of God  
                           414  
                                   

                                                              
                                                                     Decoding ''Revelations'' —the OWO Schedule
(Jehovah),” with ''opening'' of the first four of '' Seven Seals ." We need to
understand the truths that Revelations has been hiding from us , because
''Seal '' numbers 1 and 2 ''opened '' in May 2001 , releasing the '' White
Horseman '' and the '' Red Horsemen .'' ''Seal'' number 3 ''opened '' in July
2001, setting the  “Black Horsemen” free, and “ Seal” number 4 will “open”
in January 2002 , releasing the ominous '' Pale  Horse ,'' For anyone
unfamiliar with the Biblical Revelations story, the “Horse stories” go like
this: “...and I watched the Lamb ( see page 367, ff .) open the First of Seven
Seals ...and behold a White Horse , its rider held a bow8 and he was given a
Crown9 and he rode out ...to conquer.” And the lamb opened the Second
Seal . . . . .and behold a Red Horse , ...its rider given the power to take peace from
the Earth and to make men slay each other ; and he was given a mighty
sword. 10And the Lamb opened the Third Seal . . .and behold a Black Horse,  its
rider was holding a pair of scales in his hand.. ¹¹ When the Lamb opened the
Fourth Seal, ...and behold a Pale Horse ...its rider’s name was Death, and
Hell12 followed close behind . They were given the power over the 4th part of
the Earth13 to kill by sword, famine and plague and by the wild beasts of the
Earth....     
      By the time we get to  cthe '' Sixth Seal '' opening, which in technical
terms soon explained will occur between August-September of 2002,  the
''Horsemen'' have done their damage, and we find the following revelation:
''When the  Sixth Seal opened there was a  great Earthquake, the sun turned
black,...the moon turned red .14 
    As if Seal 6 didn’t promise enough damage, there its yet the '' Seventh
Seal,'' which sets loose the “ Seven Angels with Seven Trumpets ...'' By the
time the ''Third Angel sounds the Third Trumpet,'' '' a great star, blazing like a
torch, fell from the sky on the third part 15 of the rivers. . .and the name of the Star
was Wormwood .'' W e have already explored the sub-space sonic-Mion-wave-
field projection technology of the ''Trumpets''; it just so happens that
''Wormwood'' refers to the Nibiruian Annunaki Battlestar ''Wormwood ''
which the Nibiruians have used since 25,500 BC  to keep the Nibiruian
Diodic Crystal Grid (NDC-Grid)  sonic grid control machine operational in
Earth’s Planetary Shields. This is the very same ''Wormwood'' Nibiruian
Battlestar that, since 9560 BC, the Jehovian Annunaki intended to “knock
out of the sky” with their unholy ''Trumpets,'' when they waged their
competing OWO dominion campaign against the competing Nibiruian
Annunaki group during the 2000-2017 SAC.  
      It is time to pay attention, folks ! lt is no coincidence that four months
after release of the Second Seal  and Red ''Horsemen '' (the one “given the
                             ____________________________________
8.    Refers to Sagittarius constellation, Lagoon-''Hourglass Nebula''
9.    Refers to Nebula double halo.
10.  Biblical “swords” refer to speci fic photo-radionic light frequencies.
11.  Refers to the Libra constellation and symbolically to the “weighing of Earth's frequencies”
       through which Earth’s future Time Cycle will be determined
12.  Refers to the 'Pit'' of the Phantom Matrix" Black Hole system.
13.  Refers to the D-4 Astral Plane of Earth’s planetary anatomy.
14.  Both refer directly to a visual anomaly that naturally occurs when Earth passes into the
       Three-Day Particle Conversion Period  of a SAC. See page 223.
15.  Refers to the D-3 reality plane, where we all presently live.   
415                               
  
                                                                                                                                                                
                    

                        
                         HAARPs, Trumpets, Horsemen, and Heav en
power to take peace from the Earth and make men slay each other”) that we
suddenly find our nations immersed within the “New War on Terrorism.”
Already the bombs are ﬂying. Opening of the Fourth Seal (due by summer’s
end 2002) and release of the Pale  Horse  is the point in Revelations when
things begin to get really “ickey”—the rider named “Death” and the “Pit”/
Phantom Matrix/ Wormhole Crew  follow close behind. But until we come to
understand “ What the heck are these horses and horsemen anyway ?” these
revelations will have little rational meaning. It is vitally important to our
collective planetary well-being that we f inally comprehend the real meaning
of the ''Four Horsemen of the Apocalypse, '' the '' Seven Seals '' and the
''Seven Angels with Seven Trumpets .'' Here follows the truth of what we
will all move through during the next seven years of the SAC.  
                            
                   REVELATIONS AND “SAINT JOHN THE DIVINE”                
           In the Jehovian Annunaki falsification of original Essene scripture,
there were numerous historical references to the “ Trumpets of God ” and
their powers to render the “Wrath of God” on behalf of the “righteous.”16 As
previously discussed, the Biblical “ Trumpet ” was an Atlantian ''code word ''
for the sub-space Sonic-Mion-Field projection technology  that has been
used by the Jehovian Annunaki as a remote-range weapons system  since
pre-Atlantian days. Just as the ''Trumpet'' and ''Four Beasts'' references held a
hidden meaning  that was not at all ''spiritual'' or “esoteric” in nature, but
rather a specific reference to a tangible, Annunaki-created scientific
technology , so too do the other elements of the Revelations story have a
hidden technological meaning . The references pertaining to the “Trumpets,”
their “Angels,” “the Four Horsemen,” the “Altar of Gold before the Throne”
and the “24 Elders before the Throne” now found in the Biblical Revelations
story were  not part of the genuine Founders’  Emerald Covenant CDT -
Plate translations rendered by the Essenes.  
      These colorful pictures of symbolic code  were part of a Holographic
Insert Program  initiated by the Fallen Angelic Jehovian Annu-Elohim and
Bipedal Dolphin People Annunaki of Sirius A and Arcturus  in the
Phantom Matrix . The stories were based partially upon fact , in relation to
the technological reality  of the natural Planetary Seals that do release or
“open” via Star Gate-12 (the “Lamb”) during SACs. To “invent” their own
version of “Revelations,” through which the Jehovian dominion agenda was
intended to be fulfilled, the Jehovian Annunaki gave, as a series of
Holographically generated NET “visions,” a twisted version of the original
Atlantian Emerald Covenant Revelation story.  
     The individual responsible for what has emerged as the “Biblical
 Revelation” interpretation became known as “ St. John the Divine ,” who was
 in truth a female Emerald Covenant “Flame Keeper ,” born of Blue Flame
 Melchizedek mother and Jehovian Annu-Melchizedek father . The Jehovian
 Annunaki used this individual, through astral Tagging , via their portion of  
 the NET , to bring “prophecy” that would prepare those who followed to
                         ________________________
                 16. The  true  God Spirit is not wrathful, nor vengeful, but immature Fallen Angelic Annunaki
                                         and Anu-Elohim false godlets are.
                               416
                  
            
     

                                  
                                                        
                                                    The “Seven Churches,” “Seven Angels” and “the Dove"
fulfill the Jehovian OWO agenda . Emerald Covenant teachings of the D-8
Gold light fields of Orion Mintaka , Universal Star Gate-8, were distorted
into the “ Gold Altar before the Throne ” symbolism. The '' 24 Elders before
the Throne '' represented the Fallen Angelic Jehovian Annu-Elohim
forefathers of the Annunaki Nibiruian Council of 24 , which was controlled
by Jehovian ''pure-strain'' Bipedal Dolphin People Annunaki '' Overlords .''
The ''visions'' given to ''St. John'' were a symbolically encoded
interpretation of the intended Jehovian OWO agenda  scheduled to unfold
between 2001-2008 AD, during the anticipated SAC. The Jehovian “Book of
Revelation” was based upon Jehovian Annu-Elohim knowledge of Atlantian
Emerald Covenant Templar teachings pertaining to Planetary Seals  and the
behavior of Planetary Seals during the anticipated 2000-2017 SAC. The
Jehovian Revelation story audaciously depicted what the Jehovians intended
to do to Earth’s Planetary Shields, during the Final Conflict drama that
was scheduled to unfold between 2000-2017.  
   
                           THE “SEVEN CHURCHES, ” “SEVEN ANGELS” AND “THE DOVE”             
       Th e ''Angel'' word in the Jehovian Revelations story does not refer to
       singular ''Divine People.'' The symbol code of ''angel '' was used to represent
    an advanced technology  called the Jehovian Hyperdimensional Cone,
      which utilizes external Merkaba Mechanics —-an external energy
  technology  that was seeded into Earth's Planetary Shields , much as were
   t h e  a f o r e m e n t i o n e d  P h o e n i x  S p i k e s  a n d  A P I N  s y s t e m s .  T h e
    Hyperdimensional Cones (HD-Cs)  were placed as standing-conical-scalar
   wave clusters  imbued into Selenite and quartz rods,  which were originally
  implanted  into the Earth’ s crust, mantle and Planetary Shields  during
  earlier Atlantian periods, in an unsuccessful attempt to fulfill the Jehovian
   OWO dominion agenda during the 22,326 BC SAC.  
      Like the Phoenix and Falcon wormhole APIN systems, the HD-C
network  represented an interface between Earth and the Phantom Matrix.
Unlike the Phoenix and Falcon “holes in the Wall in Time,” the HD-C
network was more like “ Cracks in the Wall in Time .” The HD-C Network
of the Dove did not become fully operational until the 10,500 BC creation of
the Phoenix wormhole, which the Jehovians used to increase the function of
their Dove APIN HD-C network. The Anu-Seraphim Nibiruian Annunakis
created the Phoenix wormhole during the 10,500 BC Luciferian Conquest .
This was a time in Nibiruian history in which the Anu-Seraphim Annunaki
races of the “Councils of 9 and 12” rebelled against the Annu-Elohim Over-
lords" of the '' Council of 24 Elders .'' When the Nibiruians created the
Phoenix, the Jehovian Annunaki and their Annu-Elohim ''Council of 24
Elders'' began implanting Earth’s Planetary Shields with further elements
of the original 22,326 BC HD-C technology .                                        
      The Phoenix W ormhole created a weakness within the surrounding
                  frequency field of the ''W all in Time.'' The Jehovians were able to use these
                 weaknesses to create a network of thin, interwoven frequency bands,
  anchored through the HD-C implants, that ran from the Phoenix Wormhole                          
access point like “cracks,” into control areas of Earth’s Planetary Shields. The  
areas of Earth in which the HD-C implants were placed  were linked to the    
portion of D-7 Universal Star Gate-7 Arcturus  that was under Jehovian  
      417       
                                                                                                                                                                                  

                       
                    
                        HAARPs, Trumpets, Horsemen, and Heaven
Annunaki and Annu-Elohim dominion. Seven massive Crystal Pylon
Selenite Rods  were placed within the Arcturian SG-7 control grid , before
the SG-8 galactic core “Golden Altar and Throne.” These were described as
the “ Seven Candlesticks which are the Seven Churches ” in Biblical
Revelation. The '' Seven Stars which are the Seven Angels of the Seven
Churches " referred to the Seven Prime HD-C implants  in Earth’ s Planetary
Shields that anchored the Seven Arcturian Pylon Selenite Rods
“Candlesticks/Churches” into Earth’s grids. This is not ''Divine
Construction ''—it is the anti-Christiac work of advanced  subtle-wave
broadcasting technology  employed for intended planetary dominion and
destruction.  
      The HD-C network was intended to serve as a series of ''Siphoning
Channels. '' Portions of Earth’s Shields and selected populations could be
pulled through the Phoenix Wormhole into the Phantom Arcturus Matrix
as the Nibiruians used the Phoenix Wormhole to draw the rest of Earth’s
Planetary Shields into merger with Phantom Nibiru and Tiamat. The
network of Jehovian HD-C implants in Earth’s Planetary Shields is known as
the Dove APIN system , denoting the shape of its primary grid when viewed
from space with photo-radionic scanning equipment. The “Dove,” like the
Falcon, the Phoenix, the Serpent and the Dragon APIN systems, represent
Aerial maps  of the Fallen Angelic/Intruder ET control networks  placed in
Earth’s Templar. The “Dove” was recently revealed in the contemporary
works of Enoch,  while he was supporting the Jehovian OWO agenda before
his 1983  Emerald Covenant Redemption Contract. Specific representation
of these APIN maps  and their contemporary language literal translations
and geographical co-ordinates are contained within the Emerald Covenant
CDT-Plates “Book of Maps and Keys.” The HD-C implants of the Dove
APIN system are frequency generation points  implanted into Earth’ s body
that can create external, artificial, reverse-spin  (Phantom Matrix spin)
Merkaba Vehicles  of various sizes and designs. Once generated, these
spiraling electro-magnetic Reverse Merkaba Fields  can hold a person or
object, or an entire city or continent , depending upon the size of the field,
through hyperdimensional transport into phantom matrix . When used in
specific ways , the HD-Cs form '' Plasma Ships, '' beautiful elongated orbs of
glowing ''living '' light , that can, if programmed to do so, '' step down in
frequency” to form solid-objects , usually Silver metallic “space ships,”
complete with a Jehovian Phantom Crew.  
      When used in other ways, the HD-Cs of the ''Dove'' receive, amplify
and transmit invisible sub-sonic wave fields  from the Pylon Selenite Rod
transmission bases in the Planetary Shields of Phantom Arcturus.  The
Seven Pylon Selenite Rods stationed on Phantom Arcturus are the ''relay
station'' or '' midway station '' through which the frequencies of similar Pylon
Selenite Rod installations on Sirius A  and in Trapezium Orion  and the
Hourglass Nebula  in Sagittarius interface with the living Time Matrix
system. The HD-C points in Earth’s Planetary Shields can be used as Sub-
sonic ULF Scalar Pulse transmitters  that are capable of sending Targeted
Sub-sonic Scalar Pulses  through the Dove Matrix  network grid lines of
Earth, to very precise targets . Like the Falcon and the Phoenix, the Dove
            Matrix is a powerful weapons system , especially when combined with the
                    418 
                      

                              
                                                 
                                                The Seven Seals and the Four Horsemen of the Apocalypse
advanced “Trumpet” technology, as the ancient peoples of Jericho and
Babylon  unfortunately discovered too late, when the “ walls came tumbling
down .” The HD-Cs of the Dove are also capable of interfacing with
Jehovian-programmed Nibiruian Crystal Temple Network sites  on Earth
for interplanetary and inter-stellar sub-space communication  and access to
the NET. The HD-Cs of Earth are controlled by the Jehovian Annu-Elohim
from Arcturus in Phantom Matrix  and from a site on Earth called “ Cue-
Site-8 ” in the Takla Makon-Tarim Basin, Tibet . Presently Cue Site-8 serves
as the “ control matrix broadcast headquarters ” for the YHWH-Metatronic -
Enochian-Jehovian  Annu-Elohim, the Jehovian Annunaki branches of the
Galactic Federation and Ashtar Command , parts of the '' Archangel ''
Michael-Nephilim Matrix  and factions of the “ Great White Brotherhood-
Ruby Order ” Nephilim and related Vairagi  collective that defected from the
Emerald Covenant. The HD-Cs of the Dove Matrix link Earth to the Seven
Selenite Pylon Rods of Phantom Arcturus at Seven Primary Points  in
Earth’s Planetary Shields. At these Seven points in Earth’s Planetary Shields
the seven largest HD-Cs  are placed—the “ Seven Angels of the Seven
Churches ” in the Jehovian “Revelations” story. The “Seven Angels of
Jehovian  Destruction”17 are anchored  into Earth’ s Planetary Shields through
the ''Seven Seals of Jehovah. '' 
                                              
                                                               THE SEVEN SEALS
                                   AND THE FOUR HORSEMEN OF THE APOCALYPSE         
     The seven “anchoring rods,” or '' Seven Jehovian Seals ,'' of the Seven
Prime HD-Cs of the Dove APIN system were placed in Earth’s Planetary
Shields specifically on one vertical column, horizontally across from certain
natural configurations in Earth’s Templar called Star Crystal Seals . The
Seven Unnatural Jehovian Seals  are all positioned along Axiatonal Line-7,
the vertical coordinate upon which both the Phoenix and Falcon Matrix
wormholes  are located, and connect to a secondary set of Seven artificial
Jehovian Seals that are placed within the natural “Seed Seals” of Earth’s
Seven Primary V ortices. (See Star Gates and Seals  diagram Appendix V).
During SACs, the natural 12-Star Crystal Seals  in Earth’ s T emplar
progressively and sequentially activate with Earth’s Star Gates, allowing the
Axiatonal Lines in Earth’s grids to braid so Earth enters natural Merkaba
under D-12 Planetary Maharic Seal. The ''trans-dimensional '' Star Crystal
Seals exist between each of the 12-dimensional Star Gates  in Earth’ s
Templar; when Star Crystal Seals open, they allow the specific dimensions of
frequency from the Star Gate above and below to blend.18 The Seven
Jehovian Seals that hold the Seven “Angels”/Prime HD-C implants of the
Dove APIN system, which link via sub-space sonic frequency bands  to the
Seven Pylon Selenite Rods of Arcturus,19 were placed in correspondence to
                 
                       ________________________________________  
                              17.   Seven Prime HD-C links to the Seven Arcturian Pylon Selenite Rods
                        18.  The Star Crystal and Seed Crystal Seals within the Human  DNA Template  and personal
                           '' Inner Templar " operate the same way to create DNA Strand Braiding  for Atomic
                                         Transmutation and Star Gate passage( ascension).
                                 19.    Seven "Churches/Candlesticks/Spirits of Jehovah God”
                                419
                                                                                                                                 

                
                        HAARPs, Trumpets, Horsemen, and Heaven
Seven of Earth’s Natural Star Crystal Seals . During a SAC, the '' Seven
Unholy Jehovian Angels '' were intended to sequentially activate in response
to natural activation of seven out of the 12 natural Earth Seals; the purpose
of these unnatural Jehovian HD-C '' Seven Seals '' is to progressively r ip
greater “wormholes in the Cap on the Wall in Time .'' 
   When a Jehovian Seal activates , a new Wormhole connection to the
Phoenix Wormhole  is “frequency-punched” into Earth’ s matter base, in the
geographical location of the Jehovian Seal. The Atlantian Dove APIN , like
the Phoenix, Falcon, and several other similar networks installed during the
Atlantian period in preparation for the 2000-2017 SAC, was designed to
rapidly create a massive series of minute Black Holes in the fabric of
Earth’s body,  while creating a frequency barrier around Earth’s
magnetosphere . The ''black hole networ'' is designed to progressively
expand , each ''hole'' opening into the others as the frequency barrier in
Earth’s magnetosphere “holds the planetary mass together” while Earth is
literally '' sucked '' into the Black Hole Sub-time Distortion Cycle  of the
Phantom Matrix. Because several competing Fallen Angelic collectives from
various locations within the Phantom Matrix would attempt to use similar
APIN technological atrocities to accomplish the same feat during the 2000-
2017 SAC, Earth’s Planetary Shields would be literally pulled apart . The
planetary matter base would fragment , its various pieces as held together
within their magnetosphere suspension fields,  would be drawn into orbit
around the Phantom Matrix planets  that exerted the greatest ''magnetic
pull.'' The location in the living Time Matrix where Earth is presently
positioned, would be left with a massive “rip in time,” a Black Hole that
would progressively expand via particle accretion, to eventually “swallow” 11
dimensions of our 15-Dimensional Time Matrix.  
             The first four Jehovian HD-C implants of the Dove APIN are known as
''The Four Horsemen Of The Apocalypse .'' The ''horses'' represent four of
the 12 natural stellar currents , the carrier wave frequencies  corresponding
to the first four  of Earth’ s natural 12-Star Crystal Seals , that will run into
Earth’s Templar to begin activation of the corresponding Star Gates and
Axiatonal Lines. The Seven Jehovian HD-C Seals are placed in conjunction
to Earth’s Star Crystal Seals numbers 1, 2, 3, 8, 9, 10 and 11 . 
      Jehovian HD-C Seal-1 , the '' White Horseman ,'' placed on A7 vertical,
latitude 47.08° N, northeast of  Quebec, Canada, corresponds to Earth Seal- 1
France, which carries the D-11/l2 “Silver-White Maharic light spectra” or
the ''White Horse '' carrier wave.  
      Jehovian HD-C Seal-2,  the '' Red Horseman, '' placed on A7 vertical,
latitude l8.l° S, near the border conjunction of Chile/Peru/Bolivia,
corresponds to Earth Seal-2  near St. Helena Islands, which carries the D-l2/
l ''Red light spectra'' or the '' Red Horse '' carrier wave.  
      Jehovian HD-C Seal-3 , the '' Black Horseman ,'' placed on A7 vertical,
latitude 4l.78° N around Cape Cod, corresponds to Earth Seal-3,  south of
Sofia, Bulgaria, which carries the D-11/10 “Density-3 blue -black  and silver-
black  black light spectra ,'' or the '' Black Horse '' carrier wave.  
            Jehovian HD-C Seal-4,  the '' Pale  Horseman ,'' placed on A7 vertical,
                   latitude 24.92° N, east of Nassau, Bahamas, corresponds to Earth Seal-8 SW
               Las Palmas, Canary Islands, which carries the D-6/7 '' Pale'' Density-2 Semi-  
                          420    

                                                             
                                                 The Seven Seals and the Four Horsemen of the Apocalypse
Etheric and Density-3 Etheric  indigo/violet light spectrum, or the '' Pale
Horse .'' As Revelations 6:7 warns, when the 4th Jehovian Seal  releases, the
Rider named “Death” upon a Pale Horse takes peace from the Earth, with
“Hell” following close behind . “Hell, Hades, the Pit” represent the Pit of the
Phantom Matrix  expanding through Earth’ s Planetary Shields via the
Falcon-Phoenix wormholes  and the various Fallen Angelic APIN systems.
(See: Planetary Seals Locations and Opening Schedule , Appendix V).  
      In the Jehovian Revelation story , the Jehovian Annu-Elohim drew
their sinister inspiration from the true Revelation books  of the Emerald
Covenant CDT-Plate teachings on the Planetary Templar Mechanics of
SACs, which detail the maps and natural functions of the organic 12-Star
Crystal Seals in Earth's Templar during SACs. In Jehovian Revelation, the
“Four Horses” have '' Riders ''—the Four Horsemen , each supposedly '' given
the power by God '' (AKA Jehovian Annu-Elohim and Annunaki) to do
certain very unpleasant things  to the peoples of Earth. '' God '' did not give
these ''Horsemen '' such power or privilege ; the Jehovian  Annu-Elohim
gave themselves this unholy permission  while appointing themselves “in
the minds of man” as “God.”  
      The '' Four Horsemen '' are the “ frequencies of the first four Jehovian
Seals that would ride upon and direct the frequencies of Earth’s natural
carrier waves, the ''horses .'' The Jehovian frequencies would automatically
emerge  with the release of each corresponding natural Seal, due to  the
Jehovian HD-C implants , ''Angels,'' placed relative to the natural Seals. The
Jehovians knew that the ''Horsemen '' would bring death and destruction,
just as the Jehovian Annunaki and Annu-Elohim intended them to do so .
The frequencies transmitted by the first four Pylon Selenite Rods on
Phantom Arcturus were intended to emerge through the HD-Cs
corresponding to the first four Jehovian Seals.  
       As the first four Jehovian Seals released, unleashing the “Four Horsemen
of the Apocalypse,” Earth’s Planetary Shields would begin ripping apart  as
the artificial external Merkaba Fields generated by the HD-Cs held select
portions of Earth’s matter base and populations in trans-dimensional
suspension . The part of Earth’s Template and populations held by the
Jehovian Dove APIN  are intended to go into merger with Density-3
Phantom Arcturus  via the Phoenix Wormhole  and HD-C network . The
Jehovian Anu-Elohim and Annunaki false ''ascended masters'' refer to this as
“ascension”; it is a macabre, unholy, ascension . Unless, of course, one desires
temporary, artificially sustained “eternal” life in a '' living-dead '' thought -
form body , trapped in the Phantom Matrix  as a “demon-on-a-leash,”
commissioned to do the bidding of Jehovian Annunaki or one of the other
unsavory Fallen Angelic dictatorships.  
      The Jehovians were not kidding when they prophesied that '' the Dead
Shall Rise ,'' but unfortunately it was not our long-lost loved ones that would
be returning; the Jehovians were referring to the living-dead  tortured souls
from the Phantom Matrix Pit . Souls that have been “ harvested ”20 by the
                         _________________________                        
                           20.     I.e., kidnapped—consciousness ''soul essence" siphoned into the Phantom Matrix at time
                                              of death.
                              421
                                                                                                                                            

                        
                       
                        HAARPs, Trumpets, Horsemen, and Heaven
Jehovian Annu-Elohim, Necromiton-Andromie, Pleiadian-Nibiruian, Zeta-
Rigelian, Odedicron-Reptilian and Omicron-Drakonian “Grim Reaper”
collectives  since the Dove, White Eagle, Phoenix-Serpent, Falcon and
Dragon APIN systems were set in motion in ancient Atlantis.  
      In Biblical Revelation the Jehovians depict their great battle and
intended victory over the “Great Beast.” At the heart of the “battle with the
Beast” story is the Jehovian Annunaki and Annu-Elohim’s long-term
competition with the Omicron-Drakonians and the Marduke-Satain family
Anunnaki of Alnitak, Orion and Alpha Centauri. This story also re ﬂects the
equally vigorous competition between the Jehovian Anunnaki and the
Pleiadian-Nibiruian “Luciferian” Anunnaki (Thoth-Enki-Zeta Lulitan family
line) of Alcyone, Nibiru and Tiamat. These ancient, competing Fallen
Angelic Anunnaki and Drakonian family lines were personified as the
''Satan/Lucifer '' character  in the Jehovian edits of the Bible texts.  
       I truly hate to be the bearer of “bad news,” but the reality of the present,
highly edited and contrived version of the Bible, like that of the Islamic
Koran and other “traditional holy doctrines,” does not represent the
“absolute word of God” that so many people hope it does. ( All religious texts
have been manipulated in this way since the 9558 BC fall of Atlantis). For
over 11,000 years, Human races have been warring and killing each other on
behalf of self-promoted false “Vengeful Gods” from ancient Intruder ET
fiction stories. All the while the truth of the Loving God and humanity’s true
Spiritual Heritage of the Founders Emerald Covenant Freedom Teachings
have been repeatedly suppressed, misused, abused, twisted and defamed on
behalf of our Fallen Angelic galactic terrorists.  
        __________________________________________________________                        
                         How long will we continue to allow these cosmic criminals to use us as pawns
                             in their conquest game for Earth/Inner Earth/Halls of Amenti dominion?                         __________________________________________________________                                         
                           
                                                                 RETURN TO INNOCENCE
                        Salvaging the Sacred. Healing World Religions.
   In the times before the 208,216 BC Fall of Brenaui,21 when the Angelic
Human races of Earth suffered the loss of D-1222 access, all life experience
was a “living prayer” of joyful spiritual and material celebration. In those
times “religion” was not a control dogma used to rob personal power and
dignity from people. In those times, people did not die, they consciously
chose to ascend out of density via the Universal Star Gate system. Science
and Spirituality were fully understood as part of the same Primal Creation
Mechanics  that allowed for the experience of manifest expression and
simultaneous experience of At- one-ment with the true loving God-Source.
Back then, we all knew ourselves, each other, the Earth, and all things  as
blessed expressions of the one God, and we honored all things accordingly. In
                             ___________________________
                             21.   See Forbidden Testaments of Revelation , forthcoming.
                                 22.  Pre-matter Density-4 ''Universal Christos Field.''
                                
                              422
                      
               

                                                                                     
                                                                                                             Return to Innocence
those Ancient of Days, the Days of Innocence , there were 12 Angelic
Human Tribes appointed as the co-Guardians of Earth’s Planetary Templar
Complex. Each Tribe was entrusted with one of twelve Emerald Covenant
CDT-Plates; each CDT-Plate held one-twelfth of the Founders’ Emerald
Covenant teachings on the Nature and Mechanics of Reality, Consciousness
and Manifestation. From the 12 CDT-Plates, protected by the 12 Angelic
Human Tribes, arose the first earthly verbal and written translations of the
Founders’ Sacred Teachings. These text translations were the original Holy
Books  of the 12 genuine components of what is termed ''Religion .'' The
teachings of  all genuine Holy Books complemented each other , honored the
same eternal, loving,  one-God Source that has infinite names and none. All
of the ancient “Holy Books” that still divide our races today originally
emerged from these 12 bodies of once-sacred Emerald Covenant teachings.
In the chaos of Fallen Angelic infiltration of Atlantis, and the progressive
advancement of the Anti-Christiac Phantom Matrix paradigm on Earth that
has occurred since Atlantian times, our sacred religions have been raped
and all but extinguished.  False teachings have been woven between the lines
of truth, and the greatest bodies of truth have been removed entirely.  
       For over 11,000 years, Human and Illuminati-hybrid races, denied the
truth of their history, race identity, memory and immediate relationship to
the God-Force, have been destroying each other and the Earth on behalf of
Intruder ET/Fallen Angelic religious deception . It is now up to each of us to
decide whether or not we love the Living, Loving, Eternal God- presence ,
and the promise of “attainable heaven” that true God-spirit stands for. The
Living God-Presence does not reside in  any book, It resides within each and
every person, place or thing. True “Holy Books” teach us of the eternal truths
of spirit and science, through which we can most rapidly and easily awaken
the God-Presence within. Some people will choose to love more than the
Living-Loving God—the twisted rantings and ravings of vengeful, harsh and
judgmental Intruder ET-false-Gods, because this provides them with false
security and a “socially acceptable” frame of reference. False security and
“fitting in with the local clan” are rather pathetic “rewards” for the payment
of imprisoning one’s soul.  
       The sacred teachings of the 12-Tribe Nations are presently drowning in a
sea of Fallen Angelic lies; it is up to us to save them. Each contemporary
religion holds partial truths and partial lies . It is up to us to find the Living
God-spirit within, through which we can salvage the sacred within each and
every creed, and dispose of the garbage that has taught us to judge and kill
each other, to martyr ourselves, and to unknowingly support Fallen Angelic
agendas. If we desire to find the promised “Heaven on Earth,” we must first
find it within ourselves, which we cannot do while we continue to Crucify
Ourselves  in the name of external W arlords and Wrath-filled False Gods. In
the salvaging of the sacred and discarding of the deception within our world
religious creeds, we can all rediscover God, ourselves and each other, and in
423 
                                                                                                                                    

   
                        HAARPs, Trumpets, Horsemen, and Heaven
that discovery we can begin the journey of our collective Return to
Innocence.  
      God is real.  It is an omnipresent, omnipotent, omniscient Force and
Source of consciousness within which we all reside (even the “bad guys”),
and of which we are all composed. The true God is beyond form
manifestation; and no being can ever be separate from the true God, because
all form manifestation takes place within the Source. Even beings of the
Phantom Matrix are part of the wholeness of God, but they represent the
parts of God’s consciousness that have forgotten their Divine Identity and
have no memory of the wholeness of which they are a part. Phantom Matrix
beings compete for power with others, as they neither acknowledge nor
comprehend the endless supply of living power, energy and love that
eternally circulates between Source and all living things manifest.  
       W e are all directly connected to the real God-Source in every moment;
we can learn the once common-knowledge '' secrets '' of allowing the Living-
Loving God-Presence to progressively embody within us . We do not have
to subjugate ourselves to self-appointed false-God Fallen Angelics who
depend upon taking our energy/power to sustain their own finite supply.
Once we overcome the hurdle of “ external false-God worship ,” and replace
it with “ internal Living-God Worth-ship ,” we will no longer be overly
impressed by, or mentally and emotionally gullible toward, the “space-
brother savior” Fallen Angelic agenda.  
        Ascension is real, but it is not achieved by allowing yourself to be sucked
into the Phantom Matrix due to dogmatic adherence to Fallen Angelic -
distorted ancient texts. The Emerald Covenant Founders Races have always
taught the  original Freedom Teachings  of our Loving Source  and
Inalienable Spirituality , the realities of a loving God that lives within us all.
The Founders also teach the sacred science realities of the Maharata23 for
which the real ''Christ story'' originally stood, and which the real man Christ,
Jesheua Melchizedek, and many others of all religions, once passionately
taught.  
      Long ago, before our planet was “hijacked” by the spiritually and
genetically twisted, mentally disturbed, power-hungry Fallen Angelic souls of
the Phantom Matrix, the Emerald Covenant teachings were Humanity’s
Heritage and common knowledge. The Emerald Covenant teachings were
once the core, heart and soul of every religion. These teachings belong to
the Christian, the Muslim, the Jew, the Hindu, the Buddhist, the Tribal
Shaman....to everyone.  This was true in the days before the “Falcon,” the
“Phoenix,” the “Serpent,” the “Dragon” and the “Dove” laid their territorial
claim on Earth and attempted to possess humanity’s soul. These were the
Ancient of Days , the Days of Innocence,  when Angelic Humans lived in
peace and joyful union  with all other kingdoms in “God’ s House of Many
                              
                             ____________________________
                              23.   Personal Inner Christos, Pre-matter Template and D-12 Divine Blueprint.
                             424
                           
                         

                                                                                             
                                                                                                              Return to Innocence
Mansions” that is our 15-Dimensional Time Matrix System and the many    
others of its kind. These were days before the dereliction of Atlantis. Right
now, in the Bridge Zone Inner Earth Time Continuum that represents
humanity’s victorious future,24 the Days of Innocence are reborn.  
    T oday , we are faced with a truly profound choice. Do we subjugate and
sacrifice our Living Inner Christos25 upon the altar of wrathful Gods from
ancient books, or do we reach within and Godward, to find the Living
Presence of Source that has always been there? These are the most decisive
of times, for in the contemporary drama we will witness the long-foretold
“battle of the Angels.”                                ____________________________________________________________                         
                               The Fallen Angels and the Living Angels will, in these very times, meet, and
                        each individual will face the choice of deciding which type of Angel to be.                          ____________________________________________________________
                        _________________________
                                  24.   Time is simultaneous.
                                  25.   Our D-12 personal Christed Avatar Identity level.
                                425