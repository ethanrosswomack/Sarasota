37 
                                                                                                                                                                                                                                          

      
       The Second Seeding  
removal. The issue of the Templar Seals, and of the dimensional frequency
patterns held within the imprint for the DNA, will have to be addressed,
either in life or after the death transition, for it is the frequency patterns held
there within that will determine the dimensional bands within which a con-
sciousness will next manifest. lt is not a “judgment call” by some authority
figure that determines where you will next travel after your present life time,
but rather an energetic compatibility between the frequency bands held
within the pattern of your consciousness and those within the multidimen-
sional universe.  
     DNA is built upon minute electro-tonal patterns of multidimensional fre-
quency, and the energetic imprint of the DNA goes with you in the death transition .
The content of that electro-tonal pattern will determine how high your con-
sciousness will be able to travel once it is released from the body. The DNA
can be directly affected in life by working to bring higher-frequency, higher
dimensional energies into the operating DNA strands through using the
chakra system effectively, and the work that is done to increase the electro-
tonal patterns during life will directly affect the experiences available to you
following physical death. For some of you immortalization of the body and
passage through interdimensional portals will be possible, but only if you can
learn some of the mechanics by which these events take place. It is for this
reason that we have provided you with this information.  Y ou will go on a voy-
age when your soul awareness brings this life time to a close, with or without your
body, whether or not you are prepared; this is the way of life within the universe.  As
with any journey, preparation can make the trip much more enjoyable. Most
of you would not journey to a distant land without a map in hand, and so we
offer you a rudimentary trail guide for the journey of consciousness with
which you are presently involved. There is an order, purpose, plan and mean-
ing for your personal evolution and your existence, and it is intimately inter-
twined with the evolution of your planet and that of your species. Now we
will offer a bit of information as to where your journey will next lead.                                     
                                      SCIENCE OF ASCENSION    
    The Fifth World, the Seventh Race Cycle and Waves of Ascen sion
                                                 Beyond 2000 AD          
    The Seventh Root Race and their Cloister will emerge upon Tara after
the energetic grids of Earth and Tara reemerge. Earth's merger with Tara will
mark the ful fillment of the Covenant of Palaidor, and represents the coming
Fifth World  of Native American Legend; it is often referred to as  Earth
Ascension.  It would do many of you well to realize that the term ascension repre-
sents much more than some lofty spiritual concept invented by the ﬁnite human
  psyche in order to give purpose to its ﬁnite existence. Many in the earthly scien-
 tific communities believe that life is limited to the physical expression and