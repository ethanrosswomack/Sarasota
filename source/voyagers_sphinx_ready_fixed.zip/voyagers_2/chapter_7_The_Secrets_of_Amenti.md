7                                                                                                                   
                                 

    
                     
                      The Secrets of Amenti
endure portal transit. The Sphere of Amenti would link into the space/time         
of Tara's pre-fall past. With this sphere placed within the Earth as Earth re-    
evolved through dimensional ascension back into the Tara grid following the    
morphogenetic imprint from the sphere, a link between the future Tara and    
its pre-cataclysmic past would be reestablished. Tara's past would be re-        
attached to the Time Matrix grid and Tara's future time cycles. Through the    
Sphere of Amenti a bridge was constructed between Tara's pre-cataclysmic    
past and future tracks/cycles of time.            
       When a planet undergoes such a trauma, having a portion of its grid blown    
apart, not only does it lose the portions of its evolutionary history stored within    
the cellular memory of the parts that blew apart, it also loses a portion of its    
energetic thrust. Without this thrust the planet cannot evolve out of its Har-    
monic Universe and into the next. The planet, and most life forms on it,     
become trapped in the fabric of time. The Sphere of Amenti not only gave    
hope for the continued evolution of human/Turaneusiam lineage, it held the    
hopes of ascension and continued evolution for Earth, Tara and their seventh-   
dimensional counterpart Gaia. lf one was trapped in time, they would all be    
trapped. The only other option available in such cases of planetary morphoge-   
netic field fragmentation is that of a Host Matrix Transplant (as previously dis-    
cussed in relation to people), and this is exceedingly difficult  to achieve on a    
planetary level. Each of the 12 planets in HU-1 that emerged as a result of      
Tara's fragmentation received a similar morphogenetic sphere from the    
Palaidorians to ful fill the same purpose. But here we are only concerned with    
the Sphere of Amenti, as through it Earth became an ascension planet,  able to    
achieve dimensional ascension through re-evolution.                                                                   
                                
                                                The Sphere of Amenti and Soul Ascension
                                                                Rescue Mission from Tara
                                                                550,000,000 —250,000,000 YA
                             Th e Sphere of Amenti was entered into Earth's core within the second-     
                       dimensional frequency bands (often called the “ Cave of Creation ”) about     
                        550 million years ago from a position in HU-2 space/time that existed before
                  the Earth existed within that HU-2 time track. The rescue mission for Tara's          
                     lost souls was begun before those souls became lost, in terms of linear time.    
                             Such things are quite practical within the structure of the Time Matrix.
                        Through the Covenant of Palaidor and the Sphere of Amenti the souls of                                                                                                                        
             Earth could re-evolve back into their original 12-strand DNA body type. 
                        This process can be viewed as the Palaidorians creating new bodies (and mor-
                        phogenetic blueprints) for the now formless consciousness fragments of the                    
              fallen souls. The Sphere of Amenti morphogenetic Field allowed for the Ur-