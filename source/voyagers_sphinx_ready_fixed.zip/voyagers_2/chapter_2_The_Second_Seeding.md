2                        
                                                                                                         
                              The Second Seeding                                                                           
                                                                                                                  
                                                                         
                                                                           SIRIUS B
                                                                                 Sirius B and the Third Eye of Horus                                                                                                                                                  4,000,000 YA         
    In an attempt to revitalize the human evolutionary program, on behalf of
the Ur-Tarranates who had sacrificed their freedom 550 million years ago to
rescue the lost souls of Tara through the Turaneusiam-2 experiment, about
four million years ago the Sirian Council of HU-2, working with the Elohim
and descendants of the Taran Ceres (a HU-2 family known as the Seres) and
several other HU-2 groups created a plan through which human evolution on
Earth could be restarted. Earth's grid still could not sustain a life field with
fourth-dimensional gene coding, so a plan was devised to allow the souls
waiting within the Sphere of Amenti in D-4 to be re-entered into Earth by a
process called  Down-grading. Through this process the vibrational essence of
the race morphogenetic field could be “stepped down” to a slower vibrational
pattern, by passing a portion of the morphogenetic field through the core of
another planet in HU-1. This experiment would require the use of a plane-
tary body within the same time spiral cycles as Earth, which had a core vibra-
tional speed/particle pulsation rate slightly higher than that of Earth. The
planet chosen for this experiment is in your Sirius star system and is known as
Sirius B.  
    An artificial portal bridge was constructed between the core of Sirius B,
the Sphere of Amenti in D-4 and the Earth core at D-2. A small portion of
the Amenti morphogenetic field was placed within the core of Sirius B, the
part that contained the energy essence/souls of the Second Seeding. Some of
these soul essences combined their consciousness with the evolving etheric
consciousness of Sirius B and created a hybrid strain of Sirian-human con-
sciousness which came to be known as the Kantarians.  This name was
derived from the Kuntureaz,  the non-physical Sirian sub-race of conscious-
ness with which the human consciousness had merged. The Kantarians