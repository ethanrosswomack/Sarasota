31                                                                                                                                                                                                                                
 

 
         The Second Seeding  
mental kingdoms. These attributes of the Templar-Melchizedeks were not
originally part of the Melchizedek Cloister strain, but rather evolved through
ET distortion. The Cloister Family Melchizedeks are considered to be the
pure strain of this race, the Templar-Melchizedeks and their descendants a
mutation of that strain. In the following pages we will explore how that dis-
tinction came to be, as the duality within the Melchizedek race has created
an intense, hidden undercurrent within the ideologies of present day Earth,
greatly in ﬂuencing the development of many of your world religions. And
this distinction also directly affects the genetic code and ascension process of
descendants of the Melchizedek races.  
   The Melchizedeks of both Templar and Cloister persuasion draw their
name from their original genetic affiliation to the Turaneusiam-1 sub-race Mel-
chazedakz  from Tara, whose name also denoted their genetic affiliation with
the Entity gestalt Melchazedek from the realities beyond the Metagalactic
Core. There are many divergent races baring traces of the Melchizedek line
throughout all of the Harmonic Universes. Members of the Priesthood of
Melchizedek, who specialize in dimensional ascension training are not neces-
sarily direct members of the Melchizedek/Melchazedek race line, but often
work under the teaching programs of that Cloister.  
   During the Third Seeding, about 65,000 years ago, the Melchizedeks
appeared in Atlantean culture, and prior to the sinking of the Atlantean
islands (30,000 - 11,500 YA) retreated to an underground haven deep below
the Earth’s crust within a three-dimensional frequency modulation zone that
exists between Earth and her anti-particle double. This area is known as the
Inner Earth,  and large civilizations exist in these lands since times prior to
Atlantis, when the Melchizedeks and others began to retreat from surface life.
These underground civilizations exist to this day, and occasionally members
interact with surface Earth through the hidden caverns that link Earth’s surface
to the modulation zone of the Inner Earth. Both Cloister Family Melchizedeks
and Templar-Melchizedeks reside within these lands, under the primary guard-
ianship of the Speakers of the Blue Flame and Melchizedek Priesthood, and
Priesthoods of Ur and Mu from Tara. These sub-subterranean lands were origi-
nally called Ar-Ratoth, later Agratath and since about 3,000 years ago have
been referred to as Agartha.  
 The Cloister Family of Melchizedeks, Templar-Melchizedeks, the Staff
 of Amenti, The Speakers of the Blue Flame and  the Templar and Axion
                   Seals, the Eye of Elohim and the “666” Symbolism  
                                            10,000-3,500 YA  
    As we have mentioned, the first full wave of the Melchizedeks birthing
cycle began during the Third Seeding, about 35,000 years ago, the second
wave about 3,500 years ago and the last about  250 years ago and continues on