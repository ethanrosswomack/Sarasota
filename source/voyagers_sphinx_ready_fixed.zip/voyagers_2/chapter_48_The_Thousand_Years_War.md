48 
 
 

                                                                            
                                                                                                    The Thousand-Years’ War
exile on Sirius A with the Anunnaki joined in the Anunnaki Resistance, and
motivated their Drakon forefathers to join forces with the Anunnaki Resis-
tance, with the intent of destroying the Sphere of Amenti. In an attempt to
promote inter-galactic peace and safety for those to evolve on Earth, the Sir-
ian Council of HU-2 petitioned the Ra Confederacy and Axious Family Enti-
ties from the Metagalactic Core to intervene on behalf of the Treaty of El-
Annu. These Entity Families agreed, and the first administration of the Tem-
plar-Axion Seal  (the “666” genetic con figuration) was applied to the mor-
phogenetic field of those of the Anunnaki Resistance. The Seal was also
applied to the morphogenetic field of the Dracos hybrids. Neither strain
could now inter-breed with other species who did not carry the imprint of
their gene code. For those of the Anunnaki Resistance, the children of Annu
offered the only hope of their hybridization or reintegration on Earth, so even
before they were conceived in ﬂesh the children of Annu became a target for
infiltration by the Anunnaki Resistance. With the Treaty of El-Annu the
Thousand Years’ War was brought to a close, and the division between those
who served the Law of One and those who did not became more clearly
defined. Great protection was needed for the races of the Third Seeding, for
the Dracos, Drakon and the Anunnaki Resistance desired to see their
destruction. The Thousand Years’ War between the Elohim and the Anun-
naki brought an end to the Second Seeding of the human lineage on Earth.
  
       49