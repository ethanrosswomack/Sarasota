75                                                                                                                
                                                                                                                    

  A Journey Toward Awakening  
plane upon death. This was a definite advantage in terms of the evolution of
consciousness. However, there were also some disadvantages created by the
mechanics of the Frequency Fence.  
    The first disadvantage of the Frequency Fence was that the natural portal
structures which allowed for interstellar transit into Earth would be cut off
from the interdimensional grid. Interstellar Visitors could enter their craft
into the Earth Phantom frequency bands, but could not easily enter onto the
Earth's surface in the frequency bands below the Frequency Fence. Smaller,
more adaptable vessels were needed to orchestrate visitation, and each time a
vessel entered, it did so with the risk of disrupting the Frequency Fence,
which could release the Sphere of Amenti from its storage place. The Elohim
were put in charge of monitoring and protecting the Frequency Fence, and
the guardian organizations agreed that interstellar visitation to Earth would
be strictly limited to emergency intervention. The guardians adopted a policy
of non-interference with earthly affairs, but continued to hold the Frequency
Fence in place to preserve the integrity of the planet. lt was decided that
humans would be allowed to orchestrate their own affairs on Earth, with the
guardians attending to issues of evolutionary ascension from behind the
scenes. Because the Sphere of Amenti was now in a location more vulnerable
to Resistance attack, extremely high security measures were taken to ensure
that no one disrupted the Sphere or breached the Frequency Fence without
guardian approval. In the beginning, this fortification of the Fence was
intended for security purposes, but later it was used as a opportunity for the
Elohim to extend favoritism to those humans carrying genetic strains more
closely connected to their own morphogenetic imprint. This gave an unfair
evolutionary advantage to some humans, such as the Serres-Egyptians and
those of the Hibiru Cloister, who had stronger genetic ties to the Elohim
than many of the other races. The overall effect of the Frequency Fence and the
security tactics used to enforce it, was that the physical Earth and its peoples were
put under galactic Quarantine, losing all direct assistance from and relationship to
the multidimensional, inter-galactic communities.  Because of this quarantine,
information that traveled through the frequency bands of the higher dimen-
sions would no longer transmit into the Earth's grid and cellular memory. Not
only would the race memory from the Sphere of Amenti be unavailable to
humans upon the planet, but interdimensional communications from higher
dimensional fields would also be curtailed, as higher frequency transmissions
could not pass through the Frequency Fence. As generations of the races
evolved beneath the Frequency Fence, previous memory of humanity's
involvement with and genetic relationship to extraterrestrial civilizations
faded, and the advantages of technological advancement those relationships
allowed were lost.  
    Due to implementation of the Frequency Fence in 9540 BC, Earth
evolved under quarantine, and humanity was cut off from its interstellar heri-