82 
 
 

                                                                     
                                                                         
                                                                              Alcyone and the Templar Seal
way into the Inner Earth societies and their patriarchal, elitist, sexist, materi-
alistic slant began to color the original teachings of the Templar within cer-
tain groups. These creed distortions became apparent in the evolution of the
surface cultures, as did the progression of the Templar Seal genetic distortion,
as well as various other genetic anomalies that were created through inter-
breeding with a variety of Interstellar Visitors during the times of Atlantis .¹
     The genetic distortions were of great concern to the Palaidorians and
guardian races, as if the deviations in the DNA imprint became too numer-
ous, the original imprint for the races would be lost. If enough soul essences
from lineage with deviating genetic imprints passed back into their race mor-
phogenetic field at death, those deviations would eventually override the
original patterns in the morphogenetic field. If the Amenti race morphoge-
netic field became misaligned with the 12-strand pattern, evolution of the
12-strand DNA package could not take place.  
      In order to preserve the integrity of the Turaneusiam-2/human genetic line ,
the Sirian Council and Elohim were authorized by the Ra Confederacy to
remove certain portions of the race morphogenetic field from the Sphere of
Amenti, so the Amenti race morphogenetic field would not become misaligned
by deviations in the genetic imprint. The races removed from Amenti would
pass through the planetary morphogenetic field of Alcyone, and after death the
soul essence would evolve as consciousness for a time within the frequency
fields of Alcyone, through which genetic deviations of the human line could be
processed out before the consciousness returned to the Sphere of Amenti. This
separation of the morphogenetic fields became known as the Templar Seal . It
involved removing the sixth base tone of the second DNA strand, the sixth
overtone of the fourth DNA strand and the 12th overtone of the fifth DNA
strand. The races bearing this genetic imprint con figuration were sealed out of
the Sphere of Amenti morphogenetic field and redirected into evolution
through Alcyone, with the intention of one day releasing the Templar Seal and
reentering their morphogenetic field back into the Sphere of Amenti for ascen-
sion.  
     The races bearing the most genetic deviation were those of the T emplar-
Annu, who had been seeded through the Melchizedek Host Matrix, and
through them larger portions of the Melchizedek Cloister had become mis-
aligned with the 12-strand DNA imprint. Through the Melchizedek morpho-
genetic field, the Hebrew-Melchizedeks and Annu-Melchizedeks also carried
                         ________________________                    
                 1.   The Zephelium, the original race line of the modern day Zeta Reticuli and their Greys,
                           were one of the visiting groups to Atlantis who became genetically mixed with some of
      the T emplar-Annu race families. The reason contemporary Zeta sought genetic material
      from our race was that they hoped to find traces of their own original genetic imprint in
      our DNA, so they could reverse the mutations that had occurred in their own genetic
           lines and create hybrid versions of themselves more suited to Earth's environment