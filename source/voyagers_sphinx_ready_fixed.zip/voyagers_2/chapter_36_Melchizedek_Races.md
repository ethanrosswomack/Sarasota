36 
                                                                                         

                                                                                                                
                                                                                                              Melchizedek Races
the mystery schools of old and those of the present were all designed to assist
in the ascension passage. Many were designed specifically to release the Tem-
plar Seals, and to protect individuals from inadvertently adopting the Seals
through interbreeding.  
     Many people of present day Earth carry some portion, or all, of the T em-
plar Seals, and they will experience such a review after passing into the astral
plane in death. Others can begin this review before death by working with
spiritual principles and guardians/ascended masters, who will help them learn
the Law of One so the Seals can be removed prior to death, which will allow
some individuals to transmute the body and pass through the Halls of Amenti
to Tara, immortalizing the body as it was originally intended. The enforced
tour of duty of some of the Templar Seal bearers is almost at its end, as the
merger of Earth's grid and Tara will take place within the next three to four
Earth generations, a process that will begin in the year 2012. The Earth will
“ascend in waves,” as portions of its energetic systems merge with their dou-
bles and transmute into Tara's grid. The first wave will begin in 2012 and end
between 2072 and 2084, i.e., five to six 12-year cycles following the opening
of the Halls of Amenti, which is scheduled for 2012 - 2022. Humans who can
assemble their full fourth DNA strand will be able to ride this first wave into
ascension. The Second planetary ascension wave is not scheduled to occur
until about 4230 AD. Templar Seal bearers who have their Seals released can
ascend on this first wave, and be freed of the Earthly incarnational cycles.
     It would be helpful to humans if they could realize the reality of life after
death so when encountering this event some level of preparation can be
applied. Most humans would prepare for a trip across town, yet they make lit-
tle preparation for the greatest journey they will make; the voyage between
dimensions when they leave the con fines of one life time and their conscious-
ness moves into its next experience. All humans will have a personal review
of their life content upon this transition, but not a judgment placed upon
them. The personal soul and its higher levels of consciousness are aware of
the evolutionary process, the purpose of which is ascension. The soul aware-
ness becomes available to a human after the veils created by the con fines of
the physical genetic code are lifted, and the identity as soul then chooses the
next living experience most appropriate to its own evolution, learning,
desires and ascension process.  
    Much help is available in the higher dimensions, and there are many
institutes of higher learning, but one does not have to die in order to receive
this assistance. Education through the astral identity and projection of conscious-
ness is accessible to most humans while they are still alive in body, and through inte-
gration of the astral identity (which comes through building the fourth DNA strand)
the comprehension of the soul becomes available to the human on Earth.  It is
through this level of understanding that an individual can discover if the
Templar Seals are an issue, and if they are, how best to proceed for their