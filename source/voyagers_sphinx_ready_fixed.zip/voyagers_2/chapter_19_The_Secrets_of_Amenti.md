19
                                                                                                                                             

   
     The Secrets of Amenti  
Race strands as their frequency patterns were contained within the seventh
strand. Once strands 1—7 were assembled an lnterdimensional resonant tone
(three resonant tones) was created. The body could then turn into light, pass
through the Blue Flame in the Sphere of Amenti and re-manifest on Tara,
where assembly of strands 8-12 would continue. By removing one of the acti-
vation code/overtone frequency patterns from the morphogenetic field of the
Cloister,4 the human incarnate could not plug in the seventh DNA strand,
which meant that the incarnate could not assemble the strands of the other
Root Races so it could transmute into light to pass through the Blue Flame.
Humans carrying this code distortion became trapped in their matter bodies
within HU-1, and the supply of transmuting energy available to the matter
body became finite as the DNA strands that would have fed the body with
higher frequency energies were no longer operational. When the body
reached its genetic capacity for assembling frequency, then the physical struc-
ture would begin to deteriorate as the consciousness was transferred back into
the morphogenetic field. 
    Following this morphogenetic distortion, the consciousness would birth
into its Root Race, complete the 12 family and 12 sub-race transmutation
cycles, then run into the genetic frequency block. The body would die and
the incarnate would pass into the morphogenetic field for its Cloister, then
have to rebirth into a body within the next Root Race. After completing the
transmutation cycles of the Fourth Root Race the incarnate would pass into
its Cloister's morphogenetic field, then have to wait until the Fifth Root
Race manifestation cycle had begun, before it could complete its final incar-
nation in the Aeiran Root Race and release the Seal of Amenti. Once assem-
bling the fourth DNA strand through the Fifth Root Race incarnation the
Seal of Amenti would release from DNA strand one and the activation
codes/overtones from the Fifth Cloister would plug in, assemble the fifth,
sixth and seventh strands creating an interdimensional resonant tone. Then
the body could turn into light, pass through the Blue Flame and re-manifest
on Tara to continue evolution. The Seal of Amenti made it necessary to
incarnate three times, once within Root Races 3, 4, and 5, in order to com-
plete the dimensional ascension process into HU-2. After the sealing of the
Halls of Amenti, the Sphere of Amenti at Earth's core became the collector
of souls awaiting rebirth into the Fifth Root Race through which the Seal of
Amenti would be lifted, so they could ascend and be set free.  
     Following the Electric W ars, the Third and Fourth Root Races would
have to be reseeded on Earth, and the new seeding would carry with it the
    ___________________________  
       4.     The six th sub-frequency band overtone of dimension one was removed from strand one.