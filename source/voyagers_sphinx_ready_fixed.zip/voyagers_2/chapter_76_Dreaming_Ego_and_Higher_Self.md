76 
 
                                                                                           

                                                                   
                                                                                       Dreaming, Ego, and Higher Self
tage, but this was not the only disadvantage that the Frequency Fence cre-
ated for the human populations. The process of a soul essence birthing out of
the morphogenetic field of the Sphere of Amenti involves the essence pass-
ing out of its morphogenetic field and into the morphogenetic field of the
planet onto which it will birth. Once a soul essence has entered its planetary
morphogenetic field, it will then pass into the fetal pattern that was created
for its entry, and fetal integration of the soul consciousness occurs. As the
individualized morphogenetic field of the soul essence passes through the
planetary morphogenetic field, it picks up the frequency patterns characteris-
tic to the planetary core, which allows the essence to “ground” its identity
within the collective energy imprint of the planet.  
    After the Frequency Fence was applied and some of the third-dimen-
sional tones were removed from the planetary morphogenetic field, soul
essences passing through the Earth core for birthing could not ground the full
imprint for the third DNA strand, as the missing third-dimensional tones
would not allow the companion codes from the soul morphogenetic field to
plug into the Earth's morphogenetic field. The DNA is created in physical
terms as its already existing morphogenetic imprint passes through the Earth
core morphogenetic field where the energy imprint for the DNA then picks
up the particle patterns from the Earth that will “ ﬂesh out” the DNA imprint
in terms of dense-matter particles. If certain frequencies /tones are missing
from the Earth core, those frequencies carried in the DNA imprint cannot
flesh out into matter particles, and the DNA will manifest without those
tones in its operational strands. The Frequency Fence caused the third DNA
strand to manifest without the seventh through the twelfth base tones and
the seventh through the ninth overtones, which resulted in a genetic muta-
tion for the human lineage.                                 
                      
                        DREAMING, EGO, AND  HIGHER SELF  
                                                    Dreaming  
    The third DNA  strand corresponds to the third-Solar Plexus chakra, and
the third level of the bio-energetic field, the mental body. The DNA muta-
tion caused a division, or missing frequency link, in the third DNA strand
which manifested as a gap or void within areas of the bio-energetic system
that corresponded to that strand. The seventh through the twelfth base
tones/sub-frequency bands and seventh through the ninth overtones/sub-fre-
quency bands of the third dimension were blocked out of the third chakra,
and the nadial capsule, which naturally separates the third-dimensional/men-
tal body, and fourth-dimensional/astral body levels of the bio-energetic field,
developed a second barrier, creating an even larger gap between the con-
scious mental awareness and the astral level of awareness. ln sleep the con-
sciousness could travel into the astral identity, but now there would be a gap