84 
 

                                                                            
                                                                                       
                                                                                        Alcyone and the Templar Seal
within each of the seven sub-races are even further intermixed. We tell you
this so you may come to realize that  all of your races, though diversi fied in
genetic content are equal in value and all of them, by the design of their mor-
phogenetic pattern, are intertwined.  
    Discrimination of race, genetic lineage, or skin color is as ridiculous and
unfounded a notion as gender discrimination. Both of these ideas were given to you
at   various periods by different groups of non-terrestrial Visitors, in order to manipu-
late the evolution of the races for their own purposes. These notions have kept
your races and genders at odds, competing for who is better or best, when
instead the true power and beauty of the human races lies within its unity
which allows for diversification. You are all of equal value and importance,
and each of you brings unique characteristics and gifts into the human gene
pool. It would do your species well to realize this fact, so you can learn to
work together, through which all of you may heal and prosper. Now we will
conclude our discussion on the realignment of the Melchizedek morphoge-
netic field. 
    Following the implementation of the T emplar Seal upon the Annu and
Hebrew morphogenetic fields, these groups were provided with teachings from
the Priesthood of Ur in the lnner Earth, through which they were counseled
not to interbreed with members of the other races, so as not to pass on the
Templar Seal gene con figuration. Unfortunately, these teachings eventually
became distorted, the original meaning for the ban on interracial mixing
became lost, and the teachings evolved into an elitist creed of genetic superior-
ity among these groups. This attitude was perpetuated within the Annu and
Hebrew races and later developed into unnecessary cultural discord between
those of Annu and Hebrew lineage, and the Serres-Egyptian ruling class, and
the Hibiru, Aryan and Cloister Melchizedek families who made up the majority
of the Egyptian nations populations. This interracial discord exaggerated
already existing conditions of competition and conquest among the races.
When the Halls of Amenti were opened in 1374 BC, this interracial discord
proved to be a second primary setback to preparation for the 2017 AD mass
ascension wave. Due to interracial difficulties between the Annu-Melchizedek
and the Serres-Egyptian majorities, the Halls of Amenti were once again closed
and mass preparation for ascension was curtailed.      
    When the T emplar Seals were applied in 8,000 BC, guardianship of the
Arc of the Covenant was transferred out of the hands of the Annu-
Melchizedeks and Hebrew races into the protection of the Serres-Egyptians
and Cloister Family Melchizedeks (those born through the Sphere of Amenti
Melchizedek Cloister after the Annu and Hebrew morphogenetic fields had
been removed). Previously the four races shared responsibility and accessibil-
ity to the Arc of the Covenant, but following the Templar Seal only Cloister
Melchizedeks and Serres-Egyptians were permitted direct involvement with