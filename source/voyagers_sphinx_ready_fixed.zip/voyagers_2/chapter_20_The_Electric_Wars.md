20 
 
 

                                                                                                                The Electric Wars
Seal of Amenti. The Halls of Amenti were not in themselves sealed or
closed, they were only sealed to incarnates carrying the altered genetic strain.
Some ET hybrid strains of the humans in exile in other planetary systems,
who did not have the Seal of Amenti genetic distortion, returned to Earth
following the Electric Wars to pass through the Halls of Amenti. It was then
discovered that a much greater problem had occurred as a result of the Elec-
tric Wars.  
The Seal of Palaidor-Pole Tilt, Quick Freeze, Sphere of Amenti placed
  in D-4, lst Major Earth Flood, 5.5 Million Year-Old Wall in Time
                                   5,500,000 YA  
      Summary : As a result of damage from the Electric Wars the Elohim had to
place the Sphere of Amenti in D-4 creating a fourth-dimensional frequency
block within the second and third DNA strands, sealing Root Races 3 and 4
out of their morphogenetic field/soul matrices, creating build-up of soul frag-
ments in D-2, D-3 and D-4 that would have to integrate into Root Race 5 con-
sciousness. This created the subconscious mind D-2 emotional body which
would draw in elemental Lamanian/Lemurian-Root Race 3-soul fragments, a
D-3 egotistical mind that would draw in Alanian/Atlantean—Root Race 4-
soul fragments, and a D-4 astral mind-body that would draw in soul fragments
of Root Race three and four from the astral plane. Manifested as an extra D-4 fre-
quency pattern within the second and third DNA strands, a blockage within the sec-
ond and third chakras through which their energies could only merge through the fourth
chakra, and as an energetic barrier between the frequencies of the second, third and
fourth dimensions within the bio-energetic auric ﬁeld, this created separation between
the emotional, mental and astral identity aspects. Root Race 5 souls became
responsible for integrating the soul fragments of the Lamanians and Atlanians
of the Second Seeding and the Atlanteans and Lemurians of the Third Seed-
ing, which manifest as blockages within the second-emotional body, third-
mental body and fourth-astral body chakras and corresponding levels of the
auric field. Seal released through assembly of the fourth DNA strand and inte-
gration of soul fragments, which must occur before Seal of Amenti can release
from DNA strand one. Human consciousness lost awareness of its relationship
to Earth and the higher dimensions, and its species evolutionary memory, and
souls of Root Races and Cloisters from the Third and Fourth Races could only
evolve through the Fifth Root Race. Auric configuration remains in present
day human descendants of Root Races three and four and within Aryan Root
Race 5. The present Aryan Root Race is now responsible for integrating the
soul fragments of their Lamanian/Lemurian, and Ur-Antrian and Breanoua
Cloister ancestors from the Second and Third Seeding. The Aryan Root Race
is also responsible for integrating the anti-particle overtones omitted by the