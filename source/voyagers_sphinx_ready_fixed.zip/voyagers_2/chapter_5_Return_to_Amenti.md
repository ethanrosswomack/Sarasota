5
                                                                                                                                                                                              
                                                                    
            
Return to Amenti                                                      
                                                 
                                                 PHARAOH AKHENATON               
                   Return of the Sphere of Amenti, Birth of Pharaoh Akhen aton/  
                      Amenophis IV, Templar Seal Released From the Annu Races,  
                                           Opening the Halls of Amenti and Ascension  
                                                              2409 BC-l362 BC  
    The Sphere of Amenti could only be reentered into Earth’ s core during
the periods of dimensional blending within Earth’s natural time cycles. The
Elohim and guardians from HU-2 and HU-3 had orchestrated the Frequency
Fence and Earth's quarantine in 9540 BC in order to prevent the Sphere from
destroying Earth after it had prematurely descended through the Arc of the
Covenant as a result of the Atlantean cataclysm, and since 9540 BC the
Sphere of Amenti had been in storage, under high security, within the fre-
quency bands of the fourth dimension astral planes. The Earth’s grid had sta-
bilized and risen in vibrational speed since the times of Atlantis, and the
guardian races made plans to reenter the Sphere of Amenti into Earth’s core
through the barrier between the third and fourth dimensions during the next
natural opening in the time cycle, in preparation for opening the Halls of
Amenti. The next natural dimensional blending period would occur in 2409
BC, which marked the half cycle point within the 4426-year cycle that began
in 4622 BC. If the Sphere of Amenti could be entered into the third dimen-
sion in 2409 BC, it could then be returned to the Earth’s D-2 core whenever
the Earth grid speed rose high enough to hold the frequencies of the Blue
Flame morphogenetic field of Tara, which needed to be embodied on the
planet for the Halls of Amenti to open. As the Melchizedek Cloister race
held the imprint for the fifth DNA strand, which would pull fifth-dimen-
sional frequencies into the Earth grid, the opening of the Halls of Amenti
was dependent upon enough of the Melchizedeks and fifth strand hybrid races
being present on Earth to raise the grid speed high enough to hold the Blue