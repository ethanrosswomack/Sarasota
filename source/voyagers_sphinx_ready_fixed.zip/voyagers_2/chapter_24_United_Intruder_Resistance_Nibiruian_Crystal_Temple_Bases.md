24 United Intruder Resistance Nibiruian Crystal Temple Bases
                                                    (Underground or Underwater Illuminati Main Templar Control Bases)
CB =  Central Control Bases that direct operations of other Bases. MIB=  “Men In Black” Necromiton-human hybrid
1,  Kauai Hawaii, Cue Site-12- Necromiton-Andromie-Nephilim, Zephelium-Rigelian Zeta, Alpha-Omega Centaurians
2.  Vale of Pewsey S. England, SG-11: Pleiadian Samjase-Luciferian Anunnaki
3.   Abadan Iran SG-10- Odedicron-Reptilian Orion
4.  Pakistan CB: Omicron-Drakonian, Marduke-Dramin-Anunnaki and Necromiton-Andromie Nephilim
5.  Bermuda Island SG-3- Omicron-Drakonian and Zephelium-Rigelian-Zeta
6.  Sarasota Florida SG-2 Gru-AL- Thoth-Enki-Zephelium Anunnaki and Necromiton-Andromie Nibiruian Nephilim
7.  Machu Picchu Peru SG-5-  Pleiadian Samjase-Luciferian-Anunnaki
8.  Portugal CB-  Omicron-Drakonian, Necromiton-Andromie MIB and Odedicron-Reptilian
9.  Lake Titicaca Peru SG-7-  Omicron-Drakonian, Rigelian-Zeta and Pleiadian Samjase-Luciferian Anunnaki
10.Giza Egypt SG-4-  Omicron-Drakonian
11. Halley South Pole SG-1- Necromiton-Andromie MIB, Drakonian Dracos, Omicron-Drakonian, Rigelian-Zeta
12. Mauritania W.  Africa CB-  Omicron-Drakonian, Necromiton-Andromie MIB, Zeta Rigelian, Thoth-Enki-Zephelium     
Anunnaki
13. Paxos Island Greece Cue Site-7- Necromiton-Andromie MIB, Alpha-Omega Centaurians, Pleiadian Samjase-    
Luciferian Anunnaki.
14. Aguascalientes Mexico Cue Site-4-  Thoth-Enki-Zephelium Anunnaki, Rigelian-Zeta and Jehovian-Anunnaki
15. Cyprus Island Cue Site-1-  Omicron-Drakonian, Necromiton-Andromie MIB
16. Easter Island Cue Site-2-  Pleiadian Samjase-Luciferian-Anunnaki and Nibiruian Thoth-Enki-Zephelium Anunnaki,     
Enlil-Odedicron-Anunnaki.
17. Vatican City Rome Italy Cue Site-5-  Drakonian-Drakos, Omicron-Drakonian
18. Johannesburg S.  Africa Cue Site-3 – Omicron-Drakonian, Marduke-Dramin-Anunnaki
19. Brazil CB-  Marduke-Luciferian-Anunnaki Alpha Centauri, Enlil-Odedicron-Anunnaki Nibiru, Pleiadian Samjse-    
Luciferian-Anunnaki
20. Lop Nor Tibet Cue Site-8-  Jehovian-Anunnaki, Galactic Federation, Ashtar Command and Necromiton-Andromie     
Nephilim (Dove APIN central broadcast control)
21. Xian China SG-8- Omicron-Drakonian, Necromiton-Andromie MIB
22. Hamandan Iran CB-  Odedicron-Reptilian 
23. Al Basrah Iraq Cue Site-10- Drakonian-Dracos, Omicron-Drakonian, Necromiton-Andromie MIB
24. Bosnia CB-  Drakonian-Dracos, Necromiton-Andromie MIB and Nephilim , Marduke-Dramin-Anunnaki, Alpha-     
Omega Centaurians. (“Archangel Michael” broadcast central headquarters). 
There are many thousands of other UIR hidden bases positioned throughout the globe;     
the above 24 are the Primary Bases, located at the ancient Nibiruian Crystal Temple     
Pylon Crystal sites, through which the Planetary Templar and other bases are     
 controlled. Both UIR and Guardian subterranean bases are protected by UHF Cloaking    
                 Fields that are impermeable to present means of Earthly technological detection.
                                                                      
                                                                       © 2002 Ashayana   Deane  
                          
                            
                            525

                                                                                     2001 Update Summary Charts
          
     Angelic Human 12-Tribes and Indigo Maji Grail Lines Summary Chart
The ORIGINAL HUMAN 12-TRIBES Race Names that were edited from Essene CDT-Plate Biblical Translations 
TRIBE-1: Isutu-Esheau (Pronounced: I sU’ too-  E’ shoo). 
Star Gate DNA Signet Codes, Seed Locations and Races: SG-1. Arizona USA V ortex-1 Native American, Cue Site-1 Cyprus Island in      
Mediterranean Sea, Australia, Turkey and Greece and Antarctic SG-1 in Atlantian periods. Maji Indigo Grail Line : Original blue and      
green-eyed Australian Aborigine; often red haired.
TRIBE-2: Maahali-Bruea (Pronounced: Ma a ha’ LE- BrU’ A) 
Star Gate DNA Signet Codes, Seed Locations and Races: SG-2. Florida Seminol Native Americans SG-2 Sarasota Florida, and        
Breanoua black and brown skinned Haitian-Bimini Island races. Easter Island Cue Site-2 Muavaharivi and Jerusalem Israel V ortex-2      
Hebrew races. Maji Indigo Grail Line : Mu’A of Lemuria (Hawaii), Easter Island and Southwestern Native American descendant        
tribes. Original Hebrew (Hibiru Cloister and Melchizedek Cloister hybrid) races of Jerusalem and Jordan. 
TRIBE-3: Amekasan-Etur (Pronounced: a ME’ ka sun – e too’r). 
Star Gate DNA Signet Codes, Seed Locations and Races: SG-3. Nohassa Atlantis Bermuda Islands SG-3, Johannesburg South       
Africa black, brown and white skinned races and Nepal V ortex-3 Himalayas. Maji Indigo Grail Line : White-skinned Druedeks of      
Nohassa Atlantis.
TRIBE-4: Nuagu Hali (Pronounced: Noo ah’ goo- ha’ LE). 
Star Gate DNA Signet Codes, Seed Locations and Races: SG-4. Giza Egypt SG-4 and Sumerian UR, Aguascalientes Mexico Cue       
Site-4 and Central America. Maji Indigo Grail Line : Serres-Egyptians, original pre-Anunnaki Maya-Toltec and Mexicali Indians.
TRIBE-5: Ionatu-Etillah (Pronounced: I  O’ Na too- et il’ a) 
Star Gate DNA Signet Codes, Seed Locations and Races: SG-5. Machu Picchu Peru Incas SG-5, original Ionian Italic (Italian) races.  
Maji Indigo Grail Line : Mu’A-Incas of Machu Picchu Peru and light skinned-often fair or red-haired Celtic-Druedek Mu’A Ionians      
(combined Maji Grail Line of  Nohassa Atlantis Tribe-3 Maji Druedeks and  Lohas Atlantis Tribe-11 Maji Celteks exiled to Ionia as       
Anunnaki Leviathan raiding progressed.) 
TRIBE-6: Ramyana-Shridveta (Pronounced: Rah ma yah’ na- shrid vE’ Da). 
Star Gate DNA Signet Codes, Seed Locations and Races: SG-6. Russia Caucasus Mountains SG-6 and Scandinavian white skinned      
blond haired races, brown-skinned Rama races of India Thar Desert Cue Site-6. Maji Indigo Grail Line:  Rama-vita races of India      
and original blue-eyed blond Nordic races of Scandinavia and Russia. 
TRIBE-7: Mahata-Agrah (Pronounced: ME hah’ ta- a’g-ra) 
Star Gate DNA Signet Codes, Seed Location and Races: SG-7 Lake Titicaca Peru Incas and indigenous olive-skinned peoples of
Paxos Island Greece. Maji Indigo Grail Line : Original Mahata-Incas Lake Titicaca Peru ( ﬂed from Intruder raiders to Kauai Hawaii)      
and original olive-skinned green-eyed Ionians of Paxos Island.
TRIBE-8: Chia Zhun Zan La-Y ung (Pronounced:  ChE’ ah-Zoon – Y an LA-Y oong’). 
Star Gate DNA Signet Codes, Seed Locations and Races: SG-8. Xian China SG-8 original yellow-skinned races, and original brown-      
skinned races of Taklamakan Desert Tibet. Maji Indigo Grail Line:  Original YU-Melchizedek Tibetan light-brown-skinned, light-eyed       
races of Lop Nor Taklamakan Tibet region before Necromiton-Andromie Nephilim raiding and Yu-Chinese lineage.
TRIBE-9: Y un Zu-Xen (Pronounced: Y u-Un Zoo-Zen) 
Star Gate DNA Signet Codes, Seed Locations and Races: SG-9. North of Llasa Tibet SG-9 brown-skinned races and Westbury area      
Southern England white-skinned, dark-haired races Cue Site-9. Maji Indigo Grail Line:  YU-Mu’A Chinese and dark-haired, dark-      
eyed fair-skinned original English Mu’A Melchizedek races. 
TRIBE-10: Ma’ah-hu-ta (Pronounced: Ma-a hoo’ ta). 
Star Gate DNA Signet Codes, Seed Locations and Races: SG-10.  Sumerian UR, Persian Gulf Abadan Iran SG-10 area and Al       
Basrah Iraq Cue Site-10 area. Many family lines ﬂed to Sakkara Egypt and regions now called Afghanistan and Uzbekistan during        
early Sumerian raids; continue to live under persecution of Leviathan Illuminati races. Maji Indigo Grail Line: Light-brown-skinned      
light-eyed, dark-haired races and dark-eyed Essene-Melchizedek races of Persia, now most in Afghanistan, Uzbekistan and Russia. 
TRIBE-11: Zephar-Duun-Atur (Pronounced: Ze-far-Doon a-Tur). 
Star Gate DNA Signet Codes, Seed Locations and Races: SG-11. Southern Ireland Cue Site-11, Vale of Pewsey area Southern       
England SG-11, Scotland lowlands; white-skinned European races now in England, France, Russia, USA and Germany. Raided by      
Pleiadian-Samjase-Luciferian-Anunnaki Germanic “Sacheons”/Saxons. Maji Indigo Grail Line:  Celtek-Druedek hybrid Azurta-Arutus    
 “Celtic-Druids”, white-skinned, frequently red-haired. The true “King Arthur” Grail Line. 
TRIBE-12: A-reah-Azurta (Pronounced: a-RI’-a  Zoor’-ta). 
Star Gate DNA Signet Codes, Seed Locations and Races: SG-12. Monsegur Southern France SG-12 white-skinned and original       
MU’a Lemurian Kauai Hawaiian brown-skinned, dark-eyed races; exiled to Easter Island and Machu Picchu Peru (builders). 
Maji Indigo Grail Line : Original Mu’A Kauai Hawaiian brown-skinned and KatharA-Cathari white-skinned races of Southern France. 
                                                   © 2002 Ashayana Deane   
 
531                                    

                          
                        2001 Update Summary Charts
                            Intruder  ET and Illuminati Races of the 2001 UIR OWO Team Summary Chart Introduction.
                                                   Illuminati Hybrid Humans, Unity-Through-Diversity and Reclaiming Christos Potentials
  ''Primary Leviathan Illuminati Races ''/'' Human Tribe Infiltration '' refer to Illuminati hybrid race imposters         
within a given HumanTribe, and select family lines within a given Human Tribe that have been genetically    
compromised by Illuminati-hybrid interbreeding. These categories do not imply that named ethnic af ﬁliations    
are dominated by Intruder race genetic distortion; Illuminati ( non-human Intruder race souls) and In ﬁltrated     
family lines (Human souls, Intruder DNA attachments) make up the minority  in each Human ethnic group.    
Understanding the common problem  of Intruder race in ﬁltration now shared by all human cultures  should     
 allow for the advancement of a common ground problem-solving Human Unity Through Recognized      
Diversity , built upon inter-racial equality, respect, love and compassion. This knowledge IS NOT an    
excuse  to apply the Anti-Christos hatred creeds  of bigotry, race supremacy or prejudice against any      
lineage.  If successful in their “First Contact” invasion plan, the UIR intend to use “contrived historical and    
distorted genealogical” falsiﬁed “evidence ” to indicate that all Human races are a “common genetic lineage”    
derived from their combined Anunnaki-Sirian and Drakonian-Reptilian “stock”. This False Human Unity     
promotion  is intended to vanquish true Angelic Human Race identity  and obscure Illuminati-hybrid    
presence  to prepare us all for a “common uni ﬁed takeover” under a false UIR  “Creator God” platform. TRUE    
Human Unity  will be gained through loving identi ﬁcation of the Species Diversity  that exists within the     
“Common Chemical Clothing” of the “contemporary Human form”. Il luminati and in ﬁltrated Human family lines      
can make the choice to refuse Intruder association and opt for Emerald Covenant DNA Template Bio-           
Regenesis to continue their evolutionary path toward Christed Mastery, if they are aware of the evolutionary     
challenges and required solutions posed by Intruder race genetic connection.  Angelic Human/Indigo,       
Illuminati and In ﬁltrated races can all evolve to genuine “Christed Race” status and freedom . Due to                                                                
inherent genetic and Core Template differences, each group requires a different evolutionary path  by which     
the DNA Template, bio-energetic ﬁeld and consciousness template can reclaim the Base-12/D-12 Pre -matter    
“Divine Blueprint ” template coding required to attain genuine biologically based “ Christed Avatar     
Consciousness ”/ minimum 12-Strand DNA Template  potential. If the diversity within the illusion of the      
“Common Human Genome” is not recognized, all races will remain trapped within the present state       
of Common Race De-Evolution  through which the Christiac genetic potentials within each di versiﬁed race will     
become lost in progressive degeneration to race extinction.                
Most Human beings of Illuminati and In ﬁltrated Human race descent have no consciousness knowledge of      
their connection to Fallen Angelic Intruder ET races; nor are they aware that their genetic signature pre-      
disposes them to Intruder manipulation. This physical/emotional/mental/spiritual vulnerability to Intruder     
manipulation can be overcome if the individual comprehends the importance of utilizing genuine Founders     
Inner Christos Spiritual-Science teachings and technologies. Inner Christos D-12 Divine Blueprint sciences     
and Maharic Bio-Regenesis Technologies are the only methods by which regeneration of the DNA Strand      
Template–12 personal D-12 Pre-matter Divine Blueprint can occur to restore the individual’s direction      
connection to its D-12 Christos Avatar Identity. The Founder’s Bio-Spiritual Technologies allow the original    
connection to the Primal Light/Sound Fields to be restored  via reactivation of the 9-dimensional      
Antahkarana-Kundalini Cord  and 12-Dimensional Maharata Cord  Primal Life Force Currents.  Genetically    
vulnerable humans and Illuminati hybrids are loved by God/Source just as much as any other race  and can    
regain their freedom, free will, Bio-Spiritual Integrity and genuine Christos potential  through entering a    
chosen path of conscious evolution  built upon the genuine Founders Inner Christos spiritual/science     
teachings . Illuminati and in ﬁltrated races are victims to Intruder exploitation just as are Angelic Human and     
Indigo race lines. Like numerous Fallen Angelic races, Illuminati human-hybrid races can evolve beyond    
exploiting, abusive behaviors ; they need Love  (Tough Love  usually works better than Soft Love, which     
fallen races tend to exploit), Healing  and Inner Christos Spiritual  education , not judgment, condemnation     
and destruction, to reset and develop the Christos Potentials within themselves.   
                                                     © 2002 Ashayana Deane     
               
             532    
           
                                                                                                                                       

              
                                                                                                         2001 Update Summary Charts
     
                    Intruder ET a nd Illuminati Races of the 2001 UIR OWO Team Summary Chart (5 pages)
                              Phantom Matrix Andromeda and Centaur Intruder Races       •       
     Necromiton-Andromie : (Fallen Anu-Seraphim hybrid Andromeda) . Phantom Andromeda Planets, Alpha/Omega                               
       Centauri, Inner Earth. APIN System: “White Eagle” ('hi-jacked” GA “Gold Eagle” APIN). Falcon and Phoenix         
        Wormholes. Primary Races: Raelian “Elohim” Necromiton-Andromie insectoid-Beetle-People. Jehovian-Anunnaki-       
        Andromie-Human Nephilim dark-haired aquatic humanoid. /Annu-Melchizedek-Amealian-Nephilim. Hybornean-       
        Jehovian-Nephilim. Men-in-Black Human-insectoid hybrid Earth/Inner Earth. Marduke-Luciferian-Andromie-        
        Anunnaki insect-hominid hybrid. Omicron-Drakonian-Andromie “Vampire” serpent-dino-humanoid hybrid. Noors            
        Red Haired Humans (Omicron-Drakonian-Necromiton-Andromie-Pleiadian Human hybrid) Phantom Lyra        
        Vega/Pleiades/Alnitak (Orion-Necromiton Black League). Adalphi Blue Zeta (Necromiton-Andromie-Zeta Rigelian                   
        hybrid) Phantom Alpheratz, Andromea. Core Agendas : Andromie-Drakonian Drakonian-Orion Confederation    ,     
        Andromie-Anunnaki-Luciferian Pleiadian-Nibiruian Coalition,  Andromie-Anunnaki-Jehovian, United Federation of                  
        Planets , Andromie-Centaruian Alpha-Omega Order ;  Andromie-Supremacists Orion-Necromiton Black League .      
        Primary Leviathan Illuminati Races : Taozan King Atlantian Leviathan Illuminati lines, Asian Scarab and        
        Sadducees-Semetic Dragon Kings Leviathan Illuminati lines. Human Tribe in ﬁltration: Mongolian, China/ Japan/                  
        Tibet (Yu), Brazil, Chile, Turkey, Anastazi Native American, Hebrew. Associations: Buddhaic/ Tibetan/ Eastern/                
        Christian spiritual text distortions, the “Necromancy” Luciferian-Satanic Bible, Luciferian Egyptian/Tibetan/Mayan       
        mystical teachings, Alpha-Omega Templar Melchizedeks, “Lord Melchizedek”/“Archangel Michael”/”Angelic        
        Hierarchy”/ ''Kryon”/ ''Corteum '' Nephilim Anunnaki-Andromie hybrids.  False “Sananda-Jesus” contacts, Fallen                
        “Vairagi” false ''ascended masters, '' “Thule Society”, “Andromie” ET contact/channeling. ''Friendly Enemy'' allies       
        Marduke-Luciferian/ Marduke-Dramin(Omicron) Anunnaki /Jehovian-Anunnaki Nephite-Nephilim collectives.  Began       
        UIR 2000  / War Edict. UIR head.
•	Centaur-Luciferians and Blue Centaurs : (Fallen Anu-Seraphim hybrid Omega Centauri). Phantom Alpha and        
Omega Centauri. APIN System: “The OX” (Hi-jacked Maharajhi “Blue Oxen” APIN). Primary Races: Blue Centaurs      
Phantom Omega Centauri, Centaur-Luciferian Hominid-Centaurs (Marduke-Luciferian-Anunnaki-Centaur hybrid)       
Phantom Alpha Centaur/ Phantom Sirius B. Core Agenda : Centaurian-Necromiton-Andromie Centaurian Nation        
and Alpha-Omega Order . Primary Leviathan Illuminati Races:  Taozan King (Andromie-Anunnaki-Atalan King       
hybrid)/ Bhud-Rama King (Fallen Rama-Anunnaki-Andromie hybrid) Atlantian Leviathan Illuminati lines. Human       
Tribe Inﬁltration: India, Middle East, Pakistan, Turkey, the “Stans”, various Islands. Associations: Hindu/ Sanskrit      
Islamic text distortions, various Shamanic, Pagan, Druid, and WICCAN tradition distortions. Work with Andromie-           
Necromiton, some with Rebel Omicron-Drakonians. Joined UIR 2000  with Andromies. 
                                                                              
                                                                            Phantom Matrix  Zeta Intruder Races
•	Zeta-Rigelian/Zeta-Reticuli Zephelium : (Fallen Seraphim Lyra Vega/Apexian-Lau) Phantom Rigel Orion, Zeta-       
Reticuli, Bellatrix, Nibiru, Andromeda, Phantom Earth and various other locations. Primary Races:  All Zeta emerge       
from Zephelium  (tall bipedal blue-skinned Insectoid-Reptilian-Serpent  seed race) ; many strains . Azazael ( Blue-        
   Human-Reptile Omicron-Zephelium hybrid) Bellatrix. Aggressive Zeta-Rigelian  Omicron-hybrid “Tall Greys” Rigel       
Orion, Rutilia  (E.B.E.) Zeta-Dracos hybrid. Zeta-Reticuli   “Short Greys”, several insectoid forms, various        
systems/Phantom Earth.  Thoth-Enki-Zephelium (Zeta-Reticuli-Amealian-Anunnaki) hominid hybrid Nibiru                
Kurrendara  Orange Zeta (Dracos-Anunnaki-Zeta Rigelian hybrid) Nibiru. Adalphi Blue Zeta (Andromie-Necromiton-        
Zeta-Rigelian hybrid) Alpheratz Andromeda. Core Agenda:  Zeta Reticuli  Zeta-Pleiadian-Nibiruian-Anunnaki       
Pleiadian-Nibiruian Coalition  or Emerald Covenant (refugee) GA. Zeta-Rigelian  Zeta-Drakonian Drakonian-Orion      
Confederation . APIN System: Zeta-Rigelian  “The Falcon” APIN/Falcon Wormhole. Zeta-Reticuli: Pleiadian-Nibiruian       
Phoenix/Serpent.  Primary Leviathan Illuminati Races: Zeta-Reticuli / Ezeural/Beli-Kadmon/ Atalan King (Thoth-       
Enki-Zephelium-Anunnaki Nibiruian) Atlantian Leviathan Illuminati lines.  Larsa King  Sumerian/Osirius King Egyptian       
 (Nibiruian Anunnaki-hybrid) Leviathan Illuminati Lines. Zeta-Rigelian/  Dragon King (Germanic) Atlantian Leviathan       
Illuminati Lines. Human Tribe In ﬁltration: Both groups have small ancestral lines in most human 12-Tribes and      
contemporary abduction hybrids and clones of “body-snatched” human bodies.  Associations: Zeta Reticuli-        
Opened Phantom Earth Falcon Wormhole 1903-1916 raided by Zeta-Rigelians.  Pleiadian-Nibiruian Samjase-       
Luciferian/Thoth-Enki-Zephelium allies. Most accepted 1983-1984 Emerald Covenant Amnesty/Redemption       
Contracts, some joined Pleiadian-Nibiruian Anunnaki, to escape Zeta-Rigelians. Zeta Rigelians-  Drakonian-Orion      
Confederation administration, MJ-12 and Nazi Zeta Treaties, enslaved Zeta-Reticuli,  “Zeta-Talk”, Thule Society,       
Allister Crowley/ “Black Sun”/ “Golden Dawn”/ “Enochian Watchtowers” metaphysical cults, Pagan teaching       
distortions, Philadelphia Experiment/Montauk Project, 1983 Rigelian-Andromie Alliance. Work with Drakonian      
Necromiton-Andromies, some Omicron-Drakonian/Odedicron-Reptilian factions, “Big Brother Drac” World      
Management Team Illuminati/ “Montauk Boys”. Joined UIR 2000  with Necromiton-Andromies. 
                                                                                           © 2002 Ashayana Deane  
                      533      
                                                                                                                                                              

                
                  
              2001 Update Summary Charts
                                       Phantom Matrix Drakonian and Reptilian Intruder Races
•	Omicron-Drakonian:  (Fallen Seraphim line of Lyra-Vega) Alnitak,-Alnilam Orion, Alpha Draconis, Bellatrix.  APIN      
System: “The Dragon”. Primary Races: Omicron Bipedal Dragon-Moth-insectoid-dino-reptiles Orion.  Dracos        
human-hybrid (Lizard-hominid, some “morph” to human-like) Earth/Inner Earth, Phalzants  (Chupacabras) Omicron-      
Odedicron-mammal-hybrids, Kurrendara Anunnaki-Omicron-Zeta hybrid (Orange Zeta hybrid) Nibiru, Azazael ( Blue-      
Human-Reptile Omicron-Zephelium hybrid) Bellatrix. Marduke-Dramin-Anunnaki insect hominid (Omicron-Anunnaki       
hybrid) Core Agenda:  Omicron-Drakonian , Drakonian-Orion Confederation . Primary Leviathan Illuminati Races:      
Nephedem-Omicron human-hybrids. Etruan King/ Etalian King (Atlas-Etruan King hybrid)/ Roman Remus King       
(Etalian-Lathin  King hybrid)/ Pharisees-Semetic Dragon King (Hibiru) and Hallah King (Hibiru) Atlantian Leviathan       
Illuminati lines. Dragon King (Sumerian/ Egyptian-Tuthmosis-Ramses/Chinese/Japanese/Germanic) Leviathan       
Illuminati lines. Human Tribe In ﬁltration: Middle East/Persian (Ur/Hibiru/Hebrew/Akkadian), Taliban, Sumeria,        
Ionian (Etruscan and Roman), German/Russian, Anglo-Saxon, Asian/China (Yu), African, Aztecs, Incas, Native       
American. Associations: Knights Malta Catholic  Templar Knights , Roman “Mof ﬁa”, Scots “McDonald” raider line,       
Nazi creeds, “Black Sun” mystical schools, Curendara/ “Dramin Dragon Queen” Shamanism (Native American/       
Peru/ Africa), Haitian/African “Voo-Doo”, Roman Catholic control creeds, Toltec-Aztec , Inca,  Islamic,        
WICCAN/Pagan, Reiki text distortions, false GA claims “Omicron” group. Zeta-Rigelian/ some Odedicron-Reptilian/      
Marduke-Dramin-Anunnaki allies. Most join UIR 2000 ; rebels refuse UIR for Omicron-Drakonian OWO agenda.      
•	Dracos:  (Fallen Seraphim-Human hybrid) Earth, Inner Earth, Alcyone/ Tara. APIN System: Access to Omicron-       
Drakonian “Dragon”, Zeta-Rigelian “Falcon” and Pleiadian-Nibiruian “Phoenix” APINs. Primary Races: Hominid-      
Reptile created 1 million years ago Earth via Omicron-Drakonian forced Human interbreeding. Core Agenda:       
Reptilian-Drakonian Drakonian-Orion Confederation . Primary Leviathan Illuminati Races: “Human-Lizard Shape-      
shifters” Nephedem-Dracos hybrids Earth/ Inner Earth. Human Tribe In ﬁltration: North-South American/ Brazilian/      
African/various island Tribal cultures, Middle Eastern, Egyptian, South/South-Mid Western USA, Cuba, Australia,      
England, Spain, Portugal. Associations: Various Shamanic tradition distortions, promote false “Environmental       
causes  /  Drak “technologies”/ “ET Contact demos”, utilize astral projection to initiate “astral-body sex” with Humans       
for D-4 astral-body bio- ﬁeld/DNA Template implanting, use sound-tones for D-4/Chakra-4 astral cording/ bio- ﬁeld      
Tagging in unsuspecting humans via public events. Work with Zeta-Rigelian/ Omicron-Drakonian/ Odedicron-       
Reptilian UIR groups, Nibiruian Kurrendara (Dracos-Anunnaki hybrids) and Marduke-Dramin-Anunnaki  (Omicron-      
Anunnaki hybrids). Most joined UIR 2000  with Zeta-Rigelians; some refuse UIR for Rebel Omicron-Drakonians. 
•	Odedicron-Reptilian:  (Fallen Seraphim line of Lyra-Vega) Alnilam Orion, Lyra-Vega, Inner Earth.  APIN System:      
 “The Falcon”. Primary Races: Odedicron Avian-Reptile “Gargoyle” winged reptile-hominid hybrids. Enlil Enlil-       
Odedicron-Amealian-Anunnaki hybrid Nibiru, Beli-Kudyem Odedicron-Anunnaki-Turaneusiam-Human hybrids       
Alcyone/Tara.  Core Agenda: Reptilian-Drakonian, Drakonian-Orion Confederation  or Reptilian-Anunnaki Pleiadian-      
Nibiruian Coalition .  Primary Leviathan Illuminati Races: Nephedem-Odedicron human-hybrids Earth/Inner Earth,      
Lathin King Atlantian-Greek and Arcadian King Illuminati line, Roman Romulous King (Etalian-Lathin King Atlantian      
hybrid) Illuminati line, Atlas King, Sumerian-Egyptian Horus King (Enlil-Odedicron-Anunnaki-hybrid) Leviathan       
Illuminati line. Human Tribe In ﬁltration: Egypt , Central America, Native American, Mexico, Hawaii, Polynesian       
Island, South America, South Africa, Ionia (Italy/Greece), England, Germany. Associations:       
Egyptian/Pagan/Shamanic/Kahuna mystical teaching distortions, Egyptian “Crocodile Cults” and “Falcon Cults”,       
Malaysian “Voo-Doo”, “Lord Maitreya”, Christian texts distortions. Some work with Odedicron-Drakonian Dragon-      
Moths, others with Zeta-Reticuli Greys and Pleiadian-Samjase-Luciferian-Anunnaki; most joined UIR 2000 , a few      
factions joined Rebel Omicron-Drakonians. Several factions in Emerald Covenant Redemption Contracts. 
                                                                                  © 2002 Ashayana Deane
               
               
              534    
          

                                                                                                                                          
                                                                                                                       2001 Update Summary charts         
                                    
                                                       Phantom Matrix  Anunnaki Intruder Races
• Marduke-Luciferian-Anunnaki:  (Fallen Anu-Seraphim hybrid, Lyra Aveyon) Phantom Alpha/Omega Centauri,                          
Nibiru, Tiamat. APIN System: NDC-Grid/NCT-Bases/NET, Phoenix, Serpent Nibiruian APINs. Primary Races : -    
Vichoritz insectoid-serpent-hominid (Thoth-Enki Lulitan family-Amealian-Anunnaki/Marduke Satain family-Amealian        
-Anunnaki/Necromiton- Andromie hybrid) and Vichor  Light-haired Humanoid (Pleiadian-Amealian-Anunnaki/Vichoritz     
hybrid) Nibiru, Tiamat, Alpha Centauri. Centaur-Luciferians Hominid-Centaur hybrids (Vichoritz-Centaur) Alpha          
Centaur. Core Agenda : Luciferian-Anunnaki Pleiadian-Nibiruian Coalition  and/or Necromiton-Andromie Orion-     
Necromiton Black League . Primary Leviathan Illuminati Races: Elucum King/ Beli-Kadmon Atalan King Atlantian     
Leviathan Illuminati lines. Babylonian-Sumerian Vicherous King (Elucum King-Druedic Maji hybrid) “Scandinavian     
Vi-Kings”, Hyksos King Knights Templar/Freemason Master Race  Leviathan Illuminati lines. Human Tribe     
Inﬁltration: Raided Tribe-3 Druedic Maji lines Nohasa Atlantis/ Scandinavia/ England/Ireland/Scotland, Scots     
“McGregor” raider lines, Knights Templar Freemasons. Associations: 9560BC Luciferian Covenant. Work with     
Pleiadian-Samjase-Luciferian-Anunnaki/ Nibiruian Thoth-Enki-Zephelium-Anunnaki and/or Centaur Luciferian/     
Necromiton-Andromie Orion-Necromiton Black League .  Druid, Celtic, Pagan and Protestant Christian text     
distortions. Most joined UIR 2000  with Necromiton-Andromies. 
• Marduke-Dramin/Satain-Anunnaki:  (Fallen Anu-Seraphim hybrid, Lyra Aveyon) Phantom Alpha Centauri, Sirius B,     
Alnilam Orion, Alpha Draconis, Nibiru. APIN System: NDC-Grid/NCT-Bases/NET, Dragon, “Crocodile”(now dis-     
mantled) and Falcon Drakonian APINs Primary Races : Dramin-Dragon-Queen  dino-insect-hominid Anunnaki hybrid    
(Amealian-Anunnaki-Aquatic-Ape Marduke-Satain family line-Omicron-Drakonian-Dragon Moth hybrid). Sathosah      
Dark-haired “Hook Nose”, olive-skinned Humanoid Sirian Anunnaki (Jehovian-Satain-Nephilim-Omicron-Nephite-     
Human). Core Agenda : Satanic-Drakonian Orion-Necromiton Black League . Primary Leviathan Illuminati Races:     
Sathian King (Etruan King-Marduke Sathosah hybrid) Atlantean Leviathan Illuminati line. Babylonian-Chaldean-     
Akkadian King (Jehovian Anunnaki Nohassim-Hassah King-Sathian King hybrid) Atlantian Leviathan Illuminati line.      
Set King Egyptian (Sathian King-Babylonian King-Horus King hybrid) Leviathan Illuminati line.  Human Tribe     
Inﬁltration: Middle Eastern Hibiru, Sumeria, Akkadian-Chaldean, Babylonian, Egyptian, Native American “Kota”     
tribes, Angolan-Portuguese-W. African, Russian. Associations: “Dramin the Dragon Queen”, Egyptian “Set”     
schools, Biblical “Seth” lineage, “Necromancy” Satanic Bible, “Satanism”, Islamic and Hebrew text distortions,     
 “KKK”, Russian Psychic “Rasputin” and related “channels”. Work with Omicron-Drakonians, Dracos and Orion-     
Necromiton Black League Pro-Drac Necromiton-Andromies. Most joined UIR 2000;  some factions refused UIR for     
Rebel Omicron-Drakonians.
• Enlil-Odedicron-Anunnaki:  (Fallen Annu-Seraphim hybrid, Aveyon Lyra) Nibiru, Phantom Tiamat, Lyra-Avalon     
APIN System: “The Phoenix”. Primary Races: Enlil Amealian-Anunnaki-Aquatic-Ape/Odedicron-Avian-Reptile     
scaled reptile-hominid hybrid. Beli-Kudyem  Odedicron-Anunnaki-Turaneusiam-Human human-reptile hybrids     
Alcyone/Tara  Core Agenda:  Reptilian-Anunnaki Pleiadian-Nibiruian Coalition  or Reptilian-Drakonian Drakonian-     
Orion Confederation.   Primary Leviathan Illuminati Races: Ediruan King Atlantian/Sumerian/African Leviathan                    
Illuminati lines. Beli-Kadmon/ Atalan/Arcadia-Greek King (Nibiruian Anunnaki hybrid) Atlantian Leviathan Illuminati     
lines. Atlas King Atlantian-Sumerian and Horus-Scarab King Egyptian Leviathan Illuminati lines. Hyksos Knights     
Templar King  Anunnaki and Drakonian Anti-Christos Master Race line. Roman Romulous King and Sacheon-Gual     
King (Pleiadian-Samjase-Luciferian-Anunnaki Sacheon/Saxon- Germanic-Hyksos-Omicron Drakonian) Dragon King     
lines. Human Tribe In ﬁltration: Egyptian, African, Arcadian-Greek, South American, Inca, NW Native American,     
NW French, S. English. Associations: With Enki-Zephelium/Marduke-Luciferian Anunnaki created Nibiruian     
Primate-hominid Lulcus-Neanderthal slave race for African gold mines and Middle East labor, 250,000BC. Enlil-     
Anunnaki Raider Race of 148,000BC-75,000BC Anu Occupation, 25,000BC Lucifer Rebellion, 10,500 BC Luciferian     
Conquest, 9560BC Luciferian Covenant Atlantian Human Tribe Invasions Atlantian-Egyptian  “Phoenix” and Falcon     
mystical schools, Falcon Shamanic traditions, Nubian/ Mayan/Toltec/Olmec/ Native American “Falcon Cults” and     
“Crocodile Cults”, Gaul raider races of France, Britain, Europe, Knights Templar Free Masons Anunnaki and     
Drakonian factions. Most are members of Nibiruian Councils 9 and 12, Pleiadian-Nibiruian Coalition, Galactic     
Federation and Ashtar Command. Defected from Pleiadian-Sirian Agreements/Treaty of Altair to join UIR 2000 with     
GF, Ashtar Command and Nibiruian Council Anunnaki.                         
                                                                                               
                                                               © 2002 Ashayana Deane    
               535                                                     
                                                                                                                                       

                                                                                                                      
                   2001 Update Summary Charts
                                                                   Phan tom Matrix  Anunnaki Intruder Races (continued)
•	Jehovian Anunnaki : (Fallen Annu-Elohim Jehovani D-11 “dark avatar” collective) Phantom Lyra Aveyon, Sirius A,         
Arcturus, Alpha Centauri, Andromeda, Trapezium (Theta) Orion. APIN System: Jehovian-Nephite: “Dove and Olive      
Branch” HD-C/APIN, Jehovian 7-Seals, Arcturian Trumpet technologies and Phoenix Wormhole access. Jehovian-      
Nephilim-Morantian: Dove, Dragon and Falcon APINs. Jehovian-Nephilim-Nephite-Drakonian: Dragon and Falcon      
APINs. Primary Races:  Jehovanians Fallen Annu-Elohim. Fallen Ophanium  “Overlords”  (Oraphim Maji-Nephite      
Anunnaki hybrid) Arcturus, Trapezium Orion. Bipedal Dolphin People Anunnaki cetacean-hominid Sirius A (original           
Anunnaki pure strain), Schriki-EL  aquatic dolphins Earth. Nephite “Hook Nose”, dark haired Humanoids (Dolphin      
People Anunnaki-Hebrew/Hibiru-Melchizedek-Cloister-Human hybrids) Phantom Sirius A (“Etheric Sirians”), Orion,      
 Anteres, Pleiades, Arcturus and Lyra Aveyon (Humanoid “Arcturians” and “Lyrans”). Morantians  Jehovian-Nephilim      
Humanoid (Necromiton-Andromie-Jehovian-Anunnaki-human hybrid) Sirius A, Arcturus, Alpha Centauri,      
Andromeda. Core Agenda: Jehovian-Nephilim-Morantians : Annu-Elohim Federation of Planets. Jehovian-Nephite-     
Nohassim(Zadok): Orion-Necromiton Black League. Jehovian-Nephite-Drakonian (Baal) : Drakonian Orion      
Confederation. Jehovian-Nephite-Adam Kadmon (Belil-Davidic):  Pleiadian-Nibiruian Coalition.  Primary Leviathan      
Illuminati Races:  Jehovian-Nephilim-Morantians: Admian-Nephilim Urantia King (Morantian-Necromiton-Andromie-      
Jehovian-Anunnaki-Ur-Antrian-Cloister-Human hybrid) and Annu-Melchizedek Adamian-Nephite King Lemurian      
Leviathan Illuminati lines. Jehovian-Nephite-Nohassim “Sirian Sons of Zadok” : Zadokhim-Hassim King (Enochian       
Adamian-Nephite), Hassa King (Zadokhim-Hassim) and YHWH Hibiru King Atlantian Leviathan Illuminati Lines.      
Jehovian-Nephite-Adam Kadmon “Nibiruian Sons of Belil”: Nohassim-Adam-Kadmon King (Enochian Zadokhim /      
Thoth-Enki-Zephelium Ezeural  Beli-Kadmon Nibiruian hybrid), Larsa King (Enochian Nohassim-Adam-Kadmon/      
Thoth-Enki Ezeural and Samjase-Luciferian Sacheon-Atalan) and Davidic King (Knights Templar Enochian-      
Thothian-Hyksos Adam-Kadmon, the Abraham-David-Moses-Akhenaton-Jeshewua-9 lineage) Atlantian Adam      
Kadmon-Nephite Leviathan Illuminati lines. Jehovian-Nephite-Drakonian “ Orion Sons of Baal ”:  Taozan-Sadducees     
(Necromiton-Andromie-Jehovian Anunnaki hybrid) and Hassad-Pharisees (Omicron-Drakonian-Jehovian-Anunnaki      
 hybrid) Semetic Jehovian Dragon King lines.  Hallah King (Zadokhim-Hassim-Necromiton-Andromie-Omicron-     
Drakonian) Atlantian Nephilim-Nephite-Drakonian Leviathan Illuminati line . Human Tribe In ﬁltration: Extensive      
raiding of Angelic Human Hibiru, Hebrew (Hibiru-Melchizedek Cloister) and Essene (Melchizedek Cloister) Indigo      
Maji Grail Lines, and moderate in ﬁltration of Yu (Chinese/Tibetan), Sumerian/ Egyptian/Middle Eastern, all      
European/ American cultures. Associations: Jehovian-Nephilim-Morantians:  Major distortions of original      
Lemurian/Atlantian/Essene Emerald Covenant CDT-Plate Christos teachings, Christian Protestant text distortions,      
Urantia Book, Templar Melchizedek Mormon texts.  Jehovian-Nephite-Nohassim : Created “YHWY”/ “Jehovah” God      
 stories/ false 12-Tribe History in Hebrew/Christian texts. Jehovian-Nephite-Adam Kadmon : Promote Jehovah/      
YHWH/ Metatron/ Ophanium/ Enoch/ Archangel Michael and Tibetan creeds. Jehovian-Nephite-Drakonian: Kaballah      
Hebrew text distortions, inverted-reversed 10-Sephiroth “Tree of Life”, removed 6 letters from Hebrew alphabet.      
Traditional and Hassidic Hebrew texts distortions. Jehovian renegades in Galactic Federation/ Ashtar Command/      
Nibiruian Councils. Course in Miracles channeling and Thoth-Isis-Merlin-Archangel Michael teachings are Jehovian/      
GF/ Necromiton-Andromie Nephilim Anunnaki Co-op. Most join UIR 2000  with GF, Ashtar Command and Nibiruian      
Council. Some Jehovian-Nephite-Drakonian groups joined Rebel Omicron-Drakonian OWO agenda.
•	Pleiadian-Samjase-Luciferian-Anunnaki: (Fallen Annu-Seraphim hybrid, Aveyon Lyra) APIN System: The NDC-       
Grid, NET, “Phoenix” APIN, Phoenix wormhole, “White Eagle” APIN  Primary Races: Beli-Kudyem Reptilian-           
Anunnaki-human hybrid “Blonds” (Marduke-Luciferian-Anunnaki line of Sirius A raided Procyon Serres Maji races)       
Tara, Alcyone, Procyon and Nibiru.  Borjha “little blue hominids” of Pleiadian Alcyone, Nibiru, Tiamat, Tara. Beli-       
Kudyem human-reptile hybrids Alcyone and Inner Earth. Beli-Mahatma Pleiadian-Jehovian Anunnaki-Human       
reptilian-aquatic-human hybrids, look like “pretty perfect humans” of various heights with blond or dark hair and                
bright blue eyes, usually wear white robes and falsely claim ascended mastery, Alcyone, Inner Earth, Parallel Earth       
and Sirius A (majority race of GF and Ashtar Command). Core Agenda : Pleiadian-Nibiruian Coalition- Luciferian       
Covenant “Anunnaki Resistance” agenda.  Primary Leviathan Illuminati Races: Bruah Atlantis Atalan Kings, Lohas      
Atlantis Sacheons-Saxons Kings (Celtec-Dreudic Maji Tribe raids),  Atlantian-Sumerian  Larsa Kings, Isis Queen-       
Egyptian line, Hyksos Knights Templar-Freemason Master Race, Cathari (raid of Maji KatharA Indigo Tribe of S.       
France). Human Tribe In ﬁltration: Russia-Germany, England, France, Scotland, North and South America.       
Afﬁliations: Protestant Christian text distortions, “Isis” mystical schools, Pleiadian channels and UFO contacts,                                            
work closely with Nibiruian Anunnaki Thoth-Enki-Zeta, Enlil-Odedicron and Marduke-Luciferian lines. “Mahatma” and      
Rosecrution spiritual teachings, ancient “Olympian Gods” of Rome and Greece, Galactic Federation, Ashtar       
Command and Pleiadian-Nibiruian Council. Anunnaki portions of World Management Team Illuminati, Alpha-Omega     
Melchizedek schools, false “Mother Mary” contacts. Work with Nibiruian Thoth-Enki and Enlil-Odedicron-Anunnaki,       
Zeta-Reticuli, Necromiton-Andromie-Nephilim hybrids, Centaur-Luciferian-Anunnaki. Defected from 1992 Pleiadian-      
Sirian Agreements; all joined UIR 2000  with Galactic Federation, Ashtar Command and Nibiruian Council.                                                                                                                 
                                                                                         © 2002 Ashayana Deane   
             536                                                                                                        
             
  

                                                                                                                     2001 Update Summary Charts
                                                           Phantom Matrix  Anunnaki Intruder Races (continued)
•	Thoth-Enki-Zephelium Anunnaki : (Fallen Anu-Seraphim hybrid Lyra Aveyon). Nibiru, Tiamat, Lyra-Aveyon. APIN       
System : NDC-Grid/Battlestar Wormwood/ NET, “Serpent”, “Phoenix” and “Falcon” APINs. Primary Races :      
Amealians Anunnaki-aquatic ape-hominid Lyra-Aveyon. Enki-Zephelium-Anunnaki black-haired, tan-skinned, “Hook                 
Nose” tall humanoid-insectoid-reptilian-serpent (Amealian-Anunnaki-Zeta-Reticuli-Zephelium hybrid) Nibiru. Thoth-                   
Enki-Zephelium-Anunnaki (the Enki-Zephelium-Anunnaki Lulitan family line of Thoth), seed of the earthly E-Luhli      
Levi, Juda, Nephi and Annu-Melchizedek human-hybrid Leviathan races. Essesani, Luciferian-Anunnaki similar to      
Enki-Zephelium-Anunnaki but shorter, stockier build (Nibiruian Thoth-Enki-Zephelium Lulitan family line plus      
Marduke-Dramin/Omicron-Anunnaki Satain family line combined to form the original “Luciferian” Amealian-Anunnaki      
seed race.)   Core Agenda : Pleiadian-Nibiruian Coalition- Luciferian Covenant “Anunnaki Resistance” agenda.       
Primary Leviathan Illuminati Races : Belil-Annu-Melchizedek (Paracletes) Atalan King Atlantian Leviathan      
Illuminati line Bruah Atlantis, Larsa Kings raiders of Lohas Atlantis and Sumeria (Thoth-Belil/Samjase-Luciferian      
Sacheon/ Jehovian-Nephite-Adam Kadmon Leviathan hybrids). Osirius and Thoth Egyptian King lines, Greek-      
Roman Amulius King (Hermes-Tris-me-gis-tus lineage) and Hyksos Kings Anunnaki Master Raider Race (Knights      
Templar Freemasons) and Mayan-Hyksos King Leviathan Illuminati lines. Human Tribe Infiltration : Raiding of       
Bruah (Florida Seminal Native American Maji Tribes), Nohassa (Bermuda Island Maji tribes), Lohas (Druedic and      
Celtec Maji Tribes) Atlantis, Sumerian Ur, Egypt Giza and Sakkara (Serres Maji Tribes), Mayan, African, Central      
American, Peruvian-Inca (Maji Tribes) and various Native American tribes. Associations : Initiators of the 9560BC      
Luciferian Covenant OWO Nibiruian-Atlantian Dominion Master Plan. Dominant force of the Anunnaki portions of      
World Management Team Illuminati. Greek Hermes Tris-me-gis-tus, Greek-Roman Amulius and Julius Caesar       
Nibiruian King lines, some Roman and Greek “Olympian Gods” legends. Mayan-Quetzalcoatl, forced Human tribes      
to adopt Nibiruian-distorted Mayan Calendar and Nibiruian-created Julian Calendar in Rome. Egyptian Osirius-Isis      
mystical schools, the Atlantian Emerald Tablets (Written translations of part of data stored on Emerald Covenant       
CDT-Plate-11 stolen by Thoth in 22,340BC.) and “Brotherhood of the Snak e” Atlantian mystical schools. Led      
Nibiruian Anunnaki invader races in the Eieyani Indigo Massacre of 22,326BC Lemurian Islands (Kauai Hawaii).       
“Thoth” Alpha-Omega Melchizedek mystical schools, “Lord Melchizedek” and related channel contacts, Christian-      
Protestant text distortions, Osirius-Isis-Horus Egyptian schools. Most groups were Emerald Covenant loyal until      
Thoth defected from Emerald Covenant just prior to the SAC and Eieyani Massacre of 22,326BC. Coerced Enoch      
and his Kodazhim hybrid races to defect from Emerald Covenant to enter the Luciferian Covenant in 10,500BC to      
launch “Hyksos-Knights Templar Master Race Plan”.  Works closely with Nibiruian Enlil-Odedicron-Anunnaki,      
Pleiadian-Samjase-Luciferian-Anunnaki (primary allies), Zeta-Reticuli Zephelium, Necromiton-Andromie-      
Drakonian/Jehovian-Nephilim (primary allies) hybrids and Centaur-Luciferian-Anunnaki.  Defected from 1992       
Pleiadian-Sirian Agreements /2000 Treaty of Altair for UIR 2000. A driving force within the contemporary  New Age      
Movement Indigo  Hi-jack Plan  (body-snatching of as-yet-unawakened Indigo Maji Types 1-2-3 via Astral Implant      
Tagging, Astral Over-shadowing and eventual full body possession.) 
                                           
(Afﬁliations also include ‘’Merlin and Thoth’’ channels and contacts)
                                   
 
                                                            © 2002 Ashayana Deane           
537
                                                                                                                                                                                                                                                                                                            
                                                                                                             

                                                                               Appendix VI
                                                        
                          
                      
                       Crisis Intervention Expedited                                    
                         Amenti Opening Schedule            
      Due to the Sept 12, 2000 Fallen Angelic /Intruder ET United Resistance Illuminati     
  Edict of War and United Resistance’s intention of orchestrating Earth Templar takeover    
  and pole shift by 2008, Guardian nations issued an Imminent Crisis Order in October    
  2000, setting in motion the Emerald Covenant Masters Planetary Stewardship Initiative.    
  As per this Crisis Intervention Program, Sirius B Star Gate-6 and the D-12 Halls of    
  Amorea Passage were activated seven years early in May 2001. Advanced Planetary Tem-    
  plar RRTs are now being conducted, in effort to achieve Planetary D-12 Maharic Seal    
  Protection of Earth’s Templar and populations before Aug12, 2003. Early activation of D-