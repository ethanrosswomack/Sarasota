1 Merkaba Fields of the Sun had to be returned to their original polarity. This
would correct the D-1 Merkaba Field of Earth and the D-4 Merkaba Field of
Tara-Earth so the grids could fuse in 2012, if the Earth grid vibration was
raised high enough in time to hold the Sphere of Amenti.  
    The Earth’ s grid had to reach the speed of the UHF bands of D-3 for the
first seal on the Arc of the Covenant to spark and release the Sphere of
Amenti by 10/1986. It would be difficult, if not impossible, for the Guardians
to raise Earth's grid speed that high without the infusions of D-4 energy that
were now blocked by the 11:11/12:12 Frequency Fence, so correction of the
Sun’s Merkaba Fields became a race for time within the Guardian legions.
Even though the Frequency Fence did not lift until 1992, the Guardians were
successful in raising the grid speed enough for the Arc of the Covenant to
open by the 10/1986 deadline. The accelerated energy infusions used to re-
balance the Merkaba Fields of the Sun, began in 1973 and were projected
into the solar fields via beam ships stationed in the future D-4 time cycle.
These infusions would cause rapid shifts of the energy fields on Earth, which
would have created havoc within the consciousness of the human popula-
tions and instability of Earth’s natural EM fields. However, the 11:11/12:12
Frequency Fence allowed the Guardians to employ Holographic Insert tech-
nology on Earth, through which the illusion of grid stability could be created,
so the Guardian re-balancing efforts would remain undetected and excessive
instability within the human populations could be avoided.  Earth existed
under these Guardian-created Holographic Inserts from 1973 to 1/11/1992, when
the 11:11/12:12 Frequency Fence began lifting.  
                                      
                                      THE MONTAUK PROJECT            
          Zetas and Rigelians, the Montauk Project 1983 and 2976 AD 
    Between 1973 and 1980 Earth remained under the Guardians’  Holo-
graphic Inserts and the illusion of electromagnetic stability they created,
while the Guardians worked to complete realignment of the Sun’s Merkaba
Fields. By 1982 the Zetas became tremendously frustrated as they observed
136 
                        
          

                                                                            
                                                                                 The Montauk Project
the continuing breakdown of their Collective Mind Complex in the D-4
time cycle, and began to realize that the Guardians would correct the mis-
alignment of the Sun in time for the ascension period to proceed as sched-
uled. Between 1982 and 1984, most members of the Zeta Legion entered into
treaties with the Guardian races, and agreed to stop their plan of Earth in fil-
tration. These agreements also included the Zetas from the D-4 time cycle,
who had fallen under domination of the Dracos in that future time period.
The Guardians agreed to relocate the Zeta races and their hybrids to another
planetary system in D-4, where they could evolve peacefully, as long as the
Zetas agreed to follow the dictates of the Sirian Council and Galactic Federa-
tion, and to operate upon principles of the Law of One from that time for-
ward. The Zetas were also required to fully dismantle their Collective Mind
Complex in D-4, to release the Zeta Seal Frequency Fence and to assist the
Guardians in preparing Earth and humanity for 2012. Though most of the
Zetas agreed, and began working with the Guardians in 1983, several Zeta
and most Dracos groups refused to release their desire for possession of Earth.
These groups became known as the Dracos-Zeta Resistance,  which included
rebellious Zeta races, Dracos and their hybrids.  
     The primary Zeta groups that refused Guardian treaties are the Zeta
Greys from a solar system that orbits the star Rigel, in the Orion star system.
These are frequently called the  Rigelians ; we know them as the Futczhi  (pro-
nounced FOO’-SHE). It is this Zeta group that formed treaties with the Inte-
rior Government on Earth and orchestrated the Zeta Seal and manipulations
of the Sun. They are the most aggressive and militant of the Zeta Grey races
and are extremely dangerous to humans, because they often attempt to
present themselves as Guardians in order to seduce humans into being their
earthly operatives. The Rigelians/Futczhi dominated the other Zeta races in
the D-4 time cycle until the majority of these non-Rigelian Zetas rebelled
and sought Guardian protection when this option was offered between 1982-
1984. Following the Guardian treaties of 1982-1984, the Zeta-Dracos hybrids
known as the Rutilia,  who had always been the primary go-betweens in Zeta-
Futczhi/human relations, served as infiltrates within the Interior Govern-
ment, and continued to secretly motivate humans to continue helping them
fulfill their old agenda. (Note: the Rutilia are those beings referred to by the
government as “EBE’s” - Extraterrestrial Biological Entities. They closely
resemble the Greys, but usually have a lighter gray to gray-white complexion,
and more pronounced ridging at the rear of the skull.) The Dracos-Zeta
Resistance had to find a way to reconstruct the Zeta Seal, Frequency Fence
and Zeta Collective Mind Complex before 2012, in order to regain control of
the human populations in D-4.  
     The Dracos-Zeta Resistance set their new plan in motion in 1983, when
they covertly motivated humans to create another experiment, similar to the 
Philadelphia Experiment of 1943. They desired to create another rip in space-
137 
                                                                                                                                                                                                                                    

Countdown to Amenti  
time, through which large numbers of their ships could be secretly sent from
the future to Earth, into three different time-space coordinates. From these
positions in time, the ships could enter the D-2 frequency bands of Earth and
begin transmitting EM pulses through the Earth’s grid, which would serve to
reconstruct their Frequency Fence and cause mutation in the fourth DNA
strand.  
     Even if the grids of Earth and Tara were able to merge between 2012-2017,
the human gene code would not have time to fully assemble the fifth DNA
strand in the majority of the populations. This would stop the scheduled ascen-
sions through the Halls of Amenti and keep the Zeta Seal operational within
the Sphere of Amenti, so their human captives in D-4 would once again be
subject to Zeta-Dracos control. For their new plan to work, the Zetas had to
begin broadcasting their EM pulse Frequency Fence as close to 2012 as possible,
while still allowing enough time for the fence to take effect within the human
gene code. It would take a minimum of six years for the new frequency fence to
cause the fourth DNA strand mutation in the majority of the human popula-
tions, so the Dracos-Zeta Resistance would have to begin broadcasting their
EM pulses no later than 2006. If they began broadcasting too soon, the Guard-
ians’ infusions of  D-4 frequency would counteract their EM transmissions, and
the genetic mutation would not “hold” within the DNA. The Dracos-Zeta
Resistance decided upon the year 2004 as their target date. In order to ful fill
their plan of covert mass infiltration, they would have to enter their ﬂeets into
Earth’s D-2 frequency bands during the peak of Earth’s D-1/D-4 Merkaba Field
cycle, which takes place every 20 years on August 12th.  
    Dimensional Merkaba Fields go through cycles of movement in which
the two spiraling energy fields vertically condense and draw toward each
other, then progressively expand on the vertical axis, drawing away from each
other. When the Merkaba Fields draw away from each other, the upright
electrical spiral moves into the magnetic Merkaba spiral of the dimension
above, which causes a temporary blending of frequencies between the mag-
netic spiral of one dimension and that of the dimension above. These points
of interdimensional magnetic spiral blending are called Dimensional Mag-
netic Peaks.  During Magnetic Peaks, natural interdimensional portal win-
dows briefly open, allowing unencumbered transit between dimensional
bands. Magnetic Peaks also occur between the Merkaba Spirals of Harmonic
Universes, through which the Merkaba Fields of a dimension in one Har-
monic Universe blend with the Merkaba Fields of the corresponding dimen-
sion one Harmonic Universe up; these blending periods are called Harmonic
Magnetic Peaks.  Each Harmonic Universe has three dimensions, each of the
three dimensions representing a base tone, overtone or resonant tone, within
the 15-dimensional scale. D-1, D-4, D-7, D-10, and D-13 are base tone
dimensions. D-2, D-5, D-8, D-11 and D-13 are overtone dimensions. D-3, D-
138 

  
                                                                                    The Montauk Project
6, D-9, D-12 and D-15 are resonant tone dimensions. Harmonic Magnetic
Peaks occur when base tone —base tone, overtone —overtone, or resonant
tone—resonant tone Merkaba Field alignments take place. The D-1 base tone
Merkaba Field of Earth and the D-4 base tone Merkaba Field of Tara reach
their Magnetic Peak cycle once every 20 years between August 12th-15th,
at which time a dimensional window opens between Earth’s HU-1, and Tara’s
HU-2, time continuum cycles.  
    The first Harmonic Magnetic Peak of the 20th century occurred on
August 12th, 1903, and the last on August 12th, 1983. These periods mark a
time of peak magnetic pull within Earth’s subtle energy bodies and height-
ened dimensional blending, through which large numbers of Dracos-Zeta
ships could be cloaked and brought to Earth from D-4. August 12th, 2003 is
the closest peak date to the Dracos-Zeta Resistance target date of 2004. The
plan called for a simultaneous entry of beam ships during three time periods,
and once the Zetas had successfully orchestrated in filtration, they would
broadcast their Frequency Fence through Earth’s grid and begin the genetic
mutation. If they attempted this mutation from only one time period, there
would not be enough time for it to take hold within the majority of the popu-
lations. By entering the EM transmissions at the three different, but closely
related time periods of 1943, 1983, and 2003, a great number of people would
be affected.  
    For the Dracos-Zeta Resistance plan to be effective, they would have to
create three rips in space-time on Earth, through which their ships could be
entered. One such rip already existed from the Philadelphia Experiment of
1943 and one would have to be created in 2003. The Resistance scheduled
the third rip in space-time for the next Harmonic Magnetic Peak cycle of
August 12th 1983, the only opportunity they would have before 2003.
Working with the Interior Government, the Dracos-Zeta Resistance orches-
trated another experiment, which came to be known as the Montauk
Project.  Again, accounts of this experiment are available in other publica-
tions, so we will not detail here.  
    The Montauk project served to widen the rip in 1983 space-time that
had begun as the result of the Philadelphia Experiment. By August 14th
1983 the time periods of 1943 and 1983 were successfully linked to the Dra-
cos-Zeta Resistance D-4 time period, which they used as a base of operations.
From 1983 to the present, the Dracos-Zeta Resistance resumed their
hybridization program through abducting humans, creating several strains
of hybrids and human clones. They also created in filtrates via genetic engi-
neering, through which they could interface with Earth’s cultures under
the guise of human form. In filtrates are children conceived of natural
human conception, whose mothers were abducted during pregnancy so Zeta-
Dracos genetic materials could be infused into the fetus. These children are
born (usually within the seventh month of gestation) and raised by their
139 
                                                                                                                                                                   

Countdown to Amenti  
human parents, and appear to be fully human. They are consciously unaware
of their ET affiliation, but can be subliminally directed by the Dracos-Zeta
Resistance via the DNA and neurological structure. When Guardian groups
locate such in filtrate individuals, they orchestrate abductions, and dismantle
the Zeta-Dracos gene codes, thereby freeing these mostly human subjects
from their covert controllers.                              
                         2976 AD and the Dracos-Zeta Resistance  
    The Guardians became aware of the Dracos-Zeta Resistance problem in
1984, and were able to trace probable events in the future that would result
from this present activity. What they discovered was alarming, as the conse-
quences of this in filtration were more far-reaching than they had speculated.
They discovered a future event that would occur in the year 2976 AD, that was
the result of the Zetas’ interference after the year 2000. In this probable future,
the Guardians had been successful in realigning the Merkaba Fields of Earth
and the Sun, but in 2003 AD the Dracos-Zeta Resistance is also successful with
their in filtration plan. The Guardians saw that the Zetas’ new Frequency Fence
partially misaligns Earth’s grid in 2012, and when Earth and Tara begin to inter-
sect, major Earth changes result. Though Earth still fuses with Tara and
releases a morphogenetic wave as intended, just as that wave begins to crest
(2012), the Earth changes begin. When the morphogenetic wave begins to
crest, the Halls of Amenti portals open, but the Earth grid must be stable in
order for the Halls to remain open through their 10-year cycle (2012-2022).
The Earth changes cause a premature closing of the Halls of Amenti, which
creates a rapid drop in Earth’s grid speed. The Sphere of Amenti cannot be left
in Earth's core during this drop in vibration or the Earth grid will explode. In
this future probability, Guardians remove the Sphere of Amenti from Earth and
human populations come under direct covert control of the Dracos-Zeta Resis-
tance. The Zeta Seal genetic mutation is returned to the human race. Once
Earth is under Dracos-Zeta rule, the Zetas are attacked and dominated by the
Dracos group with whom they had been working. The Dracos take command
of Earth in both the D-3 and D-4 time cycles and begin to use the D-3 Earth
as a storehouse for unwanted photo-nuclear waste materials from the D-4
Tara-Earth time cycle.  (Photo-nuclear waste is produced through certain pro-
cesses involving the manufacture of photonic energy through manipulation of
multidimensional nuclear materials). This process causes a massive nuclear
explosion on D-3 Earth in 2976 AD, through which Earth is destroyed.  All
souls involved in the cataclysm fragment and are lost within HU-1. Their con-
nections to the Sphere of Amenti race morphogenetic field and their personal
soul matrices are severed.  
    If this future event occurred in present-Earth's line of development, not
only would the Earth and the major part of the human race be lost, but the evo-
140 

                                                                                
                                                                                     The Montauk Project
lution of Tara in HU-2 would be set back by eons, as Tara would remain
trapped in her HU-2 time cycles until Earth’s imprint could be reconstructed
and re-evolve in HU-1.  
    Upon discovering these probable future events, Guardian groups made
an appeal to the Resistance Zetas, telling them of the Dracos’ betrayal and
offering to assist them in relocation, if they would give up their in filtration
plan. The Zetas refused to alter their plans.  
    Though the Guardians could easily subdue the Dracos-Zeta legions in a
forced confrontation, such a confrontation would cause major damage to
the Earth’s Merkaba Fields, which would ensure the destruction of the
human populations.  The Guardians had to find a better way to avert the
new Dracos-Zeta agenda. Not only did the Guardians bear the responsibility
for preparing Earth and humanity for 2012, they now had the additional bur-
den of protecting their preparation plan from Dracos-Zeta Resistance sabo-
tage. In December of 1984, the Sirian Council, Pleiadian Star League,
Sirian-Arcturian Coalition for Inter —planetary Defense, the Andromeda Fed-
eration of Planets, the Palaidorians of HU-2 and several other Guardian
groups from HU-l, HU-2 and HU-3, co-created the Bridge Zone Project,  in
order to protect Earth and the human populations from Dracos-Zeta Resis-
tance in filtration, and the destruction of Earth in 2976 AD that would result
from this interference.  
    The Dracos-Zeta Resistance is presently quite aware of the Guardian’ s
Bridge Zone plan, but they are con fident that humanity will be unable to rise
to the occasion and feel sure their in filtration plan will be successful. The
Guardians believe humanity can indeed pull together and make the Bridge
Zone project a success. For this reason we of the Guardian Alliance bring to
you this hidden knowledge, so that you may be prepared to make a stand on
behalf of your own evolution and freedom.  
141