15  The Atlantian Conspiracy and Roundtables ............................................310                      
              Long-Term Problems and Immediate Solutions ...................................... 310                                                                                            
                 The Atlantian Conspiracy .............................................................................311                                                       
                 King Arthur and the Knights of the Roundtable ..................................... .315
    Progression of Major Events in the Atlantian Conspiracy ..................... .319
     Core Template Gridwork is Required . ..................................................... .328
    Creation of the Leviathan Force & Related History  ...............................328
      Angelic Human Seeding-3—Contemporary Lineage Begins  ............... .328 
    Summary of the Atlantian Conspiracy ..................................................... .330
    The REAL Atlantian-Lemurian Maps ........................................................331
    Note On 12-Strand DNA Template Activation: Be Aware  ................... ..333