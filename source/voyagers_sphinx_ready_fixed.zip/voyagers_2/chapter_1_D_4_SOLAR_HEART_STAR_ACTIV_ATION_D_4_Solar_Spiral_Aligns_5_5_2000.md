1  D-4 SOLAR - HEART STAR  - ACTIV ATION: D-4 Solar Spiral Aligns 5/5/2000
        ' DATES A V AILABLE FOR ACTIV ATION : 5/5/2000 - 2022 general populations
         STAR CRYSTAL SEAL ACTIV ATES : # 5 D-4/D- 5 BLUE STAR CRYSTAL  chakra 4 Heart Chakra
      RELEASES STAR CRYSTAL SEAL : # 2 D-1/D-2 Orange Star Crystal Seal opens
      DNA:  Strand 4 assembles & activates  Fire Code : ½ strands 1-2 activate  ACCRETION LEVEL : 3 to 4
      CHAKRAS:  draw frequency  from Solar Spiral through chakras 11 & 12, into chakras 4 & 5 then into
      Blue Star Crystal Seal
      Blue Wave Infusions  of D-4/D-5 frequency begin at Blue Star one-half activation                                             __________________________________________________________________________________ _____