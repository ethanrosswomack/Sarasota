12 Palaidia  Empires of the Urtite-Cloisters were seeded upon the locations  
   of the 12 Templar Cue Sites. The 12 Templar Cue Sites  correspond to   
   the 12 Crystal Pylon Temple Signet Site  star gates of Inner Earth , and 
 serve as the “trigger sites” for remote activation of surface Earth’s 12Tem-
plar Signet Site  star gate opening points. Each of the 12 Palaidia Empires 
were co-founded by Urtite-Cloister Race strains carrying the five Cloister 
 269 
 
                                                                                                        
  

   The Angelic Human Heritage and Rainbow Roundtables  
Race  genetic codes of the 12-Tribes Angelic Human  line, seeded by  a spe-
cialized Urtite Tri-Cloister Maji Holy Grail Line Seed Race .  
                                    URTITIE-TRI-CLOISTER MAJI HOLY GRAIL LINE  
                                                               FLAME KEEPER S 
    The Maji Holy Grail Lines emerging into the Urtite-Cloister lineage of
12-Tribes Seeding-3 all incarnated directly from the Density-5 Primal Light 
Fields, or the Primal Sound Field s from beyond the Time Matrix. The initial 
Palaidoria Empire Urtite-Cloister Maji Holy Grails  were  Rishi and 
Ascended Master “Yanas”  consciousness incarnating directly into the  
earthly drama.  The Urtite-Cloister Maji incarnated into specific Tri-Cloister 
body forms  carrying the 24-48 Strand DNA Template . The Tri-Cloister 
genetic code  carried the DNA  T emplates of three  Cloister race lines com-
bined,  plus that of the Shambali and Bhrama Mixed Cloister Angelic 
Human lines that had evolved in Inner Earth  after the cataclysm of the 
Thousand Years War of 846,000BC  that ended 12-Tribes Seeding-2 (see
 page 43).  Each Maji emerged into Density through one of the 3  Primary 
Founder Race Breneau Collectives, each from one of the 3  Primal Light 
Fields  of Density-5 (See page 48).                           
    The Urtite-Tri-Cloister Maji Holy Grail Lines  that founded the 12 
Palaidia Empires were incarnate members of the Emerald Order, Gold Order
  and Amethyst Order Y anas Collectives, the  “Eieyani ” Ascended Masters , 
from the Primal Sound Fields  beyond the Time Matrix. The High Council 
Emerald Order  Elohei-Elohim “ Blue Flame Keepers ” Grandeyanas  incar-
nated from the Eckatic Level of the Energy Matrix Primal Sound Fields. The 
Middle Council Gold Order  Seraphei-Seraphim “ Gold Flame Keepers ” 
Wachayanas  incarnated from the Polaric Level , and the Base Council Ame-
thyst Order  Bra-ha-Rama “ Violet Flame Keepers ” Ramyanas incarnated 
from the Triadic Level  of the Energy Matrix. Each of the first Urtite-Tri-
Cloister Priest-King Lines (both male and female were referred to equally by
the same title) carried the Eieyani Priest of Ur Ascended Master genetic
code. Through the Eieyani Priest Maji Urtite-Tri-Cloister DNA Template , 
the “ Rainbow Ray Current ” could be embodied, for remote activation  of
the Signet Shields, Signet Plates  and Templar Cue Sites  of Earth’s Templar. 
The “ Rainbow Ray Current ” is composed of the Khundaray Current   standing-
wave frequencies of the Primal Sound Fields from beyond the Time 
Matrix, the Kee-Ra-ShA Current  standing-wave frequencies of the Density-