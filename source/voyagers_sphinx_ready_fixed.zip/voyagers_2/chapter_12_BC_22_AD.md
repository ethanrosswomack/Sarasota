12 BC-22 AD        
     The Azurite Council knew that in order for the races to be prepared for the
mass ascension wave of 2017 AD, the integrity of the Sphere of Amenti must be
restored by realigning the portions of the Sphere trapped within the D-2 Earth
morphogenetic field. The Alcyone morphogenetic fields of Templar
Melchizedeks and those that received the Templar-Axion Seal during
Akhenaton’s reign and were stored in Sirius B, also needed to be reintegrated
into the Sphere of Amenti. Despite the failures of Akhenaton’s campaign, he
had successfully reintegrated the Annu peoples into the Sphere of Amenti
morphogenetic field, so a similar arrangement was made in reference to the
Templar and Templar-Axion Sealed race families. This time, not only would
the races be restored to their place within Amenti, the entire Sphere of
Amenti would be realigned with the original 12-strand DNA pattern. Realign-
ment of the Sphere of Amenti would allow all of the races to heal their genetic
distortions in preparation for the opening of the Halls of Amenti, and would
restore the integrity of the Sphere of Amenti so the Halls of Amenti could he
opened. This realignment project would require the services of a 12th-level
avatar, whose energetic imprint contained the alignment of 12-dimensional
frequencies. This 12th-level avatar was to realign the Sphere of Amenti and
the Alcyone morphogenetic field of the Templar Sealed Hebrew and Annu
Melchizedeks, and he was intended to bring together the factions within the
Essenes that had developed within the Melchizedek and Hebrew Cloisters. He
would also re-enter the original egalitarian Templar creed back into the teach-
ings of the Essenes.  
    Under the direction of Azurites of the Ra Confederacy , in 12 BC, the
12th-level avatar, a pure Taran Turaneusiam-1 soul essence was born outside of
Bethlehem in a private residence, to a Blue Flame Melchizedek-Hebrew Essene
mother and a Blue Flame Melchizedek-Hibiru Cloister Essene father. It was not
an Immaculate Conception, but rather orchestrated via traditional means
through a couple chosen and prepared by the Priests of  Ur. His mother’s name
was Jeudi, his father Joehius; both were leaders within the Blue Flame
Melchizedek Essene sect. The child’s soul essence was born of the HU-4 avatar
Sananda,  and the child was named Jesheua-Melchizedek (herein Jesheua-12),
who later became known as Jesus, son of Mary and Joseph. The personages of
Mary and Joseph were not the parents of this avatar child, they were the par-
ents of a ninth-level avatar soon to follow. Jesheua-12 was born to descendants
of the house of Solomon, and taken in infancy into the custody of the Priests of
Ur.