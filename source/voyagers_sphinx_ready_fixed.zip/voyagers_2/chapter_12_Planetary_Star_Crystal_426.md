12 Planetary Star Crystal 426
Jehovian opening schedule 429
Morphogenetic Seed Crystal 463
Security 254, 256, 34
see also Amenti
see also Amenti, Sphere of
see also Palaidor
see also Templar
see also Templar -Axion
     see also Zeta                                                       
     Seven Jehovian 426
     seven natural 142
Sedona, AZ 188, 346
see also Interdimensional Association of Free
                Worlds
Seed Codes 477
                                                             

Index, Volume II
Seed Implants 394
Seedings 328
      First 17, 78, 244, 251
     Second 21, 25, 26, 27-31, 43-51, 55, 63,
          271
               Atlanians 21, 22, 28-29, 45, 46,
                               123
               Lamanians 21 , 22, 28-30, 44, 45,
                                46, 55-56
     Third 21, 26, 28, 32, 36, 47, 51, 52, 55-
             70, 261, 269, 311
              Atlanteans 21, 22, 28, 32-33, 56-
                                59, 63-74, 78, 82, 84, 86,
                                87, 123
                   -Egyptian sub-race 48
                Lemurians 21, 22, 28, 56-59, 78,
                                 82, 84
Selenite Crystal Temple Network 339
selves
       1728 simultaneous 299
       3456 simultaneous 297
Seraphei-Seraphim 369
Seres 46, 50
Serpent 374
Serres 46, 91, 368
       -Egyptian father of Akhenaton 88
        -Egyptians 82, 85, 89, 91, 93, 94, 97, 323
                       evolutionary advantage of 76
   -Pleiadian 318
Serres-Egyptians 323
Set Kings 321
Seven Angels 417, 418, 431
Seven Angels with Seven Trumpets 416
Seven Angels with their Seven Trumpets 414
Seven Candlesticks 418
Seven Churches 417, 418
Seven Seals 414, 416, 420, 426,431
Seven Stars 418
Seven Trumpets 431
sexism 46
shadow self 35
Shambali, Bhrama and Annu-Melchizedek
                 Races of Inner Earth 271-272
Shambali-lonian Islands 271
Shamballah 271
Shield
     of Aramatena 281, 283, 291, 310
     of the Arc 52
Siberia 377
Signet
Ancestral Ascendancy 304
Codes 319
Council 304, 315
Councils 315, 319
maps and keys 305
Master Key Codes 273, 275
Rainbow Roundtables 340
Sites, 12 Primary Star Gates 251
Star Gates 294, 311
Silicate Matrix 300
Sir Lancelot 315
Sirian 2, 6, 65, 223
    -Arcturian Coalition for Interplanetary
             Defense 50, 51, 60, 71, 133, 141,
             233, 234
577Council 2, 3, 4, 7, 27, 28, 34, 36, 50, 60-
            69, 71-75, 83, 88, 93, 96, 97, 122,
            133, 137, 141, 177, 187, 188, 191,
            233, 250
                    intervention in 1972 133
Rebellion 3, 4, 45
root races
        Anunnaki 4, 18, 33, 45, 47, 50-69
                        86, 186, 191, 242, 245
        and Jehovah 100
        as Gods of humans 46
        Rebellion 58
        Resistance 142, 50-69, 71, 72
                           176
        see also 666
        see also Akhenaton
         blues 4, 47, 57, 73
Sirius 26, 244
     A 47, 48, 55, 102,242,379, 418
              Jehovian Anunnaki 320
              Jehovian-Nibiruian Anunnaki 319
    B 27-29, 48, 51, 55, 57, 62-65, 73, 93,
      94, 99, 100, 102, 250, 317, 379
            Azurite Yani 266
            Maharaji 271
            Marduke-Anunnaki 320
Sirius A 379
slaves 352
sleep 77-78
sleepers 347, 354, 355, 363, 365, 377, 380,
               399, 406
      Angelic 356
Smenkhkaré 94-95
Snake Brotherhood Kings 321
Sodom and Gomorrah 513, 322
Sodom and Gomorrah. 406
Solar
      Star Gate-4, see Universal Star Gate
solar
      activation 204
      eclipse 182
      ﬂares 133
      storms 182
solid matter
      illusion of 149
Solomon 99
Sonic Pillars 394
Sonic Pulse 374, 378, 385
soul
     agreements 172
          Anna remembers her 236
     fragmentation 16, 93
     harvesting 36
     mate 148
Soul Integration 301
sound
     -Symbol Program 303
     -tone Programs 303 
     Tones 108
Sound Pillars 372
South America 368, 377
space
     as an illusion 129
     distance as magnetic repulsion 129
Sphinx 59-64, 73, 82, 86, 207, 367-368

      hidden passages below 207
      rebuilt 64
Spiking Campaign 394
spiritual development 241
Spiritual Integration 298
Spiritual Manipulation 399
Spokane, WA 409
St. John the Divine 416
St. Louis, MO 409
Staff 74, 92, 120
     Holder 54
     see also rod and staff
standing wave pattern 14
star
     gate 245, 272, 276-285, 288, 299, 319,
            321
                -10 378
                -3 391
                -4 391, 396
                -4 see Universal Star Gate<$no
                                  Page> 340
                 -5 Alcyone 340
-6 339
-7 392, 417
-9 378
D-6 Sirius B 339
internal 297, 298, 301, 308
locations 317
planned destruction of 313
   gates 367
   tetrahedron 126
   wars 175, 257
states of being 456, 458
Stellar
   Activations 155, 180, 186, 195, 292, 302,
        463-466, 482
Arcturian 200
Orion 200
Pleiadian 200
see also SAC Rebellion
Sirian 200
Solar 200
Transmutative 471
             mechanics of 199
             six 199-200, 466, 471-472
                                  476
Bridge 470-473
Spiral Alignments 475
Spirals 127, 142, 186, 471
         Alignments 199, 482
         what you must know 484
Wave Infusions 186, 466-470, 472, 482
Blue 200, 237, 466
Blue-Black 200, 466
Gold 200, 466
mechanics of 199
          Silver 200, 466
          Silver-Black 200
         symptoms of 469
         Violet 200, 466
Stellar Activations Cycle 281, 286, 288, 313,  
578Index, V olume II
                   354
Stellar Activations Cycles 413
Stellar Wave Infusions 339, 404
Stonehenge 247, 251, 312, 316, 319, 321,
                    340
stress 469
suicide 42
Sumer 321
Sumeria 28, 86, 322
Sumerian Invasion 312, 321, 330
Sun 6, 126-140
abnormal activity on 131
affected by Zeta electromagnetic pulses 132
as eighth Pleiadian star 115, 128
as iron core crystal D-1 Merkaba Fields 128
illusion of distance 164
manipulation of energy field of 131
Superconscious Mind 81
Syria 101
T
Tags 349, 351, 375, 384, 416
Taliban 377
    Dragon agenda 377
Tara 1-20, 27, 30, 33-36, 41, 43, 50-72,87-
94, 99-121, 123-141, 143-
144,148,161,161-183,185-186,
190-192, 195-229, 266, 379, 483
cataclysm 282
cataclysm of 3, 4, 7, 45
future 71
Ivory Gates of 13
Palaidorians of 6, 190
Taran
     Ceres 27
     -Turaneusiam 67
     Wars 4
Target Sites