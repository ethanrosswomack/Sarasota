40 
 
 

                                                                               
                                                                                                             Science of Ascension
within cycles of time designated by the dimensional bands in which they
appear. At certain points in these dimensional time cycles the frequency
bands of one dimension blend into the one above and below, which allows
matter and anti-matter particles to merge, transmute and re-manifest within
the dimensional bands above and below. The particles and anti-particles that
will be able to shift upward, out of their home dimensional band, are those
that have fully assembled the frequency patterns within their home dimen-
sion. During this point in a time cycle the energetic tapestry, or grid, of the
matter-particle planet passes through the grid of its anti-particle double from
the parallel universe, and through this energy fusion certain portions of those
energetic grids transmute, sending a Morphogenetic Wave  into the dimen-
sional band above. The morphogenetic wave then projects its particle and
anti-particle form into manifestation within the new dimension and its
inherent time cycle. The portions of the particles and anti-particles that had
not fully assembled all of the frequency patterns from their home dimension
will not be able to merge, and will thus manifest from the morphogenetic
field back into their home dimension to continue their evolution through
assembling the remaining frequency bands of that dimension.  
      The morphogenetic field of a person exists as part of the larger morpho-
genetic field of the planet, and so when a planet approaches the dimensional
blending point in its time cycle, the people on the planet also reach that
point. People's bodies and consciousness are composed of energy particles, and
when the planet approaches transition and transmutation of some of its particles,
people on the planet will also undergo this particle transmutation . Just as only por-
tions of the planet's particles will be able to transmute and ascend into the
next dimension through the morphogenetic wave, only portions of the
human population will be able to transmute and ride with the planet on that
wave of ascension. People who have fully assembled the third- and fourth-
dimensional frequencies into their DNA (fully assembled the dimensional
frequencies into their third and fourth DNA strand) will be able to ride that
wave of ascension back into Tara's energetic tapestry, which perceptually
constitutes a leap in time. The personal morphogenetic field and conscious-
ness will be carried within the planet's morphogenetic wave, which will
merge with Tara's fourth, fifth and sixth-dimensional particle and anti-parti-
cle structure. The matter particles of the portion of Earth and its people that
were carried in the morphogenetic wave will then re-manifest out of the mor-
phogenetic field into the Second Harmonic Universe frequency bands
(dimensions 4, 5 and 6). These voyagers will find themselves in a new time
cycle, upon a future version of Earth-Tara, whereas the people who did not
catch the morphogenetic wave will continue on in their own First Harmonic
Universe time cycle (dimensions 1, 2 and 3).  
     For many people there will not be enough time between now and the
height of the ascension wave of 2012-2022 AD, to completely assemble the