3                            
                                    
                                                               
                             
                                                          
                               
                                     The Third Seeding                                  
                                    
                                                          THE ARC OF THE COVENANT    
                           Creation of the Arc of the Covenant, Removing the Sph ere of Amenti,      
the Flood, the Andromeda Galaxy, the Sirian-Arcturian Coalition for
     Interplanetary Defense and the lnterdimensional Association of Free  
             Worlds, the Urtites, Serres-Egyptians and the Priesthood of UR.  
                                                   849,000 - 800,000 YA  
      The Sphere of Amenti had been returned to Earth's core by the Elohim,
and the Sirian Council, Seres and Palaidorians of HU-2 about 900,000 years
ago, accelerating assembly of the DNA strands and releasing the Seal of
Palaidor for some strains of the races from the Second Seeding. Some groups
were able to evolve enough to release the Seal of Amenti from their DNA,
which allowed them to ascend through the Halls of Amenti back to Tara. All
was going according to plan until the outbreak of the Thousand Years’ War
850,000 years ago. Following the outbreak and escalation of the war and the
Anunnaki's intentions of destroying the Sphere of Amenti in order to use
humans as a worker race, it was no longer safe to keep the Sphere of  Amenti
within the Earth's core, as Anunnaki operatives could easily discover access to
its D-2 resting place. Under the command of the Breneau and the Ra Confed-
eracy, the Sirian Council of HU-2 assisted the Seres of HU-2 and the Elohim
in once again removing the Sphere of Amenti from the Earth. The Sphere of 
Amenti was removed from the Earth and placed within a secured location about 
849,000 years ago. The Sphere was placed within a planetary core in the
Andromeda galaxy, under high security and held there in exclusion until the
close of the Thousand Years’ War —848,800 years ago.  
       With the implementation of the Treaty of El-Annu, and the threat of the
Anunnaki Resistance, a multidimensional, intergalactic effort was made to
ensure protection for the Sphere of Amenti. The Sirian Council of HU-2
petitioned assistance from numerous star systems in HU-1 and HU-2 to pro-