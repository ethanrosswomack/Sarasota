78 
 

                                                                                         
                                                                                      Dreaming, Ego, and Higher Self
scious astral projection and mental bilocation are also now emerging . For the ear-
lier races, this loss of cognizant dream recall created an extreme sense of
isolation and an over developed focus of consciousness within the external
world. Dream recall was not the only area of human consciousness to be
affected by the Frequency Fence.  
                                         
                                The Ego and the Higher Self         
     Through the mutation in the third DNA strand, which manifested as a
division within the third chakra and mental body level of the bio-energetic
field, a new kind of consciousness developed within the races. As the first
through sixth base tones and 10th-12th overtones were left operational
within the third DNA strand, two aspects of personal mental identity were
brought into manifestation. The conscious mind, or conscious focus of atten-
tion, was divided into two areas that did not consciously associate with each
other. The portions of consciousness that manifested through the first
through sixth base tones of the third DNA strand were focused and could
perceive within the lower vibrating energy fields of the first through sixth
sub-frequency bands of the third dimension. The portions of consciousness
that manifested through the 10th-12th overtones of the third DNA strand
were focused and could perceive within the higher vibrating energy fields of
the l0th-l2th sub frequency bands of the third dimension. The portions of
personal identity manifesting through the lower base tones of the third DNA
strands became the lower self, or what has come to be known as the Ego, and
its perceptions are limited to activity taking place within the lower portions
of the third dimension. The portions of identity manifesting through the
higher overtones of the third DNA strand became the  Higher Self.  The
Higher Self mind could perceive activity taking place within the highest sub-
frequency bands of the third dimension.             
    The lower mind Ego developed an exaggerated sense of dualistic percep-
tion, as it became locked into five-sensory perception. Using only five sensory
perception, extreme distinctions between the inner world of personal iden-
tity and the outer world of manifest reality were perceived, as the cognition
of “where the inside and outside of things meet” was blocked from conscious
perception. The inner and outer realities meet within the morphogenetic
field of the race identity and that of the Earth’s core, where the energetic
inter-relationship between the planet and its people is understood. Through
the race morphogenetic field in the Sphere of Amenti the individual's con-
nection to its race and the purposes for its existence within the greater plan
of evolution can be understood, as the evolutionary plan exists within the
morphogenetic field as an energetic blue print through which identities and
events manifest. The race morphogenetic field also holds the individuated
morphogenetic field for a person, and contains the higher dimensional soul
aspects of consciousness through which the contours of the individual incar-