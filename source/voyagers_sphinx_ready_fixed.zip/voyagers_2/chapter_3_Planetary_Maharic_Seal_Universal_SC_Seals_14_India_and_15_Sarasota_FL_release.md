3 Planetary Maharic Seal. Universal SC Seals #14 India and #15 Sarasota FL release 
in Earth’s Planetary Shields; Mass Indigo DNA Seals #14 and #15 Initiate; Seals begin 
Consummation/Activation November 2003.  
        GA/UIR “Show Down”  for Planetary Templar frequency control Aug 8-20,
2003.  UIR will attempt to "un-Cap" the Falcon-Phoenix Wormholes to orchestrate 
their Dimensional Blend "Experiment " in attempt to draw Earth’s Planetary Shields
into phase-lock with Phantom Matrix; UIR attempt to use all available “Trumpet”
pulse and APIN facilities to prevent success of GA Planetary Protection Plan and 
Freedom Agenda. GA will use Trion/Meajhé Field Buffer Blanket and Inner Earth 
Crystal Pylon Temples/Cue sites to keep grids stable to avoid cataclysm. The Mag-
netic Peak Climax  of Aug 12 will amplify the dominant frequencies in Earth’s grids, 
causing Earth’s Planetary Shields to phase-lock with either the Inner Earth Bridge 
Zone time cycle  or the Phantom Matrix time cycle . If UIR Dimensional Blend
 Experiment succeeds, GA will shift to Plan B Evacuations and UIR will advance 
intended Nov-Dec 2003 “First Contact” invasion drama Phase-1 , mass sighting dem-
onstration and selective Illuminati and Exterior Government administrative con-
tact. UIR forces stationed off planet in our Time Matrix will attempt to use their 
remaining scalar pulse technologies to erode Level-3 Planetary Maharic Seal before it
reaches full critical mass in Earth’s grids and is amplified to a Level-6 Maharic Seal by
GA target date of 2006 . UIR will motivate Illuminati races to use earthly scalar pulse 
and nuclear technologies to further compromise Level-3 Planetary Maharic Seal and 
Trion/Meajhe Field “Buffer Blanket” integrity and to assist UIR in removing Level-3 
D-12 Cap on Falcon-Phoenix Wormholes to reinstate open D-3 Phantom Matrix 
access. UIR "First Contact" invasion date will be expedited to Nov-Dec 2003
 in order to bring cloaked Beam Ships to Earth to take over GA APINs and to sever Plan-
etary Trion/Meajhé Field ''Buffer Blanket" link. The group having critical mass fre-
quency control of Earth’s Templar on Aug 12, 2003  will retain governing control 
over Earth’s Templar during the remainder of the SAC.
 30.  2003 Nov:  Planetary Shields of Earth and Tara will begin to merge via Inner Earth 
 Bridge Zone time cycle, GA activates Hall of Records  in Egypt, Mass Awakening /
 DNA 12-Code Activation cycle re-commences following Sept 11, 2001 UIR Fre-
 quency Fence block  (originally due 2012 May 5).
 31.  2003 Dec:  Inner Earth portals fully open, Halls of Amenti Star Gates  opening cycle
  begins (originally due 2012 May 5 ) and Earth’s Temporary Level-3 Planetary Mah-
  aric Seal begins amplification toward GA intended 2006 acceleration. Earth begins
  entry into Holographic Beam/Photon Belt,  particle base begins polarity reversal and 
544
                 

                                                         
                                                  Expedited Amenti Opening Crisis Intervention Program Begins
Hall of Records begins transmitting through Earth’s grids Dec 21-22, 2003 ( originally      
due 2012 Dec 21 ). GA initiate 12-Code-Pulse realignment/ activation of " Golden       
Eagle " APIN  (“Guardian of the Ley Line Horizontals”), connecting it to fully act-       
ivated “ Great White Lion” APIN  ("Guardian of the Axiatonal Line Verticals") and
"4 Faces of Man "(“Guardian of the Four Corners”)/" Guardians of the 12 Pillars "
 LPIN systems. 12-Code Activation of the Golden Eagle APIN will permanently dis-
abling Necromiton-Andromies’ “White Eagle” APIN Templar Control/Broadcast-      
 ing Grid. GA will attempt to slow organic progressive acceleration of Earth core 
oscillation speed to prevent Earth from entering the Three-Day Particle Conversion  
Period in 2003 , which will create some degree of cataclysmic Earth Changes  if  it
 occurs before the Trion/Meajhé Field  “Buffer Blanket” is sufficiently strengthened. 
The Trion/Meajhé Field will be progressively amplified and the Level-3 Temporary      
Planetary Maharic Seal will be amplified to a Level-6 Temporary Planetary Maharic  
Seal between Dec 2003-June 2006. UIR in this Time Matrix, with limited resources      
and Phantom Matrix “back up” due to Level-3 Wormhole Cap, will continue efforts 
to disengage GA LPIN/APINs and to erode Temporary Level-3 Maharic Seal. If all 
goes well, the Three-Day Particle Conversion Period can be held off until June, poss-
ibly Dec 2006 , giving time for intensive GA RRT  efforts to strengthen the Trion/       
Meajhe Field Buffer Blanket. 
        A greater quantity of Earth’s Planetary Shields, geographical territories and      
populations will progress into Trion/Meajhé Field Buffer Blanket protection if the      
Three-Day Particle Conversion Period can be postponed for as long as possible. 
Emerald Covenant Founders and GA can slow Earth’s accelerated frequency acc-
retion progression to hold off the Three-Day Particle Conversion Period only until     
2006. This can be achieved  only if humanity is willing to assist in Emerald Cove-      
nant RRTs through which the integrity of the Temporary Level-3/Level-6 Plane-      
tary Maharic Seal and Buffer Blanket can be maintained.   With success of the GA      
2003 Temporary Level-3 Planetary Maharic Seal, UIR in this Time Matrix, unable to      
secure ample Phantom Matrix reinforcements due to the Wormhole Cap, will likely      
continue their Templar Conquest efforts via manipulation of Illuminati  forces. Tem-      
porary Level-3 Planetary Maharic Seal will continue to prevent the UIR 2003 “First      
Contact” invasion drama. UIR will likely revert to their original 2005 First Contact      
invasion schedule , or motivate their Illuminati forces to create a  hoax “Fake Land-      
ing”,  if they deem such an event useful to their continuing invasion strategy. After       
2003, UIR efforts will focus upon eroding Earth’s Temporary Level-3/Level-6 Plane-      
tary Maharic Seal and un-Capping the Wormholes to initiate their “First Contact”       
drama by  2005 , for orchestrated pole shift and final invasion between 2008-2011.       
UIR is also expected to intensify their efforts of waging a vicious “ideological war”       
against Emerald Covenant nations via further manipulation of Illuminati and of peo-      
ples within the UFO and New Age Movements and traditional religious dogmas. 
        If UIR compromises the Temporary Level-3/ Level-6 Planetary Maharic Seal 
any time between 2003-2006 , GA will be forced to allow Earth’s core time rhythm
to accelerate on its natural cycle. This will initiate rapid entry into the Three-Day 
Particle Conversion Period  and full Permanent Level-12 Planetary Maharic Seal  
(dimensions 1 through 12 Sealed to D-12 sub-frequency bands) before the Trion/
Meajhé Field Buffer Blanket accretes to global coverage . Areas of Earth not under suf-
ficient Trion/Meajhé Field protection will be unable to hold Permanent Level-12 
Maharic Seal; the intensive frequency infusions characteristic to the Three-Day Part-
icle Conversion Period will cause Earth Changes in unprotected areas. In this event, 
GA will initiate rapid acceleration of D-3 Nethra Phase Merkaba/Level-3 Temporary
Planetary Maharic Seal Safe Zones to D-9 Quatra Phase Merkaba/ Level-9 Temporary 
Planetary Maharic Seal protection. Portions of Earth’s Planetary Shields under Quatra
Phase Merkaba protection will then be shifted into merger with the Trans-Harmonic
Meajhé Zone Time Cycle . The neighboring Time Matrix of the Trans-harmonic 
Meajhé Zone Time Cycle will serve as a frequency buffer and “electromagnetic 
anchoring field” through which Safe Zone areas of the planet can be “hosted” into the 
Inner Earth Bridge Zone Time Continuum by 2012 .     
545                                              
 
                                                                                                                                                                 
                                                                                                                                                      

                       
                  Crisis Intervention Expedited Amenti Opening Schedule
          This is not the most desired scenario , but rather the final "Emergency Contin-
 gency Plan " that will be employed if events in this SAC proceed in a manner any 
 worse than they already have . If unfolding events dictate the necessity of invoking
 the Emergency Contingency Plan, GA will mobilize their earthly Indigo Children 
 Planetary Security Teams to offer regional Meajhé Zone  Evacuation  options, to get as      
 many people as possible into Quatra Phase Merkaba/Meajhé "Safe Zones." If the 
Three-Day Particle Conversion Period is triggered into activation before 2006, the        
Temporary Cap on the Falcon-Phoenix Wormholes will be partially compromised;  
areas with insufficient Trion/Meajhé Field Buffer Blanket protection will be left to       
progressive UIR infiltration and transfer into the Phantom Matrix Sub-T ime Distor-
tion Cycle. If a sufficient number of GA RRTs are conducted to maintain Trion/
Meajhé Field Buffer Blanket integrity, UIR forces will be unable to un-Cap the 
Wormholes, bring in “Mother Ships” for the “First Contact” drama or compromise the      
Temporary Level-3/Level-6 Planetary Maharic Seal in Merkaba “Safe Zone” areas. 
 32.   2003 Dec-2006 June:  GA continues to strengthen Trion/Meajhe Field Buffer Blan-      
        ket. Between Dec 2003-June 2006, Earth enters Level-6 Temporary Planetary Maha-      
        ric Seal  (dimensions 1-2-3-4-5-6 of Earth Sealed to D-12 sub-frequency bands)       
     sustained by 12-Code activation of Inner Earth Crystal Pylon Temples/Earth Cue      
     Sites #1, #2, #3, #4, #5 and #6 . Earth’s SGs and Ley Lines  #1, #2, #3, #4, #5 and       
        #6  will be protected under D-12 Maharic Seal. Temporary Level-6 Planetary Maharic       
     Seal will progressively move Earth and Tara into temporary hyper-dimensional sus-      
        pension of D-6 Planetary Hallah Phase Merkaba Vehicle , creating a temporary                   
        Level-6 D-12 Cap on the Falcon-Phoenix Wormhole. In June 2006, GA will acceler-      
     ate Level-6 Temporary Planetary Maharic Seal/D-6 Planetary Hallah Phase Merkaba      
     to Level-9 Temporary Planetary Maharic Seal/D-9 Planetary Quatra Phase Merkaba.      
     Regions of Earth capable of progressing into 2006 Quatra Phase Merkaba will be       
     fully protected from the physics realities of the 2006 Three-Day Particle Conver-      
     sion Period . If Three-Day Particle Conversion Period occurs before 2006, or if regions      
     cannot hold a Level-9 Temporary Planetary Maharic Seal by 2006, only areas with       
        critical mass Trion/Meajhé Field Buffer Blanket will retain Hallah Phase Merkaba/       
        Level-6 Maharic Seal sufficient to accelerate to Level-9 Temporary Planetary Maharic      
     Seal/ D-9 Planetary Quatra Phase Merkaba. Areas holding D-9 Planetary Quatra       
        Phase Merkaba will fully enter Trion/ Meajhé Field Buffer Blanket protection for       
        Three-Day Particle Conversion Period.
 33.  2006 June : Expedited Three-Day Particle Conversion Period and the 4.25 Trion      
     Buffer Bubble . Sometime between June and Dec 2006, Earth will encounter the       
        Three-Day Particle Conversion Period  (See page 223); fulfillment of the " Night of      
        the Two Moons"  prophecy. Earth will come into full alignment with the Holographic      
     Beam/Photon Belt ( originally due 2017, May 5-June 30 ), while protected within       
        the Trion/Meajhé Field Buffer Blanket. If the Three-Day Particle Conversion Period      
        is successfully postponed until 2006, GA will continue strengthening the Trion/       
        Meajhé Field Buffer Blanket in attempt to pull all of Earth  into D-9 Planetary Qua-      
     tra Phase/Merkaba Vehicle  hyper-dimensional suspension. In June 2006, Earth enters      
      Level-9 Temporary Planetary Maharic Seal  (dimensions 1-9 of Earth Sealed to D-12      
     sub-frequency bands) sustained by 12-Code activation of Inner Earth Crystal Pylon      
        Temples/Earth Cue Sites #1 through #9. Earth’s SGs  and Ley Lines  #1 through #9      
     will be protected under D-12 Maharic Seal, creating a temporary Level-9 D-12 Cap      
     on the Falcon-Phoenix Wormhole.  The Trion/Meajhé Field Buffer Blanket will       
     absorb and collect the frequencies that will release through the final three Stellar                 
        Activations/Stellar Wave Infusions , holding these frequencies in suspension until       
        2012 , when they will be released into Earth’s Planetary Shields in completion of the      
        Arcturian, Orion and Andromeda Activations. As the Three-Day Particle Conver-       
        sion Period approaches, the GA will create a temporary 4.25-dimensional  magnetic      
        field  within the Trion/Meajhe Field Buffer Blanket. The natural Planetary Shields of      
        Earth’s counterpart planet in the neighboring Trans-harmonic Meajhé Time Matrix 
546
                    
                 

                                       
                           Expedited Amenti Opening Crisis Intervention Program Begins
(not the planetary counterparts in THIS or the Inner Earth Time Matrix) will be used        
to accrete and sustain this 4.25-dimensional magnetic field in the Trion/Meahjé Field       
Buffer Blanket. 
        For the Three-Day Particle Conversion Period, during which time Earth’s natu-        
 ral magnetic fields normally collapse, the portions of Earth’s Planetary Shields and        
corresponding geographical regions in Safe Zones will be drawn into full vibrational         
co-resonance with the 4.25-dimensional magnetic fields sustained  in the Buffer Blan-        
 ket. This will allow regions of Earth, and populations, that are able to achieve tempo-        
 rary Quatra Phase Merkaba , to enter the Safe Zone of the 4.25 magnetic field region       
of the Buffer Blanket. The 4.25 magnetic field will create a stable D-4.25 “Energy        
Bubble”  within which the 3-dimensional particle base of Earth and its inhabitants             
 will be protected from the Three-Day Particle Conversion Period frequencies that set         
atomic transmutation in motion. Though the Three-Day Particle Conversion Period       
will commence in 2006, its manifest effects  will be temporarily delayed until 2012  due              
to the “4.25 Trion Buffer Bubble”.  In the original Amenti Ascension schedule, the         
Three-Day Particle Conversion Period was due to take place in 2017, at which time         
regions of Earth that could sustain 4.5 accretion  level would fully transfer into the        
 Inner Earth Bridge Zone Time Continuum. Areas and populations that could not sus-        
 tain 4.5 accretion  (all of 4th DNA Strand and one-half of 5th Strand activation)         
would separate and be drawn into the Phantom Earth/Phantom Matrix Sub-time Dis-         
tortion Cycle. Elements of the “manifest hologram” that “fell to Phantom Earth”             
would literally appear to have “disappeared” from the face of the Earth , to the per-      
ceptions of populations successfully achieving the Bridge Zone Time Cycle Shift. Pres-       
 ently, though posing more inherent risk of failure , the Emergency Crisis        
 Intervention program of the Trion/Meajhé Field Buffer Blanket provides for greater        
opportunities of population protection  not originally possible within the dynamics of        
physics of the Bridge Zone Project. 
         The “4.25 Trion Buffer Bubble” and the Trion/Meajhé Field Buffer Blanket sur-        
rounding it, will allow Earth to pass through the Three-Day Particle Conversion         
Period, through which progressive bi-polarization and separation of the global particle         
field and populations into the Bridge Zone and Phantom Matrix Time Continua will        
 occur.  By the end of 2006  this separation of Time Lines within Earth’s Planetary         
Shields will be permanent . However, the Trion/Meajhé Field Buffer Blanket will oper-          
ate as a " carrier wave field " that will temporarily hold the bi-polarized particle base of       
Earth’s Planetary Shields, time lines and populations together, in a state of slow-mov-       
ing particle suspension  during and for a time after, the Three-Day Particle Conver-       
sion Period. This process of SAC physics is distinctly different from the complete,        
 rapid separation of particle base, time lines and populations  that would have         
occurred during the later 2017 Three-Day Particle Conversion Period. All of Earth’s        
particle base and populations can be protected from falling into Phantom Matrix         
merger, if full Planetary Quatra Phase Merkaba  can be achieved in 2006 .  Popula-         
tions would no longer separate into the Phantom Earth and Bridge Zone Time Con-         
tinua as originally anticipated; all would  "make it to the Bridge Zone " continuum         
out of harms way . This ideal scenario is not likely to occur  due to the continuing         
counter-activities of the UIR; GA will none-the-less strive to achieve this ideal . If         
full Planetary Quatra Phase Merkaba can be achieved in 2006, the UIR invasion plans        
would be brought to a screeching halt as they would have insufficient time, before        
 2011, to compromise a 12-Code seal on nine dimensional levels of Earth-Tara-Gaia         
and their corresponding Time Continua.
       Unfortunately, the GA have insufficient time before 2006, to strengthen the              
Planetary Trion/Meajhé Field Buffer Blanket on a global level and to completely clear       
distortions in Earth’s grids to the degree required, to initiate full D-9 Planetary Quatra        
Phase Merkaba in 2006. Forcing a D-9 Quatra Merkaba on the entire planet in 2006,        
before Planetary Shields distortions were fully aligned with the D-12 Planetary Divine       
Blueprint, would cause pole shift and cataclysm for all.  GA will attempt to prepare         
the entire planet for 2006 D-9 Quatra Merkaba Conversion, but full success in         
this objective is not likely to occur.  Areas of Earth that do not have sufficient critical
547 
 
                                                                                                                                       
                                                                                                                                                                                                                  

                   Crisis Intervention Expedited Amenti Opening Schedule
mass of Trion/Meajhe Field frequency will be unable to hold a Level-9 Temporary       
Planetary Maharic Seal/ D-9 Quatra Merkaba. Such areas will endure progressive      
escalation of UIR/Illuminati OWO advancement, storms, famine, loss of life, quake      
and volcanic activity and political warring, and progressive deterioration of the Level-