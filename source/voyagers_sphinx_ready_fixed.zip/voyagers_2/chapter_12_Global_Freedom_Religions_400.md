12 Global Freedom Religions 400
deception by 423
distortions in 67
Mormon 31
new 173
see also Jewish religion
used as disinformation source 178
Remote Interactive Teams (RITs) 348
remote viewing 347, 348
Reptile-Insectoid Rigelian-Zeta-Zephelium 244
Reptilian 383
Repulsion Zone 165
Rescue Mission
Stage 1 9
Stage2 10
Stage 3 1 1
Stage4 15
Resonant Tone 186, 202
responsibility
     personal 108
resurrection
     see Christs, Three
Revelations 239, 407, 416, 421, 426, 431,
                 461
     Decoding 414
Rigelian Zeta 252, 253
Rigelian-Zeta 383
Rishi 270
RITs, see Remote Interactive Teams
rod 55, 74, 92
and staff, see Blue Flame
Holder 55
Rod and Staff 312, 314, 320, 322
Roman
576                                                                                                                     
                   Index, V olume II
     Empire 324
     lnvasion 323, 330
Root Races 277
Fifth (Aeiran) 20, 22, 23, 24, 28-29
Fifth (Aryan) 56, 78, 82, 84, 85, 98
Fifth (Ayrian) 29, 43-44, 46, 56, 78
Fourth (Alanians) 18, 29
Seventh (Euanjhechi) 43, 84, 195
Seventh (Yunaseti) 38-43
Sixth(Muvarians) 30, 52, 84, 123, 124, 195
Third (Lumarians) 17, 29, 30
Roswell, NM 346
Roundtable 278-289, 325
and King Arthur 310
Rainbow 302
reality of 302
RRT, see Rainbow Roundtable Rite
RRTs 389, 402, 405, 427, 428, 430, 432
Russia 215, 251, 320, 321, 377
S
Sabatoth 91-95
SAC Rebellion 327, 330
SAC, see Stellar Activations Cycle
Sacheon Annu-Melchizedek 320
Sacred Cow 371-372
Sacred Mission of Planetary Guardianship 291
Sacred Planetary Templar Merkaba
                  Mechanics 351
sacri fice 257
safe spaces 179
Saint John the Divine 416
Sakkara 322
Saleane 315
Salem, see Jerusalem
Sananda 99
Satan/Lucifer 422
savior 100
    see also Jesheua-12
Savior Space Brothers 355
Scalar Pulse 359
scalar pulses 375
Scalar Shield 300
Scarab Kings 312, 321
science
     of Creation Mechanics 241
     of Vibrational Mechanics 451
     sacred 245, 255, 298
Sea of Japan 366
Seals