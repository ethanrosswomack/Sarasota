24 Primary 251
teachings, mystical 28
Tel el-Amarna 89, 89-90, 95
teleportation 54, 57, 62, 64, 69, 71, 72, 86
television, programming humans 211
Templar
-Annu 58-68, 72, 82, 84, 89
-Axion Seal 33-36, 94, 97, 105, 134, 218
-Axions 34
Complex Star Gate System 289
Creed and chosen ones 97
Cue Sites 275, 278, 305
-Melchizedeks 98, 101
             see also Cloistered Races
original teachings  68
Seal 83, 85, 88, 98-99, 105, 216
              released from the Annu 87
Signet Site star gates 278
Solar Initiates 3, 4, 33, 45, 58, 59, 67
teachings distorted 68
technology 258
use of torture 65
   Template acceleration 281
    terrorist activity 409
    terrorists 347
    Teura 474
    The Four Horsemen Of The Apocalypse 420    
    Thebes 86, 88, 89, 95                        
  
                        
                                                        

        Index, V olume II
Third Eye of Horus 24
Thoth 260
     -Enki-Zephelium 384
     -Enki-Zephelium-(Zeta) Anunnaki
           collective 244, 258-260
    -Enki-Zeta 376
Thoth-Enki
      Annu-Melchizedek 320
      -Zephelium 256, 320
Thoth-Enki-Zephelium-Anunnaki 321
Thoth-Enki-Zeta Anunnaki 370
thought-forms 153-159
threat 251
Three-Day Particle Conversion Period 343, 388
three-dimensional perception
      illusion of 150
Tiamat 391, 394
Tibet 101, 103, 378
time
acceleration 343
as an illusion 129
continua 118, 146, 288
cycles 110-114, 120, 123, 286, 291
           26,556-year Harmonic 114, 120.
                       131, 199, 202, 239, 461, 471
               4,426-year subcycles 110, 146
ascension 111
mechanics 146-148
Primary Conjunction Points 110
Primary Coordinate Points 1 10
fields 11
illusion of movement 147, 152, 158
-Leap Mechanics 225-229
simultaneous 147
three tracks of 169-184
Track One 169-172
Track Three 176-177
Track Two 172-176
travel 7, 43, 54, 62, 71, 123, 138, 170
vectors 288, 296, 308
wall in 26, 386-397
warp 12           
Tower of Babel 312, 322, 406
Transcendence Day Stand 346
transmutation 170, 205
   of the human body 473
Transmutative Activations 464-466
Trapezium Orion 418
Treaty
of Altair 246-247, 318, 327, 371, 385
of El-Annu 48-51, 57, 58, 100
see also government, Interior
see also Guardians
see also Zeta
treaty
    Pleiadian
                  -Sirian Agreements 380
     Pleiadian-Sirian Agreements 381, 382
Treaty ofA1tair 318, 330. 345
Triadic Codes 274
Tribal Shield 297, 299, 302, 303
    Dynamics 307
Tribulation 252
Trigger Events 336, 337, 377
Trion Field 372
579Trion Pillars 343
Tri-Veca Time Continuum 372
Trumpets 406-419
truth 250
    inner 69
tunnel vision 26
Turaneusiam 1, 2, 4, 7, 8, 9, 10, 12, 18, 27,
                  30, 43, 46, 83, 84, 262. 265, 268
    see also Templar Solar Initiates
    sub-races
 Adami-Kudmon 2
Addami 2
Alania 5
Alanians 2-6, 18
Atoni 2
Azurtan 2
Beli-Kudyem 2
Bra-ha-man 2
Celtos 2
Ceres 3
Ceres-Lumian-Alanian 4
Cerrasz 2
Dhr-ah-me 2
Lumians 2, 3, 6
Luri 2
Melchazedakz 32, 233
Melchizedakz 2
Nezack-tai 2
Trin-i-ten 2
Ur-Tarranates 4-9
Yutaran Turaneusiam 4
Yutarans 2
Tutankhamon, see Pharaoh
Tutankhaton,see Pharaoh
Twelve Tribes 18
   names 303
twin ﬂames 148
U
U.S.S. Eldridge 131
UFO 231, 248, 326
    investigation 336
UHF 61, 62, 72, 74, 88, 92, 96, 100, 104,
109,115,125,133,135,181,193,
207, 495
U1R 250-259, 271, 318, 319. 326. 327, 330,
               335-353, 365, 371. 373-374. 377,
               385, 386, 388-389, 399, 400, 404-
               406, 408-414, 427, 429-430, 432
    Edict of Wa r 335, 337. 338, 339. 371. 433
    only way to stop 328
    Plan 253
    Silent Invasion 410
ULF 133. 162
     phantom electrical pulse 210
Ultraterrestrials (UT) 233
underground bases 251
underground civilizations 5, 32, 44, 45, 55, 56
Underworld 92
Unholy Alliance 359
Unified Field Physics 281
unified fields 16, 24, 40, 112, 128, 147, 149,

           
              
              
                      156, 454
      15-dimensional 464
      of Energy and Consciousness 459
      of the 15-dimensional Universal system 474
United Federation of Planets 412
United Intruder Resistance, see UIR
United Nations 252
Unity Consciousness 69
Unity through Tolerance 411
Universal Christos Divine Blueprint 291
Universal Encryption Key Codes 272, 276, 279
Universal Maharata Current 283, 299
Universal Signet Key 279
Universal Star Gate 245, 246, 247, 254, 256,
                264, 374, 382, 383
Universal Templar Complex 294, 311,
universe
    energy mechanics of 128
    Harmonic 129
              see also HU
Unnatural Disasters 409
unnatural disasters 412
UR 321
Ur 86, 89, 275
   -Antrians, see Cloistered Races
   -Tarranates 6-8, 27, 190
               turn over custody of Earth 191
   Urtite 263
Ur-Tarranates 266
Urtite 263, 269, 280
Urtite-Bi-Cloister Maji 276-277
   Rama 276
Urtite-Tri-Cloister Maji 271, 272
USA 251, 377, 431
    Constitution 361
V
Vale of Pewsey 314, 315, 324
Veca-Code Mechanics 339
Vector Codes 307
Vega-Lyra 279, 360
Vicherus Annu-Melchizedek 320
Vicherus-Sacheon Invasion 311, 320, 330
Victorous, see Merlin
Vietnam 359
Viragi 7
   see also Brigijhidett
viruses 252
   AIDS 252
Visitor Contact, reality of 382
Visitors 25, 43, 45, 85, 199
vortices 62, 73
Earth’s lst (Sedona, AZ) 188
Earth’s 2nd (Jerusalem, Israel) 189
Earth's 3rd (Himalayan Mountains) I91
Earth’s 4th (Giza, Egypt) 62, 73, 142, 203
Earth’s 5th (Machu Picchu, Peru) 212
Earth’s 6th (Caucasus Mountains,
            Russia) 215
Earth’s 7th (Andes Mountains, South
           America) 216
Earth’s smaller, secondary 191
seven primary 227
            closing of 229
V oyagers 43, 169-172
       companion 171
 580Index, V olume II
W
Waco, TX, 413
wars
American Civil War 361
Angelic 264
Centaurian 312, 321, 330
covert global 250
edict of 318, 327
Electric 251, 368
Frequency 347, 379
Grail Quest 311
instigation of 386
instigation of regional 251
Official Edict of 250
on Terrorism 376
on terrorism 410, 416
Orion 246
see also Thousand Years' War
see Electric Wars
see Holy Wars
see Palaidor Resistance
see star wars
see World War
Thousand Years’ 43-49, 50, 60, 271
World War 125, 362
World War II 125, 326. 354, 357, 361, 381
         432
World War III 345. 432
          and bin Laden 377
Washington, DC 359
water
      system contamination 211
Wave Infusion 463
     Blue 209, 213
Blue-black Liquid Light 218, 222
Gold 214, 222
Silver 222
Silver-black Liquid Light 223
six 472
Violet 209, 214, 238
waves 40
       morphogenetic 41
       of Solar Flame 188
weather
    anomalies 114
    modulation 61
    patterns 22, 74
White Eagle 370-385,409
White House 408
Wingmakers 550, 553-555
women
    as breeders of hybrids 46
    subservient to men 46
World
    Fifth 42,, 461
             transition into 462
    First 2, 10. 462
    Fourth 28-29, 462
    Second 10, 462
    Third 17, 18, 462
World Trade Center Disaster, see 2001-                    September 11
World Trade Towers, see WTC
World War III 347
worm holes 7            
wormholes 375, 393, 398, 417             
                                                   
                                     

Index, Volume II                                                                       
A7/L3 Falcon 362
Falcon 375, 409, 427
Falcon partial cap 382
Falcon uncapped 385
into other Time Matrices 395
locations of 357
Phi-Ex 359, 378, 380
Phi-Ex Cap 381, 382
Phoenix 418, 421
Wormwood 245, 327, 375, 387, 415
WTC 408
see also 2001-September 11
Y
Yanas 265, 270, 275
Yani 264
Yu 274, 276
      -Urtite 263
Yucatan 322
Yunasai 453
       Order 371
       see also Central Creative Source
Yunaseti 272 
      see Cloistered Races
      see Root Races, seventh
   Z
Zephelium 83, 123, 317
Zephelium-Zeta 313, 317
Zeta 123, 142-145, 162-183, 253, 317
collective mind 124, 130, 137
-Dracos alliance 123
-Dracos-Anunnaki 347
Frequency Fence 124
Grey-Rigelian (Futczhi) 137, 144
Legion treaties with Guardians 137
most dangerous to humans 137
old agenda 122
      see also agendas
Reticuli, reasons for seeking human DNA 83
Rigelians 257
-Ruled Society 253
Seal 124, 130, 134, 137, 142, 143, 206
Surveillance 326, 330
time travel back to Earth’s present 123
Treaties 317, 354, 378, 426
       and MJ-12 330
Zeta/Illuminati
    sonic scalar pulse testing locations 366
Zeta-Rigelian-Drakonian 366
Zhar Confederacy 7, 233
_____________________________________
Ordering information
V oyagers I, second edition, ISBN 1-893183-24-6, 272 PP
V oyagers II, second edition (paperback)  ISBN- 1-893183-25-4, 592 PP
V oyagers II, second edition (digital)  ISBN- 978-0-692-84552-3, 595 PP
For further information please contact:
ARhAyas Productions LLC
5020 Clark Rd #307
Sarasota
FL 34233
Email: office@arhayas.com
Phone: 941-924-8109
Or visit our website
www.arhayas.com
                   581