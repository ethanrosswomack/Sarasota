30 
 
                                                                               

                                                                      
                                                                             Melchizedek Races
imprint for strands 7-12. They are free of the Seals of Palaidor and Amenti,
and can thus undergo full transmutation of bodily form in order to ascend, if
they are able to fully activate the base tones within their fifth strand. Because
of their advanced genetic package the Melchizedeks are able to pass through
the Blue Flame in the Halls of Amenti and experience teleportation through
the portals into the Taran environment.           
    The Melchizedeks assisted in repairing genetic digression toward the end
of the Second Seeding, becoming one of the Host Matrix families, then
began their race birthing cycle during the Third Seeding. The first wave of
Melchizedeks appeared about 35,000 years ago, the second wave 3,500 years
ago, and the third wave began about 250 years ago and continues today. The
family of the Templar-Melchizedeks established the Essene Brotherhood and
Priesthood of Melchizedek,  a priesthood that still exists on Earth today. The
lineage of the Essenes was one of the 25 families within the Melchizedek
Cloister, descendants of the first wave of the Melchizedek cycle. The
Melchizedeks assisted the Hibiru Cloister of Root Race 5 in repairing genetic
damage at the end of the Second Seeding, then during the Third Seeding the
Templar-Melchizedeks once again intervened, creating a mixed-Cloister race
carrying the genetic codes of both lines, which accelerated the evolutionary
potentials of the Hibiru and Ayrian/Aryan races. This mix-cloister breeding
would later become a major problem for the descendants of this lineage, due
to events that transpired 10,000 years ago during the Third Seeding. The
mix-cloister Hibiru/Melchizedek race became known as the Hebrew  race
during the Second and Third Seedings. The Essenes, Templar-Melchizedeks,
Hebrew and Christian lineages of the Third Seeding, including those of
present day Earth, all carry this genetic advancement. And following the
events of 8,000 BC (10,000 YA) those affiliated with the Templar-
Melchizedeks would also carry forth a great genetic burden.  
   The spiritual in ﬂuence of the Templar-Melchizedeks has touched all of
the major Christian and Jewish persuasions, and they played an instrumental
role in the formation of the modern day Mormon-Christian  faith. The
Melchizedeks are a primary force within the present times on Earth, as they
are now within the third wave of their race birthing cycle. The Melchizedeks
hold within their lineage the promise of ascension, even more so than do the
fifth Ayrian/Aryan and Hibiru races. But not all Melchizedeks presently bear
the same genetic coding. Two primary groups of Melchizedeks have evolved
out of the original Melchizedek Cloister morphogenetic field, the Cloistered
Family of Melchizedek and the Templar-Melchizedeks.  The difference
between their spiritual teachings denotes not only a philosophical prefer-
ence, but also a genetic propensity that came into being 10,000 years ago.
Spiritual teachings that have been either directly or indirectly in ﬂuenced by
the Templar-Melchizedeks will have an distinctly patriarchal slant, often pro-
moting gender subservience, elitist philosophy and subjugation of Earth’s ele-