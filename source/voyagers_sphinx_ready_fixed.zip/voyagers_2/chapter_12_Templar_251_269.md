12 Templar 251, 269
Cycle of the Rounds 281-284, 290, 291, 292,
                  296
    3 key elements 303
D
Dagos, see hybrids
Data
     Summaries 446-450
                 Six Silent Ascension Avatars 446
                  Time Track 1—V oyager Ascension-
                            Tara D-4 Time Cycle 447
                 Time Track 2—Phantom Earth De-
                                    scending Planet-—D-3
                                    Time Cycle 448
                  Time Track 3—Night of the Two
                                    Moons— Bridge Zone
                                    Earth—Agartha—D-3.5
                                    Time Cycle 449
Day of Transcendence, see 2000, January 1
Days of Innocence 423, 424
Dead Sea 313, 322
     Conquest 322, 330
Deane, Ashayana xi, 238, 432
      Closing Statement 1998 234
Death Seal, see Amenti, Seal of
denial 248
Denver, CO 409
Destiny of Sorrow 395
dimensional
      bands 11
      blending periods 110
      Magnetic Peaks 138
Dimensional Blend Experiment 386-396, 
                 405, 408
Dino 265
dinosaurs 44
discrimination
       groundless 84, 85
disinformation 357
distortions 69, 83
        
                                  
                                                
           

Index, Volume II
Divine Blueprint 369, 372
Divine Christiac Blueprint 307
Divine Physics 298
Djoser Invasion 313, 322, 330
DNA 2-26, 28, 38, 50, 62, 78, 83, 87, 123,
                 149-159, 162, 215, 254, 255, 258,
                 270, 272, 296, 466-483
12 dormant codes 477
12-Strand Template 300
3 to 3.5 strand template 257
37-42 Strand 273
4.25-strand sustainable 257
and the personal morphogenetic field 150
Consummation 157
creation of 77
distortion 124
evolution of 109
fastest means of activating Personal 12-Strand
         Template 301
Initiation 157
junk 25
mutations 351
secret about its true nature 158
Signet Codes 289
Spontaneous Mass Activation cycle 404
template 307
Template Bio-Regenesis 243, 257
Template Core 291
Template-Star Gate Correlation 278
transmutation of 93
dogmas 257
     New Age religious 252
     Traditional religious 252
Dolphin People 265
Dominican Republic 390
Dora-Teura
    Matrix 206
Doreadeshi 119, 144, 145
double moon 114
Dove 366, 366-384, 409, 417, 418, 421, 431
Down-grading 27
Dracos 252, 319
Dracos-Zeta Resistance 137, 144, 162, 167,
172, 175, 186, 191, 192, 208, 214,
232, 234, 467
      to appear to be Guardians 178
Dragon 374, 376, 377
Dragon-Moth 244, 317
dragons 255
Drakon 6, 44, 47, 58, 71
Drakonian 250, 252, 317, 321, 322, 325, 327,
                 383
    -Reptilian
               -Insectoid races 243
Dralov 234
dream 151
       distortion of recall 78
       lucid 78
       mass 152
       repression of recall 206
       simultaneous 78
Drueidec 315, 320, 321
Druids 320
dualistic
   perception 79              
duality 25 
567
             dweller on the threshold 35
E
Eagle 367-385, 432
     Golden 370
     White 370
Earth 34, 360
1998 passage into D-4 time cycle 194
as future nuclear waste depository 140
axis tilt 62, 63, 73, 113
chakras, see vortices
changes 140, 143, 166, 168, 173, 181,
        182, 374, 427, 428
              in the USA 173
civilizations lost 73
Current State of Affairs 234
division of populations 176, 181, 187
emergence of new land forms 166, 183
evolution stunted 120
evolves to become Tara 123
future 71
gold for Anunnakis 47
illusion of solidity 147
Inner, see Inner Earth
Phantom 166, 240, 462, 470, 473
possession of 18, 48, 58, 64, 123, 137, 144
quarantine 71, 76, 82, 87, 90, 96, 105
saved by Guardians 1972-1974, 132
Sirian Activation 215
Solar Activation 204
       Heart Star 237
Star Activation 215
vortices 177
Earthlings, see human and Dracos
earthquakes 22, 73, 379
East Asia 56
Easter Island 371-372
Easter Island Heads 371
EBE 173, 178
Eckatic Codes 272
E-Den 2
Eden, Garden of 6
education 37
ego 79-81
   origins of 81
Egypt 36, 56, 60, 62, 71, 88, 103, 313, 320,
                   322
     as resettlement for Atlantis survivors 63
Egyptian 28, 46, 74, 239, 461
     Invasion 330
     mystery schools 15
     Pharaonic line 47
              see also Pharaoh
Egyptian Invasion 321
Eieyani 270, 319, 372
   Massacre 311, 319, 330, 372
Electric Wars 18, 22, 45, 51, 251
      end of 19
electrical
      disruption 182
Elohei-Elohim 242, 369
      Human Guardian race 243
      Oraphim 267
 Elohim 2, 3, 4, 6, 18-27, 34, 43, 46, 50, 55,
57, 59, 62, 66, 69, 75, 76, 83, 87,
91-104, 122, 193,194

                                                                                
 
    
         Eye of 34
EM pulse technology 211
Emerald Covenant 244, 245, 246, 247, 250,
                   252, 254, 257, 265, 271, 275, 315.                                          
                   318, 319, 323, 327, 351
    Christiac Co-evolution peace treaty 241
    Co-Evolution Peace Treaty 368
    Co-evolution Peace Treaty 339, 356
    Co-evolution treaty 242
    Crisis Intervention Plan 257
    Masters Planetary Stewardship Initiative 388
    Peace Treaty 358
    Redemption Contract 346
    Redemption Contracts 375
    teachings 424
 Emerald Order Melchizedek Cloister 371
 emergencies 411
 Emergency Release 241—??
 Encryption Key Codes 275, 278
 End Times 378
      beginning 396
 end times 461
     prophecies avoided 462
enemy 257
energy
    new fuel sources 183
energy vampires 369
Energy/Spiritual Healing Systems 384
England 247, 312, 314, 315, 316, 319, 321,
                324, 367, 429
       Stonehenge 251
Enlil-Odedicron 244
Enoch 245, 246
    Jehovian-Anunnaki collective 244, 245, 256
entity gestalt 7, 197
environmental cleanup 252
equality 85
Essene Divide 314,315,316,323,330
Essenes 323,461
Brotherhood teachings 97
see Cloistered Races
see hybrids, Melchizedek-Hibiru (Hebrew)
ET 18, 22, 43, 45, 62, 68, 233
   visitation to Earth limited to emergency
         intervention 76
Eternal Christos Avatar Identity 297
eternal life
    false 395
etheric
    implant 206
    overtone structures 113
Ethics 351
Ethnic Virus 374
Euiago 146, 148, 155, 161, 199, 461, 465,
                467
Euphrates River 86, 89
Euries 29
Europe 56, 103, 359, 377
Europherites 29
evil
    twin 35
evolution
multidimensional 106
program of human 96
Evolutionary Rounds 291, 295
Excalibur 315
568                            Index, Volume II 
exercises 493-504
    Release Crystallized Thought Patterns 493
Exodus 321, 322
external reality
    as a dream-scape 152
    field 158
F
Faces of Man 371-373
Falcon 366-385, 386-399, 408, 417
Falcon Matrix 354
Fall of Akhenaton 906 BC 330
fall of man, see Tara cataclysm
Fall of Solomon's Temple 330
Fallen Angelic
    Invader Force 401
Fallen Angelic races
    ET 242
    Master 356
Fallen Annu-Elohim collective 253
Fallen Dark Avatar collective 253
Fallen Jehovian-Annu-Elohim collective 245
Fallen Seraphim collective 253
Federation of Planets 252
FEMA 413
fence 342
Field Techniques
    The Maharic Quick Seal 502
     The Maharic Seal 496
Final Con ﬂict 247, 253, 314, 318, 325, 364,
                   365,366-383, 388,401
Fire Codes 477
Fire Letter Sequences 274, 291, 292, 293.
                  297, 299, 302, 303, 307, 312, 319
First Contact 384, 411
Five Cloistered Races, see Cloistered Races
ﬂame
     bearer 54
     blue, see Blue Flame
     double 14
     gold 14
     holder 54, 207
     Keepers 200, 270
                 message to 200
     orange-gold 74, 475
     violet 14, 200, 238, 475
     white-gold 14
Flame Code 299
ﬂood 6,45,51,73.86
     Atlantian 244, 312, 318. 320, 330, 355
     first (5,500,000 YA) 26
     second (849,000 YA) 26
Florida 359, 390, 431
     Dade County 381
     Sarasota 247, 378
     St. Augustine 375
ﬂy-by 178
Forbidden history 241, 261
      motivation for 311
Founders 233, 250, 275
Four Beasts before the Altar/Throne 414
Four Faces of Man 414, 432
Four Horsemen of the Apocalypse 414, 416
France 103, 325
Free Masons 325, 370
Freedom Teachings 424

               
Index Volume II
frequency 342
   bands 8, 22, 41
   fence 75, 80, 88, 123-126, 130-131, 134-
         140, 187, 206, 210, 256
             protection from 174
             quarantine 25, 134, 142, 203
             Zeta 124, 142, 162, 177
   field 92
   patterns 11 
   Seal 349
   transducers 292
Frequency Fence 350, 384, 394, 404, 405
future, how to prepare for 184
G
GA 1, 159, 187, 233, 234, 238
      Final Comments 230
      program for Ascension Cycle Adaptation 470
Gaia 5, 8, 11, 13, 43, 227, 266, 379, 474
    root races
       Hyperborneans 10, 84
       Polarians 10, 84
Gakona, Alaska 404
Galactic
    Core 34
       Federation 28, 62, 137, 187
Galactic Federation 244, 252, 256, 258, 312,
313, 316, 317, 318, 320, 322, 323.
324, 325, 326. 327, 376, 379, 380,
384, 419
Garden of Eden 42
gates of ivory, see pearly gates
genetic 44
     ascendancy of angelic human lineage 262-
            263
     distortions 83
     time codes 11
Genocide Crusades 316
Giza 320
Giza, Egypt 370
Giza, Egypt 374, 376, 396
God
    false 424
    reality of 424
gods
     Aton 89
Jehovah 100
     worlds 43
Golden Eagle 370
government
Allied 125, 130
Interior 131, 172, 209
cover-up tactics 177
message to 172
treaties with Zetas 131, 137
Grail Line 264-269
   Indigo Children 250
Grail Quest 313, 324
gravitation
   reversing 61
Great Cleansing 252
Great Pyramid 320
Greece 101
Grid Spiking Campaign 330
Grim Reaper 422
569grounding codes 30
Gru-AL 378,429
Gru-AL Point 294, 303, 317, 325
Guardian Alliance 241
Guardian commission of human race 31 1
Guardians 2. 9, 22, 46, 51, 56, 57, 66, 73, 75.
76, 105, 121,122, 125, 130, 132,
133,142-145,163-184, 185, 187,
194, 197, 235, 237
appearance of being uncaring 187
intervention 467
of the 12 Pillars 233, 372
treaties of 1982-1984, 137
Guinevere 315, 316
Gulf of Guinea 373
Gulf of Mexico 366, 431
H
HAARP 252, 256, 403-407
Hades 359
Haiti 390
Hall of Records 186, 206-208, 218-221,
             227-229
    closure of 229
Halley, Antarctica 368
Halls of Amenti 245, 253, 254, 271, 313, 352,
360, 395
Halls of Amorea 340
     Passage 372
Haremhab, General 90-95
Harmonic 129
Convergence 187
Magnetic Peaks 138
Merkaba Spin 260
Quadrant 146
Resonance Chamber 62
           see also pyramid
   Resonant Tone 112
harvest 421
Harvesting 375
Hassa Kings 314, 321, 364
Hatshepsut Invasion 323, 330
Hawaii 311,319, 362, 372
    Pearl Harbor 362
Hayes, Anna. see Deane, Ashayana
HD-C 417
HD-Cs 417, 419, 421
heaven 388
Hebrew-Annu-Melchizedek, see Jeshewua-9
Hebrews, see hybrids. Melchizedek-Hibiru
Hell 359
HF 176
Hibiru 364
Hibiru, see Cloistered Races
Hidden Game-board 366
hidden reality mechanics 165
higher self 79, 124
    origins of 81
Hiroshima 362. 363
history
        hidden forbidden 250
        manipulation by Annunaki 312
Hitler 326
Hitler, Adolf 361-??, 361, 364, ??-364
Holographic 
   beam 114-120, 185, 223, 227
   illusions 129

                                                                                           Index Volume II
    inserts 123, 125, 136, 211, 251
                 and the body of Christ 102
Holographic Beam, see Universal Maharata
                   Current
Holy Figure 251
Holy Grail 311
        Quest 362
        Quest for 311, 315
Holy Wars 68
Homo-sapiens-l 390
Horsemen 415, 420, 429
Horus 27
       Third Eye of 24, 27, 28, 51, 65, 93, 102
Hourglass Nebula 418
Hova Body 300
Howland Island 373
HU 129, 146
HU-1 3, 5, 6, 7, 8, 9, 12, 13, 14, 18, 19, 20,
             28, 43, 45
HU-2 1, 2, 5, 7, 8, 12, 17, 18, 20, 27, 28, 34,
             41, 45
HU-3 2, 3, 5, 10, l2, 13, 14, 18, 22, 43
HU-4 2, 12
HU-5 2, 19
human
becoming Guardian species 191
biology 54
carry the Zeta Seal genetic mutation 124
celestial lineage 101
clones 139
dominated by Nephilim 46
early man 45
evolutionary blueprint of 12
extinction 77
extraterrestrial 55
genocide, program of 345, 386
history, re-writing of 312
life span, shortened 312
mortality 205
natural birthrights of 107
responsibility for personal evolution 175
Human Amnesiacs Force 406
Human Greeting Teams 411
Hurricane Andrew 380
     affected by wormhole 381
hurricanes 379
hybrids 139
   Annu-Melchizedeks 55-56, 61-64, 72, 74,
              82-85, 88-91
   Dagos 29
   human-Anunnaki (Annu) 36, 49, 52, 56, 58
             85, 88-99
   human-Atlanian-Anunnaki (Nephilim) 46,
             48, 55, 98
   human-Drakon (Dracos) 44, 49, 55, 58,
             122-123, 131, 137-141, 142-183
                to be banned from Earth 174
  human-ET 21
  human-Sirian (Dagos) 43
  human-Sirian (Kantarian) 27-29, 48, 51, 57
        Federation 28
human-Zeta 123, 125
Marduke-Dramin-Anunnaki-Omicron 245
Melchizedek-Hibiru (Hebrew) 31, 55, 82,
         83, 85, 96-105
Men in Black 245
  570                                                                                                       Nephilim, see human-Atlanian-Anunnaki
Serres-Egyptians 47, 55, 64
Sirian-Anunnaki-Nephilim 47
Urtites 56
women as breeders of 46
Zeta-Dracos (Rutilia) 122, 137, 167, 171,
                            173, 177
           Zeta-human-Aethien (Zionites) 101
Hyksos 322, 324, 356
-Annu-Melchizedek page 323
-Egyptian kings 323
Exodus 330
Invasion 322, 330
Kings 314, 322
Hyperborneans, see Gaia
 Hyperdimensional Cones, see HD-Cs
 hyper-space 111
I
IAFW 51, 60, 69, 104, 233, 256, 264
Ice Age 22, 45
Ihopetohetep 95
Illuminati 252, 312, 324, 339, 354-365, 378,
                400, 408
       Master Plan 2003 386-400
       Sleeper groups 347
       World Management Team 376
        Zeta Treaty agreements 246
illusion 251
imagination 151
Immaculate Conception 99, 100
Imminent Crisis Order 339
incarnation 16
     12 simultaneous 148, 296
     1728 simultaneous 296
     24 transmutations in one body 17
     patterns through races and families 16
Incubation Rite, see Palaidorian birthing
                   contracts
Independence Day 189, 191
Indian Ocean 366
Indigo Children 186, 194-197, 201-203, 213,
250, 264, 269, 272, 273, 276, 297,
318, 327, 368, 372, 378, 385, 386,
393, 431
    birth schedule of 196
    hunting of 384
    Place Holders 196
    rescue missions 388
Indonesia 103
infiltrates 139, 178
Infusion
    Gold Wave 216
    Silver Wave 216
Inner Christos Connection 259
Inner Earth 32, 45, 46, 48, 53, 55,56, 60,61,
65, 72-74, 82, 86, 89-91, 96, 128,
144, 163,166,182, 195,197,225,
252, 269, 271, 324, 330
new passages into 183
Star Gates 278
Time Cycle 388
intelligence 39
Intended Dimensional Blend Time Rip 330
Intended Frequency Fence 330
interbreeding 4, 34, 35, 43, 45, 55, 85, 97

Index Volume II
interdimensional
cloaking 255
transport 73
Interdimensional Association of Free Worlds, see
                 IAFW
Internal Merkaba Mechanics 258
interstellar political drama 241
intervention, when it is permitted 145
Intruders 199, 234
intuition, suppressing of 124
Inyu 264
Iran 56, 378
Iraq 378, 409
Ireland 320
Islamic extremists 377
Israel 322, 346, 378
        Crusade 322, 330
J
Japan 359, 362, 377
Jehovah 100, 369
Jehovian
-Annu-Melchizedeks 322
-Anunnaki 313, 318, 321, 322
Anunnaki 319
Hassa Kings 323
HD-C Seals 420
-Sirius-A  317
         Anunna 244
     -Urantia 320
Jericho 406
Jerusalem 86, 89, 98, 101, 102, 346, 378
Jesheua-12, see Christs, Three
Jesheua-Melchizedek, see Christs, Three
Jeshewua-9, see Christs, Three
Jesus 251
Jesus Christ, see Christs, Three
Jeudi 99
Jewish religion
founding of 98
Kabbalah 98
Joehius 99
John the Baptist 314, 323
Jordan 322
Joseph, father of Jesus 99-100
see also Joehius
Judaism 31
judgment day 36
K
Kabbalah 98
Kantarians, see human-Sirian hybrids
karmic
     debt 153
immunity 153
imprint 153
clearing your 154
how to change your 154
Kathara
     Bio-Spiritual Healing System 257
     Grid 281
Kauai 311, 319
Kauai, Hawaii 372
Keepers
of Records for Earth 26
of the Blue Flame 91-95, 195, 217, 237
571of the Flame 54, 89, 91, 92
of the Keys 304
of the Orange-Gold Flame 195
of the Violet Flame 195, 200, 203
Kee-Ra-ShA Light Currents 299, 306
Keylon 452-461
    Codes 455-461
     Crystal Body 458, 460
Keylonta 451-459
   Codes
                 downloaded into Anna Hayes 236
    science 7, 66, 183, 231, 232, 451-459