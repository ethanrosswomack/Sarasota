60 
  
      

                                                                                             
                                                                                                                       
                                                                                                                              
                                Giza to Atlantis
nine beings of HU-2, who were large, upright, fur-covered felines of advanced
intelligence, were revered as Godlike by the early Anunnaki civilizations,
and the Anunnaki of the Sirian Council paid tribute to this heritage. The
Anunnaki of the Sirian Council drew strength and comfort from their affilia-
tion with the Leonine people, and, by constructing this monument, intended
to show the power of the Anunnaki united and built upon their Leonine
ancestral allies. The symbolic design of the Sphinx was intended to show the
Anunnaki Resistance that they were alone in their conquest and that the
true Anunnaki heritage stood behind the Anunnaki of the Sirian Council. In
practical terms, the Sphinx was constructed to serve as a fortification for the
Inner Earth portal and also as a safe house and library for the storage of sacred
records and texts. It also served the purpose of housing the great energy-
transmitting machines that were charged with UHF fifth-dimensional energy
from the Arc of the Covenant, and the smaller Ankhs which were infused
with energy in a similar fashion.  
     Historically , the larger machines became known as Arcs of the Covenant,
and the true identity of the Arc of the Covenant as being a portal bridge was
lost. But during the time of the original building of the Sphinx the truth of the
Arc of the Covenant was well known, and the objects were understood as tools
which could draw, hold and transmit energy that was drawn, through the Arc
of the Covenant, from the Blue Flame of Amenti that was stored in the
Andromeda galaxy. Both the large and small tools were designed in the shape
of the Ankh, which allowed high frequency energy to be synthesized in specific
ways following the natural laws of interdimensional energy mechanics. The
Ankhs were used to create the Spinx, various pyramids, and other structures as they 
provided the power to reverse gravitional pull and directly affect the particle make-up
and    morphogentic    ﬁelds of   Earth  matter  substance.  They served  as major construc -    
tion tools, weather modulators, healing tools and as interdimensional transit
devices. The original Sphinx served as a protective fortress in which these
devices could be stored and kept out of the hands of the Templar-Annu.  
    The second major construction of the Sirian Council Anunnaki was a
massive pyramid centered directly over the portal opening to the Arc of the
Covenant. This pyramid was originally constructed during the same time
period as the Sphinx, about 48,459 years ago (about 46,459 BC). The recon-
struction of this pyramid, which occurred about 12,550 years ago (10,500 BC)
then again about 11,000 years ago (9,000 BC) is what has come to be known in
modern times as the Great Pyramid of Giza, the Cheops pyramid. This struc-
ture was reconstructed and repaired on numerous occasions. It was designed
and erected by the Anunnaki of the Sirian Council, the Annu-Melchizedeks,
Hebrew, and Serres-Egyptian peoples from that time period. The pyramid was
not constructed to serve as a burial tomb, though much later it was used as