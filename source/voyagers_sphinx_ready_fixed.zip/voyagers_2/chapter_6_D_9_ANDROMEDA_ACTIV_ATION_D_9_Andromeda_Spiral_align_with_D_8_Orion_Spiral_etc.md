6  D-9 ANDROMEDA ACTIV ATION : D-9 Andromeda Spiral align with D-8 Orion Spiral. etc
   DATE : 5/5/2017 - 6/30/2017 day 3 -2017 GAIAN ACTIVATION
   EARTH VORTEX OPENS:  Portals open between morph dimensions 9-15, D-8 M G Core and Earth-Tara-Gaia
   SILVER-BLACK LIQUID LIGHT WAVE INFUSION : day 3-2017 D-10 BT& D-11 OT enter Earth s Core
   DNA : strand # 9 assembles. Silver-Black Star  crystal activates for 12 -24 hours
   EARTH ACCRETION LEVEL : 7 to 8 HUMAN ACCRETION LEVEL : 8 to 9
   ( Phantom Earth and Bridge Zone separation. Ascensions to D-9 +)
                                         _____________________________________________________________________________
      DNA strands will ac tivate only if the strands below have been fully assembled and activated .
       2017: 3-day particle conversion period, Earths particles and populations separate into different time tracks
        2022 Mass Ascension cycle ends.  BT or OT = base tone or over tone frequencies
                                                       ©2002 Ashayana Deane
490 
                                                                                   
                    

                                                
                                                                             Appendix IV
                                                                                                                                
                                                                 
                                                              
                                                                   
                                                            Field Techniques                         
     FIELD TECHNIQUE 1: EXERCISE TO RELEASE CRYSTALLIZED
                        THOUGHT PATTERNS FROM THE DNA
                           AND CELLULAR MEMORY IMPRINT
• By moving the focus of your conscious attention into a slower-moving pul-
     sation pattern, you will be able to release the thought patterns stored with-
     in your cells. When you relax your mental focus and slow your heart and
     breathing rates, your consciousness expands and begins to pulsate faster,
     while the pulsation rhythm of your body’s particles slows. From this
     quickened state of consciousness, you can then consciously shift the par-
     ticle-pulsation speed of your awareness into very slow pulsation rhythms.
• First, you will visualize moving your consciousness through a dark tunnel, with a
bright light at its end (the same effect as in a Near Death Experience, which
occurs for the following reason). Moving into the light represents the
quickening of the particle pulsation rhythm of your consciousness, for
which you are aiming in this exercise. You perceive the “dark tunnel” as
your consciousness moves from its D-4 pulsation rhythm, through  the 90°
shift in angular rotation of particle spin that exists between the D-4 and
D-5 frequency bands, and into the faster pulsation rhythms of D-5 fre-
quency. The “light at the end of the tunnel” represents the collective re-
ality fields of the D-5 frequency bands, (and the D-5 consciousn ess
contained there within), as viewed in condensed form, by consciousness
stationed in lower dimensions. One moves closer to the light as the par-
ticle pulsation rhythm of the consciousness accelerates to the rhythm of
the D-5 frequency bands. The light will appear to take on spherical form,
like a blazing sun, as the consciousness nears the D-5 pulsation rhythm.
One merges with the light when the consciousness has reached D-5 pul-
sation rhythm. This is the process you will encounter after death, but it
can be used consciously while you are still in body, for many different pur-
poses. When you perceive the light you are seeing the fifth dimension.
• Once visualizing yourself in the light, submerge yourself within it and feel that light
         move through every cell in your body, imagine it moving through your DNA.
      This raises the pulsation rhythm of the body’s particles by infusing them
493 
                                                                                                                                                                                                                                           
                                     


    Field Techniques
within the D-5 frequency patterns carried by your accelerated conscious-
ness, bringing what is stored within the cells closer to the range of your
conscious perception. When you view your body from this D-5 state of
consciousness, you will notice areas of the body that appear quite light
filled, and others that appear dark. The dark areas represent parts of the
body in which slower-pulsating particles are stored, the dark areas are the
karmic imprints you seek to release.
•  Next, move your attention into one of the dark areas as fully as possible, feel its
sensations and become aware of the pulsation rhythm of the energy in that inter-
nal space. It will have a distinct feel of rhythm that you can detect if you
move your attention into i t.
• Become aware of the difference between the pulsation rate of your con-
sciousness and that of the dark area, then  consciously slow the pulsation rate
of your consciousness to match that of the dark area. Feel yourself moving
down into the blackness of the dark space, slowing the rhythm of your
consciousness, spreading out, and becoming one with the area. As you
proceed to move your consciousness into the area, you will feel a distinct
sensation of the stopping of expansion. This occurs when your conscious-
ness has fully expanded itself into the morphogenetic field of t hat dark
area thought-form. You have become one with the thought pattern, you
are the pattern. You do not have to identify the contents of the thought
pattern in order to release it, though you may begin to receive ideas, im-
ages or emotional qualities from the thought-form as you proceed through
this exercise. Let the impressions pass by your attention, and keep focused
on the exercise. In merging your awareness with the dark thought-form,
you have moved the station of your consciousness from the D-4 level,
through the D-5 level and down into the frequency bands in which that
thought-form originated. You have entered its source of creation and
merged your identity with that of the identity who created the pattern.
You have become the creator of the thought pattern. Being its creator, you
can now change it.¹
• Once you have become one with the crystallized thought-form, sense the
    shape and boundaries of its energy structure. It will have a form and struc-
    ture of energy that you can “feel out” with your consciousness.
• Feel your awareness expand into every layer of the energy form, as if you are fill-
    ing a balloon with water or a box with sand, until you can feel your con-
    sciousness take up every inch of area within the structure of the thought-
    form. Once you feel completely expanded into the thought-form, begin
    to recreate it.
    ___________________________________
1.      Note : Having the ability to consciously shift your entire awareness into the D-5 level is                  
         an attribute of complete fifth DNA strand assembly and activation, which most humans
         do not yet possess. When you use your present imagination to create the inner experience
         of this merger, you actually accelerate the assembly of strands four and five and rapidly
         increase your accretion level. The more you practice such exercises, the more your aware-
         ness will be able to access the D-5 pulsation rhythm, which will make the D-5 merger pro-                                                                                                                                                        
                    gressively more tangible and “real” in terms of physical perception and embodiment of D-
         5 frequency. Any exercises that mentally “take you into the light" will do this for you.           
494

     Field Technique 1: Exercise to Release Crystallized Thought Patterns
• Call light to yourself. Imagine that you can see light streaming in from a beam
       above you, as if there was a sun positioned above your consciousness.
• Breathe light from that sun, into your consciousness and feel it make the pulsation
rhythm of the thought-form and your consciousness move faster. See the dark
area that is presently “you” become more and more light filled. Begin to
hear the sound pitch of the energy in the thought-form and hear its fre-
quency raise, as more and more light enters the thought-form. Allow the
sound and sensation of expanding light to fill your entire consc iousness,
and continue to draw light in, until you sense a distinct stop to the sensa-
tion of light expanding. The thought-form has now reached its maximum
holding capacity for UHF energy.
• Now, imagine that the sun above you is moving down, into your consciousness
 and the thought-form. When the sun enters the thought-form, the thought-
form explodes and the crystalline energy substance, of which its morpho-
genetic field was made, literally blows apart. The thought-form no longer
exists as a reality within your body or consciousness, its particles of energy
substance have been released. The energetic reality of this process is that
of using inner light (visualizations) to guide UHF sound patterns into a
thought-form morphogenetic field. The UHF sound patterns literally
shatter the energy structure of the thought-form, breaking apart the crys-
tallization of slower-pulsating energy particles, just as certain tones of
sound can cause a glass to shatter in the physical world. Through engaging
in this process, you are literally merging the slower-pulsating crystallized
particles with their anti-particles, through the thought-form of the sun
that you created during the visualization. That “sun” image translates
through your body consciousness as D-5 through D-8 frequency, the fre-
quency bands of transmutation through which particle and anti-particle
merge. When you merge multidimensional particles and anti-particles you
create photons. Through this exercise you have created a burst of photo-
nic energy within the frequency bands in which the thought-form crystal-
lization had been.
• To conclude this exercise , focus upon the image of the sun causing the thought-
 form to explode. Imagine that you can feel this explosion within your body as a
 sudden burst of energy that runs through your cells from the area in the body
 where the dark area had been. Visualize this occurring, and see that the dark area
 is now ﬁlled with radiating light. You may not have to imagine the sensation
 of energy rushing through you at all, for this is the energetic reality of what
 is taking place. The degree to which you can sense this energy release will
   depend upon how sensitized your neurological structure is to higher fre-
    quency energy. This sensitivity will increase the more you engage your
  consciousness in activities such as this exercise. Exercises like this activate
 dormant DNA codes, which program the body to build new neuro-pas-
 sageways and nerve endings. This increases the body’s ability to sense sub-  
   tle energy and expands the perceptual range of consciousness while it is                                        
 focused in the body.  
 
  • As you visualize photonic light running through your body , consciously guide
       that light directly into the DNA, while holding the intention that the body will
       use this energy to accelerate the DNA-building process, under the direction of    
495
                                                                                                                                 
                                                                                                                 

                                                                                                                      
Field Techniques
the soul matrix identity. Visualize minute photonic particles moving into and ad-
hering to your double helix DNA strands, until you perceive all of the light par-
ticles that were released, as merging with your DNA.
• Complete the exercise  by visualizing your consciousness returning into the bright
 light sun, then move your awareness backward through the dark tunnel until it
 is focused in your present moment station of consciousness.
                    FIELD TECHNIQUE 2: THE MAHARIC SEAL
• The teachings of the Guardian Alliance are vested in the Law of One; the
interconnection, and Interdependence , of all dimensions of “reality”...
and the Living God, or Spirit, alive within all things.
• All Guardian Alliance teachings are “state of the art,” and specifically ac-
knowledge the scientific/ energetic foundations of “Oneness,” together
with clear emphasis on the unification of science with Spirit, t he “Chris-
tos Within,” and the absolute association with Esoteric Metaphysical Or-
der.
• The practical purpose of these teachings is to truly free and empower all,
through expanded consciousness and educated enlightenment, through
which reverence, respect, love and co-operative co-creation are fostered
within the Global Community. These perspectives fully embrace geo-
physical planetary healing as an intrinsic consequence of personal align-
ment and expansion.
• The personal-planetary technique given here is a key-stone tool of such im-
portance that it is made freely available to everyone. Like all Temple tech-
niques and tools, the Maharic Seal is grounded firmly in Univers al
Unified Field physics, ancient Merkaba Mechanics and Matter Template
Science (a.k.a. the “Divine Blueprint”).
•These techniques are known as “ Bio-Regenesis Technologies"  which were once
 common knowledge, taught in the Pre-Ancient Mystery Schools of ad-
 vanced human cultures; these were regarded as standard, as well as essen-
 tial, daily practice.
• The Maharic Seal , like all Bio-Regenesis Technologies , implies application of
speciﬁc conscious energy, directed to, and within, the core manifestation
template of the body. This technique directly activates the specific math-
ematical -geometrical relationship within, and between, the  Angelic Hu-
man and the planetary, organic, evolutionary blueprint utilizing the
hydroplasmic frequencies of the 10th, 11th and l2th Dimensional “ Maha-
ra Current .” The Maharic Current was fully re-anchored on this planet for
the first time in about 210,000 years, at the GRU-AL point, Sarasota, FL,
Signet 2 point of the Planetary Templar Grid, on May 5, 2000.
• The Maharic Seal  is a major tool by which the purpose, intention, awareness
   and effect of the Angelic Human  can be significantly accelerated in a gen-
   uine, substantial and high impact fashion.
496

                           
                          Field Techniques
                                    
                             Regular use o f the Maharic Seal will:
• Begin the process of activating the 8th through 12th chakras of the personal
     Kathara Grid;
• Assist the opening of Crystal Seals in the body (which otherwise block
    DNA activation);
• Open the Planetary Bio/Feed Interface within the personal body, enabling
  the body vehicle to become a truly effective tool for lasting, planetary  grid
  and sacred site work;
• Trigger DNA activations which progressively and automatically activate
       the full Merkaba;
• Enable healers to transmit 12D frequency sub-harmonics, providing more
       powerful, longer lasting (often permanent) healing facilitation -free of
       personal and client energetic field distortions;
• Protect users from “disharmonic” energies associated with “channeling,”
       healing, Astral projection, and other means of personal field infiltration;
• Assist Indigo Type III children anchor the higher frequencies which cause
       fractious behavior (administered via parent);
• Amplify the results of spiritually focused activity;
• Harmonize personal & environmental energies;
• Create Morphogenetic Re-patterning , clearing karmic / miasmic imprints                           
   which otherwise block DNA activation (and the attainment of true con-
     sciousness expansion and full embodiment of the "Christos Principle'');
• Realign, revitalize and regenerate all aspects of the physical and subtle body
      systems;
• Trigger activation of 11th and 12th sub-harmonics in every DNA strand
 which assists correction of code reversal and the effects of interaction with
 other code mutated partners;
• Prepare and equip practitioners to receive and hold the increas ing ﬂow of
 higher frequency energies ﬂowing into the Planetary Grids and personal
 morphogenetic fields arising from the intensifying Stellar Activation Cy-
 cle now underway (2000-20l7).
498

                                                        
                                                                          The Personal and Planetary Maharic Shields Chart                                                                                                                
Temporary Maharic Seal Technique Steps
   Short Version of the Maharic Seal™ Bio-field Clearing, Alignment and Pro-
      tection Technique from the Kathara Bio-Spiritual Healing System ™
      Program . For temporary restoration and maintenance of personal Bio-
      Field Integrity and Physical Revitalization.
                                                                                                                                                      
  Prior to use: Read through  the steps and practice the visualizations and their se-
      quence slowly,  for familiarity.
1. Imagine the two-dimensional image of a “Merkaba Star” or six-pointed
        “Star of David,” in the color of Pale Silver, as if the image is drawn on a
  black background on the inside of your forehead. This image represents a
  composite scalar wave pattern Keylontic Symbol Code called the “Hi-
  erophant.” Its color denotes the frequency spectra of the 11th and 12th
  Dimensions, and its form, combined with these color frequencies, repre-
  sents the control code of the l2th dimensional frequency band. It is the
  Key Code to unlock the 12th Dimensional Maharic Shield in the personal
  and planetary scalar grids.
2. Inhale , while visualizing the Hierophant Symbol at the center of the brain,
       in the Pineal Gland.
3. Exhale, while using the exhale breath to firmly move the Hierophant down
        the Central Vertical Body Current (energy current in the center of the
        body), then out between the legs and straight down into the Earth’s core
        (your 13th Chakra).
4. Inhale, while imagining that you can see at Earth’s core a huge, Disc-shaped
         Crystalline Platform of Pale Silver Light that extends outward on a hori-
zontal plane through the entire body of the Earth and out into the atmo-
sphere. Visualize the Hierophant suspended in the center of the disc (this
image represents the Planetary Maharic Shield, the scalar wave grid com-
posed of dimension 10/11/12 frequency, with the Hierophant Key Code
positioned to activate the Planetary Shield.)
5. Exhale,  while pushing your breath outward into the Earth’s Maharic Shield,
          imagining as you exhale that the force of the breath has made the Earth’s
          Maharic Shield begin to spin.
6. Inhale,  using the inhale breath to draw Pale Silver Light from Earth’s spin-
        ning Maharic Shield into the Hierophant positioned at the center of the
        Planetary Shield.
7. Exhale,  using the exhale breath to push the Pale Silver Light throughout the
        entire Hierophant making the Hierophant glow and pulsate with Pale Sil-
        ver Light.
8. Inhale, imagine that the glowing Pale Silver Hierophant momentarily ﬂash-
        es Crimson Red and returns to Pale Silver. Then use the inhale breath to
       draw the Hierophant vertically up from its position at Earth’s core, to a po-
       sition 12" below your feet (the position of your dormant personal Maharic
       Shield scalar-wave grid). As you inhale the Hierophant upward from
       Earth’s core, imagine that it trails a thick cord of Pale Silver Light behind
       it. Qne end of the Silver Cord remains attached to Earth’s core, the other
       attached to the Hierophant (the Cord represents an “Energy Feed Line”  
     499                                                                                                      
                                                                                                 
  
                                                                                                                        

  
Field Techniques
      through which you will draw energy up from the Earth’s Maharic Shield
      into your personal Maharic Shield)
9.   Exhale,  with your attention on the Hierophant positioned 12" below your
      feet and use the exhale breath to push a burst of Pale Silver Light outward
on a horizontal plane from the Hierophant. Imagine that a Disc-shaped,
Crystalline Platform of Pale Silver Light about 4' in diameter, extends on
 a horizontal plane 12" beneath your feet around the Hierophant at its cen-
 ter. (This image represents your personal Maharic Shield.)
10. Inhale,  while using the inhale breath to draw more Pale Silver Light up
   through the Pale Silver Cord from Earth’s Core, into the Hierophant at
   the center of your personal Maharic Shield.
     
11.  Exhale,  using the exhale breath to push the Pale Silver Light from the Hi-
          erophant, out into your Maharic Shield. Imagine that your Maharic
          Shield now pulsates, as it fills with the Pale Silver Light from Earth’s Core.
12.  Inhale,  again drawing more Pale Silver Light up from Earth’s Core through
      the Pale Silver Cord into the Hierophant, and imagine the Pale Silver
      Cord expanding to four feet in width, forming a Pillar of Silver Light run-
      ning up from Earth’s Core directly into your four-foot-diameter Maharic
      Shield.
  13.  Exhale,  again using the exhale breath to push Pale Silver Light from the
        Hierophant outward into your Maharic Shield, while imagining that your
     Maharic Shield “takes on a life of its own,” the disc suddenly “folding
     upward ” with a “ popping ” sensation, to form a 4' diameter pillar of Pale
     Silver Light all around and running through your body.2
 14.  Inhale,  imagining that the inhale breath draws the Pale Silver Light from
      the Pillar encasing the body into every body cell. Sense the tingling feel-
      ing as the Pale Silver Light moves through the physical body.
 15.  Exhale, imagining that you can feel the energy of the Pale Silver Light ex-
       panding into every cell of the body and then outward around the body
       into the Bio-field.
   16.  Breathe naturally for a minute or two, as the feeling of the Pale Silver Light
      moves through you, while sensing the energy presence of the Maharic Seal
      Pale Silver Pillar 4' around your body. The more time you spend breathing
      and sensing the energies, the more dimension 10/11/12 frequency you are
      drawing into your Pillar, which will increase the length of time the Maha-
      ric Seal Pillar will remain in your Bio-field.
 17.  Return your attention to the Hierophant still positioned 12" below your
        feet.
18.  Inhale , using the inhale breath to draw the Hierophant up through your
       Central Vertical Body Current, then out the top of your head (the 7th
       “Crown” Chakra), to a point about 36" above the head (the 14th Chakra).
_______________________
 2.    This is your Maharic  seal, a temporary scalar-wave pillar of dimension 10/11/12 frequency
         light that blocks out disharmonic frequencies from dimensions 1 through 12 and begins to
         realign disharmonic frequencies in your body and bio-fi eld to their original perfect natural
         order.
500
                        
                

                                                             The Personal and Planetary Maharic Shields Chart
19.   Exhale for cefully , using the exhale breath to rapidly expand the Hi-
     erophant outward on a horizontal plane at the 14th Chakra, until the Hi-
     erophant suddenly “disappears” from view, with a mild “popping”
     sensation.
20.  Breathe normally, while visualizing for a moment a brilliant 4' Pale Silver
     Pillar of Light extending from the Earth’s Core upward, fully encasing
     your body and extending far above the head, into Earth’s atmosphere and
     to a single Star of Pale Blue Light far off in deep space. Your Maharic
     Shield is now temporarily activated, and your Maharic Seal Pillar is tem-
     porarily manifest within your Bio-Field. The Maharic Seal will remain in
     your Bio-field anywhere from 20 minutes to 1 hour at first. The more this
     exercise is practiced, the longer the Pillar will remain.
21.   For quick reinforcement of the Maharic Seal, once the full process has
     been run within 24 hours: Simply imagine a spark of Pale Silver Light at
     the Pineal Gland, exhale it rapidly down to Earth’s Core and imagine the
     Earth’s Maharic Shield spinning. Call to mind the Pale Silver Cord and
     inhale the 4' diameter Cord all the way up around you, forming the Pillar,
     attaching it “out in deep space” to the Star of Pale Blue Light.
• The Short Version of this technique provides a “manually created” tempo-
     rary Maharic Seal in your Bio-Field, and requires manual resetting every
     24 hours, with frequent reinforcement during the day. Using and practic-
     ing the full version of this technique, as described in the Kathara Bio-Spir-
     itual Healing SystemTM Level-l  Maharic Recoding Process TM, will
     progressively program the Cellular Memory of the body to hold the Ma-
     haric Seal for prolonged periods of time. With consistent practice of the
     full technique, over an extended period of time, the Maharic Seal will
     function automatically as a permanent fixture within your B io-field.
• In the meantime, the Short Version of this technique, coupled with rein-
     forcement throughout the day, will provide Bio-field protection and gen-
     tle, regenerative Core Template realignmen t for all aspects of the
     physical and Subtle-Energy-Body- systems. It is recommended to use at
     least this Short Version of the Maharic Seal technique prior to ANY en-
     ergy work, “channeling,” or Astral and Dream Projection. It will not only
     provide protection from disharmonic energies; it will also amplify the re-
     sults you desire to gain from these activities.
501 
                                                                                                            

                         
                         Field Techniques
                 FIELD TECHNIQUE 3: THE MAHARIC QUICK SEAL
1.  Work with a 24 pointed, 3 Dimensional Star (Hierophant) and be aware
       that you will be working with beings known as the Breneau Rishi.
2.  Begin by slowing your breathing, as you imagine or visualize a 24 point, 3-
       Dimensional, Hierophant at the Pineal Gland in the center of your brain.
       Visualize the Hierophant surrounded by a Pale Blue Sphere of Light.
(The Blue Sphere serves as a buffer for your readiness to accept the frequencies
       associated with using the 24 pointed Star; the Blue Sphere holds the en-
       ergy for you until your body can handle the energy. If you can handle it,
       the energy will simply pass through the blue sphere).
3. Inhale,  as if you are going to grab the Blue Sphere containing the 24 point
       star located at the Pineal, and on the Exhale move the 24 point star/ Blue
       Sphere, all the way down to Earth’s Core. Try to hear a sound tone as the
       Hierophant/ Sphere hits the Planetary Shields.
4. Inhale  and draw the Hierophant/ sphere up to your Personal Maharic Shield
       12" below your feet. . .and Exhale  while watching the Pale Silver-Blue
       sphere expand out to a large sphere. . .and watch as your Maharic Shield
       pops out as a disc, about 4' in diameter, Pale Silver with a light coating of
       Pale Blue.
5. Bring your attention to the center of your Maharic Shield 12" below your
       feet. . .and Inhale the 24 point Star (only) up into the Heart Chakra. Ex-
       hale , expanding the frequencies of the 24 point Star into the Heart
       Chakra.
6. Inhale  to grab the 24 point Star, and exhale , pushing the Star up into the
       14th Chakra 36" above the head. Imagine that the 24 point Star is spin-
       ning in a clockwise direction in the 14th Chakra. As you do this, try to
       feel/sense the energy around you, just a few inches out from your body.
7. Now, put your attention into your Maharic Shield 12" below your feet, take
       a couple of relaxing breaths and inhale deeply pulling the Pale Silver and
       Blue energy up, as if you are pulling on your Maharic Seal to latch it on to
       your 14th Chakra. Try and feel the sensations just a few inches from your
       body now-feel the difference if you can. This procedure gives you a Quick
       Seal.
8. Now envision the cord of Pale Silver Maharic Light that would normally
       come up with your Shield and focus on the Earth’s Core. Begin drawing
       energy all the way up the 4” diameter cord and into the body.  Inhale  the
       energy up into the Heart Center, and expand it there. Begin to form a Pale
       Silver ball of Maharic frequency.
On each exhale  send your energy down to the Earth’s Core to bring up another
       load of Maharic frequency, up from the Planetary Shields, expand it into
       the Heart center and repeat several times. Notice that the Cord grows
       larger as you do this, expanding from approximately 4" to 6 to 8" diameter,
       until finally it feels like a skin around (as well as wit hin) your body. . .as
       you load your Astral field with Maharic Frequency.    
502                            
                          
                                         

   
                                                                              
                                                                                     Field Technique 4: The Maharata
9. Move your attention to the Pale Silver ball you have created in your Heart
Center,  inhale  and move it up to the 14th Chakra 36" above your head. . .as
you do, feel for the sheath of Maharic Frequency encasing your etheric
body, close to your skin. ɜ
                     
                               FIELD TECHNIQUE 4: THE MAHARATA
                                  Anchoring the Planetary Christos Field
                           The Group Maharic Seal - Building the Um Shaddai Ur
                                    “Pillar of First Cause/ Eckatic Light”
1. One Breath + three
       Breath 1—Visualize Hierophant Symbol Code  at the Pineal Gland.  Inhale,
             then exhale forcefully , moving the Symbol Code down the Central
           Body Current  and into Earth’s core
    Three  breaths —Take 3 full breaths, and on each exhale  push firmly into
               the Symbol Code at the Earth’s core, making the Symbol Code spin,
               and visualize each breath expanding into a huge spinning DISC of
               Pale Silver Light , in the center of the Earth; the disc spins, moving
               faster with each breath.4
2. One Breath—On the next  inhale , draw the spinning Symbol Code up to 12"
        below the feet , visualizing a 4' diameter tube  of Pale Silver Light trailing
        from Earth’s core... following the Symbol Code. Exhale , and push the
        spinning disc of Pale Silver Light  outward, 12" beneath the feet.  This is your
        personal Maharic Shield.
       
       Three breaths —Take 3 breaths, and on each exhale , push the breath out-
             ward into the disc making the disc spin faster.
3. One Breath + three  
      
      Breath l— On the inhale,  draw a large amount of Pale Silver Energy up
     through the tube- from the Earth’s core, and exhale  this energy into the
     Maharic Shield  DISC , 12" beneath your feet. Visualize the disc “pop-
     ping ” into a Vertical Pillar of Pale Silver Light  - completely surrounding,
     and penetrating,  your body; while connecting with the Silver  tube,  to   
     form a large tube/pillar  of Light  extending from the Earth’s core. . .up
     into the Earth’s atmosphere to a pale blue speck of Light at the center
     of the sun; aligns with the Eckatic Level of the Energy Matrix. Visu-
     alize your body as being sealed within  the Silver Pillar - this is your Per-
     sonal Maharic Seal.
        
       Three breaths—Take 3 breaths; on the  inhale  draw energy up from Earth’s
                 core to the 4th Heart Chakra.  On the exhale,  push the breath from the
                 Heart Chakr a into the tube of Pale Silver Light around you; each
                 Breath making the Pillar appear brighter and stronger.___________________________________________________________
3.       This Maharic/ Christos skin charges and saturates your etheric body. Try to feel the peace-
          fulness and all-knowing nature of this frequency.
4.       This is the Earth’s Maharic Shield—the Shield of Aramatena.
503

  Field Techniques
3. One breath —Take a slow, full, inhale  drawing a thick current of energy up
from Earth’s core to the Heart Chakra . Then, exhale sharply, directing the
breath energy to a point at the center of the group circle.5 As you exhale , vi-
sualize your Pillar replicating . One Pillar remains around you,6 and another
replica  expands outward around the entire group. Visualize a large Silver
disc growing  out from the group center point , 12 ” beneath the surface you are
standing on , forming a platform upon  which the group stands. This is the
group Maharic Shield, through  which the Um Shaddai Ur Pillar will electro
  magnetically ground into Earth’s Maharic Shield.
  4. Three breaths : Take three final breaths, and with each one, inhale and visu
          alize a stream of Pale Silver energy coming up through the feet from
          earth’s core and simultaneously down from the Sun through the top of the
          head. . .the two streams of energy meeting to form one thick Silver stream
         at the Heart Chakra. Exhale  Maharic frequency into the group center
         point.
    After the third energizing breath, simply breathe normally, as each exhale
moves energy into the group center point. Stand with the group for a
few moments and visualize the Um Shaddai Ur Pillar of Light emanat
ing from the Sun, through the group Pillar and group Maharic
Shield. . .and into the Earth core Maharic Shield
___________________________
5.      Or into focus object , if one is used.
6.      This is your Personal Field Seal.
504

                                                                                                                                                                     
 2001 Update Summary Charts
                         
           Crisis Intervention Expedited Amenti Opening Schedule 2000-2012
                                            Summary Chart (3 Pages)
Abbreviations Key: SAC = Stellar Activations Cycle. GA= Guardian Alliance. UlR= United lntruder Resistance. NDC-Grid=  Nibiruian Diodic 
Crystal Grid. NCT-Bases = Nibiruian Crystal Temple Bases. PSC Seals = Planetary Star Crystal Seals.
J-Seals = 7 unnatural Planetary Jehovian Seal implants. J-DNA Seals  = 7 unnatural Jehovian implants that manifest in the DNA with J-Seal 
release. APlN = Atlantian Pylon Implant Network global ''microchip'' grid. LPlN= Lemurian Pylon Implant Network global ''microchip'' grid. RRT=
''Rainbow Roundtable'' Masters Planetary Templar Merkaba Mechanics.
1992 November : Anunnaki reluctantly enter Pleiadian-Sirian Agreements, give up OWO agenda fearing Drakonian
OWO defeat, enter Emerald Covenant, promise to assist Founders Christos Realignment Mission; Founders
postpone Christos Realignment date from 2012 to end of continuum cycle 4230AD to give Anunnaki races time for
DNA Bio-Regenesis.
2000 January 1 : FL Shields Clinics,  Transcendence Day successful, Stellar Bridge Grounds 12-Code. Anunnaki
negate 1992 Emerald Covenant Pleiadian-Sirian Agreements for OW0 agenda.
2000 March:  Egypt Shields Clinic , D-8 Seal of Orion Templar Security Seal released.
2000 May 5:  FL Shields Clinic,  Solar Spiral Alignment, Earth enters Solar Activation, Planetary Templar begins 12-
Code activation.
2000 July 5:  Anunnaki reluctantly reenter GA Pleiadian-Sirian Agreements/ Treaty of Altair  fearing Drakonian or
Emerald Covenant victory.
2000 August : Macchu Picchu Peru Shields Clinic  Anunnaki reluctantly begin agreed Solar SG-4 transfer to
Eieyani-GA.
2000 September 12:  Anunnaki break Treaty of Altair, join United Intruder Resistance (UIR)  OW0 War Edict with
Necromiton-Andromies/Drakonians, attack indigo Templar Security Team, sabotage agreed NDC-Grid GA transfer
Stonehenge England.
2000 September-2001 April : GA War Crisis Order, revelation of Atlantian Conspiracy Agenda, institute early RRT
plan; return agenda to original ''Christos Realignment Mission'' December 21, 2012. Begin Emergency intervention.
2001 May : RRT Kauai Hawaii  GA Crisis Intervention; SG-6 Sirius B/Halls of Amorea opened. NCT-Base Kauai
realigned. PSC Seals #1/ #2, J-Seals #1 ''White Horseman''/ #2 ‘Red Horseman‘ release, DNA Seals #1/ #2,
J-DNA Seals #1/#2 Initiate.
2001 July:  RRT Ireland  Cue-Site-11 realigned, Star Gate-11 activates, 11:11 clearing starts. RRT England  GA NDC-
Grid Nibiruian Wormwood-Stonehenge link severed, NCT-Bases England, Iran, Pakistan  realigned. PSC Seal #3,
J-Seal #3 “Black Horseman‘ release, DNA Seal #3, J-DNA Seal #3 Initiate.
2001 August:  Mass DNA 12-Code Awakening Initiates (originally 2012 May 5).UlR expedites OWO/Frequency
Fence. Eieyani Reserve Intervention Program initiated ; 720,000 Eieyani Indigos adult Walk-ins  due by
December 2002. PSC Seals # 1/ #2, DNA Seals #1/ #2, J. Seals #1/#2 Consummate/Activate.
2001 September 1 : First Team of indigo Eieyani Reserve Walk-ins to Earth via Halls of Amorea/ Sirius B SG-6
2001 September 3:  GA complete Giza/Alcyone Spiral alignment ( originally 2001 September 17 ). Blue Wave
infusion  D5/D6 activates Earth Core ( originally 2002 June ). RRT Sarasota FL  GA start Trion/Meajhe Field via Bi-
Veca/Tri-Veca Codes. NCT-Bases Sarasota FL, Bermuda  partially realigned, UIR Psycho-tronic attack. PSC Seal
#4 releases, DNA Seal #4 initiates.
2001 September 11 : UIR launches ''Trumpet'' Phantom Pulse; Dove/Phoenix/Serpent APlNs ''on line'' with Falcon
Wormhole. UIR Frequency Fence/ Psycho-tronic Pulse Program transmits. WTC/Pentagon Disaster Trigger Event
OWO WW3 agenda. UIR expedited Frequency Fence begins transmitting September 12, 2001.
2001 October;  UlR ampliﬁes Frequency Fence/ Psychotronics. RRT PA;  GA ampliﬁes Trion/Meajhe Field Level-1
“4 Faces of Man” LPlN  via Khu-Veca Code, blocks United Resistance remote Philadelphia APIN site activation.
2001 October end: GA Level-2 “4 Faces of Man” LPIN , via Dha-Veca Code. PSC Seal # 3, DNA Seal #3, J-Seal/J-
DNA Seal #3 Consummate/Activate.
2001 November:  Blue Wave infusions D5/D6 grid accelerations start; RRT Sarasota FL , GA Level-3 ''4 Faces of
Man'' LPlN Blue Wave activation  via Rha-Veca Code. NCT-Bases Sarasota FL, Bermuda  fully realign.
2001 December:  Alcyone Spiral aligns with Earth, Pleiadian Activation  begins, Vortex/Star Gate-5  Macchu Picchu
starts opening cycle ( originally 2004 June ). Veca Code NYC Trion Field Link indigo Outreach Program.
                                                                                                   ©2002 Ashayana Deane
                                  510
                                                            
             
                                                                                  

                                                                                                         2001 Update Summary Charts
2001 December end : RRT Macchu Picchu Peru , GA anchor Trion/Meajhe Field to Vortice/StarGate-5 , Level-4 "4
Faces of Man" LPIN.  PSC Seal # 4, DNA Seal #4 Consummate/Activate. PSC Seals #5/ #6/ #7, DNA Seals #5/ #6/
#7 Initiate. NCT-Bases Machu Picchu Peru , Portugal  realign.
2002 January:  Blue Wave Infusion complete, Violet Wave Infusion  D6/D7 activates Earth Core (originally 2006
June ). RRTs Lake Titicaca Peru , GA anchor Trion/Meajhe Field to Vortice/StarGate-7 Level-5 "4 Faces of Man ''
LPlN . UlR Trumpet Pulse Falcon-Phoenix Wormhole merger  attempt. NCT-Bases Lake Titicaca Peru, Giza
Egypt, South Pole, Mauritania West Africa realign . PSC Seals #8/ #9, J-Seals #4 ''Pale Horsemen''/#5 release;
DNA Seals #7#8, J-DNA Seals #4/ #5 initiate.
2002 April:  Violet Wave infusions D6/D7 grid accelerations start. RRT Sarasota FL, GA Level-5 "4 Faces of
Man" LPIN Violet Wave activation  amplify Trion/Meajhe Field. PSC Seals # 5/ #6/ #7, DNA Seals #5/ #6! #7
Consummate/Activate early April. PSC Seals #8/ #9, J-Seals #4 ‘Pale Horsemen‘/ #5, DNA Seals #8/ #9 and
J- DNA Seals #4/ #5 Consummate/Activate mid April.
2002 May-June : Sirian Spiral aligns with Earth, Sirian Activatio n begins, Vortex/Star Gate-6 Russia begins
opening cycle (originally 2008 June ). RRTs Paxos Greece, GA Level-7 "4 Faces of Man" LPlN activation,  link
Earth's ''4 Faces of Man'' LPIN to '' Guardians of the 12 Pillars " Trion Field, realign/ activate Cue Sites . NCT-
Bases Paxos Greece, Central Mexico, Cyprus, Easter Island, Rome ltaly, Johannesburg South Africa, Brazil
realign. Inner Earth to Earth portals and Meajhe Zone sites  begin open cycle. Begins Earth to Inner Earth Bridge
Zone and Trans-Harmonic Meajhe Time Cycle  merger.
2002 July:  RRTs Bermuda and Sarasota FL , GA Level-8 "4 Faces of Man" LPIN , amplify Trion/Meajhe Field
''Buffer Blanket'' and begin Falcon/ Phoenix Wormholes / Intruder APlNs CAP  lo stop UIR 2003 invasion.
Expected UIR ''Phantom Pulse" assaults  attempt to prevent Wormhole Capping; potential excessive storm
activity Atlantic Ocean/Gulf of Mexico.
2002 August-September:  Violet Wave Infusion completes, Gold Wave infusion  D7/D8 activates Earth Core
(originally 2010 June). RRTs Tibet and Sarasota FL , GA Level-9 "4 Faces of Man '' LPlN , NCT-Bases Lhasa
Tibet, Xian China, Hamandan Iran  realign. PSC Seals #10/ #11/# 12, J-Seals # 6 ''great quake''/ #7 ''Golden censer-
7Angels-7 Trumpets" release. DNA Seals #10/ #11/ #12, J-DNA Seals #6! #7 initiate J-Seal # 6 possible quakes
Peru/Chile. UIR Jehovian ''Chosen One" Frequency Fence transmission Pineal Block.
2002 November-December:  Earth‘s Vortex /Star Gate-7  begins open cycle ( originally 2012 January).  Gold Wave
infusions start  D7/D8 grid accelerations . RRTs France and Sarasota FL,  GA Level-10 "4 Faces of Man" LPlN ,
SG-12 France begins open cycle, starts D-12 Planetary Maharic Shield  protection. Last NCT-Bases Iraq, Bosnia
realign. Galactic SC Seal #13 release; indigo DNA Seal #13 Initiates. PSC Seals # 10/ #11/ #12, DNA Seals #10/
#11/ #12, J-Seals # 6/ #7 Consummate/Activate. UlR Trapezium Orion/HAARP pulse attempt to destroy SG-12 ;
''Golden Cense '' Revelation . 720,000 Eieyani-indigo Reserve Team  Walk-ins complete by 2002 end.
2003 January : Meajhe Zone sites  fully open, GA advance private contacts, continue amplifying Trion/Meajhe
Field/Bridge Zone link/Planetary Maharic Seal. GA programs  shift to prep of indigo MC Regent Consulate Team for
DNA Activations/ ''Safe Zones"/ early 3-Day Particle Conversion Period . Rebel Omicron-Drakonian Illuminati
escalate external political warfare.
2003 March : Planetary-Galactic SC-Seal #13, indigo DNA Seal #13 Consummate/Activate.
2003 April:  RRTs various, GA Level-11 "4 Faces of Man" LPIN, ''Great White Lion" APIN  start, efforts to balance
grids to lessen storm/ quake/ volcanic potentials, World Peace Efforts .
2003 May-July:  GA amplify Great White Lion APlN, ﬁnal prep for August 2003 Show Down. UlR ''UFO activity''
increase prep for intended late 2003 ''First Contact''; Frequency Fence/ Psycho-tronic attack amplify, ''Un-natural
Disaster'' population reduction. Increased Nuclear War issues  potential involving India. UIR ''Human Greeting
Teams '' contact, ''ET in ﬁltrate'' placed.
                                                             
                                                                                           ©2002 Ashayana Deane
                             511 
                                                                                                                                                                                                          
                                                                                                                                                                                                            
    

2001 Update Summary Charts
2003 August 8-20 : Earth's Merkaba 100-year Magnetic Peak August 12, 2003 . The GA /UIR ''Show Down''
August 8-20. RRTs India and Sarasota FL , GA Level-12  "4 Faces of Man " LPIN,  realigned NDC-Grid/24 NCT-
Bases to phase-lock Earth/ Bridge Zone,  Guardians of the 12 Pillars link to Meajhe Time Cycle via ''Rainbow Ray "
Pillars.  Earth LEVEL-3 D-12 Planetary Maharic Seal,  SG/ Ley Lines #1/#2/ #3 D3 Nethra Phase Merkaba
protection, Level-3 Falcon-Phoenix Wormholes Cap. Universal SC Seals #14 /#15 release. Indigo DNA Seals #14/
#15 Initiate. UIR Dimensional Blend Experiment  attempt to un-Cap‘ Wormholes, merge Earth/Phantom Matrix,
erode Level-3 Maharic Seal before Level-6 ampli ﬁcation. Level-3 Maharic Seal prevents UlR 2003 First Contact
Mother-ship entry, reschedule 2005 for 2008-2011 ﬁnal invasion.
2003 November : Earth/ Tara grids begin merger via Inner Earth Bridge Zone, GA activate Hall of Records  Egypt,
Mass Awakening/DNA 12-Code Activation re-commences alter September 12, 2001 block ( originally 2012 May 5 ).
2003 December : Inner Earth portals full open,  Amenti SG  open begins ( originally 2012 May 5 ). December 21-22,
2003,Earth begins Holographic Beam  entry, Hall of Records begins transmit ( originally 2012 December 21 ). GA
activates '' Golden Eag le'' APIN,  connect to ''Great White Lion''  APIN/ ''4 Faces of Man'' LPIN, disables Necromiton-
Andromies ''White Eagle'' APlN. GA slow Earth core to postpone 3-Day Particle  Conversion Period to 2006.  UlR
intensiﬁes New Age/UFO/ Religious manipulation " ideological war".
2003 December-2006 June:  Earth progresses to LEVEL-6 Planetary Maharic Seal,  SG/ Ley Lines #1-#6 D-6
Hallah Phase Merkaba  protection in preparation for 2006. GA " Emergency Contingency Plan"  Level-12 Maharic
Seal to prevent cataclysm if Particle Conversion Period occurs before 2006. If UlR OWO invasion 2005, GA issue
Level-9 Maharic Seal in areas that can hold D-9 Quatra Phase Merkaba protection.
2006 June:  Earth to LEVEL-9 Planetary Maharic Seal,  SG/ Ley Lines #1-#9 D-9 Quatra Phase Merkaba
protection. GA attempt Quatra Phase Merkaba for entire planet but not likely. Between June-December 2006, 3-Day
Particle Conversion Period  (Re: Chapter 11); ''Night of the Two Moons'' Earth/ Holographic Beam full alignment
(originally 2017, May 5-June 30 ). "Meajhe Zones " in temporary 4.25-D magnetic ﬁeld/ D-9 Quatra Phase
Merkaba  full protection/stable, ‘ Trion Zones”  in D-6 Hallah Phase Merkaba partial protection/ less stable;
Trion/Meajhe Field Buffer Blanket suspends Arcturian/ Orion/ Andromeda Activations frequencies to 2012.
2006-2012 : Earth remains in Meajhe Zone -Quatra Phase Merkaba/ Trion Zone -Hallah Phase Merkaba protective
Bi-Polar Suspension  to 2012 when ﬁnal  time line separation  of Meajhe Zone /Bridge Zone and Trion Zone
/Phantom Matrix  occurs. GA '' Last Call '' for Illuminati and Human Bridge Zone Emerald Covenant Amnesty/
Redemption Contracts .
2011;  UIR attempt OWO invasion/Pole Shift agenda last 3-4 month "window of opportunity'' as Meajhe Zone
Quatra Phase Merkaba slows to complete Bridge Zone shift starting April-July 2011. ''Wlngmakers " Labyrinth
Group tricked by UIR Necromiton-Andromie-Anunnaki hybrid Nephilim ''Corteum '' to build UlR '' BeaST Pulse ''
weapon. UIR intend to use 2011 BeaST Pulse  and Trumpet Pulse to reactivate 7 Jehovian Seals, uncap/ merge
Falcon-Phoenix Wormholes and rip Earth's Planetary Shields apart to merge past-present-future Phantom Earth to
Earth in 2011 . 6520AD-GA's Wingmakers  site holds Founders‘ ''Trump Card" Signet Shield-6;  GA block BeaST
Pulse, prevent 2011 Final Conﬂict drama UIR invasion.
2012 December ; Early December 2012, suspended D7/D8 Gold Wave infusion/ Arcturian Activation , D8/D9 Sliver
Wave infusion/Orion Activation  and D9/D10 Blue-Black Liquid Light Wave Infusion/ Andromeda Activation
frequencies release in Earth grids (originally 2017).  Earth Meajhe Zones remain in 4.25-D Quatra Phase Merkaba
ﬁnal Bridge Zone merger. Trion Zones localized Earth Changes mark passage to Phantom Matrix time line merger.
Earth's Bi-polarized Meajhe Zones/Trion Zones in Trion/Meajhe Field Butler Blanket suspension ﬁnal time line
separation.
December 21, 2012:  Christos Realignment Mission fulﬁlls on Founder's original sch edule of December 21, 2012 due
to Anunnaki detection to UIR; date was set 22,326BC . Earth/lnner Earth/Trans-Harmonic Meajhe Time Matrix
Universal SG-12 SC Seals release, fully link three Time Matrixes. Final 3 ''Christos'' Stellar Wave Infusions/ Lyran
Stellar Activations ; D10/D11 Silver-Black  Liquid Light Infusion/D-10 Lyra-Vega Activation , D11/D12 Pale Silver
Maharata ''Christos'' Liquid Light Infusion/D-11 Lyra- Aveyon Activation , D12/D-15 ''Rainbow Ray" infusion/D-12
Lyra-Aramatena Activation . Earth-Tara-Gaia/Universal '' Christos Divine Blueprint " anchors, P ermanent Level-12
Planetary Maharic Seal /D-12 Mahunta Phase Merkaba , Halls of Amenti/Earth's SGs permanently open , our Time
Matrix/Phantom Matrix permanently severed. Real Age of Enlightenment begins. Mass GA Contact Eieyani/Sinus B
Maharaji/Azurites/Aethien/Serres 2017 .
                                                                   ©2002 Ashayana Deane
512

             
2001 Update Summary Charts
            Progression of Intruder APIN Templar Conquest -Atlantis to 2001
                                         Summary Chart (4 Page)
                    APIN Earth Beginnings : Advanced “Crystalline Micro-chip” Technologies of the ancient Atlantian and Lemurian
                                         APIN (Atlantian Pylon Implant Network) and LPIN (Lemurian Pylon Implant Network) systems
                                                 were implanted in Earth’ s Template during various periods of Atlantis/Lemuria
• 5.5 Million Years Ago : Elohei-Elohim Leonines (Anuhazi) and Seraphei-Seraphim Avians (Cerez-Serres) create          
“Wall in Time” Earth/Phantom Earth barrier, Great White Lion  and Golden Eagle APINs  to hold Earth’s Planetary     
Shields together and prevent Earth’s Phantom Matrix descent after Electric Wars . Founders install 24 NCT-Bases  
          (Nibiruian Crystal Temple Bases) Nibiru interface link 3 million years ago  when Nibiru became Emerald Covenant                
         planet. APIN and NCT-Base conquest battles frequent throughout Angelic Human Seedings 2 and 3. “Lion” APIN       
         shut down by Intruder Omicron-Drakonians in 208,216BC  SAC Fall of Brenaui. Anu Occupation 148,000BC-      
         75,000BC , Nibiruian Anunnaki takeover 24 NCT-Bases, Humans underground exile.
• 75,500BC : Omicron-Drakonian/Odedicron-Reptilian races create '' Dragon '' APIN  in Templar Quest campaign.     
Anunnaki, attempt Inner Earth takeover, Anu Occupation dominion prevented in 75,000BC via Inner Earth Rebellion.      
Pacific Continent ''Lemuria'' destroyed 50,000BC  Jehovian-Anunnaki Templar quest, Arc of the Covenant passage     
relocated from Atlantis to Giza, Egypt. GA, with Emerald Covenant Anunnaki build Mars Base  and 1st Sphinx/Giza     
Great Pyramid  teleport station in 46,459 . Atlantic Continent reduced to islands, Sphinx/Pyramid-1 damaged, natural     
Sirius B alignment severed 28,000 BC  Anunnaki/Illuminati Templar quest. 
• 25,500 BC : Lucifer Rebellion . Pleiadian, Nibiruian and Alpha Centauri ''Luciferian'' Anunnaki Intruder races unite;     
bring NDC-Grid  (Nibiruian Diodic Crystal Grid)/ Battlestar Wormwood Stonehenge link, NET (Nibiruian Electro-     
static Transduction field) '' Checkerboard Matrix '' grid control/DNA mutation technologies to Atlantis for Earth     
Templar dominion.  Nibiruian Anunnaki seize control of Solar SG-4 , and partial control of Giza Pyramid  Earth SG-4.