4   D-7 ARCTURIAN -  CORE STAR - ACTIV ATION : D-7 Arcturian Spiral Aligns 2017 day-1 Holographic Beam
.     DATES A V AILABLE FOR ACTIV ATION  2017 day-1 through day-3 (between 5/5/2017 - 6/30/2017)
      STAR CRYSTAL SEAL ACTIV ATES . # 9 D-8/D-9  SILVER STAR CRYSTAL , above navel
      RELEASES STAR CRYSTAL SEAL  #6 D-5/D-6 Indigo Star Crystal Seal opens
      DNA  Strand 7 assembles, activates day-2, 6 activates  Fire Code : strands 5-6 activate ACCRETION LEVEL :6 to 7
       CHAKRAS  draw frequency from Arcturian Spiral through chakras 8 & 9 then into Silver Star Crystal Seal above
      navel
      Silver Wave Infusions  of D-8/D-9 frequency begin at Silver Star one-half activation
                                        _______________________________________________________________________________________ _