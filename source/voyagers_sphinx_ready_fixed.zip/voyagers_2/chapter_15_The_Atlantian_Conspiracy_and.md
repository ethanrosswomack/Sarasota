15
                          
                       
                     The Atlantian Conspiracy and
                                    Roundtables
                                        LONG-TERM PROBLEMS AND IMMEDIATE SOLUTIONS
                                          
                                              Rainbow Roundtables
 • The Sacred Science Mechanics  by which the Planetary Christos Realign-
        ment can be fulfilled have long been hidden within the Legends of King
         Arthur  and the '' Knights of the Roundtable. ''
 • The '' Roundtable '' of Arthurian Legend referred to Signet Councils . The
        word “Signet” refers to '' Star Gates .'' In the ancient knowledge of the
        Palaidia Urtite-Cloister races, the Signet Councils were the specific
          groups of Angelic Humans  that assembled to  run the corrected Fire Let-
        ter Sequences into Earth’s  Planetary Shields  during SACs,  to prevent
        pole shift and progressively restore  Earth’s D-12 Christos Divine Blue-
           print (the Shield of Aramatena).
 • The “Roundtable” of Arthurian Legend referred to the “Rainbow Round-
        table” (RRT) . The RRTs are groups of Angelic Humans assembled in the