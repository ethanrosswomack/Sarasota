12 Maharic Shield  and the D-12 Species Tribal Shields , through which
            our consciousness manifests in time.  
    • The secrets to reclaiming the Divine Birthrights and Responsibilities  of
        Angelic Human heritage are hidden within the realities of the Tribal
          Shield and  the specific '' Fire Letter Sequence''  of the Tribal Shield that
         manifest within and govern the function  of the Angelic Human D NA
           Template .                                                                                            
     
     
     
      297  
                                                                                                                                                 

                                           
                     
                   The Angelic Human Heritage and Rainbow Roundtables
                  THE  REALITY  OF SPIRITUAL  INTEGRATION  
• Spiritual Actualization  is as much a function of Divine Physics  as it is a
    product of Divine Consciousness . The natural Primal Order of Universal
    Structure sets the Templates of Manifestation  to which consciousness
     must conform  to enter the experience of manifest expression within a
      space-time-matter system.  
• The personal Christos Maharic Shield Manifestation Template and the
     Christos Tribal Shield Species Manifestation Template are microcosmic
      replicas of the macrocosmic Primal Order upon which Universal and Cos-
        mic structure are built.  
 
• The tangible realities of human Spiritual Actualization take place through
     the Primal Order of the Angelic Human 12-Strand DNA Template.
      Each DNA Strand Template  holds a specific set of “Internal Star Gates”
       that allow for the progressive merging of the consciousness and energy fre-
     quencies of the 1728 selves  incarnate within the Two Planetary 12-Cy-
        cles of the Cycle of the Rounds.  
 
• Spiritual Actualization as a reality , rather than as a theoretical concept,
     takes place through progressive activation  of the dormant 12-Strand
     DNA  T emplate.  Each DNA  Strand T emplate corresponds to one dimen-
     sional frequency band, to corresponding levels or dimensions of con-
      scious awareness and to a specific set of incarnations  within the Cycle
     of the Rounds. Spiritual Actualization is accomplished when the 12-
     Strand DNA  T emplate “Internal Star Gates”  have fully opened, allow-
     ing the 12 dimensions  of conscious awareness of the Eternal Personal
      Christos Identity to merge and unify within a singular embodiment, across
        the fields of time.  
• The key to  Spiritual Actualization  is activation of the dormant personal
      12-Strand DNA  T emplate. The most rapid means  of activating the dor-                                                                                                                                             
     mant Angelic Human 12-Strand DNA  T emplate is through activation of
     the T ribal Shield,  the Species D-12 Christos Divine Blueprint, which
     represents the core programming  of the personal D-12 Maharic Shield.
 298                      

                                                                                                                                                  
                                                                                              Activating the Tribal Shield
                         ACTIVATING  THE  TRIBAL  SHIELD  
 •  The 12-dimensional Tribal Shield  is the dormant Species Divine Blueprint
       within the DNA Template core  of the Angelic Human races of the four
            Evolutionary Rounds. The frequencies of energy and dimensions of con-
        sciousness of the 1728 simultaneous selves  of the Personal Eternal Chris-
     tos Identity can be activated in one incarnation  through  sequential
     activation of the Fire Letter Sequences or “Flame Codes ” of the Tribal
          Shield.  
  • The “Flame Code Fire Letters” within the DNA Template are the DNA
      Signet Codes  that correspond to Earth’ s 12 Primary Star Gates  and the
      Planetary Shields  through which the planetary body manifests. The
        Flame Codes serve as the core foundation of the personal 12-Strand DNA
        Template.  
   • The DNA Template Flame Codes of the Tribal Shield allow for the Primal
      Life Force Currents of the Density-5 (dimensions 13-14-15 ) Kee-Ra-ShA
     Primal Light Fields  and the Khundaray Primal Sound Fields  from the
      Energy Matrix, beyond the 15-Dimensional Time Matrix, to embody
        more fully within the Angelic Human form.  
  • A Fire Letter is a fixed point of consolidated frequency  that holds specific
       frequencies of consciousness into manifest form. The Manifestation Tem-
        plates  or Divine Blueprints of all things  manifest are built upon intricate
       patterns of interwoven Fire Letters called Fire Letter Sequences. The
        Flame Codes of the Angelic Human personal DNA  T emplate and Species
        Tribal Shield are composed of the same  Fire Letter Sequences  that make
           up the Divine Blueprint of Earth’s Planetary  Shields.  
    • Activation of the Tribal Shield sets in motion simultaneous “firing” or acti-
      vation of the 144- Fire Letters  (12 Fire Letter Sequences)  of the l2-
       Strand DNA  T emplate, expediting the natural evolutionary process of
        Soul, Over-Soul and Christos A vatar Identity Integration, through pro-
          gressively opening the “Trans-time DNA Template Star Gates.”  
     • Activating the 12-Strand DNA Template allows the D-12 frequency of the
      Universal “Christos” Maharata Current  to activate within and run
      through the Angelic Human DNA  T emplate and into the Earth’ s Plane-
        tary Shields.  Activation of the Maharata Current within groups of An-
        gelic Humans on Earth allows for collective anchoring  of the D-12
   Planetary Christos Divine Blueprint , the Shield of Aramatena , to          
 achieve fulfillment of Angelic Humanity’s Sacred Commission  of the
        Planetary Christos Realignment  Mission.  
    299  

   
                 The fastest means of naturally activating the Personal 12-Strand DNA        
     THE FASTEST MEANS OF NATURALLY ACTIVATING THE
                          PERSONAL 12-STRAND DNA TEMPLATE  
  
  1.Tribal Shield Activation: Activating the 144 Fire Letters of the Tribal
      shield.  
   2.Emerald and Amethyst A wakening 2 Masters Kundalini Activations: Re-
     leasing key Fire Codes  between the DNA  Strand T emplates to allow for
        expedited DNA Strand Braiding.  
3.DNA Template Bio-Regenesis: Progressive use of internally directed DNA
       T emplate Bio-Regenesis technologies for progressive purging of Strand
             T emplate mutations, restoration of the natural D-12 Christos Divine
    Blueprint of the 12-Strand DNA  T emplate and expedited, accelerated ac-
        tivation of the DNA  Strand T emplate Base Codes and Acceleration
           Codes.  
 4.Master Key Codes: Use of the personal scalar-wave-guide Symbol Code Pro-
    grams that correspond directly to the core programming of the personal D-