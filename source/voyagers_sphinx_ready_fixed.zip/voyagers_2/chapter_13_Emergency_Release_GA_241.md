13 Emergency Release GA ............................................................................241                                                         
              A New Level of (Continuous) Revelation . . . . . . . . . …………........…. .241                                                                   
                Anunnaki, 1992 Pleiadian-Sirian Agreements & Fallen ET races....... 242                                                   
                Solar Star Gate-4 & Anunnaki defection from                                                                                               
               the 1992 Pleiadian-Sirian Agreements  .............................................245                                                                               
        The July 5, 2000, Treaty of Altair & Anunnaki Sabotage                                                                                  
                       of the 9/2000 UK Expedition . .............................................................247                                                                        
                The September 2000 UIR and the Edict of War ......................................250                                                                                  
                The D-l2 Planetary Security Seal, Planetary Shields Clinics,                                                                                           
                      and Crisis Intervention . ........................................................................255                                                            
                Invasion Agenda, HAARP, Merkaba-Reversal,                                                                                                 
                      and the Rude Awakening ......................................................................257                                                           
                Merkaba Mayhem, Real Ratios, and                                                        .                                                            
                       the Nibiruian Checkerboard Mutation .............................................. .259.