17               
                            
                                                                           
                                                                                      
                 The Phi-Ex Wormhole and
                              Illuminati OWO
                                           THE BERMUDA TRIANGLE, PHI-EX WORMHOLE,
                                                 FALCON MATRIX AND WORLD WAR II          
    Prior to the Anunnaki’s September 12, 2000, defection from the Treaty
of Altair Emerald Covenant peace treaty, GA Races were hopeful that
cooperation between Guardian races and the previously ill-intended
Anunnaki would allow for a peaceful resolution  to the Final Con flict drama
that had been “brewing” since the 9560 BC Luciferian Covenant . Since
November 1992, Emerald Covenant races have had to make concessions
regarding the expedient release of data  in order to maintain peaceful
cooperation from Anunna ki collectives controlling the NET . In 1992, the
GA knew that the interstellar political circumstances were extremely volatile
as Earth approached the 2000-2017 Stellar Activation Cycle  (SAC). They
also knew, since the last failed SAC of 22,326 BC  had ended in a  
''stalemate '' between the competing agendas of the Drakonian/Reptilian,
Anunnaki and Emerald Covenant races, that the 2000-2017 SAC  would
represent the climax  of a long-term battle between the forces of freedom  and
those of dominion.                  
      The 1992 Pleiadian-Sirian Agreements arose out of necessity, if peace
were to be maintained and cataclysm averted during the 2000-2017 SAC.
The opportunity for these well-intended but ill-fated peace agreements arose
from the actions of numerous Illuminati hybrid-human collectives since the
early 1930s . As explained in Voyagers I , certain factions within several world
governments had made covert treaties  with the Drakonian Agenda Rigelian
Zeta-Zephelium ¹ races of Orion —and thus the '' Zeta Treaties '' and '' MJ- 
12'' were born. Because of these intended “One World Order ”Drakonian/ 
Reptilian dominion treaties, competing Anunnaki forces who, since 
Atlantis, had been “nurturing” their Illuminati hybrid “Sleeper” races on
 Earth for their intended 2000-2017 takeover, suddenly found that their long-
anticipated position of covert power had been compromised. Since formation 
of the Anunnaki Luciferian Covenant of 9560 BC,  Anunnaki legions had
________________________  
                                1.     insectoid/reptile
                            354
               
                         


                                                              
                                                                               The Bermuda Triangle, Phi-Ex Wormhole... 
orchestrated a progressive in filtration of Human 12-Tribe culture and
systematic destruction and distortion of the Human historical records via
their Annu-Melchizedek  human-hybrid Illuminati race lines. Since
formation of the ancient Luciferian Covenant, the Anunnaki had intended
for these Illuminati race “Sleepers ” to be in position for overt Anunnaki
infiltration and takeover of Earth via the “ Savior Space Brothers ” deception
drama when the long-awaited 2000-2017 SAC arrived.  
    Anunnaki races of Nibiru, Pleiades-Alcyone, Sirius A, Andromeda,
Alpha and Omega Centauri, Arcturus and Orion had progressively gained a
stronghold on Earth through the 25,500 BC installation of the Nibiruian
Electro-static Transduction (NET)  and Nibiruian Diodic Crystal (NDC)
Grid at Stonehenge. Since the 9558 BC  Anunnaki-orchestrated “Atlantian
Flood” drama and '' Planetary Housecleaning '' (removal of historical records
and planting of false historical evidence), the major interstellar Photo-sonic
Communications system of Earth, the Nibiruian Crystal Temple Network,
was Anunnaki controlled via the NET, making Emerald Covenant Guardian
race communication with human populations progressively more di fficult.  
        The Anunnaki races were not the only ones running the long-term
“infiltration through hybridization agenda ” since initiation of the 9560 BC
Luciferian Covenant  in preparation for the One W orld Order dominion
conquest scheduled for the 2000-2017 SAC. Numerous factions of
Illuminati-Human-hybrid races of both Anunnaki and Drakonian/Reptilian
descent were created through raiding of the Atlantian Annu-Melchizedek
hybrid race line that emerged from the Emerald Covenant Anunnaki DNA
Bio-Regenesis Program .² The warring and conquest documented in known
“Human” historical record since 9560 BC has been an illustration of the
progressive power quest between competing factions of Illuminati hybrids for
Earth Star Gate site dominion.  The true Race Identity  of Human l2-Tribe
races progressively became “lost in the shuffle” and engulfed by Illuminati
hybrid race identity, as Illuminati hybrid races, always directly but covertly
motivated  from “behind the scenes” by their respective Fallen Angelic
collectives, launched their competing territorial dominion campaigns.  
         The elite '' Masters of War '' that have held, by force, positions of
political, religious and economic power throughout our known history from
Sumeria, Babylon, Egypt and Rome, up to the present-day covert '' World
Management Team ,'' are the Illuminati hybrid “Sleeper Races.”  The
Illuminati hybrid Sleeper Races are the Earthly representatives  of competing
Anunnaki, Necromiton and Drakonian/Reptilian Fallen Angelic legions,
and they have been the motivating force behind literally all “human” politics
since the 9558 BC “fall” of Atlantis. Illuminati hybrid Sleepers are but a
minority  within Earth populations, but they are those presently in positions
of greatest power  and in ﬂuence behind  the global political, religious and
economic infrastructure . Like Earth’s Human races, Illuminati Sleeper races
have been subjected to literally thousands of years of false cultural and
religious programming  via implanted Anunnaki and Drakonian/Reptilian
indoctrination . Most Sleeper races do not consciously know  of the reality of
                          ______________________________________
                           2.     See Forbidden Testaments of Revelation , forthcoming.   
                                355       
                                                                                                                                        

                                                          
        The Phi-Ex Wormhole and Illuminati OWO  
Fallen Angelics/ETs —only the few elite, key controllers  among each
Sleeper faction are permitted conscious knowledge of covert Fallen Angelic/
ET contact,  and none are permitted full knowledge regarding the real Fallen
Angelic/ET agendas.  Fallen Angelics historically control their Sleepers to
serve as their “ expendable pawns ” upon “Chess-board Earth,” through
remote NET-transmission of subliminal psychotronic EM scalar-pulse
programs and astral Tagging. Though Illuminati hybrid Sleeper races appear
both outwardly and genetically like “common humans,” due to genetic
mutations  that began in 25,500 BC, they do not have the human soul
essence . The Sleepers are incarnates from the Fallen Angelic/ET collectives
that control them; genuine Human 12-Tribe incarnates emerge from a once-
ascended master Guardian Maji Grail Line soul collective, not from the
Fallen Angelic collectives from which Illuminati Sleepers emerge.  
    The various competing Anunnaki and Drakonian/Reptilian Illuminati
hybrid Sleeper Races have been a hidden, predominant reality on Earth
since  155,000 BC . Since the 9560 BC  formalization of the Anunnaki
Luciferian Covenant, the competing family lines  of Illuminati Sleeper Races
have been part of a progressively orchestrated, highly organized long-term
strategic plan  to create Fallen Angelic '' Master Races '' on Earth in
preparation for the 2000-2017 SAC . Through these Fallen Angelic
Illuminati hybrid Sleeper Master Races, the competing legions of Anunnaki
and Drakonian/Reptilian interstellar collectives each intended to achieve
dominion of Earth’s Star Gates during the 2000-2017 SAC.  The strategic
plans of Fallen Angelic/Intruder ET Earth-dominion agendas that were set
forth in the ancient Atlantian Conspiracy  all held the intended scheduled
climax  as the 2000-2017 SAC . It was known by all Visitor races since
22,326 BC Atlantis , that the competing Fallen Angelic collectives intended
to wage war with each other , via manipulation of their Illuminati hybrid
Sleeper races, during the 2000-2017 SAC , in the final dominion quest  for
Earth’s Halls of Amenti Star Gates. The carefully cultivated and strategically
positioned Illuminati hybrid Sleeper Races  were intended, by each of the
competing Fallen Angelic factions, to serve as the tools through which this
war would be won . Since the 25,500 BC Lucifer Rebellion, Atlantian
invasion and resultant progression of Fallen Angelic territorial in filtration of
Earth, Emerald Covenant Indigo Children and Angelic Human 12-Tribe
races  have also retained their presence  on Earth, despite continually
advancing Illuminati hybrid and Fallen Angelic persecution, political
infiltration, false cultural indoctrination and attempted genocide. Guardian
races too have their Angelic Sleeper Races , incarnate representatives of the
Founders’ Emerald Covenant  Co-evolution Peace Treaty , who were long
intended to awaken and serve as the  peaceful healers and bringers of
Freedom  when the Final Conﬂict drama of the 2000-2017 SAC emerged.  
    Until the early 1930s, the Anunnaki legions  believed that they had
the upper hand  in regard to defeating Humans and Drakonian/Reptilian
legions in completion of the 2000-2017 One World Order Dominion agenda.
The Anunnaki Illuminati hybrid Sleeper Race family lines of the Knights
Templar, Free Masons, Hyksos  and related factions immersed within certain
contrived “religious” persuasions were in positions of global power, each
serving in administration over large, unsuspecting, amnesiac, (via DNA   
356  
   

                                                               
                                                                        The Bermuda Triangle, Phi-Ex Wormhole...
mutation) indoctrinated collectives of Angelic Human populations. The
majority of Human populations  existed in an  easy-to-direct amnesiac state
of Lost Race Identity and religious/scienti fic/historical cultural
Disinformation Propaganda control.  Competing Drakonian/Reptilian
legions would have a difficult time mobilizing their own Illuminati Sleeper
Race forces due to the Anunnaki’s predominant control of the NET and
Earth’s interstellar communications systems. In the early 1900s, Zeta-
Zephelium races  from an adjacent Time Matrix ( see Voyagers I ) managed to
break through the Anunnaki NET, by forcing a “hole in the cap” of a sealed,
ancient  Atlantian wormhole . This wormhole, one of two  remaining from
the technological abuses of ancient Atlantis,  is an artificially created trans-
dimensional, geophysical anomaly  that has existed in the Atlantic Ocean  off
the coast of what is now Savannah, GA , since 10,500 BC.  The two ancient
Atlantian wormholes are in the Atlantic Ocean on Axiatonal Line 7 , at
about 69.5° W longitude off the eastern U.S. coast. The first wormhole is on
horizontal Ley Line 3,  the Star Gates-3-Bermuda/ 9-Bam T so Tibet
“Bermuda-Jerusalem-Afghanistan-Pakistan-Bam Tso-Nagasaki Line ” at
32° N. The second is on horizontal Ley Line-4/10 , the Star Gates-4-Giza/10-
Abadan-Iran “ Giza-Persian-Gulf-Mid Way Line  ” at 30° North latitude.
Collectively, the two Atlantian wormholes, and the various Templar '' Port
Interface Networks '' connected to them, are responsible for the odd
phenomena of  plane/boat disappearances and electromagnetic anomalies  in
the area of the Atlantic called the '' Bermuda Triangle .'' 
    The Zeta races began surveillance of Earth territories and were rapidly
joined by an aggressive, militant Zeta race from Orion Rigel , who took over
administration of Zeta Earth missions on behalf of the Drakonian/Reptilian
Agenda.  By the early 1930s , through covert, direct physical contact , Zeta-
Rigelian forces had seduced a majority of key controllers  in the global
political community within both the Anunnaki and Drakonian/Reptilian
Illuminati hybrid Sleeper races into entering the Zeta Treaties  to stand
against what they presented as the “pending Anunnaki invasion.” At this
point “ MJ-12 ” and key components of the '' World Management Team ''
covert Interior Government were mobilized into a uni fied organization under
the Drakonian One World Order Agenda . Through the unanticipated
events  initiated by the Zeta Treaties , Anunnaki legions were forced to
initiate select, covert physical contact  with key figures in their Illuminati
hybrid factions, in an attempt to persuade them to break the Zeta treaties in
favor of Anunnaki  (Pleiadian-Nibiruian) allegiance.  
    Though the Anunnaki gained some converts  through these attempts,
the majority of   Illuminati hybrid races remained compromised by the trickery
of the Zeta Treaties, as the Zetas provided key weapons technologie s to
further their interests in the WW2 drama . Anunnaki races refused to provide
weapons technologies, as they feared their Illuminati hybrid races might use
such technologies against them  if the Anunnaki could not maintain critical
mass control of Illuminati races. As the “ UFO/Abduction Movement”
progressed following the dominant  Drakonian/Reptilian Zeta Agenda , the
Anunnaki began an aggressive covert counter-campaign using Psychotronic
scalar pulse technologies  and the NET to “awaken” their civilian Anunnaki
Illuminati hybrid Sleeper Races . The Anunnaki “trump card ” of the NET/    
357     
 
                                                                                                           

                                     
                      
                         The Phi-Ex Wormhole and Illuminati OWO
NDC Grid3  was used to initiate Psychotronic transmission of '' channeling ''
contact  with Illuminati Sleepers and Humans within the private sector.
Through this covert application of selective  mass mind control,  progressive
cooperation of unsuspecting people was garnered to advance the Anunnaki
dominion agenda, culminating in the creation of what has become the “ New
Age Movement. ” Throughout the building fiasco of Earth Illuminati-
Interstellar politics, Emerald Covenant Guardian races  made numerous
attempts at physical contact with key members of all Illuminati factions and
Human governments. Guardian races offered protection from both
Anunnaki and Draconian/Reptilian invasion if Illuminati and Human
Interior Government controllers would willingly honor the tenets of
egalitarian freedom, non-exploitation and peaceful coevolution  as long-
stated within the Emerald Covenant. Direct Guardian intervention in
Earth’s affairs required World Management Team controllers to discontinue
their programs of “Official Denial,” reveal the truth of the Atlantic
Wormholes, and Visitor Contact , to the public and to present to all
populations  the free-will  choice of entering the Founders’  Universal
Emerald Covenant Peace Treaty.  
   Guardian races explained that advanced Star Gate sciences and
Planetary Templar technologies  would be provided in stages as needed, to
create peaceful protection  of Earth’ s territories from further invasion. In
order for direct Guardian assistance to be given, the Illuminati hybrid races
who were controlling Earth’s infrastructure on behalf of competing Fallen
Angelic factions would need to accept the peaceful methods of intervention
offered by the Emerald Covenant races. Guardian nations would not endorse
the use of, nor provide, advanced weapons technologies  for the pending
Earth con ﬂict; such technologies would not secure the victory of freedom;
they would ensure only planetary destruction . The Illuminati would need to
put aside their own One World Order dominion agendas , exploitation of
Human populations and intentions of war in favor of peaceful interplanetary
and interstellar coevolution  built upon the freedom teachings of the
Emerald Covenant and Lyran-Sirian free cultural model. Illuminati races
within the covert Interior Government and World Management Team
repeatedly refused Guardian offers of assistance  in favor of the One World
Order dominion agendas and promises of power-hoarding  offered by
competing Anunnaki and Drakonian/Reptilian forces.                      
                         
                        
                           ________________________________
                              3.     See  Masters Templar Coursebook , now available.
                                358
                                
                         

                                                          The Phi-Ex Wormhole, and the Phantom Matrix ''Pit'' —1943
                                                             THE PHI-EX WORMHOLE,
                                                    AND THE PHANTOM MATRIX “PIT”—1943
                  
      In 1943  the Zeta/Drakonian agenda gained further strength  through
initiation of the Philadelphia Experiment , in which another '' time-rip Worm
hole'' or Port Interface Network (PIN),  was made in Philadelphia, PA,  via
the first Atlantic Wormhole. This PIN connected numerous points in Earth’s
global geography to the adjacent Time Matrix that is partially under Zeta/
Drakonian rule. The adjacent Time Matrix  to which Earth’ s new I943
wormhole network was connected once existed as part of our own Time
Matrix. Through repeated abuse of Advanced Scalar Pulse technologies ,
this portion of our Time Matrix imploded  250 billion years ago  forming an
11-dimensional Black Hole Sub-Time Distortion Cycle  within the
structure of our 15-Dimensional Time Matrix. This progressively contracting,
unnatural Black Hole Sub-Time Distortion system is known as the '' Phantom
Matrix ;'' in Biblical terms the Phantom Matrix is described as “t he
Bottomless Pit,”  and is also referred to as '' Hell'' and '' Hades .'' 
         The Fallen Angelic/Intruder ET races  that have plagued our Time
Matrix throughout history are the DNA-mutated/consciousness-distorted
life-forms  that emerge from the Phantom Matrix into our Time Matrix in an
attempt to “energetically feed” their slowly imploding, dying system by
harnessing life force from our living system. During the August 12, 1943,
Philadelphia Experiment, Zeta forces tricked Illuminati races  into
employing technologies that the Zeta knew  would create active Wormhole
links  between the Phantom Matrix and Atlantic Wormhole.  In 1943, not
only were the main East Coast power centers of the US  linked to the Zeta-
controlled Atlantic Wormhole, but an entire  network of wormhole links
was also created. The Zeta Phi-Ex Wormhole network extends diagonally
from Portland, ME- Boston, MA- Montauk, NY- Philadelphia, PA-
Washington DC- Mt. Mitchell/Asheville, NC- SW Florida, Atlanta-GA ,
horizontally across the US to Alaska,  spanning both the Pacific and Atlantic
Oceans into N. Ireland, across Europe and into Vietnam and Japan . Key
Illuminati controllers were tricked by the Zetas into orchestrating this
“experiment” under the false pretense of developing military “Cloaking”
(invisibility) technologies. In one well-orchestrated technological
deception , the Zeta-Rigelian Drakonian force had literally “carved out their
intended territory” across the global map,  gaining covert control of many key
Axiatonal Lines, Ley Lines and Star Gate sites  in Earth’ s Planetary T emplar,
while striking terror into the hearts of their Illuminati collaborators. (The
''Trojan Horse '' of the Atlantian NDC-Grid revisited). The Zeta and
Illuminati creation of this Wormhole network had unanticipated
consequences  for the Drakonian agenda races—the '' Phi-Ex  (Phi-ladelphia
Ex-periment) Wormhole ” allowed for yet another Fallen   Angelic “player”
to directly enter the contemporary Earth game.  
                    
         NECROMITON-ANDROMIES AND THE “UNHOLY ALLIANCE”
 
        A Fallen Angelic race, which had long intended dominion over the
   Zeta/Drakonian legions of the adjacent Phantom Time Matrix and which
   had gained partial access to the Atlantian Wormhole the Zetas opened in the
     359  
                                                                                                                              
                                                                                                                                                                                 

                                                                                                                                                                                                                                                     
                        
                          The Phi-Ex Wormhole and Illuminati OWO
early 1900s, was also able to gain easy open access to Earth territories via the
Phi-Ex Wormhole. The most diabolical player  in the Earth drama is the
ancient race called the Necromiton —a hybrid Insectoid Beetle-Reptilian
Anunnaki-hominid-hybrid  race from the adjacent Andromeda  galaxy . The
Necromitons are feared and hated by most Anunnaki and Drakonian/
Reptilian races, and like their competitors, the Necromitons have had
Illuminati hybrid Sleeper Races  positioned among human populations of
Earth since the Atlantian period. The Necromiton races are the leaders of an
Unholy Fallen Angelic Alliance  that involves several powerful renegade
rebel races . Included in this Unholy Alliance, and directed by Necromiton
“Andromie” administrators  are the following collectives:  
     • The Blue Centaurs  and Anunnaki-hybrid Centaurian  races of Alpha
and Omega Centauri.  
    • The Orion Black League Human-Reptilian hybrid “ Noors ”4 of
Alnitak-Orion, the Pleiades, Andromeda and Vega-Lyra . 
    • Also included are several rebel factions  of both Anunnaki and
Drakonian/Reptilian legions, including factions of the “Archangel Michael”
and Annu-Melchizedek Anunnaki Nephilim  rebel races and rebel portions
of the Omicron-Drakonian5 collective of Alnitak-Zeta and Alnilam-Epsilon
Orion.  
  The Phi-Ex W ormhole born of the 1943 Philadelphia Experiment
presented the Necromiton force with renewed opportunity for large-scale
Earth in filtration.  Necromiton Andromie race operatives have become
known as the “ Men in Black”  within the contemporary UFO drama.  
   Between 1930-1943, most Necromiton-Andromies were not
particularly interested in participating overtly in the “Final Con ﬂict” Earth
drama being set up by competing Anunnaki and Drakonian/Reptilian
factions. The Necromiton had an Earth Star Gate dominion agenda of their
own, which originally included extermination of all Earth races, including
the Illuminati hybrid operatives of the other Fallen Angelic collectives.
Originally the Necromiton intended to build their underground power bases
and “wait and see” whether the Drakonian/Reptilian or Anunnaki forces
“won the Final Con ﬂict,” intending then to “ depose the victors ” and claim
Earth, Inner Earth  and the Halls of Amenti  Star Gates for their own. The
Necromiton races planned to take direct action only if the 2000-2017 SAC
fully commenced , as the Amenti Gates could not be accessed otherwise. No
one knew for certain until 1998  whether or not Earth’ s core vibration would
sustain commencement of the pending SAC, but all interstellar races were
''positioning their Illuminati operatives '' for the dramas that were due to
rapidly emerge should the SAC commence in 2000.  
    Unlike Anunnaki and Drakonian/Reptilian races, the Necromiton were
not interested in dominion of surface Earth, because their primary genetic
strains cannot live long under surface-Earth conditions. Their interest in
Earth is strategic only ; Earth is the primary point in our Time Matrix from
which the Halls of Amenti Star Gates can be potentially invaded. When the
                         
                          ______________________________
                             
                                4.     Red-haired Human-looking Omicron Drakonian-human hybrids
                                 5.     Dragon-Moth       
                           360                      
                     

                                             
                                                  
                                                '' Big Brother Drac,'' the Andromies, Hiroshima and Hitler
Zeta-Rigelians advanced their OWO agenda by creating the Phi-Ex
wormhole, the Necromiton set up underground  bases in certain strategic
locations, beginning limited covert  contact  with key members of their
Illuminati Sleeper races for “future reference.” From 1943  forward, both
Anunnaki and Drakonian/Reptilian legions and their Illuminati hybrid loyals
contrived competing “step-by-step” strategic plans  by which covert political
infiltration, leading to One World Order surface Earth dominion between
2008-2012,  would be progressively set in motion. The Zeta-Rigelian
Drakonian agenda had advanced rapidly following the 1930s’ Zeta Treaties,
quickly over-powering the previously Anunnaki-dominated covert
Illuminati political landscape . In the early 1930S, the '' Majestic-12 ''
Illuminati head of Zeta-Drakonian-agenda operations had progressively
infiltrated key positions of world politics, most notably in the U.S.A., which
the Anunnaki Illuminati had historically boasted as their “stronghold” since
their “Yankee” victory over the Drakonian “Rebel” force during the
American Civil War.6 In the l930s the Zetas assisted in creating central
organization of the covert World Management Team  on behalf of the
Drakonian agenda, through which global economic and political powers
were centralized  under the covert governance  of a hidden Zeta-Rigelian
Drakonian totalitarian “Big Brother.”  
                    
                          “BIG BROTHER DRAC,” THE ANDROMIES,  
                                      HIROSHIMA AND HITLER 
   Compromise of the American Constitution  had been orchestrated by
Anunnaki Illuminati  via manipulation of American banking laws, in their
quest for covert economic control during the late 1800s  and early l900s.
The American Constitution  was further violated  by the Zeta-Drakonian-
agenda Illuminati in the 1930s , with the creation of the privately held
interests of the U.S. Federal Reserve and several other acts of “underground
sleight-of-hand.”7 As the Zeta-Drakonian Illuminati organization of MJ-I2
was quietly expanded into what became the U.S. CIA, the previously covert
Anunnaki Illuminati control of the American political-economic machine
fell to the equally covert “hostile takeover” of the advancing Zeta-Drakonian
''Big Brother '' game-plan. Adopting the strategies of the Anunnaki
Illuminati before them, the Zeta-Drakonian Illuminati created a complex
''underground '' system  of '' Black-Budget Funding '' networks, including
covert drug and arms running, to fund building of underground Zeta -
Drakonian Bases  and further the quest for covert Big Brother territorial
dominion.  
  World War II  began in 1939  as the Zeta-Rigelian Drakonian-agenda
force launched a covert territorial conquest and race supremacy/genocide
campaign through their Illuminati hybrid “fall guy” Adolf Hitler . The
                            
                             _______________________
                     6.   Sadly , it is primarily Humans who end up “playing the soldiers” that lose their lives
                        unknowingly on behalf of the covert Illuminati-ET alliance and their '' Illuminati arm-
                                        chair warriors .''
                7.   The external aspects of these covert Illuminati in filtration of U.S. and world political and
                                        economic systems are well chronicled by various “conspiracy theorists” of our time.
                               361
                                                                                                                                                 
                                                                                                                               

                                                                                                                                                                                         
The Phi-Ex Wormhole and Illuminati OWO  
political quest was covertly motivated by Star Gate territory control,  the
“Holy Grail Quest” for Earth’s Templar,  as it had been in WW1 and all
Human wars since Atlantis. In WW1 and WW2  all groups were covertly
competing for territories that could be used for Port Interface Networks
connecting to the A7/L3 Falcon wormhole.  Once the Zetas had “opened the
cap” on the Falcon wormhole on Axiatonal Line-7/Ley Line-3, territories
connecting with this coordinate through Earth’s natural Ley Line structure
became “prime real estate”  for their use as Falcon wormhole Port Interface
sites.  
     In WW2,  select members of Japan’ s Illuminati elite were covertly
“inspired” by a faction of the Necromiton-Andromie  race that at the time
chose to compete with the Zeta-Rigelian legion for Port Interface Site
dominion in various regions. The U.S.A. and Japan became entangled  with
each other over intended dominion of Ley Line-3 Port Interface Site
control.  In 1940 , the Necromiton-Andromies began covert contact with
their Illuminati hybrid family lines in the areas of Hawaii and Nagasaki and
Hiroshima, Japan. Nagasaki  is a prime Port Interface Site  on Falcon
wormhole Ley Line-3 ; the Necromitons inspired their members of the
Japanese and Hawaiian Illuminati to begin construction of two underground
marine bases  in these regions. The Nagasaki-Hawaii Necromiton bases
would prevent the Zeta-Drakonian races from expanding their Falcon Port
Interface Network as they planned to do during Earth’s scheduled ''Magnetic
Peak '' of August 12, 1943. The greatest objectives of the Zeta-Rigelian
Drakonians in 1940-1941  were reducing concentrations of Angelic Human
Maji and Necromiton Illuminati family lines  inhabiting the Nagasaki-
Hiroshima areas, and thwarting Necromiton base-building  by having
Human government attentions scrutinize Hawaiian territories. The
Necromiton Fallen Angelics would be left without their Illuminati “surface
work force” in Japan, local Angelic Human Planetary Shields guardian races
would be destroyed and any covert Necromiton marine activities around
Hawaii would be instantly detected and exposed should the Necromitons
attempt to proceed. To “solve” their pending problem, the Zeta-Rigelians
directed their Illuminati family lines in Tokyo and other regions of Japan to
launch a “secret attack” on Hawaii. Simultaneously, the  Zeta-Rigelians
warned their Illuminati key controllers in the U.S.A. that the attack was
coming, but that they should do nothing . 
     Once the December 7, 1941 , Japanese attack on Pearl Harbor  was
completed, the American Illuminati were then directed to enter territorial
war but to '' wait until the appropriate time ,'' to use the Zeta-Rigelian -
inspired atomic bomb. Meanwhile, on August 12, 1943,  the Zeta-Rigelians
inspired their Illuminati within the Allied forces to orchestrate the infamous
“Philadelphia Experiment ” during Earth’s stronger 20-year August-12
“Magnetic Peak” cycle.  Through Zeta trickery the Phi-Ex wormhole and
Falcon Port Interface Network were brought into global operation in 1943.
The Zeta—Rigelians intended to open the final links of the Phi-Ex Falcon
Port Interface Network  during the August 12, 1945 , yearly planetary
Magnetic Peak. The Necromiton-Andromies were using a Cloaking
Protection Field around their progressing underground base at the Nagasaki
Port Interface Site, which would prevent the Zeta-Rigelians from opening 
362      

                                                 '' Big Brother Drac,'' the Andromies, Hiroshima and Hitler
and claiming the site under their control in August 1945. As the Zeta-
Rigelians had planned since 1941 , the “ time had come ” to inspire the US
Illuminati to direct Human troops to use their A-bomb to “flatten”
Hiroshima and Nagasaki . This military atrocity was ordered to break
through the Necromiton photo-sonic cloaking screen  and to “clear the real
estate” of Necromiton Illuminati “cells” for Zeta-Rigelian Drakonian
Illuminati “resettlement.” On August 6, 1945, Hiroshima , the Necromiton-
Illuminati controlled Cloaking Shield main generator system and a city
composed almost completely  of innocent Angelic Humans  of “ Yu Urtite-
Cloister Maji Grail Line ” descent fell amidst radioactive rubble. The Zeta-
Rigelian command waited until August 9, 1945,  before giving the order to
strike Nagasaki . The rapidity of the second strike ensured that the
Necromiton would have insufficient time thereafter to erect a temporary
Cloaking Shield in an attempt to prevent the Zetas’ scheduled August 12 ,
1945, Sub-space Sonic scalar pulse.  
    The Zeta-Rigelians’  August 12, 1945, Phi-Ex sonic scalar pulse  put
the Nagasaki Port Interface Site “on line” with the Zeta-Drakonian-
controlled Falcon wormhole and Phi-Ex Network. By August I3, 1945, the
Nagasaki Phi-Ex Port Interface link had proved successful, and the Zeta-
Rigelians informed Japanese Illuminati controllers that it was “time to
surrender,” that the “Nagasaki Mission” was completed. On  August 14,
1945 , the Japanese Emperor gave consent to Japan’s compliance with the
Allied demand for surrender.8 Securing and activating the Nagasaki Port
Interface Site under Zeta-Rigelian Drakonian control  was the real reason
behind Japan’s attack on Hawaii and America’s “return retaliation.” The
Japanese Illuminati majority, individual “Sleepers” covertly placed within
positions among Human government elite, agreed to participate , as did the
American Illuminati, only because the Zeta had threatened them  that if
they did not comply, atomic bombs and sonic pulses would be used to destroy
their entire countries. This threat gives one some insight into the “Mind
Games”  Fallen Angelics like to play , and also into the reasons why
Illuminati races are most often too frightened to rebel  against Intruder ET
orders. Drakonian, Necromiton and Anunnaki Fallen Angelic races
continually use these types of Mind Games to keep their Illuminati key
controllers in subservient compliance.  
    What was going on with the Nazis during the WW2 period was
equally as reprehensible.  The Zeta-Rigelians assisted in developing the
Nazi movement of WW2,  supporting and '' nurturing '' Hitler  and his inner
circle Drakonian Illuminati crew; the Nazi Illuminati elite had also entered
Zeta Treaties in the early 1930s, agreeing to “ reduce populations ” of several ,
primarily Angelic Human ''pure-strain '' ethnic groups . The Zeta-Rigelians
instructed their Illuminati operatives in the U.S.A. and several European
countries to financially fund the Nazi movement  “without leaving a paper
trail.” While keeping an external posture of Allied loyalty  to maintain their
                        _________________________________                          
                              8.    This is the real reason why Japan didn’t immediately surrender after the first,
                                         Hiroshima, strike.  Their Zeta-Rigelian Drakonian-agenda Illuminati “elite” were
                                         instructed to wait until Nagasaki , the Port Interface Site , had been “taken care of                                                                                   
              before agreeing to surrender.  
                                                       363                                  
                                                                                                                                           
                                                                                                 

                         
                   
                        The Phi-Ex Wormhole and Illuminati OWO
hidden positions within Human governments, the Illuminati operatives in
several Allied  countries covertly funded Nazi objectives . The Necromiton-
Andromies  made covert physical contact with Hitler , “playing on” his
personal prejudice against Jewish races. They convinced him to assist in the
Necromitons’ plan  of keeping the Zeta-Rigelians ''in their place,'' by
providing small “gifts” of metaphysical Templar knowledge  that allowed
the Nazis to unearth certain ''valuable relics '' from the Grail Quests of
ancient times. Consequently, Hitler '' got carried away with himself '' in his
genocide campaign against Jews,  on behalf of his Necromiton-Andromie
affiliations. In Hitler’s Zeta-Drakonian “deals,” he had been instructed to
reduce numbers of only certain Jewish family lines associated with the
''true Hebrew '' Angelic Human/Indigo Child Maji Grail Line lineage.
Hitler had been warned to leave ''untouched '' families of the Drakonian
''Hibiru Illuminati ,'' a Hibiru-Drakonian Illuminati hybrid lineage
descended from the ancient Atlantian “Hassa King” family line  that has
been progressively masquerading under “Jewish disguise ” since the
Atlantian period. But in his overzealous quest for race supremacy, and
“double-dealings ” with the Necromiton-Andromie force, Hitler’s “ethnic
hunting” became indiscriminate,  and several Hibiru-Drakonian Illuminati
families, favored by the Zeta-Rigelians, were destroyed.  
   The Zeta-Rigelian Drakonian force promptly gave the order to
international Zeta-Drakonian Illuminati conclaves to withdraw all support
from the Nazi campaign  and to assist the Allied Illuminati  controllers in
orchestrating the defeat of Nazi Germany. This information has been
provided by the GA/Eieyani for inclusion in this book, so readers may begin
to realize the extent to which the covert Fallen Angelic presence and the
advancing invasion has determined the external events that Humans have
lived through and died from for so long.  The realities of covertly inspired
Fallen Angelic/Illuminati-orchestrated “Human Wars” are now emerging
into the global arena  once again as the UIR advances the final strategies  in
its OWO, Star Gate quest, '' Final Conflict '' dominion campaign. We will all
become a bit wiser, less likely to get caught up in the Final Conﬂict War
Game and perhaps become a bit more compassionate toward those who fall
to this ploy, if we look to the true causal element  behind these “W ar
Dramas.” Fallen Angelic/Intruder ET races covertly motivate this  “Victim-
Victimizer” drama among Human nations in order to support their own
“Unholy Grail Quest” initiatives.  
   Ninety-Nine percent of the people working for and within their
national government communities have no idea  of the Atlantian Conspiracy
that has operated behind world politics for thousands of years. This is
especially true in America , where most military personnel, even in the
highest ranks, honestly still believe that the U.S.A. is a democracy  that
they would willingly give their lives to defend. The truth hurts —the core
infrastructure of America,  like that of all global nations since the 1930s,
has been covertly and progressively compromised and ''absorbed '' by the
covert Big Brother Zeta-Rigelian Drakonian World Management Team .
                    What even most conspiracy theorists do not yet realize is that '' at the top '' of
                          this corruption there exists Fallen Angelic/lntruder ET masterminds  who  
                       have had the Illuminati races terri fied to rebel  since the  Zeta Treaties  of the 
                         364  
                           

                                               “Big Brother Drac, ” the Andromies, Hiroshima and Hitler
1930s. As painful as it might be for Americans to confront, (and it is
painful!), we have been living under the contrived  ''illusion of freedom ''
while our nation and our planet has been in the clutches of a progressively
advancing, cunningly orchestrated Intruder ET invasion for the last 70
years —an invasion that was planned, and methodically implemented  by, our
unwelcome Visitors since 9560 BC Atlantis.  Human nations have been
intentionally driven around in mental circles within a “fantasy world,” a
''perceptual bubble'' of manipulated security and ''Official Denial.'' If the
United Intruder Resistance (UIR) succeeds in ful filling its 2001-2008
OWO Progression Schedule, our collective ''wake-up call '' will soon pass
the ''sell-by '' date.  If they did not need  human populations  to assist them in
running the Star Gate Security Access Codes during the SAC, they would
have “gotten rid of us” long ago.  
___________________________________________________________
That Humans have managed to hold their own this far, despite what has been
       done covertly to intentionally enslave the Human race since Atlantis,
                     is a testimony to the true strength of the Human spirit.___________________________________________________________
      
         The  SAC  dominion  strategies  of   all  Fallen   Angelic/ET    Illuminati  OWO
agendas became highly organized, formalized and slowly implemented by
1972 , with ﬂuctuations of power between various competing Anunnaki and
Drakonian-agenda factions being covertly “played out” within various
external, international political and economic dramas. The common aspect
of these hidden global political agendas was the '' Final Conflict '' drama , in
which Human races, unknowingly headed by the covert manipulation of
competing Illuminati hybrid Sleeper races under subliminal Fallen Angelic
Psychotronic control , would be slowly and systematically  led into creating a
final Human global war.  Through this Fallen-Angelic-scheduled WW3
Final Conflict drama , the outcome of the Anunnaki vs. Drakonian/Reptilian
One World Order Dominion agendas would be determined. The competing
Fallen Angelic legions of all sides  intended to have unsuspecting humans
and Illuminati hybrids  “fight the battle”  against each other,  while the
covert  instigating force  of the victorious Fallen Angelic collective  would
later come to “claim battle field Earth for re-settlement.” At this point, the
“dominion victor” would then have to face the Necromiton force.  
365