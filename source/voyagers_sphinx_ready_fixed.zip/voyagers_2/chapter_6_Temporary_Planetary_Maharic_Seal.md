6 Temporary Planetary Maharic Seal. 
       “Safe Zone”  areas under sufficient Trion/Meajhé Field Buffer Blanket and Tem-      
porary Level-9 Temporary Planetary Maharic Seal protection will remain more stable,     
environmentally, politically and economically.  Conditions in unsafe zones will pro-      
gressively deteriorate as the UIR attempts to un-Cap the Falcon-Phoenix Wormholes,      
while advancing their invasion agenda in unprotected regions toward the 2011 Final      
Conﬂict. The 2006 Three-Day Particle Conversion Period will be the determining      
factor in what portions of Earth’s geography will undergo final cataclysmic shift      
into the Phantom Matrix in 2012 . Regions co-resonant with the Phantom Matrix       
time line will undergo some degree of geophysical changes , such as severe quaking or     
submergence beneath the waters, between 2006-2017 . But the populations  in these      
regions will still have some time left to develop biological co-resonance with Safe       
Zones, after Particle Conversion occurs. The 4.25 Trion Buffer Bubble will create sta-      
ble areas of land mass and culture that are held secure within D-9 Quatra Phase Merk-      
aba Field protection, and which will sustain a constant D-4.25  magnetic field.  The D-      
4.25 magnetic field will allow any life forms with 4.25 DNA Strand Template activa-      
tion²   to move into Safe Zone territories for final 2012  transition into the Inner Earth      
Bridge Zone Time Continuum.  Originally a 4.5 DNA Strand Template activation       
level was needed for passage into the Bridge Zone continuum. 
        Now, populations with a lower 4.25-DNA Strand Template activation  will       
have greater opportunity to “make it to the Bridge Zone” in 2012. The general Trion/      
Meajhe Field Buffer Blanket in Earth’s magnetosphere will provide non-Safe Zone      
regions with some degree of protection  during the 3-Day Particle Conversion       
period, preventing full planetary magnetic field collapse. These areas will be less stable      
and more prone to anomalous geological, climatic, atmospheric and electromagnetic      
phenomena than Safe Zone areas under the 4.25 Trion Buffer Bubble protection. Fol-      
lowing the 2006 Three-Day Particle Conversion Period, and until 2012 , regions and      
populations co-resonant with the Phantom Matrix time line will have greater protec-      
tion from succumbing to immediate Phantom Matrix descent. These regions of Earth      
will experience a " slow fall " to the Phantom Matrix, with less severe Earth Changes,      
spread out over a longer period of time, than would have occurred with the “fast fall”      
2017 Particle Conversion Period. The ''slow fall" allows for the potential of retrieving      
greater population numbers from Phantom Matrix demise. The 4.25 Trion Buffer Bub-      
ble plan was not originally considered viable,  as it required that Earth’s grid speed be      
rapidly accelerated by 2006 to a minimum of D-9 oscillation/ Planetary Quatra Phase      
Merkaba/ Level-9 Temporary Planetary Maharic Seal. This rapid grid speed accelera-      
tion increases the potentialities of greater Earth Changes and possibilities of pole      
shift  before 2012 arrives, which is a risk to all populations that Emerald Covenant       
nations were not originally willing to take.    
      As circumstances have evolved, the Anunnaki races  defecting from the 2000      
Treaty of Altair and 1992 Pleiadian-Sirian Agreements have made the decision for      
everyone . Due to their support of the UIR OWO dominion campaign, pole shift       
and destruction of the Human race  by 2008 would be a certainty, if the Trion/Meajhé      
Field Buffer Blanket and 4.25 Trion Buffer Bubble option was not immediately called      
into play. The Trion/Meajhé Field Buffer Blanket/4.25 Buffer Bubble plan will create a      
condition of progressively extreme bi-polarity  among global Human nations and Illu-      
minati collectives. “Very Safe” GA Safe Zone areas will be interspersed among “very      
unsafe” UIR dominated areas. Extreme differences in polarity between DNA Tem-       
plate activation levels, and thus maturity and stability of consciousness and fortitude      
of biological constitution among world populations, along with resultant confronta-
                          _____________________________
                            2.   All of Strand-4 and one-quarter of Strand-5
                            548       
 

                                
                                   Expedited Amenti Opening Crisis Intervention Program Begins
                            tions and con ﬂict between these polarity extremes, will progressively escalate while      
                        Earth is sustained within the Trion/Meajhé Field Buffer Blanket between 2006-2012.       
                        It will seem as if the world has “divided itself into “good vs. evil”, with little space      
                        between the two opposing consciousness factions; sadly, each “side” of the polarity      
                        drama will perceive themselves as the “victims” and “good guys”, viewing the “other      
                        side” as the “evil, victimizing enemy”. During these coming difficult times, GA  will      
                        promote the necessity of Healing through recognition of our Common Divine Source.      
                        They will also teach of the Law of One Christos realities of the D-12 Pre-matter      
                        Divine Blueprint, through which all polarities and separations can be mended, and by      
                        which beings of every species, race and creed can tangibly integrate the One-Spirit      
                        through which all life is created and sustained. People are free to choose whatever per-      
                        spectives they desire; our choices and beliefs will create the experiential reality we will      
                 perceive within this mass drama. 
____________________________________________________________________________
If we choose to believe the drama is not real, it will simply engulf and consume        
us; if we acknowledge the challenges presented and believe only in their effec-                               
     tive, loving resolution, we will know the mastery of co-creative victory. 
____________________________________________________________________
 
    34.  2006-2012:  Meajhé and Trion Zones- Polarized Earth in Trion/Meajhé Field Sus-      
 pension to 2012 . Following the 2006 Three-Day Particle Conversion Period, por-       
 tions o f Earth and its populations co-resonant to the Inner Earth Bridge Zone Time           
 Continuum will remain in the stable areas of the 4.25 Trion Buffer Bubble Safe Zone,      
 which is referred to as the Meajhé Field,  until 2012 . Until 2012, the Meajhé Field         
 will be sustained by Level-9 Temporary Planetary Maharic Seal/D-9 Quatra Phase      
 Merkaba Vehicle , when final transition into the Bridge Zone time continuum will      
 take place.  Meajhé Field Safe Zones, or “ Meajhé Zones ” will provide a natural fre-      
 quency buffer to the Three-Day Particle Conversion Period frequency infusions and          
 will be the most environmentally and culturally stable areas of the globe during the            
 remainder of the SAC. Meajhé Zones will also provide environmental support to the                         
 progressive 12-Code DNA Template activation of Human and Indigo populations.          
 Portions of Earth and its populations co-resonant to the Phantom Matrix Sub-time         
 Distortion Cycle will remain temporarily protected within the less stable Trion Field       
 of the Trion/Meajhé Field Buffer Blanket, the portion of the Buffer Blanket that sur-     
 rounds  the more stable 4.25 Trion Buffer Bubble Meajhé Zone.  
          The Planetary Trion Field will provide temporary protection from the 2006       
       Three-Day Particle Conversion Period, and will to some degree buffer the transmuta-      
    tive frequencies characteristic to this event; it will protect these areas from Phantom            
       Matrix descent until 2012. Ideally, the Planetary Trion Field will be sustained by       
       Level-6 Temporary Planetary Maharic Seal/D-6 Hallah Phase Merkaba Vehicle       
       until 2012, when final transition into the Phantom Matrix time continuum will take      
       place via apparent regional Earth Changes.  Areas of Earth under Trion Field Hallah      
       Phase Merkaba protect are called “Trion Zones”. Earth’s SGs and portals in Trion             
       Zones, protected by the Trion Field Hallah Phase Merkaba, will have only a 6-dimen-      
       sional protective seal . Despite GA efforts to retain this protection, UIR forces may             
       compromise this Level-6 Temporary Planetary Maharic Seal to partially un-Cap the          
       Wormholes as early as 2005, which will intensify Earth Changes potentials in these               
       regions in 2005 and during the 2006 Three-Day Particle Conversion Period. Follow-                
       ing Earth’s 2006 passage through the Three-Day Particle Conversion Period, areas              
        under Quatra Phase Merkaba/Meajhé Zone protection cannot be intrinsically com-            
       promised by UIR activities. Meajhe Zones may suffer a small degree of temporary               
       instability if UIR infiltration of Trion Zones is extensive, but Meajhé Zones will re-              
       stabilize to complete the Bridge Zone time continuum shift in 2012.
           If UIR is successful in eroding the Level-6 Temporary Planetary Maharic Seal in            
    Trion Field areas, they will move forth with their intended Illuminati OWO agenda,      
    Frequency Fence and "First Contact" drama. In this case, populations within Meajhé      
    Zones  will be most protected from the effects of OWO progression. Beginning in            
    2002-2003, GA will provide the Indigo Planetary Security Team with information for
         
         549                                                                                                                    
                                                                                                                                                                                                                                                 
 

         Crisis Intervention Expedited Amenti Opening Schedule
public release, and eventually Safe Zone Progression Maps , pertaining to the geo-
graphical development of Meajhé and Trion Zone areas. The regional Quatra Phase
Merkaba Vehicles surrounding "Meajhé Safe Zones" will operate like '' invisible envi-
ronmental force-fields ." Populations can come and go through these areas unabated. 
With a bit of a practice, individuals with DNA Strand Template-4 12-Code activation 
or higher will be able to sense the electro-static boundaries  of Meajhé Zones. Those    
with lesser strand level, or less than 12-Code3), DNA Template activation will be 
unable to detect Meajhé Zone perimeters. Under most conditions, conventional sci-
entific instruments are not sensitive enough to multi-spectrum electromagnetic sub-
tleties to detect Meajhe Zones. The Quatra Phase Merkaba Vehicles of Meajhé Zone
regions will hold the natural "Divine Blueprint '' integrity of nine out of 12 dimen-
sional levels of the land, atmosphere and magnetic fields in these regions, creating
enhanced biological protection from UIR Frequency Fence, RIT, Psycho-tronic and 
Bio-warfare technologies. 
       The Planetary Shields in Meajhé Zone areas will hold higher frequency and
have a faster particle pulsation rhythm, which will make these areas seem " almost 
invisible " to Illuminati and UIR attentions. People with 12-Code activating DNA4 
will be instinctually drawn to Meajhé Zone areas via vibrational co-resonance  of the
biological/mental/emotional/spiritual bodies. Individuals carrying excessive DNA     
Template and consciousness distortions, such as Illuminati and Fallen Angelic races, 
or people carrying Fallen Angelic astral Tagging or possession, will experience varying 
degrees of biological disharmony and mental/emotional fatigue or agitation in     
response to Meajhé Zone frequencies.5
       Meajhé Zone and Trion Zone regions and the populations within them will 
exist “side by side”, each experiencing a different set of events and frequencies,
until their final separation in 2012 . GA general education programs will continue to
focus upon assisting people to regenerate the DNA Template, Bio-energetic Field and 
Spiritual Consciousness integrity that is needed to sustain the body within Meajhé
Zone areas. Meajhé Zone Indigo education programs will focus upon Crisis Interven-
tion “Trouble Shooting”, the advanced Planetary Templar Mechanics needed to sus-
tain the integrity of the Meajhé/Trion Field Buffer Blanket, coping skills for 
accelerated DNA Template activation, outreach programs to assist those in Trion 
Zones and preparation for physical GA contact. After the 2006 Three-Day Particle
Conversion Period, the GA, via the Indigo Team, will "put out the last call" for Emer-
ald Covenant Amnesty and Redemption Contracts . All Illuminati races  and 
Humans desiring to become free of Fallen Angelic manipulation and Phantom Matrix 
descent will have a final opportunity to "make it to the Bridge Zone." These efforts 
will continue until  2011 , when the last round of the "Final Con ﬂict" drama is due to 
unfold. 
35. 2011:  The Final Conflict Drama Begins –Invasion Attempt, “Wingmakers”, the
BeaST and the Shield.  Nibiruian Battlestar Wormwood,  if left untouched in its usual 
3657.8  year orbit, was is due to pass through the Asteroid Belt between 2008-2024; GA 
will slow Wormwood's passage and reduce it to fragments before Asteroid Belt inter-
section, producing likely cycles of intense but manageable meteor showers 2011-2015. 
Between 2008-2012 Planet Nibiru,  presently in Phantom Matrix Sirius A orbit on 
the "other end" of Wormwood’s reverse, "tilted" elliptical orbit plane, will undergo
pole shift and realignment of its natural orbit, returning to its organic position beyond
Pluto’s orbit in our galactic system. Return of Nibiru to its natural orbit will take place 
                          _____________________________________________
3.   12th of 12 sub-frequency bands in each Strand Template activated.
4.   Christos Divine Blueprint activation, with the full spectrum of 12 sub-frequency bands in 
      each DNA Strand Template activating.