39 
                                                                                                                                                                                                                             

     
      The Second Seeding  
more rapidly and with less effort, for you will learn to work with the natural
laws of energetic structure to which your consciousness is bound, instead of
working against these mechanics because your consciousness has yet to com-
prehend the forces through which it manifests.  
    The evolution of planet Earth is intimately connected to that of the
planet Tara, which is the original planetary mass out of which Earth emerged.
This means that the morphogenetic field of Earth was originally part of the
morphogenetic field of Tara (and both were part of Gaia's morphogenetic
field). In order for an energy structure to fully ascend through the 15-dimen-
sional scale it must assemble all portions of its original morphogenetic
imprint. The morphogenetic fields exist as tapestries of inter-woven energy
particles, composed of literal substance, and so the process of assembling mor-
phogenetic fields into their original pattern is the process of recombining the
portions of this energetic tapestry that have become separated from the origi-
nal, back into the original form of the energetic tapestry. Planetary ascension
is the reuniting of energy units that had been separated into various dimen-
sional frequency bands, pulling those energy particles back together by merg-
ing the frequencies within which the particles reside. There are natural
energy dynamics that govern the merger of multidimensional frequency
bands, part of which involves particles and anti-particles merging.  
    Particles and anti-particles are composed of units of multidimensional
sound, or tones, and within each frequency band there are base tones and
overtones. The process of merging particles and anti-particles in order to cre-
ate the merging of frequency patterns is the process of bringing together base
tones and overtones that emerged out of the same morphogenetic field.
When base tone and overtone merge, a resonant tone is created, through
which particle and antiparticle merge, and transmute into pure energy. They
return to the morphogenetic field carrying with them the new frequency pat-
terns they picked up from the Uni fied Field of the dimension in which they
appeared, which in turn expands and adds energy to the original morphoge-
netic field. When the particles and anti-particles are next expressed into
manifestation, they will appear within the next frequency band up, as their
rate of vibration was increased by adding the frequency patterns from the
dimension they just left.  It is through this process of building dimensional frequen-
cies into the morphogenetic ﬁeld, through the merging of particles and anti-particles,
that matter forms evolve up through the dimensional scale . Tara and Earth will
merge through this process, as Earth moves upward into the dimensional fre-
quency bands in which Tara's matter-body is positioned.  
     When the frequency bands of Earth and T ara merge, changes will take
place within the matter-body of Earth. New land masses will begin to rise in
the oceans, new waters will emerge in places where they were not. But this
process does not take place all at one. Planetary ascension takes millions or
billions of years. Planetary ascension takes place in  waves.  All planets evolve