12 Human Tribes  had been entrusted as Guardians of the knowledge
contained in the CDT-Plate that corresponded to the Tribe’s Planetary Star
Gate assignment.  The amnesiac Leviathan races , driven and covertly
manipulated into Star Gate territory conquest , progressively waged war and
claimed dominion over amnesiac Human nations , forcibly indoctrinating
Human l2-Tribes into docile compliance  to competing, twisted, Fallen
Angelic false historical, religious and, later, scienti fic creeds. The Indigo
Child Maji Grail Lines  have been the “ Keepers of the Sacred Founders
Emerald Covenant CDT-Plate Knowledge ” throughout our troubled and
progressively violent history.  
    All through this history of sorrow , competing legions of Leviathan
Illuminati families were motivated by their Fallen Angelic taskmasters to
attain possession of speci fic geographical regions and sites  corresponding to
the APIN systems. Only one or two “ Key Controllers”  in each of the many
Illuminati groups  learned that these areas held the Anunnaki Phoenix
Spiking Matrix . Even the Illuminati Key Controllers  were deceived, for
they were not told these sites were '' Anunnaki intended take-over points .''
They were told the lie that these sites were ''sacred and belonged to their
Creator Gods and Angels.'' Since the 9558 BC “fall of Atlantis,” churches,
synagogues, places of ''worship ,'' economic, governmental , and  public
social areas  were repeatedly built over, and around , areas through which the
Phoenix Spiking Matrix  would be run come the 2000-2017 SAC . 
    Many of the Phoenix Matrix territories were overtaken by competing
Drakonian agenda Leviathan Illuminati forces, who would usually destroy
the buildings of their competitors and erect their own edifices to their Fallen
Angelic effigies. At various times, the Anunnaki Fallen Angelics  of Nibiru,
Tiamat and Alcyone would use their Phoenix Matrix, NDC-Grid and NET,
to Cap the Falcon Matrix  wormhole of their Drakonian competitors. The
Drakonian Illuminati would then quest for the territories of the Nibiruian
Crystal Temple Network, successfully gain governing control over some of
the 24 Primary sites and use them to siphon energy from the NDC-Grid  in
order to '' blow the Cap back off '' of the Falcon  wormhole. Anunnaki and
398 
                                                                                    

                                                                                                 
                                                                                                                            
                                                                                                                  Spiritual Manipulation
Drakonian Illuminati factions continually warred over possession of these
“Sleeping Phoenix Spike Sites ” and Nibiruian Crystal Temple Networks ,
all attempting to position themselves appropriately, in preparation for the
''Big Party '' that the Fallen Angelics knew was scheduled to come during
the 2000-2017 SAC.  Our beloved America , as well as  Europe , and literally
all countries on the planet, have been carefully cultivated  through the
Illuminati Leviathan force family lines to reach their present state of
“civilization.”21 America was not “discovered”—it was ''seized'' by competing
factions of (Freemason) Pleiadian-Nibiruian Knights Templar-Anunnaki
and Drakonian-Nephedem  Leviathan Illuminati races, like many other
nations have been. When America was  ''discovered ,'' it was “time” to
prepare for the Big Party and “Sleepers Awakening .” 
      Here we are  today, still  amnesiac, still asleep...as our “Atlantian
Phantoms” emerge with us from the forced slumber of our ancient
Atlantian Nightmare . In the 1920s-1930s  the Zeta races of Phantom Earth
and neighboring Phantom galactic systems broke through the latest
Anunnaki ''Cap '' on the Falcon Matrix  wormhole. The Zeta conned
amnesiac Anunnaki and Drakonian Illuminati races into Zeta Treaty Deals.
In 1943 the Zeta tricked the Illuminati into using their covert control over
unsuspecting Human governments , to orchestrate the 1943 Philadelphia
Experiment , which the Zeta knew would activate the Phi-Ex Falcon
Wormhole APIN system . In 1972  the Pleiadian-Nibiruian Anunnaki
opened the Phoenix wormhole and began activating its APIN system. In
1983  the Zeta further motivated a now frightened and subservient Illuminati
force into the Montauk Project , through which the Phi-Ex/Falcon Matrix
wormhole was further  ''plugged into '' the Necromiton-Andromie
controlled Planetary Shields of Alpha and Omega Centauri. Through the
recent history earlier described in this writing, we have now emerged into the
Mass Drama of the forming of the UIR and their September 12, 2000, Edict
of War. What does this mean  to our world?  It means that the primary ,
once-opposing forces of the Anunnaki and Drakonian agenda legions have
joined with the Andromie-Necromiton force. They intend to combine their
collective, hidden, technological power  of the Montauk-Phi-Ex-Falcon and
Phoenix wormholes and the APIN systems, to ensure that Earth and its
peoples ''have a nice trip'' into the Phantom Matrix Black Hole Sub-Time
Distortion Cycle during the 2000-2017 SAC. The unspoken “motto” of the
UIR might be something like '' Have a Nice Trip... Join Us In the ‘Fall’ ...,''
and I’m not talking about “autumn .'' 
                                      
                                                          SPIRITUAL MANIPULATION              
      The reality of our present drama means that there are hordes of
amnesiac Illuminati Sleepers , ''Human Greeting Teams '' and '' just every-
day people ,'' that are presently the unsuspecting victims of Astral Tagging,
targeted Psychotronic mind control  or DNA bond possession . These are
mostly good-hearted, intelligent people, who think they are ''honoring their
 God, Angel, ET, government or science.'' They are being blindly guided
                           _________________________
                              21.   or might I say “Zombification?”    
                                399                                                                   
                                                                                                                                                      
                    

                                                                
                       
                        The Wall in Time and Atlantian Secrets of the Phoenix and the Falcon
through their chosen ''Pet Control Dogma '' (''Traditional'' or
''Contemporary,'' religious or scienti fic) into unknowingly playing  a
previously assigned role  in the advancement of the UIR Fallen Angelics’
Illuminati OWO Master Plan.  
   The really sad part  is that our race has been, step-by-step, forced,
seduced, deceived, tricked and cajoled into playing these  ''unholy '' roles;
even the Illuminati races,  whom '' anybody in the know likes to blame ,'' are
being victimized and denied the right of true data assessment and free-will
choice.  The Illuminati races within the infrastructure of the covertly
metaphysically motivated Illuminati World Management Team, who serve as
Fallen Angelic puppets, are being “played on” and manipulated by fear for
personal survival and a desire for acquisition of power to prevent pain and
create personal pleasure. These are the same motivations behind the actions
of the ''spiritual'' peoples of traditional and New Age affiliation, who think
worshiping an ancient book, or surrendering personal power to an external
''God,'' ''ET,'' ''Angel'' or ''channel'' is the ultimate expression of spiritual
development and will ''make everything all right.'' Fear, the ''Pleasure-Pain
Principle '' and Disinformation  are the common control elements  by which
Illuminati and Humans become easily misled into surrendering their power to
something outside of themselves. Once this ''outside source '' has your
power, compliance with the approval of that source becomes, implicitly,
the only way to feel empowered.  
    The Anunnaki-dominated New Age ''pseudo-Ascension '' spiritual
movement (most of it inspired by the ''Templar Melchizedek'' false ascension
teachings of Anunnaki’s Thoth, pre-Emerald Covenant Enoch, ''Archangel
Michael & Friends,'' ''Jehovah,'' ''Maitreya,'' ''Lord Melchizedek and spiritual
hierarchy,'' the Urantia etc....) inherently promotes a fear-based paradigm  of
''Light, Love and Pretend Away the Darkness '' dogma . These groups prey
on the spiritual longings  of Christians and Hebrew peoples, borrowing the
false ''Crucifixion of Christ '' story from Anunnaki & Drakonian “edited and
embellished” (see Council of Nicaea, page 315) traditional texts22 The fact
that the false “Crucifixion Story” has been so predominant in the founding of
so many cultures for the last 2000 years gives one some idea of just how
successful the Anunnaki have been in using the NET, NDC-Grid and
their manipulated Illuminati-hybrid Leviathan races to ensnare our minds .
Since the 9558 BC Atlantian “flood” was staged, such “ spiritual rape by
religious control dogma deception”  has been propagated in every culture  by
various competing Fallen Angelic/Intruder ET forces via “channeling” to,
and manipulation of, their amnesiac Illuminati races. Perversion  of the
once-Sacred Emerald Covenant Spiritual-Science Maharata-Templar
teachings that formed the 12 Global Freedom Religions that were
humanity’s heritage  from the Ancient of Days until Atlantis, has been done
as a s trategically planned and progressively implemented  element  of the
Atlantian Conspiracy agenda . Most people who succumb to these mind
                        _______________________                       
                    22.    It truly amazes me how many people are so attached to the Anunnaki-implanted false-
                                  hood that ''Christ was Cruci fied.'' You would think people who cherish all Jesheua was
                                            and stood for would be delighted and joyful to discover that he ascended via the Arc of
                                            the Covenant portal passage without a nail hole in sight!
                        400
                   

                                                       
                                                  
                                       Breeding a Final Conﬂict Army and Planetary Shields Reversal
control games are literally terri fied to face the facts of our present reality that
they have been led to believe exist, and so afraid to face reality that they
must defend at all costs the illusion of 3-D safety . Denial is one of the greatest
forms of fear, and it usually requires that the fear itself be denied . 
                             
                                                BREEDING A FINAL CONFLICT ARMY
                                            AND PLANETARY SHIELDS REVERSAL
      The “twist the true teachings” game was implemented by competing
Fallen Angelic legions for very speci fic reasons —long-term population
control  was one objective. “ Getting rid of the competition in the name of
defending your God ” is a tactic that has been, and still is being,  used  by
competing Fallen Angelic legions to turn factions of Illuminati and Human
populations against each other.  This has been done throughout recorded
history by competing Fallen Angelic factions, to secure Star Gate and APIN
Site territories  and to ensure that '' critical mass dominance '' of their chosen
Leviathan race  would be secured and ready  for the scheduled  2000-2017
''Invasion Party ,'' This is the same reason we have been told by both
Anunnaki and Drakonian pseudo-Gods to '' go forth and multiply ,'' in
conjunction with the falsehood  that “ birth control is a sin .” Along with this
ploy went the editing of the Sacred Teachings  that explained how birth
control is naturally achieved . And the Anunnaki “fail to mention” in their
false “We are your Creator Gods” propaganda that they intentionally caused
DNA mutations that increased female ovulation  in Human females from
the previous, natural, “ once every three years ” cycle to its present monthly
cycle . Why ? So we’d all be '' good little breeders '' to make sure they had the
needed ''head count '' on planet when the 2000-2017 SAC  came. Once
upon a time, when Earth was not being remotely run by mentally ill Fallen
  Angelic invaders , Humanity knew how important it was to keep a natural
  balance between and among species numbers; these balances were always
  respected. All species knew instinctively when “enough was enough,” and
      their bodies naturally complied by not permitting conception to occur .
    Human races had the ability to consciously choose whether or not to
  conceive once every three years,23 and parents knew who the incarnating
  soul would be and held memories of other lifetime relationships with the
  soul.  
       Our races have been deceived into utterly destroying the once-natural
balances of life on our planet  in order to raise an amnesiac , easy to covertly
  direct ''Fallen Angelic Inside Invader Force .'' If there are enough Human
   bodies on Earth carrying the natural Planetary T emplar DNA  Security Codes
 and the DNA  T emplate can be altered to run the Security Code frequencies            
into the Planetary Shields in reverse sequence during the SAC, Earth’s
  Planetary Shields  will fully reverse  their natural spin and polarity . Full
     reversal of Earth’s Planetary Shields will permit Earth’s Shields to merge with
     those of a Planet in the Phantom Matrix. Over-breeding  has produced a
                  massive population. The “ Checkerboard DNA Mutation ” has reversed the
               Human DNA Template Security Codes and personal Merkaba Fields (which
                       _____________________
                        23.    In even earlier days, it was seven years.
                              401
                                                                                                                                                                                                                                         
  

                                    
      
              The Wall in Time and Atlantian Secrets of the Phoenix and the Falcon  
         
               give Planetary Shields access), and we have been denied all memory and
           knowledge —most of us don’t even know that Earth’s Templar, Star Gates
             and Planetary Shields exist. Sounds like the ''perfect set up ,'' doesn’t it ? But
            the positioning of our race to ful fill the Fallen Angelic/Intruder ET Halls of
           Amenti Hijack Master Plan doesn’t stop here. Fortunately , the solutions to
             our rather massive  contemporary problems are not nearly as complex as the
                                  problems   themselves. RRT   Biotronic Technologies and   Masters   Planetary
               T emplar Mechanics  are the tools through which we can set ourselves, and
                  Planet Earth, free.  
                                       
                             
                                        402