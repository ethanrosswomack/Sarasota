23 AD - Essene Divide
325 - Council of Nicaea
608 - Arthurian Grail Quest
1244 - Albigensian Crusade
1500 - Ameka Crusade
1750 - Nibiruian Re-acquaintance
1916 - Zeta Surveillance
1930-1940 - Zeta Treaties and MJ-12
I983 - Orion Intrusion
1992 - Pleiadian-Sirian Agreements
November 1999 - Centaurian-Necromiton Intrusion
January 2000 - SAC Rebellion
July 5, 2000 - Treaty of Altair
September 12, 2000 — United Intruder Resistance (UIR)
February 2001 - Grid Spiking Campaign
2003 - Intended Dimensional Blend Time Rip
2004 - Intended Frequency Fence
2008 - Intended Pole Shift via Nibiruian Battle Star and NDC-Grid
2012 - Intended Resistance Re-settlement & Inner Earth Crusade
330
                                         

                            Note On 12-Strand DNA Template Activation:  BE AWARE
      NOTE ON 12-STRAND DNA TEMPLATE ACTIVATION:
                                          BE AWARE
                                 Averting the Seduction of the “Quick Fix” and “Ego Pat”
• No Human on Earth  at this time has true 12-Strand DNA Template  ac-
     tivation or consummation , as the Planetary Shields cannot yet sustain bi-
     ological presence that holds continually activated D-12 frequency. 
     Distortions in the Race Genetic Imprint caused by the Planetary Shield
     severely block natural 12-Strand DNA Template activation, even if the
     Planetary Shields could sustain 12-Strand Activated Biology. Without
     consistent  use of DNA Template Bio-Regenesis technology and related
     Core Template Kathara Healing modalities, no human  on Earth at this
     time would  achieve genuine  12-Strand activation  during the  contemporary
     evolution cycle.
• Competing false 12-strand DNA activation programs are presently being
     run via unsuspecting New Age & UFO Movement “Channels & Contac-
     ees,” by Jehovian¹ Dolphin People Anunnaki and Pleiadian-Nibiruian²
     Anunnaki-Drakonian-Reptile hybrid races . The largest False DNA Ac-
     tivation - “Ascension” Program is conducted by the '' Alpha-Omega  Tem-
     plar Melchizedek Anunnaki-Drakonian Alliance ," which is composed of
     Centaur & Drakonian-Anunnaki races of Density-2 & 3 Alpha Centauri  and
     Omega Centauri,  the Necromiton-(Beetle-Reptile)-Anunnaki hybrid
     race of Andromeda3 and several other related Fallen Angelic Collectives
     following the Omicron-Drakonian-Zeta-Illuminati  “One World Order”
     dominion agenda. One of the most prominent expressions of the Alpha-
     Omega-Centaurian-Andromie Anunnaki-Drakonian-Necromiton col-
     lective refers to itself as the '' Archangel Michael '' Matrix,  a Bio-neuro-
     logical Mass Mind-control Program  run via the Alpha-Omega
     Collective, that is literally “broadcast into Earth’s airwaves to unsuspect-
     ing channels” from Parallel Earth  through the NDCG . False 12-Strand
     DNA Activation Programs are geared toward  ''Monadic Reversal '' - re-
     versing the Fire Letter Sequences  in the Human DNA Templates to cre-
     ate Reverse Sequence 11-Strand Activation  in humans, so human DNA
     will assist the Fallen Angelic mission  of gaining control of Earth’s Plan-
     etary Shields & Star Gates on a reverse-11 activation4 during the 2000-
     2017 SAC.
• Fallen Angelic and Illuminati Human Leviathan races use the seduction of
     false claims of “Easy DNA Template Activation” and false promises of As-
     cension without providing the details of the mechanics  by which these dy-
     namics naturally take place. If we know the mechanics  we can detect when
     they are being intentionally misused to orchestrate Anti-Christiac Do-
     minion agendas. The tactics of false “Quick-Fix Claims” and false promis-
     es are further coupled with false “sugar and spice,” in which our egos are
__________________
 1.  Sirius A, Arcturian, & ''Galactic Federation"
 2.  Anu-Seraphim Aquatic-ape-hominid
 3.  ''Andromies" &''Men-in-Black"
 4.  34-CCW/21-CW Nibiruian Merkaba                                                                               
333 
                                                                                                      

   
                     
                          The Atlantian Conspiracy and Roundtables
    
     fed as we are told “what we want to hear” and “how great and Beloved we
      are,” while being covertly “railroaded right under our own noses.” If we do
      not “fall for” the age-old “Quick-Fix” and “Ego-Pat” Seductions, we can
      avert Fallen Angelic and Illuminati manipulation tactics and learn how
      things really work , so we become empowered to set ourselves, and assist oth-
      ers, too to set themselves free. We can “Activate our 12-Strands of
      DNA,”5  but it takes work, a labor of Divine Love, and it requires Divine
      Sacred Science knowledge .
  • DNA Template and Kundalini Activations do not occur via “wishful think-
              ing” or “hopeful  spiritual intention ”—they   are  processes  of    natural  Bio-Spiritu-
     al Creation Physics , which occur via educated, conscious direction of
     energy and genuine Spiritual Wisdom. There is a natural Divine Right
     Order of energy mechanics that governs the manifestation of conscious-
     ness in biological form; the mechanics of this order must be understood
     and appropriately applied if one expects to attain genuine, essential , Bio-
     Spiritual Mastery.
      
                        __________________________         
           5.   24-48 Strands for Indigos
         334