8 AD 100
  -21 AD 101
8% of the races 44, 52, 88, 117, 123,125, 
                  130, 134, 144, 160, 179, 209 
8,400 BC 312, 321, 330
8,900 BC 312, 321, 330
800,000YA 55, 56 
     -55,000YA 55 
8-21 102
840,000YA 51, 55, 63
846,800 BC 271,272 
848,000 YA 100 
848.800YA 48, 50, 328 
849,000YA 50, 51
      -800,000YA 50 
850,000 YA 45, 48, 50 
      -848,800YA 48 
8835 YA 74, 75 
8-strand DNA 10,
9540 BC 320 
9,558 BC 320, 330 
9,560 BC 320, 330 
900,000YA 50 
906 BC 323 
950,000 YA 45,46
9,540 BC 86
9558 BC 244, 271, 312, 313, 318, 349, 355
562                
  389,393, 394,396,398,403,422,
             426,
9558 YA 74 
9560 BC 312, 314, 325, 338 352, 354, 355, 
             365, 378, 390, 392,
9560 BC-9558 BC 353 
9560-9558 BC 394
A
Abadan, Iran 370, 376 
abduction 131, 139, 178 
    consensual 134
    for hybridization experimentation 131              
    missing fetus pregnancy 235
Abraham 324 accretion level 149-183 
Activation 157
    Codes 16 
Adam and Eve 6
    see also Biblical stories 
Aegean 366 
Aeiran, see Root Races 
Aethien 264 
Aethien-Mantis 368 
Afghanistan 377
    UIR plans to rule 377 
Africa 56, 377 
Agartha 271 
Agartha, see Inner Earth
agendas
    Anti-Christiac 243 
    Anti-Christian 312 
    Anti-Christos 313
    Anunnakis to destroy the Human race 243  
    Anu-Seraphim Anunnaki Race Supremacy
         world dominion 244
    Atlantian Conspiracy 318
    Drakonian 246, 317
    Drakonian-Centaur-Necromiton-Andromie     
             Anunnaki-hybrid dominion 244
    Drakonian-Zeta 257
    Emerald Covenant peace treaty and
             freedom 250
    fear-based 179
    Founders’ Emerald Covenant freedom 243      
    Guardian 134
    invasion 257
    Jehovian 317
    Jehovian One World Order dominion 245     
    Luciferian 317
    new Dracos-Zeta 141
    old Zeta 123, 130, 234
    One World Order 317, 319
    One World Order Earth dominion 250
    United Resistance 250
Agratath, see Inner Earth
AIDS 252
Akashic Record 206
Akhenaton, see Pharaoh
Alanians 21,45
Alaska 359, 366, 404
Albigensian Crusade 316, 325, 330
Alcyone 35, 65, 69, 71, 72, 83, 88, 98, 99,
              100, 115, 127, 128, 142, 143, 187,
              203, 206, 233, 244
     as the primary sun of our solar system 115
                                         Index, Volume II

Index, Volume ll   
      see also Pleiades
Algeria 375
ALL 428
Alnitak-Orion 360
Alpha Centauri 245
Alpha-Centauri Marduke-Necromiton-
                Anunnaki 320
Alpha-Omega
    Centauri 242
     Templar Melchizedek Anunnaki 256, 258,
         260
Alpha-Omega-Centauri 327
Altair 266, 371
Ameka Crusade 325, 330
Amenophis, see Pharaoh
Amenti 52
       Activation Cycle 188
       Ascension Program Schedule 201-229, 343
       Halls of  9,11, 50, 54, 65, 66, 70, 105,
                  110-119, 142-143 162-184, 235
                      Sealing of 19-24
       Rescue Mission 6
       Seal of 28, 30, 33, 50,52, 105, 134, 205
       Secrets of 1, 105
       Sphere of 7-26, 27-29, 50-55, 105, 107-
                110, 117-120, 124-125, 130, 135-
                140, 142-143, 168-180, 185-229
                    distortions in 94
                    merging with 16
                    security seal of 72
      Staff of, see Blue Flame
      Temple-Generator Complexes 253
      Transmission of 1998 1
America
    real founding of 393-397
American Revolution 317
Amnesty Contracts 379
Amonites 7
Amorea, Hall of 28
Andes Mountains 56, 217, 228
Andromeda 36, 50, 51, 53, 61, 72, 74, 222,
                  223, 242, 244, 250, 317, 360, 379,
                  471
      Association of Planets in 51
      Council 191
      Federation of Planets 97, 141
Andromie
    -Necromiton 392
Andromies 177, 191, 250, 318, 366
     -Rigelian Coalition 374, 376
Angelic
     Kingdom 197
Angelic Human 292, 304, 308, 318, 320, 321,
                 322, 327
    1728 selves 297
    Christos Divine Blueprint 290
    Heritage 289
    Race 289
    reincarnational heritage 297
    Sacred Mission 292
Angelic Human evolution, Fourth Round 285
Angels 252
Angular-Rotation-of-Particle-Spin, see ARPS
Ankhesenamon 95
Ankhesenpaaton 95
Ankhi 91, 93, 94
563    assassination of 94
ankhs 62, 64, 72, 73, 74
Annu, see also hybrids, human-Anunnaki
Annu-Elohim 242, 265
    Anunnaki 242
    Anyu 265
Annu-Melchizedek 311, 312, 319, 320, 321,
                 323, 324, 390
Anunnaki Nephilim 360
Leviathan 390
Midianite-Hyksos Kings 321
see hybrids
Urantia 319
Annunaki 411
Antahkarana Primal Life Force Current 301
Antarctica 366
Anteres 371
anti-particle 453, 458
       double 108
       universe 10
Anti-Particle Universe 296
Anuhazi 262, 264
Anu-Melchizedek
      Leviathans 390
Anunnaki 312, 318, 321, 325, 327, 339, 345
                  350, 357, 370, 380, 384, 393, 396
      Defection 384
      Luciferian Covenant 352
      Mind Control 395
      peaceful co-evolution with humans 243
      see also Sirian
Anu-Seraphim 242
      Alpha-Omega Templar Melchizedeks 244
      Anunnaki 252
      Pleiadian Samjase Anunnaki 244
Anyu 265
APIN 366, 367-385, 388, 392, 394, 395,
                 397,  404, 405, 408, 414, 417, 418
                 420, 421, 431
       Falcon 380
       Phoenix 375
       Serpent 376
Aramatena 308, 368
    -Lyra 279, 372
Arc of the Covenant 43, 50-67, 71-74, 82-
105, 120-121, 142-143, 185-202,
313, 314, 320, 321, 322
announcement 193
Guardians of 57
seal on 135
sparking of 235
transfer of guardianship from Egyptians to
                      Hibiru Cloister 96
Archangel Michael 244, 258, 360, 370
    Nephilim-Nephite collective 256
Arcturian 36, 51, 223
     Federation 97
     mother-craft Ashalum 234
Arcturus 242, 244, 245, 379, 417
Arihabi, see Christs, Three
Arizona 188
Armageddon 325, 345, 378
ARPS 428, 429
Ar-Ratoth, see Agartha
Arthurian Grail Quest 330
artificial Christ Consciousness Grid 135

Aryan 21, 22, 24, 28, 31
Ascension 395
real 424
ascension 8-14, 18, 24, 30-44, 52, 62, 98,
           100, 105, 106-121, 137,138, 188, 
           189, 213, 239, 461 
    and DNA mutations 482
    codes 265 
    cycle 66, 70, 111 
              closes 228
              dynamics 463-492 
              of 196 BC-4230 AD 67 
     do it while it’s easy 229  
     false 421 
     mass 104
     of groups and couples 170 
     process of 39 
     schedule 199-229 
     science of 67 
     self-directed 258 
     stopped by suicide 42
     to Heaven 42 
     transport route 171 
     waves 40
Ashalum 234 
Asheville,NC 359
Ashtar Command 244, 256, 258, 327, 376,
                  379, 380, 419 
Asia 368, 377 
asteroids
     near-misses 122
Astral
    identity 37
    projection 79
Atlania 28, 33 
Atlanians, see Second Seeding
Atlanta, GA 359, 409 
Atlanteans, see Third Seeding 
Atlantian 261
    Conspiracy 320, 327, 356
             and Roundtables 310-320 
             Progression of Major Events 319 
     ﬂood 244
     Holocaust 319, 330
Atlantian Pylon Implant Network, see AP1N 
Atlantian Spikes 394 
Atlantic 56, 359, 366, 377, 430, 431 
     marine disturbances in 381 
Atlantis 28, 33, 56-67, 71-73, 83, 86, 87,
                  311, 314, 315, 316, 317, 320, 353,
                  367, 380, 389 
     Islands of 64, 71, 72 
     Nohassa 396 
     Rising 113
     sinking of 32,63,73, 134, 142 
     three Primary nations 389 
Atlas Mountains 375 
Atomic Transmutation 258 
Aton 89
     Aton-a, see Ra
     Atonist movement 89 
auric field 24 
Australia 366, 368
authority 67
avatar 88, 88-109
564                        Index, Volume ll   
birth of #1 189, 193 
birth of #2 191, 193 
birth of #3 194, 197
birth of #4 209, 212 
birth of #5 215 
birth of #6 218 
birth of 7th-level 189 
false public claims to be 194 
Sananda 99 
see also Christs, Three
six silent 186, 193-197, 478 
when soul enters the infant body 193 
Aveyon-Lyra 279 
awakening 249
Axiatonal and Ley Lines, see ALL 
Axiatonal Lines 342, 348, 357, 367 
Axious 34
axis tilt 86 
Aya 95
Ayrians, see Root Races 
Azar-Azara 7, 233
Azurite 264
   48-Strand DNA Template Angelic    
            Hominid 262
 -Amenti Galactic-Planetary Templar  Security     
            Team 276
    Council 98, 99, 104, 122, 233 
   see Ra
   Universal Templar Security Team 256, 275,  
 302
B
Babble-On Massacre 312.322,330 
Babylon 312 
Babylonia 322 
Bahamas 390, 431
Battlestar 245, 247, 251, 253, 254, 314, 327,    
                 375, 387, 415 
        see also Nibiru 
beam ships 136, 139 
Beast 422
Bermuda Islands 390, 396, 409, 429 
Bermuda Triangle 354 
Bethlehem 99 
Bhrama 272
Bible 245, 315, 322, 324, 369, 407 
Biblical stories 6, 26, 42, 51, 103, 239,461 
Big Brother 361,364 
bi-location 235 
bin Laden, Osama 376, 408 
    Falcon agenda 377 
    UIR affiliation 377
bio-neurological perceptual block 211 
Black Budget 361 
black hole 388, 397 
black holes 5, 167, 359, 420 
Black Sea 56 
Blow-Up Charts 434-?? 
Blue Centaurs 360
Blue Flame 13, 14, 15,17, 20, 30, 31, 33, 34,     
                    53,57,61,72, 74, 86, 96, 100, 
                    117-120, 134, 142, 143, 170, 185,
                    194, 200, 238
     Melchizedeks 98
     Speakers of the 32, 33
                                          

Index Volume II
Blue Oxen 371, 414
Blue Wave
   Infusion 207, 210
body
   emotional 21
   immortal 42
Body-Snatching 385
Bolivia 430
bonding
   contract 196
Bosnia 251, 346
Boston, MA 359
Boulder, CO 409
Bra-ha-Rama Maji 274
brainwashing 125
Branch Davidians 413
Breanoua 263, 276
Breanoua 271, 272
   see also Cloistered Races
Breatherian 266
Brenaui 422
Breneau 19, 34, 48, 50, 233, 262, 265, 275,
               303
    Rishi 7
Bridge Zone Project 142-179 187 199 225
                  234 239, 240, 305, 339, 379, 388,
                                    461, 462, 467, 483
conditions for success 179
how you can help it succeed 168
mechanics of 145, 160-168
use of to avoid less favorable futures 176
Brigijhidett 7
Bruah 311, 319, 320
Bruah-Atlantis 317
    Annu-Melchizedeks 321
Buddha 251
C
cancer 252
Carpathian Mountains 56
Caspian Sea 366
Castle Rock V ortex 346
Cathars 316
Catheri 325, 328
Caucasus Mountains 215, 217, 320, 321,
Cave of Creation 8
CDT-Plate Translations 398
CDT-Plate translations 241, 325 414
cellular
    memory 149, 156
    transmutation 457, 477
Celtec 315, 321
Celtics 320
Centaur 245, 392
Centauri 370
Centaurian 360
Centaurian-Necromiton Intrusion 326, 330
Centaurians 371
Central America 366
Central Creative Source 12,42, 69, 80, 107
                      451
Ceres 3, 6
Cerez 264
Cerez-Seraphei-Seraphim 368
Cetaceans 264 
chakra 21, 458, 476
565 
     base (1st) 19, 35
     Earth’s, see vortices
     heart (4th) 21, 35
            blockage of 124
     higher centers to activate 184
     sacral (2nd) 35
     solar plexus (3rd) 35, 77
Changing of the Guard 189, 190
Channeling 317
channeling 312, 336
     use by Anunnakis 380
Charleamea 235-236
Charts
AmentiAscension Program 436
Recent History and Current Events 435
The Seven Seals 438
The Six Silent Ascension Avatars 438
Time Continuum Progression 440
Time Mechanics 439
Time Shift Continuum Progression
            I Phantom Earth 411
Checkerboard DNA Mutation 401
Checkerboard DNA Reversal 405
Checkerboard Mutation 259
Chemtrails 252
Chental 234
Chihuahua, Mexico 408, 429
Chile 430
China 103, 251, 346, 377
Choosing Your Future 450
Chosen Ones; 97, 98, 252, 314, 317, 318, 322
                   326
Christ Consciousness 187, 188, 259, 304
Christiac Freedom Agenda 371
Christianity 31
      distorted teachings of 103
      inﬂuence from Templar-Melchizedeks 98
Christos Avatar 302
       Integration 302
Christos Current, see Universal Maharata
               Current
Christos Identity Integration 301
Christos Realignment 278, 280, 281-284,
               286, 288, 292, 293, 303, 304, 305
               308, 314, 316, 318, 328
Christos Reclamation 328
Christs
     Jesus 84, 99, 100
               see also Christs, Three, Jeshewua
     Three 96-04, 251
               Arihabi 101-102
cruci fied 102
in India 102
not avatar 100
resurrection of 102
               descending lines from 102
African 103
Celtic 103
Egyptian 103
French 103
United States 103
              Jesheua-Melchizedek (Jesheua-
                               12) 99, 136, 314, 323
                             as true savior of the                                         
                                           Hebrews 102
              ascension of 104

                                                                                                             
 
in India 100-101
in Persia and Egypt 101
sacred procreative rites of 103
Jeshewua-9 (Jesus) 100, 102-104
birth not Immaculate 100
in Egypt 101
in France 101
in Nepal, Greece, Syria, Persia
           and Tibet 101
Church of Rome 323, 325
     in filtrated by Drakonians 315
civilization
     sudden appearance of new structures 183
Classi fied Document 344
cleansing 240, 462
climate 22
     change 45, 51
Climatic Disturbances 429
Cloaking Protection Field 362
Cloaking Shields 352
Cloistered Races 9-19, 50, 69, 75
       Breanoua 10, 17, 21, 28, 29, 44, 56, 78,
             82, 84
                  Second infusion 18
       Five 10, 17, 56
       formation of 15
       Hibiru 10, 17, 24, 28-31, 43, 44, 47, 56,
                 78, 82, 84, 274
                       evolutionary advantage of 76
      Melchizedeks 10, 17, 29, 30-34, 47-48,
              52, 56, 57, 62, 63, 64, 82-108, 195,
              266
                  25 families 31, 97
                  birthing wave 88
                  Essenes 31, 96-105
                  Templar 31, 35
      Palaidorian refers to the Five Cloistered Races
      Ur-Antrians 10, 17, 21, 28-30, 44, 55-57,
                   82, 84
      Yunaseti 10, 17, 84, 195
clones 170
Code of the Blue Nile 272
common control elements 400
consciousness 25, 35, 39, 79, 80, 452
and frequency patterns 149
evolution of  76, 148
merging with anti-particle double 93
moving through time matrix 148
now-moment stream of 151
polarization of 412
rapidly restructuring 155
Contract Bond, see bonding, contract
Copiapo, Chile 431
Core Manifestation Template 296
Core Scalar Template Dynamics 351
Co-resonant Continuum Alignment 288
Council of 12 417
Council of 24 Elders 417
Council of 9 417
Council of Nicaea 315, 324, 330
Covenant of Palaidor 6, 51, 105, 271
CPNs 367
Creation Physics 351
Crisis Intervention 255
Crisis Intervention Program 256, 335, 346
Cro-Magnon
                                                                                                                          566      
      
                   Index, V olume II
  
    -l  390
     -2 390
     -3 390
     -4 390
cruci fixion 102
Crying Statues 251
crystal 62
     Body 456
     Earth’s D-1 Iron Core 126
     generator 63, 65, 72, 73
               explosion like atomic bomb 63
     gold core
               of Sun 132, 143
               of Tara-Earth 128
     seals 477
     Seed 473
star 473
Crystal Pylon Networks, see CPNs
Crystal Pylon Selenite Rods 418
Crystal Pylon Temples 269, 271, 278
Crystal Temple Networks 348
Cuba 390, 431
Cue Sites