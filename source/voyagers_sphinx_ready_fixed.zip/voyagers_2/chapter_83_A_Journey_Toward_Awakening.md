83 
                                                                                                                         
                                                                                                                                                                                                           
        

                  A Journey Toward Awakening
excessive genetic deviation, so the morphogenetic fields of these three groups
were chosen for re-alignment through Alcyone.  
    It is important to note that the genetic deviations carried by these groups
were not inferior or “bad;” the deviations simply would have taken those
aspects of humanity on a different evolutionary course. This would have
eventually redirected the entire course of human evolution, and the original
Turaneusiam 12-strand DNA package would no longer be available to the
human lineage of Earth. The 12-strand package is one of the highest genetic
imprints within HU-1 and HU-2 for it allows full transmutation out of matter
and can embody the consciousness of a 12-dimensional oversoul when the 12
strands are fully activated. Very few biological forms possess this potential.
Humans carrying the lineage of the deviated genetic codes are in no way infe-
rior to other human strains, and as long as excessive deviations are not
allowed to alter the original Amenti morphogenetic field, those races do not
pose a threat to the human lineage. As you will see, through the course of this
chapter, the guardian races have insured the integrity of the human genetic
imprint, and have also made it possible for the races deviating from that
imprint to return and ascend through the Sphere of Amenti. The Hebrew
morphogenetic field was realigned and entered into the Sphere of Amenti
about 2000 years ago with the birth of the man who has come to be known as
Jesus Christ, and the Annu-Melchizedeks and Templar-Annu were reentered
into Amenti about 3,300 years ago with the birth of the Pharaoh Akhenaton/
Amenophis IV .  
    At your present point in history all of your races are part of the Amenti
morphogenetic field, and all of you are in the process of healing and assem-
bling various DNA configurations.  We do not want the more immature among
you to misuse this information on genetic lineage as grounds for unfair and discrim-
inatory attitudes toward other members of   your  race, for such discrimination has no
intelligent basis and is groundless.  We would also like to mention here that of
the Third through Seventh Root Races and their Cloisters, each of the seven
sub-races within each race carries one of the race strains from each of the
seven Root Races. For example, those of the Aryan Root Race affiliated with
the Hibiru Cloister, who carry the gene code imprint for the white skinned
races, have within their seven sub-races a white skinned sub-race with a dom-
inant Aryan or Hibiru Cloister gene, a black skinned sub-race with a domi-
nant Euanjhechi or Yunaseti Cloister gene, a yellow skinned sub-race with a
dominant Muvarian or Melchizedek Cloister gene, a brown skinned sub-race
with a dominant Lemurian or Ur-Antrian gene, and a red skinned sub-race
with a dominant Atlantean or Breanoua Cloister gene. There will also be two
additional sub-races which bear the primary skin color of their Root Race and
Cloister, who carry a dominant gene from the First Polarian and Second
Hyperbornean Root Races of Gaia. Each of the primary Root Races and their
Cloisters have this inter-mixed sub-racial division. The seven sub-families