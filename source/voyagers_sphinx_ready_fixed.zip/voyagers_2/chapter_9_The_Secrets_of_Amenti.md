9 
                                                                                                                      

                    
                     The Secrets of Amenti
 DNA  strand to which they were assigned. Each race had eight strands of
 DNA  manifest within the body structure. The five Cloistered races did not
 possess gender, nor did they originally possess the degree of matter density
  with which you are familiar. Density of form developed over time throughout
   the course of their evolution on Earth, between 250 million and 25 million
 years ago. The five Cloistered Races were:  
 1. Ur-Antrians —brown skinned-strand #2  
 2. Breanoua— red skinned-strand #3  
 3. Hibiru —white skinned-strand #4  
 4. Melchizedeks —yellow skinned-strand #5  
 5. Yunaseti —black skinned-strand #6  
           The Cloistered races populated the Earth for many generations, creating
   various racial mixtures through which many of the lost souls of T ara were able
 to ascend. This period of great civilization became known as the Second
    W orld (250-25 million years ago) within your present Native American Cul-
 tures. Many of these souls ascended. Those who digressed returned to the
  Sphere of Amenti to re-birth on Earth in the particle universe as members of
  the Root Races. The First World represented the original Turaneusiam cul-
         tures of T ara (560-550 million Y A). The Palaidorian Cloister races left no
        remnants in your present world, for they evolved within the faster moving
        time bands of Earth, within the anti-particle universe. The morphogenetic
          fields of those races were then drawn into your particle-Earth and out of these
  came the next evolutionary stage.                  
                                    The First and Second Etheric Root Races of Gaia
                                                             Rescue Mission Stage 2
                                                           25,000,000-20,000,000 YA
     Before manifestation into embodiment on your Earth the five Cloistered
          races divided into two groups. One group held the DNA  imprint for 1/2 of
  the first strand of DNA (which corresponded to dimension-one frequencies),
 the other group held the remaining 1/2 of the first strand. This created polar-
 ization and gender within the Cloistered Race morphogenetic field. Both
 groups held the dimensional codes/strands of 7-12. These two groups were
 seeded on Gaia, the seventh-dimensional/HU-3 counterpart to T ara and
    Earth. These two races were the first two Root Races,  the Polarians of Gaia
    and the Hyperborneans  of Gaia’ s antiparticle double. These beings were of a
  much less dense, or “etheric” nature, but through their evolution on Gaia (25