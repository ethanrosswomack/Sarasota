90 
 
                                                                                 

                                                                                 
                                                                                                               
                                                                                                               
                                                                                                              Pharaoh Akhenaton
enter the Annu-Melchizedek morphogenetic field back into the Sphere of
Amenti, see that the Halls of Amenti were opened, then oversee the training
and ascension of all individuals whose genetic codes would allow them to
pass through the fifth-dimensional frequencies into Tara. Serres-Egyptians,
and all of the other races were to be considered equally for this process, but
Akhenaton, from the beginning, showed extreme favoritism toward people of
Annu descent and an unwarranted prejudice toward those of Serres-Egyptian
lineage. To appease the Priests of Ur, Akhenaton would allow select Serres to
enter into the initiation programs at Akhetaton, but then systematically omit
them from the final stages of training, so the opportunity of program comple-
tion and ascension was denied. The Priests of Ur and the Elohim created an
alternative plan by which the Melchizedek Cloister Keepers of the Blue
Flame, who held strategic  positions  within  Akhenaton’s inner council, would
be permitted to conduct ascension rites under the direction of the Priests of
Ur, without Akhenaton’s knowledge of their activities.  
     The Keepers of the Blue Flame were headed by the primary Flame
Holder, a women named Phaelopea, who for long held the rank of High
Priestess of the Atonist temples at Akhetaton. The inner circle of the Flame
Keepers was composed of General Haremhab, head of Akhenaton’s strategic
armies of the north, the head physician of Akhenaton’s court and his illegiti-
mate, elder half brother Sabatoth, and his fourth wife Ankhi (historically
known as Kiya). There were approximately 200 other members of the Blue
Flame Melchizedeks among Akhenaton’s ranks, who had originally been sent
to support him in his efforts. As his personal prejudice and intolerance of the
Serres-Egyptians had colored his ability to ful fill his ascension duties appro-
priately, the Blue Flame Melchizedeks were assisted by the Elohim to carry
out ascension by night, using an alternative portal passage to the Great Pyra-
mid of Giza. Through the alternate route, the Keepers of the Blue Flame
would not have to pass through the portions of Inner Earth through which
Akhenaton conducted his ascensions, so both groups could ful fill the ascen-
sion contract, while circumnavigating Akhenaton’s personal character lean-
ings. From 1363 BC to 1362 BC the Keepers of the Blue Flame lead qualified
Serres-Egyptians and others to the Arc of the Covenant at Giza, successfully
ascending several hundred individuals not of Annu descent through the
Halls of Amenti.  
      In 1362 BC the inevitable occurred, and Akhenaton discovered the activi-
ties of the Keepers of the Blue Flame, and charged identi fied members with
treason, and sentenced them to death. Among those sentenced to die were his
fourth wife Ankhi and his half brother Sabatoth. With the assistance of the
Elohim, these individuals were exiled to Giza and placed under the protection
of a select group of Serres-Egyptian priests who had been permitted to know of
the secrets of Amenti. Akhenaton’s fourth wife Ankhi had produced a son for