92 
 
                                                                                                                

                                                                                                             
                                                                                                           Pharaoh Akhenaton
          
    Prior to this event, the Elohim and Priests of Ur had intended to orches-
trate the ascension of Akhenaton, his first wife Nefertiti and their daughters.
This was scheduled to occur after the seat of power had been transferred from
Akhenaton to his fourth wife Ankhi and their son, through whom the half
brother Sabatoth would acquire the throne until the avatar child came of
age. The Elohim intentions were to blend the Atonist and Amonist perspectives
together around the original Templar teachings of the Law of One, through which 
Egypt could be uniﬁed and serve as a model for preparing the races for ascension.
Following the closing of the Halls of Amenti, this plan was no longer feasible,
as the royals could not ascend to Tara while the Sphere of Amenti remained
split in two, so alternative measures had to be taken. The Sirian Council had
arranged for the royal family to be taken by starship to Sirius B after the trans-
fer of earthly power, but Akhenaton did not live long enough to ful fill this
vision.  
    The Elohim and Priests of Ur attempted to council Akhenaton following
the closing of the Halls of Amenti, but he misunderstood their attempts at
astral communication to represent attempted manipulation by evil forces.
Having no memory of the Giza events, Akhenaton was swayed by the Priests
of Ur, during physical contact, to allow the Flame Keepers to go free. He was
further advised to continue with the plan to allow Ankhi to be appointed as
wife number one so the child would be given legitimacy as the next heir to
the Pharaonic line. Events became a jumble of confusion as Akhenaton,
fearing treason at every turn, chose to disregard the requests of the Priests of
Ur that ascension practices be stopped. This request was given in good mea-
sure, as anyone attempting to ascend through Amenti while the Sphere was
broken into two pieces, would find their soul essence fragmented into D-2
and the upper portions of D-3. Thinking that he was sparing the Annu from
manipulation attempts by the Priests of Ur, Akhenaton used the Staff to
access the alternative portal route to Giza, and continued to ascend groups of
Annu through the portals, not realizing he was sentencing them to soul frag-
mentation. Sabatoth discovered Akhenaton was using the Halls of Amenti
and so he, going against the advice of the other Flame Keepers, also contin-
ued ascension attempts for the Serres-Egyptian peoples. Sabatoth discovered
that by using the D-2 portals to access parallel Earth, through which people
could merge consciousness with their anti-particle double and transmute
their DNA, that passage into the Halls of Amenti could be made without the
use of the Staff or Blue Flame. Neither man realized they were sending people
into fragmentation and both believed they were assisting their own people
who were being unfairly denied by the other side.  
    The Elohim again intervened to stop these activities. The personal mor-
phogenetic fields of individuals involved with ascension after the Halls of
Amenti were closed were removed from the Sphere of Amenti morphoge-
netic field and placed within the Third Eye of Horus portal passage in the