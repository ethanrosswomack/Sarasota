# Chapter 11

Opening the Halls of Amenti 
     Along with these events, a series of monumental occurrences were also
to take place, as Earth entered the final phases of its ascension cycle. From
1988 through 2017 the natural seals of Earth’s seven primary vortices/chakras
would systematically open, as six Stellar Spirals progressively came into
alignment with Earth’s Merkaba Fields. On 1/1/2000 Earth’s energetic fields
would strike an interdimensional Resonant Tone, beginning the cycle of
Earth's Stellar Activations. The Guardians were to call a global gathering of
Light Workers on this day, for a celebration of the Day Of Transcendence, to
assist Earth in holding the interdimensional Resonant Tone so planetary
ascension into the D-4 time cycle could begin. 
     Earth would then experience six Stellar Activations and six Stellar Wave
Infusions between 5/5/2000 and 2017, through which the particle conversion
process of the morphogenetic wave would take place. Between 1992-5/5/
2012, six silent avatars would birth on Earth, to purge genetic mutations and
realign the imprints of DNA strands 2-7 with the 12-strand DNA imprint
within the Sphere of Amenti race morphogenetic field. Between 1999 and
2017, 150,000 lndigo Children would birth on Earth through parents with
Palaidorian Birthing Contract soul agreements, to carry the activated sixth
DNA strand imprint. Keepers of the Blue Flame and Keepers of the Violet
Flame would receive their “wake up call” and progressively undergo six Star
Crystal Stellar Activations and Wave Infusions, activating DNA strands 5-9,
between 6/1996 and 2017. 
     Following their six Stellar Activations, the Keepers of Tara's Blue Flame
morphogenetic field would embody the Blue Flame on 5/5/2012, and begin
initiating Stellar Activations in others who hoped to ascend through the
Halls of Amenti to Tara or Gaia. The Keepers of Gaia’s Violet Flame mor-
phogenetic field would embody the Violet Flame on 1/1/2017 and begin
ascending people to Gaia during a 3-day period in 2017. The seven planetary
dimensional Merkaba Fields between Earth in HU-1, Tara in HU-2 and Gaia
in HU-3 would progressively open to each other as Earth, Tara and Gaia
aligned with the Holographic Beam for three days in 2017. This would per-
mit full ascension through the Halls of Amenti and the Blue and Violet
Flames, into the Meta-galactic Core at D-8, for those who had fully assem-
bled the sixth DNA strand. 
         
     On 9/17/2001, the Hall of Records in Giza, Egypt, would begin opening.
On 5/5/2012, the Flame Holders would activate the Hall of Records, and on
12/21/2012 the Hall of Records would begin transmitting data through
Earth’s grid, making interdimensional memory available to Earth's popula-
tions. Throughout this multi-faceted sequence of events, the grids of Earth,
Tara and Gaia had to be kept in balance and various segments of the popula-
tion had to be guided to their appropriate ascension paths, while Guardians
continued to monitor, side step and undo manipulation tactics of the Dracos-
Zeta Resistance and D-4 Anunnaki instigators. 
186 

                                                                                     
                                  10/1986 through 6/1998
After 2022, the evolutionary path for Earth’s populations would be set,
the two versions of Earth would progress forward in their respective time
cycles, and the three divisions of Earth’s populations would embark upon
                            their chosen paths of future evolution.  
 
   Before all of the above events could occur the Guardians had to re-align
the solar Merkaba Fields so the 11:11/12:12 Frequency Fence could come
down. Once this occurred, the artificial D-4 “Christ Consciousness” grid
could resume transmitting D-4 frequency into Earth core to progressively
accelerate grid speed and realign the fourth Vortex/Giza pyramid with the
Alcyone spiral, so the Holographic Beam could intersect with Earth at the
proper angle in 2017. At times, we of the Guardian Alliance shake our heads
and chuckle when we hear humans lament that “the Guardians must not be
real, or if they are real, they are uncaring, because they are not doing any-
thing to help us with the Intruder problem.” Perhaps now you can understand
what we have been doing to help you behind the scenes, and that this workload does
not allow an excessive amount of resources to be placed upon concerns of social pro-
tocol. 
    We will now provide an overview of the status of your ascension schedule.
                                           10/1986 THROUGH 6/1998 
                    
                          The Opening of Amenti — Schedule of Events 
                            What has transpired between 10/1986 and 6/1998? 
   1.   October 1986: The Arc Of The Covenant First Seal Opened. The
     Sphere Of Amenti Began Descent To Earth. The 9540 BC Quarantine
      Frequency Fence Began To Lift. The Earth’s grid speed raised high
       enough to spark open the first seal on the Arc of the Covenant and the
       Sphere of Amenti began its 14-month descent into the Earth's D-2 core.
      With the release of the first Arc of the Covenant Seal, the Quarantine
         Frequency Fence from 9540 BC began to disengage. Some of the third
      DNA strand mutations caused by this Seal began to heal, allowing the veil
     between the ego and the higher self identity aspects to begin dissolving.
  2.    August 16, 1987: The Harmonic Convergence. Permission For Guard-
   ian lntervention On Earth Was Granted. Bridge Zone Project Was Set
     In Motion. Guardians Began Keying Earth’s Vortices. In 1987, in
     response to the event of the Harmonic Convergence on 8/16/1987, the
     Sirian Council persuaded the Galactic Federation and other HU-2 and
     HU-3 groups to allow the ascension program to be activated for the
   human populations. Permission was given for the Guardians to intervene
    and set the Bridge Zone Project plan from 1984 in motion. Guardian
187 
                                                                                                                                                  
                                                                                                              
  
 
 

             Opening the Halls of Amenti 
   groups began keying Earth’s vortices with UHF seals to block Intruder
    forces from using the vortex portals. Guardian and Intruder forces began
     vying for control over Earth’s vortices. 
3.  January 1988: Sphere Of Amenti Returned To Earth’s Core And The
    12-year Amenti Activation Cycle Began. Earth’s First Vortex Seal-Ari-
          zona, USA-opened. Amenti’s D-1 Frequencies Began Transmitting
      Through Earth’s Grid. The Sphere of Amenti returned to Earth’s D-2
       core from the UHF bands of D-3, for the first time in about 3,500 years,
       and began transmitting its D-1 frequencies into Earth’s grid. This began
         the 12-year activation process of the Sphere of Amenti, through which
      the Sphere progressively opens its D-1, D-2 and D-3 frequencies into
     Earth's core D-2 morphogenetic field. This will raise the pulsation rhythm
           of Earth’s particle base and the frequency of Earth's grid, in preparation for
                  Earth’s first Stellar Activation on 5/5/2000. As the Sphere of Amenti
        began transmitting its D-1 frequencies through Earth’s grid, the natural
         seal on Earth’s first primary vortex opened and the vortex began its 4-year
     activation cycle. Earth's first primary vortex/chakra is located in the
         region of the Painted Desert in the state of Arizona, USA. (The Sedona,
       AZ, vortices are connected to this primary vortex and they began multidi-
     mensional activation at this time.) 
 4.  September 1989: Guardians Repair Solar Fields. Guardian Transmis-
   sions of D-4 Frequency to Increase Earth's Grid Speed Begin. The Sir-
     ian Council and other Guardian groups completed the realignment of the
   solar Merkaba Fields, which began the realignment of Earth's D-1 and D-2
   Merkaba Fields, that had been misaligned by the Zetas following the Phil-
   adelphia Experiment of 1943. This allowed D-4 frequency transmissions
  from the Guardian’s artificial “Christ Consciousness” grid to resume infu-
   sion into Earth’s core, to raise Earth’s core frequencies. This also allowed
   for the 11:11/12:12 Frequency Fence to come down, once the Earth’s grid
      re-balanced. 
 5. January 11, 1992: The 11:11—Promise Of Ascension—Granted as
    Guardians Transmitted The 11 D-4 Magnetic Base Codes That Would
       Allow 11:11/12:12 Frequency Fence to Later Release. On 1/11/1992
   the Guardians began to transmit the 11 D-4 magnetic base tones that had
   been removed from Earth's morphogenetic field in 1972, to create the pro-
   tective 11:11/12:12 Frequency Fence, which stopped the Red Pulse/Wave
   of Solar Flame from moving through Earth and neighboring planets.
   Transmission of these magnetic codes marked the beginning of the 11:11/
   12:12 Frequency Fence disengagement. The Fence had blocked the third
   and fourth DNA strands from plugging into each other, which caused a
      block between the D-3 personality and higher self and the astral identity.
        The Fence would also block the Sphere of Amenti from transmitting D-4
     188 
 

                                                                           
                                                                              10/1986 through 6/1998
      frequency into Earth’s grid in 2000. The Halls of Amenti could not open
   while the Fence was in place. With the return of the D-4 magnetic base
    tones to the Earth’s morphogenetic field, the opening of Amenti would
     continue on schedule, the third and fourth DNA strands began to align
      and astral awareness became more accessible to the 3-dimensionally con-
     sciousness human identity. The date of 1/11/1992 became known as the
  11:11 in New Age circles, representing the celebration of the promise of
   ascension, which was granted on that date, through Earth receiving the 11
   D-4 magnetic base codes that would allow the Frequency Fence to disas-
       semble. 
             6.  June 6, 1992: Earth’s Second Vortex Seal—Jerusalem, Israel—
           opened; Amenti’s D-2 Frequencies Began Transmitting Through
           Earth’s Grid. The Sphere of Amenti completed opening its D-1 frequen-
         cies into Earth’s morphogenetic field, Earth’s first primary vortex in the
        Arizona Painted Desert completely opened and activated and the seal on
         Earth’s second primary vortex began to open and activate. Earth’s second
         primary vortex/chakra is located in Jerusalem, Israel. The Sphere of
        Amenti began transmitting its D-2 frequencies through Earth's grid.
      7.  July 26, 1992: Avatar # 1—Seventh-level Avatar—Is Born And Aligns
      DNA Strand 2 Imprint With 12-strand Pattern; Corrected Strand 2
       Imprint Begins Transmitting Through Earth’s Grid. The first of six
         Silent Avatars was born. This avatar is a D-7 soul essence from HU-3, a
      seventh-level avatar, with 7-dimensional frequency bands activated in his
      genetic code. This individual was born with DNA strand 7 fully activated.
      As his soul essence passed through the Sphere of Amenti the imprint for
          DNA strand 2 was realigned with the 12-strand DNA pattern and the
    imprint for the aligned DNA strand 2 began transmitting through Earth's
       grid and into the bio-energetic fields of Earth’s population. 
             8.  December 12, 1994: The 12:12- Independence Day- Human Gradua-
    tion. Changing Of The Guard Of Amenti. The 11:11/12: 12 Frequency
     Fence Releases. Earth Guardianship Is Turned Over To Humanity. The
      Ascension Schedule Moves Forth. The 11 D-4 magnetic base tone codes
      and electrical overtone codes of the 11:11/12:12 Frequency Fence com-
      pleted re-entry into the Earth’s D-2 morphogenetic field and the 11:11/
     12:12 Frequency Fence was fully dismantled. The 12th base tone and 12th
        overtone frequencies of D-4 were reconnected to the 11 D-4 base tones
              and overtones within Earth’s morphogenetic field and the Sphere of
         Amenti. Human DNA could now continue to assemble through the
       fourth and fifth strand. The remaining stages of opening the Halls of
      Amenti were no longer under full Guardian control, the responsibility for
     humanity's evolutionary destiny was now in human hands. The success of
    the opening of the Halls of Amenti and the Bridge Zone Project, which
      189 

    Opening the Halls of Amenti 
were previously controlled by the Guardians’ 11:11/12:12 Frequency
  Fence, would now be determined by the rate at which human conscious-
  ness and DNA evolved to higher accretion levels. The Sphere of Amenti
 race morphogenetic field, which had been created 550,000,000 years ago
  by the Palaidorians of Tara would now be placed under Earth human
 guardianship. The Ur-Tarranate Palaidorian souls from HU-2, who had
  merged their consciousness to form the Sphere of Amenti, began to leave
  Earth and the Sphere of Amenti, to return to their HU-2 Taran reality
  fields. For 550,000,000 years, the energetic substance of the Ur-Tarranate
  souls and their consciousness had provided the medium through which
  the lost soul fragments of Tara could evolve from HU-1, by merging their
  consciousness with that of the Ur-Tarranates within the Sphere of
         Amenti, through evolution of the DNA. The Ur-Tarranates had served as
  a Host Matrix Family for the entire Earthly human lineage. The Sphere of
    Amenti morphogenetic field “rescue mission” for the lost soul fragments of
  Tara represents a Host Matrix Transplant, through which the entire
   Earthly human lineage has evolved. When the fall from Tara occurred, the
       lost souls of Tara were cut off from their soul matrices and the Turaneu-
      siam-1 race morphogenetic field. The Ur-Tarranates of Amenti served as
   an adoptive soul matrix through which the lost souls could re-evolve,
    until they had re-built their connection to their Taran soul matrices
   through assembly of the fourth and fifth DNA strand. Through the accel-
     erated evolution opportunity offered by Earth’s present ascension cycle,
   fourth and fifth DNA strand assembly would allow many humans the
   chance to re-connect with their personal soul matrices from HU-2. The
    services of the Ur-Tarranates would no longer be needed, as the humans
         who made their soul matrix connection would become carriers of the
    human evolutionary blueprint. 
   The return of the race morphogenetic field to the human species could
not occur while the 11:11/12:12 Frequency Fence remained in place and
DNA strands four and five were blocked from assembly. When the Fre-
quency Fence dismantled on 12/12/1994, fourth and fifth strand assembly
once again became available to humanity. The event of Amenti’s transfer
to human guardianship can be viewed as a “Changing of the Guard”.
With the termination of the Frequency Fence, between 1/11/1992 and 12/
12/1994, the Host Matrix Family Ur-Tarranate souls began leaving Earth,
as progressively more humans re-connected to their HU-2 soul matrices.
The Ur-Tarranates involved in the Amenti project had been Earth-bound
for 550,000,000 years and could not ascend from HU-1 until this “Chang-
ing of the Guard” took place. As of 12/12/1994 the ancient Ur-Tarranate
souls from Tara could at last disengage themselves from the Sphere of
Amenti and continue on their own evolutionary journey through the
190 
    

                                                                         
                                                                        
  10/1986 through 6/1998
 
        higher Harmonic Universes. This date of 12/12/1994 became known as
         the 12:12 and represents humanity’s true Independence Day, when the
         fate of human destiny was turned over from the custodial care of the
        ancient Ur-Tarranate race and placed into the hands of an evolving
         humanity. The 12:12 stands for humanity's graduation from its adolescent
          evolution into the adult role of becoming a planetary Guardian species.
    9.  1995: Guardians Initiate Portal Project To Secure Earth's Vortices
         From Intruder Infiltration By 2012. The Sirian Council became aware
        of Anunnaki Resistance plans to instigate Earth changes through D-4
         interference. The Pleiadian Star League and members of the Andromeda
          Council agreed to assist the Sirian Council in more aggressive efforts of
         frequency-keying, monitoring and protecting Earth’s vortex/portal system
        from Anunnaki Resistance and Dracos-Zeta Resistance manipulation.
          They began the collaborative Portal Project. Guardian and Intruder forces
         have been secretly vying for portal control ever since. Presently the
         Andromies have most of Earth’s portals under protection, though Intruder
        forces continue to attempt to overtake the primary second portal vortex
         in Jerusalem and the smaller, secondary portals in Manhattan, Florida,
        Sedona, Arizona, Hawaii, Tibet, China and in other areas of the globe.
        Guardians must secure all seven primary vortex points by 2012 for the
        Bridge Zone Project and the opening of the Halls of Amenti to unfold
          smoothly, without causing grid instability and Earth changes. Humanity
         can help the Guardians in this portal protection endeavor by using
          focused group meditation to project high frequency D-4 - D-8 frequency
          into these locations and into the Earths grid in general, using “sun” visu-
            alizations. 
      10. June 1996: Earth’s Third Vortex—Himalayan Mountains—Opened.
         Amenti Began Transmitting D-3 Frequencies Through Earth’s Grid.
         Keepers Of The Blue And Violet Flames Begin First Stellar Activation,
        The Solar-Heart Star Activation. The Sphere of Amenti completed
         opening its D-2 frequencies into Earth’s morphogenetic field, Earth’s sec-
        ond primary vortex in Jerusalem, Israel completely opened and activated
        and the seal on the third primary vortex/chakra began to open and acti-
        vate. The third vortex is located in the Himalayan Mountains of South
                            Central Asia. The Sphere of Amenti began transmitting its D-3 frequen-
         cies into Earth’s grid. The Keepers of the Blue and Violet Flames and their
        Flame Holders began the D-4 Solar-Heart Star Activation, initiating the
                            assembly and activation of their fourth DNA strand. 
                 11. June 24, 1996: Avatar 2—Eighth-level Avatar—Was Born And
                    Aligned DNA Strand 3 Imprint With 12-strand Pattern. Corrected
                       Strand 3 Imprint Begins Transmitting Through Earth’s Grid. The sec-
                       ond of six Silent Avatars was born. This avatar is a D-8 soul essence from
                       191 
                                                                                                                                         

  Opening the Halls of Amenti 
     HU-3, an eighth-level avatar, with 8-dimensional frequency bands acti-
     vated in his genetic code. This individual was born with the eighth DNA
     strand fully activated. As his soul essence passed through the Sphere of
     Amenti, the imprint for DNA strand 3 was realigned with the 12-strand
     DNA pattern and the corrected third strand imprint began transmitting
       through Earth’s grid. 
    By 1996 there was great concern among Guardian races, as to whether
Earth’s grid speed would be raised high enough by 6/30/1998 to spark the sec-
ond seal on the Arc of the Covenant. If the second seal did not open by this
date, Earth could not begin its ascent into pulsation rhythms of the D-4 time
cycle for merger with Tara. 
    If Earth’s grid speed was not high enough to spark open the second Seal
on the Arc of the Covenant by June 30, 1998, the Bridge Zone Project would
not succeed. The Halls of Amenti would not open. The Earth would be
unable to shift into the D-4 time cycle by 1/2012 and the Dracos-Zeta Resis-
tance would have a much better chance of creating the 2003 experiment and
2004 Frequency Fence. If Earth was unable to begin shift into a D-4 particle
pulsation rhythm by 5/5/2000, sporadic Earth changes would erupt between
2012-2017, as the grids of Earth and Tara attempted to merge, and the oppor-
tunity for ascension would be lost. 
    Guardians were permitted by the HU-2 and HU-3 councils to continue
their transmissions of D-4 frequency into Earth’s grid, but they were not per-
mitted to directly intervene in Earth’s affairs by landing and directing the
actions of humans to desired ends. Humans had been given guardianship of
Earth on 12/12/1994. Visiting Guardians were allowed to assist, but not to
alter the choices humanity would make for itself. The Dracos-Zeta Resistance
continued to inﬂuence human decision making through covert infiltrates,
and motivated an acceleration of new technology testing among various
groups of global military organizations. Top Secret military experiments using
scalar wave technology, satellite manipulation of inter-stellar radio waves and
certain types of nuclear testing from 1988 through the present, progressively
created new imbalances in Earth’s bio-fields and grid, which hampered the
Guardians’ efforts to raise grid speed. It was feared that by 6/30/1998 the grid
speed would not be high enough to spark the second seal on the Arc of the
Covenant. Guardian groups from all over the galaxy, and from HU-2 and
HU-3 watched, waited and prayed that humanity would be able to counter-
balance the activities of their governments by raising personal consciousness
and accretion levels enough to allow Earth’s grid speed to sufficiently
increase. In 12/1997 the Anunnaki Resistance began subliminally manipulat-
ing populations through the primary vortex in Jerusalem, the secondary vor-
tex in Manhattan and several other secondary vortices whose security seals
they were able to decode and release. Following this new development, the
192 

                                                                       
                                                                       The Arc of the Covenant Opens
odds of the second seal on the Arc of the Covenant sparking open by 6/30/
1998 were about two million to one against the event occurring. 
                 Prospects for the Bridge Zone Project and opening the Halls of Amenti were bleak as 1998
                                                  dawned under the inﬂuence of covert ET manipulation                                                                      
 
 
 
                      THE ARC OF THE COVENANT OPENS 
          In the beginning of this transmission we mentioned that we had an
          announcement to make, and we will make that announcement now.
              In February 1998 the Elohim from HU-3 knew the second seal of the
Arc of the Covenant would not be sparked open in time for the 6/30/1998
deadline. They broke their own protocol. Having a change of heart toward
helping the entire human species, rather than only their preferred genetic
strains, the Elohim intervened. 
     The original ascension plan called for the birth of six avatar souls from
HU-3 and HU-4, between 1992 and 2012. These individuals were needed to
hold higher-dimensional frequency as Earth progressively integrated the fre-
quencies from the Sphere of Amenti and to correct any misalignments in the
morphogenetic imprints of DNA strands 2-7, within the Sphere of Amenti.
The avatars were to be born about four years apart, in various, undisclosed loca-
tions on the globe, beginning in 1992. Avatar 1 was born on 7/26/1992 and
Avatar 2 on 6/24/1996. Avatar 3 was not due to birth until the year 2000.
  Knowing the ascension plan had reached a standstill early in 1998, 
      the Elohim orchestrated the early birthing of the third avatar, 
                                       the ninth-level avatar.  
 
       
        With the birth of the third avatar, Earth’s morphogenetic field would
receive a sudden burst of UHF energy as the avatar soul passed through the
Sphere of Amenti, Earth’s core and into fetal integration, moments before
physical birth.¹ 
          
         ______________________ 
1.   Most avatar souls do not enter the fetal body anywhere near conception, as the vibra-
tional rate of their consciousness would literally blow the physical tissue apart, cause mis-
carriage of the pregnancy and damage to the mother’s bio-energetic system. They usually
hover about and over shadow the pregnancy, then enter the infant’s body just before it
passes through the birth canal. Avatar pregnancies rarely exceed a seven-month gestation
period, as avatar-selected fetal bodies have a larger genetic package, tend to develop more
rapidly and begin to drain the life force energy of the mother-host after the seventh
month of gestation. Most are born as premature infants with soul integration taking place
during or just after the birth process. 
193 
                                                                                                                                                                                                             
                                                                                                                     

Opening the Halls of Amenti 
              The Guardian Alliance would like to announce the following: 
On June 26, 1998, at 3:46 PM, the third Avatar child was born, and the second
seal on the Arc of the Covenant sparked open, beginning Earth's 2-year preparation
         for passage into the particle pulsation rhythms of the D-4 time cycle. 
   The child was born at home to a couple residing in a village of a Third
World country. He was in actuality a five5-month gestation infant, but is
believed to be only two-months premature. He is faring well and will survive
to fulfill his purpose of holding higher-dimensional frequency as the Sphere
of Amenti continues to open. The name, religious affiliation and location of
this child (and the other five avatars) are unimportant. His identity will not
be publicly disclosed, nor will the identities of the other five ascension ava-
tars reach public notice during the ascension period. Four of the Six Silent
Avatars will disclose their identities sometime after they have turned 33 years
of age and their service missions come into mass awareness. 
    Anyone publicly claiming to be one of the six Silent Avatars before 2025
AD (when avatar one turns 33) is either misguided, being manipulated by
Intruder forces or is purposely trying to distort the truth. There are a number
of other legitimate avatars present on Earth at this time. Some of them are
publicly known, but these are not of the six Silent Ascension Avatars, whose
purpose is to realign the human DNA imprint and ensure Earth’s grid stabil-
ity by holding higher-dimensional frequency in their bio-energetic fields as
the Sphere of Amenti opens into Earths morphogenetic field. 
    Our announcement is thus a birth announcement, but also the confirma-
tion of Earth's passage into the D-4 time cycle in preparation for entering the
Bridge Zone, the opening of the Halls of Amenti and the opportunity for
ascension. 
    The second seal on the Arc of the Covenant has been sparked and Earth
will now begin preparation for the descent of the Blue Flame of Amenti and
the opening of the Halls of Amenti portals, which are scheduled for May 5,
2012. 
       Your preparation for ascension is now back on schedule. 
                       
                           PALAIDORIAN BIRTHING CONTRACTS 
                
                 The Indigo Children, Palaidorian Birthing Contracts, 
                            Contract Bonds, and the Incubation Rite. 
        Along with the birth of the Six Silent Ascension Avatars between 1992-
2012, the Palaidorians and Priests of Ur from HU-2, working with the Elohim
and other Guardian races from HU-3 and HU-4, organized the Palaidorian
Birthing Contract soul agreement program. To ensure the success of the Bridge
Zone project, and thus the ascension program, a minimum of 144,000 individu-
als on Earth would have to completely assemble and activate the sixth DNA
strand and rapidly begin assembly and activation of the seventh and eighth
194 

                                                                                         
                                                                                      Palaidorian Birthing Contracts
DNA strands. The only members of the human population on Earth that
organically possessed the sixth DNA strand imprint are the groups who have
undergone genetic acceleration through earlier Zionite intervention—those
who carry the Celestial 12-strand Silicate Matrix gene code. The Keepers of
the Blue, Violet and Orange-Gold Flames also possess this genetic configura-
tion. The Sixth Root Race Muvarians and their Melchizedek Cloister race are
born with the fourth DNA strand assembled and the imprint for the fifth strand
dormant. The Muvarians have not yet begun their birthing cycle on Earth. The
Melchizedek Cloister race must fully assemble the fifth DNA strand before it
can activate the imprints for strands 6 and above. Members of all of these races
must fully assemble and activate the lower strands, then assemble and activate
the sixth strand by completing at least three Stellar-Star Crystal Activations,
before Earth can receive the needed concentration of D-6 frequency these acti-
vated sixth strand individuals would provide. There is little time left before the
2012—2017 ascension period begins for a minimum of 144,000 individuals to
awaken to their soul purposes and consciously complete these Stellar activa-
tions to activate their sixth DNA strand. 
    Being aware of the shortage of time available to achieve the needed
sixth strand activations, the Palaidorians created an early birthing program
for members of the seventh Root Race Euanjhechi and their Cloister Race
Yunaseti. The Euanjhechi and Yunaseti, often referred to collectively as the
Paradisians, possess a fully activated fifth DNA strand at birth and the ability
to rapidly assemble and activate the sixth DNA strand imprint, which they
organically carry. The Paradisians are D-6 soul essences and become fully
embodied souls when their sixth strand completes activation, usually by 12
years of age. 
    Through soul agreements with members of the Sixth Race Melchizedek
Cloister and others carrying the Celestial Silicate Matrix gene code, 150,000
couples were chosen to serve as birthing parents for the incoming Paradisian
race soul essences. These are the only groups of humans possessing a large
enough gene code to create fetal bodies strong enough to hold the Paradisian
soul essence. Through these Palaidorian soul agreements, which are orches-
trated by the Priests of Ur from Agartha and Tara, selected Earth couples are
subconsciously guided together by their personal soul-level identities, to ful-
fill the Palaidorian Birthing Contract. 
   Through astral contact and/or Guardian ET soul-agreement abductions,
the parent couples undergo manipulation of their bio-energetic fields and
DNA, to allow for a strong, energetic soul bond to be created between the
parents. This electromagnetic bond allows the soul matrices of the individu-
als in the couple to merge, forming an UHF bio-energetic field through
which an advanced fetal pattern, with a genetic code larger than that of
either of the parents, can be conceived. Once this bond, referred to as a
195 
                                                                                                              

Opening the Halls of Amenti 
Bonding Contract or Contract Bond, takes place, the bio-energetic fields
and life paths of the parents are blended together, following which time the
couples will be led together through various circumstances that occur in their
earthly lives. Some of the parent couples will be consciously aware of these
Contract Bonds and Birthing Contracts, others will be consciously unaware
and “just so happen to fall in love with each other” and bear their Paradisian
child. 
   The Palaidorian Birthing Contracts and Contract Bonds are high-level
soul agreements entered into by the parents’ over-soul level identities, in
cooperation with the over-soul identity of the child they will birth. In fulfill-
ing these contracts the individual parents receive acceleration of their
genetic blueprint, which allows them further advancement in their evolu-
tionary ascension process. The over-soul identity enters the Palaidorian con-
tract in order to allow its incarnate the opportunity for advancement. These
contracts in no way violate the rights of the incarnate and they are intended
by the over-soul to guide the incarnate to its highest life experience. 
    The births of the Six Silent Ascension Avatars and those of the I50,000
Paradisian souls are orchestrated through Palaidorian Birthing Contracts and
Contract Bonds. The Paradisian souls will enter incarnation on Earth from
the D-6 frequency bands of Tara through the D-6 Sirian Stellar Spiral. The
sixth-dimensional frequencies correspond to the Indigo wave pattern of the
interdimensional Light Spectrum, thus the Paradisian children have been
nicknamed the “Indigo Children” or “Sirian Blue Babies”. The coming birth
of the Indigo Children has been foretold within various Earth human groups
that are working with other Guardian ET and metaterrestrial contacts. Some
of this information has been published in channeled writings. 
   The birth schedule of the Indigo Children will proceed as follows: the
first wave of 144,500 Indigo Children will birth between 1999-2004. They
will complete activation of the sixth DNA strand at the age of 12, between
2011-2016. Children of the first birth wave will serve as Place Holders, their
sixth DNA strand activation serving to ensure the balance and grounding of
D-6 frequency on Earth during the 2012-2017 ascension period. The second
birth wave of 5,500 Indigo Children will birth between 2005-2017, to reach
maturity at age 12 between 2017-2029. The children of the second birth
wave will assist Bridge Zone Earth to balance frequency following the 2017
particle conversion process. They will also serve as Place Holders, grounding
D-6 frequency into the Sphere of Amenti race morphogenetic field. 
    The finalization of the Palaidorian Birthing Contracts and Contract
Bonds between the parent couples of the Indigo Children took place on
August 30, 1998. Prior to this date, contracts were transferable between vari-
ous eligible individuals, giving chosen soul identities the opportunity to exit
or renegotiate the terms of their Palaidorian Contracts. 
196  

                                                      Palaidorian Birthing Contracts
    As of 8/30/1998, parent couples were bound to their Palaidorian Birthing
Contracts and Contract Bonds, as the necessary bio-energetic field and DNA
adjustments that would fulfill the Contract Bond were given to the parent
couples through astral body mechanics, referred to as the Incubation Rite.
During the 3-day Incubation Rite, couples agreeing to uphold their contracts
were taken to Agartha-Inner Earth by the Priests of Ur, via their astral bod-
ies. The Priests of Ur then initiated the bio-energetic field mechanics
through which the DNA, bio-energetic fields and soul matrices of the two
individuals in a couple are fused together, by infusions of energy from their
respective over-souls. 
    Through these rites, the Contract Bond and Birthing Contract are pro-
grammed into the individual’s active DNA program, creating a twin DNA
code alignment between the couple. This rite begins the Incubation Period
for each individual, through which the life patterns and soul directive of each
person is aligned with the contract and all events, karmic patterns and cir-
cumstances that are not part of the contract are purged from the life drama
manifestation pattern. From this point forward, the couple’s lives will unfold
according to the soul identity’s intentions, offering the incarnates protection
from various karmic dramas and ego-based choices that normally would have
manifested. The Incubation Rite marks the suspension of the karmic imprint
                            for the individual and the accelerated integration of the soul and ego identity. 
 
 
 
 
                              The couples of Palaidorian Birthing Contracts will begin rapid DNA
activation acceleration in preparation for their child’s birth, and will receive
“across the board" protection from the Palaidorians and HU-3 Guardians, to
ensure the success of their contracts. Though the families of the Palaidorian
Contracts may appear no different than any other Earthly family, they are
fully guided and protected from the higher Harmonic Universes. Due to their
agreement to participate in this service to human evolution, these couples
are granted direct intervention and support from the D-6 “Angelic King-
doms,” Guardians from HU-2 through HU-5 and the Entity gestalts from
Meta-Galactic Core. This “divine   intervention” will    create an  almost “magi-
cal” ease in Earthly endeavors that are part of the Palaidorian Contract and
the   individuals  will  also   experience  greater   difficulty   in   successfully   orches-
trating Earthly affairs that are not part of the contracts to which their souls
have agreed. All incarnates fulfilling their Palaidorian Birthing Contracts
will  be  freed  from the  HU-1 reincarnational cycles of   birth  and  death, follow-
ing their present incarnation. 
   Through the births of the Six Silent Avatars and the Indigo Children,
Earth’s transition to the Bridge Zone and humanity’s opportunity for ascen-
sion will unfold as planned. 
12. June 26, 1998: Avatar 3—Ninth-level Avatar—Was Born Two Years
    Early. The Second Seal On Arc Of The Covenant Opened. Avatar 3
    Aligned DNA Strand 4 With 12-strand Pattern. Corrected Strand 4
 197 
                                                                                                                  
                                                                                                                                            

Opening the Halls of Amenti 
Imprint Will Allow Reverse-mutations Of Strand 4 Distortions; And
Release Of Palaidor, Amenti, And Zeta Seals From DNA On 5/5/2000.
The third of six Silent Avatars was born two years early via Elohim inter-
vention; originally birth was scheduled for 5/5/2000. This avatar is a D-9
soul essence from HU-3, a ninth-level avatar, with 9-dimensional fre-
quency bands activated in his genetic code. This individual was born with
DNA strand 9 fully activated. As his soul essence passed through the
Sphere of Amenti, the imprint for DNA strand 4 was realigned with the
12-strand pattern. The Seals of Palaidor, Amenti and Zeta all begin to
release with the assembly of the aligned fourth DNA strand. The birth of
Avatar 3 reset the aligned fourth strand pattern into the Sphere of Amenti
morphogenetic field, releasing the imprint of the Palaidorian, Amenti and
Zeta Seals from human DNA. The D-4 frequencies from Amenti will not
begin transmitting through Earth’s grid until 1/2000 and the corrected
pattern for the fourth DNA strand will begin transmitting through Earth’s
grid on 5/5/2000. 
                                      What transpires next? 
        198 
           

                                         11
                           
                                                       
                    
                   
            
                                    Things to Come  
                        
            
                                              
                                                  ASCENSION SCHEDULE 
          As Earth approaches its half-point in the second ascension cycle of its
26,556-year Euiago time cycle, the opportunity for ascension of human popu-
lations through the Halls of Amenti and into HU-2 is presented. Taking
advantage of this time-cycle placement opportunity, with Guardian assis-
tance, Earth can be shifted out of the range of Intruder Visitor manipulation,
through the Bridge Zone time continuum shift. The dynamics by which these
changes will occur are highly scientific, and involve complex interdimen-
sional physics mechanics. We have provided extensive information concern-
ing humanity’s need to evolve the DNA in order to accommodate these
changes, attempting to assist you in understanding the concept of the interre-
lationship of biological, spiritual and planetary evolution. 
      The ﬁnal aspect of these interdimensional evolutionary/ascension dynamics
with which you need  to  become acquainted, is the mechanics of Transmutative
Stellar Activations and Stellar Wave Infusions, for it is through these mechan-
ics that personal and planetary ascension takes place. In the Appendix we pro-
vide a brief introduction to Stellar Activations (page 464) and Stellar Wave
Infusion Mechanics (page 466). For now, we would simply like you to under-
stand that Earth and the human populations will be facing a series of six
Transmutative Stellar Activations and Stellar Wave Infusions between 5/5/
2000 and 2017. Through these Stellar Activations and Wave Infusions
Earth’s particle base will be temporarily raised into the pulsation rhythms of
the HU-2 time cycles, so grid merger between Earth and Tara, and the open-
ing of the Amenti ascension passages, can take place. 
     These energy dynamics will affect the planetary grid and the physical and
bio-energetic systems of humans directly, so it is wise that you become aware
of these coming events. For this reason we have included the progression of
Stellar Spiral Alignments, Stellar Activations and Stellar Wave Infusions
with our running schedule of upcoming Earthly events. The Six Stellar Acti-    
199  
                       

     Things to Come
  vations, Stellar Wave Infusions and Stellar Spiral alignments Earth will
  encounter between 2000 and 2017 are as follows:
                                                                                                                                                            
1.   D-4 Solar Activation: 5/5/2000-6/2004.
       Blue Wave Infusion 6/2002- 6/2006
       D-4 Solar Spiral aligns with Earth's Merkaba Fields
 2.   D-5 Pleiadian Activation: 6/2004 -6/2008.
       Violet Wave Infusion 6/2006-6/2010
       D-5 Pleiadian Alcyone Spiral aligns with Solar Spiral Merkaba Fields
 3.   D-6 Sirian Activation: 6/2008-1/1/2012.
       Gold Wave Infusion 6/2010- 6/2014
         D-6 Sirian Spiral aligns with Pleiadian-Alcyone Spiral Merkaba Fields
 4.   D-7 Arcturian Activation: 2017—day 1¹
       Silver Wave Infusion day 1-2¹
       D-7 Arcturian Spiral aligns with Sirian Spiral Merkaba Fields
 5.   D-8 Orion Activation: 20l7—day 2¹
      Blue-Black Liquid Light Wave Infusion day 2-3¹
      D-8 Orion - Meta-Galactic Core Spiral aligns with Arcturian Spiral
      Merkaba Fields
 6.   D-9 Andromeda Activation: 2017—day 3¹
       Silver-Black Liquid Light Wave Infusion day 3¹
        D-9 Andromeda- Galactic Core morphogenetic field Spiral aligns with
      Orion Spiral Merkaba Fields.
      The following chronology of events also includes the Activation and
Infusion schedules for the Keepers of the Blue Flame and the Keepers of the
Violet Flame. Many of you reading this book may have hidden soul agree-
ments to serve as a Keeper of the Blue or Violet Flames. The Flame Keepers
are a specialized soul group that carries the Celestial Silicate Matrix gene
code, who incarnate during various time periods to assist the Palaidorians of
HU-2 with the human evolutionary process. Flame Keepers possess special-
ized genetic codes that will allow them to hold UHF within their bodies to
assist Earth with the Stellar Activation process. These writings represent a
“wake-up call” to the Flame Keepers, it is time for them to remember their
higher calling. Those of you who feel drawn to the concept of the Flame
Keepers are likely to be members of the Blue or Violet Flame soul groups. The
Keepers of the Blue Flame (Tara’s HU-2, D-5 morphogenetic field) begin and
complete their Stellar Activations and Infusions just prior to Earth's Activa-
tions and Infusions. The Keepers of the Violet Flame (Gaia’s HU-3, D-7 mor-
________________________________
1.   Three-day particle conversion period between 5/5/2017-6/30/2017
200

                                                      
                                                The Amenti Ascension Program Schedule
phogenetic field) begin and complete three of their Activations and Infusions
just after those of Earth and three just prior. We have included the schedules
for Earth and the two Flame Keepers groups in this chronology to assist the
   Keepers in their awakening process. 
                THE AMENTI ASCENSION PROGRAM SCHEDULE
                                                6/1998 to 2017
                                          
                                               Transcendence Day
        1.    June 26, 1998: Sphere of Amenti Continues to Transmit D-3 Frequen-
      cies into Earth’s Core. The Morphogenetic Wave Begins to Build. Earth
        Prepares for 1/1/2000 Transcendence Day. Flame Keepers Begin Blue
      Wave Infusions. 
           By 7/1998 the Sphere of Amenti opened into Earth’s morphogenetic field
            six (out of 12) D-3 frequencies and it will proceed to transmit its remain-
        ing six D-3 frequencies into Earth’s core between 7/1998 and 1/ 1/2000.
      On 1/1/2000 Amenti will begin transmitting D-4 frequency through
       Earth’s grid. The morphogenetic wave began to build on 6/26/1998 and
         the D-4 Solar Spiral began to align with Earth, following the birth of Ava-
            tar 3 and the sparking of the second seal on the Arc of the Covenant. Fol-
         lowing the 6/26/1998 opening of the second seal on the Arc of the
       Covenant, Blue Wave Infusions began within the bio-energetic fields of
       the Keepers of the Blue and Violet Flame, as they assembled half of the
       fourth DNA strand, halfway through their Solar Activation that began in
        6/1996. The Flame Keepers will complete their Solar Activation on 1/1/
       2000, in preparation for Earth’s Solar Activation on 5/5/2000. The Blue
        Wave Infusions of the Flame Keepers will complete in 1/2002.
    2.   August 30-September 1, 1998: Incubation Rite for Humans with
       Palaidorian Birthing Contracts Took Place in Agartha. Contract Bonds
       Were Activated.
    Humans with Palaidorian Birthing Contract and Contract Bond soul
     agreements were taken in their astral bodies to Agartha, by the Priests of
    Ur. Those accepting their contracts to birth the Indigo children were
    given the Contract Bond Incubation Rite, through which the soul matri-
    ces of each parent couple were energetically merged and the Birthing
   Contract was programmed into their operating genetic code.The
    Palaidorian Birthing Contracts became finalized, non-transferable and
    irreversible following the Contract Bond activation through the Incuba-
      tion Rite.
   3.    January 1, 2000: Celebration of the Day of Transcendence. Earth Pre-
            pares for Its Solar Activation as D-4 Solar Spiral Aligns with Earth’s
       D-2 and D-3 Particle Base.
 201 
                                                                                                                  
                                                                                                                

     Things to Come 
Due to the Guardians’ D-4 energy infusions into Earth’s core (which
began in 196 BC) and the opening of the second seal on the Arc of the
Covenant, with the birth of Avatar 3 on 6/26/1998, the Earth’s core parti-
cle pulsation speed raised high enough to begin preparation for Earth’s
Solar Activation on 5/5/2000. These frequency infusions have sufficiently
increased the particle pulsation rhythm of Earth's D-2 core and elemental
particle field, and Earth’s D-3 atmospheric particle field. Further D-4 fre-
quencies will be able to run through Earth’s D-2 and D-3 particle bases on
1/1/2000, when the D-4 Solar Spiral begins to align with Earth's core. D-4
is a primary base tone dimension and D-2 is a primary overtone dimension
within the 15-dimensional scale. When the full D-4 frequency spectrum
of the Solar Spiral begins to permeate Earth’s D-2 core and elemental par-
ticle field on 1/1/2000, an interdimensional Resonant Tone will be struck
as D-2 overtone and D-4 base tone frequencies merge. 
           
This  interdimensional Resonant Tone allows Earth’s 3-dimensional particle  ﬁeld
to raise in pulsation rhythm, to receive the progressive Transmutative Stellar
Wave Infusions and Stellar Activations that will allow Earth to rise into the
HU-2 time cycles for merger with Tara. Without this interdimensional Reso-
nant Tone, created through the merger of Earth’s D-2 core frequencies
with the D-4 Solar Spiral frequencies, Earth would not be able to achieve
its temporary shift into the HU-2 time cycle. If Earth is unable to make
this shift, the grids of Earth and Tara will not fully merge and the Bridge
Zone project will fail. The Halls of Amenti will not open, the planetary
ascension process will halt and Earth and its populations will remain
trapped within the HU-1 time cycle to fall under Dracos-Zeta Resistance
control. 
The striking of this lnterdimensional Resonant Tone is a natural part of
Earth’s ascension cycle, and will take place on 1/1/2000, as Earth’s grid has
reached the necessary particle pulsation rhythm as of 6/26/1998. The
event of the interdimensional Resonant Tone Striking will occur on
schedule. The alignment between Earth’s D-2 core and the D-4 Solar
Spiral and the resulting Interdimensional Resonant Tone created through
this alignment, constitutes a Day of Transcendence, for Earth and its
populations. The boundaries of Earth’s 26,556-year HU-1 time cycle, and
humanity’s entrapment within HU-1 physical matter, will be temporarily
Transcended. This Day of Transcendence marks the ﬁrst day of Earth’s new
 dawn into the age of enlightenment and the opportunity to stop the Intruder Vis-
 itors’ intended destruction of the human race. 
The Interdimensional Resonant Tone of Transcendence Day is scheduled   
  
 
 
 
 
 
 
 
 
 
 
 
  
      to occur between 12:00 PM of 1/1/2000 and 12:00 AM 1/2/2000, 
           as Earth completes its first day of the new millennium. 
202 
         

                                                                  
                                                                           
                                                                     The Amenti Ascension Program Schedule 
       Light Workers across the globe will be called together in celebration of
        this monumental occasion, and will be directed to begin Solar-Heart Star
         Activations for all who join them in this endeavor. The focused energies
         of the Light Workers global network will serve to create balance and
      acceleration within Earth’s grid, to prepare Earth for the initiation of its
       D-4 Solar Activation on 5/5/2000. This gathering of Light Workers and
        others on 1/1/2000 is needed to counterbalance the fear-based, lower-
       vibrating energies of the fanatical groups who will promoting “millennial
      fever” and doom between 12/ 1999 and 1/2000. These fear-based energies
      have the potential to create temporary grid imbalances that could mani-
      fest as localized Earth changes, as Earth enters the Solar Activation on 5/
        5/2000. Celebration of the Day of Transcendence will serve as an Earth healing
                          measure, as well as a ceremony of human unity. Earth’s fourth primary vortex-  
                           Giza, Egypt - will begin opening on this clay. 
 
 
 
 
 
             
              4.   1999-2004: First Birth Wave of Indigo Children. 
    The first wave of 144,500 D-6 soul essence—Root Race 7: Paradisian chil-
   dren, who possess the imprint for DNA strand 6, will birth on Earth. They
     will reach maturity and activation of the sixth DNA strand at age 12,
     between 2011-2016, to become Place Holders that ground D-6 frequency
         on Earth during the 2012—2017 ascension period. 
   5.  January 1, 2000: Earth’s Fourth Vortex—Giza, Egypt—Opens. The
    Sphere of Amenti Begins Transmitting D-4 Frequencies Through
      Earth’s Grid. The Blue Flame Begins Its 12-year Descent to Earth,
       Through the Alcyone and Solar Spirals. The Keepers of the Blue and
      Violet Flames Complete Solar-Heart Star Activation. Keepers of the
      Blue Flame Begin Fifth Strand-D-5 Pleiadian-Soul Seat Activation.
        The 9540 BC Quarantine Frequency Fence Dissolves. 
    As the Sphere of Amenti completes opening its D-3 frequencies into
      Earth’s morphogenetic field, it begins to transmit D-4 frequencies through
    Earth’s grid. The natural seal on Earth’s fourth primary vortex/chakra
    opens; Earth’s fourth primary vortex is located beneath the Sphinx and
    Great Pyramid of Giza in Egypt. The Keepers of the Blue and Violet
     Flames will complete their Solar Activation, assembly and activation of
     DNA strand four and Heart Star Activation. Through completion of the
     Solar Activation, the first level of soul integration takes place, astral inte-
     gration. The Keepers of the Blue Flame will begin their D-5 Pleiadian-
    Soul Seat-Activation and will initiate assembly and activation of their
     fifth DNA strand, in preparation for grounding and embodying the fre-
      quencies of the Blue Flame of Amenti on 5/5/2012. The Keepers of the
       Blue Flame begin their Pleiadian-Soul Seat -Activation in 1/2000 and will
        complete this second Activation and begin the Third Activation on 1/1/
      2005. The Keepers of the Violet Flame will begin their Pleiadian-Soul
      Seat-Activation on 1/1/2005. The Blue Flame begins its 12-year descent
     203 
       
 
                                                                                               

  
     Things to Come 
                 to Earth through the Alcyone spiral and Solar Spirals. As D-4 frequencies
      from the Sphere of Amenti begin transmitting through Earth’s core, the
        UHF band D-3 Quarantine Frequency Fence of 9540 BC completely
        releases, which creates a reversal of the third DNA strand mutation that
        was caused by the Frequency Fence. This mutation manifested as a block-
       age in the third chakra and an artificial division within the third mental
         body level of the auric field, creating a division between the Ego/personal-
      ity awareness and the Higher Self awareness. Reversal of this mutation
           will allow humanity the opportunity to merge the Ego, stationed in the
      low to middle frequency bands of D-3, with the Higher Self identity, sta-
        tioned in the UHF bands of D-3. The Higher Self connects the D-3 con-
       scious identity to the astral and soul levels of identity. When the Ego and
         Higher Self merge, awareness of the astral and soul identity becomes more
      available to the Ego, dream reality and astral perception become clearer,
        fourth DNA strand assembly and Solar Activation become available to
                the identity and consciousness begins to become multidimensional. 
                                            
                                           Earth Solar Activation 
 6.  May 5, 2000: D-4 Solar Spiral Aligns with Earth’s D-1 Iron Core
       Crystal. Earth’s First Transmutative Stellar Activation—The Solar
           Activation —begins. Earth’s D-1 Particle Base Enters D-4 Time Cycle.
      The Corrected Fourth DNA Strand Imprint Begins Transmitting
      through Earth’s Grid and Seals of Palaidor, Amenti and Zeta Can
       Release from DNA. Solar Activation and Multidimensional Identity
         Become Available to the Masses. 
       Earth’s D-1 electrical overtone particles in Earth’s D-1 iron core crystal
        begin to merge with Tara’s D-4 magnetic base tone anti-particles in Tara’s
       D-4 gold core crystal, transmuting both into their higher-dimensional
      morphogenetic fields/hyper-space (D-1 particles to D-15, D-4 anti-parti-
       cles to D-12). This is considered a D-4 Solar Activation as the Merkaba
       Fields of the D-1 and D-4 core crystals are held within the center of the
       sun and D-4 frequency transmits to Earth via the D-4 Solar Spiral. All of
       Earth’s D-1 overtone particles and Tara’s D-4 base tone anti-particles
       enter hyper-space and the overtone D-l and base tone D-4 Merkaba Fields
        will open into each other. Earth’s D-1 overtone particle base will have
       completed its shift into the pulsation rhythms of the D-4 time cycle and
        Earth’s D-1 base tone particles enter D-3 pulsation rhythm. As Earth’s D-l
       Merkaba Field opens into Tara's D-4 Merkaba Field, the particle pulsation
       speed of Earth’s core begins to rise into that of the D-4 frequency bands.
                 By the end of its Solar Activation in 6/2004,  Earth will complete 1/3 of its shift
             into the HU-2 time cycles, in preparation for merger with Tara on 5/5/2012.
       During Earth’s second D-5 Pleiadian Activation Earth’s D-2 and D-3 par-
      ticle base will also rise into the pulsation rhythms of HU-2 time cycles,
    204 

                                                
                                                
                                                      The Amenti Ascension Program Schedule 
and Earth’s D-2 and D-3 Merkaba Fields will merge with those of Tara,
placing Earth fully within the HU-2 time cycles by 1/2012. Earth’s Solar
Activation is the first of six Transmutative Stellar Activations the planet
will undergo between 2000 and 2017. Earth prepares for its Solar Activa-
tion in 1/2000, when its D-2 and D-3 particle bases align with the Solar
Spiral. The Solar Activation initiates on 5/5/2000, when Earth’s D-1 iron
core crystal aligns with the Solar Spiral. Earth’s Solar Activation begins in
5/5/2000 and will complete in 6/2004, at which time Earth’s second Stel-
lar Activation will begin. The corrected imprint for the fourth DNA
strand will release through the Earth’s grid on 5/5/2000. This will allow
people whom are consciously working to assemble DNA the opportunity
to release the Seal of Palaidor, Seal of Amenti and traces of the Zeta Seal
from their DNA, so fourth strand assembly and the Solar-Heart Star Acti-
vation can begin. Assembly and activation of the fourth DNA strand
allows the consciousness to achieve the first level of soul integration,
Astral integration. 
    The D-4 Seal of Palaidor is a genetic mutation from 5,500,000 years
ago, which caused a blockage between the second and third chakras, a
division between the second, third and fourth levels of the auric field and
separation between emotional, mental and astral identity levels. This seal is
released by fully assembling the fourth DNA strand. Release of this seal allows
polarization in the fourth/heart chakra to reverse, and the D-2 emotional,
D-3 mental and D-4 astral levels of awareness to merge. The nadial cap-
sule (barrier between D-3 and D-4 frequency levels in the auric field) dis-
solves and the blockage between the D-3 conscious perceptions and D-2
sub-conscious mind releases. Release of the Seal of Palaidor represents the ﬁrst
stage of soul integration, as the conscious D-3 identity begins to access the D-4
astral planes and skills of D-4 projection of consciousness and multidimensional
communication develop. 
    The Seal of Amenti, the Death Seal, is a genetic mutation from
5,508,100 years ago, a mutation in DNA strand 1, which caused a block-
age between the physical and etheric body. The sixth activation code
(overtone) of the first DNA strand was removed, which caused mutation
in the first, second and third DNA strands, that manifested as a block
between the body’s particles and the anti-particles of the body-double in
the parallel universe. This seal ended humanity’s ability to possess an Immortal
Body and created the necessity for birth and death through incarnational cycles
in order to evolve. lt stopped the process of bodily transmutation and the ability
to physically pass through the Halls of Amenti, in the masses. Release of the
Seal of Amenti allows the body to merge its particles with those of its
anti-particle double and creates merging of the physical and etheric bod-
ies. This creates transmutation of the body form, the ability to bodily ascend, the
return of the Immortal Body and release from the cycles of reincarnation. Cre-
205 
                                                                                                                  
                                                                                                                                                                                                                                                              

 
   Things to Come
     ates the merger of consciousness between present identity and identity
   focused in the parallel universe. Release of the Seal of Palaidor and assem-
      bly of the full fourth and fifth DNA strands is necessary to reclaim the
  Immortal Body. Release of the Seal of Amenti allows the process of fifth               
 strand DNA assembly and Pleiadian-Soul Seat -Activation to continue. 
       
         The Zeta Seal is a genetic mutation created in 1748 AD by the Zetas’
      Frequency Fence in the D-4 time cycle. Zeta Seal was removed by Guard-
     ians through astral realignment, between l902-1986, but traces of this
       fourth DNA strand mutation still appear in some humans. Zeta Seal
        blocked D-4 frequency, and thus multidimensional perception, from the
      D-3 perceptual awareness, creating an artificial barrier between the D-3
      conscious self and the astral identity. The seal operated as an etheric
     implant within the nadial capsule, between the third and fourth layers of
     the auric field. This caused repression of dream recall and memory of mul-
         tidimensional experience, and hampering of multidimensional communi-    
        cation, astral projection and the soul integration processes. It allowed      
      Zetas to electrically impulse human bio-chemical response patterns and
            behavior, through subliminal manipulation of the bio-neurological struc-
               ture. Zeta Seal releases with assembly of realigned fourth DNA strand. 
                                     
                                                The Hall of Records
     7.   September 17, 2001: Guardians Complete Alignment of Giza Pyramid
    with Alcyone Spiral. Hall of Records Begins to Open. The Guardians
      will complete their Earth grid realignment, bringing the Great Pyramid of
    Giza/vortex 4 into alignment with the Alcyone spiral in preparation for
 the Holographic Beam of 2017. This will begin the opening of the Hall of
  Records beneath the Sphinx. 
    
       The Hall of Records is a fourth-dimensional portal passage storage area that
 connects to the higher-dimensional morphogenetic ﬁelds of Earth, Tara and
  Gaia, where the complete planetary memory banks are stored in the form of
 crystalline energy substance. These crystalline morphogenetic imprints are
 collectively called the Ancient Dora-Teura Matrix, and they contain the
 entire living memory of the five Harmonic Universes in one l5-dimen-
  ional system. The Akashic Record planetary memory bank of D-8 is part
   of the larger Ancient Dora-Teura Matrix memory complex. The Hall of
   Records represents a D-4 conduit through which data from the Akashic
   Record and Ancient Dora-Teura can be downloaded through the Earth’s
   seven-primary vortices and into the Sphere of Amenti and Earth’s mor-
   phogenetic field. The data is transferred electronically through the Hall of
   Records, into Amenti and Earth’s core, then into Earth's grid. The history
  of the universe then becomes available to anyone on Earth that has a high
         enough accretion level to translate the data through their genetic code
  
  206 

                                                     
                                                            The Amenti Ascension Program Schedule
and consciousness. The Hall of Records opens only when the Alcyone spi-
ral is aligned with the primary fourth vortex beneath the Sphinx and
Great Pyramid. 
Within the structure of the Sphinx there are several dormant portal pas-
sages that lead from the Sphinx, to the Great Pyramid then into the D-2
portal passage of Earth’s core, where the Sphere of Amenti is stored. Once
the Alcyone spiral is activated, these portals are accessible, but only to
individuals who carry very precise frequency tone combinations within
their bio-energetic fields. In order for the Hall of Records to release its
data through the portals of the Sphinx and into the Sphere of Amenti, the
three individuals who represent the Flame Holders of the D-2 Orange-
Gold Flame (a male), the D-5 Blue Flame (female) and the D-7 Violet
Flame (female) must enter the Sphinx through the D-4 astral plane, and
find their way to the inner chamber and the portal activation site, which
is a very small crawl space, boxed-in on three sides, just large enough to
hold three bodies (astral) lined up side by side. The activation site is
underground and is presently sealed by several layers of stone, its access
crawl space, through which it was constructed, is packed with earth. There
are several hidden passages within and beneath the Sphinx, that are marked with
a series of instructional symbol codes, the ﬁnal four of which can only be
decoded by the Flame Holders. The symbols are multidimensional Keylontic
Access Codes that, once translated and pulled into the body, serve as the elec-
tronic lock release for the Hall of Records. 
The Flame Holders will be guided to Egypt with a small support team to
help them hold the energy, at the appropriate time. The Flame Holders
must enter the activation site using the astral body. Ideally, they must
project from the physical body stationed within the King’s Chamber of the
Great Pyramid. When the Alcyone spiral is activated, the Flame Holders
within the Kings Chamber will receive a “Blue Flame Infusion” (a bodily
infusion of UHF D-5 energy from the Alcyone spiral), through an energy
rite known only to the Flame Holders and beings with D-15 “clearance”
(beings whom have undergone 15-dimensional initiations and carry the
imprint for D-13 through D-15 within their morphogenetic field). After
the infusions, the Flame Holders will link their bio-energetic fields, and
enter the astral plane and access site together. Once in the activation site
the three will blend the energies of their astral bodies in one unit of ultra-
conscious energy identity. The physical and astral bodies of the Flame
Holders serve as a conduit through which the electronically stored data
from the Hall of Records can download, activate the portals and pass into
the Sphere of Amenti. The Flame Holders allow the Hall of Records to be
put “on line” with the Sphere of Amenti, after which time this data trans-
mits through Earth’s grid and becomes available to anyone on Earth who
can translate the information. The Hall of Records begins opening with
207 
                                                                                                                  

      Things to Come 
      the activation of the Alcyone spiral, but cannot be accessed until the Blue
         Flame of Amenti embodies on Earth, with the birth of the sixth avatar.
       The birth of the sixth avatar creates an energetic connection between 12
          dimensions of the Hall of Records and the Earth’s core, which allows data
       to ﬂow through the Flame Holders and into the Sphere of Amenti. If the
        Halls of Amenti cannot open, the Hall of Records also remains closed.
      Prior to the opening of the Hall of Records, the chambers leading to the
       dead-end in front of the activation site in the Sphinx will be discovered.
         The Halls of Amenti will begin to open on 5/5/2012. The Hall of Records
         will begin opening on 9/17/2001, but will not activate and begin transmit-
       ting data until after the birth of the sixth avatar, which is scheduled for
        12:01 am on 5/5/2012. At this time the Flame Holders will be called to
         activate the Hall of Records for the races. 
 
      8.  2001: Dracos-Zeta Resistance Tentative Plan to Stage Public Landing
       and Introduction to Begin Frequency Fence Project. Guardians Plan
              “Fly-by’s” if  Warning of Earth Changes Is Needed. 
 
             The Dracos-Zeta Resistance tentatively plans to stage a public landing in
       order to deceptively introduce themselves as Guardians and begin covert
                   infiltration of Earth’s electrical power supply and water systems in prepara-
           tion for implementing their Frequency Fence. The Resistance forces will not
           land if they believe their Frequency Fence plan is in jeopardy. If Earth’s grid
              reaches a 3.75-accretion level by 2001, (which will only occur if 8% of the
           population assembles the fifth DNA strand by 2001; this is not expected
           until just before 2012) the Resistance Frequency Fence will not work on
           the masses. If the Frequency Fence plan can be averted, the Resistance
            will abandon their direct take-over plans, and resort to instigating Earth
         changes. 
           If they cannot gain control over human populations, they still hope to
           stop the Halls of Amenti from opening, so the acceleration of the human
           genetic blueprint does not take place. The Resistance will lose control
           over their future D-4 stronghold if present human populations can assem-
           ble the fourth and fifth DNA strands. For this reason the Resistance has a
           vested interest in keeping the Halls of Amenti closed. Without the Fre-
           quency Fence it will be difficult for them to stop the Bridge Zone project,
           the opening of Amenti and the accelerated genetic evolution it will bring.
           If they cannot stop these events they will attempt to gain dominion over
           the D-3 “phantom Earth”, to begin rebuilding their strong hold from D-3
           after 2017, a plan that is likely to fail if Guardians decide to enforce a ban 
          on Resistance presence. 
             If   the  Frequency  Fence   plan  is  stopped  there    is  a  strong   likelihood  that Resistance
          forces will leave of their own accord. If the Frequency Fence plan is not
     stopped, humans remaining on D-3 phantom Earth will still remain vul-
  208 
      
     

                                                           
                                                        The Amenti Ascension Program Schedule
    
   nerable to Resistance infiltration. The Frequency Fence plan can still be
    averted if the Interior Government stops all cooperation with the Resis-
  tance EBEs and refuses to allow the 2003 experiment to take place.
 
      In the event that the public landing of 2001 does occur, the Resistance
       Frequency Fence plan is still operational, and Earth populations will have
   until 2004 to assemble DNA to the 3.75 accretion level in order to protect
     themselves from the Frequency Fence. If the Frequency Fence plan is
   operational Guardian Visitors may stage mass sighting “ﬂy-by’s”, anytime
   between 1998-2004, in order to warn the populations that Earth changes
   will be coming due to the Frequency Fence. In the event that the Fre-
    quency Fence is averted by 2004, and severe Earth changes are not
   expected, Guardians will NOT stage mass “fly-by’s”. We are hoping the
   Frequency Fence plan will be abandoned. Humanity can help this effort
   by trying to assemble and activate the fifth DNA strand in 8% of the pop-
    ulations by 2001. Presently an estimated 0.24% of global populations have
     the fifth strand assembled and activated. Reaching 8% by 2001 is not
   likely, but it is not impossible if humanity really tries to reach this goal. If
    this goal can be reached the Dracos-Zeta Resistance takeover plan can be
     stopped before it is put into action. 
  9.  January 2002: Keepers of the Blue and Violet Flames End Blue Wave
   Infusions. Keepers of the Blue Flame Begin Violet Wave Infusions.
    The Keepers of the Blue and Violet Flames will complete their Blue Wave
   infusions in 1/2002 and the Keepers of the Blue Flame will begin Violet
      Wave Infusions. The Keepers of the Blue and Violet Flames complete
   their D-5/D-6 Blue Wave Infusions that began on 6/26/1998. The Keepers
   of the Blue Flame are halfway through their D-5 Pleiadian-Soul Seat Acti-
   vation and their D-6/D-7 Violet Wave Infusion begins. Through these D-
   6/D-7 Wave Infusions, D-6 base tone and D-7 overtone frequencies, and
   imprints for DNA strands 6 and 7, enter into the morphogenetic fields of
  the Keepers of the Blue Flame. The Keepers of the Violet Flame will begin
  their D-5 Pleiadian-Soul Seat Activation on 1/1/2005 and their Violet
   Wave Infusions will begin in 1/2007. Shifting to the Bridge Zone Earth
    requires completion of the Blue Wave Infusion, activation of half of the
   fifth DNA strand, completion of the Solar-Heart Star Activation and half
   of the Pleiadian-Soul Seat Activation. The D-5 Pleiadian Activation
   becomes available to the masses (those who were not born with the fifth
    DNA strand imprint) on 9/9/2004, with the birth of Avatar 4 and the
  release of the corrected fifth DNA strand imprint through Earth’s grid. At
  this time fifth strand assembly can begin for those who completed fourth
         strand assembly and Heart Star Activation through the Solar Activation.
     The masses will not be able to complete the D-5 Pleiadian Activation
   until the 5/5/2012, following the birth of Avatar 6 and the activation of
       the fifth-strand codes.  
209     
 
                                                                   
  

          
             Things to Come
    10. June 2002: Earth Begins First Stellar Wave Infusion—The Blue Wave
   Infusion. 
    Earth is halfway through its D-4 Solar Activation, as the frequencies of
    the D-5/D-6 Blue Wave Infusion descend through the Pleiadian-Alcyone
     and Solar Spirals, beginning Earth’s first Transmutative Stellar Wave lnfu-
    sion, the D-5/D-6 Blue Wave Infusion. Through these D-5/D-6 Wave
  Infusions, D-5 base tone and D-6 overtone frequencies enter into Earth’s
 core morphogenetic field. Earth’s Blue Wave Infusion will complete in 6/
  2006, when Earth’s Violet Wave Infusion begins. In 6/2004 the D-5 Pleia-
  dian-Alcyone Spiral comes into alignment with the D-4 Solar Spiral,
  completing Earth’s D—4 Solar Activation and beginning Earth’s D-5 Pleia-
 dian Activation. Earth will complete six Stellar Wave Infusions between
  6/2002 and 6/2017. Three of these infusions will occur concurrently with
    the final three Stellar Activations within a 3-day period that will fall
  somewhere between 5/5/2017 and 6/30/2017. 
                                           
                                                                   
                                                           2003 Zeta Experiment
 
     11. August 12, 2003: Dracos-Zeta Resistance and Covert Government
   Dimensional Blending Experiment. 
    The Dracos-Zeta Resistance hopes to coerce the Interior Government to
    orchestrate a Dimensional Blending Experiment through top secret mili-
     tary operations. The experiment resembles the Philadelphia Experiment
    of 1943 and the Montauk Project of 1983. The Resistance’s covert moti-
   vation for the 2003 experiment is to create a rip in space-time that will
    connect with space-time rips that were made during the experiments in
     1943 and 1983, so they may cloak large numbers of spacecraft while bring-
    ing them into underground bases. The presence of these underground
   fleets at three different time intervals, is necessary for the Resistance to
    broadcast the EM pulses of their intended Frequency Fence. If the Interior
     Government and world military organizations can be convinced to stop any
       such dimensional blending experiments, especially during the months of July
   through October of 2003, the Frequency Fence agenda will be abandoned.
 
  12. Spring 2004: Dracos-Zeta Resistance to Begin EM Pulses of Frequency
     Fence. 
    If the Dracos-Zeta Resistance is successful in motivating the 2003 experi-
  ment and the Earth’s grid is not yet at 3.75 accretion, they intend to begin
    broadcasting the base EM pulses of the Frequency Fence, from several
    underground base locations. The Resistance will have introduced an
    undetectable organic element to mass water supplies by this time, which is
   needed to repress the human body’s natural immunological response to
    the foreign EM pulses used in the Frequency Fence. If transmission of the
     Frequency Fence base pulses begins, an undetectable ULF “phantom”
     electrical pulse will begin to be transmitted through Earth’s grid, into the
   210 
                   
       

                                                   
                                                                        The Amenti Ascension Program Schedule
bio-energetic and electro-chemical systems of humans and into mass elec-
trical power stations. The phantom pulse will follow the natural ﬂow of
electricity from main power generation plants into all electrical systems
drawing power from those plants, and will thus be transmitted through all
commercial and residential electrical devices. The ULF EM phantom
pulse will create a subtle disruption within the bio-energetic fields of
humans, which will manifest in the body as a bio-neurological perceptual
block, through which the human conscious and sub-consciousness minds
can be blocked from translating perceptual data from all but a few select
dimensional frequency bands. A “perceptual harness" on human conscious-
ness will result, through which the Resistance can transmit Holographic Inserts
and subliminally impulse human behavioral response patterns directly through
the sub-conscious mind and physical body. 
   
     The human body has a natural immune response to such electromag-
netic invasion, which the Resistance can repress by introducing a certain
organic elemental compound into the water supply, and by transmitting
specific wave spectrums of light directly into the human optical facilities.
Technologies such as broadcast television are intended as vehicles to carry
the subliminal light-spectrum patterns into the human optical facilities.
Common radio waves are also intended as carriers of subsequent EM
pulses, which will serve to reinforce the bio-neurological programming of
the Frequency Fence. 
  
     The Resistance will attempt to use your own technologies against you.
After approximately six years of such covert electromagnetic manipula-
tion, the contrived electromagnetic imprint will be strong enough to over-
ride the natural DNA imprint within the personal morphogenetic field.
The perceptual harness will manifest as a genetic mutation within the
human DNA, a mutation that will be genetically passed on through
breeding. The Frequency Fence is a powerful, advanced, EM pulse tech-
nology of which the Resistance is in possession and now intends to use on
the human populations. Human technology presently does not have such
command of EM pulse mechanics, and so will be unable to create techno-
logical protection from the Frequency Fence. 
          However, humanity does possess the natural ability to accelerate the genetic
code, through which natural immunity to the Frequency Fence, the water
additive and the subliminal, digital light-spectrum transmissions can be
created. It is much easier to prevent the Frequency Fence from affecting the bio-
neurological system, by building this natural immunity before the EM pulse
transmissions begin, than it will be to reverse the effects of these transmissions
once the broadcasting is initiated. If the Frequency Fence plan is not averted
by 2004, the Frequency Fence will be operational by 2006, at which time
the Resistance will begin broadcasting mass Holographic Inserts—five-   
      211 
                                                                                                       
                                                                                                                        
                                                                                                                          

                        Things to Come
             sensory perceptual—illusions-into Earth’s   atmosphere, through which the
        masses can be directed as the Resistance desires. Can you understand why
        we of the Guardian Alliance are trying to educate your race in regard to
       the very real ET technologies the Resistance plans to use against you? We
          are not trying to frighten you. We are hoping you will be mature enough
          to comprehend the consequences of such technologies before you
          unknowingly fall under this inﬂuence. You have the power to stop the Fre-
       quency Fence now, by taking command of your personal evolutionary
         imprint. You can protect yourselves if you are willing to learn how to do
            so. 
                                        
                                                          Earth's Pleiadian Activation
        13. June 2004: D-5 Pleiadian-Alcyone Spiral Aligns with D-4 Solar Spiral.
           Earth’s Fifth Vortex—Machu Picchu, Peru—-Opens. Earth Completes
       Solar Activation and Begins Pleiadian Activation. The Sphere of
                   Amenti Begins Transmitting D-5 Frequency into Earth’s Grid. 
         The Sphere of Amenti completes opening its D-4 frequencies into Earth's
         morphogenetic field, Earth’s fourth primary vortex at Giza is fully opened
        and activated and the natural seal on Earth’s fifth primary vortex begins to
        open and activate as the D-5 Alcyone spiral aligns with the D-4 Solar Spi-
         ral. Earth’s fifth primary vortex is located in Machu Picchu, Peru. The
        Sphere of Amenti begins transmitting its D-5 frequencies into Earth’s grid
        as Earth completes its D-4 Solar Activation and begins its D-5 Pleiadian
         Activation. The morphogenetic wave continues build. The particles of
        Earth’s D-2 elemental kingdom begin to merge with Tara’s D5 anti-parti-
          cles, Earth's D-3 atmospheric anti-particles begin to merge with Tara’s D-6
        particles. Earth’s D-2 and D-3 Merkaba Field begin to merge with Tara’s
        D-5 and D-6 Merkaba Field, through the pathway of the Alcyone spiral.
        By the end of its Pleiadian Activation in 6/2008, Earth will complete the
        final 2/3 of its shift into the HU-2 time cycles, in preparation for merger
          with Tara on 5/5/2012. 
      14. September 9, 2004: Tentative Birth of Avatar 4—Tenth-level Avatar.
         Will Align DNA Strand 5 with 12-strand Pattern. Corrected Strand 5
           Imprint Begins Transmitting through Earth’s Grid. 
        The fourth of six Silent Avatars is scheduled to be born; the birth can
       occur before this date, following the birth of Avatar 3 on ]une 26, 1998,
        but must take place by September 9, 2004, to realign the fifth DNA strand
        imprint in the Sphere of Amenti morphogenetic field, before this strand
        imprint begins transmitting through Earth’s grid on 9/9/2004. The fourth
        avatar is a D-10 soul essence from HU-4, a tenth-level avatar, with 10-
       dimensional frequency bands activated in its genetic code. This individual
        will be born with strand 10 fully activated. As this soul essence passes
       through the Sphere of Amenti, the imprint for DNA strand 5 will realign
     212 
                    
              

 
 
 
 
                                                The Amenti Ascension Program Schedule 
with the 12-strand DNA pattern, and the fifth strand imprint will begin
transmitting through Earth’s grid. The Palaidor, Amenti and Zeta Seals
will be fully released from the DNA in all whom worked to assemble the
fourth strand. Though the corrected fifth strand begins assembly in 2004,
for most of the populations it will not fully activate, or plug into the lower
strands and become operational, until 5/5/2012, when the Blue Flame is
embodied on Earth. The D-5 Pleiadian Activation pre-activation strand 5
assembly becomes available to the masses on 9/9/2004, but completion of
this activation and activation of the Soul Seat Star Crystal, will not be
available to the masses until the fifth strand activates after 5/5/2012.
Completion of the Pleiadian Activation and assembly and activation of
the fifth DNA strand allows the consciousness to achieve the second level
of soul integration, the Soul Seat Activation, and begins the process of
cellular transmutation through which the body can raise its particle pulsa-
tion rhythm into the HU-2/D-5 time cycle for teleportation through the
Halls of  Amenti. Ascension to Tara requires completion of the Pleiadian Acti-
vation, full activation of strand 5, completion of  half of the Violet Wave Infusion
and activation of the Soul Seat Star Crystal. 
        15.  2005-2017: Second Birth Wave of Indigo Children. 
          The second wave of 5,500 D-6 soul essence—Root Race 7: Paradisian
           children, who possess the imprint for DNA strand 6, will birth on Earth.
         They will reach maturity and activation of the sixth DNA strand at the
         age of 12, between 2017-2029, to become Place Holders that ground D-6
              frequency on Bridge Zone Earth following the 2012-2017 ascension
               period. 
    16.  January 1, 2005: Keepers of the Blue Flame Begin Sixth DNA Strand,
             D-6 Sirian-Earth Star Activation. Keepers of the Violet Flame Begin
               Fifth DNA Strand, D-5 Pleiadian-Soul Seat Activation. 
   The Keepers of the Blue Flame complete their D-5 Pleiadian -Soul Seat
    Activation and begin their D-6 Sirian-Earth Star Activation. Through
    the Sirian Activation they will assemble and activate the sixth DNA
   strand and complete the third level of soul identity integration, in prepa-
    ration for embodying Tara’s Blue Flame morphogenetic field on 5/5/2012.
    The Keepers of the Violet Flame begin their D-5 Pleiadian-Soul Seat
    Activation and assembly and activation of their fifth DNA strand, begin-
    ning the second level of soul identity integration, in preparation for
         embodying Gaia’s Violet Flame morphogenetic field on 1/1/2017.
    17. June 2006: Earth Completes Blue Wave Infusion and Begins Violet
  Wave Infusion. 
Earth will be halfway through its D-5 Pleiadian Activation, the D-5/D-6
Blue Wave Infusion that began in 6/2002 completes and the D-6/D-7 Vio-
let Wave Infusion begins. Through these D-6/D-7 Wave Infusions, D-6
        213 

                 Things to Come
      base tone and D-7 overtone frequencies are entered into Earth’s core mor-
      phogenetic field. Earth will complete its D-6/D-7 Violet Wave Infusion,
         and begin its D-7/D-8 Gold Wave Infusion in 6/2010. 
         18. 2006: Dracos-Zeta Resistance to Begin Broadcasting Holographic
        Inserts, if Frequency Fence is Established in 2004. 
     Dracos-Zeta Resistance plans to begin broadcasting mass Holographic
      Inserts through their Frequency Fence in order to direct populations away
        from the path of ascension and to establish full covert control over global
      social and economic structures. Once populations are under perceptual
       control Resistance members can walk among humans undetected. They
      plan to create various types of geographical disturbances that interfere
       with the grid merger between Earth and Tara. If it was not for the Bridge
       Zone Project these activities could have stopped the opening of the Halls
      of Amenti. The Frequency Fence and intended grid disruptions can still
       cause Earth changes between 2012-2017, but the Halls of Amenti will
        remain stable as long as Earth's core morphogenetic field reaches the 3.5
       accretion level necessary for Earth to enter the Bridge Zone pulsation
       rhythm in 2012. Only the phantom Earth that returns to the D-3 time
         cycle after 2017 will be susceptible to Resistance control and the massive
       Earth changes that could result from the Frequency Fence and related
        activity. Humans with an accretion level below 4.5 (all of the fourth DNA
        strand assembled and activated plus half of the fifth strand) will end up in
      this future D-3 time continuum after 2017. The Earth changes, Holo-
         graphic Inserts and mental take over can be stopped in this D-3 time cycle
      if humanity can help the Guardians stop the Resistance from activating
        the Frequency Fence in 2004. 
  19. January 2007: Keepers of the Blue Flame Begin Gold Wave Infusions.
           Keepers of the Violet Flame Begin Violet Wave Infusions.  
 
  The Keepers of the Blue Flame are half way through their D-6 Sirian-
      Earth Star Activation, the D-6/D-7 Violet Wave Infusion that began in 1/
      2002 completes and the D-7/D-8 Gold Wave Infusion begins. Through
      these D-7/D-8 Wave Infusions, D-7 base tone and D-8 overtone frequen-
         cies, and imprints for DNA strands 7 and 8, enter into the morphogenetic
       fields of the Keepers of the Blue Flame. The Keepers of the Violet Flame
      are half way through their D-5 Pleiadian-Soul Seat Activation, the D-5/
      D-6 Blue Wave Infusion that began in 2002 completes and the D-6/D-7
      Violet Wave Infusion begins. Through these D-6/D-7 Wave Infusions, D-
        6 base tone and D-7 overtone frequencies, and imprints for DNA strands 6
     and 7, enter into the morphogenetic fields of the Keepers of the Violet
          Flame. 
    214 
 
                   

                                                            
                                                                           
                                                                          The Amenti Ascension Program Schedule
                                   
                                                             
                                                            Earth’s Sirian Activation
                 
                 20. June 2008: D-6 Sirian Spiral Aligns with D-5 Pleiadian-Alcyone Spi-           
                             ral. Earth’s Sixth Vortex—Caucasus Mountains, Russia—Opens. Earth          
                    Completes D-5 Pleiadian Activation and Begins D-6 Sirian Activation. 
 
      The Sphere of Amenti Begins Transmitting D-6 Frequency through 
                    Earth’s Grid. Earth Completes Shift into HU-2 Time Cycles. 
          The Sphere of Amenti will complete its  opening of D-5 frequencies into
        Earth’s morphogenetic field, the fifth primary vortex in Peru will be fully
     opened and activated, and the natural seal on the sixth primary vortex
        will  open. Earth’s  sixth     primary  vortex  is located  in   the  Caucasus Moun-
    tains in Russia. The Sphere of Amenti begins transmitting D-6 frequency  
   through Earth’s grid, as the D-6 Sirian Spiral aligns with the D-5 Alcyone                  
  Spiral. Earth completes its D-5 Pleiadian Activation that began in 6/2004
       and begins its D-6 Sirian Activation. 
            At the end of its Pleiadian Activation on 6/2008, Earth completes its ﬁnal 2/3
             shift into the HU-2 time cycles, in preparation for the merger of the grids of
         Earth and Tara on 5/5/2012. The morphogenetic wave continues to build
        as Tara’s D-4 and D-5 particles begin to merge with Gaia’s D-7 and D-8
          anti-particles, and Tara’s D-4 and D-5 Merkaba Fields begin to merge with
          Gaia’s D-7 and D-8 Merkaba Fields. Tara’s D-4 and D-5 particle base
                moves  into  the  D-7 and D-8 time  cycles  of  HU-3 while  Earth’s temporary
        shift into the HU-2 time cycles completes. 
             21. July 22, 2008: Tentative Birth of Avatar 5—11th-level Avatar. Will
          Align DNA Strand 6 Imprint with 12-Strand Pattern. Corrected
          Strand 6 Imprint Begins Transmitting through Earth’s Grid and the
             Templar Seal Can Release from DNA. 
          The fifth of six Silent Avatars is to be born on this date. The birth can
                 occur    earlier, following birth of Avatar 4 on 9/9/2004, but  it  must occur  by
             7/22/2008, when the sixth DNA strand imprint begins transmitting
              through   Earth’s   grid. The birth of     Avatar    5   is presently  scheduled for 7/22/
        2008. This avatar is a D-11 soul essence from HU-4, an 11th-level avatar,
        with 11-dimensional frequency bands activated in its genetic code. This
         individual will be born with strand 11 fully activated. As this soul essence
         passes through the Sphere of Amenti the imprint for DNA strand 6 will
            realign with the 12-strand pattern and the sixth strand imprint will begin
            transmitting through Earth’s grid. 
                 Though the sixth strand will assemble  in  2008, in those  who  have   assembled
                               strands 5 and below, the  sixth strand will not activate for most people until after
                   the Violet Flame embodies on Earth in 2017. Assembly and activation of the
         sixth DNA strand allows the consciousness to achieve the third and final
       level of soul integration, the Earth Star Activation, at which time the
         identity can choose to transmute into etheric form on D-7 Gaia, to begin
       215 
                                                                                                                                       
                                                                                                                                        

                  Things to Come
       
    embodiment of the over soul identity. Assembly of the sixth DNA strand
     releases the D-6 Templar Seal, which made bodily ascension impossible
      for those with this genetic configuration. The Templar Seal was placed on
     certain race strains in 8000 BC, and created genetic distortion in many
           others through interbreeding. Release of the Templar Seal allows one to
       fulfill activation of the sixth DNA strand for ascension to Gaia and
       beyond. 
  22. January 2009: Keepers of the Blue Flame Begin Seventh DNA Strand,
    D-7 Arcturian-Core Star Activation. Keepers of the Violet Flame Begin
      Sixth DNA Strand, D-6 Sirian-Earth Star Activation. 
    The Keepers of the Blue Flame complete their D-6 Sirian-Earth Star Acti-
    vation and will activate their seventh DNA strand beginning their D-7
      Arcturian-Core Star Activation, which begins embodiment of the first
          level of the over-soul identity, in preparation for embodying the Blue
     Flame in 2012. The Keepers of the Violet Flame complete their D-5 Pleia-
      dian-Soul Seat Activation and will activate their sixth DNA strand to
     begin their D-6 Sirian-Earth Star Activation, beginning the third level of
     soul identity integration, in preparation for embodying the Violet Flame
        in 2017. 
  23. June 2010: Earth Begins Gold Wave Infusions. 
     Earth is half way through its D-6 Sirian Activation, the D/6/D-7 Violet
       Wave Infusion that began in 6/2006 completes and the D-7/D-8 Gold
      Wave Infusion begins. Through these D-7/D-8 Wave Infusions, D-7 base
    tone and D-8 overtone frequencies are entered into Earth’s core morpho-
       genetic field. 
  24. June 2011: Keepers of the Blue Flame Begin Silver Wave Infusions.
        Keepers of the Violet Flame Begin Gold Wave Infusions. 
       The Keepers of the Blue Flame are half way through their D-7 Arcturian -
    Core Star Activation, the D-7/D—8 Gold Wave Infusion that began in 1/
      2007 completes and the D-8/D-9 Silver Wave Infusion begins. Through
    these D-8/D-9 Wave Infusions, D-8 base tone and D-9 overtone frequen-
       cies, and imprints for DNA strands 8 and 9, enter the morphogenetic
          fields of the Blue Flame Holders. The Keepers of the Violet Flame are half
          way through their D-6 Sirian-Earth Star Activation, the D-6/D-7 Violet
           Wave Infusion that began in 1/2007 completes and the D-7/D-8 Gold
               Wave Infusion begins. Through these D-7/D-8 Wave Infusions, the D-7
           base tone and D-8 overtone frequencies, and imprints for DNA strands 7
        and 8, enter the morphogenetic fields of the Keepers of the Violet Flame.
   25. January 1, 2012: Earth Completes D-6 Sirian-Earth Star Activation.
     Earth’s Seventh Vortex—Andes Mountains, South America-—Opens.
       Amenti Begins Transmitting D-7 Frequency through Earth’s Grid. Blue
      Flame Begins its Final Approach to Earth through the Alcyone Spiral
 216 
  

                                               
                                                                    The Amenti Ascension Program Schedule
Keepers of the Blue Flame Activate Eighth DNA Strand and Begin D-8
Orion-Earth Core Activation. Keepers of the Violet Flame Activate
Seventh DNA Strand, D-7 Arcturian-Core Star Activation. 
Earth completes its D-6 Sirian Activation, that began in 6/2008 and D-6
frequencies from the Earth’s core morphogenetic field begin transmitting
through Earth’s grid. As this occurs, D-7 frequencies from the Sphere of
Amenti begin transmitting through Earth’s grid and the Sphere of Amenti
completes opening its D-6 frequency into Earth’s morphogenetic field.
Earth completes the first 3 Activations of its Transmutative Stellar Acti-
vation cycle, and will not begin its fourth D-7 Arcturian Activation until
the D-7 Arcturian Spiral aligns with the D-6 Sirian spiral on day one of
the Three-day Particle Conversion Period between 5/5/2017 and 6/30/
2017. 
    By 1/2012 the sixth primary vortex in the Caucasus Mountains will be
fully open and activated and the natural seal on the seventh primary vor-
tex will begin to open and activate. Earth’s seventh primary vortex is
located in the Andes Mountains of western South America. The Blue
Flame of Amenti begins its final approach to Earth through the Alcyone
spiral. The Keepers of the Blue Flame complete their D-7 Arcturian -
Core Star Activation, fully activating the seventh DNA strand to become
seventh-level avatars, embodying the first level of the oversoul identity.
The Keepers of the Blue Flame begin activating the eighth DNA strand,
initiating their D-8 Orion-Earth Core Activation, which allows integra-
tion of the second level of the over-soul identity to become an eighth-
level avatar. Completion of the D-7 Arcturian-Core Star Activation
causes the Core Star crystal energy center within the body (above the
navel, below the third Solar Plexus chakra) to transmit D-7 frequency.
The bodies of the Flame Keepers become transmitters of UHF light and
sound, as their bio-energetic fields fill with D-7 frequency. The Flame
Keepers become conduits for D-7 energies, which ﬂow to Earth from the
Arcturian Spiral, through the Sirian, Pleiadian-Alcyone and Solar Spirals.
Through the bodies of the Flame Keepers achieving Arcturian-Core Star
Activation, D-7 frequency runs through Earth’s core, preparing Earth for
its 2017 alignment with the Arcturian Spiral and beginning the separa-
tion of particle fields within the Earth’s matter-body. Following the Core
Star Activation, the Blue Flame Keepers hold the power within their bio-
energetic fields to create seventh strand DNA activations in others, and to
assist others of lesser DNA strand assembly in passing through the Halls of
Amenti, once the Halls have opened. The D-8 Orion and D-9 Androm-
eda Activations allow the Flame Keepers to become transmitters of D-8
and D-9 frequency, capable of initiating Orion and Andromeda Activa-
tions in others and through which the Earth Core prepares to align with
   217 
                                                                                                                 
 
 

 Things to Come 
        the D-8 Orion and D-9 Andromeda Spirals in 2017. As the Keepers of the 
       Blue Flame begin their D-8 Orion-Earth Core Activation, the Keepers of 
       the Violet Flame begin their D-7 Arcturian-Core Star Activation. 
    26. March 2012: Keepers of the Blue Flame Begin Blue-black Liquid Light 
     Wave Infusions. 
 
   The Keepers of the Blue Flame are half way through their D-8 Orion- 
    Earth Core  Activation, the D-8/D-9 Silver Wave Infusion that began in 6/       
     2011 completes and the D-9/D-10 Blue-Black Liquid Light Wave Infusion         
          begins. Through these D-8/D-9 Wave Infusions, the D-9 base tone and D-
          8 overtone frequencies, and imprints for DNA strands 9 and 10, enter into 
        the morphogenetic fields of the Keepers of the Blue Flame. 
   27. May 5, 2012, 12:01 AM: Birth of Avatar 6—12th-level Avatar. Will 
      Align DNA Strand 7 Imprint with 12-strand Pattern. Templar-Axion 
    Seal Releases from Human DNA as Corrected Strand 7 Imprint Begins 
     Transmitting through Earth’s Grid. 
      The sixth of six Silent Avatars will be born precisely at this time, passing 
 through the Sphere of Amenti into fetal integration at 12:01 am, on 5/5/ 
      2012. This is a D-l2 soul essence from HU-4, a 12th-level avatar, which is 
    the highest level of identity that can be embodied through the human
       genetic code. Jesheua-12 (12 BC-27 AD), of   the  soul  identity   Sananda, was
     the last level 12 avatar to incarnate on Earth. The sixth avatar will be born 
     with 12-dimensional frequency bands activated in his genetic code, a fully 
      activated DNA strand 12. As his soul essence passes through the Sphere
  of Amenti, the imprint for DNA strand 7 will realign with the 12-strand
pattern, and the seventh strand imprint will begin transmitting through                     
Earth’s grid. As the seventh DNA strand imprint aligns and activates, 
the  D-7 “666” Templar-Axion Seal, which imposed repeated reincarnation
  for humans who carried this DNA mutation, is released from Templar-
   Axion sealed humans who begin assembling the seventh DNA strand.
        
                                        Halls of Amenti Open 
              28.  May 5, 2012: The Grids of Earth and Tara Begin to Merge and  the 
           Morphogenetic Wave Prepares to Crest. The Keepers of the Blue Flame                                            
          End D-8 Orion-Earth Core Activation and Begin D-9 Andromeda-                                                               
             Galactic Core  Activation. The Blue Flame of Amenti Embodies within
the Keepers  of  the Blue Flame. Spontaneous Mass Awakening Occurs.
The Halls of Amenti Open and Ascensions Begin. The Three Flame
Holders Are Called to Giza to Activate the Hall of Records.
The grids of Earth and Tara begin to merge as the morphogentic wave
prepares to crest. The Keepers of the Blue Flame complete their D-8
Orion-Earth Core Activation, becoming eighth-level avatars and begin
their D-9 Andromeda-Galactic Core Activation. As the ninth DNA
strand begins activation and assembly, the third level of the over-soul
   218 
  
 

                                                    
                                                                      The Amenti Ascension Program Schedule
embodies and the Keepers of the Blue Flame become ninth-level avatars.
The Keepers of the Blue Flame will complete their D-9 Andromeda Acti-
vation, to become ninth-level avatars, on day one of the Three-day Parti-
cle Conversion Period between 5/5/2017 and 6/30/2017. On 5/5/2012 the
Blue Flame of Amenti descends through the Alcyone spiral and into
embodiment within the Keepers of the Blue Flame. Embodiment of the
Blue Flame takes place through the primary Flame Holder, who magneti-
cally draws the Blue Flame from the Alcyone spiral and into her bio-ener-
getic field and body. Flame Holders carry a specific magnetic base tone
within their DNA that allows the bio-energetic system to become highly
magnetic, when this recessive gene is activated. Without this extremely
rare recessive gene, the human body would be ripped apart in attempting
to draw energy directly from the Alcyone spiral while the Blue or Violet
Flames are descending. Flame Holders are incarnated on Earth during
appropriate times, after carefully selecting a parental lineage (via
Palaidorian Birthing Contracts) that carries this recessive gene, specifi-
cally to fill this role. These individuals are predestined via over-soul con-
tracts, to fulfill this role. 
 
There are three Flame Holder positions to fill, that of the D-2 Orange-
gold Flame (requiring male embodiment) and those of the D-5 Blue and
D-7 Violet Flames (female embodiments). For each position there are only
three individuals born that can fill this role, for a total of nine individuals
on the planet at any one time, who will carry this rare recessive gene. The
primary position is held by a Flame Holder who is appointed by the Galac-
tic Council of HU-4 and the second and third positions serve as “back-
up”, in the event that the primary Flame Holder cannot fulfill the role.
The primary Flame Holder chooses the souls who will serve as back up and
they incarnate during the same time period as per these soul agreements.
The Keepers of the Flames are likewise born into their roles via soul agree-
ments and will begin to awaken to their greater mission once it is time for
their service to begin. The Flame Keepers and Holders have begun to
awaken to their identity over the last 15 years. Once the Blue Flame
Holder has drawn the Blue Flame from the Alcyone spiral, the Flame
Holder then down-grades the frequencies of the Blue Flame through her
bio-energetic field and transfers the frequencies of the Blue Flame into the
Flame Keepers via the fourth/Heart chakra. Once the Blue Flame frequen-
cies stabilize in the morphogenetic fields of the Flame Keepers, an intense
infusion of HU-2 frequencies spreads through the Amenti morphogenetic
field and through the Earth’s grid, which allows rapid acceleration of fifth
and sixth DNA strand assembly to occur throughout the populations who
have begun assembling the fifth and sixth strands. The seventh strand will
begin to assemble in those who have assembled strands 6 and below.
Strand 5 rapidly begins to activate triggering a spontaneous expansion of
   219 
                          
                                                                                                                 
                                                                                                                 
 
 

                     Things to Come
    multidimensional awareness and awakening to multidimensional memory
     and identity within the populations who assembled the fifth strand.
     Strands 6 and 7, which have been assembled, will remain dormant until
    activation during the Three-day particle conversion period between 5/5/
      2017 and 6/30/2017. 
   
     As the grids of Earth and Tara begin to merge, the Halls of Amenti, within
     the Sphere of Amenti at Earth’s core, begin to open and people who have
     assembled the fifth strand and above can begin passing through the portals
       that connect to the Halls of Amenti and Tara. At this time, forward
        through 2022, people on the ascension path to Tara will be guided to the
      appropriate portal or interdimensional Transport locations for transfer to
     Tara. Just following the birth of Avatar six on 5/5/2012, the three primary
     Flame Holders and their support team will be called to Egypt to activate
      the Hall of Records portals. Numerous groups will try this feat prior to this
     time, but only the three Flame Holders possess the needed frequency
     codes in their bio-energetic fields to allow them to serve as conduits for
      downloading the electronic transmissions from the Dora-Teura Matrix
      and Akashic Record. Once the portals between the Sphinx, Great Pyra-
          mid and Earth's core open, universal memory comes “on line” within the
          Sphere of Amenti and the Sphere of Amenti prepares to release this con-
          tinual ﬂow of electronically coded data into Earth’s grid, where it can be
          picked up through the human bio-energetic field and translated into con-
            scious information. Reincarnational and race memory will become avail-
       able to people who have assembled the fourth DNA strand and above. 
  29. December 21, 2012: The Morphogenetic Wave Begins Cresting, Earth
       Begins Passing into the Holographic Beam and Photon Belt. Earth’s
       Particle Base Begins to Separate, Magnetic and Electrical Poles of Earth
     and Tara Reverse, Angular Rotation of Particle Spin Shifts 45°. The
     Grids of Earth and Tara Continue to Merge. Earth’s Fastest Pulsating
       Particles Begin Transfer to Hyper-space and the Hall of Records Begins
       Transmitting Data through Earth’s Grid. 
       As the morphogenetic wave begins cresting, Earth’s particle base begins
      separating in to fields of fast, moderate and slow pulsation. The fastest pul-
      sating particles begin to transfer from Earth, through Earth’s core and the
       Alcyone spiral, into the higher-dimensional morphogenetic fields/hyper-
      space. Earth begins passing into the Holographic Beam, Earth’s overtone
       particles pass into the Photon Belt and all of Earth’s electrical overtone
            particles and Tara’s base tone anti-particles enter hyper-space. The base
           tone particles left in Earth’s grid begin to blend with the overtone anti-
          particles left in Tara's grid, the polarity of the particles and anti-particles
          temporarily reverses and the angular rotation of particle spin shifts 45°.
           Earth’s magnetic poles reverse and shift 45° as Tara’s electrical poles
             reverse and counter-shift 45°. Between 12/21/2012 and 6/30/2017 the D-1
            220 
   
