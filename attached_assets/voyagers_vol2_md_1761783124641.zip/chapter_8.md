# Chapter 8

                                                                                             
                                                                                                   Merkaba Fields
their D-1 Merkaba Fields, which exist within the core of each planet and col-
lectively manifest as your Sun. When viewed from the vibration level of the
third dimension, which is where your consciousness and instruments are pres-
ently focused, the D-1 Merkaba Fields, which exist within the core of Earth and
the local planets, and which are within the core of the Sun, appear to be
located outside of the planets, many miles away in outer space. You are dealing
with multi-layered reality fields that take place in the same space, but appear to
be separated due to the relationship between particle pulsation rhythm and
angular rotation of particle spin. 
    The perceivable experience of movement, passing time, matter, space,
distance between objects and separation of forms is an illusion created by the
multidimensional, holographic refraction of particles and anti-particles,
which pulsate and spin at varying speeds and angular rotations in relation to
each other. The movement of particles itself is a holographic illusion; movement
only appears to be such when consciousness views itself through the layered prisms
of multidimensional order. It will be centuries before your scientists begin to
comprehend these facts of reality construction. However, while your con-
sciousness is focused within the multiple layers of dimensional reality, the
concepts of space, time, matter and movement will indeed appear to apply, so
we will continue our discussion following that paradigm of perception.
     You can begin to stretch your perceptual and conceptual fields by simply
pondering the following concepts and allowing your intuitive senses to bring to
you a sensed cognition of these realities of which we speak. When you look at
your Sun from the third dimension, you are seeing the D-1 Merkaba Field of
Earth and her sister planets. From the D-3 frequency level, when you view the
D-2 Merkaba Field surrounding Earth’s iron core crystal, which holds Earth’s
morphogenetic field, it appears to be the solid matter makeup of your Earth’s
body and elemental/telluric kingdom. From the D-3 view, the D-3 Merkaba
Field is the Earth’s atmosphere within which your present reality takes place.
The distance of outer space that you perceive between Earth, the Sun and the
planets represents the magnetic repulsion zone that separates the D-1, D-2 and
D-3 frequency bands of HU-1 from the counter-rotating D-4, D-5 and D-6 fre-
quency bands of HU-2. 
     All dimensions exist in the same space, but seem to operate separately due
to the particle pulsation rates of which they are composed. Particle pulsation
rates are created by the degrees of angular rotation at which particles and anti-
particles spin in relation to each other. In one universe there are 15 primary
dimensional bands. Dimensional frequency bands group in sets of 3, and each
set of three dimensions represents a Harmonic Universe. Thus there are five
Harmonic Universes within one 15-dimensional Universe. The degree of angu-
lar rotation of particle spin shifts 90° from one dimension to the next within
one Harmonic Universe. In each Harmonic Universe containing three dimen-
129 
                                                                                                                                                                                                                 

     
     Countdown to Amenti 
sions, there are two 90° shifts of the angular rotation of spin between the parti-
cles. Between one Harmonic Universe and the next there is a 45° reverse
angular rotation of particle spin. This 45° reverse angular rotation of particle
spin creates a Magnetic Repulsion Zone, or “void” between Harmonic Uni-
verses, which keeps the reality fields contained there within separated from
each other. These Magnetic Repulsion Zones are what you perceive as the
seemingly endless vestiges of outer space. Through this structure of relative
angular rotations of particle spin, the holographic illusions of multidimensional
reality, matter, time, space, movement and individuation of form are perpetu-
ally created and sustained. This will conclude our brief introductory lesson in
multidimensional physics; we hope we have provided some interesting ideas for
your more courageous scientists to explore. 
                
 THE PHILADELPHIA EXPERIMENT AND SOLAR CRISIS 
                                   
                                 The Philadelphia Experiment 1943 
     We will now resume our discussion of the Zetas plan to stop the merger of
Earth and Tara’s grid and what they did to the Sun in 1943 that almost caused
the extinction of the human population on Earth in the 1970s. 
    The Zetas determined that in order to retain control of the human soci-
ety within the future space-time coordinates where they had successfully
achieved dominion over Tara-Earth’s territories in the D-4 time cycle, they
had to stop the fifth DNA strand from manifesting within the human popula-
tions of present-day Earth. Re-alignment of the fourth DNA strand by
Guardian groups had broken down their D-4 Frequency Fence and they were
losing control of their human subjects in the future. If the fifth DNA strand
activated within 8% of Earth’s present human populations, the race Morpho-
genetic Field in the Sphere of Amenti would realign the Frequency Fence
distortions in the grids of Earth and Tara, and the Zetas’ Frequency Fence and
Zeta Collective Mind Complex in D-4 would be destroyed. The upcoming
morphogenetic wave period of 2012-2017 in Earth's present time cycle would
allow all Earth humans to begin assembly of their fifth DNA strand and the
D-4/strand-four Zeta Seal would be released in all humans. After 2017 the
Zetas would totally lose control of the future human populations, if they did
not stop the fifth DNA strand from activating within Earth humans and stop
the present Earth grid from receiving its scheduled infusion of fifth to ninth-
dimensional frequencies. 
    From the beginning of their involvement with the covert human gov-
ernments, the Zetas held this secret agenda of Earth infiltration. When they
offered the Allied Governments technological information that helped them
win World War II, the Zetas had ulterior motives. In 1943 the Zetas offered
the U.S. Navy a rudimentary technology that would allow them to make
objects appear invisible. On August 12th, 1943 the experiment was con-
130 

                                                     
                                                   
                                      The Philadelphia Experiment and Solar Crisis
 
ducted in Philadelphia, PA, using a battle ship, the U.S.S. Eldridge. The
event became known as the Philadelphia Experiment. We will not detail the
experiment here, as there are several published accounts of this event, but we
would like you to understand the Zetas’ motivation for instigating this
project. The Zetas knew that in creating such an experiment, which utilized
the creation of an external, manufactured Merkaba Field, that the functions
of Earth’s natural Merkaba Fields would be disrupted. They failed to share
this knowledge with the US. government. The experiment created a “rip in
space-time,” or a tear in the natural Merkaba Fields, which served as a dimen-
sional warp through which the Zetas could secretly pass their ships to Earth
from their D-4 future location. Using this rip in space-time, the Zetas were
able to transport large numbers of their spacecraft, undetected by human
observation, into Earth’s D-2 Merkaba Field, and, from there, the ships could
be used to broadcast specific electromagnetic pulses directly into Earth’s D-1
Merkaba Field at the center of the Sun. 
    Because the Earth is directly connected to Sun through the Stellar
Spirals of the multidimensional Merkaba Fields, the Zetas knew they could
misalign the grids of Earth and Tara by manipulating the Merkaba Fields of
the Sun. They desired to create a Frequency Fence on Earth that would cause
the grids of Earth and Tara to repel each other in 2012. Earth would be
unable to receive its infusion of D-5 frequency, which would stop the fifth
DNA strand imprint from manifesting in the races and keep Earth trapped
within HU-1 for another 26,556-year cycle. They also knew that such a Fre-
quency Fence, applied during the half-point in the second ascension cycle,
would cause a pole shift on Earth, creating cataclysmic changes on Earth,
wiping out the majority of the populations, once the environment had re-sta-
bilized, the Zetas and Dracos planned to claim Earth’s territories as their own.
      The covert human government had no idea of the Zetas’ real plan when they
entered treaties with them during WW2, and they still do not know the extent to
which they have been manipulated by the Zetas. The Interior Government was
not aware of the dire consequences that could have resulted from these
actions. Violation of human rights through covert forced abductions of citi-
zens for hybridization experimentation was the least of the troubles created 
by the Zetas’ involvement. In 1943 the Zetas used the opportunity presented
by the Philadelphia Experiment to begin their plan of shifting the Earth’s grid
out of alignment with Tara via manipulating the energy fields of the Sun. To
the present day, the Interior Government does not realize that it was this
event which triggered abnormal activity on the Sun between 1949 and 1972,
activity which had some of Earth’s scientific community very concerned
about the probability of a major pole shift occurring sometime during the
1970s or 1980s. The Merkaba Fields of the Earth, the Sun and Tara are inti-
mately intertwined with each other and with the Pleiadian star system and
131 

      Countdown to Amenti 
others, so following 1943 the Zetas plan brought many different Guardian
groups into Earth's drama. 
    After the rip in space-time was made on August 12th, 1943, the Zetas
secretly positioned their spacecraft beneath Earth’s surface in the D-2 fre-
quency bands and began beaming electromagnetic pulses into the Sun.
Using these EM pulses, the following effects were created: 
    The spin of the base tone particles/magnetic field of the Sun’s D-1 Merk-
aba Field was reversed, which made the Sun’s D-1 magnetic spiral become
electrical. This change in the Sun created a reciprocal shift of polarity within
the D-1 Merkaba Field of Earth. Earth’s D-1 base tone particles/magnetic spi-
ral became electrical. This, in turn, caused Earth’s D-1 electrical/overtone
particle spiral to reverse and become magnetic. Through spacecraft posi-
tioned within the D-4 frequency bands, the Zeta next reversed the spin on
the Sun’s D-4 Merkaba Field, which set the pattern for Tara's grid through
the gold core crystal at the center of the Sun. The D-4 Merkaba Fields of par-
ticle and anti-particle Tara were reversed. These actions constituted a full
reversal of Earth’s D-1 electromagnetic Merkaba Fields, and a partial reversal
of Tara’s D-4 electromagnetic Merkaba Fields, putting both out of alignment
with the Merkaba Fields of D-2, D-3, D-5 and D-6. 
    Normally, when the grids of Tara and Earth begin to enter alignment
with each other about five years before the half-cycle point, the D-1 and D-4
Merkaba Fields line up as follows: 
    Earth’s electrical overtone spiral in D-1 aligns with Tara’s base tone mag-
netic spiral in D-4, and Earth’s magnetic base tone spiral in D-1 aligns with
Tara’s electrical overtone spiral in D-4. 
    This alignment of D-1 electrical to D-4 magnetic and D-1 magnetic to
D-4 electrical creates an interdimensional Resonant Tone through which the
planetary grids can fuse. Following the reversal of Tara’s D-4 and Earth’s D-1
Merkaba Fields, the new alignment between Earth’s and Tara’s Merkaba
Fields became D-1 electrical to D-4 electrical and D-1 magnetic to D-4 mag-
netic. The particles, which compose the planetary grids, would magnetically
repel each other and the grids of Earth and Tara could not fuse. But this plan
also causes major imbalance within the D-2, D-3, D-5 and D-6 Merkaba
Fields. If the Sirian Council and other Guardian groups had not intervened, the
human populations of Earth would have been vaporized between 1972-1974. 
    By 1950 Earth scientists began to notice odd phenomena occurring on
the Sun, as the Sun appeared to release periodic spirals of energy toward the
Earth. This phenomenon was heavily observed between 1952 and 1968, and
there was great concern that this solar anomaly would alter the wobble of
Earth upon its axis, creating a pole shift of the planet. Although most of this
information was blacked out of the media and kept from the public, some of
these studies were published in scientific journals and news papers, especially
after 1968, when the scientists calculated that if events continued as they
132 

                                                                         
                                                                            Solar Crisis and 11:11/12:12
    were, by 1972 there would be a huge explosion on the Sun that would cause
pole reversal and wipe out humanity by about 1984. On August 7, 1972 the
solar explosions began to occur. Earth scientists observed a rapid increase in
solar flares for several days, which peaked on August 7th, with the most
intense ﬂare ever recorded. Solar winds accelerated at an alarming rate in the
most intense solar storm ever witnessed by Earth scientists. Published
accounts of these observations can be found in scientific literature from this
time period. The solar winds increased rapidly between August 7th and
August 10th I972, then strangely the winds began a rapid decrease in speed
and the solar storms appeared to die down in the month that followed. This
was a perplexing observation to Earth scientists; they had no idea that the Sirian
Council had intervened. 
                                
                                 SOLAR CRISIS AND 11:11/12:12 
                                  
 
 
 
 
 
                                             Wave-of-Flame and Red Pulse 
        
      In January of 1972 members of the Sirian Council, Sirian-Arcturian
Coalition for Interplanetary Defense, the Pleiadian Star League and several
other Guardian groups entered the UHF bands of Earth’s atmosphere, aware
of the solar events that were to occur. If they had not intervened, Earth’s
populations would have been wiped out by 1974. When the electromagnetic
Merkaba Fields of the Sun are artificially manipulated, such as they were by
the Zetas following the Philadelphia Experiment, erratic electrical energies
build up within the Sun’s energetic grid, throwing all of the Sun’s Merkaba
Fields out of balance. As the misalignment of the Sun’s EM fields progresses,
it manifests as an acceleration of solar-ﬂare activity, which eventually culmi-
nates in surface explosions and temporary expansion of the Sun’s Merkaba
Fields, lasting about 950-970 years. 
      In 1972, the first explosions began to occur. The explosions would have
continued until about September of 1973, when the Sun’s D-1 Merkaba Field
would have burst open and expanded. The expansion of the Sun’s D-1 Merke
aba Field would have sent an intense wave of ULF energy out through all of
the planets in the local solar system. This wave of energy would cause a
chain reaction within all of the planetary Merkaba Fields, through which
pole reversal and vaporization of surface life would result. This wave of
expanding D-I energy is called a Red Pulse (red denoting its D-I frequency),
and it constitutes a wave of solar ﬂame within the D-1 frequency bands. Life-
forms on planets in the First Harmonic Universe cannot survive such an infu-
sion of ULF D-1 energy, because it would implode the molecular structure
before the genetic code could expand enough to process those frequencies.
    In order to avert the pending termination of Earth life, the Guardian
races, under the direction of the Sirian Council, altered several layers of the
morphogenetic fields of Earth and the local planets. As the Red Pulse Wave
133 
                                                                                                                                                              

      Countdown to Amenti 
of Flame would be coming in on the electrical overtone D-1 frequency bands,
all of the D-1 overtones were temporarily removed from the planetary mor-
phogenetic fields. This served to create a D-1 seal around Earth’s core, so the
ULF of the Red Pulse could not enter Earth’s grid, or the grids of the neigh-
boring planets. Next, a frequency seal was placed within the D-4 frequency
bands, in order to block D-4 frequencies from entering into Earth’s morpho-
genetic field. Once the overtones of D-1 were removed, Earth’s core could
not synthesize incoming D-4 frequency, and the core would explode, so D-4
frequencies had to be temporarily blocked from Earth. To create the D-4 seal,
the first 11 (out of 12) base tones and overtones of D-4 were removed from
Earth’s morphogenetic field, which meant that Earth’s lower three Merkaba
Fields connected with the D-4 Merkaba Field only at the level of the 12th
base tone and 12th overtone. These morphogenetic manipulations created
another Frequency Fence, which served as a protective barrier around Earth
and the neighboring planets. In energetic terms the 11:11/12:12 Frequency
Fence took the form of a spherical band of energy surrounding Earth, within
the D-1 and D-4 frequency bands—a protective “bubble” of multidimen-
sional energy. 
    Following the implementation of the Guardians’ Frequency Fence,
humanity was under three layers of frequency modulation, the original Fre-
quency Fence Quarantine from 9540 BC, the Zeta Seal Frequency Fence
from 1748 AD and the 11:11/12:12 Frequency Fence of 1972. All three of
these Frequency Fences would need to be lifted in order for the Blue Flame of
Amenti to become embodied on Earth between 2012 and 2017. As Fre-
quency Fences are morphogenetic manipulations, they also manifest within
the DNA imprint of the races. The DNA of 8% of the human populations
would have to be realigned and purged of the three Frequency Fence Seals
and the remaining mutations from the earlier Amenti, Palaidorian, Templar
and Templar-Axion Seals by January 1, 2012. Guardian races began conduct-
ing mass-level, consensual, soul-agreement abductions of humans since 1972,
in order to help humans begin repairing these genetic mutations, and also to
begin education on preparation for 2012. Memory repression tactics were
used to spare humanity the terror of facing events that it was not yet prepared
to understand. The Zetas had been conducting frequent forced abductions
since the late l940s as part of their hybridization program. They also used
memory repression tactics. Guardians did not participate in these forced
abductions, nor did they participate in intrusive experimentation. 
    When the 11:11/12:12 Frequency Fence was established in 1972, the
Guardians knew it was a temporary measure to buy the time they needed to
rebalance the Merkaba Fields of Earth and the Sun. Balancing the Merkaba
Fields was the most important project in the Guardian agenda. Since 9558 BC,
when the islands of Atlantis sank and the Earth tilted on her axis, the Guard-
ians knew they would have to assist in realigning the Merkaba Fields of Earth
134 

                                                                              Solar Crisis and 11:11/12:12
before the 2012-2017 ascension cycle. Following the events of 1943-1972,
this re-balancing effort would be much more difficult to achieve. Originally
the Guardians planned to slowly accelerate the vibration rate of Earth’s grid
through occasional infusions of D-4 energy that would slowly bring the grid
into alignment and correct the pole tilt over the course of about 2,000 years.
These occasional energy transmissions began in 196 BC, when Earth entered
its present 4,426-year cycle. In their original plan the Guardians intended to
raise Earth’s grid vibration into the UHF bands of the third dimension begin-
ning in the 1950s, so the first seal on the Arc of the Covenant could be
released no later than October of 1986. Following the release of the first seal
on the Arc, the Sphere of Amenti would begin its 12-14 month descent into
Earth’s core. 
    The Sphere of Amenti had to be in place no later than 1/1/1988 so the
Sphere would be able to fulfill the first 12-year phase of its activation cycle no
later than 2,000 AD. Once the Sphere was fully activated to the 3-dimen-
sional level in Earth’s D-2 core, it would cause Earth’s grid to send a spark of
D-5 frequency into the Arc of the Covenant, releasing the second seal on the
Arc. This would begin the 12-year descent of the Blue Flame of Amenti and
the shift of Earth from the D-3 to the D-4 time cycle. The second seal on the
Arc of the Covenant had to spark open no later than 6/1998 so the shift into
the D-4 time cycle would begin by 1/1/2000, in order for the Earth’s grid to be
prepared for proper fusion with Tara’s grid between 2012-2017. The D-5 fre-
quencies of the Blue Flame had to be embodied within the populations of
Earth, no later than 5/5/2012, or else Earth changes would result when the
grids began to merge. 
    When the Zetas’ Frequency Fence and genetic mutation from the
future began affecting Earth in 1748, creating blockages of the D-4 frequen-
cies in Earth’s morphogenetic field and fourth-strand DNA mutations in the
races, the Guardians began construction of an artificial D-4 grid imprint
within the Earth’s morphogenetic field. They re-entered the aligned D-4 fre-
quency patterns into the gold core crystal D-4 Merkaba Field at the center of
the Sun, which began to restore the D-4 imprint in the Earth’s morphoge-
netic field and within the Sphere of Amenti. This allowed the Guardians to
continue infusing Earth with D-4 frequency to slowly reverse Earth’s unnatu-
ral tilt on its axis. This artificial D-4 imprint also began the deterioration of
the Zetas’ Frequency Fence and a reverse mutation of the fourth DNA strand.
The new D-4 imprint manifested as a band of UHF energy surrounding the
outer portions of the Earth’s atmosphere, about 444,000 miles out in space,
just beyond the 12th overtone of the third dimension. It allowed human
consciousness to continue its expansion into D-4 perception and allowed the
Earth’s infusion of D-4 energy accelerations to continue. This artificial D-4
grid which the Guardians began constructing in 1748, has frequently been
referred to in New Age terminology as the “artificial Christ Consciousness     
135                                                                                                                
                                                                                                                   

        Countdown to Amenti 
Grid”. This term was chosen because the upper frequency bands of D-4 rep-
resent the beginning levels of the Turaneusiam 12-strand DNA conscious-
ness, which was exemplified on Earth by Jesheua-12 in 12 BC-27 AD. When
the problems arose with the Zetas’ manipulation of the Sun between 1943-
1972, the artificial D-4 grid became blocked by the 11:11/12:12 Frequency
Fence. 
    In 1972, the Guardians had to accelerate their whole energy infusion
program in order to reverse the damage the Zetas had caused, which meant
that humanity would be put on a course of very rapid evolution between 1972
and 2012. For the artificial D-4 grid to become operational again, the 11:11/
12:12 Frequency Fence had to be removed, which meant that the D-4 and D-
1 Merkaba Fields of the Sun had to be returned to their original polarity. This
would correct the D-1 Merkaba Field of Earth and the D-4 Merkaba Field of
Tara-Earth so the grids could fuse in 2012, if the Earth grid vibration was
raised high enough in time to hold the Sphere of Amenti. 
    The Earth’s grid had to reach the speed of the UHF bands of D-3 for the
first seal on the Arc of the Covenant to spark and release the Sphere of
Amenti by 10/1986. It would be difficult, if not impossible, for the Guardians
to raise Earth's grid speed that high without the infusions of D-4 energy that
were now blocked by the 11:11/12:12 Frequency Fence, so correction of the
Sun’s Merkaba Fields became a race for time within the Guardian legions.
Even though the Frequency Fence did not lift until 1992, the Guardians were
successful in raising the grid speed enough for the Arc of the Covenant to
open by the 10/1986 deadline. The accelerated energy infusions used to re-
balance the Merkaba Fields of the Sun, began in 1973 and were projected
into the solar fields via beam ships stationed in the future D-4 time cycle.
These infusions would cause rapid shifts of the energy fields on Earth, which
would have created havoc within the consciousness of the human popula-
tions and instability of Earth’s natural EM fields. However, the 11:11/12:12
Frequency Fence allowed the Guardians to employ Holographic Insert tech-
nology on Earth, through which the illusion of grid stability could be created,
so the Guardian re-balancing efforts would remain undetected and excessive
instability within the human populations could be avoided. Earth existed
under these Guardian-created Holographic Inserts from 1973 to 1/11/1992, when
the 11:11/12:12 Frequency Fence began lifting. 
                                      
                                      THE MONTAUK PROJECT 
          
          Zetas and Rigelians, the Montauk Project 1983 and 2976 AD
 
    Between 1973 and 1980 Earth remained under the Guardians’ Holo-
graphic Inserts and the illusion of electromagnetic stability they created,
while the Guardians worked to complete realignment of the Sun’s Merkaba
Fields. By 1982 the Zetas became tremendously frustrated as they observed
136 
                        

                                                                            
                                                                                 The Montauk Project
the continuing breakdown of their Collective Mind Complex in the D-4
time cycle, and began to realize that the Guardians would correct the mis-
alignment of the Sun in time for the ascension period to proceed as sched-
uled. Between 1982 and 1984, most members of the Zeta Legion entered into
treaties with the Guardian races, and agreed to stop their plan of Earth infil-
tration. These agreements also included the Zetas from the D-4 time cycle,
who had fallen under domination of the Dracos in that future time period.
The Guardians agreed to relocate the Zeta races and their hybrids to another
planetary system in D-4, where they could evolve peacefully, as long as the
Zetas agreed to follow the dictates of the Sirian Council and Galactic Federa-
tion, and to operate upon principles of the Law of One from that time for-
ward. The Zetas were also required to fully dismantle their Collective Mind
Complex in D-4, to release the Zeta Seal Frequency Fence and to assist the
Guardians in preparing Earth and humanity for 2012. Though most of the
Zetas agreed, and began working with the Guardians in 1983, several Zeta
and most Dracos groups refused to release their desire for possession of Earth.
These groups became known as the Dracos-Zeta Resistance, which included
rebellious Zeta races, Dracos and their hybrids. 
     The primary Zeta groups that refused Guardian treaties are the Zeta
Greys from a solar system that orbits the star Rigel, in the Orion star system.
These are frequently called the Rigelians; we know them as the Futczhi (pro-
nounced FOO’-SHE). It is this Zeta group that formed treaties with the Inte-
rior Government on Earth and orchestrated the Zeta Seal and manipulations
of the Sun. They are the most aggressive and militant of the Zeta Grey races
and are extremely dangerous to humans, because they often attempt to
present themselves as Guardians in order to seduce humans into being their
earthly operatives. The Rigelians/Futczhi dominated the other Zeta races in
the D-4 time cycle until the majority of these non-Rigelian Zetas rebelled
and sought Guardian protection when this option was offered between 1982-
1984. Following the Guardian treaties of 1982-1984, the Zeta-Dracos hybrids
known as the Rutilia, who had always been the primary go-betweens in Zeta-
Futczhi/human relations, served as infiltrates within the Interior Govern-
ment, and continued to secretly motivate humans to continue helping them
fulfill their old agenda. (Note: the Rutilia are those beings referred to by the
government as “EBE’s” - Extraterrestrial Biological Entities. They closely
resemble the Greys, but usually have a lighter gray to gray-white complexion,
and more pronounced ridging at the rear of the skull.) The Dracos-Zeta
Resistance had to find a way to reconstruct the Zeta Seal, Frequency Fence
and Zeta Collective Mind Complex before 2012, in order to regain control of
the human populations in D-4. 
     The Dracos-Zeta Resistance set their new plan in motion in 1983, when
they covertly motivated humans to create another experiment, similar to the 
Philadelphia Experiment of 1943. They desired to create another rip in space-
137 

Countdown to Amenti 
time, through which large numbers of their ships could be secretly sent from
the future to Earth, into three different time-space coordinates. From these
positions in time, the ships could enter the D-2 frequency bands of Earth and
begin transmitting EM pulses through the Earth’s grid, which would serve to
reconstruct their Frequency Fence and cause mutation in the fourth DNA
strand. 
     Even if the grids of Earth and Tara were able to merge between 2012-2017,
the human gene code would not have time to fully assemble the fifth DNA
strand in the majority of the populations. This would stop the scheduled ascen-
sions through the Halls of Amenti and keep the Zeta Seal operational within
the Sphere of Amenti, so their human captives in D-4 would once again be
subject to Zeta-Dracos control. For their new plan to work, the Zetas had to
begin broadcasting their EM pulse Frequency Fence as close to 2012 as possible,
while still allowing enough time for the fence to take effect within the human
gene code. It would take a minimum of six years for the new frequency fence to
cause the fourth DNA strand mutation in the majority of the human popula-
tions, so the Dracos-Zeta Resistance would have to begin broadcasting their
EM pulses no later than 2006. If they began broadcasting too soon, the Guard-
ians’ infusions of  D-4 frequency would counteract their EM transmissions, and
the genetic mutation would not “hold” within the DNA. The Dracos-Zeta
Resistance decided upon the year 2004 as their target date. In order to fulfill
their plan of covert mass infiltration, they would have to enter their ﬂeets into
Earth’s D-2 frequency bands during the peak of Earth’s D-1/D-4 Merkaba Field
cycle, which takes place every 20 years on August 12th. 
    Dimensional Merkaba Fields go through cycles of movement in which
the two spiraling energy fields vertically condense and draw toward each
other, then progressively expand on the vertical axis, drawing away from each
other. When the Merkaba Fields draw away from each other, the upright
electrical spiral moves into the magnetic Merkaba spiral of the dimension
above, which causes a temporary blending of frequencies between the mag-
netic spiral of one dimension and that of the dimension above. These points
of interdimensional magnetic spiral blending are called Dimensional Mag-
netic Peaks. During Magnetic Peaks, natural interdimensional portal win-
dows briefly open, allowing unencumbered transit between dimensional
bands. Magnetic Peaks also occur between the Merkaba Spirals of Harmonic
Universes, through which the Merkaba Fields of a dimension in one Har-
monic Universe blend with the Merkaba Fields of the corresponding dimen-
sion one Harmonic Universe up; these blending periods are called Harmonic
Magnetic Peaks. Each Harmonic Universe has three dimensions, each of the
three dimensions representing a base tone, overtone or resonant tone, within
the 15-dimensional scale. D-1, D-4, D-7, D-10, and D-13 are base tone
dimensions. D-2, D-5, D-8, D-11 and D-13 are overtone dimensions. D-3, D-
138 

  
                                                                                    The Montauk Project
6, D-9, D-12 and D-15 are resonant tone dimensions. Harmonic Magnetic
Peaks occur when base tone—base tone, overtone—overtone, or resonant
tone—resonant tone Merkaba Field alignments take place. The D-1 base tone
Merkaba Field of Earth and the D-4 base tone Merkaba Field of Tara reach
their Magnetic Peak cycle once every 20 years between August 12th-15th,
at which time a dimensional window opens between Earth’s HU-1, and Tara’s
HU-2, time continuum cycles. 
    The first Harmonic Magnetic Peak of the 20th century occurred on
August 12th, 1903, and the last on August 12th, 1983. These periods mark a
time of peak magnetic pull within Earth’s subtle energy bodies and height-
ened dimensional blending, through which large numbers of Dracos-Zeta
ships could be cloaked and brought to Earth from D-4. August 12th, 2003 is
the closest peak date to the Dracos-Zeta Resistance target date of 2004. The
plan called for a simultaneous entry of beam ships during three time periods,
and once the Zetas had successfully orchestrated infiltration, they would
broadcast their Frequency Fence through Earth’s grid and begin the genetic
mutation. If they attempted this mutation from only one time period, there
would not be enough time for it to take hold within the majority of the popu-
lations. By entering the EM transmissions at the three different, but closely
related time periods of 1943, 1983, and 2003, a great number of people would
be affected. 
    For the Dracos-Zeta Resistance plan to be effective, they would have to
create three rips in space-time on Earth, through which their ships could be
entered. One such rip already existed from the Philadelphia Experiment of
1943 and one would have to be created in 2003. The Resistance scheduled
the third rip in space-time for the next Harmonic Magnetic Peak cycle of
August 12th 1983, the only opportunity they would have before 2003.
Working with the Interior Government, the Dracos-Zeta Resistance orches-
trated another experiment, which came to be known as the Montauk
Project. Again, accounts of this experiment are available in other publica-
tions, so we will not detail here. 
    The Montauk project served to widen the rip in 1983 space-time that
had begun as the result of the Philadelphia Experiment. By August 14th
1983 the time periods of 1943 and 1983 were successfully linked to the Dra-
cos-Zeta Resistance D-4 time period, which they used as a base of operations.
From 1983 to the present, the Dracos-Zeta Resistance resumed their
hybridization program through abducting humans, creating several strains
of hybrids and human clones. They also created infiltrates via genetic engi-
neering, through which they could interface with Earth’s cultures under
the guise of human form. Infiltrates are children conceived of natural
human conception, whose mothers were abducted during pregnancy so Zeta-
Dracos genetic materials could be infused into the fetus. These children are
born (usually within the seventh month of gestation) and raised by their
139 
                                                                                                                                                              

Countdown to Amenti 
human parents, and appear to be fully human. They are consciously unaware
of their ET affiliation, but can be subliminally directed by the Dracos-Zeta
Resistance via the DNA and neurological structure. When Guardian groups
locate such infiltrate individuals, they orchestrate abductions, and dismantle
the Zeta-Dracos gene codes, thereby freeing these mostly human subjects
from their covert controllers. 
                            
                         2976 AD and the Dracos-Zeta Resistance 
    The Guardians became aware of the Dracos-Zeta Resistance problem in
1984, and were able to trace probable events in the future that would result
from this present activity. What they discovered was alarming, as the conse-
quences of this infiltration were more far-reaching than they had speculated.
They discovered a future event that would occur in the year 2976 AD, that was
the result of the Zetas’ interference after the year 2000. In this probable future,
the Guardians had been successful in realigning the Merkaba Fields of Earth
and the Sun, but in 2003 AD the Dracos-Zeta Resistance is also successful with
their infiltration plan. The Guardians saw that the Zetas’ new Frequency Fence
partially misaligns Earth’s grid in 2012, and when Earth and Tara begin to inter-
sect, major Earth changes result. Though Earth still fuses with Tara and
releases a morphogenetic wave as intended, just as that wave begins to crest
(2012), the Earth changes begin. When the morphogenetic wave begins to
crest, the Halls of Amenti portals open, but the Earth grid must be stable in
order for the Halls to remain open through their 10-year cycle (2012-2022).
The Earth changes cause a premature closing of the Halls of Amenti, which
creates a rapid drop in Earth’s grid speed. The Sphere of Amenti cannot be left
in Earth's core during this drop in vibration or the Earth grid will explode. In
this future probability, Guardians remove the Sphere of Amenti from Earth and
human populations come under direct covert control of the Dracos-Zeta Resis-
tance. The Zeta Seal genetic mutation is returned to the human race. Once
Earth is under Dracos-Zeta rule, the Zetas are attacked and dominated by the
Dracos group with whom they had been working. The Dracos take command
of Earth in both the D-3 and D-4 time cycles and begin to use the D-3 Earth
as a storehouse for unwanted photo-nuclear waste materials from the D-4
Tara-Earth time cycle. (Photo-nuclear waste is produced through certain pro-
cesses involving the manufacture of photonic energy through manipulation of
multidimensional nuclear materials). This process causes a massive nuclear
explosion on D-3 Earth in 2976 AD, through which Earth is destroyed. All
souls involved in the cataclysm fragment and are lost within HU-1. Their con-
nections to the Sphere of Amenti race morphogenetic field and their personal
soul matrices are severed. 
    If this future event occurred in present-Earth's line of development, not
only would the Earth and the major part of the human race be lost, but the evo-
140 

                                                                                
                                                                                     The Montauk Project
lution of Tara in HU-2 would be set back by eons, as Tara would remain
trapped in her HU-2 time cycles until Earth’s imprint could be reconstructed
and re-evolve in HU-1. 
    Upon discovering these probable future events, Guardian groups made
an appeal to the Resistance Zetas, telling them of the Dracos’ betrayal and
offering to assist them in relocation, if they would give up their infiltration
plan. The Zetas refused to alter their plans. 
    Though the Guardians could easily subdue the Dracos-Zeta legions in a
forced confrontation, such a confrontation would cause major damage to
the Earth’s Merkaba Fields, which would ensure the destruction of the
human populations. The Guardians had to find a better way to avert the
new Dracos-Zeta agenda. Not only did the Guardians bear the responsibility
for preparing Earth and humanity for 2012, they now had the additional bur-
den of protecting their preparation plan from Dracos-Zeta Resistance sabo-
tage. In December of 1984, the Sirian Council, Pleiadian Star League,
Sirian-Arcturian Coalition for Inter—planetary Defense, the Andromeda Fed-
eration of Planets, the Palaidorians of HU-2 and several other Guardian
groups from HU-l, HU-2 and HU-3, co-created the Bridge Zone Project, in
order to protect Earth and the human populations from Dracos-Zeta Resis-
tance infiltration, and the destruction of Earth in 2976 AD that would result
from this interference. 
    The Dracos-Zeta Resistance is presently quite aware of the Guardian’s
Bridge Zone plan, but they are confident that humanity will be unable to rise
to the occasion and feel sure their infiltration plan will be successful. The
Guardians believe humanity can indeed pull together and make the Bridge
Zone project a success. For this reason we of the Guardian Alliance bring to
you this hidden knowledge, so that you may be prepared to make a stand on
behalf of your own evolution and freedom. 
141 

                                                                                                            
                                    8 
                   
                         
                                                                                      
                        
                       
 
                     
                         Current Events 
                      
                                             THE BRIDGE ZONE PROJECT 
                           
                                        The Bridge Zone Time Continuum Shift 
                    12/1984 - present
 
        
    Before the Dracos-Zeta legions had altered the EM fields of the Sun in
1943 the Guardians’ preparation plans were relatively simple. Using their
artificial “Christ Consciousness” D-4 grid from 1748, they progressively sent
transmissions of UHF D-4 energy into Earth’s grid to raise the vibration of
Earth’s core high enough to send the first spark into the Arc of the Covenant
by October of 1986. The Sphere of Amenti would complete its 14-month
descent through the Arc from the UHF bands of D-3 by 1988. The Sphere of
Amenti would merge its D-1, D-2 and D-3 frequency patterns with, and
expand Earth's morphogenetic field no later than 6/1998, which would spark
the Arc a second time, beginning the 12-year descent of the Blue Flame and
Earth’s temporary 2000 AD shift into the D-4 time cycle. The Guardians
would continue to gradually realign Earth's Merkaba Fields/electromagnetic
fields to correct the tilt caused by Atlantis sinking. This would align Earth’s
fourth vortex/Heart Chakra at Giza with the Alcyone energy spiral by 2004,
in preparation for Earth’s entry into the Photon Belt and Holographic Beam,
and the opening of the Halls of Amenti in 2012. 
    The original Quarantine Frequency Fence from 9540 BC would begin to
lift once the Arc of the Covenant first opened, and all traces of the fourth-
strand DNA Zeta Seal mutation and Zeta Frequency Fence would dissolve
once the Arc was sparked a second time and D-4 frequency from the Sphere
of Amenti would begin transmitting through Earth’s grid. Between 1/1988 and
1/2017, the seven natural seals on Earth’s seven primary vortex points would pro-
gressively  open  as   the    dimensional  Merkaba  Fields   and   Stellar  Spirals   began   opening
and blending into each other, while the Guardians assisted the Earth grid to remain
balanced through these transitions. The Guardians planned to offer dispensa-
tions of teachings to humans while the veils between the ego, higher self and
142 

                                                                              
                                                                               The Bridge Zone Project
soul identity began to lift, as the DNA progressively assembled. The Guard-
ians’ primary concern at this time was to realign Earth’s Merkaba Fields and
bring Giza into alignment with Alcyone. They would ensure that the descent
of the Sphere of Amenti and the Blue Flame stayed on schedule. Guardians
were to maintain planetary balance while Earth’s seven vortex seals opened,
and they would begin making subtle contact with humans, to help them pre-
pare for the opening of the Halls of Amenti. 
    Following the 1943 Philadelphia Experiment, the Zetas’ manipulation
of the solar Merkaba Fields and the necessity of the Guardians’ 11:11/12:12
Frequency Fence of 1972, the Guardians’ preparation plan and deadline
schedule became more taxing. Before the original plan could continue, the
11:11/12:12 Frequency Fence, which blocked all of the fourth-dimensional
frequencies except the 12th base tone and overtone out of Earth’s grid, had to
be dismantled. Though the Guardians could alter the Frequency Fence
enough to allow the Sphere of Amenti to enter Earth's core on schedule, the
fence could not remain intact when the Sphere of Amenti began transmit-
ting D-4 frequency into Earth’s grid in 1/2000, when the fourth vortex seal
opened. lt would take about four years for the Earth’s grid to balance once
the 11:11/12:12 Frequency Fence was released, so the fence had to be down
no later than 1/1996. 
     Once the Sphere of Amenti was opened, if the D-4 frequencies could not
enter Earth’s core in 1/2000, the D-4 Merkaba Field of Tara, the gold core
crystal stored at the center of the Sun, would explode. In this event, not only
would Earth explode, but so would the other 10 planets of the local solar sys-
tem and the Sun, all of which are energetically attached to the D-4 Merkaba
Field gold core crystal. This would begin a similar chain reaction within the
Pleiadian star system, to which Earth’s Sun belongs. As you may now under-
stand, balance and timing are extremely important factors when the Halls of
Amenti open. In order to remove the 11:11/12:12 Frequency Fence, the
Merkaba Fields of the Sun would have to be carefully realigned no later than
6/1994, which would allow one and one-half years for the Earth’s grids to
rebalance before the Frequency Fence was lifted. Realigning the solar fields is
a delicate process in and of itself, but this process combined with the general
preparations of opening the Halls of Amenti within the scheduled deadlines
served to make the Guardians’ task even more complex. 
     As if these complications were not enough, the Guardians then discov-
ered the potentially disastrous results of the Dracos-Zeta Resistance infiltra-
tion and their plan to re-institute their Frequency Fence and Zeta Seal in
2003. The events of the 2017 ascension cycle were taking a very serious turn,
and if the circumstances were not handled properly, the human populations
would be decimated by severe Earth changes between 2012-2017. The
option of stopping the Sphere of Amenti from descending through the Arc of
the Covenant, and thus allowing Earth and humanity to remain trapped
143 
                                                                                                                     
                                                                                                                 

  
   Current Events 
within HU-1 time cycles for another 26,556 years, was no longer open. The
Earth changes of 2012-2017 could be primarily avoided in this case, but
humanity would fall under dominion of the Dracos-Zeta Resistance and
under that inﬂuence the Earth would meet with an untimely, cataclysmic end
in 2976 AD. These events could not be allowed to transpire, as they were set
to occur. The explosion of Earth would cause tragic consequences for Earth,
Tara and numerous other star systems. The lost souls of Tara, whom the
Guardians had so painstakingly nurtured and protected for the past 550 mil-
lion years, would once again be fragmented and left with no evolutionary
blue print to follow. 
    The Rigelian/Futczhi Zetas working with the Dracos would not listen
to reason and the Dracos would not release their claims on Earth. Confronta-
tional force between the Guardians and the Dracos-Zeta Resistance, during
Earth’s most vulnerable period, would destroy the planetary balances of
Earth, so the Guardians had to turn to high-spiritual technology in order to shift the
course of events as they were evolving on Earth. In 1984 Guardian groups from
HU-1, HU-2 and HU-3 joined together to create the Bridge Zone Project.
The basic idea behind the Bridge Zone project involved shifting Earth com-
pletely out of the HU-1 time cycle, an event that would not occur naturally
until the second morphogenetic wave of the second ascension cycle, during
the natural Doreadeshi in 4230 AD. Since the Guardians could not move the
Dracos-Zeta Resistance out of the way of Earth’s intended evolution, they would
instead move Earth out of the way of the Dracos-Zeta Resistance. The Guardians
would construct an artiﬁcial time continuum between the third and fourth dimen-
sions, into which Earth could pass in 2017. This constituted orchestrating a forced
Doreadeshi, 2213 years ahead of its natural schedule. 
    In order for the Dracos-Zeta Resistance’s Frequency Fence to work in
2003-2004 AD, they had to transmit very specific EM pulses, at very specific
angles through the Earth’s grid. The Zetas had worked since 1943 to deci-
pher the appropriate calculations to use for the projections of their EM
pulses. If the Merkaba Fields of Earth were rapidly accelerated, which would
constitute a planetary leap in time cycles from the HU-1/D-3 cycle to Bridge
Zone D-3.5 cycle of the lnner Earth, between D-3 and D-4, the Zetas-Dracos
calculations would be useless. The Earth’s grid speed would be increased to a
level that the Frequency Fence EM pulses could not reach. The Dracos-Zeta
Resistance would not have enough time to decipher new calculations, and
once Earth was stabilized in the Bridge Zone D-3.5 time continuum, and
under full Guardian protection, the Dracos-Zetas could not successfully
launch an infiltration. Furthermore, if Earth was successfully shifted, and its
frequency  raised sufficiently, the Dracos-Zetas would lose control of  their  Fre-
quency Fence and their human captives in the D-4 cycle. For humanity to shift
into the Bridge Zone with Earth, the populations would have to fully assemble
their DNA to the 4.5 -strand level, and a minimum of  8% would have to assemble
144 

                                                                                   
                                                                              
                                                                  The Bridge Zone Mechanics
the ﬁfth DNA strand. Along with this, 144,000 individuals would need to fully
assemble the sixth strand, embody their entire soul matrix and begin to assemble the
seventh-twelfth strands. This acceleration of the human genetic imprint would
release the D-4 Zeta Seal from all of the human races, present and future, and
would allow Earth’s grid speed to raise high enough to remain in the Bridge
Zone. 
    Following the shift to the Bridge Zone, Earth would leap ahead 2213
years by skipping the second half of its D-3 cycle, then move backward in
time 1106.5 years within the Bridge Zone cycle. After completing 1106.5
years in the Bridge Zone, Earth would leap ahead another 1106.5 years by
skipping the first half of its first D-4 cycle. Earth would then pass into the first
D-4 cycle at the half-cycle point and continue its path of natural evolution
through the D-4 time cycles. This movement of 2213 years ahead, 1106.5
back, and 1106.5 ahead in time represents a cumulative leap of 2213 years in
evolutionary space-time progression. The Dracos-Zeta Frequency Fence
would end up in the dimensional frequency bands below the Bridge Zone fre-
quency bands in which the Earth was positioned, and thus Earth’s grid would
be unaffected. However, once Earth was above the frequency fence, it could
not be re-entered into the dimensional bands below the fence. The Merkaba
Fields of Earth would re-seal in 2017, locking Earth into the Bridge Zone
time continuum. If the Guardians were going to force an early Doreadeshi, by
moving both the overtone/electrical fields and the base tone/magnetic fields
of Earth into the Bridge Zone time continuum cycle during the 2017 half-
cycle point, the move would have to be permanent. 
 
                                    BRIDGE ZONE MECHANICS
 
    The idea of shifting a planetary body from one time continuum to
another may seem quite outrageous to a civilization that does not yet have a
working comprehension of multidimensional physics. We assure you that
such a procedure is most definitely real and valid in terms of the structural
energetic dynamics of the Time Matrix. This procedure is not used fre-
quently, for it is a complex and delicate process requiring direct intervention
from the higher Harmonic Universes of HU-3-HU-5. For the most part,
planets and civilizations are allowed to evolve along the course of their own
development, following their own choices and meeting with the conse-
quences of those choices. But occasionally a planet and its peoples get into
trouble that has far-reaching consequences for numerous planetary systems,
and in these cases intervention in the course of evolution is permitted. Earth
is presently in such a state of potential crisis, unbeknownst to most of its pop-
ulations. 
145 
                                                                                                                     
  
 
 
 
 
 
 
 
 
 

 
            Current Events 
                           TIME-CYCLE MECHANICS AND EVOLUTION 
                                       
                                                    Time-Cycle Mechanics 
    In order to understand the dynamics involved in such a time continuum
shift, it is helpful to realize that the structure and illusion of linear time is cre-
ated through the pulsation rate of particles and their relationship to that of
other particles. Each of the six 4,426 year smaller cycles within one 26,556
year Harmonic Time Cycle represents one time continuum. A 26,556-year
Harmonic Time cycle, through which a planet evolves through the 3-dimen-
sional bands of one Harmonic Universe, is called an Euiago. A planet passes
through each of the six smaller time continua as it progresses upward through
the 3-dimensional scale within its Harmonic Universe. Each dimensional
band contains two time continua of 4,426 years each, so each dimension rep-
resents a time track of 8,852 years. 
    Of the six time continua in a 26,556-year Euiago cycle, four time con-
tinua represent forward-moving tracks of time called Pardo, and two repre-
sent counter-rotating tracks of time called Reiago, in which the planet passes
through the parallel universe. A Pardo = 17,704 years (4 continua of 4,426
years each = 4 x 4,426 years = 17,704 years). A Reiago = 8,852 years (2 con-
tinua of 4,426 years each = 2 x 4,426 = 8,852 years) spent in the parallel uni-
verse. Each Euiago contains one Pardo and one Reiago. 
    A planet’s progression through one time continuum creates a 45° shift in
the angular rotation of particle spin, or 1/8th of a full 360° rotation of parti-
cles, thus one continuum represents one dimensional Octave. One Octave =
a 4,426-year track of time. One dimension contains two time continua, or two
Octaves. A planet’s progression through one dimension creates a 90° shift (2
shifts of 45°) in the angular rotation of particle spin, or one-fourth of a full
360° rotation, thus one dimension represents one Harmonic Quadrant. One
Quadrant = an 8,852-year track of time. Three dimensions, three Quadrants,
or six Octaves (time continua) represent one Harmonic Universe. One Har-
monic Universe = a 26,556-year track of time. 
    As a planet progresses through the first two Pardo Octaves, the angular
rotation of particle spin shifts 90° from its original position. Upon entering
the two Reiago Octaves in the parallel universe, the angular rotation of parti-
cle spin undergoes a 90° reverse rotation, bringing the angular rotation of
particle spin back to its original position. As the planet completes the final
two Pardo Octaves, returning from the parallel universe, the angular rotation
of particle spin again shifts 90°. Through the progression of three dimen-
sions, or Quadrants, the angular rotation of particle spin has a cumulative
shift of 90° (+90°, -90°, +90° = +90° shift), so in one Harmonic Universe the
angular rotation of particle spin undergoes one-quarter of a full 360° rotation.
    When passing from one Euiago cycle (Harmonic Universe) to the next,
the angular rotation of particle spin shifts 45°. Between HU-1 and HU-2, the
146 
